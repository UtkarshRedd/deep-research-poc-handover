<!-- page 1 -->
# AGENCY AGREEMENT
| Field | Value |
|---|---|
| Document Type | Agency Agreement |
| SEC Filing Date | 1999-12-16 |
| Parties | (Alamogordo Financial Corporation ("Company"); AF Mutual Holding Company ("MHC"); Alamogordo Federal Savings and Loan Association ("Bank"); Savings Association Insurance Fund ("SAIF"); Federal Deposit Insurance Corporation ("FDIC"); Charles Webb & Company; Bruyette & Woods, Inc. ("Agent")) |
| Source | CUAD v1 / ALAMOGORDOFINANCIALCORP_12_16_1999-EX-1-AGENCY AGREEMENT |

ALAMOGORDO FINANCIAL CORPORATION 1,101,643 Shares

COMMON STOCK (Par Value $.0l Per Share)

Subscription Price $10.00 Per Share

AGENCY AGREEMENT

___________ __, 2000

Charles Webb & Company, a Division of Keefe, Bruyette & Woods, Inc. 211 Bradenton Avenue Dublin,
Ohio 43017

Ladies and Gentlemen:

Alamogordo Financial Corporation, a federal corporation (the "Company"), AF Mutual Holding Company
(the "MHC") and Alamogordo Federal Savings and Loan Association, a federally chartered stock savings
and loan association (the "Bank") with its deposit accounts insured by the Savings Association
Insurance Fund ("SAIF") administered by the Federal Deposit Insurance Corporation ("FDIC"), hereby
confirm, jointly and severally, their agreement with Charles Webb & Company, a Division of Keefe,
Bruyette & Woods, Inc. (the "Agent"), as follows:

Section 1. The Offering. In accordance with the Stock Issuance Plan adopted by its Board of
Directors (the "Plan"), the Company will offer and sell up to 1,101,643 shares of its common stock,
par value, $.01 per share (the "Shares" or "Common Stock"), in a subscription offering (the
"Subscription Offering") to (1) depositors of the Bank with account balances of $50.00 or more as of
September 30, 1998 ("Eligible Account Holders"), (2) the Employee Stock Ownership Plan of the Bank
(the "ESOP"), (3) depositors of the Bank with account balances of $50.00 or more as of December 31,
1999 ("Supplemental Eligible Account Holders"), and (4) employees, officers and directors of the
Bank. To the extent Shares remain unsold in the Subscription Offering, the Company is offering for
sale in a community offering (the "Community Offering" and when referred to together with the
Subscription Offering, the "Subscription and Community Offering") the Shares not so subscribed for
or ordered in the Subscription Offering to members of the general public, with preference given to
natural persons residing in the New Mexico counties of Otero and Lincoln

("Other Subscribers"), (all such offerees being referred to in the aggregate as "Eligible
Offerees"). It is anticipated that shares not subscribed for in the Subscription and Community
Offering will be offered to certain members of the general public on a best efforts basis through a
selected dealers arrangement (the "Syndicated Community Offering") (the Subscription Offering,
Community Offering and Syndicated Community Offering are collectively referred to as the
"Offering"). It is acknowledged that the purchase of Shares in the Offering is subject to the
maximum and minimum purchase limitations as described in the Plan and that the Company and the Bank
may reject, in whole or in part, any orders received in the Community Offering or Syndicated
Community Offering. The Company will issue the Shares at a purchase price of $10.00 per share (the
"Purchase Price").

The Company has filed with the Securities and Exchange Commission (the "Commission") a registration
statement on Form S-1 (File No. 333- ) (the "Registration Statement") containing a prospectus
relating to the Offering for the registration of the Shares under the Securities Act of 1933 (the
"1933 Act"), and has filed such amendments thereof and such amended prospectuses as may have been
required to the date hereof. The term "Registration Statement" shall include all exhibits thereto,
as amended, including post-effective amendments. The prospectus, as amended, on file with the
Commission at the time the Registration Statement initially became effective is hereinafter called
the "Prospectus," except that if any Prospectus is filed by the Company pursuant to Rule 424(b) or
(c) of the rules and regulations of the Commission under the 1933 Act (the "1933 Act Regulations")
differing from the prospectus on file at the time the Registration Statement initially becomes
effective, the term "Prospectus" shall refer to the prospectus filed pursuant to Rule 424(b) or (c)
from and after the time said prospectus is filed with the Commission.

In accordance with Title 12, Parts 575 and 563b of the Code of Federal Regulations (the "MHC
Regulations"), the Company has filed with the Office of Thrift Supervision (the "OTS") an
Application on Form MHC-2 with respect to the stock issuance (the "MHC Application"), including the
Prospectus and the Valuation Appraisal Report prepared by RP Financial, LC (the "Appraisal") and has
filed such amendments thereto as may have been required by the OTS. The MHC Application has been
approved by the OTS and the related Prospectus has been authorized for use by the OTS.
<!-- page 2 -->
Section 2. Retention of Agent; Compensation; Sale and Delivery of the Shares. Subject to the terms
and conditions herein set forth, the Company and the Bank have retained the Agent to consult with
and to advise the Bank, the MHC and the Company, and to assist the Company, on a best efforts basis,
in the distribution of the shares of Common Stock in the Offering. The services that the Agent will
provide include, but are not limited to (i) training the employees of the Bank who will perform
certain ministerial functions in the Subscription and Community Offering regarding the mechanics and
regulatory requirements of the stock offering process, (ii) managing the Stock Information Center by
assisting interested stock subscribers and by keeping records of all stock orders and (iii)
preparing marketing materials.

2

On the basis of the representations, warranties, and agreements herein contained, but subject to the
terms and conditions herein set forth, the Agent accepts such appointment and agrees to consult with
and advise the Company, the MHC and the Bank as to the matters set forth in the letter agreement
("Letter Agreement"), dated November 29, 1999 between the Company and the Agent (a copy of which is
attached hereto as Exhibit A). It is acknowledged by the Company, the MHC and the Bank that the
Agent shall not be required to take or purchase any Shares or be obligated to take any action which
is inconsistent with all applicable laws, regulations, decisions or orders.

The obligations of the Agent pursuant to this Agreement (other than those set forth in Sections
2(d), 8 and 9 hereof) shall terminate upon the completion or termination or abandonment of the Plan
by the Company or upon termination of the Offering, but in no event later than the date (the "End
Date") which is 45 days after the Closing Date (as hereinafter defined). All fees or expenses due to
the Agent but unpaid will be payable to the Agent in next day funds at the earlier of the Closing
Date (as hereinafter defined) or the End Date. In the event the Offering is extended beyond the End
Date, the Company, the MHC, the Bank and the Agent may agree to renew this Agreement under mutually
acceptable terms.

In the event the Company is unable to sell a minimum of 708,050 Shares within the period herein
provided, this Agreement shall terminate and the Company shall refund to any persons who have
subscribed for any of the Shares, the full amount which it may have received from them plus accrued
interest as set forth in the Prospectus; and none of the parties to this Agreement shall have any
obligation to the other parties hereunder, except as set forth in this Section 2 and in Sections 6,
8 and 9 hereof.

In the event the Offering is terminated, the Agent shall be reimbursed for its actual accountable
out-of-pocket expenses.

If all conditions precedent to the consummation of the Offering, including, without limitation, the
sale of all Shares required by the Plan to be sold, are satisfied, the Company agrees to issue, or
have issued, the Shares sold in the Offering and to release for delivery certificates for such
Shares on the Closing Date (as hereinafter defined) against payment to the Company by any means
authorized by the Plan; provided, however, that no funds shall be released to the Company until the
conditions specified in Section 7 hereof shall have been complied with to the reasonable
satisfaction of the Agent and their counsel. The release of Shares against payment therefor shall be
made on a date and at a place acceptable to the Company, the MHC, the Bank and the Agent.
Certificates for shares shall be delivered directly to the purchasers in accordance with their
directions. The date upon which the Company shall release or deliver the Shares sold in the
Offering, in accordance with the terms herein, is called the "Closing Date."

The Agent shall receive the following compensation for its services hereunder:

3

(a) A management fee of $25,000, payable in four installments of $6,250 on November 29 and December
29, 1999 and January 29 and February 29, 2000. Should the Offering be terminated for any reason not
attributable to the action or inaction of the Agent, the Agent shall have earned and be entitled to
be paid fees accruing through the stage at which the termination occurred.

(b) A Success Fee of $75,000.

(c) If any of the shares remain available after the Subscription and Community Offerings, at the
request of the Bank, the Agent will seek to form a syndicate of registered broker-dealers to assist
in the sale of such Common Stock on a best efforts basis, subject to the terms and conditions set
forth in the selected dealers agreement. the Agent will endeavor to distribute the Common Stock
among dealers in a fashion which best meets the distribution objectives of the Bank and the Plan.
the Agent will be paid a fee not to exceed 5.5% of the aggregate Purchase Price of the Shares sold
by them. the Agent will pass onto selected broker-dealers,
<!-- page 3 -->
who assist in the syndicated community, an amount competitive with gross underwriting discounts
changed at such time for comparable amounts of stock sold at a comparable price per share in a
similar market environment. Fees with respect to purchases affected with the assistance of a
broker/dealer other than the Agent shall be transmitted by the Agent to such broker/dealer. The
decision to utilize selected broker-dealers will be made by the Bank upon consultation with the
Agent. In the event, with respect to any purchases of Shares, fees are paid pursuant to this
subparagraph 2(c), such fees shall be in lieu of, and not in addition to, payment pursuant to
subparagraph 2(a) and 2(b).

(d) The Company will bear those expenses of the proposed offering customarily borne by issuers,
including, without limitation, regulatory filing fees, "Blue Sky," and NASD filing and registration
fees; the fees of the Company's accountants, attorneys, appraiser, transfer agent and registrar,
printing, mailing and marketing and syndicate expenses associated with the Offering; the fees set
forth in Section 2; and fees for "Blue Sky" legal work. If the Agent incurs expenses on behalf of
the Company, the Company will reimburse the Agent for such expenses.

The Agent shall be reimbursed for reasonable out-of-pocket expenses, including costs of travel,
meals and lodging, photocopying, telephone, facsimile and couriers. The Agent shall also be
reimbursed for its fees of underwriter's counsel (including counsel's out-of-pocket expenses) not to
exceed $35,000. The selection of such counsel will be done by the Agent, after consultation with the
Bank.

Section 3. Prospectus; Offering. The Shares are to be initially offered in the Offering at the
Purchase Price as defined and set forth on the cover page of the Prospectus.

4

Section 4. Representations and Warranties of the Company, the MHC and the Bank. The Company, the MHC
and the Bank jointly and severally represent and warrant to and agree with the Agent as follows:

(a) The Registration Statement which was prepared by the Company, the MHC and the Bank and filed
with the Commission was declared effective by the Commission on __________ __, 2000. At the time the
Registration Statement, including the Prospectus contained therein (including any amendment or
supplement), became effective, the Registration Statement contained all statements that were
required to be stated therein in accordance with the 1933 Act and the 1933 Act Regulations, complied
in all material respects with the requirements of the 1933 Act and the 1933 Act Regulations and the
Registration Statement, including the Prospectus contained therein (including any amendment or
supplement thereto), and any information regarding the Company or the MHC or the Bank contained in
Sales Information (as such term is defined in Section 8 hereof) authorized by the Company, the MHC
or the Bank for use in connection with the Offering, did not contain an untrue statement of a
material fact or omit to state a material fact required to be stated therein or necessary to make
the statements therein, in light of the circumstances under which they were made, not misleading,
and at the time any Rule 424(b) or (c) Prospectus was filed with the Commission and at the Closing
Date referred to in Section 2, the Registration Statement, including the Prospectus contained
therein (including any amendment or supplement thereto), and any information regarding the Company,
the MHC or the Bank contained in Sales Information (as such term is defined in Section 8 hereof)
authorized by the Company, the MHC or the Bank for use in connection with the Offering will contain
all statements that are required to be stated therein in accordance with the 1933 Act and the 1933
Act Regulations and will not contain an untrue statement of a material fact or omit to state a
material fact necessary in order to make the statements therein, in light of the circumstances under
which they were made, not misleading; provided, however, that the representations and warranties in
this Section 4(a) shall not apply to statements or omissions made in reliance upon and in conformity
with written information furnished to the Company, the MHC or the Bank by the Agent or its counsel
expressly regarding the Agent for use in the Prospectus or statements in or omissions from any Sales
Information or information filed pursuant to state securities or blue sky laws or regulations
regarding the Agent.

(b) The MHC Application which was prepared by the Company, the MHC and the Bank and filed with the
OTS was approved by the OTS on ___________ ___, 2000, and the related Prospectus has been authorized
for use by the OTS. At the time of the approval of the MHC Application, including the

5
<!-- page 4 -->
Prospectus (including any amendment or supplement thereto), by the OTS and at all times subsequent
thereto until the Closing Date, the MHC Application, including the Prospectus (including any
amendment or supplement thereto), will comply in all material respects with the MHC Regulations,
except to the extent waived in writing by the OTS. The MHC Application, including the Prospectus
(including any amendment or supplement thereto), does not include any untrue statement of a material
fact or omit to state a material fact required to be stated therein or necessary to make the
statements therein, in light of the circumstances under which they were made, not misleading;
provided, however, that the representations and warranties in this Section 4(b) shall not apply to
statements or omissions made in reliance upon and in conformity with written information furnished
to the Company, the MHC or the Bank by the Agent or its counsel expressly regarding the Agent for
use in the Prospectus contained in the MHC Application or statements in or omissions from any sales
information.

(c) The Company and the MHC have registered with the OTS as savings and loan holding companies under
the Home Owners' Loan Act, as amended ("HOLA").

(d) No order has been issued by the OTS or the FDIC (hereinafter any reference to the FDIC shall
include the SAIF) preventing or suspending the use of the Prospectus, and no action by or before any
such government entity to revoke any approval, authorization or order of effectiveness related to
the Offering is, to the best knowledge of the Company, the MHC or the Bank, pending or threatened.

(e) The MHC is and, as of the Closing Date, will continue to be duly organized and validly existing
as a federally chartered mutual holding company under the laws of the United States, duly authorized
to conduct its business and own its property as described in the Registration Statement and the
Prospectus; as of the Closing Date, the MHC will have obtained all licenses, permits and other
governmental authorizations required for the conduct of its business except those that individually
or in the aggregate would not materially adversely affect the financial condition, earnings,
capital, assets or properties of the Company, MHC and Bank taken as a whole; as of the Closing Date,
all such licenses, permits and governmental authorizations will be in full force and effect and the
MHC will be in compliance therewith in all material respects; as of the Closing Date, the MHC will
be duly qualified as a foreign corporation to transact business in each jurisdiction in which the
failure to be so qualified in one or more of such jurisdictions would have a material adverse effect
on the financial condition, earnings, capital, assets, properties or business of the Company, MHC
and Bank considered as one enterprise.

6

(f) The MHC does not own any equity securities or any equity interest in any business enterprise
except as described in the Prospectus.

(g) The MHC is not authorized to issue any shares of capital stock.

(h) At the Closing Date, the Plan will have been adopted by the Boards of Directors of the Company,
the MHC and the Bank and approved by the members of the Bank, and the offer and sale of the Shares
will have been conducted in all material respects in accordance with the Plan, the MHC Regulations,
and all other applicable laws, regulations, decisions and orders, including all terms, conditions,
requirements and provisions precedent to the Offering imposed upon the Company, the MHC or the Bank
by the OTS, the Commission, or any other regulatory authority and in the manner described in the
Prospectus. No person has sought to obtain review of the final action of the OTS in approving the
Plan or in approving the MHC Application, or any other statute or regulation.

(i) The Bank has been organized and is a validly existing federally chartered savings and loan
association in capital stock form of organization, duly authorized to conduct its business and own
its property as described in the Registration Statement and the Prospectus; the Bank has obtained
all material licenses, permits and other governmental authorizations currently required for the
conduct of its business; all such licenses, permits and governmental authorizations are in full
force and effect, and the Bank is in all material respects complying with all laws, rules,
regulations and orders applicable to the operation of its business; the Bank is existing under the
laws of the United States and is duly qualified as a foreign corporation to transact business and is
in good standing in each jurisdiction in which its ownership of property or leasing of property or
the conduct of its business requires such qualification, unless the failure to be so qualified in
one or more of such jurisdictions would not have a material adverse effect on the condition,
financial or otherwise, or the business, operations or income of the Bank. The
<!-- page 5 -->
Bank does not own equity securities or any equity interest in any other business enterprise except
as described in the Prospectus or as would not be material to the operations of the Bank. Upon
completion of the sale by the Company of the Shares contemplated by the Prospectus, (i) all of the
issued and outstanding capital stock of the Bank will be owned by the Company, (ii) the Company will
have no direct subsidiaries other than the Bank, and (iii) the Company will be a majority-owned
subsidiary of the MHC. The Offering will have been effected in all material respects in accordance
with all applicable statutes, regulations, decisions and orders; and, except with respect to the
filing of certain post-sale, post-Offering reports, and documents in compliance with the 1933 Act
Regulations, the OTS' resolutions or letters of

7

approval, all terms, conditions, requirements and provisions with respect to the Offering imposed by
the Commission, the OTS, and the FDIC, if any, will have been complied with by the Company, the MHC
and the Bank in all material respects or appropriate waivers will have been obtained and all
material notice and waiting periods will have been satisfied, waived or elapsed.

(j) The Company has been duly incorporated and is validly existing as a corporation in good standing
under the laws of the United States with corporate power and authority to own, lease and operate its
properties and to conduct its business as described in the Registration Statement and the
Prospectus, and at the Closing Date the Company will be qualified to do business as a foreign
corporation in each jurisdiction in which the conduct of its business requires such qualification,
except where the failure to so qualify would not have a material adverse effect on the condition,
financial or otherwise, or the business, operations or income of the Company. The Company has
obtained all material licenses, permits and other governmental authorizations currently required for
the conduct of its business; all such licenses, permits and governmental authorizations are in full
force and effect, and the Company is in all material respects complying with all laws, rules,
regulations and orders applicable to the operation of its business.

(k) The Bank is a member of the Federal Home Loan Bank of Dallas ("FHLB- Dallas"). The deposit
accounts of the Bank are insured by the FDIC up to the applicable limits; and no proceedings for the
termination or revocation of such insurance are pending or, to the best knowledge of the Company or
the Bank, threatened.

(l) The Company, the MHC and the Bank have good and marketable title to all real property and good
title to all other assets material to the business of the Company, the MHC and the Bank, taken as a
whole, and to those properties and assets described in the Registration Statement and Prospectus as
owned by them, free and clear of all liens, charges, encumbrances or restrictions, except such as
are described in the Registration Statement and Prospectus, or are not material to the business of
the Company, the MHC and the Bank, taken as a whole; and all of the leases and subleases material to
the business of the Company, the MHC and the Bank, taken as a whole, under which the Company, the
MHC or the Bank hold properties, including those described in the Registration Statement and
Prospectus, are in full force and effect.

(m) The Company and the Bank have received an opinion of their special counsel, Luse Lehman Gorman
Pomerenk & Schick with respect to the federal income tax consequences of the Offering and the
opinions of

8

____________________ with respect to New Mexico income tax consequences of the Offering; all
material aspects of the opinions of Luse Lehman Gorman Pomerenk & Schick and _____________________
are accurately summarized in the Registration Statement and will be accurately summarized in the
Prospectus; and further represent and warrant that the facts upon which such opinions are based are
truthful, accurate and complete.

(n) The Company, the MHC and the Bank have all such power, authority, authorizations, approvals and
orders as may be required to enter into this Agreement, to carry out the provisions and conditions
hereof and to issue and sell the Shares to be sold by the Company, as provided herein and as
described in the Prospectus except approval or confirmation by the OTS of the final appraisal of the
Company. The consummation of the Offering, the execution, delivery and performance of this Agreement
and the consummation of the transactions herein contemplated have been duly and validly authorized
by all necessary corporate action on the part
<!-- page 6 -->
of the Company, the MHC and the Bank and this Agreement has been validly executed and delivered by
the Company, the MHC and the Bank and is the valid, legal and binding agreement of the Company, the
MHC and the Bank enforceable in accordance with its terms (except as the enforceability thereof may
be limited by bankruptcy, insolvency, moratorium, reorganization or similar laws relating to or
affecting the enforcement of creditors' rights generally or the rights of creditors of savings and
loan holding companies, the accounts of whose subsidiaries are insured by the FDIC or by general
equity principles regardless of whether such enforceability is considered in a proceeding in equity
or at law, and except to the extent if any, that the provisions of Sections 8 and 9 hereof may be
unenforceable as against public policy).

(o) The Company, the MHC and the Bank are not in violation of any directive received from the OTS,
the FDIC, or any other agency to make any material change in the method of conducting their
businesses so as to comply in all material respects with all applicable statutes and regulations
(including, without limitation, regulations, decisions, directives and orders of the OTS, and the
FDIC) and, except as may be set forth in the Registration Statement and the Prospectus, there is no
suit or proceeding or charge or action before or by any court, regulatory authority or governmental
agency or body, pending or, to the knowledge of the Company, the MHC or the Bank, threatened, which
might materially and adversely affect the Offering, the performance of this Agreement or the
consummation of the transactions contemplated in the Plan and as described in the Registration
Statement and the Prospectus or which might result in any material adverse change in the condition
(financial or otherwise), earnings, capital or properties of the

9

Company, the MHC and the Bank, or which would materially affect their properties and assets.

(p) The financial statements, schedules and notes related thereto which are included in the
Prospectus fairly present the consolidated balance sheet, income statement, statement of changes in
equity and cash flows of the Bank at the respective dates indicated and for the respective periods
covered thereby and comply as to form in all material respects with the applicable accounting
requirements of Title 12 of the Code of Federal Regulations and generally accepted accounting
principles (including those requiring the recording of certain assets at their current market
value). Such financial statements, schedules and notes related thereto have been prepared in
accordance with generally accepted accounting principles consistently applied through the periods
involved, present fairly in all material respects the information required to be stated therein and
are consistent with the most recent financial statements and other reports filed by the Bank with
the OTS. The other financial, statistical and pro forma information and related notes included in
the Prospectus present fairly the information shown therein on a basis consistent with the audited
and unaudited financial statements of the Bank included in the Prospectus, and as to the pro forma
adjustments, the adjustments described therein have been properly applied on the basis described
therein.

(q) Since the respective dates as of which information is given in the Registration Statement
including the Prospectus: (i) there has not been any material adverse change, financial or
otherwise, in the condition of the Company, the MHC or the Bank considered as one enterprise, or in
the earnings, capital or properties of the Company, the MHC or the Bank, whether or not arising in
the ordinary course of business; (ii) there has not been any material increase in the long-term debt
of the Bank or in the principal amount of the Bank's assets which are classified by the Bank as
substandard, doubtful or loss or in loans past due 90 days or more or real estate acquired by
foreclosure, by deed-in-lieu of foreclosure or deemed in-substance foreclosure or any material
decrease in retained earnings or total assets of the Bank nor has the Company, the MHC or the Bank
issued any securities (other than in connection with the incorporation of the Company) or incurred
any liability or obligation for borrowing other than in the ordinary course of business; (iii) there
have not been any material transactions entered into by the Company, the MHC or the Bank; (iv) there
has not been any material adverse change in the aggregate dollar amount of the Bank's deposits or
its consolidated net worth; (v) there has been no material adverse change in the Company's, the
MHC's or the Bank's relationship with its insurance carriers, including, without limitation,
cancellation or other termination of the Company's, the

10
<!-- page 7 -->
MHC's or the Bank's fidelity bond or any other type of insurance coverage; (vi) except as disclosed
in the Prospectus there has been no material change in management of the Company, the MHC or the
Bank, neither of which has any material undisclosed liability of any kind, contingent or otherwise;
(vii) the Company, the MHC or the Bank has not sustained any material loss or interference with its
respective business or properties from fire, flood, windstorm, earthquake, accident or other
calamity, whether or not covered by insurance; (viii) the Company, the MHC or the Bank is not in
default in the payment of principal or interest on any outstanding debt obligations; (ix) the
capitalization, liabilities, assets, properties and business of the Company, the MHC and the Bank
conform in all material respects to the descriptions thereof contained in the Prospectus; and (x)
neither the Company, the MHC nor the Bank has any material contingent liabilities, except as set
forth in the Prospectus. All documents made available to or delivered or to be made available to or
delivered by the Bank, the MHC or the Company or their representatives in connection with the
issuance and sale of the Shares, including records of account holders, depositors and other members
of the Bank, or in connection with the Agent's exercise of due diligence, except for those documents
which were prepared by parties other than the Bank, the MHC, the Company or their representatives,
to the best knowledge of the Bank, the MHC and the Company, were on the dates on which they were
delivered, or will be on the dates on which they are to be delivered, true, complete and correct in
all material respects.

(r) As of the date hereof and as of the Closing Date, neither the Company, the MHC nor the Bank is
(i) in violation of its articles of incorporation or charter or bylaws, respectively, or (ii) in
default in the performance or observance of any material obligation, agreement, covenant, or
condition contained in any material contract, lease, loan agreement, indenture or other instrument
to which it is a party or by which it or any of its property may be bound; the consummation of the
Offering, the execution, delivery and performance of this Agreement and the consummation of the
transactions herein contemplated have been duly and validly authorized by all necessary corporate
action on the part of the Company, the MHC and the Bank and this Agreement has been validly executed
and delivered by the Company, the MHC and the Bank and is a valid, legal and binding Agreement of
the Company, the MHC and the Bank enforceable in accordance with its terms, except as the
enforceability thereof may be limited by (i) bankruptcy, insolvency, reorganization, moratorium,
conservatorship, receivership or other similar laws now or hereafter in effect relating to or
affecting the enforcement of creditors' rights generally or the rights of creditors of federal
savings institutions, (ii) general equitable principles, (iii) laws relating to the safety and
soundness of insured depository institutions, and (iv) applicable

11

law or public policy with respect to the indemnification and/or contribution provisions contained
herein, and except that no representation or warranty need be made as to the effect or availability
of equitable remedies or injunctive relief (regardless of whether such enforceability is considered
in a proceeding in equity or at law). The consummation of the transactions herein contemplated will
not: (i) conflict with or constitute a breach of, or default under, or result in the creation of any
material lien, charge or encumbrance upon any of the assets of the Company, the MHC or the Bank
pursuant to the articles of incorporation of the Company or the charter and bylaws of the Bank and
the MHC, or any material contract, lease or other instrument to which the Company, the MHC or the
Bank has a beneficial interest, or any applicable law, rule, regulation or order; (ii) violate any
authorization, approval, judgement, decree, order, statute, rule or regulation applicable to the
Company, the MHC or the Bank, except for such violations which would not have a material adverse
effect on the financial condition and results of operations of the Company, the MHC and the Bank on
a consolidated basis; or (iii) result in the creation of any material lien, charge or encumbrance
upon any property of the Company, the MHC or the Bank.

(s) No default exists, and no event has occurred which with notice or lapse of time, or both, would
constitute a default, on the part of the Company, the MHC or the Bank in the due performance and
observance of any term, covenant or condition of any indenture, mortgage, deed of trust, note, bank
loan or credit agreement or any other instrument or agreement to which the Company, the MHC or the
Bank is a party or by which any of them or any of their property is bound or affected, except such
defaults which would not have a material adverse affect on the financial condition or results of
operations of the Company, the MHC and the Bank on a consolidated basis; such agreements are in full
force and effect; and no other party to any such agreements has instituted or, to the best knowledge
of the Company, the MHC and the Bank, threatened any action or proceeding wherein the Company, the
MHC or the Bank would or might be alleged to be in default
<!-- page 8 -->
thereunder.

(t) Upon consummation of the Offering, the authorized, issued and outstanding equity capital of the
Company will be within the range set forth in the Prospectus under the caption "Capitalization," and
no Shares have been or will be issued and outstanding prior to the Closing Date (other than Shares
held by the MHC); the Shares will have been duly and validly authorized for issuance and, when
issued and delivered by the Company pursuant to the Plan against payment of the consideration
calculated as set forth in the Plan and in the Prospectus, will be duly and validly issued, fully
paid and non-assessable, except for shares purchased by the ESOP with funds

12

borrowed from the Company to the extent payment therefor in cash has not been received by the
Company; except to the extent that subscription rights and priorities pursuant thereto exist
pursuant to the Plan, no preemptive rights exist with respect to the Shares; and the terms and
provisions of the Shares will conform in all material respects to the description thereof contained
in the Registration Statement and the Prospectus. To the best knowledge of the Company, the MHC and
the Bank, upon the issuance of the Shares, good title to the Shares will be transferred from the
Company to the purchasers thereof against payment therefor, subject to such claims as may be
asserted against the purchasers thereof by third-party claimants.

(u) No approval of any regulatory or supervisory or other public authority is required in connection
with the execution and delivery of this Agreement or the issuance of the Shares, except for the
approval of the Commission, the OTS and any necessary qualification, notification, registration or
exemption under the securities or blue sky laws of the various states in which the Shares are to be
offered, and except as may be required under the rules and regulations of the NASD.

(v) The Accounting & Consulting Group L.L.P. which has certified the consolidated audited financial
statements and schedules of the Bank included in the Prospectus, has advised the Company, the MHC
and the Bank in writing that they are, with respect to the Company, the MHC and the Bank,
independent public accountants within the meaning of the Code of Professional Ethics of the American
Institute of Certified Public Accountants and Title 12 of the Code of Federal Regulations and
Section 571.2(c)(3).

(w) RP Financial LC, which has prepared the Valuation Appraisal Report as of December ___, 1999 (as
amended or supplemented, if so amended or supplemented) (the "Appraisal"), has advised the Company
in writing that it is independent of the Company, the MHC and the Bank within the meaning of the MHC
Regulations.

(x) The Company, the MHC and the Bank have timely filed all required federal, state and local tax
returns; the Company, the MHC and the Bank have paid all taxes that have become due and payable in
respect of such returns, except where permitted to be extended, have made adequate reserves for
similar future tax liabilities and no deficiency has been asserted with respect thereto by any
taxing authority.

(y) The Bank is in compliance in all material respects with the applicable financial record-keeping
and reporting requirements of the Currency and

13

Foreign Transactions Reporting Act of 1970, as amended, and the regulations and rules thereunder.

(z) To the knowledge of the Company, the MHC and the Bank, neither the Company, the MHC, the Bank
nor employees of the Company, the MHC or the Bank have made any payment of funds of the MHC, the
Company or the Bank as a loan for the purchase of the Shares or made any other payment of funds
prohibited by law, and no funds have been set aside to be used for any payment prohibited by law.

(aa) Prior to the Offering, neither the Company, the MHC nor the Bank has: (i) issued any securities
within the last 18 months (except for notes to evidence other bank loans and reverse repurchase
agreements or other liabilities in the ordinary course of business or as described in the
Prospectus, and except for any shares issued in connection with the incorporation of the Company);
(ii) had any material dealings within the 12 months prior to the date hereof with any member of the
NASD, or any person related to or associated with such member, other than discussions and meetings
relating to the proposed Offering and routine purchases and sales of United States government and
<!-- page 9 -->
agency securities; (iii) entered into a financial or management consulting agreement except as
contemplated hereunder; and (iv) engaged any intermediary between the Agent and the Company, the MHC
and the Bank in connection with the offering of the Shares, and no person is being compensated in
any manner for such service. Appropriate arrangements have been made for placing the funds received
from subscriptions for Shares in a special interest-bearing account with the Bank until all Shares
are sold and paid for, with provision for refund to the purchasers in the event that the Offering is
not completed for whatever reason or for delivery to the Company if all Shares are sold.

(bb) The Company, the MHC and the Bank have not relied upon the Agent or its legal counsel or other
advisors for any legal, tax or accounting advice in connection with the Offering.

(cc) The Company is not required to be registered under the Investment Company Act of 1940, as
amended.

(dd) Any certificates signed by an officer of the Company, the MHC or the Bank pursuant to the
conditions of this Agreement and delivered to the Agent or their counsel that refers to this
Agreement shall be deemed to be a representation and warranty by the Company, the MHC or the Bank to
the Agent as to the matters covered thereby with the same effect as if such representation and
warranty were set forth herein.

14

Section 5. Representations and Warranties of the Agent.

The Agent represents and warrants to the Company, the MHC and the Bank that:

(i) it is a corporation and is validly existing in good standing under the laws of the State of Ohio
and licensed to conduct business in the State of Ohio and it has the full power and authority to
provide the services to be furnished to the Bank, the MHC and the Company hereunder.

(ii) The execution and delivery of this Agreement and the consummation of the transactions
contemplated hereby have been duly and validly authorized by all necessary action on the part of the
Agent, and this Agreement has been duly and validly executed and delivered by the Agent and is a
legal, valid and binding agreement of the Agent, enforceable in accordance with its terms.

(iii) Each of the Agent and its employees, agents and representatives who shall perform any of the
services hereunder shall be duly authorized and empowered, and shall have all licenses, approvals
and permits necessary to perform such services.

(iv) The execution and delivery of this Agreement by the Agent, the consummation of the transactions
contemplated hereby and compliance with the terms and provisions hereof will not conflict with, or
result in a breach of, any of the terms, provisions or conditions of, or constitute a default (or an
event which with notice or lapse of time or both would constitute a default) under, the articles of
incorporation of the Agent or any agreement, indenture or other instrument to which the Agent is a
party or by which it or its property is bound.

(v) No approval of any regulatory or supervisory or other public authority is required in connection
with the Agent's execution and delivery of this Agreement, except as may have been received.

(vi) There is no suit or proceeding or charge or action before or by any court, regulatory authority
or government agency or body or, to the knowledge of the Agent, pending or threatened, which might
materially adversely affect the Agent's performance of this Agreement.

Section 5.l Covenants of the Company, the MHC and the Bank. The Company, the MHC and the Bank hereby
jointly and severally covenant with the Agent as follows:

(a) The Company will not, at any time after the date the Registration Statement is declared
effective, file any amendment or supplement to the Registration Statement without providing the
Agent and its counsel an opportunity to

15

review such amendment or supplement or file any amendment or supplement to which amendment or
supplement the Agent or its counsel shall reasonably object.

(b) The MHC and Bank will not, at any time after the MHC Application is approved by the OTS, file
any amendment or supplement to such
<!-- page 10 -->
MHC Application without providing the Agent and its counsel an opportunity to review such amendment
or supplement or file any amendment or supplement to which amendment or supplement the Agent or its
counsel shall reasonably object.

(c) The Company, the MHC and the Bank will use their best efforts to cause any post-effective
amendment to the Registration Statement to be declared effective by the Commission and any
post-effective amendment to the MHC Application to be approved by the OTS and will immediately upon
receipt of any information concerning the events listed below notify the Agent: (i) when the
Registration Statement, as amended, has become effective; (ii) when the MHC Application, as amended
has been approved by the OTS; (iii) any comments from the Commission, the OTS or any other
governmental entity with respect to the Offering or the transactions contemplated by this Agreement;
(iv) of the request by the Commission, the OTS or any other governmental entity for any amendment or
supplement to the Registration Statement, the MHC Application or for additional information; (v) of
the issuance by the Commission, the OTS or any other governmental entity of any order or other
action suspending the Offering or the use of the Registration Statement or the Prospectus or any
other filing of the Company, the MHC or the Bank under the MHC Regulations, or other applicable law,
or the threat of any such action; (vi) the issuance by the Commission, the OTS or any authority of
any stop order suspending the effectiveness of the Registration Statement or of the initiation or
threat of initiation or threat of any proceedings for that purpose; or (vii) of the occurrence of
any event mentioned in paragraph (g) below. The Company, the MHC and the Bank will make every
reasonable effort (i) to prevent the issuance by the Commission, the OTS or any state authority of
any such order and, if any such order shall at any time be issued, (ii) to obtain the lifting
thereof at the earliest possible time.

(d) The Company, the MHC and the Bank will deliver to the Agent and to its counsel two conformed
copies of the Registration Statement and the MHC Application, as originally filed and of each
amendment or supplement thereto, including all exhibits. Further, the Company, the MHC and the Bank
will deliver such additional copies of the foregoing documents to counsel to the Agent as may be
required for any NASD and "blue sky" filings.

16

(e) The Company, the MHC and the Bank will furnish to the Agent, from time to time during the period
when the Prospectus (or any later prospectus related to this offering) is required to be delivered
under the 1933 Act or the Securities Exchange Act of 1934 (the "1934 Act"), such number of copies of
such Prospectus (as amended or supplemented) as the Agent may reasonably request for the purposes
contemplated by the 1933 Act, the 1933 Act Regulations, the 1934 Act or the rules and regulations
promulgated under the 1934 Act (the "1934 Act Regulations"). The Company authorizes the Agent to use
the Prospectus (as amended or supplemented, if amended or supplemented) in any lawful manner
contemplated by the Plan in connection with the sale of the Shares by the Agent.

(f) The Company, the MHC and the Bank will comply with any and all material terms, conditions,
requirements and provisions with respect to the Offering, and the transactions contemplated thereby,
imposed by the Commission, the OTS or the MHC Regulations, and by the 1933 Act, the 1933 Act
Regulations, the 1934 Act and the 1934 Act Regulations to be complied with prior to or subsequent to
the Closing Date and when the Prospectus is required to be delivered, and during such time period
the Company, the MHC and the Bank will comply, at their own expense, with all material requirements
imposed upon them by the Commission, the OTS or the MHC Regulations, and by the 1933 Act, the 1933
Act Regulations, the 1934 Act and the 1934 Act Regulations, including, without limitation, Rule
10b-5 under the 1934 Act, in each case as from time to time in force, so far as necessary to permit
the continuance of sales or dealing in the Common Stock during such period in accordance with the
provisions hereof and the Prospectus.

(g) If, at any time during the period when the Prospectus relating to the Shares is required to be
delivered, any event relating to or affecting the Company, the MHC or the Bank shall occur, as a
result of which it is necessary or appropriate, in the opinion of counsel for the Company, the MHC
and the Bank or in the reasonable opinion of the Agent's counsel, to amend or supplement the
Registration Statement or Prospectus in order to make the Registration Statement or Prospectus not
misleading in light of the circumstances existing at the time the Prospectus is delivered to a
purchaser, the Company, the MHC and the Bank will immediately so inform the Agent and prepare and
file, at their own expense, with the Commission and the OTS and furnish to the Agent a reasonable
number of copies of an amendment or amendments of, or a supplement or supplements to, the
Registration Statement or Prospectus (in form and substance reasonably satisfactory to the Agent and
its counsel after a reasonable time for review) which will amend or supplement the Registration
Statement or
<!-- page 11 -->
Prospectus so that as amended

17

or supplemented it will not contain an untrue statement of a material fact or omit to state a
material fact necessary in order to make the statements therein, in light of the circumstances
existing at the time the Prospectus is delivered to a purchaser, not misleading. For the purpose of
this Agreement, the Company, the MHC and the Bank each will timely furnish to the Agent such
information with respect to itself as the Agent may from time to time reasonably request.

(h) The Company, the MHC and the Bank will take all necessary actions, in cooperating with the
Agent, and furnish to whomever the Agent may direct, such information as may be required to qualify
or register the Shares for offering and sale by the Company or to exempt such Shares from
registration, or to exempt the Company as a broker-dealer and its officers, directors and employees
as broker-dealers or agents under the applicable securities or blue sky laws of such jurisdictions
in which the Shares are required under the MHC Regulations to be sold or as the Agent and the
Company, the MHC and the Bank may reasonably agree upon; provided, however, that the Company shall
not be obligated to file any general consent to service of process, to qualify to do business in any
jurisdiction in which it is not so qualified, or to register its directors or officers as brokers,
dealers, salesmen or agents in any jurisdiction. In each jurisdiction where any of the Shares shall
have been qualified or registered as above provided, the Company will make and file such statements
and reports in each fiscal period as are or may be required by the laws of such jurisdiction.

(i) The Company, the MHC and the Bank will not sell or issue, contract to sell or otherwise dispose
of, for a period of 90 days after the Closing Date, without the Agent's prior written consent, any
Common Stock other than the Shares or other than in connection with any plan or arrangement
described in the Prospectus, including existing stock benefit plans.

(j) The Company shall register its Common Stock under Section 12(g) of the 1934 Act on or prior to
the Closing Date pursuant to the Plan and shall request that such registration be effective prior to
or upon completion of the Offering. The Company shall maintain the effectiveness of such
registration for not less than three years or such shorter period as may be required by the OTS.

(k) During the period during which the Company's Common Stock is registered under the 1934 Act or
for three (3) years from the date hereof, whichever period is greater, the Company will furnish to
its shareholders as soon as practicable after the end of each fiscal year an annual report of the
Company (including a consolidated balance sheet and statements of consolidated

18

income, shareholders' equity and cash flows of the Company and its subsidiaries as at the end of and
for such year, certified by independent public accountants in accordance with Regulation S-X under
the 1933 Act and the 1934 Act).

(l) During the period of three years from the date hereof, the Company will furnish to the Agent:
(i) as soon as practicable after such information is publicly available, a copy of each report of
the Company furnished to or filed with the Commission under the 1934 Act or any national securities
exchange or system on which any class of securities of the Company is listed or quoted (including,
but not limited to, reports on Forms 10-K, 10-Q and 8-K and all proxy statements and annual reports
to stockholders), (ii) a copy of each other non-confidential report of the Company mailed to its
stockholders or filed with the Commission, the OTS or any other supervisory or regulatory authority
or any national securities exchange or system on which any class of securities of the Company is
listed or quoted, each press release and material news items and additional documents and
information with respect to the Company, MHC or the Bank as the Agent may reasonably request; and
(iii) from time to time, such other nonconfidential information concerning the Company, the MHC or
the Bank as the Agent may reasonably request.

(m) The Company, the MHC and the Bank will use the net proceeds from the sale of the Shares in the
manner set forth in the Prospectus under the caption "Use of Proceeds."

(n) Other than as permitted by the MHC Regulations, the HOLA, the 1933 Act, the 1933 Act
Regulations, and the laws of any state in which the Shares are registered or qualified for sale or
exempt from registration, neither the Company, the MHC nor the Bank will
<!-- page 12 -->
distribute any prospectus, offering circular or other offering material in connection with the offer
and sale of the Shares.

(o) The Company will use its best efforts to (i) encourage and assist a market maker to establish
and maintain a market for the Shares and (ii) list and maintain quotation of the Shares on a
national or regional securities exchange or on the Nasdaq Stock Market ("Nasdaq") effective on or
prior to the Closing Date.

(p) The Bank will maintain appropriate arrangements for depositing all funds received from persons
mailing subscriptions for or orders to purchase Shares in the Offering on an interest-bearing basis
at the rate described in the Prospectus until the Closing Date and satisfaction of all conditions
precedent to the release of the Bank's obligation to refund payments received from

19

persons subscribing for or ordering Shares in the Offering in accordance with the Plan and as
described in the Prospectus or until refunds of such funds have been made to the persons entitled
thereto or withdrawal authorizations canceled in accordance with the Plan and as described in the
Prospectus. The Bank will maintain such records of all funds received to permit the funds of each
subscriber to be separately insured by the FDIC (to the maximum extent allowable) and to enable the
Bank to make the appropriate refunds of such funds in the event that such refunds are required to be
made in accordance with the Plan and as described in the Prospectus.

(q) The Company, the MHC and the Bank will take such actions and furnish such information as are
reasonably requested by the Agent in order for the Agent to ensure compliance with the NASD's
"Interpretation Relating to Free Riding and Withholding."

(r) Neither the Company, the MHC nor the Bank will amend the Plan without notifying the Agent prior
thereto.

(s) The Company shall assist the Agent, if necessary, in connection with the allocation of the
Shares in the event of an oversubscription and shall provide the Agent with any information
necessary to assist the Company in allocating the Shares in such event and such information shall be
accurate and reliable in all material respects.

(t) Prior to the Closing Date, the Company, the MHC and the Bank will inform the Agent of any event
or circumstances of which it is aware as a result of which the Registration Statement and/or
Prospectus, as then amended or supplemented, would contain an untrue statement of a material fact or
omit to state a material fact necessary in order to make the statements therein not misleading.

(u) Subsequent to the date the Registration Statement is declared effective by the Commission and
prior to the Closing Date, except as otherwise may be indicated or contemplated therein or set forth
in an amendment or supplement thereto, neither the Company, the MHC nor the Bank will have: (i)
issued any securities or incurred any liability or obligation, direct or contingent, for borrowed
money, except borrowings from the same or similar sources indicated in the Prospectus in the
ordinary course of its business, or (ii) entered into any transaction which is material in light of
the business and properties of the Company and the Bank, taken as a whole.

(v) The facts and representations provided to Luse Lehman Gorman Pomerenk & Schick by the Bank, the
MHC and the Company and upon which Luse

20

Lehman Gorman Pomerenk & Schick will base its opinion under Section 7(c)(1) are and will be
truthful, accurate and complete.

Section 6. Payment of Expenses. Whether or not the Offering is completed or the sale of the Shares
by the Company is consummated, the Company, the MHC and the Bank jointly and severally agree to pay
or reimburse the Agent for the Company, the MHC and the Bank have agreed to reimburse the Agent for
its out-of-pocket expenses, and its legal fees (as specified in Section 2) and to indemnify the
Agent against certain claims or liabilities, including certain liabilities under the Securities Act,
and will contribute to payments the Agent may be required to make in connection with any such claims
or liabilities; and the fees set forth under Section 2. In the event the Company is unable to sell a
minimum of 708,050 Shares, the Company, the MHC and the Bank shall promptly reimburse the Agent in
accordance with Section 2 hereof.

Section 7. Conditions to the Agent's Obligations. The obligations of the Agent hereunder, as to the
Shares to be delivered at the Closing Date, are
<!-- page 13 -->
subject, to the extent not waived in writing by the Agent, to the condition that all representations
and warranties of the Company, the MHC and the Bank herein are, at and as of the commencement of the
Offering and at and as of the Closing Date, true and correct in all material respects, the condition
that the Company, the MHC and the Bank shall have performed all of their obligations hereunder to be
performed on or before such dates, and to the following further conditions:

(a) At the Closing Date, the Company, the MHC and the Bank shall have conducted the Offering in all
material respects in accordance with the Plan, the MHC Regulations, and all other applicable laws,
regulations, decisions and orders, including all terms, conditions, requirements and provisions
precedent to the Offering imposed upon them by the OTS.

(b) The Registration Statement shall have been declared effective by the Commission and the MHC
Application and MHC Notice shall be approved by the OTS not later than 5:30 p.m. on the date of this
Agreement, or with the Agent's consent at a later time and date; and at the Closing Date, no stop
order suspending the effectiveness of the Registration Statement shall have been issued under the
1933 Act or proceedings therefore initiated or threatened by the Commission or any state authority,
and no order or other action suspending the authorization of the Prospectus or the consummation of
the Conversion shall have been issued or proceedings therefore initiated or, to the Company's, the
MHC's or the Bank's knowledge, threatened by the Commission, the OTS, the FDIC, or any state
authority.

(c) At the Closing Date, the Agent shall have received:

21

(1) The favorable opinion, dated as of the Closing Date and addressed to the Agent and for its
benefit, of Luse Lehman Gorman Pomerenk & Schick, special counsel for the Company, the MHC and the
Bank, in form and substance to the effect that:

(i) The Company has been duly incorporated and is validly existing as a corporation under the laws
of the United States.

(ii) The Company has corporate power and authority to own, lease and operate its properties and to
conduct its business as described in the Registration Statement and the Prospectus.

(iii) The Bank has been organized and is a validly existing federally chartered savings and loan
association in capital stock form of organization, authorized to conduct its business and own its
property as described in the Registration Statement and the Prospectus. All of the outstanding
capital stock of the Bank upon completion of the Offering will be duly authorized and, upon payment
therefor, will be validly issued, fully paid and non-assessable and will be owned by the Company,
free and clear of any liens, encumbrances, claims or other restrictions.

(iv) The Bank is a member of the FHLB-Dallas. The deposit accounts of the Bank are insured by the
FDIC up to the maximum amount allowed under law and no proceedings for the termination or revocation
of such insurance are pending or, to such counsel's Actual Knowledge, threatened; to the extent that
such information constitutes matters of law and legal conclusions, has been reviewed by such counsel
and is accurately described in all material respects.

(v) The MHC has been duly organized and is validly existing as a federally chartered mutual holding
company, duly authorized to conduct its business and own its properties as described in the
Registration Statement and Prospectus.

(vi) Upon consummation of the Offering, immediately upon completion thereof subject to compliance
with all conditions imposed by the OTS under the terms of the OTS' approval order, in an amount as
described in the Prospectus, the authorized, issued and outstanding capital stock of the Company
will be within the range set forth in the Prospectus under the caption "Capitalization," and no
shares of Common Stock have been issued prior to the Closing Date; at the time of the Offering, the
Shares subscribed for pursuant to the Offering will have been duly and validly authorized for
issuance, and when issued and delivered by the Company pursuant to the Plan against payment of the
consideration calculated as set forth in the Plan and

22

Prospectus, will be duly and validly issued and fully paid and non-assessable; the issuance of the
Shares is not subject to preemptive rights and the terms and provisions of the Shares conform in all
material respects to the description thereof
<!-- page 14 -->
contained in the Prospectus. To such counsel's Actual Knowledge, upon the issuance of the Shares,
good title to the Shares will be transferred by the Company to the purchasers thereof against
payment therefor, subject to such claims as may be asserted against the purchasers thereof by
third-party claimants.

(vii) The execution and delivery of this Agreement and the consummation of the transactions
contemplated hereby, have been duly and validly authorized by all necessary action on the part of
the Company, the MHC and the Bank; and this Agreement is a valid and binding obligation of the
Company, the MHC and the Bank, enforceable in accordance with its terms, except as the
enforceability thereof may be limited by (i) bankruptcy, insolvency, reorganization, moratorium,
conservatorship, receivership or other similar laws now or hereafter in effect relating to or
affecting the enforcement of creditors' rights generally or the rights of creditors of savings
institutions, the deposits of which are insured by the FDIC and their holding companies, (ii)
general equitable principles, (iii) laws relating to the safety and soundness of insured depository
institutions and their holding companies, and (iv) applicable law or public policy with respect to
the indemnification and/or contribution provisions contained herein, including without limitation
the provisions of Sections 23A and 23B of the Federal Reserve Act and except that no opinion need be
expressed as to the effect or availability of equitable remedies or injunctive relief (regardless of
whether such enforceability is considered in a proceeding in equity or at law).

(viii) The MHC Application has been approved by the OTS and the Prospectus has been authorized for
use by the OTS, and no action has been taken, and to such counsel's Actual Knowledge none is pending
or threatened, to revoke any such authorization or approval.

(ix) The Plan has been duly adopted by the required vote of the directors of the Company, the MHC
and the Bank, and based upon the certificate of the inspector of election, by the members of the
Bank.

(x) Subject to the satisfaction of the conditions to the OTS' approval of the Offering, no further
approval, registration, authorization, consent or other order of any federal regulatory agency is
required in connection with the execution and delivery of this Agreement, the issuance of the Shares
and the consummation of the Offering, except as may be required under the securities or blue sky
laws of various jurisdictions (as to which no opinion need be

23

rendered) and except as may be required under the rules and regulations of the NASD and/or the NYSE
(as to which no opinion need be rendered). To such counsel's Actual Knowledge, the Offering has been
consummated in all material respects in accordance with MHC Regulations, except that no opinion is
rendered with respect to (a) the Registration Statement or Prospectus, which are covered by other
clauses of this opinion, (b) the satisfaction of the post-Offering conditions in the OTS Regulations
or in the OTS approvals of the MHC Application, (c) the securities or "blue sky" laws of various
jurisdictions, and (d) the rules and regulations of the NASD.

(xi) The Registration Statement is effective under the 1933 Act, and no stop order suspending the
effectiveness has been issued under the 1933 Act or proceedings therefor initiated or, to such
counsel's Actual Knowledge, threatened by the Commission.

(xii) At the time the MHC Application, including the Prospectus contained therein, was approved by
the OTS, the MHC Application, including the Prospectus contained therein, complied as to form in all
material respects with the requirements of the MHC Regulations, federal law and all applicable rules
and regulations promulgated thereunder (other than the financial statements, the notes thereto, and
other tabular, financial, statistical and appraisal data included therein, as to which no opinion
need be rendered).

(xiii) At the time that the Registration Statement became effective, (i) the Registration Statement
(as amended or supplemented, if so amended or supplemented) (other than the financial statements,
the notes thereto, and other tabular, financial, statistical and appraisal data included therein, as
to which no opinion need be rendered), complied as to form in all material respects with the
requirements of the 1933 Act and the 1933 Act Regulations, and (ii) the Prospectus (other than the
financial statements, the notes thereto, and other tabular, financial, statistical and appraisal
data included therein, as to which no opinion need be rendered) complied as to form in all material
respects with the requirements of the 1933 Act, the 1933 Act Regulations, the MHC Regulations and
federal law.
<!-- page 15 -->
(xiv) The terms and provisions of the Shares of the Company conform, in all material respects, to
the description thereof contained in the Registration Statement and Prospectus, and the form of
certificate used to evidence the Shares is in due and proper form.

(xv) There are no legal or governmental proceedings pending or threatened which are required to be
disclosed in the Registration Statement and Prospectus, other than those disclosed therein, and to
such counsel's

24

Actual Knowledge, all pending legal and governmental proceedings to which the Company, the MHC or
the Bank is a party or of which any of their property is the subject, which are not described in the
Registration Statement and the Prospectus, including ordinary routine litigation incidental to the
Company's, the MHC's or the Bank's business, are, considered in the aggregate, not material.

(xvi) To such counsel's Actual Knowledge, there are no material contracts, indentures, mortgages,
loan agreements, notes, leases or other instruments required to be described or referred to in the
MHC Application, the Registration Statement or the Prospectus or required to be filed as exhibits
thereto other than those described or referred to therein or filed as exhibits thereto in the MHC
Application, the Registration Statement or the Prospectus. The description in the MHC Application,
the Registration Statement and the Prospectus of such documents and exhibits is accurate in all
material respects and fairly presents the information required to be shown.

(xvii) To such counsel's Actual Knowledge, the Company, the MHC and the Bank have conducted the
Offering, in all material respects, in accordance with all applicable requirements of the Plan and
applicable federal law, except that no opinion is rendered with respect to (a) the MHC Application,
the Registration Statement or Prospectus, which are covered by other clauses of this opinion, (b)
the satisfaction of the post-Offering conditions in the OTS Regulations or in the OTS approval of
the MHC Application, (c) the securities or "blue sky" laws of various jurisdictions, and (d) the
rules and regulations of the NASD. The Plan complies in all material respects with all applicable
federal laws, rules, regulations, decisions and orders including, but not limited to, the MHC
Regulations; no order has been issued by the OTS, the Commission, the FDIC, or any state authority
to suspend the Offering or the use of the Prospectus, and no action for such purposes has been
instituted or, to such counsel's Actual Knowledge, threatened by the OTS, the Commission, the FDIC,
or any state authority and no person has sought to obtain regulatory or judicial review of the final
action of the OTS, approving the Plan, the MHC Application or the Prospectus.

(xviii) To such counsel's Actual Knowledge, the Company, the MHC and the Bank have obtained all
material licenses, permits and other governmental authorizations currently required for the conduct
of their businesses and all such licenses, permits and other governmental authorizations are in full
force and effect, and the Company, the MHC and the Bank are in all material respects complying
therewith, except where the failure to have such licenses, permits and other governmental
authorizations or the failure to be in compliance therewith would not have a material adverse effect
on the

25

business or operations of the Bank, the MHC and the Company, taken as a whole.

(xix) To such counsel's Actual Knowledge, neither the Company, the MHC nor the Bank is in violation
of its articles of incorporation and bylaws or its Charter and bylaws, as appropriate or, to such
counsel's Actual Knowledge, in default or violation of any obligation, agreement, covenant or
condition contained in any contract, indenture, mortgage, loan agreement, note, lease or other
instrument to which it is a party or by which it or its property may be bound, except for such
defaults or violations which would not have a material adverse impact on the financial condition or
results of operations of the Company, the MHC and the Bank on a consolidated basis; to such
counsel's Actual Knowledge, the execution and delivery of this Agreement, the occurrence of the
obligations herein set forth and the consummation of the transactions contemplated herein will not
conflict with or constitute a breach of, or default under, or result in the creation or imposition
of any lien, charge or encumbrance upon any property or assets of the Company, the MHC or the Bank
pursuant to any material contract, indenture,
<!-- page 16 -->
mortgage, loan agreement, note, lease or other instrument to which the Company, the MHC or the Bank
is a party or by which any of them may be bound, or to which any of the property or assets of the
Company, the MHC or the Bank are subject; and, such action will not result in any violation of the
provisions of the certificate of incorporation or bylaws of the Company or the Charter or bylaws of
the MHC or the Bank or, to such counsel's Actual Knowledge, result in any violation of any
applicable federal law, act, regulation (except that no opinion with respect to the securities and
blue sky laws of various jurisdictions or the rules or regulations of the NASD need be rendered) or
order or court order, writ, injunction or decree.

(xx) The Company's articles of incorporation and bylaws comply in all material respects with the
regulations of the OTS. The Bank's and MHC's charter and bylaws comply in all material respects with
the rules and regulations of the OTS.

(xxi) To such counsel's Actual Knowledge, neither the Company, the MHC nor the Bank is in violation
of any directive from the OTS or the FDIC to make any material change in the method of conducting
its respective business.

(xxii) The information in the Prospectus under the captions "Regulation," "The Stock Offering,"
"Restrictions on Acquisition of the Alamogordo Financial and Alamogordo Federal" and "Description of
Capital Stock of the Alamogordo Financial," to the extent that such information constitutes

26

matters of law, summaries of legal matters, documents or proceedings, or legal conclusions, has been
reviewed by such counsel and is correct in all material respects. The discussion of statutes or
regulations described or referred to in the Prospectus are accurate summaries and fairly present the
information required to be shown. The information in the Prospectus relating to the tax consequences
of the stock offering has been reviewed by such counsel and fairly describes the opinions rendered
by Luse Lehman Gorman Pomerenk & Schick and _____________________ to the Company, the MHC and the
Bank with respect to such matters.

(xxiii) The Company and the MHC have been duly registered and are in good standing as savings and
loan holding companies under the HOLA.

(xxiv) In addition, such counsel shall state that during the preparation of the MHC Application, the
Registration Statement and the Prospectus, they participated in conferences with certain officers
of, the independent public and internal accountants for, and other representatives of the Company,
the MHC and the Bank, at which conferences the contents of the MHC Application, the Registration
Statement and the Prospectus and related matters were discussed and, while such counsel have not
confirmed the accuracy or completeness of or otherwise verified the information contained in the MHC
Application, the Registration Statement or the Prospectus, and do not assume any responsibility for
such information, based upon such conferences and a review of documents deemed relevant for the
purpose of rendering their view (relying as to materiality as to factual matters on certificates of
officers and other factual representations by the Company, the MHC and the Bank), nothing has come
to their attention that would lead them to believe that the MHC Application, the Registration
Statement, the Prospectus, or any amendment or supplement thereto (other than the financial
statements, the notes thereto, and other tabular, financial, statistical and appraisal data included
therein as to which no view need be rendered) contained an untrue statement of a material fact or
omitted to state a material fact required to be stated therein or necessary to make the statements
therein, in light of the circumstances under which they were made, not misleading.

In giving such opinion, such counsel may rely as to all matters of fact on certificates of officers
or directors of the Company, the MHC and the Bank and certificates of public officials. The opinion
of Luse Lehman Gorman Pomerenk & Schick shall be governed by the Legal Opinion Accord ("Accord") of
the American Bar Association Section of Business Law (1991). The term "Actual Knowledge" as used
herein shall have the meaning set forth in the Accord. For purposes of such opinion, no proceedings
shall be deemed to be pending, no order or stop order shall be deemed to be issued, and no action
shall be deemed to be instituted unless, in each case, a director or executive officer of the
Company, the MHC or the Bank shall have received a copy of such

27

proceedings, order, stop order or action. In addition, such opinion may be limited to present
statutes, regulations and judicial interpretations and to
<!-- page 17 -->
facts as they presently exist; in rendering such opinion, such counsel need assume no obligation to
revise or supplement it should the present laws be changed by legislative or regulatory action,
judicial decision or otherwise; and such counsel need express no view, opinion or belief with
respect to whether any proposed or pending legislation, if enacted, or any proposed or pending
regulations or policy statements issued by any regulatory agency, whether or not promulgated
pursuant to any such legislation, would affect the validity of the Offering or any aspect thereof.
Such counsel may assume that any agreement is the valid and binding obligation of any parties to
such agreement other than the Company, the MHC or the Bank.

The favorable opinion, dated as of the Closing Date and addressed to the Agent and for their
benefit, of the Bank's local counsel, in form and substance to the effect that, to the best of such
counsel's knowledge, (i) the Company, the MHC and the Bank have good and marketable title to all
properties and assets which are material to the business of the Company, the MHC and the Bank and to
those properties and assets described in the Registration Statement and Prospectus, as owned by
them, free and clear of all liens, charges, encumbrances or restrictions, except such as are
described in the Registration Statement and Prospectus, or are not material in relation to the
business of the Company, the MHC and the Bank considered as one enterprise; (ii) all of the leases
and subleases material to the business of the Company, the MHC and the Bank under which the Company,
the MHC and the Bank hold properties, as described in the Registration Statement and Prospectus, are
in full force and effect; and (iii) the Bank is duly qualified as a foreign corporation to transact
business and is in good standing in each jurisdiction in which its ownership of property or leasing
of property or the conduct of its business requires such qualification, unless the failure to be so
qualified in one or more of such jurisdictions would not have a material adverse effect on the
condition, financial or otherwise, or the business, operations or income of the Bank.

(d) At the Closing Date, the Agent shall have received the favorable opinion, dated as of the
Closing Date, of Silver, Freedman & Taff, L.L.P., the Agent's counsel, with respect to such matters
as the Agent may reasonably require. Such opinion may rely upon the opinions of counsel to the
Company, the MHC and the Bank, and as to matters of fact, upon certificates of officers and
directors of the Company, the MHC and the Bank delivered pursuant hereto or as such counsel shall
reasonably request.

(e) At the Closing Date, the Agent shall receive a certificate of the Chief Executive Officer and
the Principal Financial and/or Accounting Officer of the Company, the MHC and the Bank in form and
substance reasonably satisfactory to the Agent's Counsel, dated as of such Closing Date, to the
effect that: (i) they have carefully reviewed the Prospectus and, in their opinion, at the time the
Prospectus became authorized for final use, the Prospectus did not contain any untrue statement of a
material fact or omit to state a material fact necessary in order to make the statements therein, in
light of the circumstances under which they were made, not misleading; (ii) since

28

the date the Prospectus became authorized for final use, no event has occurred which should have
been set forth in an amendment or supplement to the Prospectus which has not been so set forth,
including specifically, but without limitation, any material adverse change in the condition,
financial or otherwise, or in the earnings, capital, properties or business of the Company, the MHC
or the Bank, and the conditions set forth in this Section 7 have been satisfied; (iii) since the
respective dates as of which information is given in the Registration Statement and the Prospectus,
there has been no material adverse change in the condition, financial or otherwise, or in the
earnings, capital or properties of the Company, the MHC or the Bank, independently, or of the
Company, the MHC and the Bank, considered as one enterprise, whether or not arising in the ordinary
course of business; (iv) the representations and warranties in Section 4 are true and correct with
the same force and effect as though expressly made at and as of the Closing Date; (v) the Company,
MHC and the Bank have complied in all material respects with all agreements and satisfied all
conditions on their part to be performed or satisfied at or prior to the Closing Date and will
comply in all material respects with all obligations to be satisfied by them after the Offering;
(vi) no stop order suspending the effectiveness of the Registration Statement has been initiated or,
to the best knowledge of the Company, the MHC or the Bank, threatened by the Commission or any state
authority; (vii) no order suspending the Offering or the effectiveness of the Prospectus has been
issued and no proceedings for that purpose are pending or, to the best knowledge of the Company, the
MHC or the Bank, threatened by the OTS, the Commission, the FDIC, or any state authority; and (viii)
to the best knowledge of the Company, the MHC or the Bank, no person has sought to obtain review of
the final action of the OTS approving the Plan.

(f) Prior to and at the Closing Date: (i) in the reasonable opinion of the Agent, there shall have
been no material adverse change in the condition, financial or otherwise, or in the earnings or
business of the Company, the MHC or the Bank independently, or of the Company, the MHC and the Bank,
considered as one enterprise,
<!-- page 18 -->
from that as of the latest dates as of which such condition is set forth in the Prospectus other
than transactions referred to or contemplated therein; (ii) the Company, the MHC or the Bank shall
not have received from the OTS or the FDIC any direction (oral or written) to make any material
change in the method of conducting their business with which it has not complied (which direction,
if any, shall have been disclosed to the Agent) or which materially and adversely would affect the
business, operations or financial condition or income of the Company, the MHC and the Bank taken as
a whole; (iii) the Company, the MHC and the Bank shall not have been in default (nor shall an event
have occurred which, with notice or lapse of time or both, would constitute a default) under any
provision of

29

any agreement or instrument relating to any outstanding indebtedness; (iv) no action, suit or
proceeding, at law or in equity or before or by any federal or state commission, board or other
administrative agency, shall be pending or, to the knowledge of the Company, the MHC or the Bank,
threatened against the Company, the MHC or the Bank or affecting any of their properties wherein an
unfavorable decision, ruling or finding would materially and adversely affect the business,
operations, financial condition or income of the Company, the MHC and the Bank taken as a whole; and
(v) the Shares have been qualified or registered for offering and sale or exempted therefrom under
the securities or blue sky laws of the jurisdictions as the Agent shall have reasonably requested
and as agreed to by the Company, the MHC and the Bank.

(g) Concurrently with the execution of this Agreement, the Agent shall receive a letter from The
Accounting & Consulting Group L.L.P. dated as of the date of the Prospectus and addressed to the
Agent: (i) confirming that The Accounting & Consulting Group L.L.P. is a firm of independent public
accounts within the meaning of Rule 101 of the Code of Professional Ethics of the American Institute
of Certified Public Accountants and applicable regulations of the OTS and stating in effect that in
its opinion the consolidated financial statements, schedules and related notes of the Bank as of
September 30, 1999 and 1998 and for each of the three years in the period ended September 30, 1998,
as are included in the Prospectus and covered by their opinion included therein, comply as to form
in all material respects with the applicable accounting requirements and related published rules and
regulations of the OTS and the 1933 Act; (ii) stating in effect that, on the basis of certain agreed
upon procedures (but not an audit in accordance with generally accepted auditing standards)
consisting of a reading of the latest available unaudited interim consolidated financial statements
of the Bank prepared by the Bank, a reading of the minutes of the meetings of the Board of Directors
and members of the Bank and consultations with officers of the Bank responsible for financial and
accounting matters, nothing came to their attention which caused them to believe that: (A) the
unaudited financial statements included in the Prospectus are not in conformity with the 1933 Act,
applicable accounting requirements of the OTS and generally accepted accounting principles applied
on a basis substantially consistent with that of the audited financial statements included in the
Prospectus; or (b) during the period from the date of the latest unaudited consolidated financial
statements included in the Prospectus to a specified date not more than three business days prior to
the date of the Prospectus, except as has been described in the Prospectus, there was any increase
in borrowings, other than normal deposit fluctuations, by the Bank; or (c) there was any decrease in
the consolidated net assets of the Bank at the date of such letter as compared with amounts

30

shown in the latest unaudited consolidated statement of condition included in the Prospectus; and
(iii) stating that, in addition to the audit referred to in their opinion included in the Prospectus
and the performance of the procedures referred to in clause (ii) of this subsection (f), they have
compared with the general accounting records of the Bank, which are subject to the internal controls
of the Bank, the accounting system and other data prepared by the Bank, directly from such
accounting records, to the extent specified in such letter, such amounts and/or percentages set
forth in the Prospectus as the Agent may reasonably request; and they have reported on the results
of such comparisons.

(h) At the Closing Date, the Agent shall receive a letter dated the Closing Date, addressed to the
Agent, confirming the statements made by The Accounting & Consulting Group L.L.P. in the letter
delivered by it pursuant to subsection (f) of this Section 7, the "specified date" referred to in
clause (ii) of subsection (f)
<!-- page 19 -->
thereof to be a date specified in such letter, which shall not be more than three business days
prior to the Closing Date.

(i) At the Closing Date, the Agent shall receive a letter from RP Financial LC, dated the date
thereof and addressed to counsel for the Agent (i) confirming that said firm is independent of the
Company, the MHC and the Bank and is experienced and expert in the area of corporate appraisals
within the meaning of Title 12 of the Code of Federal Regulations, Section 563b.7(f)(1)(i), (ii)
stating in effect that the Appraisal prepared by such firm complies in all material respects with
the applicable requirements of Title 12 of the Code of Federal Regulations, and (iii) further
stating that their opinion of the aggregate pro forma market value of the Company, the MHC and the
Bank expressed in their Appraisal dated as of December __, 1999, and most recently updated, remains
in effect.

(j) The Company, the MHC and the Bank shall not have sustained since the date of the latest
financial statements included in the Prospectus any material loss or interference with its business
from fire, explosion, flood or other calamity, whether or not covered by insurance, or from any
labor dispute or court or governmental action, order or decree, otherwise than as set forth or
contemplated in the Registration Statement and Prospectus and since the respective dates as of which
information is given in the Registration Statement and Prospectus, there shall not have been any
change in the long- term debt of the Company, the MHC or the Bank other than debt incurred in
relation to the purchase of Shares by the Bank's Eligible Plans, or any change, or any development
involving a prospective change, in or affecting the general affairs, management, financial position,
stockholders' equity or results of operations of the Company or the Bank, otherwise than as set
forth or

31

contemplated in the Registration Statement and Prospectus, the effect of which, in any such case
described above, is in the Agent's reasonable judgment sufficiently material and adverse as to make
it impracticable or inadvisable to proceed with the Subscription Offering or the delivery of the
Shares on the terms and in the manner contemplated in the Prospectus.

(k) At or prior to the Closing Date, the Agent shall receive: (i) a copy of the letters from the OTS
approving the MHC Application and authorizing the use of the Prospectus; (ii) a copy of the order
from the Commission declaring the Registration Statement effective; (iii) certificate of good
standing from the OTS evidencing the good standing of the Company; (iv) a certificate from the FDIC
evidencing the Bank's insurance of accounts; (v) a certificate of the FHLB-Dallas evidencing the
Bank's membership thereof; (vi) a certificate from the OTS evidencing the Company's and the MHC's
standing as registered savings and loan holding companies; (vii) a copy of the Bank's federal stock
charter; and (viii) a copy of the Company's federal charter; and (viii) a copy of the MHC's federal
charter.

(l) Subsequent to the date hereof, there shall not have occurred any of the following: (i) a
suspension or limitation in trading in securities generally on the New York Stock Exchange or in the
over-the-counter market, or quotations halted generally on the Nasdaq, or minimum or maximum prices
for trading have been fixed, or maximum ranges for prices for securities have been required by
either of such exchanges or the NASD or by order of the Commission or any other governmental
authority; (ii) a general moratorium on the operations of commercial banks, federal savings
institutions or a general moratorium on the withdrawal of deposits from commercial banks or federal
savings institutions declared by federal authorities; (iii) the engagement by the United States in
hostilities which have resulted in the declaration, on or after the date hereof, of a national
emergency or war; or (iv) a material decline in the price of equity or debt securities if the effect
of such a declaration or decline, in the Agent's reasonable judgement, makes it impracticable or
inadvisable to proceed with the Offering or the delivery of the shares on the terms and in the
manner contemplated in the Registration Statement and the Prospectus.

(m) At or prior to the Closing Date, counsel to the Agent shall have been furnished with such
documents and opinions as they may reasonably require for the purpose of enabling them to pass upon
the sale of the Shares as herein contemplated and related proceedings or in order to evidence the
occurrence or completeness of any of the representations or warranties, or the fulfillment of any of
the conditions, herein contained; and all proceedings taken by the Company, the MHC or the Bank in
connection with the Offering and the sale

32
<!-- page 20 -->
of the Shares as herein contemplated shall be satisfactory in form and substance to the Agent and
its counsel.

Section 8. Indemnification.

(a) The Company, the MHC and the Bank jointly and severally agree to indemnify and hold harmless the
Agent, its respective officers and directors, employees and agents, and each person, if any, who
controls the Agent within the meaning of Section 15 of the 1933 Act or Section 20(a) of the 1934
Act, against any and all loss, liability, claim, damage or expense whatsoever (including but not
limited to settlement expenses), joint or several, that the Agent or any of them may suffer or to
which the Agent and any such persons may become subject under all applicable federal or state laws
or otherwise, and to promptly reimburse the Agent and any such persons upon written demand for any
expense (including reasonable fees and disbursements of counsel) incurred by the Agent or any of
them in connection with investigating, preparing or defending any actions, proceedings or claims
(whether commenced or threatened) to the extent such losses, claims, damages, liabilities or
actions: (i) arise out of or are based upon any untrue statement or alleged untrue statement of a
material fact contained in the Registration Statement (or any amendment or supplement thereto),
preliminary or final Prospectus (or any amendment or supplement thereto), the MHC Application (or
any amendment or supplement thereto), or any instrument or document executed by the Company, the MHC
or the Bank or based upon written information supplied by the Company, the MHC or the Bank filed in
any state or jurisdiction to register or qualify any or all of the Shares or to claim an exemption
therefrom, or provided to any state or jurisdiction to exempt the Company as a broker-dealer or its
officers, directors and employees as broker-dealers or agent, under the securities laws thereof
(collectively, the "Blue Sky Application"), or any document, advertisement, oral statement or
communication ("Sales Information") prepared, made or executed by or on behalf of the Company, the
MHC or the Bank with their consent or based upon written or oral information furnished by or on
behalf of the Company, the MHC or the Bank, whether or not filed in any jurisdiction, in order to
qualify or register the Shares or to claim an exemption therefrom under the securities laws thereof;
(ii) arise out of or are based upon the omission or alleged omission to state in any of the
foregoing documents or information, a material fact required to be stated therein or necessary to
make the statements therein, in light of the circumstances under which they were made, not
misleading; or (iii) arise from any theory of liability whatsoever relating to or arising from or
based upon the Registration Statement (or any amendment or supplement thereto), preliminary or final
Prospectus (or any amendment or supplement thereto), the MHC Application

33

(or any amendment or supplement thereto), any Blue Sky Application or Sales Information or other
documentation distributed in connection with the Offering; provided, however, that no
indemnification is required under this paragraph (a) to the extent such losses, claims, damages,
liabilities or actions arise out of or are based upon any untrue material statement or alleged
untrue material statement in, or material omission or alleged material omission from, the
Registration Statement (or any amendment or supplement thereto), preliminary or final Prospectus (or
any amendment or supplement thereto), the MHC Application (or any amendment or supplement thereto),
any Blue Sky Application or Sales Information made in reliance upon and in conformity with
information furnished in writing to the Company, the MHC or the Bank by the Agent or its counsel
regarding the Agent provided, that it is agreed and understood that the only information furnished
in writing to the Company, the MHC or the Bank by the Agent regarding the Agent is set forth in the
Prospectus; and, provided further, that such indemnification shall be to the extent permitted by the
Commissioner, the OTS, the FDIC and the Board of Governors of the Federal Reserve. The
indemnification provided for in this paragraph (a) shall not be applicable with respect to any loss,
liability, claim, damage, or expense whatsoever if it is determined by final judgment of a court
having jurisdiction over the matter that such loss, liability, claim, damage or expense was
primarily a result of the Agent's willful misconduct or gross negligence.

(b) The Agent agrees to indemnify and hold harmless the Company, the MHC and the Bank, their
directors and officers and each person, if any, who controls the Company, the MHC or the Bank within
the meaning of Section 15 of the 1933 Act or Section 20(a) of the 1934 Act against any and all loss,
liability, claim, damage or expense whatsoever (including but not limited to settlement expenses),
joint or several, which they, or any of them, may suffer or to which they, or any of them may become
subject under all applicable federal and state laws or otherwise, and to promptly reimburse the
Company, the MHC, the Bank, and any such persons upon written demand for any expenses (including
<!-- page 21 -->
reasonable fees and disbursements of counsel) incurred by them, or any of them, in connection with
investigating, preparing or defending any actions, proceedings or claims (whether commenced or
threatened) to the extent such losses, claims, damages, liabilities or actions: (i) arise out of or
are based upon any untrue statement or alleged untrue statement of a material fact contained in the
Registration Statement (or any amendment or supplement thereto), the MHC Application (or any
amendment or supplement thereto), the preliminary or final Prospectus (or any amendment or
supplement thereto), any Blue Sky Application or Sales Information, (ii) are based upon the omission
or alleged omission to state in any of the foregoing documents a material fact required to be stated
therein

34

or necessary to make the statements therein, in the light of the circumstances under which they were
made, not misleading, or (iii) arise from any theory of liability whatsoever relating to or arising
from or based upon the Registration Statement (or any amendment or supplement thereto), preliminary
or final Prospectus (or any amendment or supplement thereto), the MHC Application (or any amendment
or supplement thereto),or any Blue Sky Application or Sales Information or other documentation
distributed in connection with the Offering; provided, however, that the Agent's obligations under
this Section 8(b) shall exist only if and only to the extent (i) that such untrue statement or
alleged untrue statement was made in, or such material fact or alleged material fact was omitted
from, the Registration Statement (or any amendment or supplement thereto), the preliminary or final
Prospectus (or any amendment or supplement thereto), the MHC Application (or any amendment or
supplement thereto), or any Blue Sky Application or Sales Information in reliance upon and in
conformity with information furnished in writing to the Company, the MHC or the Bank by the Agent or
its counsel regarding the Agent, provided, that it is agreed and understood that the only
information furnished in writing to the Company, the MHC or the Bank by the Agent regarding the
Agent is set forth in the Prospectus. The indemnification provided for in this Section 8 (b) shall
not be applicable with respect to any loss, liability, claim, damage, or expense whatsoever if it is
determined by final judgment of a court having jurisdiction over the matter that such loss,
liability, claim, damage or expense was primarily a result of the Company's, the MHC's or the Bank's
willful misconduct or gross negligence.

(c) Each indemnified party shall give prompt written notice to each indemnifying party of any
action, proceeding, claim (whether commenced or threatened), or suit instituted against it in
respect of which indemnity may be sought hereunder, but failure to so notify an indemnifying party
shall not relieve it from any liability which it may have on account of this Section 8 or otherwise.
An indemnifying party may participate at its own expense in the defense of such action. In addition,
if it so elects within a reasonable time after receipt of such notice, an indemnifying party,
jointly with any other indemnifying parties receiving such notice, may assume defense of such action
with counsel chosen by it and approved by the indemnified parties that are defendants in such
action, unless such indemnified parties reasonably object to such assumption on the ground that
there may be legal defenses available to them that are different from or in addition to those
available to such indemnifying party. If an indemnifying party assumes the defense of such action,
the indemnifying parties shall not be liable for any fees and expenses of counsel for the
indemnified parties incurred thereafter in connection with such action, proceeding or claim, other
than reasonable costs

35

of investigation. In no event shall the indemnifying parties be liable for the fees and expenses of
more than one separate firm of attorneys (and any special counsel that said firm may retain) for
each indemnified party in connection with any one action, proceeding or claim or separate but
similar or related actions, proceedings or claims in the same jurisdiction arising out of the same
general allegations or circumstances.

(d) The agreements contained in this Section 8 and in Section 9 hereof and the representations and
warranties of the Company, the MHC and the Bank set forth in this Agreement shall remain operative
and in full force and effect regardless of: (i) any investigation made by or on behalf of agent or
their officers, directors or controlling persons, agent or employees or by or on behalf of the
Company, the MHC or the Bank or any officers, directors or controlling persons, agent or employees
of the Company, the MHC or the Bank; (ii) delivery of and payment hereunder for the Shares; or (iii)
any termination of this
<!-- page 22 -->
Agreement.

Section 9. Contribution. In order to provide for just and equitable contribution in circumstances in
which the indemnification provided for in Section 8 is due in accordance with its terms but is for
any reason held by a court to be unavailable from the Company, the MHC, the Bank or the Agent, the
Company, the MHC, the Bank and the Agent shall contribute to the aggregate losses, claims, damages
and liabilities (including any investigation, legal and other expenses incurred in connection with,
and any amount paid in settlement of, any action, suit or proceeding of any claims asserted, but
after deducting any contribution received by the Company, the MHC, the Bank or the Agent from
persons other than the other party thereto, who may also be liable for contribution) in such
proportion so that the Agent is responsible for that portion represented by the percentage that the
fees paid to the Agent pursuant to Section 2 of this Agreement (not including expenses) bears to the
gross proceeds received by the Company from the sale of the Shares in the Offering, and the Company,
the MHC and the Bank shall be responsible for the balance. If, however, the allocation provided
above is not permitted by applicable law or if the indemnified party failed to give the notice
required under Section 8 above, then each indemnifying party shall contribute to such amount paid or
payable by such indemnified party in such proportion as is appropriate to reflect not only such
relative fault of the Company, the MHC and the Bank on the one hand and the Agent on the other in
connection with the statements or omissions which resulted in such losses, claims, damages or
liabilities (or actions, proceedings or claims in respect thereto), but also the relative benefits
received by the Company, the MHC and the Bank on the one hand and the Agent on the other from the
Offering (before deducting expenses). The relative fault shall be determined by reference to, among
other things, whether the untrue or alleged untrue statement of a material fact or the omission or
alleged omission to state a material fact relates to information supplied by the Company, the MHC
and/or the Bank on the one hand or the Agent on the other and the parties' relative intent, good
faith, knowledge, access to information and opportunity to correct or prevent such statement or
omission. The Company, the MHC, the Bank and the Agent agree that it would not be just and equitable
if contribution pursuant to this Section 9 were determined by pro-rata allocation or by any other

36

method of allocation which does not take into account the equitable considerations referred to above
in this Section 9. The amount paid or payable by an indemnified party as a result of the losses,
claims, damages or liabilities (or actions, proceedings or claims in respect thereof) referred to
above in this Section 9 shall be deemed to include any legal or other expenses reasonably incurred
by such indemnified party in connection with investigating or defending any such action, proceeding
or claim. It is expressly agreed that the Agent shall not be liable for any loss, liability, claim,
damage or expense or be required to contribute any amount which in the aggregate exceeds the amount
paid (excluding reimbursable expenses) to the Agent under this Agreement. It is understood that the
above stated limitation on the Agent's liability is essential to the Agent and that the Agent would
not have entered into this Agreement if such limitation had not been agreed to by the parties to
this Agreement. No person found guilty of any fraudulent misrepresentation (within the meaning of
Section 11(f) of the 1933 Act) shall be entitled to contribution from any person who was not found
guilty of such fraudulent misrepresentation. The obligations of the Company, the MHC and the Bank
under this Section 9 and under Section 8 shall be in addition to any liability which the Company and
the Bank may otherwise have. For purposes of this Section 9, each of the Agent's, the Company's, the
MHC or the Bank's officers and directors and each person, if any, who controls the Agent or the
Company or the MHC or the Bank within the meaning of the 1933 Act and the 1934 Act shall have the
same rights to contribution as the Agent, the Company, the MHC or the Bank. Any party entitled to
contribution, promptly after receipt of notice of commencement of any action, suit, claim or
proceeding against such party in respect of which a claim for contribution may be made against
another party under this Section 9, will notify such party from whom contribution may be sought, but
the omission to so notify such party shall not relieve the party from whom contribution may be
sought from any other obligation it may have hereunder or otherwise than under this Section 9.

Section 10. Survival of Agreements, Representations and Indemnities. The respective indemnities of
the Company, the MHC, the Bank and the Agent and the representations and warranties and other
statements of the Company, the MHC, the Bank and the Agent set forth in or made pursuant to this
Agreement shall remain in full force and effect, regardless of any termination or cancellation of
this Agreement or any investigation made by or on behalf of the Agent, the Company, the MHC, the
Bank or any controlling person referred to in Section 8 hereof, and shall survive the issuance of
the Shares, and any successor or assign of the Agent, the Company, the MHC, the Bank, and any such
controlling person shall be entitled to the benefit of the respective agreements, indemnities,
warranties and representations.

Section 11. Termination. The Agent may terminate this Agreement by giving the notice indicated below
in this Section 11 at any time after this Agreement becomes effective as follows:

(a) In the event the Company fails to sell the required minimum number of the Shares by _________,
2000, and in accordance with the provisions of the Plan or as required by the MHC Regulations, and
applicable law, this Agreement shall terminate upon refund by the Company to each person who has
subscribed for or ordered any of the Shares the full amount which it may

37
<!-- page 23 -->
have received from such person, together with interest as provided in the Prospectus, and no party
to this Agreement shall have any obligation to the other hereunder, except for payment by the
Company, the MHC and/or the Bank as set forth in Sections 2(a), 6, 8 and 9 hereof.

(b) If any of the conditions specified in Section 7 shall not have been fulfilled when and as
required by this Agreement unless waived in writing, or by the Closing Date, this Agreement and all
of the Agent's obligations hereunder may be cancelled by the Agent by notifying the Company, the MHC
and the Bank of such cancellation in writing or by telegram at any time at or prior to the Closing
Date, and any such cancellation shall be without liability of any party to any other party except as
otherwise provided in Sections 2(a), 6, 8 and 9 hereof.

(c) If the Agent elects to terminate this Agreement as provided in this Section, the Company, the
MHC and the Bank shall be notified promptly by telephone or telegram, confirmed by letter.

The Company, the MHC and the Bank may terminate this Agreement in the event the Agent is in material
breach of the representations and warranties or covenants contained in Section 5 and such breach has
not been cured after the Company, the MHC and the Bank have provided the Agent with notice of such
breach.

This Agreement may also be terminated by mutual written consent of the parties hereto.

Section 12. Notices. All communications hereunder, except as herein otherwise specifically provided,
shall be mailed in writing and if sent to the Agent shall be mailed, delivered or telegraphed and
confirmed to Charles Webb & Company, a Division of Keefe, Bruyette & Woods, Inc., 211 Bradenton,
Dublin, Ohio 43017-3514, Attention: Patricia A. McJoynt, Executive Vice President (with a copy to
Silver, Freedman & Taff, L.L.P., Attention: Martin L. Meyrowitz, P.C.) and, if sent to the Company,
the MHC and the Bank, shall be mailed, delivered or telegraphed and confirmed to the Company, the
MHC and the Bank at 500 10th Street, Alamogordo, New Mexico 88310-0690, Attention: Miles Ledgewood,
President (with a copy to Luse Lehman Gorman Pomerenk & Schick, Attention: Eric Luse).

Section 13. Parties. The Company, the MHC and the Bank shall be entitled to act and rely on any
request, notice, consent, waiver or agreement purportedly given on behalf of the Agent when the same
shall have been given by the undersigned. The Agent shall be entitled to act and rely on any
request, notice, consent, waiver or agreement purportedly given on behalf of the Company, the MHC or
the Bank, when the same shall have been given by the undersigned or any other officer of the
Company, the MHC or the Bank. This Agreement shall inure solely to the benefit of, and shall be
binding upon, the Agent, the Company, the MHC, the Bank, and their respective successors and
assigns, and no other person shall have or be construed to have any legal or equitable right, remedy

38

or claim under or in respect of or by virtue of this Agreement or any provision herein contained. It
is understood and agreed that this Agreement is the exclusive agreement among the parties hereto,
and supersedes any prior agreement among the parties and may not be varied except in writing signed
by all the parties.

Section 14. Closing. The closing for the sale of the Shares shall take place on the Closing Date at
such location as mutually agreed upon by the Agent and the Company, the MHC and the Bank. At the
closing, the Company, the MHC and the Bank shall deliver to the Agent in next day funds the
commissions, fees and expenses due and owing to the Agent as set forth in Sections 2 and 6 hereof
and the opinions and certificates required hereby and other documents deemed reasonably necessary by
the Agent shall be executed and delivered to effect the sale of the Shares as contemplated hereby
and pursuant to the terms of the Prospectus.

Section 15. Partial Invalidity. In the event that any term, provision or covenant herein or the
application thereof to any circumstance or situation shall be invalid or unenforceable, in whole or
in part, the remainder hereof and the application of said term, provision or covenant to any other
circumstances or situation shall not be affected thereby, and each term, provision or covenant
herein shall be valid and enforceable to the full extent permitted by law.

Section 16. Construction. This Agreement shall be construed in accordance with the laws of the State
of Kansas.

Section 17. Counterparts. This Agreement may be executed in separate counterparts, each of which so
executed and delivered shall be an original, but all of which together shall constitute but one and
the same instrument.

If the foregoing correctly sets forth the arrangement among the Company, the MHC, the Bank and the
Agent, please indicate acceptance thereof in
<!-- page 24 -->
the space provided below for that purpose, whereupon this letter and the Agent's acceptance shall
constitute a binding agreement.

Section 18. Entire Agreement. This Agreement, including schedules and exhibits hereto, which are
integral parts hereof and incorporated as though set forth in full, constitutes the entire agreement
between the parties pertaining to the subject matter hereof superseding any and all prior or
contemporaneous oral or prior written agreements, proposals, letters of intent and understandings,
and cannot be modified, changed, waived or terminated except by a writing which expressly states
that it is an amendment, modification or waiver, refers to this Agreement and is signed by the party

39

to be charged. No course of conduct or dealing shall be construed to modify, amend or otherwise
affect any of the provisions hereof.

Very truly yours,

ALAMOGORDO FINANCIAL ALAMOGORDO FEDERAL SAVINGS AND CORPORATION LOAN ASSOCIATION

By Its Authorized By Its Authorized Representative: Representative:

- ---------------------------- --------------------------------- Miles Ledgerwood Miles Ledgerwood
Chairman Chairman

AF MUTUAL HOLDING COMPANY

By Its Authorized Representative:

- ---------------------------- Miles Ledgerwood Chairman

Accepted as of the date first above written

Charles Webb & Company, a Division Keefe, Bruyette & Woods, Inc.

By Its Authorized Representative:

- ----------------------------- Patricia A. McJoynt Executive Vice President

40
