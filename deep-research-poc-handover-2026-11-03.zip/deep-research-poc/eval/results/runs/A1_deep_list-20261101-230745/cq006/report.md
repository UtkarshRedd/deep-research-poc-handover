# Which jurisdiction's law governs the Application Development Agreement between InfinixS...

*Question:* Which jurisdiction's law governs the Application Development Agreement between InfinixSoft Global LLC and Clickstream Corporation (dated 2020-03-20)?

## Identify agreement and governing law clause

The document is the Application Development Agreement between InfinixSoft Global LLC ("Developer") and Clickstream Corporation ("Client"), dated 2020-03-20. [412cdcb23cd9a62a p.1] Section 21 states: "21. [uncited] GOVERNING LAW. [uncited] This Agreement shall be governed by the laws of the state of Florida.". [412cdcb23cd9a62a p.7] Therefore, the laws of the state of Florida govern the Application Development Agreement between InfinixSoft Global LLC and Clickstream Corporation dated 2020-03-20. [412cdcb23cd9a62a p.7]

## Verification appendix

Claims: 5 · supported: 3 · partially: 0 · dropped: 0 · gaps: 2 · tier-1 support rate: 1.00

| claim | section | tier 1 | score | sources | note |
|---|---|---|---|---|---|
| s1.1 | s1 | keep | 1.00 | e1→[412cdcb23cd9a62a p.1] |  |
| s1.2 | s1 | gap |  |  | no evidence cited |
| s1.3 | s1 | gap |  |  | no evidence cited |
| s1.4 | s1 | keep | 1.00 | e2→[412cdcb23cd9a62a p.7] |  |
| s1.5 | s1 | keep | 1.00 | e2→[412cdcb23cd9a62a p.7] |  |

### Evidence

- e1 [412cdcb23cd9a62a p.1 L2-7] keep (1.0): "# APPLICATION DEVELOPMENT AGREEMENT
| Field | Value |
|---|---|
| Document Type | Development Agreement |
| Agreement Date | 2020-03-20 |
| Parties | InfinixSoft Global LLC ("Developer"); Clickstream Corporation ("Client") |"
- e2 [412cdcb23cd9a62a p.7 L290-291] keep (1.0): "21. GOVERNING LAW. This Agreement shall be governed by the laws of the state of Florida."
