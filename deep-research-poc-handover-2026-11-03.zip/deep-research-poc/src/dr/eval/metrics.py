"""Metrics (PLAN Phase 6). Deterministic ones never call a model; the judge is the only model
metric and gets an explicit "unknown" option so it is never forced into a verdict.

Retrieval
  candidate_recall        gold docs ∩ first-move candidates / gold docs           (the ceiling)
  opened_or_cited_recall  gold docs ∩ (docs read or cited) / gold docs            (localization; DCI:
                          coverage alone misleads, this measures whether the agent got to the text)
  gold_page_cited         gold docs with >= 1 evidence item on a gold page / gold docs
Grounding
  citation_support_rate   claims with tier1 keep|truncate / claims with evidence
  hallucination_gate      True = FAIL: a claim with tier1 drop (or tier2 unsupported) survived
  gap_rate                gap claims / all claims
Answer
  contains_answer         gold answer text appears in the report (cheap proxy, exact questions)
  item_recall             coverage questions: gold items present in the report / gold items
  abstention              not_in_corpus questions must abstain; others must not
  judge                   rubric-based LLM verdict: correct | partially_correct | incorrect | unknown
Cost
  tokens per correct answer (free tier: tokens stand in for dollars)
"""
from __future__ import annotations

import re
import statistics
from typing import Any, Literal

from pydantic import BaseModel, Field

from ..models import EvidenceItem, VerifyResult
from ..prompts import load
from ..structured import ModelCaller


def _norm(s: str) -> str:
    return " ".join(re.sub(r"[^\w%.$-]+", " ", s.lower()).split())


# --------------------------------------------------------------------------- retrieval / grounding


def recall(gold: set[str], found: set[str]) -> float | None:
    if not gold:
        return None
    return len(gold & found) / len(gold)


def gold_page_cited(gold: list[tuple[str, list[int]]], items: list[EvidenceItem]) -> float | None:
    """Fraction of gold documents with at least one evidence item on one of their gold pages
    (any page counts when the gold entry lists no pages)."""
    if not gold:
        return None
    hit = 0
    for doc_id, pages in gold:
        for it in items:
            if it.doc_id == doc_id and (not pages or it.page in pages):
                hit += 1
                break
    return hit / len(gold)


def citation_support_rate(results: list[VerifyResult]) -> float | None:
    cited = [r for r in results if r.tier1 != "gap"]
    if not cited:
        return None
    ok = sum(1 for r in cited if r.tier1 in ("keep", "truncate"))
    return ok / len(cited)


def hallucination_gate(results: list[VerifyResult]) -> bool:
    """True = FAIL (at least one unsupported claim survived to the report)."""
    return any(r.tier1 == "drop" or r.tier2 == "unsupported" for r in results)


def gap_rate(results: list[VerifyResult]) -> float | None:
    if not results:
        return None
    return sum(1 for r in results if r.tier1 == "gap") / len(results)


# --------------------------------------------------------------------------- answer


def contains_answer(gold_answer: str | None, text: str) -> bool | None:
    if not gold_answer:
        return None
    return _norm(gold_answer) in _norm(text)


def item_recall(gold_items: list[str], text: str) -> float | None:
    if not gold_items:
        return None
    body = _norm(text)
    return sum(1 for it in gold_items if _norm(it) in body) / len(gold_items)


def abstention(q_type: str, abstained: bool) -> dict[str, bool]:
    expected = q_type == "not_in_corpus"
    return {"expected": expected, "abstained": abstained, "correct": expected == abstained}


class JudgeJSON(BaseModel):
    verdict: Literal["correct", "partially_correct", "incorrect", "unknown"] = "unknown"
    rubric_hits: list[bool] = Field(default_factory=list)
    reason: str = ""


_SCORE = {"correct": 1.0, "partially_correct": 0.5, "incorrect": 0.0, "unknown": None}


def judge_correctness(question: str, gold_answer: str | None, rubric: list[str], report_md: str,
                      caller: ModelCaller, max_report_chars: int = 12_000) -> dict[str, Any]:
    """Rubric-based verdict from the judge model; a failed or unparseable reply is `unknown`."""
    from langchain_core.messages import HumanMessage

    body = report_md if len(report_md) <= max_report_chars else report_md[:max_report_chars] + "\n…(truncated)"
    prompt = load("judge", question=question, gold_answer=gold_answer or "(no reference answer; use the rubric)",
                  rubric="\n".join(f"{i + 1}. {r}" for i, r in enumerate(rubric)) or "(none)", report=body)
    got = caller.json([HumanMessage(content=prompt)], JudgeJSON) or JudgeJSON(reason="judge call failed or returned invalid JSON")
    hits = got.rubric_hits[: len(rubric)] if rubric else []
    return {"verdict": got.verdict, "score": _SCORE[got.verdict], "rubric_hits": hits,
            "rubric_rate": (sum(hits) / len(rubric)) if rubric and hits else None, "reason": got.reason[:300]}


# --------------------------------------------------------------------------- aggregation


def _mean(values: list) -> float | None:
    vals = [v for v in values if isinstance(v, (int, float)) and not isinstance(v, bool)]
    return round(sum(vals) / len(vals), 3) if vals else None


def _rate(values: list) -> float | None:
    vals = [v for v in values if isinstance(v, bool)]
    return round(sum(vals) / len(vals), 3) if vals else None


def _median(values: list) -> float | None:
    vals = [v for v in values if isinstance(v, (int, float)) and not isinstance(v, bool)]
    return round(statistics.median(vals), 1) if vals else None


def summarize(rows: list[dict]) -> dict[str, dict]:
    """Per-slice (question type) and overall aggregates over runner rows."""
    out: dict[str, dict] = {}
    slices = ["all"] + sorted({r["type"] for r in rows})
    for sl in slices:
        rs = rows if sl == "all" else [r for r in rows if r["type"] == sl]
        ok = [r for r in rs if not r.get("error")]
        correct = [r for r in ok if r.get("judge_score") == 1.0] or (
            [r for r in ok if r.get("contains_answer") is True] if all(r.get("judge_verdict") is None for r in ok) else [])
        tokens = sum((r.get("in_tokens") or 0) + (r.get("out_tokens") or 0) for r in ok)
        out[sl] = {
            "n": len(rs), "errors": len(rs) - len(ok),
            "candidate_recall": _mean([r.get("candidate_recall") for r in ok]),
            "opened_or_cited_recall": _mean([r.get("opened_or_cited_recall") for r in ok]),
            "gold_page_cited": _mean([r.get("gold_page_cited") for r in ok]),
            "support_rate": _mean([r.get("support_rate") for r in ok]),
            "gate_fail_rate": _rate([r.get("gate_fail") for r in ok]),
            "contains_answer_rate": _rate([r.get("contains_answer") for r in ok]),
            "item_recall": _mean([r.get("item_recall") for r in ok]),
            "abstention_ok_rate": _rate([r.get("abstention_correct") for r in ok]),
            "judge_pass_rate": _rate([(r.get("judge_verdict") == "correct") for r in ok if r.get("judge_verdict")]),
            "judge_unknown_rate": _rate([(r.get("judge_verdict") == "unknown") for r in ok if r.get("judge_verdict")]),
            "wall_s_p50": _median([r.get("wall_s") for r in ok]),
            "calls_p50": _median([r.get("tool_calls") for r in ok]),
            "tokens_p50": _median([(r.get("in_tokens") or 0) + (r.get("out_tokens") or 0) for r in ok]),
            "tokens_per_correct": round(tokens / len(correct)) if correct else None,
        }
    return out


def render_summary(summary: dict[str, dict], variant: str) -> str:
    cols = [("n", "n"), ("errors", "err"), ("candidate_recall", "cand recall"), ("opened_or_cited_recall", "opened/cited"),
            ("gold_page_cited", "gold page"), ("support_rate", "support"), ("gate_fail_rate", "gate fail"),
            ("contains_answer_rate", "has answer"), ("item_recall", "item recall"), ("abstention_ok_rate", "abstain ok"),
            ("judge_pass_rate", "judge pass"), ("judge_unknown_rate", "judge ?"), ("wall_s_p50", "wall s p50"),
            ("calls_p50", "calls p50"), ("tokens_p50", "tokens p50"), ("tokens_per_correct", "tok/correct")]
    lines = [f"### {variant}", "", "| slice | " + " | ".join(h for _, h in cols) + " |", "|---|" + "---|" * len(cols)]
    for sl, m in summary.items():
        lines.append(f"| {sl} | " + " | ".join("" if m.get(k) is None else str(m[k]) for k, _ in cols) + " |")
    return "\n".join(lines) + "\n"
