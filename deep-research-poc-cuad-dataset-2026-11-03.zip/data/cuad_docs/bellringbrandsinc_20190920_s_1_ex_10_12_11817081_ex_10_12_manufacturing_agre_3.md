<!-- page 1 -->
# MANUFACTURING AGREEMENT
| Field | Value |
|---|---|
| Document Type | Manufacturing Agreement |
| Agreement Date | 2018-10-01 |
| Parties | Stremick's Heritage Foods, LLC ("Heritage"); Premier Nutrition Corporation ("Premier"); Heritage and Premier (individually as a “Party” and collectively as the “Parties”) |
| Source | CUAD v1 / BellringBrandsInc_20190920_S-1_EX-10.12_11817081_EX-10.12_Manufacturing Agreement3 |

AMENDMENT NO. 2 TO STREMICK'S HERITAGE FOODS, LLC and PREMIER NUTRITION CORPORATION MANUFACTURING
AGREEMENT

This Second Amendment ("Second Amendment"), entered into by and between Stremick's Heritage Foods,
LLC, ("Heritage"), Premier Nutrition Corporation ("Premier") is effective as of October 1, 2018
("Second Amendment Effective Date") and amends that certain Manufacturing Agreement between Heritage
and Premier dated July 1, 2017 ("Agreement"). Heritage and Premier are each referred to herein as a
"Party" and collectively as the "Parties".

WHEREAS, PREMIER and HERITAGE entered into the Agreement;

WHEREAS, the Parties wish to extend and amend the Agreement in accordance with the terms and
conditions set forth herein; and

WHEREAS, HERITAGE [***] desires to produce Products packaged in aseptic plastic bottles ("Bottled
Products") for PREMIER in accordance with the terms and conditions set forth in the Agreement, as
well as those set forth herein, [***]; and

NOW, THEREFORE, in consideration of the promises and of the mutual covenants, representations and
warranties, contained in the Agreement and set forth herein, the Parties hereby agree that the
following changes be made to the Agreement: 1. Term. This Second Amendment shall be effective from
The Second Amendment Effective Date and shall expire on December 31, 2021. Upon expiration, this
Second Amendment shall be of no further force or effect, and the terms and conditions of the
Agreement shall as they were before the Second Amendment Effective Date. Notwithstanding anything
herein to the contrary, a Party's right to enforce the terms and conditions of this Second Amendment
shall survive the Second Amendment's expiration. 2. 1 BASIC TERMS. Section 1, of the Agreement is
amended as follows:

a. Section 1(a)(viii) is removed in its entirety and replaced with:

"(viii) Pricing and Terms for Tetra 325 ml Dreamcaps ........................ Schedule C"

b. A new section, Section 1(a)(xi), is inserted to read

"(xi) Pricing and Terms for Aseptic Plastic Bottles ........................... Schedule C-1" 3.
PRODUCTION OF PRODUCT.

a. Section 2(a) of the Agreement is amended so that the first sentence that previously read:

"Heritage shall produce the products described on Schedule A attached hereto, as may be amended by
the Parties hereafter from time to time (the "Products"), for Premier at [***] Heritage's or
Heritage's wholly owned subsidiary, Jasper's facilities (the "Facilities"). [***]"

Source: BELLRING BRANDS, INC., S-1, 9/20/2019
<!-- page 2 -->
now reads:

"Heritage shall produce the products described on Schedule A and Schedule A-1 attached hereto, as
may be amended by the Parties hereafter from time to time (the "Products," each individual unit of
Product "Unit"), for Premier at [***] Heritage's or Heritage's wholly owned subsidiary, Jasper's
facilities (the "Facilities"). [***], except that, notwithstanding anything herein to the contrary,
[***]."

b. Section 2(c) of the Agreement is amended so that the term "Units" as defined therein is now
referred to as "Tetra Units".

c. Section 2(d) of the Agreement is amended so that whereas it previously read:

"During the Term, Premier shall have the right (but not the obligation) to order from Heritage
quantities of Products in excess of [***] and provided Heritage has the capacity and the ability to
produce such additional quantities of Products, Heritage agrees to produce such additional
quantities per the pricing and terms on Schedule C."

it now reads:

"During the Term, Premier shall have the right (but not the obligation) to order from Heritage
quantities of Products in in excess of [***] and provided Heritage has the capacity and the ability
to produce such additional quantities of Products, Heritage agrees to produce such additional
quantities per the pricing and terms on Schedule C."

d. Section 2(e) of the Agreement is amended so that whereas it previously read:

[***]

it now reads:

[***]

e. Section 2(f) of the Agreement is amended so that whereas it previously read:

[***]

it now reads:

[***]

f. Section 2(m) of the Agreement is amended so that the term "Units" appearing in the second
complete sentence is replaced with the term "Tetra Units".

g. Section 2(n) of the Agreement is amended so that the last sentence that previously read:

"The final production quantity by Heritage and Jasper will count towards the MAOV requirements" 2

Source: BELLRING BRANDS, INC., S-1, 9/20/2019
<!-- page 3 -->
now reads:

"The final production quantity of Tetra Units by Heritage and Jasper will count toward the MAOV
requirements for Tetra Units."

h. Section 2(o)(i) of the Agreement is amended so that the first sentence that previously read:

"All Products manufactured, packaged and delivered to Heritage or Jasper under the terms of this
Agreement shall conform to the specifications supplied to Heritage by Premier as listed on Schedule
A, which Schedule may from time to time be modified by Premier in writing (the "Specifications"),
shall conform to Post Holding's Quality Expectations Manual attached hereto as Schedule E, and shall
conform in all material respects to samples previously supplied to Premier by Heritage."

now reads:

"All Products manufactured, packaged and delivered by Heritage or Jasper under the terms of this
Agreement shall conform to the specifications supplied to Heritage by Premier as listed on Schedule
A and/or Schedule A-1, which Schedules may from time to time be modified by Premier in writing (the
"Specifications"), shall conform to Post Holding's Quality Expectations Manual attached hereto as
Schedule E, and shall conform in all material respects to samples previously supplied to Premier by
Heritage." 4. Section 3 DELIVER, PRICING, BILLING AND PAYMENT

a. Section 3(b) of the Agreement is amended so that whereas it previously read:

"Heritage shall purchase all ingredients and packaging materials identified in Schedule C to be used
in connection with the manufacturer of the Products. Heritage shall invoice Premier through the
[***] billing as identified on Schedule C."

now reads:

"Heritage shall purchase all ingredients and packaging materials identified in the relevant Schedule
C or Schedule C-l to be used in connection with the manufacturer of the Products. Heritage shall
invoice Premier through the [***] billing as identified on the relevant Schedule C or Schedule C-l.
Heritage shall not, however, purchase ingredients or packaging materials in excess of those required
[***]."

b. Section 3(c) of the Agreement is amended so that whereas it previously read:

"Heritage shall charge Premier [***] as set forth in Schedule C."

it now reads:

"Heritage shall charge Premier [***] as set forth in the relevant Schedule C or Schedule C-1." 5.
Schedule A-l. The following is attached to and incorporated into the Agreement as Schedule A-l:

Schedule A-1 ([***])

[***]

[***] 3

Source: BELLRING BRANDS, INC., S-1, 9/20/2019
<!-- page 4 -->
6. Section 13 NOTICES is amended such that whereas Notice to PREMIER was required to:

"VP Operations Premier Nutrition Corporation 188 Spear Street, Suite 600 San Francisco, CA 94608
Email:[***]

With a Copy to General Counsel: Email [***]"

it is now required to:

"Premier Nutrition Corporation VP Operations 1222 67th Street, Suite 210 Emeryville, CA 94608 Email:
[***]

With a Copy to General Counsel: Email [***]" 7. Schedule C-l. The following is attached to and
incorporated into the Agreement as Schedule C-l:

Schedule C-1 ([***])

[***]

8. Except as otherwise specified above in this Amendment, all other terms, conditions, and covenants
of the Agreement shall remain in full force and effect.

IN WITNESS WHEREOF, the Parties have caused this Agreement to be executed by a duly authorized
officer on the day and year first above written. PREMIER NUTRITION CORPORATION STREMICKS HERITAGE
FOODS, LLC And as and for Jasper Products, LLC

BY: /s/ Darcy Davenport BY: /s/ Sam Stremick ITS: President ITS: President 4

Source: BELLRING BRANDS, INC., S-1, 9/20/2019
