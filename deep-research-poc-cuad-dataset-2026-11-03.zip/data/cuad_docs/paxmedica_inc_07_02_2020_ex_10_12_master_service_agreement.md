<!-- page 1 -->
# Master Service Agreement
| Field | Value |
|---|---|
| Document Type | Service Agreement |
| Agreement Date | 2008-05-25 |
| Parties | CRO Consultiong (Pty) Limited ("CRO"); Purinis Pharmaceuticals LLC ("Client") |
| Source | CUAD v1 / PAXMEDICA,INC_07_02_2020-EX-10.12-Master Service Agreement |

Exhibit 10.12 Certain identified information has been excluded because it is both not material and
would likely cause competitive harm if publicly disclosed.

Master Service Agreement This Master Service Agreement ("Agreement"), entered into on May 25th, 2018
by and between CRO Consulting (Pty) Limited, whose Registered Office is at OnQ House 250 Market
Street Fairland Johannesburg 2170 South Africa (hereinafter referred to as "CRO") and Purinix
Pharmaceuticals LLC whose Registered Office is at 1266 East Main Street, Suite 700R, Stamford, CT
06902, USA (hereinafter referred to as "Client"). 1.0 Services 1.1. Client requires CRO to carry out
Clinical Research Services in South Africa ("Services"). CRO will carry out the tasks agreed and
summarised in the Addenda to this Master Service Agreement. 1.2. This Agreement forms the basis for
a working relationship between Client and CRO. This Agreement will be supplemented, in the form of
Project-specific Addenda, as the need arises. The Project-specific Addenda will contain the detailed
requirements of each Project for which Services are contracted to CRO by Client and all fees to be
paid by Client. 1.3. Client will provide CRO with the documents and information necessary as
requested by CRO for the conduct of the Services. 1.4. CRO agrees to perform the specific tasks set
forth in the Project-specific Addenda in a professional manner, in strict accordance with the terms
and conditions contained herein, relevant professional standards including in accordance with the
Protocol and applicable amendments and ICH GCP Guidelines (ICH Harmonised Tripartite Guideline for
Good Clinical Practice, May 1996) and all other relevant laws, rules, regulations and guidelines.
1.5. CRO agrees to perform these Services according to CRO's Standard Operating Procedures (SOPs) or
other guidelines as provided, which are provided to Client on request. 1.6 CRO may not subcontract
any parts of the Services to a third party without the prior written approval of Client, which
approval shall not unreasonably be withheld. CRO will remain fully liable for the acts and omissions
of its employees and approved subcontractors as if performed by CRO. 1.7 CRO will provide Client
with a weekly written report summarizing the Services including all clinical study activity and any
other information reasonably requested by Client. 2.0 Payment 2.1 Client will pay CRO for
satisfactory performance of Services as agreed in each Project-specific Addendum to this Agreement.
Confidential Page 1 of 7 Initials: CL MD Version Jan16_v1
<!-- page 2 -->
Certain identified information has been excluded because it is both not material and would likely
cause competitive harm if publicly disclosed. 2.2 Routine telephone calls, mobile calls, faxes and
photocopying will be included in the rate provided by CRO. For clarity, there shall be no payment
obligations other than as agreed in each Project-specific Addendum. 2.4 CRO will provide a detailed
account of all time and tasks, as against project specific task and time addenda, and will be
payable within 30 days of receipt of invoice by Client. 2.5. Changes in scope may be incorporated
into this Agreement or the Project-specific Addenda upon the written consent of both parties. 2.6.
In the event of a conflict between the terms of this Agreement and the Project-specific Addenda the
terms of this Agreement shall prevail unless specifically stated in the Project-specific Addenda.
3.0 Period of the Agreement 3.1. This Agreement shall take effect on the date of signature of the
Agreement by both parties and shall terminate when all obligations required of both parties
hereunder are performed unless either terminated earlier or extended by the parties pursuant to the
terms of this Agreement subject to clause 4.0. 4.0 Termination 4.1. Either party may terminate this
Agreement on thirty (30) days written notice if the other materially breaches this Agreement;
provided, however that the party in breach shall have the right to cure such breach within thirty
(30) days after receipt of written notice of the other party's intention to terminate. 4.2. Client
may terminate this Agreement on thirty (30) days written notice without cause. In the event of
termination by Client for reasons other than default by CRO, Client shall pay all sums owing to CRO,
but unpaid, for work performed to date of receipt of termination notice, and all reasonable and
necessary costs associated with the termination itself or to which CRO is committed to pay. In the
event of termination by Client, CRO shall use all efforts to minimize any such costs, including
cancelling orders and services to the extent possible. 4.3. In the event of early termination under
4.1. above where CRO is in material breach, any credit held in favour of CRO shall be returned to
Client within thirty (30) days following such termination, provided that the Client will then be
liable for all outstanding third party costs lawfully incurred hereunder by CRO prior to the
termination. 4.4. Either party shall be entitled forthwith to terminate this Agreement with
immediate effect by written notice to the other if that other is adjudged insolvent or goes into
liquidation (other than for bona fide reconstruction) or has a receiver appointed over any of its
property or assets. 5.0 Warranties, Limitations of Liability and Indemnification 5.1. CRO warrants
to Client that the Services will be performed in a professional and workmanlike manner and on a best
endeavours basis in accordance with the standard of care ordinarily and reasonably expected in the
performance of such Services and that the work performed for Client will be correct in all material
respects to the best of the knowledge and belief of CRO. However, Client acknowledges that the
provision of the Services is dependent upon the responsiveness of the South African regulatory
authorities and CRO shall not be held responsible for any acts or omissions of such authorities.
Confidential Page 2 of 7 Initials: CL MD Version Jan16_v1
<!-- page 3 -->
Certain identified information has been excluded because it is both not material and would likely
cause competitive harm if publicly disclosed. 5.2. CRO reserves the right to place staff on the
project, however not without initially providing a project management and resource outline to
Client, including but not limited to, the current Curriculum Vitae of proposed staff. CRO will
notify Client of any change in staff. Any new or replacement personnel shall be subject to Client's
prior written approval, which approval shall not be unreasonably withheld. 5.3. CRO will utilize CRO
business cards, letterheads and facsimile templates for the purpose of the conduct of this trial.
5.4. Notwithstanding any other provision of this Agreement, each party's total liability in respect
of damages under this Agreement, any regulation or common law shall be limited to the sum of all
amounts received from Client in terms of this Agreement; provided, however, that this limitation
shall not apply with respect to any claims arising out of or relating to clause 6 (Inventions and
Proprietary Information), indemnification obligations or damages arising from a party's gross
negligence or willful misconduct. 5.5. Neither Party shall be liable to the other Party in respect
of any indirect loses or damaged, pure economic nature, loss of profits or income howsoever arising.
5.6. CRO will defend, indemnify and hold harmless Client and its directors, officers, employees and
agents from and against all liabilities, costs and expenses (including reasonable attorneys' fees
and court costs) arising from any third party claim, action or lawsuit or other proceeding which is
attributable to any negligent or willful act or omission or breach of this Agreement on the part of
CRO or any of its agents or employees in the course of performing CRO's obligations hereunder. 5.7.
Client will defend, indemnify and hold harmless CRO and its directors, officers, employees and
agents from and against all liabilities, costs and expenses (including reasonable attorneys' fees
and court costs) arising from any third party claim, action or lawsuit or other proceeding which is
attributable to any negligent or willful act or omission or breach of this Agreement on the part of
Client or any of its agents or employees in the course of performing Client's obligations hereunder,
including but not limited to breaches of third party intellectual property rights. 6.0 Inventions
and Proprietary Information 6.1 CRO agrees that during the term of this Agreement and for a period
of three years thereafter: (a) to disclose and assign to Client as its exclusive property all
inventions and technical or business innovations specifically derived from the work assigned by
Client to CRO which CRO develops or conceives, solely or in conjunction with others (1) that are
based on or involve information of Client, (2) that relate to, constitute, result from, or include
the work in which CRO will be engaged for Client, or (3) that are otherwise made through the use of
any time, facilities or materials of Client; Confidential Page 3 of 7 Initials: CL MD Version
Jan16_v1
<!-- page 4 -->
Certain identified information has been excluded because it is both not material and would likely
cause competitive harm if publicly disclosed. (b) that all deliverables and work products in the
form of works of authorship developed by CRO in the performance of Services under this Agreement
shall be deemed works made for hire, and shall belong fully and exclusively to Client; and that if
by operation of law such deliverables or work products are not works made for hire, CRO agrees to,
and does hereby, assign to Client all right, title, and interest in such deliverables or work
product, including all copyrights therein; (c) to execute all necessary documents and provide Client
proper assistance (at its expense) sufficient to enable it to obtain patent, copyright or other
legal protections for any such inventions or innovations as described in paragraph 7.1(a) and (b),
and to make and maintain reasonably detailed accurate records of any such inventions or innovations;
(d) to deliver to Client, upon termination or expiration of this Agreement, all materials which were
provided to CRO under the terms of this Agreement and which relate to the business of, or belong to,
Client or which were provided by Client for the use of its employees, contractors or consultants;
(e) not to use, publish, or otherwise disclose (except if properly authorized as a part of the work
for Client) any information which is provided to CRO under the terms of this Agreement including but
not limited to any non-public, proprietary or confidential information; (f) not to disclose or
utilize in the performance of Services for Client any proprietary or confidential information of
others or any inventions of CRO which are not included within the scope of this Agreement; (g) not
to divulge to any person, firm, or corporation any information received during the course of this
service agreement with regard to the personal, financial, or other affairs of Client or its
subsidiaries, and that all such information shall be kept confidential and shall not, in any manner,
be revealed to anyone. h) not to divulge or make known to any person, firm, or corporation any of
the methods, processes, formulae, discoveries, or inventions, and not, in any manner whatsoever,
divulge, publish or otherwise reveal, either directly or indirectly, any knowledge of inventions or
devices which CRO may come into knowledge of solely as a result of and during the terms of CRO
agreement with Client and to retain whatever knowledge secured in trust as a fiduciary for the sole
benefit of Client, its successors and assigns. 8.0 Medical and Regulatory 8.1. Both parties shall
promptly notify the other party of any governmental regulatory inspections of which it becomes aware
and which relate to any project covered in the Addenda. Client shall have the right to be present at
any such inspections and shall have primary responsibility for preparing any responses, which may be
required, to the extent such responses relate to the project covered by the Addenda. 8.2. Client may
designate representatives who shall, upon reasonable notice to CRO, have access to and shall be
permitted to review all documents, information, data and/or materials specifically related to the
conduct of the projects covered by the Addenda. 8.3. CRO will inform Client in writing immediately
of any suspected fraud. Confidential Page 4 of 7 Initials: CL MD Version Jan16_v1
<!-- page 5 -->
Certain identified information has been excluded because it is both not material and would likely
cause competitive harm if publicly disclosed. 9.0 Independent Contractor Status 9.1 It is understood
and agreed that CRO is an independent contractor and will not have any rights to any of Client
benefits, nor for any purposes be deemed or intended to be an employee of Client. CRO agrees to make
any payments or withholding required by the South African Revenue Service. 9.2 It is further
understood that CRO is not an agent of Client and is not authorized to bind Client with respect to
any third party. 10.0 Conflicts of Interest 10.1. CRO represents that there is no conflict of
interest between performance of this Agreement and the performance of services by CRO for any other
party. In the event that CRO believes that there is presently any such conflict, or any such
conflict arises during the term of this Agreement, CRO will immediately notify Client which may, at
its sole discretion, immediately terminate this Agreement without liability to CRO. 11.0 Notices
11.1. Any notice will be in writing and will be given by registered mail, return receipt requested,
or hand delivered to the other party at the address given on this agreement or to such other address
as may be substituted by notice. If sent by mail, notice will be effective on the date of receipt.
12.0 General Provisions 12.1 CRO will not assign any right or delegate any obligation under this
Agreement without the prior written consent of Client. Any attempted assignment or delegation
without such consent will be void. 12.2 The headings in this Agreement are for reference purposes
only; they will not affect the meaning or construction of the terms of this Agreement. 12.3 If any
parts or part of this Agreement are held to be invalid, the remaining parts of the Agreement will
continue to be valid and enforceable. 12.4. The provisions of this Agreement are for the sole
benefit of the parties, and not for the benefit of any other persons or entities. 12.5 Any action of
any kind by either party arising out of this Agreement must be commenced within five (5) years from
the date the right, claim, demand, or cause of action shall first arise. 12.6 This Agreement
contains the complete and exclusive understanding of the parties with respect to the subject matter
hereof. No waiver, alteration or modification of any of the provisions hereof will be binding unless
in writing and signed by a duly authorized representative of the party to be bound. Neither the
course of conduct between the parties nor trade usage will act to modify or alter the provisions of
this Agreement. 12.7 This Agreement shall be governed by the laws of the State of Connecticut,
U.S.A. without regard to conflict of law principles. Confidential Page 5 of 7 Initials: CL MD
Version Jan16_v1
<!-- page 6 -->
Certain identified information has been excluded because it is both not material and would likely
cause competitive harm if publicly disclosed. BANKING DETAILS [***] Fur the purposes of invoicing,
invoices shall be addressed to: Purinix Pharmaceuticals LLC [***] Att: Chief Executive Officer CRO
Client Signature /s/ Michael Derby Signature /s/ Catherine Lund Name Michael Derby Name Catherine
Lund Title CEO Title Managing Director Date 25/05/2008 Date 25/05/2008 Confidential Page 6 of 7
Initials: CL MD Version Jan16_v1
<!-- page 7 -->
Certain identified information has been excluded because it is both not material and would likely
cause competitive harm if publicly disclosed. ADDENDA 1 Clinical Protocol Synopsis of Phase 2B Study
using [***]to Treat Children with Autism Spectrum Disorder PAYMENT SCHEDULE (USD) With reference to
OnQ proposal v3 13/04/2018 [***] Signature of Contract: 20% of Professional Fees OnQ costs
Monitoring [***] [***] Office overhead [***] [***] Data Management [***] [***] [***] [***] Milestone
Percentage USD ( amount) Signature of contract SAHPRA approval 15% [***] FPI 5% [***] 50%
recruitment 20% [***] 100% recruitment 20% [***] DB lock 10% [***] CSR Draft 10% [***] Acceptance of
Final CSR Final Payment [***] Confidential Page 7 of 7 Initials: CL MD Version Jan16_v1
