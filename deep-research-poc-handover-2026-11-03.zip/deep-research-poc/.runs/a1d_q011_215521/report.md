# What maximum Leverage Ratio applies to Halvorsen Marine Holdings as of 2025-05-01

*Question:* What maximum Leverage Ratio applies to Halvorsen Marine Holdings as of 2025-05-01?

## Identify Halvorsen Marine Holdings and Credit Agreement Effective Date

Halvorsen Marine Holdings is the entity whose leverage ratio is being queried. [uncited] The Credit Agreement effective date is 2025-02-14. [8b969cb203b8817e p.1] This date is before 2025-05-01. [8b969cb203b8817e p.1]

[GAP] The maximum Leverage Ratio applicable to Halvorsen Marine Holdings is not provided in the evidence.

## Locate Original Leverage Ratio Covenant

Section 7.1 of the original Credit Agreement defines the maximum Leverage Ratio covenant applicable to Halvorsen Marine Holdings. [8b969cb203b8817e p.9] The Borrower shall not permit the Leverage Ratio as of the last day of any fiscal quarter to exceed 4.00 to 1.00. [8b969cb203b8817e p.9]

## Determine Applicability as of 2025-05-01

The original maximum Leverage Ratio is 4.00 to 1.00. [5734789b958179bc p.2] The First Amendment changes the maximum Leverage Ratio to 4.50 to 1.00 effective 2025-07-31. [5734789b958179bc p.2] The First Amendment effective date is 2025-07-31, which is after 2025-05-01. [5734789b958179bc p.1] Therefore, the original maximum Leverage Ratio of 4.00 to 1.00 applies to Halvorsen Marine Holdings as of 2025-05-01. [5734789b958179bc p.2]

## Verification appendix

Claims: 10 · supported: 8 · partially: 0 · dropped: 0 · gaps: 2 · tier-1 support rate: 1.00

| claim | section | tier 1 | score | sources | note |
|---|---|---|---|---|---|
| s1.1 | s1 | gap |  |  | no evidence cited |
| s1.2 | s1 | keep | 1.00 | e4→[8b969cb203b8817e p.1] |  |
| s1.3 | s1 | keep | 1.00 | e4→[8b969cb203b8817e p.1] |  |
| s1.4 | s1 | gap |  |  |  |
| s2.1 | s2 | keep | 1.00 | e1→[8b969cb203b8817e p.9] |  |
| s2.2 | s2 | keep | 1.00 | e1→[8b969cb203b8817e p.9] |  |
| s3.1 | s3 | keep | 1.00 | e3→[5734789b958179bc p.2] |  |
| s3.2 | s3 | keep | 1.00 | e3→[5734789b958179bc p.2] |  |
| s3.3 | s3 | keep | 1.00 | e2→[5734789b958179bc p.1] |  |
| s3.4 | s3 | keep | 1.00 | e3→[5734789b958179bc p.2] |  |

### Evidence

- e1 [8b969cb203b8817e p.9 L75-75] keep (1.0): "Section 7.1 Maximum Leverage Ratio. The Borrower shall not permit the Leverage Ratio as of the last day of any fiscal quarter to exceed 4.00 to 1.00."
- e2 [5734789b958179bc p.1 L6-6] keep (1.0): "| Effective Date | 2025-07-31 |"
- e3 [5734789b958179bc p.2 L19-21] keep (1.0): "Effective as of the First Amendment Effective Date, the Credit Agreement is amended as follows:
1.1 Section 7.1 is amended by replacing "4.00 to 1.00" with "4.50 to 1.00", so that the Borrower shall not permit the Leverage Ratio as of the l…"
- e4 [8b969cb203b8817e p.1 L5-6] keep (1.0): "| Effective Date | 2025-02-14 |"
