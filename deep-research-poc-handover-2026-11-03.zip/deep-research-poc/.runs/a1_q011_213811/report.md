# What maximum Leverage Ratio applies to Halvorsen Marine Holdings as of 2025-05-01

*Question:* What maximum Leverage Ratio applies to Halvorsen Marine Holdings as of 2025-05-01?

## Halvorsen Marine Holdings as a party to the Credit Agreement

Halvorsen Marine Holdings, Inc. is listed as a party with Meridian Trust Bank, N.A. for the First Amendment effective 2025-07-31. [5734789b958179bc p.1] The provided evidence does not state that Halvorsen Marine Holdings, Inc. is a party to the Credit Agreement. [5734789b958179bc p.1] The provided evidence does not state a maximum Leverage Ratio applicable to Halvorsen Marine Holdings, Inc. as of 2025-05-01. [5734789b958179bc p.1] The provided evidence does not establish that Halvorsen Marine Holdings, Inc. is covered by Credit Agreement covenants as of 2025-05-01. [5734789b958179bc p.1]

[GAP] The maximum Leverage Ratio applicable to Halvorsen Marine Holdings, Inc. as of 2025-05-01 is not in the evidence.

[GAP] Evidence that Halvorsen Marine Holdings, Inc. is a party to the Credit Agreement is not in the evidence; only First Amendment parties are shown.

## Maximum permitted Leverage Ratio

The Original Credit Agreement, effective 2025-02-14, Section 7.1, states that the Borrower shall not permit the Leverage Ratio as of the last day of any fiscal quarter to exceed 4.00 to 1.00. [8b969cb203b8817e p.9] Therefore, the maximum permitted Leverage Ratio is 4.00 to 1.00 as of the last day of each fiscal quarter. [8b969cb203b8817e p.9]

## Effectiveness of the cap on 2025-05-01

[GAP] The writer produced nothing for: Establish that the 4.00 to 1.00 cap was in force for Halvorsen Marine Holdings on 2025-05-01 because the First Amendment, which would raise the cap to 4.50 to 1.00, is effective only on 2025-07-31 (after 2025-05-01).

## Verification appendix

Claims: 9 · supported: 6 · partially: 0 · dropped: 0 · gaps: 3 · tier-1 support rate: 1.00

Notes: OpenAITimeoutError: Request timed out.

| claim | section | tier 1 | score | sources | note |
|---|---|---|---|---|---|
| s1.1 | s1 | keep | 1.00 | e2→[5734789b958179bc p.1] |  |
| s1.2 | s1 | keep | 1.00 | e2→[5734789b958179bc p.1] |  |
| s1.3 | s1 | keep | 1.00 | e2→[5734789b958179bc p.1] |  |
| s1.4 | s1 | keep | 1.00 | e2→[5734789b958179bc p.1] |  |
| s1.5 | s1 | gap |  |  |  |
| s1.6 | s1 | gap |  |  |  |
| s2.1 | s2 | keep | 1.00 | e1→[8b969cb203b8817e p.9] |  |
| s2.2 | s2 | keep | 1.00 | e1→[8b969cb203b8817e p.9] |  |
| s3.1 | s3 | gap |  |  |  |

### Evidence

- e1 [8b969cb203b8817e p.9 L74-76] keep (1.0): "## Article VII — Financial and Negative Covenants
Section 7.1 Maximum Leverage Ratio. The Borrower shall not permit the Leverage Ratio as of the last day of any fiscal quarter to exceed 4.00 to 1.00.
Section 7.2 Minimum Interest Coverage Ra…"
- e2 [5734789b958179bc p.1 L6-7] keep (1.0): "| Effective Date | 2025-07-31 |
| Parties | Halvorsen Marine Holdings, Inc.; Meridian Trust Bank, N.A. |"
