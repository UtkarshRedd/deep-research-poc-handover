"""list_docs: compact manifest rows (metadata only, never body text).

Supports simple structured filters so the agent can use the extracted metadata
(doc_type, date range, party substring) instead of grepping for it — TODO.md item 9.
"""
from __future__ import annotations

from ..config import DEFAULT, Config
from ..models import ManifestEntry
from ..workspace import Workspace


def list_docs(
    ws: Workspace,
    doc_ids: list[str] | None = None,
    doc_type: str | None = None,
    date_from: str | None = None,
    date_to: str | None = None,
    party_contains: str | None = None,
    config: Config = DEFAULT,
) -> tuple[list[ManifestEntry], int]:
    """Return (rows, total_matching). Rows are capped; total is complete."""
    rows = [ws.manifest[d] for d in (doc_ids or ws.doc_ids()) if d in ws.manifest]
    if doc_type:
        rows = [r for r in rows if (r.doc_type or "").lower() == doc_type.lower()]
    if date_from:
        rows = [r for r in rows if r.date and r.date >= date_from]
    if date_to:
        rows = [r for r in rows if r.date and r.date <= date_to]
    if party_contains:
        q = party_contains.lower()
        rows = [r for r in rows if any(q in p.lower() for p in r.parties)]
    total = len(rows)
    return rows[: config.tools.MANIFEST_MAX_ROWS], total


def render(rows: list[ManifestEntry], total: int) -> str:
    out = [f"{total} docs" + (f" (showing {len(rows)})" if len(rows) < total else "")]
    for r in rows:
        bits = [r.doc_id, r.title[:80]]
        if r.doc_type:
            bits.append(r.doc_type)
        if r.date:
            bits.append(r.date)
        if r.parties:
            bits.append("; ".join(r.parties[:3]))
        bits.append(f"{r.n_pages}p")
        out.append(" | ".join(bits))
    return "\n".join(out)
