<!-- page 1 -->
# Side Letter — Halvorsen Marine Holdings
| Field | Value |
|---|---|
| Document Type | Side Letter |
| Effective Date | 2025-02-14 |
| Parties | Halvorsen Marine Holdings, Inc.; Meridian Trust Bank, N.A. |
| Facility ID | FAC-2025-0042 |
| Version | Side Letter |

2025-02-14
To: Halvorsen Marine Holdings, Inc., 1200 Harbor Way, Suite 400, Seattle, Washington 98101
From: Meridian Trust Bank, N.A., as Administrative Agent, on behalf of the Lenders
Re: Credit Agreement dated as of 2025-02-14 (facility FAC-2025-0042) — Permitted Vessel Dispositions

This side letter forms part of the Loan Documents and records an accommodation agreed among the parties at closing.
<!-- page 2 -->
## 1. Permitted Vessel Dispositions
Notwithstanding Section 7.6 of the Credit Agreement, the Borrower may dispose of vessels in the ordinary course of fleet renewal for aggregate consideration of up to $20,000,000 per fiscal year without the consent of the Required Lenders, provided that the Net Cash Proceeds are reinvested in replacement vessels within 180 days.
## 2. Notices
Any notice under this side letter must be delivered by electronic mail to the Administrative Agent at agency.services@example.invalid, with a copy by overnight courier, and is effective one (1) Business Day after dispatch.
<!-- page 3 -->
## 3. Confidentiality; Governing Law
This side letter is confidential and may not be disclosed except to the parties' advisors and as required by law.
This side letter shall be governed by the laws of the State of New York.
Meridian Trust Bank, N.A., as Administrative Agent — By: /s/ Authorized Signatory
Acknowledged and agreed: Halvorsen Marine Holdings, Inc. — By: /s/ Authorized Signatory
