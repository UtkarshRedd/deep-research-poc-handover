<!-- page 1 -->
# CO-DEVELOPMENT AGREEMENT
| Field | Value |
|---|---|
| Document Type | Development Agreement |
| Agreement Date | 2020-01-09 |
| Parties | PhaseBio Pharmaceuticals Inc. ("PB"); SFJ Pharmaceuticals X, Ltd. ("SFJ")("party" and collectively, the "Parties") |
| Source | CUAD v1 / PhasebioPharmaceuticalsInc_20200330_10-K_EX-10.21_12086810_EX-10.21_Development Agreement |

Exhibit 10.21

Certain information has been excluded from this agreement (indicated by "[***]") because such
information (i) is not material and (ii) would be competitively harmful if publicly disclosed.

EXECUTION VERSION

CO-DEVELOPMENT AGREEMENT

This Co-Development Agreement ("Agreement"), made effective as of January 9, 2020 (the "Effective
Date"), is by and between PhaseBio Pharmaceuticals Inc., a Delaware corporation, with a principal
place of business at 1 Great Valley Parkway, Suite 30, Malvern, Pennsylvania 19355, USA ("PB"), and
SFJ Pharmaceuticals X, Ltd. ("SFJ"), an SFJ Pharmaceuticals Group company and corporation organized
and existing under the laws of the Cayman Islands, having its principal place of business at SIX,
2nd Floor, Cricket Square PO Box 2681, Grand Cayman, KY1-1111 Cayman Islands (each, a "Party" and
collectively, the "Parties").

WHEREAS, SFJ is in the business of facilitating, among other things, the development and approval of
pharmaceutical products and desires to provide financing and participate in conducting the Clinical
Trials for the development of the Product as a treatment of patients for the reversal of the effects
of the Ticagrelor Compound; and

WHEREAS, PB has rights to the Product, is conducting clinical trials of the Product in the United
States and the European Clinical Trial Countries, and would like to enter into an agreement with SFJ
to provide operational support for the conduct of clinical trials of the Product in the European
Clinical Trial Countries, to conduct clinical trials of the Product in the Designated Asian
Countries, and to provide global financing for the continued development of the Product.

NOW THEREFORE, in consideration of the mutual agreements contained herein and other good and
valuable consideration, the sufficiency of which is hereby acknowledged, the Parties agree as
follows:

ARTICLE 1

DEFINITIONS

1.1 Defined Terms. Initially capitalized terms will have the meaning ascribed to such terms in this
Agreement, including the following terms which will have the following respective meanings:

1.1.1 "Account" is any "account" as defined in the UCC with such additions as such term may
hereafter be made and includes, without limitation, all accounts receivable and other sums owing to
PB.

1.1.2 "Affiliate" means, with respect to a party, a business entity under common control with, or
controlling or controlled by, such party, with "control" meaning direct or indirect ownership of 50%
or more of the voting interest in such other entity, and in the case

Source: PHASEBIO PHARMACEUTICALS INC, 10-K, 3/30/2020
<!-- page 2 -->
of a partnership, control of the general partner. Notwithstanding the foregoing, neither The
Blackstone Group Inc. nor any of its divisions, including Blackstone Life Sciences, shall be deemed
to be an "Affiliate" of SFJ.

1.1.3 "Alliance Manager" has the meaning ascribed to such term in Section 5.1.5.

1.1.4 "Anti-Corruption Laws" means the U.S. Foreign Corrupt Practices Act, as amended, the UK
Bribery Act 2010, as amended, and any other applicable anti-corruption laws and laws for the
prevention of fraud, racketeering, money laundering or terrorism.

1.1.5 "Applicable Law" means the applicable laws, rules and regulations, including any rules,
regulations, guidelines, or other requirements of any Governmental Authorities (including any
Regulatory Authorities), to the extent legally binding, that may be in effect from time to time in
any country or regulatory jurisdiction of the Territory. For clarity, Applicable Laws will include
the FFDCA, the PHSA, the Anti-Corruption Laws, and all laws, regulations and legally binding
guidelines applicable to the Clinical Trials, including GCP, GLP, GMP and ICH guidelines.

1.1.6 "Approval Buy-Out Payment" has the meaning ascribed to such term in Section 6.7.1.

1.1.7 "Approval Payments" has the meaning ascribed to such term in Section 6.1.

1.1.8 "Approved CRO" has the meaning ascribed to such term in Section 2.4.1.

1.1.9 "Approved Third Party Vendor Costs" has the meaning ascribed to such term in Section
5.2.2.2(g).

1.1.10 "Approved Vendor" has the meaning ascribed to such term in Section 2.4.2.

1.1.11 "AstraZeneca Product" has the meaning ascribed to such term in the AZ License.

1.1.12 "AstraZeneca Product Improvements" has the meaning ascribed to such term in the AZ License.

1.1.13 "AstraZeneca Product Know-How" has the meaning ascribed to such term in the AZ License.

1.1.14 "AstraZeneca Product Patents" has the meaning ascribed to such term in the AZ License.

Source: PHASEBIO PHARMACEUTICALS INC, 10-K, 3/30/2020
<!-- page 3 -->
1.1.15 "AstraZeneca Product References" has the meaning ascribed to such term in the AZ License.

1.1.16 "AZ License" means the License Agreement between MedImmune and PB dated November 21, 2017, a
copy of which is attached hereto as Exhibit L, as amended by that certain First Amendment to License
Agreement dated January 9, 2020, a copy of which is attached hereto as Exhibit M.

1.1.17 "BLA" means: (a) a biologics license application submitted to the FDA pursuant to Section
351(a) of the PHSA and the regulations promulgated thereunder, or its successor application; or (b)
an application for authorization to market and/or sell a biological product in any country or
regulatory jurisdiction other than the US submitted to the applicable Regulatory Authority in such
country or regulatory jurisdiction, including, with respect to the EU, a marketing authorization
application submitted either (i) to the EMA pursuant to the centralized EU filing procedure or (ii)
to the applicable national Regulatory Authority in an individual EU member state if the centralized
EU filing procedure is not used.

1.1.18 "Brilinta Competing Product" means any P2Y12 receptor antagonist, other than the AstraZeneca
Product or Generic Ticagrelor Product.

1.1.19 "Business Day" means a day that is not a Saturday, Sunday or a US federal holiday.

1.1.20 "Buy-Out Payment" means an Approval Buy-Out Payment or a Change of Control Buy-Out Payment.

1.1.21 "Calendar Quarter" means each successive period of three (3) consecutive calendar months
ending on March 31, June 30, September 30 and December 31; provided, that, the (a) the first
Calendar Quarter shall begin on the Effective Date and end on the last day of the Calendar Quarter
in which the Effective Date falls, and (b) the final Calendar Quarter shall end on the last day of
the Term.

1.1.22 "Calendar Year" means each successive period of twelve (12) months commencing on January 1
and ending on December 31; provided, that, (a) the first Calendar Year shall begin on the Effective
Date and end on December 31 of the Calendar Year in which the Effective Date falls, and (b) the
final Calendar Year shall end on the last day of the Term.

1.1.23 "Case Report Form" or "CRF" means the collection of documents designed specifically for
recording data pursuant to the Protocol. A CRF is completed for each Subject and will be in
electronic form, validated and in compliance with all Applicable Laws.

1.1.24 "CFC" means a "controlled foreign corporation" as defined in the IRC.

1.1.25 "Change of Control" means, with respect to PB, at any time prior to the date of the payment
by PB of the final Approval Payment hereunder, (a) a merger, reorganization or consolidation with a
Third Party which results in the voting securities of PB outstanding

Source: PHASEBIO PHARMACEUTICALS INC, 10-K, 3/30/2020
<!-- page 4 -->
immediately prior thereto ceasing to represent, or being converted into or exchanged for voting
securities that do not represent, at least fifty percent (50%) of the combined voting power of the
voting securities of the surviving entity or the parent corporation of the surviving entity
immediately after such merger, reorganization or consolidation, (b) a transaction in which a Third
Party becomes the beneficial owner of fifty percent (50%) or more of the combined voting power of
the outstanding securities of PB, other than through the issuance of voting securities for the
purpose of raising financing to one or more financial or institutional investors that are not then
controlled by an entity engaged in the development or commercialization of pharmaceutical or
biotechnology products, or (c) the sale or other transfer of all or substantially all of PB's
business or assets relating to the Product for use in the Indication. A Licensing Transaction shall
not constitute a Change of Control, unless such Licensing Transaction includes the grant of US
Commercialization Rights in which event such Licensing Transaction shall be deemed to be a Change in
Control.

1.1.26 "Change of Control Buy-Out Payment" has the meaning ascribed to such term in Section 6.7.2.

1.1.27 "Claim" means any Third Party claim, demand, suit and/or cause of action.

1.1.28 "Clinical Investigator" means the principal investigator at each Site.

1.1.29 "Clinical Investigator Meeting" has the meaning ascribed to such term in Section 3.2.2.1.

1.1.30 "Clinical Supply Agreement" has the meaning ascribed to such term in Section 3.14.1.2.

1.1.31 "Clinical Supply Agreement" has the meaning ascribed to such term in Section 3.14.1.1.

1.1.32 "Clinical Trials" means the Phase 3 Trial, any required supplemental clinical trial of the
Product in China contemplated by the Development Plan, and the pharmacokinetic study of the Product
in Japanese Subjects contemplated by the Development Plan.

1.1.33 "Clinical Trial Activity" has the meaning ascribed to such term in Section 2.3.1.

1.1.34 "Clinical Trial Agreement" has the meaning ascribed to such term in Section 3.2.1.3.

1.1.35 "Clinical Trials Database" has the meaning ascribed to such term in Section 3.5.3.1.

1.1.36 "Clinical Trials Master File" has the meaning ascribed to such term in Section 3.5.4.

Source: PHASEBIO PHARMACEUTICALS INC, 10-K, 3/30/2020
<!-- page 5 -->
1.1.37 "CMC" means chemistry, manufacturing and controls.

1.1.38 "CMC Information" means the CMC information intended or required for the submission of an IND
or BLA.

1.1.39 "CMO" means contract manufacturing organization or contract development and manufacturing
organization.

1.1.40 "Commercial Launch" means, with respect to the Product and a country in the Territory, the
first sale to a Third Party of such Product in such country after (a) Regulatory Approval and (b) in
any country in which price approval is necessary or relevant for a majority of the population to
obtain access to pharmaceutical products, price approval for such Product in such country.

1.1.41 "Commercialization" or "Commercialize" means the commercial manufacture, marketing,
promotion, sale and/or distribution of the Product. For clarity, Commercialization excludes all
activities associated with development and seeking Regulatory Approval for the Product.

1.1.42 "Commercially Reasonable Efforts" means with respect to the performance of activities under
this Agreement by a Party (as pertains to its role in conducting the Clinical Trials): reasonable,
diligent, good-faith efforts to accomplish such objective which are consistent with industry
standards for companies of comparable size as that of such Party. "Commercially Reasonable Efforts"
requires, with respect to a particular task or activity in making, using, selling, offering for
sale, importing, exporting, developing (including seeking regulatory approvals or applicable pricing
or reimbursement approvals) or otherwise commercializing the Product, that a Party: (i) promptly
assign responsibility for such task or activity to specific employee(s) who are held accountable for
progress and monitor such progress on an on-going basis; (ii) set and consistently seek to achieve
specific and meaningful objectives for carrying out such task or activity; and (iii) make and
implement decisions and allocate resources designed to advance progress with respect to such
objectives in accordance with established timelines; provided, however, that, to the extent that the
performance of a Party's obligations hereunder is adversely affected by the other Party's breach in
performing its obligations hereunder, the impact on the first Party of such performance failure by
the other Party will be taken into account in determining whether the first Party has used its
Commercially Reasonable Efforts to perform any such affected obligations.

1.1.43 "Competing Product" means any agent intended to neutralize, abrogate or reverse the
antiplatelet activity of the Ticagrelor Compound.

1.1.44 "Completion Date" means, as to a particular Clinical Trial, the earlier of (a) the date of
final database lock for such Clinical Trial and (b) the date such Clinical Trial or this Agreement
is terminated.

1.1.45 "Confidential Information" of a Party means all information and materials provided and/or
disclosed (including in written form, electronic form or otherwise) by,

Source: PHASEBIO PHARMACEUTICALS INC, 10-K, 3/30/2020
<!-- page 6 -->
or on behalf of, such Party or its Affiliates, agents or representatives to the other Party, its
Affiliates, agents or representatives in connection with this Agreement, including, technical,
scientific, regulatory and other information, results, knowledge, techniques, data, analyses,
inventions, invention disclosures, plans, processes, methods, know-how, ideas, concepts, test data
(including pharmacological, toxicological and clinical test data), analytical and quality control
data, formulae, specifications, marketing, pricing, distribution, cost, sales, and manufacturing
data and descriptions. In addition, the terms and conditions of this Agreement shall be deemed to be
Confidential Information of both SFJ and PB. For further clarity, the terms of the AZ License shall
be considered the Confidential Information of PB, and SFJ acknowledges that the terms of the AZ
License are also considered "Confidential Information" (as defined in the AZ License) of MedImmune,
and that each of PB and MedImmune is deemed to be the "receiving Party" and the "disclosing Party"
with respect thereto for purposes of the AZ License. Notwithstanding the foregoing, any AstraZeneca
Product Know-How and any AstraZeneca Product Improvement shall be deemed to be the Confidential
Information of PB for purposes of this Agreement and of MedImmune for purposes of the AZ License,
and SFJ shall be deemed to be the receiving Party and PB shall be deemed to be the disclosing Party
with respect thereto for purposes of this Agreement (it being understood that MedImmune is deemed to
be the "receiving Party" and MedImmune is deemed to be the "disclosing Party" with respect thereto
for purposes of the AZ License). In addition, notwithstanding SFJ's ownership of the Research
Results prior to assignment thereof in accordance with Section 11.1.1.4, the Research Results shall
at all times be deemed to be Confidential Information of PB, and PB and SFJ shall be deemed the
disclosing Party and the receiving Party, respectively, with respect thereto.

1.1.46 "Contingent Liabilities" means, for any Person, (i) Indebtedness (as defined in Section
7.7.3) of that Person, and (ii) any direct or indirect liability, contingent or not, of that Person
for (a) warranty obligations, (b) potential claims for damages, (c) assessments, and (d) any other
condition, situation or set of circumstances involving various degrees of uncertainty that may
result in a loss or liability.

1.1.47 "Control" or "Controlled" means (a) for Intellectual Property, a Party's ability to grant
applicable licenses, sublicenses and/or other rights thereunder and (b) for materials and documents,
a Party's ability to provide, or provide access to, such materials and/or documents, each without
violating any contractual obligations to a Third Party. For clarity, if a Party only can grant a
license or sublicense and/or provide rights and/or access of limited scope, for a specific purpose
or under certain conditions due to an encumbrance, "Control" or "Controlled" will be construed to so
limit such license, sublicense, provision of rights and/or access.

1.1.48 "Copyrights" means, collectively, all works of authorship, mask works and any and all other
registered and unregistered copyrights and copyrightable works, and all applications, registrations,
extensions, and renewals thereof.

Source: PHASEBIO PHARMACEUTICALS INC, 10-K, 3/30/2020
<!-- page 7 -->
1.1.49 "Cover", "Covered" or "Covering" means, with respect to the applicable Intellectual Property,
in the absence of the applicable rights and licenses granted, would be infringed, misappropriated,
or otherwise violated by.

1.1.50 "CRO" means contract research organization.

1.1.51 "CRO Agreement" has the meaning ascribed to such term in Section 2.4.1.

1.1.52 "CSR" means, for with respect to a Clinical Trial, a clinical study report, or other
equivalent document or series of materials, constituting a summary report of the clinical and
medical data resulting from such Clinical Trial and prepared for incorporation into submissions
seeking Regulatory Approval for the Product, and includes all statistical analyses of such data per
the statistical analysis plan.

1.1.53 "Data Room" means that certain electronic data room established by PB and to which SFJ and/or
its advisors were granted access.

1.1.54 "Designated Asian Countries" means China, Japan, and Hong Kong.

1.1.55 "Designated European Countries" means [***].

1.1.56 "Development" has the meaning ascribed to such term in the AZ License.

1.1.57 "Development Costs" means all internal and external costs incurred or paid by SFJ or PB
associated with completing the Clinical Trials, including but not limited to all Approved Third
Party Vendor Costs, Product Supply Costs, the Initial Development Cost Payment, PB Costs, the SFJ
Interim Management Fee and, if applicable, the SFJ Final Management Fee.

1.1.58 "Development Plan" means a written plan for the Development Program, the initial version of
which is attached hereto as Exhibit D, and which will be subject to amendment by the JDC from time
to time during the Development Term.

1.1.59 "Development Program" means a CMC, clinical and regulatory development program to be
undertaken by the Parties to develop the Product for the Indication, carry out the Clinical Trials,
and seek Regulatory Approval for the Product.

1.1.60 "Development Term" means the period commencing on the Effective Date and ending on the later
of (a) the latest of the Completion Dates of the Clinical Trials, and (b) the date on which all
efforts in pursuit of Regulatory Approval of the Product for Indication have been concluded or
terminated.

1.1.61 "Disclosing Party" has the meaning ascribed to such term in Section 10.1.

Source: PHASEBIO PHARMACEUTICALS INC, 10-K, 3/30/2020
<!-- page 8 -->
1.1.62 "Dispute" has the meaning ascribed to such term in Section 15.10.

1.1.63 "Effective Date" has the meaning ascribed to such term in the Preamble.

1.1.64 "EMA" means the European Medicines Agency and any successor agency thereto in the EU having
substantially the same function.

1.1.65 "EU" means the European Union or any successor union of European states thereto having a
substantially similar function.

1.1.66 "European Clinical Trial Countries" means [***].

1.1.67 "Excluded Licensing Transaction" means (a) a license or sublicense granted to an academic
collaborator, service provider, contract research organization, contract manufacturer or similar
Third Party that does not grant to such Third Party any right to Commercialize the Product (other
than, in the case of a CMO, the right to commercially manufacture PB2452 or the Product on behalf of
PB or its Affiliates, without any other right to Commercialize the Product), or (b) a license or
sublicense not involving a grant of rights to the Product (by way of example and not of limitation,
a license or sublicense to develop and commercialize any product based on PB's proprietary ELP
technology, including PB1046 and PB1023).

1.1.68 "Exclusive Period" means, subject to the earlier termination of the AZ License, (a) in the
case of the conduct of human clinical trials with respect to a Competing Product, the period
beginning on the Effective Date and ending on November 21, 2022, and (b) in the case of the sale or
offer for sale of a Competing Product, the period beginning on the Effective Date and ending on
November 21, 2024.

1.1.69 "Exercise Price" has the meaning set forth in Section 8.1.

1.1.70 "Executive Officers" means the executive officers of each of PB and SFJ identified on Exhibit
E.

1.1.71 "Existing Licenses" means: (a) the License, Development and Commercialization Agreement dated
March 28, 2019, between PB and ImmunoForge Co., Ltd., including the ancillary agreements between
such parties entered into in connection therewith; and (b) the License Agreement dated April 13,
2018, between PB and [***], as amended.

1.1.72 "Existing PB Intellectual Property" has the meaning ascribed to such term in Section
11.1.1.1.

1.1.73 "Exploit" has the meaning ascribed to such term in the AZ License.

1.1.74 "FDA" means the US Food and Drug Administration and any successor agency thereto in the US
having substantially the same function.

Source: PHASEBIO PHARMACEUTICALS INC, 10-K, 3/30/2020
<!-- page 9 -->
1.1.75 "FFDCA" means the US Food, Drug, and Cosmetic Act, as amended from time to time, together
with any rules, regulations and requirements promulgated thereunder (including all additions,
supplements, extensions and modifications thereto).

1.1.76 "Financial Disclosure Form" has the meaning ascribed to such term in Section 3.2.1.4.

1.1.77 "GAAP" means generally accepted accounting principles in the US, as consistently applied by
the applicable Party.

1.1.78 "Generic Ticagrelor Product" means an oral formulation of the Ticagrelor Compound that is (a)
sold, offered for sale or distributed under: (i) in the U.S., an ANDA (as defined in the FFDCA) that
refers to the AstraZeneca Product as the reference listed drug, (ii) in the EU, a marketing
authorization for a generic medicinal product granted in accordance with Article 10 of Directive
2001/83/EC or (iii) in any other country or jurisdiction, an equivalent of provisions set forth in
clause (i) or clause (ii) and (b) approved in the applicable country or jurisdiction for at least
one of the indications for which the AstraZeneca Product is approved in such country or
jurisdiction. For purposes of this definition, references to AstraZeneca Product exclude Generic
Ticagrelor Products.

1.1.79 "GMP Manufacturer" means the Party that is responsible for ensuring that the Product is
manufactured in accordance with GMP.

1.1.80 "Going Concern Cure Period" has the meaning ascribed to such term in Section 3.18.3.

1.1.81 "Going Concern Funding" has the meaning ascribed to such term in Section 4.2.4.

1.1.82 "Going Concern Notice" has the meaning ascribed to such term in Section 3.18.3.

1.1.83 "Good Clinical Practices" or "GCP" means all applicable good clinical practice standards for
the design, conduct, performance, monitoring, auditing, recording, analyses and reporting of
clinical trials, including, as applicable, (a) the International Conference on Harmonisation of
Technical Requirements for Registration of Pharmaceuticals for Human Use ("ICH") Harmonised
Tripartite Guideline for Good Clinical Practice (CPMP/ICH/135/95) and any other guidelines for good
clinical practice for clinical trials on medicinal products; (b) the Declaration of Helsinki (2004)
as last amended at the 52nd World Medical Association in October 2000 and any further amendments or
clarifications thereto; and (c) the equivalent Applicable Laws in any relevant country, each as may
be amended and applicable from time to time and in each case, that provide for, among other things,
assurance that the clinical data and reported results are credible and accurate and protect the
rights, integrity, and confidentiality of clinical trial Subjects.

Source: PHASEBIO PHARMACEUTICALS INC, 10-K, 3/30/2020
<!-- page 10 -->
1.1.84 "Good Manufacturing Practices" or "GMP" means all applicable good manufacturing practices
including, as applicable, (a) the applicable part of quality assurance to ensure that products are
consistently produced and controlled in accordance with the quality standards appropriate for their
intended use, as defined in European Commission Directive 2003/94/EC laying down the principals and
guidelines of good manufacturing practice; (b) the principles detailed in the US Current Good
Manufacturing Practices, 21 CFR Sections 210, 211, 601 and 610; (c) the Rules Governing Medicinal
Product in the European Community, Volume IV Good Manufacturing Practice for Medicinal Product; (d)
the principles detailed in the ICH Q7A guidelines; and (e) the equivalent Applicable Laws in any
relevant country, each as may be amended and applicable from time to time.

1.1.85 "Government Official" is broadly defined as and includes: (a) any elected or appointed
government official (e.g., a member of a ministry of health); (b) any employee or person acting for
or on behalf of a government official, agency, or enterprise performing a governmental function; (c)
any non-US political party officer, employee, or person acting for or on behalf of a non-US
political party or candidate for public office; (d) any employee or person acting for or on behalf
of a public international organization; (e) all government employees and employees of state-owned
enterprises; or (f) any person otherwise categorized as a government official under local law; where
"government" is meant to include all levels and subdivisions of non-US governments (i.e., local,
regional, or national and administrative, legislative, or executive).

1.1.86 "Governmental Authority" means any supranational, federal, national, state or local court,
agency, authority, department, regulatory body or other governmental instrumentality.

1.1.87 "ICH" has the meaning ascribed to such term in Section 1.1.78.

1.1.88 "IDMC" means the independent data monitoring committee, which will be established pursuant to
Section 3.9.1.

1.1.89 "IDMC Charter" has the meaning ascribed to such term in Section 3.9.1.

1.1.90 "IND" means an investigational new drug application, clinical trial application, clinical
trial exemption, or similar application or submission filed with or submitted to a Regulatory
Authority in a jurisdiction that is necessary to initiate human clinical testing of a pharmaceutical
product in such jurisdiction, including any such application filed with the FDA pursuant to 21
C.F.R. Part 312.

1.1.91 "Indemnification Claim Notice" has the meaning ascribed to such term in Section 12.2.1.

1.1.92 "Indemnified Party" has the meaning ascribed to such term in Section 12.2.1.

Source: PHASEBIO PHARMACEUTICALS INC, 10-K, 3/30/2020
<!-- page 11 -->
1.1.93 "Indemnifying Party" has the meaning ascribed to such term in Section 12.2.1.

1.1.94 "Indication" means the reversal of the effects of the Ticagrelor Compound in Ticagrelor
Compound-treated in at least one of (i) patients with major bleeding or (ii) patients requiring
urgent surgery / invasive procedure.

1.1.95 "Information" means technical or scientific know-how, trade secrets, methods, processes,
formulae, designs, specifications and data, including biological, chemical, pharmacological,
toxicological, pre-clinical, clinical, safety, manufacturing and quality control data and assays; in
each case, whether or not confidential, proprietary, patented or patentable.

1.1.96 "Informed Consent" has the meaning ascribed to such term in Section 3.3.2.1.

1.1.97 "Initial Development Cost Payment" has the meaning ascribed to such term in Section 4.2.2(i).

1.1.98 "Initial EU Payment" has the meaning ascribed to such term in Section 6.1.

1.1.99 "Initial Funding Date" has the meaning ascribed to such term in Section 4.2.2(i).

1.1.100 "Initial US Payment" has the meaning ascribed to such term in Section 6.1.

1.1.101 "Intellectual Property" means all intellectual property and industrial property rights of
any kind or nature throughout the world, including all US and foreign, (a) Patents; (b) Trademarks;
(c) Copyrights; (d) rights in computer programs (whether in source code, object code, or other
form), algorithms, databases, compilations and data, technology supporting the foregoing, and all
documentation, including user manuals and training materials, related to any of the foregoing; (e)
trade secrets and all other confidential information, know-how, inventions, proprietary processes,
formulae, models, and methodologies; (f) rights of publicity, privacy, and rights to personal
information; (g) all rights in the foregoing and in other similar intangible assets; and (h) all
applications and registrations for the foregoing.

1.1.102 "Interim Period" has the meaning ascribed to such term in Section 4.2.2.

1.1.103 "Investigator's Brochure" means the written document containing a brief description of the
drug substance and formulation of the Product, a summary of the pharmacological and toxicological
effects of the Product in animals and human nonclinical models, a summary of the pharmacokinetics
and biological disposition of the Product in animals and humans, a summary of information relating
to safety and effectiveness of the Product in humans obtained from prior clinical studies, and a
description of possible risks and side effects to

Source: PHASEBIO PHARMACEUTICALS INC, 10-K, 3/30/2020
<!-- page 12 -->
be anticipated on the basis of prior experience with the Product under investigation or with related
drugs.

1.1.104 "IRB" means institutional review board, or its equivalent.

1.1.105 "IRC" means the Internal Revenue Code of 1986, as amended, and the Treasury Regulations
adopted thereunder.

1.1.106 "JCC" has the meaning ascribed to such term in Section 5.5.1.

1.1.107 "JDC" has the meaning ascribed to such term in Section 5.4.1.

1.1.108 "JDC Chairperson" has the meaning ascribed to such term in Section 5.4.2.

1.1.109 "JDC Representative(s)" has the meaning ascribed to such term in Section 5.4.1.

1.1.110 "JSC" has the meaning ascribed to such term in Section 5.1.1

1.1.111 "JSC Chairperson" has the meaning ascribed to such term in Section 5.1.2.

1.1.112 "JSC Representative(s)" has the meaning ascribed to such term in Section 5.1.1.

1.1.113 "Licensed Compound" has the meaning ascribed to such term in the AZ License.

1.1.114 "Licensed Know-How" has the meaning ascribed to such term in the AZ License.

1.1.115 "Licensed Patents" has the meaning ascribed to such term in the AZ License.

1.1.116 "Licensed Product" has the meaning ascribed to such term in the AZ License.

1.1.117 "Licensing Transaction" means: (a) a license or sublicense to a Third Party under any of the
PB Intellectual Property to Commercialize the Product in the US, Designated European Countries, or
Designated Asian Countries (other than, in the case of a Third Party CMO, a license or sublicense to
commercially manufacture PB2452 or the Product on behalf of PB or its Affiliates, without any
license or sublicense to engage in any other Commercialization activities with respect to the
Product); or (b) a sale or transfer to a Third Party of any of the PB Intellectual Property, in each
case, other than in conjunction with a permitted assignment of this Agreement pursuant to Section
15.6 in connection with the sale or other transfer of all or substantially all of its business or
assets to which this Agreement relates.

Source: PHASEBIO PHARMACEUTICALS INC, 10-K, 3/30/2020
<!-- page 13 -->
For clarity, an assignment of the AZ License to a Third Party in conjunction with a permitted
assignment by PB of this Agreement pursuant to Section 15.6 in connection with the sale or other
transfer of all or substantially all of its business or assets to which this Agreement relates shall
not be deemed a Licensing Transaction.

1.1.118 "Licensing Transaction Agreement" means a definitive agreement for a Licensing Transaction
between PB and a Third Party.

1.1.119 "Losses" means liabilities, losses, costs, damages, fees and/or expenses (including
reasonable legal expenses and attorneys' fees) payable to a Third Party.

1.1.120 "Manufacturer" means the company set forth on Exhibit J.

1.1.121 "Material Adverse Event" means (i) an event occurring after the Effective Date that has a
material adverse effect on (a) the business, operations, prospects or financial condition of PB, (b)
prospect of payment of the Approval Payments by PB, or (c) the development of the Product for the
Indication or prospects for Regulatory Approval of the Product for the Indication (it being
understood that if the interim results of the Phase 3 Trial do not demonstrate Successful Phase 3
Interim Analysis, it shall be deemed to be a Material Adverse Event), or (ii) if PB has not obtained
the SVB Consent within [***] of the Effective Date, or (iii) if PB is in default of its obligations
under the AZ License (excluding any such default that would not entitle AZ to terminate the AZ
License); provided however, that none of the following shall constitute, or shall be considered in
determining whether there has occurred, a Material Adverse Event: (A) changes in laws or regulations
or in the interpretations or methods of enforcement thereof; (B) changes in the pharmaceutical or
biotechnology industries in general; or (C) any earthquakes, hurricanes, tsunamis, tornadoes,
floods, mudslides, wildfires or other natural disasters, weather conditions, sabotage, terrorism,
military action or war (whether or not declared) or other force majeure events in the US or any
other country or region in the world.

1.1.122 "Material Anti-Corruption Law Violation" means a violation by a Party or its Affiliate of an
Anti- Corruption Law relating to the subject matter of this Agreement that would, if it were
publicly known, have a material adverse effect on the other Party or its Affiliate because of its
relationship with such Party.

1.1.123 "Maximum Development Costs" has the meaning ascribed to such term in Section 4.1.

1.1.124 "MedImmune" means MedImmune Limited, a limited liability company formed under the laws of
the United Kingdom.

1.1.125 "MedImmune Confidential Information" means (a) the terms of the AZ License; and (b) any
AstraZeneca Product Know-How and any AstraZeneca Product Improvement.

1.1.126 "MedImmune Pharmacovigilance Agreement" has the meaning ascribed to the term
"Pharmacovigilance Agreement" in the AZ License.

Source: PHASEBIO PHARMACEUTICALS INC, 10-K, 3/30/2020
<!-- page 14 -->
1.1.127 "NMPA" means China's National Medical Products Administration or any successor agency
thereto in China having substantially the same function.

1.1.128 "Participation Rights" means with respect to a Party, such Party's Chief Executive Officer
and Chief Medical Officer (or their respective designees) shall be entitled to participate on a
silent basis in all meetings with Regulatory Authorities during the Development Term and to the
extent practicable such Party shall be entitled to review pre-meeting briefing materials. The other
Party shall provide such Party with copies of the minutes of all of the aforementioned meetings
within [***] after receipt of the final minutes from the applicable Regulatory Authority.

1.1.129 "Party" or "Parties" has the meaning ascribed to such term in the Preamble.

1.1.130 "Patent" will mean patents, patent applications, patent disclosures, and all related
continuations, continuations-in-part, divisionals, reissues, re-examinations, substitutions, and
extensions thereof.

1.1.131 "PB" has the meaning ascribed to such term in the Preamble.

1.1.132 "PB2452" means the anti-ticagrelor antibody fragment product known as PB2452 (and referred
to in the AZ License as "MEDI2452"), as further defined by the protein sequence set forth in
Schedule 1.96 to the AZ License.

1.1.133 "PB Confidential Information" means all Confidential Information provided and/or disclosed
by or on behalf of PB or its Affiliates, agents or representatives to SFJ or its Affiliates, agents
or representatives hereunder. For clarity, PB Confidential Information will include any and all CMC
Information.

1.1.134 "PB Costs" has the meaning ascribed to such term in Section 4.2.2(ii)(3).

1.1.135 "PB Financial Statements" has the meaning ascribed to such term in Section 3.18.2.

1.1.136 "PB Indemnified Parties" has the meaning ascribed to such term in Section 12.1.1.

1.1.137 "PB Intellectual Property" means all Intellectual Property owned or Controlled by PB that is
necessary or useful for the manufacture, use, sale or import of the Product, including Trial
Inventions.

1.1.138 "PB Services" means performing or managing all CMC related activities (including supply of
Product for use in the Clinical Trials) and oversight of the Phase 3 Trial in the US and the
European Clinical Trial Countries.

1.1.139 "PB SOPs" has the meaning ascribed to such term in Section 3.1.6.

Source: PHASEBIO PHARMACEUTICALS INC, 10-K, 3/30/2020
<!-- page 15 -->
1.1.140 "PB Territory" means the US and the European Clinical Trial Countries.

1.1.141 "Permitted Third Party" means any CRO, Site, Clinical Investigator and/or Vendor to whom PB
or SFJ has delegated responsibility or whom PB or SFJ has engaged in connection with the Clinical
Trials or any CMO whom PB has engaged to perform CMC related activities (including supply of Product
for use in the Clinical Trials). For clarity, Third Parties that have been delegated responsibility
by or engaged by a Permitted Third Party will be considered Permitted Third Parties.

1.1.142 "Person" means any individual, corporation, general or limited partnership, limited
liability company, joint venture, estate, trust, association, organization, labor union, or other
entity or Governmental Authority.

1.1.143 "Personally Identifiable Information" means any information relating to an identified or, in
combination with other information, identifiable person or persons captured in an electronic or
hardcopy format, including such information as it relates to clinical trials subjects (including
key-coded patient data), physicians, clinicians, healthcare professionals, consultants, or other
persons participating in the Clinical Trials, and any equivalent definition in the Applicable Laws
to the extent that such definition is broader than that provided here.

1.1.144 "Phase 3 Interim Data" means the data collected from the Phase 3 Trial as of database lock
for the interim analysis of the Phase 3 Trial expressly contemplated by the Phase 3 Trial Protocol.

1.1.145 "Phase 3 Success Criteria" shall mean that the results of the Phase 3 Trial meet at least
one of the two primary endpoints set forth in the Phase 3 Trial Protocol.

1.1.146 "Phase 3 Trial" means the clinical trial of the Product described in PhaseBio Protocol
Number PB‑CL‑004, entitled "A Phase 3, multicenter, open-label, single arm study of PB2452 in
Ticagrelor-treated patients with major bleeding or requiring urgent surgery / invasive procedure,"
as such protocol may be amended from time to time in accordance with this Agreement.

1.1.147 "Phase 3 Trial Protocol" has the meaning ascribed to such term in Section 2.1.1.

1.1.148 "PHSA" means the Public Health Service Act as set forth at 42 U.S.C. Chapter 6A, as may be
amended from time to time, together with any rules, regulations and requirements promulgated
thereunder (including all additions, supplements, extensions and modifications thereto).

1.1.149 "PK Studies" means the pharmacokinetic study of the Product in Japanese Subjects
contemplated by the Development Plan, any pharmacokinetic study of the Product in Chinese Subjects
contemplated by the Development Plan, and any other pharmacokinetic study of the Product in Japanese
Subjects or Chinese Subjects that may be

Source: PHASEBIO PHARMACEUTICALS INC, 10-K, 3/30/2020
<!-- page 16 -->
required by the PMDA or NMPA, as applicable. PK Studies shall not include any clinical trial of the
Product with any efficacy endpoint.

1.1.150 "PMDA" means the Pharmaceuticals and Medical Devices Agency of Japan or any successor agency
thereto in Japan having substantially the same function.

1.1.151 "Pre-Approval Commercialization Activities" has the meaning ascribed to such term in Section
4.3.

1.1.152 "Product" means the product containing PB2452 described on Exhibit A.

1.1.153 "Product Filings" has the meaning ascribed to such term in Section 3.1.2.

1.1.154 "Product Supply Costs" has the meaning ascribed to such term in Section 3.14.1.2.

1.1.155 "Program Transfer" has the meaning ascribed to such term in the form of Program Transfer
Agreement attached hereto as Exhibit O.

1.1.156 "Program Transfer Agreement" has the meaning ascribed to such term in Section 3.20.

1.1.157 "Protocol" means the Phase 3 Trial Protocol or an SFJ Territory Clinical Trial Protocol.

1.1.158 "Receiving Party" has the meaning ascribed to such term in Section 10.1.

1.1.159 "Regulatory Approval" means conditional or unconditional approval of a BLA for the Product
for the Indication: (a) by the FDA in the US; (b) by EMA in the EU or by the applicable national
Regulatory Authority in any individual Designated European Country; (c) by the PMDA in Japan; or (d)
by the NMPA in China. For clarity, "Regulatory Approval" excludes any pricing or reimbursement
approval that may be necessary or useful for marketing or sale of the Product in any country or
regulatory jurisdiction. For further clarity, the Parties acknowledge that, as of the Effective
Date, PB intends to file a BLA with EMA using the centralized EU filing procedure to seek Regulatory
Approval in the EU, and PB neither intends, nor has any obligation under this Agreement, to submit
any BLA to, or seek Regulatory Approval from, the applicable national Regulatory Authority in any
individual Designated European Country.

1.1.160 "Regulatory Authority" means in a particular country or regulatory jurisdiction in the
Territory, any applicable Governmental Authority involved in granting approval to initiate or
conduct clinical testing in humans, for Regulatory Approval, including FDA, EMA, PMDA, and NMPA.

Source: PHASEBIO PHARMACEUTICALS INC, 10-K, 3/30/2020
<!-- page 17 -->
1.1.161 "Regulatory Documentation" has the meaning ascribed to such term in the AZ License.

1.1.162 "Research Results" means all Information arising out of, or resulting from, the Clinical
Trials and/or the CMC activities contemplated by the Development Program, including the Clinical
Trials Database; but excluding AstraZeneca Product Improvements, AstraZeneca Product Know-How,
AstraZeneca Product Patents, and Trial Inventions (including Intellectual Property in or to Trial
Inventions).

1.1.163 "Serious Safety Issue" means any SUSAR or series of SUSARs directly related to or caused by
the administration of the Product in the conduct of the Clinical Trials where such SUSAR or series
of SUSARs substantially diminishes the probability of receiving Regulatory Approval for the Product,
or results in a Regulatory Authority imposing a clinical hold on further development of the Product
which clinical hold is not lifted or removed within [***].

1.1.164 "SFJ" has the meaning ascribed to such term in the Preamble.

1.1.165 "SFJ Confidential Information" means all Confidential Information provided and/or disclosed
by, or on behalf of, SFJ or its Affiliates, agents or representatives to PB or its Affiliates,
agents or representatives hereunder.

1.1.166 "SFJ Final Management Fee" has the meaning ascribed to such term in Section 4.2.3(i).

1.1.167 "SFJ Indemnified Parties" has the meaning ascribed to such term in Section 12.1.2.

1.1.168 "SFJ Interim Management Fee" has the meaning ascribed to such term in Section 4.2.2(ii)(2).

1.1.169 "SFJ Services" means providing global oversight of the CRO and other Third Party Vendors and
execution of the Clinical Trials in European Clinical Trial Countries, Japan, and China.

1.1.170 "SFJ SOPs" has the meaning ascribed to such term in Section 3.1.5.

1.1.171 "SFJ Territory" means the Designated Asian Countries.

1.1.172 "SFJ Territory Clinical Trial Protocol" has the meaning ascribed to such term in Section
2.1.1.

1.1.173 "Site" has the meaning ascribed to such term in Section 3.2.1.3.

1.1.174 "SOPs" means the PB SOPs or SFJ SOPs.

Source: PHASEBIO PHARMACEUTICALS INC, 10-K, 3/30/2020
<!-- page 18 -->
1.1.175 "Statistical Analysis Plan" has the meaning ascribed to such term in Section 3.5.6.

1.1.176 "Subject" has the meaning ascribed to such term in Section 3.3.2.1.

1.1.177 "Subject Recruitment Plan" has the meaning ascribed to such term in Section 3.3.1.

1.1.178 "Successful Phase 3 Interim Analysis" means that the interim results of the Phase 3 Trial
meet the interim primary endpoint set forth in the Phase 3 Trial Protocol.

1.1.179 "SUSAR" means a suspected unexpected serious adverse reaction, without regard to causality,
that is life- threatening (i.e., causes an immediate risk of death) or that results in any of the
following outcomes: death; in-patient hospitalization or prolongation of existing hospitalization;
persistent or significant disability or incapacity (i.e., substantial disruption of the ability to
conduct normal life functions); or a congenital anomaly or birth defect. For clarity, a planned
medical or surgical procedure is not, in itself, a SUSAR.

1.1.180 "SVB" means, subject to Section 7.4, Silicon Valley Bank, a California corporation.

1.1.181 "SVB Consent" has the meaning ascribed to such term in Section 7.6.1.2.

1.1.182 "SVB Collateral" means, subject to Section 7.4, "Collateral" as defined in the SVB Loan
Agreement.

1.1.183 "SVB Loan" means, subject to Section 7.4, the $15,000,000 term loan evidenced by the SVB
Loan Agreement.

1.1.184 "SVB Loan Agreement" means, subject to Section 7.4, that certain Loan and Security Agreement
dated as of March 25, 2019 among SVB, WestRiver Innovation Lending Fund VIII, L.P., and PB, as
amended, restated, or otherwise modified from time to time.

1.1.185 "Term" has the meaning ascribed to such term in Section 14.1.

1.1.186 "Territory" of a Party means: (a) in the case of PB, the PB Territory; or (b) in the case of
SFJ, the SFJ Territory.

1.1.187 "Third Party" means any Person other than PB, SFJ and their Affiliates.

1.1.188 "Third Party Infringement" means any actual or threatened infringement, misappropriation, or
other violation by a Third Party of any Intellectual Property Controlled by PB that relates to this
Agreement and/or the Product, including the Trial Inventions.

Source: PHASEBIO PHARMACEUTICALS INC, 10-K, 3/30/2020
<!-- page 19 -->
1.1.189 "Ticagrelor Compound" means (1S,2S,3R,5S)-3-[7-{[(1R,2S)-2-(3,4-
difluorophenyl)cyclopropyl]amino}-5-(propylthio)-3H-[1,2,3]-triazolo[4,5-d]pyrimidin-3-yl]-5-(2-hydroxyethoxy)cyclopentane-
1,2-diol.

1.1.190 "Timeline" has the meaning ascribed to such term in Section 2.3.1.

1.1.191 "Timeline Remediation Plan" has the meaning ascribed to such term in Section 2.3.2.

1.1.192 "Trademarks" means, collectively, all registered and unregistered marks, trade dress rights,
logos, taglines, slogans, Internet domain names, web addresses, and other indicia of origin,
together with the goodwill associated with any of the foregoing, and all applications,
registrations, extensions and renewals thereof, selected for use on the Product.

1.1.193 "Trial Data Package" means all Information, in any form, generated or developed by or on
behalf of a Party or any of its Affiliates (including by any of their respective Permitted Third
Parties) in the conduct of the Clinical Trials during the Development Term, including the Clinical
Trial Database and other data and reports arising out of the Clinical Trials, any Clinical Trial
Agreements or any Vendor Agreements or CRO Agreements related to the conduct of the Clinical Trials,
including the Research Results; but, in each case, excluding Trial Inventions.

1.1.194 "Trial Invention" means: (a) any invention or discovery, whether or not patentable, made,
developed, generated, conceived, or reduced to practice by or on behalf of a Party or any of its
Affiliates or Permitted Third Parties, or jointly by or on behalf of the Parties or any of their
respective Affiliates or Permitted Third Parties, in the course or as a result of the conduct of any
Clinical Trial or any other activity conducted pursuant to this Agreement, including, without
limitation, any improvement to any Existing PB Intellectual Property; and (b) all Intellectual
Property in any of the items described in the preceding clause (a); but excluding, in each case,
AstraZeneca Product Improvements, AstraZeneca Product Know-How and AstraZeneca Product Patents.

1.1.195 "UCC" means the Uniform Commercial Code, as the same may, from time to time, be enacted and
in effect in the State of Delaware; provided, that, to the extent that the UCC is used to define any
term herein and such term is defined differently in different Articles or Divisions of the UCC, the
definition of such term contained in Article or Division 9 shall govern; and provided further, that
in the event that, by reason of mandatory provisions of law, any or all of the attachment,
perfection or priority of, or remedies with respect to, the SFJ Security Interest on any SFJ
Collateral is governed by the Uniform Commercial Code in effect in a jurisdiction other than the
State of Delaware, the term "UCC" shall mean the Uniform Commercial Code as enacted and in effect in
such other jurisdiction solely for purposes of the provisions thereof relating to such attachment,
perfection, priority or remedies and for purposes of definitions relating to such provisions.

1.1.196 "US", "U.S." or "USA" means the United States of America, its territories and possessions,
including Puerto Rico.

Source: PHASEBIO PHARMACEUTICALS INC, 10-K, 3/30/2020
<!-- page 20 -->
1.1.197 "US Approval Payments" has the meaning ascribed to such term in Section 6.1.

1.1.198 "US Commercialization Rights" shall mean any license or grant of other rights exclusive or
non-exclusive to Commercialize the Product for the Indication in the US (other than a license or
grant of other rights to a CMO to commercially manufacture PB2452 or the Product on behalf of PB or
its Affiliates, without any license or grant of other rights to engage in any other
Commercialization activities with respect to the Product).

1.1.199 "VAD" means the value added data set, including the data in the format as described in the
Statistical Analysis Plan.

1.1.200 "Vendor(s)" has the meaning ascribed to such term in Section 2.4.2.

1.1.201 "Vendor Agreement" has the meaning ascribed to such term in Section 2.4.2.

1.2 Construction. For purposes of this Agreement: (1) words in the singular will be held to include
the plural and vice versa as the context requires; (2) the words "including" and "include" will mean
"including, without limitation," unless otherwise specified; (3) the terms "hereof," "herein,"
"herewith," and "hereunder," and words of similar import will, unless otherwise stated, be construed
to refer to this Agreement as a whole and not to any particular provision of this Agreement; and (4)
all references to "Section" and "Exhibit," unless otherwise specified, are intended to refer to a
Section or Exhibit of or to this Agreement.

1.3 Conflicts. In the event of any conflict between the terms of this Agreement, the Protocol and/or
any other Exhibit, the Protocol will control (as applicable), followed by the terms of this
Agreement, and followed by any applicable other Exhibit.

ARTICLE 2

THE CLINICAL TRIALS

2.1 The Protocols.

2.1.1 The Protocols. The protocol for the Phase 3 Trial (the "Phase 3 Trial Protocol") as it exists
on the Effective Date has separately been mutually agreed upon by the Parties in writing. The
protocol for each Clinical Trial (other than the Phase 3 Trial) of the Product to be conducted in
the SFJ Territory (each, an "SFJ Territory Clinical Trial Protocol") will be prepared by SFJ in
consultation with PhaseBio and approved by the JDC within [***].

2.1.2 Changes to the Protocols.

2.1.2.1 Any changes to the Phase 3 Trial Protocol, including any country-specific appendices
required by Applicable Law and changes made in response to any communications with any Regulatory
Authorities, that require a submission to a Regulatory Authority, an IRB or other ethics committee,
will be prepared by PB, with support from SFJ, and

Source: PHASEBIO PHARMACEUTICALS INC, 10-K, 3/30/2020
<!-- page 21 -->
will require the JDC's approval, which will not be unreasonably withheld or delayed and which will
be communicated to the Parties as soon as reasonably practicable following the JDC's receipt of the
draft amendment from PB. Any changes to an SFJ Territory Clinical Trial Protocol, including changes
made in response to any communications with a Regulatory Authority, an IRB or other ethics committee
in the SFJ Territory, will be prepared by SFJ, with support from PB, and will require the JDC's
approval, which will not be unreasonably withheld or delayed and which will be communicated to the
Parties as soon as reasonably practicable following the JDC's receipt of the draft amendment from
SFJ.

2.1.2.2 If either Party believes that a Protocol requires amendment to comply with any Applicable
Laws or based on any communications from any Regulatory Authorities, such Party will inform the JDC.
If the JDC agrees that such an amendment is required by any Applicable Laws the JDC will provide the
applicable Party (PB in the case of the Phase 3 Trial or SFJ in the case of any other Clinical
Trial) with written notice thereof as soon as reasonably practicable, and such Party, with support
from the other Party, will prepare a draft amendment to such Protocol, which will only be effective
and part of such Protocol upon approval by the JDC pursuant to Section 5.2.2, which approval will
not be unreasonably withheld and which will be communicated to the Parties as soon as reasonably
practicable following the JDC's receipt of the draft amendment from such Party.

2.1.3 Protocol Approval. SFJ will be responsible for obtaining all necessary approvals of each
Protocol (including as required by Applicable Laws) within the SFJ Territory, and PB will be
responsible for obtaining all necessary approvals of the Phase 3 Trial Protocol (including as
required by Applicable Laws) within the PB Territory, in each case prior to commencing the
applicable Clinical Trial in such Party's Territory. Each Party will reasonably co-operate with the
other in such regard.

2.2 Sponsor.

2.2.1 Sponsorship and Responsibilities. PB will be the sponsor of the Clinical Trials in the PB
Territory. SFJ will be the sponsor of the Clinical Trials in the SFJ Territory. SFJ in the SFJ
Territory, and PB in the PB Territory, will have all responsibilities of a sponsor as specified in
Applicable Laws, except, in the case of the Phase 3 Trial in the European Clinical Trial Countries,
that SFJ shall perform certain activities that are PB's responsibilities as sponsor as set forth in
Exhibit G.

2.2.2 Compliance with the Protocol and Applicable Laws. Each Party will conduct the Phase 3 Trial
within its Territory, and SFJ will conduct each other Clinical Trial in the SFJ Territory, and
perform all other responsibilities assigned to it hereunder in connection with any such Clinical
Trial in compliance with the applicable Protocol, all Applicable Laws and the terms hereof.

2.2.3 Diligence. Each Party will conduct due diligence with respect to each Permitted Third Party
used by such Party to ensure that such Permitted Third Party can comply with all applicable terms
and obligations of this Agreement and Applicable Laws.

Source: PHASEBIO PHARMACEUTICALS INC, 10-K, 3/30/2020
<!-- page 22 -->
2.3 Compliance with the Timeline.

2.3.1 The Timeline. The timeline for conducting the Clinical Trials is attached as Exhibit I hereto
(the "Timeline"). In conducting the Clinical Trials, the Parties will use Commercially Reasonable
Efforts to complete each activity specified on the Timeline (each, a "Clinical Trial Activity") by
the date specified for such Clinical Trial Activity on the Timeline. The Parties will notify the JDC
in writing upon completion or achievement of each of their designated Clinical Trial Activities.

2.3.2 Failure to Complete a Clinical Trial Activity. If a Party fails to, or knows that it will not,
complete a Clinical Trial Activity in accordance with the timeline specified for such Clinical Trial
Activity on the Timeline, that Party will promptly notify the JDC. Within [***] of such written
notice, if the Party has failed to, or knows that it will not, complete (a) any Clinical Trial
Activity within [***] of the date for the Clinical Trial Activity on the Timeline or (b) the final
Clinical Trial Activity within [***] of the date for the final Clinical Trial Activity on the
Timeline, the Party will provide the JDC with a written remediation plan detailing the means by
which, and the date on which, that Party expects to be able to complete the relevant Clinical Trial
Activities (each, a "Timeline Remediation Plan"). Following receipt thereof, the JDC Representatives
will discuss and consider in good faith such Timeline Remediation Plan. If the JDC approves such
Timeline Remediation Plan (such approval not to be unreasonably withheld or delayed), the JDC will
provide the appropriate Party with written notice thereof, specifying the dates on which the Party
will be required to update the JDC of its progress with respect thereto. If the JDC is unable to
approve such Timeline Remediation Plan, the matter will be decided by the JSC in accordance with
Section 5.2. After approval of a Party's Timeline Remediation Plan, if such Party believes in good
faith that any modification to such Timeline Remediation Plan is necessary or appropriate, such
Party may propose such modification to the JDC and shall disclose to the JDC any additional
information or circumstances that have become known to such Party that form the basis for its
request for modification. The JDC will discuss and consider such in good faith such modification,
which shall be subject to JDC approval (such approval not to be unreasonably withheld or delayed) as
described above.

2.3.3 Failure to Complete a Timeline Remediation Plan. If PB fails to complete a Clinical Trial
Activity it is responsible for as outlined in an approved Timeline Remediation Plan, then SFJ has
the right to withhold any quarterly fixed payments due to PB pursuant to Section 4.2 until the
Clinical Trial Activity is completed, in which event SFJ will not be considered in breach of this
Agreement for withholding any such amounts any amounts due to PB pursuant to this Section 2.3.3. If
either Party fails to complete a Clinical Trial Activity it is responsible for as outlined in an
approved Timeline Remediation Plan, then the other Party, at its sole discretion, may assume
responsibility for completing such Clinical Trial Activity, in which event:

2.3.3.1 in the case of SFJ's assumption of responsibility for completing a Clinical Trial Activity
that was to have been performed by PB, (a) the costs incurred by SFJ in completing such Clinical
Trial Activity shall be included as Development Costs hereunder and

Source: PHASEBIO PHARMACEUTICALS INC, 10-K, 3/30/2020
<!-- page 23 -->
(b) in no event shall any failure or delay by SFJ in performing any of its obligations hereunder
that are dependent upon the completion of such Clinical Trial Activity constitute a breach of this
Agreement or entitle PB to terminate this Agreement or exercise any remedy available to it under
this Agreement; and

2.3.3.2 in the case of PB's assumption of responsibility for completing a Clinical Trial Activity
that was to have been performed by SFJ, (a) an amount equal to the costs incurred by PB in
completing such Clinical Activity shall be deducted (i) first from the SFJ Interim Management Fee
until the SFJ Interim Management Fee is reduced to zero, and (ii) thereafter from the SFJ Final
Management Fee, and (b) in no event will any such costs incurred by PB be included in actual
Development Costs for purposes of Section 14.2, and (c) in no event shall any failure or delay by PB
in performing any of its obligations hereunder that are dependent upon the completion of such
Clinical Trial Activity constitute a breach of this Agreement or a Material Adverse Event, or
entitle SFJ (i) to withhold any quarterly fixed payments due to PB or other amounts SFJ is obligated
to pay or incur pursuant to Section 4.2, (ii) to terminate this Agreement or (iii) to exercise any
other remedy available to it under this Agreement, including the remedy set forth in Section 3.20.

2.4 Approved CROs and Approved Vendors.

2.4.1 Approved CROs. Except as otherwise provided herein, a Party may delegate any of its
responsibilities described in Section 2.2 to its Affiliates (subject to Section 15.1) and/or any CRO
that is either listed on Exhibit B or is approved in advance by the JDC (in either case, an
"Approved CRO"). Each Party will be required to enter into a written agreement with each Approved
CRO utilized by such Party (each, a "CRO Agreement") on commercially reasonable and customary terms,
consistent with industry standards for similar agreements and sufficient to enable such Party to
comply with its obligations hereunder with respect to the delegated responsibilities, including, but
not limited to, Section 2.2.2, and the terms pertaining to ownership of Intellectual Property and
publications, and treatment of Confidential Information.

2.4.2 Approved Vendors. Each Party will be permitted to contract for services, equipment, tools,
materials and/or supplies required for the Clinical Trials or Regulatory Approval with any Person
that is either listed on Exhibit C or is approved in advance by the JDC (each, an "Approved
Vendor"). Such Party will be required to enter into a written agreement with each such Person (each,
a "Vendor Agreement") on commercially reasonable and customary terms, consistent with industry
standards for similar agreements and sufficient to enable such Party to comply with its obligations
hereunder with respect to the contracted activities, including, but not limited to, the terms
pertaining to publications and ownership of Intellectual Property, and treatment of Confidential
Information.

2.4.3 Responsibility. For clarity, each Party will remain responsible for all of its obligations
under this Agreement, notwithstanding any delegation to an Affiliate or an Approved CRO or any
contracting to an Approved Vendor. Each Party shall use Commercially Reasonable Efforts to oversee
the services of its Affiliates and any Approved CRO or Approved Vendor utilized by such Party to
provide services hereunder.

Source: PHASEBIO PHARMACEUTICALS INC, 10-K, 3/30/2020
<!-- page 24 -->
2.5 Background Materials and Reasonable Assistance.

2.5.1 Background Materials.

2.5.1.1 Promptly following the Effective Date, PB will provide SFJ with all copies of documents and
information Controlled by PB that SFJ, acting in good faith, identifies as reasonably necessary for
SFJ to perform its Development Program responsibilities hereunder (the "Background Materials"),
except to the extent the provision of any such documents is otherwise provided for in this
Agreement. For clarity, PB will remain the sole owner of, and will retain all right, title and
interest in, to and under all Background Materials, including all Intellectual Property thereto, and
the Background Materials will be PB Confidential Information.

2.5.1.2 If, during the Development Term, any additional documents and/or information that PB
Controls are reasonably necessary for the performance of SFJ's Development Program responsibilities,
SFJ may request such documents and/or information (with reasonable specificity) from PB, and PB will
provide such documents and/or information as reasonably necessary to SFJ (and such documents will be
deemed Background Materials).

2.5.2 Questions Pertaining to the Phase 3 Trial Protocol. Promptly following the Effective Date
during the Development Term, PB will identify one (1) individual with knowledge of the Phase 3 Trial
Protocol and the Product who will be made available at reasonable times during normal business hours
in such employee's country of residence upon reasonable advance notice to answer SFJ's questions
directly pertaining to such Protocol.

ARTICLE 3

CLINICAL TRIALS ACTIVITIES, REGULATORY APPROVAL AND RESPONSIBILITIES

3.1 Parties' Roles and Responsibilities.

3.1.1 PB Responsibilities. PB will have primary responsibility for conducting the Phase 3 Trial in
the US and the European Clinical Trial Countries, provided that SFJ will provide operational support
for and assist with the conduct of the Phase 3 Trial in the European Clinical Trial Countries as
specified on Exhibit G and will enter into Clinical Trial Agreements with Sites in the European
Clinical Trial Countries and CRO Agreements for the Phase 3 Trial in the European Clinical Trial
Countries. Except as expressly set forth in Section 3.1.2 with respect to the PK Studies, PB will
have sole responsibility for interactions with Regulatory Authorities in the US and the European
Clinical Trial Countries during the Development Term with SFJ to have Participation Rights.
Thereafter, if the Phase 3 Trial meets the Phase 3 Trial Success Criteria, PB will use Commercially
Reasonable Efforts to perform all activities associated with submitting BLAs and seeking Regulatory
Approval for the Indications in the US and the Designated European Countries.

Source: PHASEBIO PHARMACEUTICALS INC, 10-K, 3/30/2020
<!-- page 25 -->
3.1.2 SFJ Responsibilities. SFJ will have primary responsibility for conducting the Phase 3 Trial in
the Designated Asian Countries and sole responsibility for conducting the other Clinical Trials in
the Designated Asian Countries (provided that SFJ may elect not to conduct Clinical Trials in Hong
Kong). If SFJ elects to conduct any PK Study in Japanese Subjects in the US or Chinese Subjects in
the US, PB shall, with SFJ's assistance and cooperation, file an appropriate amendment to the US IND
for the Product with the protocol for such PK Study, and SFJ may conduct such PK Study in the
applicable Subjects in the US in accordance with such protocol. In connection with any Japanese or
Chinese PK Study during the Development Term, (i) SFJ will have sole responsibility for interactions
with Regulatory Authorities in Japan and China, with PB to have Participation Rights, and (ii) PB,
as the sponsor of the US IND for the Product, will have primary formal responsibility for
interactions with the FDA regarding any PK Study conducted in Japanese Subjects or Chinese Subjects
(as applicable) in the US, with SFJ to have Participation Rights, but, as between PB and SFJ (but
not vis-à-vis the FDA), SFJ shall, in consultation with PB, determine the strategy for such
interactions, and, except to the extent contrary to Applicable Law or in violation of PB's duties as
the sponsor of such US IND, PB's interactions with the FDA shall at all times be consistent with
SFJ's strategy. Thereafter, if the Phase 3 Trial meets the Phase 3 Trial Success Criteria and the
necessary endpoints are met in the other Clinical Trials in the SFJ Territory, SFJ will use
Commercially Reasonable Efforts to perform all activities associated with submitting BLAs and
seeking Regulatory Approval for the Indication in Japan and China, and PB will use Commercially
Reasonable Efforts to perform all activities associated with seeking Approval for the Indication in
the Designated European Countries. Upon approval of a BLA for the Product for the Indication by NMPA
in China or PMDA in Japan, SFJ, on behalf of itself and its Affiliates, shall, and hereby does,
assign to PB all of SFJ's and its Affiliates' right, title and interest in and to all INDs, BLAs and
Regulatory Approvals (including all amendments and supplements to any of the foregoing) and other
filings with, and formal submissions to, NMPA or PMDA, respectively, and other applicable Regulatory
Authorities in such country, in each case, with respect to the Product in such country
(collectively, "Product Filings"). Within [***] after assignment of such Product Filings in the
applicable country, SFJ shall deliver to PB: (a) true, correct and complete copies of all Product
Filings in such country (in each case, whether held in the name of SFJ or any of its Affiliates),
and disclose to PB in writing all previously-undisclosed Research Results within the Trial Data
Package; (b) formally transfer or assign, or cause to be formally transferred or assigned, into the
name of PB or its designee all Product Filings in such country (in each case, whether held in the
name of SFJ or any of its Affiliates); and (c) take such other actions and execute such other
instruments, assignments and documents as may be necessary to effect, evidence, register and record
the transfer, assignment or other conveyance of such rights to PB or its designee.

3.1.3 Regulatory Interactions. Without limitation to Section 3.12.5, SFJ shall, except to the extent
a need for exigent action prevents it from doing so, cooperate with PB to provide MedImmune with
copies of SFJ's initial BLA relating to the Product to PMDA or NMPA, as applicable, a reasonable
amount of time (but no less than [***]) prior to the anticipated date for the applicable submission
to allow MedImmune to review and comment on such BLA, and SFJ shall consider all comments and
proposed revisions from MedImmune in good faith in connection with effecting such submission. SFJ
shall cooperate with PB in PB's

Source: PHASEBIO PHARMACEUTICALS INC, 10-K, 3/30/2020
<!-- page 26 -->
consultation with MedImmune regarding, and in keeping MedImmune informed of, the status of the
preparation of the dossier rationale and proposed labeling with respect to the Product in the SFJ
Territory. Upon MedImmune's request (as communicated by PB to SFJ), SFJ shall promptly (and in any
event, within [***]) provide to MedImmune access to and copies of any Regulatory Documentation
necessary or reasonably useful for MedImmune to Exploit the AstraZeneca Product or update the label
with respect thereto.

3.1.4 Compliance. Each Party will conduct its portion of the Development Program and perform all
other of its duties and responsibilities hereunder in accordance with the Development Plan and in
material compliance with all Applicable Laws. PB will use Commercially Reasonable Efforts to oversee
the Manufacture of the Product, and PB will materially comply, and PB will require that all
Permitted Third Parties of PB materially comply, with all Applicable Laws with respect to the
analysis, storage, handling, disposal and transfer of the Product. SFJ will materially comply, and
SFJ will require that all Permitted Third Parties of SFJ materially comply, with all Applicable Laws
with respect to the storage, handling, disposal and transfer of all quantities of Product supplied
by or on behalf of PB for use in the conduct of Clinical Trials in the European Clinical Trial
Countries and the Designated Asian Countries.

3.1.5 SFJ SOPs. Subject to the terms hereof, SFJ will, within the SFJ Territory, use Commercially
Reasonable Efforts to conduct, or ensure that the Approved CRO conducts, the Clinical Trials in
accordance with the standard operating procedures (the "SFJ SOPs") that will be provided to PB
within [***] following the later of (i) the Effective Date or (ii) the selection of such Approved
CRO for PB's review and comment. Following the Effective Date, SFJ may amend any SOPs; provided that
with respect to material amendments to SOPs that pertain to Clinical Trials activities and/or other
obligations that are, or will be, performed by SFJ or any Permitted Third Party utilized by SFJ
during the remainder of the Term or any time thereafter as set forth in this Agreement, SFJ will
provide the JDC with a copy of each such amendment to permit the JDC Representatives to review and
comment on such amendments and SFJ will reasonably consider incorporating such comments.

3.1.6 PB SOPs. Subject to the terms hereof, PB will, within the PB Territory, use Commercially
Reasonable Efforts to conduct, or ensure that the Approved CRO conducts, the Clinical Trials in
accordance with the standard operating procedures (the "PS SOPs") that will be provided to SFJ
within [***] following the later of (i) the Effective Date or (ii) the selection of such Approved
CRO for SFJ's review and comment. Following the Effective Date, PB may amend any SOPs; provided that
with respect to material amendments to SOPs that pertain to Clinical Trials activities and/or other
obligations that are, or will be, performed by PB or any Permitted Third Party utilized by PB during
the remainder of the Term or any time thereafter as set forth in this Agreement, PB will provide the
JDC with a copy of each such amendment to permit the JDC Representatives to review and comment on
such amendments and PB will reasonably consider incorporating such comments.

Source: PHASEBIO PHARMACEUTICALS INC, 10-K, 3/30/2020
<!-- page 27 -->
3.2 Sites and Clinical Investigators.

3.2.1 Selection of Sites and Investigators.

3.2.1.1 SFJ will select the study sites within the SFJ Territory and the European Clinical Trial
Countries to conduct the Clinical Trials and will inform the JDC in advance of SFJ's choice of each
study site; the JDC will have the right to reject any such site(s) which the JDC will determine in
its reasonable judgment are not appropriate.

3.2.1.2 PB will select the study sites within the US to conduct the Clinical Trials and will inform
the JDC in advance of PB's choice of each study site; the JDC will have the right to reject any such
site(s) which the JDC will determine in its reasonable judgment are not appropriate.

3.2.1.3 Each Party will enter, and will ensure that its Affiliates enter, and each Approved CRO will
enter, into an agreement with each study site; such an agreement will be substantially in the form
to be provided by PB and agreed upon by the Parties within [***] following the Effective Date (the
"Clinical Trial Agreement") (upon execution of such Clinical Trial Agreement, such study site will
be deemed a "Site"). If a study site requires any material changes to such form Clinical Trial
Agreement, SFJ with regard to the European Clinical Trial Countries and the SFJ Territory and PB
with regard to the US, will inform the JDC and seek JDC approval of such change, and the JDC will
not unreasonably withhold such approval. For clarity, each Clinical Trial Agreement will be on
commercially reasonable and customary terms, consistent with industry standards for similar
agreements and sufficient to enable such Party to comply with its obligations hereunder with respect
to such Clinical Trial, including, but not limited to, Section 2.2.2, the terms pertaining to
ownership of Intellectual Property and publications, and treatment of Confidential Information.

3.2.1.4 The Clinical Trials Agreements will also require that the Clinical Investigators, any
sub-investigators (e.g., research fellows, residents and associates) and any others required by
Applicable Law at each Site complete a financial disclosure document substantially in the form to be
agreed upon by the Parties (the "Financial Disclosure Form"). For clarity, if any of the foregoing
individuals do not complete such Financial Disclosure Form, such individuals may not participate in,
or do any work in connection with, the Clinical Trials.

3.2.2 Obligations During the Clinical Trials Conduct.

3.2.2.1 During the Development Term, SFJ will conduct meetings with the Clinical Investigators
within the SFJ Territory and the European Clinical Trial Countries, and PB will conduct meetings
with the Clinical Investigators in the US (each, a "Clinical Investigator Meeting"), of which the
JDC will be provided with reasonable advance notice and in which the other Party will have the right
(but not the obligation) to attend and participate. Minutes of Clinical Investigator Meetings will
be made available to the JDC upon request.

3.2.2.2 Each Party will provide the JDC with copies of all communications relevant to the Clinical
Trials and provided to all Sites, and upon request of the

Source: PHASEBIO PHARMACEUTICALS INC, 10-K, 3/30/2020
<!-- page 28 -->
JDC, provide the JDC with copies of any other communications between such Party and any individual
Sites and/or any Affiliate or Approved CRO and any individual Sites.

3.2.2.3 If a Party terminates a Site, such Party will inform the JDC with the reason for such
termination and if reasonably practicable, such notice will be provided reasonably in advance of
such termination.

3.2.2.4 PB in the PB Territory and SFJ in the SFJ Territory will be responsible for preparing and
submitting any INDs and amendments thereto to Regulatory Authorities as required by Applicable Laws
in the countries for which Sites have been selected. PB will prepare the CMC Information and any
updates to this information and submit it to the applicable Regulatory Authority as required by
Applicable Laws.

3.3 Subjects and Informed Consent.

3.3.1 Subject Recruitment Plan. The Parties will comply with the subject recruitment plan for the
Clinical Trials, which will be established by each Party for their respective Territory, except in
the case of the European Clinical Trial Countries which SFJ will be responsible for, and
communicated to the JDC, for approval by the JDC not to be unreasonably withheld, within a
reasonable period of time after the Effective Date not to exceed [***] of the Effective Date (the
"Subject Recruitment Plan") in recruiting subjects to participate in the Clinical Trials. For
clarity, prior to engaging in any recruiting activities, the Parties, within their respective
Territory, will ensure that the applicable IRBs and/or other ethics committees approve any related
materials and activities as required by the JDC and all Applicable Laws.

3.3.2 Informed Consent.

3.3.2.1 PB, with support from SFJ, will prepare the informed consent document(s) for use in the
Clinical Trials. Each Party will ensure that the informed consent of each subject participating in a
Clinical Trial in such Party's respective Territory, except in the case of the European Clinical
Trial Countries which SFJ will be responsible for, be obtained in accordance with all Applicable
Laws, including completion of the informed consent document. Such informed consent document for a
Clinical Trial will be substantially in the form to be approved by the JDC within [***] following
approval by the JDC of the final Protocol for such Clinical Trial (collectively, "Informed Consent")
(upon obtaining such Informed Consent, a prospective subject will be deemed a "Subject"). For
clarity, the Informed Consent document that each Subject signs will expressly state that each
Subject understands that such Party is providing support for the Clinical Trials and will authorize
disclosure of data and results related to the Clinical Trials to PB or SFJ, as applicable, for any
purpose, subject to all Applicable Laws.

3.3.2.2 PB will ensure that the Informed Consent has been obtained by a Permitted Third Party from
each Subject in the US prior to administration of the Product to such Subject in accordance with the
Protocol. SFJ will ensure that the Informed Consent has been obtained by a Permitted Third Party
from each Subject in the European Clinical Trial Countries and the SFJ Territory prior to
administration of the Product to such Subject in accordance with the Protocol.

Source: PHASEBIO PHARMACEUTICALS INC, 10-K, 3/30/2020
<!-- page 29 -->
3.3.3 Inclusion and Exclusion Criteria. Neither Party will waive, and each Party will require that
its Permitted Third Parties do not waive, any exclusion or inclusion criteria specified in the
Protocol.

3.4 Investigator's Brochure.

3.4.1 Investigator's Brochure. PB will maintain the Investigator's Brochure for the Product. SFJ
will, promptly following receipt of written notice from PB of the need for an Investigator's
Brochure update, provide PB with all information regarding the Clinical Trials that is necessary to
enable PB to update the Investigator's Brochure.

3.4.2 Parties' Responsibilities. Promptly following the Effective Date, PB will provide SFJ with the
most recent version of the Investigator's Brochure. PB will also promptly provide SFJ with any
updated versions of the Investigator's Brochure. Each Party will ensure that each Site in such
Party's respective Territory, except in the case of the European Clinical Trial Countries which SFJ
will be responsible for, and all applicable IRBs and other ethics committees receive a copy of, and
promptly receive any updates to, the Investigator's Brochure.

3.5 Data Collection and Data Management.

3.5.1 CRF. PB, with support from SFJ, will be responsible for preparing the form of CRF for the
Clinical Trials in accordance with the Protocol.

3.5.2 Data Management Plan.

3.5.2.1 Each Party will use Commercially Reasonable Efforts to comply with the data management plan
to be agreed upon by the Parties within [***] following approval by the JDC of the final Protocol
(the "Data Management Plan"). For clarity, the Data Management Plan will be agreed upon by the
Parties prior to recruitment of subjects for the Clinical Trials.

3.5.2.2 With respect to any data collected in connection with the Clinical Trials, each Party will
ensure that such data is held in one or more appropriate facilities with information security
protections in accordance with all Applicable Laws including [***].

3.5.3 Clinical Trials Database.

3.5.3.1 PB, with support from SFJ, will use Commercially Reasonable Efforts to establish a Clinical
Trials database for the data collected from each Site for the Clinical Trials (the "Clinical Trials
Database") within [***] following approval by the JSC of the Final Protocol. SFJ with regard to
European Clinical Trial Countries and the SFJ Territory and PB with regard to the US will promptly
update the Clinical Trials Database upon receiving data for the Clinical Trials from any Site and
any other applicable Permitted Third Party, and each Party will ensure that the Sites and such other
Permitted Third Parties promptly following collection thereof, provide data in connection with the
Clinical Trials to such Party.

Source: PHASEBIO PHARMACEUTICALS INC, 10-K, 3/30/2020
<!-- page 30 -->
3.5.3.2 Each Party will provide the JDC with electronic copies of such data requested by the JDC at
JDC meetings and in accordance with Applicable Laws.

3.5.3.3 If, at any time during the Development Term, PB decides to change the format of the database
for the Clinical Trials, PB will so notify SFJ and the Parties will cooperate to ensure that the
format that PB selects permits SFJ to incorporate the data from the Clinical Trials into its
relevant systems and is in compliance with all Applicable Laws.

3.5.3.4 The Vendor responsible for the database will provide SAS datasets to the Parties in
accordance with specifications as defined by PB (i) when the data in the Clinical Trials Database
are equivalent to [***] of total data expected to be recorded in the Clinical Trials Database; (ii)
if a safety signal is identified; and/or (iii) if a request is received from the Regulatory
Authorities.

3.5.3.5 PB and SFJ will jointly maintain the Clinical Trials Database including ensuring that
information included in the Clinical Trials Database is accurate and up-to-date. PB will be
responsible for registering, maintaining and updating any registries pertaining to the Clinical
Trials to the extent required by any Applicable Laws, including www.clinicaltrials.gov,
www.clinicalstudyresults.org, and the PHRMA Website Synopsis.

3.5.4 Clinical Trials Master File. Promptly following the Effective Date, PB and SFJ will jointly
establish and maintain a Clinical Trials master file for each Clinical Trial in the format as agreed
upon by the JDC (each a "Clinical Trials Master File"). Notwithstanding anything to the contrary
herein, neither PB nor SFJ will be permitted to delegate its rights and obligations pursuant to this
Section 3.5.4 to any Permitted Third Parties without the prior approval of the JDC, except either
Party may delegate its rights and obligations pursuant to this Section 3.5.4 to any of its
Affiliates.

3.5.5 Source Data Verification. PB will be responsible for source verification of data records in
the US, and SFJ will be responsible for source data verification of data records in European
Clinical Trial Countries and the SFJ Territory. At either Party's request, a Party will provide the
other Party with copies of any reports relating to source data verification and other types of
Clinical Trials audits.

3.5.6 Statistical Analysis. PB will perform any statistical analysis required in accordance with the
statistical analysis plan for the Clinical Trials to be agreed upon by the Parties within [***] of
the Effective Date (the "Statistical Analysis Plan").

3.6 Audits.

3.6.1 Each Party will conduct quality oversight inspections and audits of the facilities and
services of the Permitted Third Parties utilized by such Party in accordance with its standard
operating procedures and will provide the other Party with copies of such audit reports upon
request.

Source: PHASEBIO PHARMACEUTICALS INC, 10-K, 3/30/2020
<!-- page 31 -->
3.6.2 During the Development Term, PB will conduct quality oversight inspections and audits of the
manufacturing facilities for the Product in accordance with its internal policies and PB will
provide SFJ with copies of such audit reports.

3.7 Monitoring. PB in the US, and SFJ in European Clinical Trial Countries and the SFJ Territory,
will monitor the Clinical Trials, and share information with the JDC pertaining to monitoring the
Clinical Trials, in accordance with the monitoring plan for the Clinical Trials to be agreed upon by
the Parties within [***] following the Effective Date.

3.8 IRBs and Other Ethics Committees.

3.8.1 Each Party will be responsible for obtaining the approval of the IRBs and other ethics
committees required prior to commencing, and during, the Clinical Trials at every Site in such
Party's Territory, except in the case of the European Clinical Trial Countries which SFJ will be
responsible for.

3.8.2 Each Party will ensure that IRBs and such other relevant ethics committees have current
registrations and accreditations as required by Applicable Law and will provide all ethics
committees, including all IRBs, and Regulatory Authorities, with all necessary documentation prior
to, and during the course of, the Clinical Trials as required by Applicable Law.

3.8.3 PB in the US, and SFJ in the SFJ Territory and in the European Clinical Trial Countries, will
be responsible for responding to all queries from the IRBs and other ethics committees; provided
that (a) the other Party will make itself reasonably available to assist with any such queries and
(b) if such query relates solely to the CMC Information, the Manufacturing Dossier, and/or
preclinical studies, PB will prepare the applicable response and provide SFJ with a copy thereof.

3.9 IDMC

3.9.1 PB will establish an IDMC for the Clinical Trials, [***]. For clarity, [***].

3.9.2 PB will ensure that the IDMC is provided with all information and data that it requires [***],
and SFJ will reasonably cooperate with PB in such regard.

3.10 Environmental Health and Safety.

3.10.1 In conducting the Clinical Trials, each Party will comply with all Applicable Laws relating
to environmental, health and/or safety matters and will be solely responsible for establishing
material and specimen handling guidelines and for ensuring use of controls, including appropriate
personal protective equipment, that minimize potential worker exposure, obtaining the material
safety data sheets and providing the appropriate training for workers who will be potentially
exposed to the Product.

Source: PHASEBIO PHARMACEUTICALS INC, 10-K, 3/30/2020
<!-- page 32 -->
3.10.2 Each Party will promptly notify the JDC, in writing, of any worker claims of suspected
occupational illnesses related to working with the Product, regardless of whether such claims are
received during the Development Term or any time thereafter. After termination of this Agreement for
whatever reasons, or expiration of this Agreement, each Party will promptly notify the other Party
of any worker claims of suspected occupational illnesses related to working with the Product during
the Development Term, of which it has knowledge.

3.11 Completion of the Clinical Trials.

3.11.1 PB will use Commercially Reasonable Efforts to keep the Sites participating in the Phase 3
Trial in the US, and SFJ will use Commercially Reasonable Efforts to keep the Sites participating in
each Clinical Trial in European Clinical Trial Countries and the SFJ Territory, operational,
including continuing to dose Subjects with the Product in accordance with the Protocol and
conducting any follow-up work required, until the Completion Date for such Clinical Trial. As a
Clinical Trial is completed or otherwise terminated at each Site for which a Party is responsible,
such Party will close out such Clinical Trial as specified in the Protocol, including performing all
Subject follow-up and providing the other Party with all Clinical Trial data not provided as of such
date. For clarity, copies of documents, including any CRFs and the Clinical Trials Master File will
be made available and/or transferred to the other Party upon the other Party's request, or at the
other Party's option, destroyed (provided that such destruction is in compliance with ICH
guidelines). Notwithstanding the foregoing, neither Party will provide the other Party with any
Personally Identifiable Information.

3.11.2 Upon the Completion Date of a Clinical Trial, SFJ will return to the location specified by PB
at such time, or, at PB's option, destroy, any unused Product from such Clinical Trial (SFJ's
expenses in doing so will be included in Development Costs), and will comply with all Applicable
Laws in so returning or destroying such Product.

3.11.3 The CSR for the Phase 3 Trial will be prepared by PB, with support from SFJ, in compliance
with all Applicable Laws, including ICH E3 guidelines. The final, signed CSR for the Phase 3 Trial
(the "Final Phase 3 Trial CSR") will be provided to SFJ promptly following the Completion Date of
the Phase 3 Trial. In the event that there are any additional safety or efficacy data pertaining to
the Phase 3 Trial that come into the possession of PB after it has provided SFJ with the Final Phase
3 Trial CSR, PB will prepare and promptly provide SFJ with a supplement to such CSR. The CSR for
each Clinical Trial (other than the Phase 3 Trial) conducted in the SFJ Territory will be prepared
by SFJ, with support from PB, in compliance with all Applicable Laws, including ICH E3 guidelines.
The final, signed CSR for each such Clinical Trial conducted in the SFJ Territory (each, a "Final
SFJ Territory CSR") will be provided to PB promptly following the Completion Date of such Clinical
Trial. In the event that there are any additional safety or efficacy data pertaining to any such
other Clinical Trial conducted in the PB Territory that come into the possession of SFJ after it has
provided PB with the Final SFJ Territory CSR for such Clinical Trial, SFJ will prepare and promptly
provide PB with a supplement to such CSR.

Source: PHASEBIO PHARMACEUTICALS INC, 10-K, 3/30/2020
<!-- page 33 -->
3.12 Commercially Reasonable Efforts.

3.12.1 Timely performance of the Clinical Trials and receipt of Regulatory Approval is important to
the success of this Agreement. Each Party will use Commercially Reasonable Efforts to complete the
Clinical Trials according to the Timeline and, if the Clinical Trials is successful, to obtain
Regulatory Approval, in such Party's Territory. In the event that either Party fails to complete the
Clinical Trials in their respective Territory according to the Timeline and this failure is not
cured as set forth in Section 14.2.1, the other Party may terminate this Agreement pursuant to
Section 14.2.1, or following discussion by the JSC that such Party failed to use Commercially
Reasonable Efforts, the other Party may assume the roles and responsibilities of such Party;
provided that in the event of such failure by SFJ, SFJ will remain obligated to pay the costs under
Section 4.2.2(ii).

3.12.2 In the event of Successful Phase 3 Interim Analysis, PB will use Commercially Reasonable
Efforts to obtain Regulatory Approval for the Product for the Indication (a) by the FDA in the US,
including the obligation to file a BLA for the Product for the Indication with the FDA within [***]
of Successful Phase 3 Interim Analysis, provided that PB shall not be required to file such BLA
earlier than the estimated date for BLA filing in the US based on Successful Phase 3 Interim
Analysis set forth in the Timeline, and (b) by EMA in the EU (or, as applicable, by the applicable
national Regulatory Authorities in one or more Designated European Countries), including the
obligation to file a BLA for the Product for the Indication with EMA (or the applicable national
Regulatory Authorities in one or more Designated European Countries) within [***] of Successful
Phase 3 Interim Analysis, provided that PB shall not be required to file such BLA earlier than the
estimated date for BLA filing in the EU based on Successful Phase 3 Interim Analysis set forth in
the Timeline.

In the event that PB fails to use Commercially Reasonable Efforts to so obtain Regulatory Approval
for the Product for the Indication, including the obligation to file a BLA for the Product for the
Indication with each of the FDA and EMA (or the applicable national Regulatory Authorities in one or
more Designated European Countries) by the dates set forth in this Section 3.12.2, and this failure
is not cured within [***] after receipt of written notice from SFJ requesting such cure, SFJ may
either terminate this Agreement pursuant to Section 14.2.1, or assume PB's regulatory filing
activities (in which event SFJ's expenses in assuming such regulatory filing activities shall be
deemed to be Development Costs).

3.12.3 Upon achievement of the Phase 3 Success Criteria, PB will use Commercially Reasonable Efforts
to obtain Regulatory Approval for the Product for the Indication by the FDA in the US and by EMA in
the EU (or, as applicable, by the applicable national Regulatory Authorities in one or more
Designated European Countries), including the obligation to file a BLA for the Product for the
Indication with each of the FDA and EMA (or the applicable national Regulatory Authorities in one or
more Designated European Countries) within [***] of the date of achievement of the Phase 3 Success
Criteria. In the event that PB fails to use Commercially Reasonable Efforts to so obtain Regulatory
Approval for the Product for the Indication, including the obligation to file a BLA for the Product
for the Indication with each of the FDA and EMA (or the applicable national Regulatory Authorities
in one or more

Source: PHASEBIO PHARMACEUTICALS INC, 10-K, 3/30/2020
<!-- page 34 -->
Designated European Countries) within [***] of the date of achievement of the Phase 3 Success
Criteria, and this failure is not cured as set forth in Section 14.2.1, SFJ may either terminate
this Agreement pursuant to Section 14.2.1, or assume PB's regulatory filing activities (in which
event SFJ's expenses in doing so shall be deemed to be Development Costs).

3.12.4 Upon achievement of the Phase 3 Success Criteria or Successful Phase 3 Interim Analysis if
conditional approval based on interim data is allowed by the relevant Regulatory Authority (or, if
later, achievement of the primary endpoint(s) of any other Japan-specific or China-specific Clinical
Trial, as applicable, being conducted by SFJ in the applicable country that is necessary for filing
of a BLA with PMDA or NMPA, respectively), SFJ will use Commercially Reasonable Efforts to obtain
Regulatory Approval for the Product for the Indication by the PMDA in Japan and by the NMPA in
China, including the obligation to file a BLA for the Product for the Indication with each of the
PMDA and the NMPA within [***] of the date of achievement of the Phase 3 Success Criteria, provided
that SFJ shall not be required to file such BLA earlier than the estimated date for BLA filing in
Japan or China (as applicable) based on the Phase 3 Success Criteria or Successful Phase 3 Interim
Analysis if conditional approval based on interim data is allowed by the relevant Regulatory
Authority as set forth in the Timeline or, if later, achievement of the primary endpoint(s) of any
other Japan-specific or China-specific Clinical Trial, as applicable, being conducted by SFJ in the
applicable country that is necessary for filing of a BLA with PMDA or NMPA, respectively. In the
event that SFJ fails to use Commercially Reasonable Efforts to so obtain Regulatory Approval for the
Product for the Indication, including the obligation to file a BLA for the Product for the
Indication with each of the PMDA and the NMPA within [***] of (a) the date of achievement of the
Phase 3 Success Criteria or, (b) if later, achievement of the primary endpoint(s) of any other
Japan-specific or China-specific Clinical Trial, as applicable, being conducted by SFJ in the
applicable country that is necessary for filing of a BLA with PMDA or NMPA, respectively, or
Successful Phase 3 Interim Analysis if conditional approval based on interim data is allowed by the
relevant Regulatory Authority, and this failure is not (i) caused by PB's failure to perform its
obligations hereunder or (ii) cured as set forth in Section 14.2.1, PB may either terminate this
Agreement pursuant to Section 14.2.1, or assume SFJ's regulatory filing activities, in which event
an amount equal to PB's expenses in doing so [***]. In no event will any such costs incurred by PB
be included in actual Development Costs for purposes of Section 14.2.

3.12.5 Regulatory Approvals. The Parties acknowledge that regulatory matters with respect to the
Product will reasonably require coordination with regulatory matters with respect to the AstraZeneca
Product, and SFJ agrees to cooperate in good faith with PB and MedImmune as reasonably necessary for
and in relation to each of PB and SFJ, on the one hand, and MedImmune, on the other hand, to obtain
and maintain regulatory approvals (including Regulatory Approvals) with respect to the Product in
the case of PB and SFJ and with respect to the AstraZeneca Product in the case of MedImmune. Prior
to submitting any written or electronic communication to a Regulatory Authority in a country of the
Territory with respect to AstraZeneca Product that would reasonably be expected to require a change
to the Regulatory Authority‑approved full prescribing information for the AstraZeneca Product for
such country, SFJ shall cooperate with PB in PB's consultation with MedImmune. SFJ shall keep PB
reasonably informed of its efforts to obtain and maintain Regulatory Approval for the Product in

Source: PHASEBIO PHARMACEUTICALS INC, 10-K, 3/30/2020
<!-- page 35 -->
the SFJ Territory and developments with respect thereto, including SFJ's expected timing with
respect to submission and receipt of any and all Regulatory Approvals.

3.13 Pharmacovigilance and Safety Information Exchange.

3.13.1 SFJ acknowledges that PB is bound by the pharmacovigilance and safety information exchange
requirements of Sections 3.4.4(b) through 3.4.4(h) of the AZ License and the terms of the MedImmune
Pharmacovigilance Agreement (a copy of which is attached hereto as Exhibit N) relating both to the
Product and the AstraZeneca Product and that, in order to comply with its obligations to MedImmune,
PB must obtain SFJ's commitment to provide adverse event and other safety information relating to
the Product and to AstraZeneca Product to PB in a form and within the applicable time periods
necessary for PB to comply with Sections 3.4.4(b) through 3.4.4(h) of the AZ License and the terms
of the MedImmune Pharmacovigilance Agreement.

3.13.2 The safety reporting units from each of the Parties shall meet and shall within [***] of the
Effective Date agree upon a written agreement for exchanging adverse event and other safety
information relating to the Product (the "Pharmacovigilance Agreement"). The Pharmacovigilance
Agreement will ensure that adverse event and other safety information are exchanged upon terms that
will permit (a) PB to comply with Sections 3.4.4(b) through 3.4.4(h) of the AZ License and the terms
of the MedImmune Pharmacovigilance Agreement, and (b) each Party to comply with Applicable Laws and
requirements of Regulatory Authorities.

3.13.3 Each Party agrees not to enter in to any clinical activity implicating pharmacovigilance
obligations for the Product in its respective Territory prior to execution of the Pharmacovigilance
Agreement.

3.14 Product.

3.14.1 Supply of the Product.

3.14.1.1 PB will be the GMP Manufacturer of the Product for the Clinical Trials, either directly or
through an Approved Vendor. In particular, with respect to the Clinical Trials, PB will maintain in
force a clinical supply agreement with a CMO that has sufficient capacity to manufacture and supply
GMP-compliant Product for the Clinical Trials in a timely manner in accordance with a clinical
supply schedule approved by the JDC (as amended by the JDC from time to time, the "Clinical Supply
Schedule").

3.14.1.2 During the Development Term, PB will supply, as determined by the JDC, or cause to be
supplied, as determined by the JDC to SFJ GMP-compliant Product manufactured in compliance with the
then-current CMC Information included in the IND submitted to the applicable Regulatory Authority
for the Clinical Trials in the European Clinical Trial Countries or the SFJ Territory, as
applicable, in accordance with the Clinical Supply Schedule as set forth in a clinical supply
agreement to be entered into between the Parties within [***] after the Effective Date (the
"Clinical Supply Agreement"). The costs for the supply of the Product for the Clinical Trials in the
US, the European Clinical Trial Countries and the SFJ

Source: PHASEBIO PHARMACEUTICALS INC, 10-K, 3/30/2020
<!-- page 36 -->
Territory (the "Product Supply Costs") will be borne by PB. Each Party will provide the JDC at each
JDC meeting with quarterly reports regarding inventory of the Product and the reasonably anticipated
needs for the Product to ensure that PB can supply the Product in accordance with the Clinical
Supply Schedule.

3.14.2 Use of the Product.

3.14.2.1 SFJ will (i) in conducting the Clinical Trials, only use Product supplied by PB or such
Third Parties designated by PB; (ii) only use the Product supplied by PB or Third Parties designated
by PB, and require that its Permitted Third Parties that receive any of the Product supplied by PB
or Third Parties designated by PB only use such Product, for the sole purpose of conducting the
Clinical Trials in accordance with the respective Protocols; and (iii) ensure subject dosing
compliance per the respective Protocols for the Clinical Trials conducted in the European Clinical
Trial Countries or the SFJ Territory. Dosage and Administration Instructions will be provided to SFJ
by PB sufficiently in advance of the Clinical Trials' commencement.

3.14.2.2 PB in the US, and SFJ in the European Clinical Trial Countries and the SFJ Territory, will
be responsible for ensuring that the Product is administered solely to the Subjects in Clinical
Trials conducted by such Party in accordance with the respective Protocols. For each dose
administered to a Subject in a Clinical Trial conducted by such Party, such Party will implement
procedures and ensure that records are maintained specifying the date and time that such dose of the
Product is administered, the amount of the Product administered to such Subject, the lot number of
the Product from which such dosage came, and the number of the Subject to which such dosage was
administered. Each Party shall provide copies of such records to the other Party upon the other
Party's reasonable request.

3.15 Complaints Related to the Product. During the Development Term, each Party will promptly
forward to the other Party any complaints that it receives related to the Product. PB in the US, and
SFJ in European Clinical Trial Countries and the SFJ Territory, will respond to any complaints of
which such Party becomes aware relating to the Product provided that the other Party will provide
reasonable cooperation in connection therewith. Notwithstanding the foregoing, if a complaint
pertains to the manufacturing, appearance or general physical characteristics of the Product or
other processes at the manufacturing facility, PB will be solely responsible for responding to such
complaint.

3.16 Recall of the Product in Connection with Study Prior to Approval. If the Product is recalled
for safety reasons or GMP non‑compliance prior to Regulatory Approval, PB in the US, and SFJ in
European Clinical Trial Countries and the SFJ Territory, will be responsible for the operational
execution of such recall. PB will cooperate with SFJ in connection with any such recall in European
Clinical Trial Countries or the SFJ Territory. The costs for such any such recall will be at PB's
expense and not be a Development Cost, unless such recall and/or costs were based on the material
breach of this Agreement, intentional misconduct, or gross negligence of SFJ or any of its
Affiliates or Permitted Third Parties, in which case, SFJ will bear the expense of any such recall
and such expense will not be a Development Cost.

Source: PHASEBIO PHARMACEUTICALS INC, 10-K, 3/30/2020
<!-- page 37 -->
3.17 Compliance with Laws. SFJ and its Affiliates and PB and its Affiliates will comply, and each
Party will use Commercially Reasonable Efforts to ensure that all Permitted Third Parties utilized
by such Party comply, with all Applicable Laws with respect to the storage, handling, disposal and
transfer of the Product, and each Party assumes sole responsibility for the violation of such
Applicable Laws by such Party or any of its Affiliates or its Permitted Third Parties.

3.18 Disclosures.

3.18.1 During the Development Term, each Party shall provide the other Party at meetings of the JSC
(or in advance of such meetings as part of the information that may be distributed to JSC members
prior to such meetings or, if no such meeting is held in a [***], directly to the other Party) at
least once during each [***] with summaries of all data known to such Party material to obtaining
Regulatory Approval, and material Product safety data in all indications (including but not limited
to Serious Safety Issues), including such material data relating to efficacy, clinical sites,
patient enrollment and drop-out rates, CMC and other material manufacturing data, and material
communications with Regulatory Authorities.

3.18.2 PB shall (a) provide SFJ with quarterly unaudited financial statements and annual audited
financial statements (the "PB Financial Statements") promptly following the availability thereof
(and no later than the date filed with the SEC) and provide to SFJ on a quarterly basis concurrently
with the applicable PB Financial Statements [***], (b) promptly notify SFJ of achieving the
Successful Phase 3 Interim Analysis and the Phase 3 Success Criteria, and (c) on or prior to the end
of each [***] during the Term [***]. At least [***] during the Term, upon SFJ's request, Executive
Officers of PB shall meet with Executive Officers of SFJ to review and discuss PB's financial
condition and operations. [***].

3.18.3 PB shall provide prompt written notice (a "Going Concern Notice") to SFJ if (i) PB determines
in accordance with GAAP that it is probable that PB will be unable to meet its obligations as they
become due within one year after the date that PB's financial statements for the then-current
quarter are issued, or available to be issued or (ii) a "Going Concern" footnote is included in any
of the PB Financial Statements required to be delivered by PB to SFJ pursuant to Section 3.18.2 (a
"Going Concern Condition"). During the applicable Going Concern Cure Period (as defined below), PB
shall have the ability to remedy the Going Concern Condition through a restructuring of PB's costs
and operations (provided that such restructuring does not adversely impact PB's ability to perform
its obligations hereunder) or through raising additional capital in one or more financing or
strategic transactions so as to enable PB to meet its obligations as they become due within such one
year period including performing all of PB's obligations hereunder. "Going Concern Cure Period"
shall mean the [***] period following delivery of a Going Concern Notice, provided that if SFJ does
not offer and fund Going Concern Funding as set forth in Section 4.2.4 sufficient to remedy the
Going Concern Condition within such [***] period, the Going Concern Cure Period shall be extended to
[***] following delivery of such Going Concern Notice.

Source: PHASEBIO PHARMACEUTICALS INC, 10-K, 3/30/2020
<!-- page 38 -->
3.19 Exclusivity Commitment of SFJ. During the applicable Exclusive Period, SFJ shall not, and shall
cause its Affiliates not to, either by itself or through a Third Party, conduct human clinical
trials of, or sell, offer for sale or have sold:

3.19.1 any Competing Product (other than Product) alone or in combination (whether fixed dose or
co-packaged) with one (1) or more other active ingredients;

3.19.2 any combination (whether fixed dose or co-packaged) with one (1) or more other active
ingredients of the Product and a Competing Product;

3.19.3 any agent that is intended as an antidote to, or is intended to neutralize, abrogate or
reverse the antiplatelet activity of, (i) any Brilinta Competing Product alone or in combination
(whether fixed dose or co-packaged) with one (1) or more other active ingredients or (ii) both the
Ticagrelor Compound and a Brilinta Competing Product;

3.19.4 without limitation to the foregoing, any agent with dual activity as (i) an antidote to, or
for use as an agent to neutralize, abrogate or reverse the antiplatelet activity of, the Ticagrelor
Compound and (ii) an antidote to, or for use as an agent to neutralize, abrogate or reverse the
antiplatelet activity of, any Brilinta Competing Product; or

3.19.5 any Brilinta Competing Product.

3.20 Program Transfer. In the event that, at any time after payment to PB of the Initial Development
Cost Payment on the Initial Funding Date, PB shall (a) fail to pay any amounts payable to SFJ
hereunder within [***] of the date such payment is due, or (b) become in default of its obligations
under the AZ License (excluding (x) any such default that would not entitle AZ to terminate the AZ
License and (y) any such default that is caused by SFJ's breach of its obligations under this
Agreement), or (c) (i) fail to remedy the Going Concern Condition within the Going Concern Cure
Period as set forth in Section 3.18.3 or (ii) refuse to accept the Going Concern Funding if offered
by SFJ as set forth in Section 4.2.4, then, SFJ may deliver written notice to PB electing to cause
PB's business related to the Product to be transferred to SFJ (the "Program Transfer Notice"), and
shall deliver a copy of the Program Transfer Notice to MedImmune concurrently with delivery to PB,
and within [***] following the delivery of the Program Transfer Notice, PB and SFJ shall execute and
deliver a Program Transfer Agreement in the form attached hereto as Exhibit O (the "Program Transfer
Agreement") which shall effect the Program Transfer effective as of the date SFJ delivers the
Program Transfer Notice to PB. For clarity, this Section 3.20 shall not be effective prior to
payment to PB of the Initial Development Cost Payment on the Initial Funding Date.

ARTICLE 4

DEVELOPMENT COSTS

4.1 Development Costs. SFJ will be obligated to pay or incur up to One Hundred Twenty Million U.S.
Dollars ($120,000,000.00) of Development Costs ("Maximum Development Costs") in accordance with the
funding schedule set forth in Section 4.2. Any

Source: PHASEBIO PHARMACEUTICALS INC, 10-K, 3/30/2020
<!-- page 39 -->
Development Costs in excess of the sum of the Maximum Development Costs and any Going Concern
Funding will be borne by PB.

4.2 Funding Schedule.

4.2.1 Subject to Section 4.2.4 below, SFJ will pay or incur up to a total of $120 million of
Development Costs as set forth in the table below and as detailed below, as set forth in Sections
4.2.2 and 4.2.3. For clarity, this Section 4.2.1 sets forth a summary of the payments due under
Sections 4.2.2 and 4.2.3 only, and does not create any additional obligation to pay or incur
development costs in excess of those obligations set forth in Sections 4.2.2 and 4.2.3.

To be paid 45 days after the later of (a) the Effective Date, and (b) the date that PB has obtained
the SVB Consent, as set forth in Section 4.2.2(i)

To be paid prior to the date of Successful Phase 3 Interim Analysis, as set forth in Section
4.2.2(ii)

To be paid after the date of Successful Phase 3 Interim Analysis, as set forth in Section 4.2.3

Total

$10 Million Up to $80 Million* At least $20 Million and up to $30Million Up to $120 Million

* In addition to initial $10 Million.

4.2.2 Following the Effective Date and prior to the date of first availability of the Phase 3
Interim Data (the "Interim Period"), SFJ shall pay or incur up to $90 million of Development Costs
as follows:

(i) The initial payment of Ten Million U.S. Dollars ($10,000,000.00) set forth in the table above,
to reimburse PB for development costs incurred by PB prior to the Effective Date (the "Initial
Development Cost Payment"), shall be payable on the date ("Initial Funding Date") that is forty-five
(45) days after the later of (a) the Effective Date, and (b) the date that PB has obtained the SVB
Consent.

(ii) Following payment to PB of the Initial Development Cost Payment on the Initial Funding Date:

(1) SFJ shall promptly pay all Approved Third Party Vendor Costs incurred by SFJ or PB in connection
with the Clinical Trials during the Interim Period.

(2) SFJ shall pay to SFJ Affiliates the amount of [***] to reimburse such SFJ Affiliates for their
internal costs of overseeing the CROs in European Clinical Trial Countries and the SFJ Territory and
for the management of the Clinical Trials in European Clinical Trial Countries and the SFJ Territory
during the Interim Period (the "SFJ Interim Management Fee").

Source: PHASEBIO PHARMACEUTICALS INC, 10-K, 3/30/2020
<!-- page 40 -->
(3) SFJ shall pay PB an amount equal to $90 million, less (a) the Initial Development Cost Payment,
(b) the SFJ Interim Management Fee, and (c) the Approved Third Party Vendor Costs paid or incurred
by SFJ during the Interim Period, (which Approved Third Party Vendor Costs amount shall be estimated
and agreed to by the Parties no later than [***]) to be paid pro rata in six (6) equal quarterly
payments within [***] after the end of each Calendar Quarter beginning with the Calendar Quarter
ending September 30, 2020 through the Calendar Quarter ending December 31, 2021.

Notwithstanding anything else contained herein to the contrary, in no event shall SFJ be required to
pay or incur Development Costs in excess of $90 million during the Interim Period. If the
Development Costs during the Interim Period exceed $90 million, PB shall pay or incur all such
excess Development Costs including continuing to provide the PB Services during the Interim Period
at the expense of PB unless otherwise agreed to in writing by SFJ. For the avoidance of doubt, if
the Successful Phase 3 Interim Analysis is not achieved, SFJ shall have no obligation to pay or
incur any further Development Costs.

4.2.3 Following the date of the Successful Phase 3 Interim Analysis and until the end of the
Development Term (the "Final Period"):

(i) SFJ shall pay to SFJ Affiliates the amount of [***] to reimburse such SFJ Affiliates for their
internal costs of overseeing the CROs in European Clinical Trial Countries and the SFJ Territory and
for the management of the Clinical Trials in European Clinical Trial Countries and the SFJ Territory
during the Final Period (the "SFJ Final Management Fee").

(ii) SFJ shall pay PB the amount (the "PB Costs") by which the Elected Total Amount (defined below)
exceeds the sum of (a) the Initial Development Cost Payment, (b) the SFJ Interim Management Fee, (c)
the SFJ Final Management Fee, and (d) all Approved Third Party Vendor Costs (as estimated and agreed
to by the Parties prior to the start of the Final Period which are expected to be paid by SFJ
through the end of the Development Term) paid or incurred by SFJ (including Approved Third Party
Vendor Costs paid by SFJ during the Interim Period) and (e) the amounts paid to PB pursuant to
Section 4.2.2(ii)(3), which PB Costs shall be paid pro rata in five (5) equal quarterly payments
within [***] after the end of each Calendar Quarter beginning for the Calendar Quarter ending March
31, 2022 through the Calendar Quarter ending March 31, 2023, provided however, in no case earlier
than forty-five (45) days after the later of (i) Approved Third Party Vendor Costs have been agreed
to by the Parties and (ii) PB has elected and informed SFJ of the Elected Total Amount. Within [***]
after achievement of the Successful Phase 3 Interim Analysis, PB shall notify SFJ in writing of the
total amount of Development Costs (inclusive of all Development Costs paid or incurred since the
Effective Date) that PB elects to have SFJ fund (the "Elected Total Amount"), which shall be no less
than $110 million and no more than $120 million.

(iii) In the event that the Development Costs paid by SFJ after paying all required payments under
the preceding provisions of this Section 4.2 shall be less than the Elected Total Amount then any
remaining balance of the Elected Total Amount shall be paid to PB by SFJ within [***] of the last
payment under Section 4.2.3(ii), to be used by PB for

Source: PHASEBIO PHARMACEUTICALS INC, 10-K, 3/30/2020
<!-- page 41 -->
commercialization activities, and such amount paid by SFJ shall be deemed to be included in
Development Costs.

Subject to Section 4.2.4 below, but notwithstanding anything else contained herein to the contrary,
in no event shall SFJ be required to pay or incur Development Costs in excess of $120 million in
total. If the total Development Costs exceed $120 million, PB shall pay or incur all such excess
Development Costs including paying all excess Approved Third Party Vendor Costs and Product Supply
Costs and continuing to provide the PB Services at the expense of PB unless otherwise agreed to in
writing by SFJ. In connection with the Development, manufacture and Commercialization of the Product
and fulfillment of PB's obligations hereunder, PB shall spend at least an amount equal to the amount
of funding paid by SFJ to PB pursuant to this Section 4.2.

4.2.4 If PB has not eliminated a Going Concern Condition by the expiration of the applicable Going
Concern Cure Period, SFJ shall have the option, but not the obligation, to pay PB an additional
amount (the "Going Concern Funding") up to the amount necessary to eliminate the Going Concern
Condition as reasonably determined by SFJ after consultation with PB, which amount (if any) must be
accepted by PB and shall be included in Development Costs and shall be paid by SFJ within [***]
after the expiration of the Going Concern Cure Period. The Going Concern Funding shall be placed in
an escrow account established by PB with the JSC to have sole authority to release funds from escrow
to be spent as directed by the JSC to fulfill PB's obligations hereunder.

4.3 Pre‑Commercialization Costs. During the Term, PB will be solely responsible at its own cost
(subject to Sections 4.2) for performing those activities reasonably necessary to prepare for
Commercial Launch of the Product in the Territory (the "Pre- Approval Commercialization
Activities"). Such Pre-Approval Commercialization Activities may include at PB's sole discretion
creating educational or marketing materials, establishing distribution channels and designing
packaging and labeling, in each case as reasonably necessary to Commercialize the Product in the
Territory.

ARTICLE 5

GOVERNANCE

5.1 Joint Steering Committee.

5.1.1 Representatives. Within [***] after the Effective Date, the Parties will establish a joint
steering committee to oversee and manage the collaboration (the "JSC"). Each Party initially will
appoint [***] to serve as representatives to the JSC (the "JSC Representatives"), with each JSC
Representative having knowledge and expertise regarding developing products similar to the Product
and sufficient decision-making authority within the applicable Party to make decisions on behalf of
such Party within the scope of the JSC's decision‑making authority and, if any such representative
is not an employee of the appointing Party, such representative shall execute a confidentiality
agreement in form and substance acceptable to the other Party (and, for the avoidance of doubt, the
appointing Party shall remain

Source: PHASEBIO PHARMACEUTICALS INC, 10-K, 3/30/2020
<!-- page 42 -->
responsible to the other Party for any noncompliance by such representative with such
confidentiality obligations). Each Party may replace its JSC Representatives at any time upon
written notice to the other Party.

5.1.2 Chairperson. The JSC chairperson ("JSC Chairperson") shall be designated from the Parties' JSC
Representatives and shall serve for a term of one (1) year. SFJ shall appoint the first JSC
Chairperson and subsequent appointments will rotate on an annual basis between PB and SFJ. The JSC
Chairperson will be responsible for drafting and circulating the draft agenda and ensuring minutes
are prepared.

5.1.3 Meetings. From the Effective Date, through the date of the Regulatory Approval in the US, at
least one Designated European Country, and either Japan or China, the JSC will meet at least [***]
(and for clarity, such meetings are intended to be conducted via teleconference) unless the Parties
mutually agree otherwise. Either Party may call a special meeting of the JSC (by videoconference or
teleconference) during the Development Term by providing at least [***] prior written notice to the
other Party, which notice shall include a reasonably detailed description of the matter, in the
event such Party reasonably believes that a significant matter must be addressed prior to the next
scheduled meeting.

5.1.4 Participants. The JSC may invite individuals who are not JSC Representatives to participate in
JSC meetings; provided that (a) all JSC Representatives of both Parties consent to such non-member's
participation; and (b) such non-member has executed a confidentiality agreement in form and
substance acceptable to the non-inviting Party (and, for the avoidance of doubt, the inviting Party
shall remain responsible to the non-inviting Party for any noncompliance by such individual with
such confidentiality obligations). For clarity, such non-members will have no voting rights at the
JSC.

5.1.5 Alliance Managers. Each Party shall appoint an individual to act as an alliance manager for
such Party (each, an "Alliance Manager") by providing the name and contact information for the
Alliance Manager to the JSC. Each Party may change its Alliance Manager from time to time in its
sole discretion upon written notice to the JSC. The Alliance Managers shall be the primary point of
contact for the Parties regarding the activities contemplated by the Agreement, and the Parties
shall use reasonable efforts to ensure that any requests for information and data made outside of
the JSC are made through the Alliance Mangers. The Alliance Managers shall attend all meetings of
the JSC. For clarity, the Alliance Managers may also be members of the JSC.

5.1.6 Costs. Each Party will bear its own expenses relating to the meetings and activities of the
JSC.

5.2 JSC Responsibilities and Decision-Making.

5.2.1 Responsibilities (Review and Discuss). The JSC's responsibilities will include reviewing and
discussing (but not approving) the following:

Source: PHASEBIO PHARMACEUTICALS INC, 10-K, 3/30/2020
<!-- page 43 -->
5.2.1.1 Oversight of the Parties' collaboration including (i) overall strategic direction, (ii)
developing strategies to maximize the value of the Product for the Indication, and (iii) reviewing
and commenting on the Development Program and Regulatory Approval strategies;

5.2.1.2 material changes in the Development Program, including changes required by, or made to
respond to comments from, a Regulatory Authority, that do not require approval pursuant to Section
5.2.2.2;

5.2.1.3 the activities related to, the progress of, and the costs incurred in connection with, the
Development Program;

5.2.1.4 summaries of the Research Results;

5.2.1.5 forecast of the estimated timeline (on at least a [***] basis) for its development
activities with respect to the Product for the Indication;

5.2.1.6 the addition to the Development Program of any new Clinical Trials testing the efficacy of
the Product for the Indication; and

5.2.1.7 any other matters the Parties mutually agree in writing will be, or are expressly provided
in this Agreement to be, reviewed and discussed by the JSC.

5.2.2 Responsibilities (Review and Approve). The JSC's responsibilities will include reviewing and
approving (in each case, such approval not to be unreasonably withheld, conditioned or delayed) the
following:

5.2.2.1 the Protocols;

5.2.2.2 [***]:

(a) [***];

(b) [***];

(c) [***];

(d) [***];

(e) [***]; or

(f) [***].

(g) commercially reasonable budgets of CRO and Third Party Vendor costs (the "Approved Third Party
Vendor Costs") and Product Supply Costs.

5.2.2.3 any other matters the Parties mutually agree in writing will be, or are expressly provided
in this Agreement to be, reviewed and approved by the JSC.

Source: PHASEBIO PHARMACEUTICALS INC, 10-K, 3/30/2020
<!-- page 44 -->
The JSC shall use good faith efforts to approve budgets for the Approved Third Party Vendor Costs
and the Product Supply Costs no later than [***].

5.2.3 Limitation on Authority. Notwithstanding anything to the contrary set forth in this Agreement,
the JSC will have no authority to (x) amend, modify or waive compliance with this Agreement, or (y)
resolve any dispute concerning the validity, interpretation, construction of, or breach of this
Agreement.

5.2.4 Decision-Making. PB shall retain sole decision-making authority over all matters within the
scope of the JSC's oversight other than the matters described in the foregoing 5.2.2. The unanimous
approval of the JSC will be required with respect to all matters within its decision-making
authority as described in the foregoing Section 5.2.2. The JSC Representatives of each Party will
collectively have one (1) vote. The presence of at least one of each Party's JSC representatives
constitutes a quorum for the conduct of business at any JSC meeting, and no vote of the JSC may be
taken without a quorum present. If the JSC cannot reach consensus on an issue for which it has
decision-making authority, then PB shall have the final decision-making authority, provided that if
SFJ disagrees with any such PB decision with regard to any of the matters set forth in Section
5.2.2, then, at SFJ's request, the matter shall be escalated to the Executive Officers for attempted
resolution by good faith negotiations during a period of [***]. If, notwithstanding such good faith
negotiations, the Executive Officers fail to resolve such matter prior to expiration of such [***]
negotiation period, and SFJ in good faith continues to disagree with such PB decision, then SFJ
shall have the right to terminate this Agreement as provided in Section 14.2.10 upon written notice
to PB delivered within [***] after expiration of such [***] negotiation period.

5.3 Reports to be Provided to the JSC.

Except as may otherwise be agreed by the Parties, at each JSC meeting PB with regard to the PB
Territory and SFJ with regard to the SFJ Territory will provide an update on the progress of the
Clinical Trials and PB with regard to the U.S. and the Designated European Countries and SFJ with
regard to Japan and China will report on progress toward obtaining Regulatory Approvals.

5.4 Joint Development Committee.

5.4.1 Representatives. Within [***] of the Effective Date, the Parties will establish a joint
development committee to oversee the conduct of the Clinical Trials (the "JDC"). Each Party
initially will appoint [***] to serve as representatives to the JDC (the "JDC Representatives"),
with each JDC Representative having knowledge and expertise regarding developing products similar to
the Product and sufficient seniority within the applicable Party to make decisions within the scope
of the JDC's decision- making authority. Each Party may replace its JDC Representatives at any time
upon written notice to the other Party.

5.4.2 Chairperson. The JDC chairperson ("JDC Chairperson") shall be designated from the Parties' JDC
Representatives and shall serve for a term of [***]. [***] shall

Source: PHASEBIO PHARMACEUTICALS INC, 10-K, 3/30/2020
<!-- page 45 -->
appoint the first JDC Chairperson and subsequent appointments will rotate on [***] basis between SFJ
and PB. The JDC Chairperson will be responsible for drafting and circulating the draft agenda and
ensuring minutes are prepared.

5.4.3 Meetings.

5.4.3.1 Timing.

(i) From the Effective Date through the date of first Regulatory Approval, the JDC will meet at
least once every [***] (and for clarity, such meetings are intended to be conducted via
teleconference) unless the Parties mutually agree otherwise.

(ii) Either Party may call a special meeting of the JDC (by videoconference or teleconference)
during the Development Term by at least [***] prior written notice to the other Party in the event
such Party reasonably believes that a significant matter must be addressed prior to the next
scheduled meeting.

5.4.3.2 Participants. The JDC may invite individuals who are not JDC Representatives to participate
in JDC meetings; provided that (a) the JDC Representatives of both Parties consent to such
non-member's participation; and (b) such non-member is subject to confidentiality obligations
consistent with those described in ARTICLE 11 of this Agreement. For clarity, such non-members will
have no voting rights at the JDC.

5.4.3.3 Costs. For clarity, each Party will bear its own expenses relating to the meetings and
activities of the JDC and such costs will not be Development Costs hereunder.

5.4.4 Notice to be Provided to the JDC.

5.4.4.1 Unusual or Unforeseen Events. Each Party will promptly notify the JDC of any unforeseen or
unusual events that occur in connection with the Clinical Trials that may affect the quality,
integrity, or timeliness of the Clinical Trials.

5.4.4.2 Urgent Safety Measures or Serious Breaches. If either Party becomes aware of (a) any urgent
safety measures taken by a Clinical Investigator to protect Subjects against immediate hazard or (b)
any serious breaches of the Protocol or any Applicable Laws (including ICH GCP guidelines), such
Party will immediately inform the JDC.

5.4.4.3 Regulatory Inspections. Each Party will promptly notify the JDC within [***] of any
inspection by any Governmental Authority, including any Regulatory Authority, in connection with the
Clinical Trials. Each Party will promptly forward to the JDC copies of any inspection findings that
a Site receives from any Regulatory Authority.

5.4.4.4 Government Investigations. Each Party will promptly notify the JDC upon learning of any
investigations by any Governmental Authority in connection with the Clinical Trials.

Source: PHASEBIO PHARMACEUTICALS INC, 10-K, 3/30/2020
<!-- page 46 -->
5.4.4.5 Notification of Error. If either Party learns of an error or omission in the conduct of the
Clinical Trials that could call into question the validity, or otherwise compromise the quality
and/or integrity, of part or all of the Clinical Trials or activities conducted in connection
therewith, such Party will inform the JDC in writing within [***] of either Party learning of such
error and/or omission. The members of the JDC will discuss in good faith a remediation plan to
address such error within [***] of such written notification. Such remediation plan will not be
effective unless and until approved by the JDC (such approval not to be unreasonably withheld or
delayed). If the JDC approves such remediation plan, the JDC will provide each Party with written
notice thereof, specifying the dates on which, and the detail with which the Party responsible for
such Clinical Trial will be required to update the JDC of its progress with respect thereto. If the
JDC is not able to approve such remediation plan, the matter will be decided by the JSC pursuant to
the procedure described in Section 5.2.4.

5.4.4.6 Compliance with Laws. With respect to each of the foregoing Sections 5.4.4.1 through
5.4.4.5, the Party responsible for notifying the JDC will notify the Person to whom notice is
required to comply with all Applicable Laws.

5.4.4.7 Progress Reports. Except as may otherwise be agreed to by the Parties, at each JDC meeting
the Party responsible for such Clinical Trial will provide an update on the progress and cost of
such Clinical Trial and Regulatory Approval as measured against the Timeline.

5.4.4.8 Post-Development Term Notices. Following completion of the Development Term and through the
end of the Term, any and all notices required pursuant to this Section 5.4 will be provided to the
JSC instead of the JDC.

5.4.5 Responsibilities and Decision-Making.

5.4.5.1 Responsibilities. The JDC's responsibilities will include: (a) approving the initial
Protocol (b) approving any changes to the Protocol that requires a submission to a Regulatory
Authority, an IRB or other ethics committees; (c) discussing the activities in connection with, the
progress of, and the costs incurred in connection with, the Clinical Trials, including updates from
any Clinical Investigator Meetings; (d) reviewing and discussing any notices that it receives
pursuant to the foregoing Section 5.4.4; (e) discussing and reviewing the Research Results; (f)
reviewing and discussing on at least a quarterly basis the forecast Development Costs and Timeline;
(g) reviewing and discussing (as necessary) proof of submission of any safety reports to the
Regulatory Authorities, Clinical Investigators, IRBs and any other ethics committees; (h) reviewing
certain data to be provided by each Party at each JDC meeting as requested by the other Party and in
accordance with all Applicable Laws; (i) reviewing performance and progress of the Clinical Trials
and Regulatory Approval process; and (j) any other matters the Parties mutually agree will be, or
are expressly provided in this Agreement to be, within the responsibilities of the JDC.

5.4.5.2 Decision-Making. The unanimous approval of the JDC will be required with respect to all
matters within its decision-making authority as described in the foregoing Section 5.4.5.1. The JDC
Representatives of each Party will collectively have one (1)

Source: PHASEBIO PHARMACEUTICALS INC, 10-K, 3/30/2020
<!-- page 47 -->
vote. The presence of at least one of each Party's JDC representatives constitutes a quorum for the
conduct of business at any JDC meeting, and no vote of the JDC may be taken without a quorum
present. If the JDC cannot reach consensus on an issue for which it has decision-making authority,
then such matter will be escalated to the JSC.

5.5 Joint Commercialization Committee.

5.5.1 Representatives. By [***], the Parties will establish a joint commercialization committee (the
"JCC") to oversee and manage the Commercialization of the Product (excluding direct oversight and
management of commercial manufacture of Product, provided that PB shall keep the JCC reasonably
informed of commercial manufacturing activities), including PB's compliance with its diligence
obligations under the AZ License. Each Party will initially appoint [***] to serve as
representatives on the JCC (the "JCC Representatives"), with each JCC Representative having
knowledge and expertise regarding Commercializing products similar to the Product or knowledge of
PB's Commercialization plans and activities for the Product (as applicable) and being reasonably
acceptable to the other Party. If any such representative is not an employee of the appointing
Party, such representative shall execute a confidentiality agreement in form and substance
acceptable to the other Party (and, for the avoidance of doubt, the appointing Party shall remain
responsible to the other Party for any noncompliance by such representative with such
confidentiality obligations). Each Party may replace its JCC Representatives at any time upon
written notice to the other Party.

5.5.2 Information. PB shall provide to the JCC a draft of each Commercialization Plan (as defined in
the AZ License) at least [***] in advance of the date PB is required to deliver such
Commercialization Plan to MedImmune. The JCC shall promptly review and discuss each draft
Commercialization Plan.

5.5.3 Chairperson. PB shall designate the JCC chairperson ("JCC Chairperson") from its JCC
Representatives. The JCC Chairperson will be responsible for drafting and circulating its Party's
draft agenda and ensuring minutes are prepared.

5.5.4 Meetings. From the Effective Date through the date of the Final Approval Payment, the JCC will
meet at least every two months (and for clarity, such meetings are intended to be conducted via
teleconference), unless the Parties mutually agree otherwise. Either Party may call a special
meeting of the JCC (by videoconference or teleconference) by providing at least five (5) Business
Days' prior written notice to the other Party, which notice shall include a reasonably detailed
description of the matter, in the event such Party reasonably believes that a significant matter
must be addressed prior to the next scheduled meeting.

5.5.5 Participants. The JCC may invite individuals who are not JCC Representatives to participate in
JCC meetings; provided that (a) all [***] JCC Representatives of both Parties consent to such
non-member's participation; and (b) such non-member has executed a confidentiality agreement in form
and substance acceptable to the non-inviting Party (and, for the avoidance of doubt, the inviting
Party shall remain responsible to the non-inviting Party for any noncompliance by such individual
with such confidentiality obligations).

Source: PHASEBIO PHARMACEUTICALS INC, 10-K, 3/30/2020
<!-- page 48 -->
5.5.6 Costs. Each Party will bear its own expenses relating to the meetings and activities of the
JCC.

5.6 JCC Responsibilities and Decision-Making.

5.6.1 Responsibilities. The JCC's responsibilities will include the following:

5.6.1.1 [***].

5.6.1.2 [***];

5.6.1.3 [***];

5.6.1.4 [***];

5.6.1.5 [***]; and

5.6.1.6 Any other matters the Parties mutually agree will be, or are expressly provided in this
Agreement to be, reviewed and discussed by the JCC.

5.6.2 Decision Making. The unanimous approval of the JCC will be required with respect to all
matters within its decision-making authority as described in the foregoing Section 5.6.1. The JCC
Representatives of each Party will collectively have one (1) vote. The presence of at least one of
each Party's JCC representatives constitutes a quorum for the conduct of business at any JCC
meeting, and no vote of the JCC may be taken without a quorum present. If the JCC cannot reach
consensus on an issue for which it has decision-making authority, then such matter will be escalated
to the JSC.

ARTICLE 6

PAYMENTS TO SFJ

6.1 Regulatory Approval. In exchange for the purchase of the Trial Data Package as set forth in
Section 11.1.1.4, PB will pay to SFJ, in US Dollars:

6.1.1 following Regulatory Approval by the FDA, an initial payment in the amount set forth below to
be made within [***] after the date of the Regulatory Approval by the FDA as shown in the table
below (the "Initial US Payment") and annual payments in the amounts set forth below on or before
each applicable anniversary of the date of such Regulatory Approval (collectively but excluding the
Initial US Payment, the "US Approval Payments");

6.1.2 following Regulatory Approval by the EMA, an initial payment in the amount set forth below to
be made within [***] after the date of the Regulatory Approval by the EMA (or, as applicable, by the
national Regulatory Authority in any Designated European Country) as shown in the table below (the
"Initial EU Payment") and annual payments in the amounts set forth below on or before each
applicable anniversary of the date of the such

Source: PHASEBIO PHARMACEUTICALS INC, 10-K, 3/30/2020
<!-- page 49 -->
Regulatory Approval (collectively but excluding the Initial EU Payment, the "EU Approval Payments");
and

6.1.3 following Regulatory Approval by the PMDA or the NMPA, an initial payment in the amount set
forth below to be made within [***] after the date of first Regulatory Approval by the PMDA or the
NMPA as shown in the table below (the "Initial Japan/China Payment") and annual payments in the
amounts set forth below shall be due on each applicable anniversary of the date of such Regulatory
Approval (collectively but excluding the Initial Japan/China Payment, the "Japan/China Approval
Payments");

provided, in each case, that if conditional Regulatory Approval in a geographic territory specified
above in Section 6.1.1, 6.1.2 or 6.1.3 is obtained on the basis of Successful Phase 3 Interim
Analysis but unconditional Regulatory Approval is not obtained (i.e., the accelerated Regulatory
Approval is withdrawn by the applicable Regulatory Authority) in such geographic territory as a
result of failure of the final results of the Phase 3 Trial to meet the Phase 3 Success Criteria or
failure of any other human clinical trial that the applicable Regulatory Authority requires PB to
conduct after the grant of conditional Regulatory Approval as a condition to the grant of
unconditional Regulatory Approval to meet the primary endpoint(s) of such trial and the Product is
required to be withdrawn from the market in such geographic territory, then PB shall have no
obligation to make any additional Approval Payment for such geographic territory that would
otherwise have become due during the period after withdrawal of such conditional Regulatory Approval
and before such time (if ever) as Regulatory Approval for such geographic territory is again
obtained (and for so long thereafter as such Regulatory Approval remains in effect), provided
further that with regard to withdrawal of such conditional Regulatory Approval in [***].

The Initial US Payment, Initial EU Payment, Initial Japan/China Payment, US Approval Payments, EU
Approval Payments and Japan/China Approval Payments are collectively referred to as the "Approval
Payments", and shall be subject to adjustment as provided in Section 6.2. For the sake of clarity,
the Initial Japan/China Payment and each of additional Japan/China Approval Payment set forth in the
table below shall only be paid once regardless of receipt of Regulatory Approval in both Japan and
China.

Approval Payment Schedule

Upon Approval 1yr

Anniversary

2yr

Anniversary

3yr

Anniversary

4yr

Anniversary

5yr

Anniversary

6yr

Anniversary

7yr

Anniversary

8yr

Anniversary Total

FDA Approval 5,000,000 [***] [***] [***] [***] [***] [***] [***] 0 330,000,000

EMA Approval 5,000,000 [***] [***] [***] [***] [***] [***] [***] 0 210,000,000

First Approval by either PMDA or NMPA

1,000,000

[***] [***] [***] [***] [***] [***] [***] [***]

60,000,000

Total 11,000,000 [***] [***] [***] [***] [***] [***] [***] [***] 600,000,000

6.2 Payment Adjustments. In the event that the actual Development Costs paid or incurred by SFJ
hereunder are lower or greater than One Hundred Twenty Million U.S. Dollars ($120,000,000.00),
including by reason of any amount of Going Concern Funding paid by SFJ to

Source: PHASEBIO PHARMACEUTICALS INC, 10-K, 3/30/2020
<!-- page 50 -->
PB in accordance with Section 4.2.4, or in the event that such actual Development Costs are subject
to adjustment pursuant to Section 2.3.3, Section 3.12.2 and/or Section 3.12.3, the Approval Payments
will be multiplied by a fraction, the numerator of which is such actual amount of Development Costs
paid or incurred by SFJ hereunder (as adjusted, to the extent applicable, pursuant to Section 2.3.3,
Section 3.12.2 and/or Section 3.12.3) and the denominator of which is One Hundred Twenty Million
U.S. Dollars ($120,000,000.00). In the event that Regulatory Approval is obtained in a particular
jurisdiction while Development Costs for other jurisdiction(s) are still being paid or incurred, in
which case the Parties shall recalculate the applicable adjustment at such time as the final amount
of actual Development Costs is known and determine any true-up payments required to be made by PB
with respect to any payment made pursuant to Section 6.1 prior to such time, and PB shall pay any
such true-up payment to SFJ within [***] after receipt of invoice from SFJ.

6.3 Method and Timing of Payment. The US Approval Payments, EU Approval Payments and Japan/China
Approval Payments to SFJ will be due as of the applicable annual anniversary of the date of the
applicable Regulatory Approval. SFJ shall deliver invoices to PB for the US Approval Payments, EU
Approval Payments and Japan/China Approval Payments at least [***] before the applicable anniversary
of the date of Regulatory Approval, and such payments will be made by PB on or before the later of
(a) [***] and (b) [***] following delivery of such invoices, by wire transfer to SFJ's account that
SFJ shall designate on such invoice. PB will provide SFJ with written notice of each wire transfer
to SFJ's account. All amounts payable and calculations under this Agreement shall be in US dollars.

6.4 Late Payments. If PB fails to pay any amount due under this Agreement on the due date therefore,
then, without prejudice to any other remedies that SFJ may have, that amount will bear interest from
the due date until payment of such amount is made, both before and after any judgment, at a rate
equal to, [***] percent ([***]%) per annum computed on the basis of a year of 360 days for the
actual number of days payment is delinquent or if such rate exceeds the maximum amount permitted by
Applicable Law, at such maximum rate.

6.5 Taxes. The Parties hereby acknowledge and agree that payments made under this Agreement will be
made without reduction for withholding or similar taxes, unless such withholding or similar tax is
required (x) by a taxing authority as a result of an audit or examination, (y) due to the assignment
of this Agreement or any payment obligation hereunder (to the extent permitted) by SFJ to an
Affiliate or Third Party, or (z) as a result of a change in Applicable Laws at any time during the
Term. In such case, the Parties shall use commercially reasonable and legal efforts to mitigate the
amount of such taxes that would need to be withheld and/or paid. Any amounts withheld pursuant to
this Section 6.5 will be timely paid over to the appropriate taxing authority, and will be treated
for purposes of this Agreement as having been paid to the Party that otherwise would have received
such amounts. In the event of a "determination" within the meaning of Section 1313(a) of the Code
that withholding or similar taxes were required but were not properly withheld, the Party that
received the relevant payment will indemnify and hold the other Party harmless with respect to such
taxes and related Losses.

Source: PHASEBIO PHARMACEUTICALS INC, 10-K, 3/30/2020
<!-- page 51 -->
6.6 Tax Cooperation. The Parties will cooperate and produce on a timely basis any tax forms or
reports, including any IRS Forms W-8BEN or W-9, as applicable, reasonably requested by the other
Party in connection with any payment made under this Agreement. Each Party will provide to the other
Party any tax forms that may be reasonably necessary in order for such Party not to withhold tax or
to withhold tax at a reduced rate under an applicable bilateral income tax treaty. Each Party will
provide to the other Party any tax forms at least [***] prior to the due date for any such payments.
Each Party will provide the other with commercially reasonable assistance to enable the recovery, as
permitted by law, of withholding taxes, VAT, or similar obligations resulting from payments made
under this Agreement, such recovery to be for the benefit of the Party bearing such withholding tax
or VAT. Each Party will provide commercially reasonable cooperation to the other Party, at the other
Party's expense, in connection with any official or unofficial tax audit or contest relating to tax
payments made with respect to amounts paid or payable to such other Party under this Agreement.

6.7 Buy-Out Option.

6.7.1 Approval Buy-Out Option. Within one hundred and twenty (120) days following the receipt of
Regulatory Approval with respect to each of the US, Designated European Countries, and Japan/China,
PB shall have the right to make a one-time payment (each, an "Approval Buy-Out Payment") in lieu of
all (but not less than all) Approval Payments (as adjusted in accordance with Section 6.2) for the
applicable country(ies) (other than the Initial US Payment, Initial EU Payment or Initial
Japan/China Payment, as applicable, payable pursuant to Section 6.1 as a result of such Regulatory
Approval, in each case, as adjusted in accordance with Section 6.2) by written notice delivered to
SFJ no later than [***] after the date of such Regulatory Approval, which written notice shall set
forth the amount of the applicable Approval Buy-Out Payment, the proposed date of closing (which
shall occur within [***] after the date of the Regulatory Approval), and the calculation of the
Approval Buy-Out Payment in reasonable detail based upon the proposed closing date. The Approval
Buy-Out Payment will be calculated as follows:

[***]

Each Approval Buy-Out Payment will be payable in one installment in cash at the closing to an
account specified by SFJ. The discount rate used to calculate each Approval Buy-Out Payment shall be
[***] percent ([***]%).

6.7.2 Change of Control Buy-Out Option. Within one hundred and twenty (120) days following the
closing of a Change of Control, PB or its successor shall have the right to make a one-time payment
(the "Change of Control Buy-Out Payment") in lieu of all (but not less than all) remaining Approval
Payments for the applicable country(ies) in which Regulatory Approval has been received as of the
date of closing of such Change of Control, provided that SFJ has not previously assigned the right
to receive the Approval Payments to a Third Party, in which event PB or its successor shall not have
such right. To exercise its right to make the Change of Control Buy-Out Payment, PB or its successor
shall provide written notice to SFJ (the "Change of Control Buy-Out Notice") no later than [***]
after the date of closing of such Change of Control, which written notice shall set forth the amount
of the applicable Change of

Source: PHASEBIO PHARMACEUTICALS INC, 10-K, 3/30/2020
<!-- page 52 -->
Control Buy-Out Payment, the proposed date of closing of the buy-out (which shall occur within [***]
after the date of closing of such Change of Control), and the calculation of the Change of Control
Buy-Out Payment in reasonable detail based upon the proposed closing date of the buy-out. The Change
of Control Buy-Out Payment will be calculated as follows:

[***]

The Change of Control Buy-Out Payment will be payable in one installment in cash at the closing to
an account specified by SFJ. The discount rate used to calculate each Change of Control Buy-Out
Payment shall be [***] percent ([***]%). For the avoidance of doubt, the Change of Control Buy-Out
Payment shall only apply with regard to Approvals which have already been obtained prior to the
Change of Control.

ARTICLE 7

SECURITY INTEREST

7.1 Grant of Security Interest. As security for the payment and performance of the PB Obligations,
PB hereby grants to SFJ, effective upon PB's receipt of the Initial Development Cost Payment on the
Initial Funding Date, a security interest in all of PB's right, title and interest (excluding any
leasehold interest) in, to and under all of its property, wherever located and whether now existing
or owned or hereafter acquired or arising, including all goods, accounts (including health-care
receivables), equipment, inventory, contract rights or rights to payment of money, leases, license
agreements, franchise agreements, general intangibles, intellectual property (including, for the
avoidance of doubt, all PB Intellectual Property), commercial tort claims, documents, instruments
(including any promissory notes), chattel paper (whether tangible or electronic), cash, deposit
accounts, certificates of deposit, fixtures, letters of credit rights (whether or not the letter of
credit is evidenced by a writing), securities, and all other investment property, supporting
obligations, and financial assets, whether now owned or hereafter acquired, wherever located; and
all of PB's books and records relating to the foregoing, and any and all claims, rights and
interests in any of the above and all substitutions for, additions, attachments, accessories,
accessions and improvements to and replacements, products, proceeds and insurance proceeds of any or
all of the foregoing (collectively, the "SFJ Collateral"). Anything herein to the contrary
notwithstanding, in no event shall the SFJ Collateral include, and PB shall not grant and shall not
be deemed to have granted a security interest in, (1) any property to the extent that such grant of
security interest is prohibited by any Applicable Law of a Governmental Authority or constitutes a
breach or default under or results in the termination of or requires any consent not obtained under,
any contract, license, agreement, instrument or other document evidencing or giving rise to such
property, except to the extent that such Applicable Law or the term in such contract, license,
agreement, instrument or other document providing for such prohibition, breach, default or
termination or requiring such consent is ineffective under Section 9-406, 9-407, 9-408 or 9- 409 of
the Uniform Commercial Code in effect in the State of Delaware (or any successor provision or
provisions) of any relevant jurisdiction or any other Applicable Law (including bankruptcy or
insolvency statutes) or principles of equity; provided, however, that such security interest shall
attach immediately at such time as such Applicable Law

Source: PHASEBIO PHARMACEUTICALS INC, 10-K, 3/30/2020
<!-- page 53 -->
is not effective or applicable, or such prohibition, breach, default or termination is no longer
applicable or is waived, and to the extent severable, shall attach immediately to any portion of the
SFJ Collateral that does not result in such consequences or (2) any of PB's rights, title or
interest in any of the outstanding voting capital stock or other ownership interests of a CFC in
excess of 65% of the voting power of all classes of capital stock or other ownership interests of
CFC entitled to vote. This Agreement shall create a continuing security interest in the SFJ
Collateral which shall remain in effect until all PB Obligations (other than contingent indemnity
obligations) have been paid or otherwise satisfied in full in accordance with this Agreement and/or,
if applicable, the Program Transfer Agreement. Upon payment or other satisfaction of all PB
Obligations (other than contingent obligation), SFJ shall, at the sole cost and expense of PB,
release its Liens in the SFJ Collateral and all rights therein shall revert to PB.

7.2 Priority of Security Interest. PB represents, warrants and covenants that, subject to fulfilment
of PB's obligations under Section 7.4 and SFJ making any filings necessary to achieve such
perfection, the security interest granted to SFJ pursuant to this ARTICLE 7 (the "SFJ Security
Interest") on the Initial Funding Date shall be and shall at all times thereafter continue to be a
first- priority perfected security interest in the SFJ Collateral (subject only to the lien of SVB
arising under the SVB Loan Agreement, subject in all respects to the terms and conditions of the
subordination agreement contemplated by Section 7.4 hereof, and other Permitted Liens that are
permitted pursuant to the terms of this Agreement).

7.3 Authorization to File Financing Statements. PB hereby authorizes SFJ to file, on or at any time
from time to time after PB's receipt of the Initial Development Cost Payment on the Initial Funding
Date, and PB shall execute and deliver to SFJ (as applicable), financing statements, amendments to
financing statements, continuation financing statements, termination statements, security agreements
relating to the SFJ Collateral constituting intellectual property, fixture filings (if applicable),
notices and other documents and instruments, in form satisfactory to SFJ as SFJ may reasonably
request, to perfect and continue perfected, maintain the priority of or provide notice of SFJ's
security interest in the SFJ Collateral and to accomplish the purpose of this Agreement, without
notice to PB, with all appropriate jurisdictions located within the United States and the Designated
European Countries. Such financing statements may indicate the SFJ Collateral as substantially the
same as the SFJ Collateral described in Section 7.1 or words of similar effect, or as being of an
equal or lesser scope, or with greater detail, all in SFJ's reasonable discretion.

7.4 Subordination to SVB Loan. On or before the Initial Funding Date, PB shall negotiate in good
faith and enter into a subordination agreement with SVB and SFJ reflecting in all material respects
the terms described on Exhibit P attached hereto, pursuant to which SFJ will subordinate to SVB all
PB Obligations and all Liens in the SFJ Collateral in favor of SFJ of indebtedness of PB to SVB,
which agreement shall (a) limit the aggregate principal amount of indebtedness of PB to SVB that
will be senior to SFJ at [***], (b) include a provision pursuant to which in certain circumstances
SFJ shall be entitled in its discretion to purchase or repay all obligations (other than contingent
indemnity obligations) owing by PB to SVB arising under or in connection with the SVB Loan Agreement
in exchange for a release of SVB's Liens on PB's assets, (c) include an obligation on the part of
SFJ to, in connection with any refinancing or

Source: PHASEBIO PHARMACEUTICALS INC, 10-K, 3/30/2020
<!-- page 54 -->
replacement of the SVB Loan Agreement, enter into a new subordination agreement with a new lender(s)
on terms and conditions that are taken as a whole not less favorable in any material respect to SFJ
than those set forth in the subordination agreement to be entered into with SVB, and (d) otherwise
be in form and substance reasonably satisfactory to SFJ. Upon the execution of such new
subordination agreement with such new lender(s), references herein to "SVB" shall refer to such new
lender(s), references herein to the "SVB Loan" shall refer to the loans provided by such new lender
(provided that the aggregate principal amount of such loans shall not exceed [***]), references
herein to the "SVB Collateral" shall refer to the collateral securing such new loan, and references
herein to the "SVB Loan Agreement" shall refer to such loan and security agreement or similar
document entered into with such new lender(s).

7.5 Negative Covenants.

7.5.1 Incurrence of Certain Indebtedness. PB shall not, without SFJ's prior written consent, create,
incur, assume, or be liable for any Indebtedness, or permit any subsidiary of PB to do so, other
than Permitted Indebtedness.

7.5.2 Subordinated Debt. PB shall not (a) make or permit any payment on any Subordinated Debt,
except to the extent permitted by the terms of the subordination, intercreditor, or other similar
agreement to which such Subordinated Debt is subject, or (b) amend any provision in any document
relating to Subordinated Debt which would provide for earlier or greater principal, interest, or
other cash payments thereon, or materially adversely affect the subordination thereof to PB
Obligations owed to SFJ.

7.5.3 Encumbrances. PB shall not, without SFJ's prior written consent:

7.5.3.1 create, incur, allow, or suffer any Lien on any of the PB Intellectual Property, or assign
or convey any right to receive income with respect to the PB Intellectual Property (other than
royalty and other license fee obligations to licensors thereof in accordance with the applicable
license agreement), including the sale of any PB Intellectual Property, or permit any of its
subsidiaries to do so, other than Liens in favor of SVB (subject in all respects to the terms and
conditions of the subordination agreement contemplated by Section 7.4 hereof) and other Permitted
Liens that are permitted pursuant to the terms of this Agreement; or

7.5.3.2 except as and to the extent permitted by Section 7.5.6, enter into any agreement, document,
instrument or other arrangement (except with or in favor of SFJ or SVB) with any Person which
directly or indirectly prohibits or has the effect of prohibiting PB or any subsidiary of PB from
assigning, mortgaging, pledging, granting a security interest in or upon or encumbering any proceeds
from PB Intellectual Property.

7.5.4 Distributions; Investments. PB shall not, without SFJ's prior written consent, (a) pay any
dividends or make any distribution or payment on account of or redeem, retire or purchase any
capital stock, provided that (i) PB may convert any of its equity convertible securities into other
equity securities (or cash for partial shares) pursuant to the terms of such equity convertible
securities or otherwise in exchange thereof, (ii) PB may pay dividends

Source: PHASEBIO PHARMACEUTICALS INC, 10-K, 3/30/2020
<!-- page 55 -->
solely in common stock, and (iii) PB may repurchase the stock of former employees or consultants
pursuant to stock repurchase agreements, provided that the aggregate amount of all such repurchases
does not exceed [***] Dollars ($[***]) per fiscal year; or (b) directly or indirectly make any
Prohibited Investment (including, without limitation, by the formation of or through any
subsidiary), or permit any of its subsidiaries to do so. For the avoidance of doubt, nothing in this
Section 7.5.4 shall limit the ability of PB to pay or settle on conversion (in cash or equity) any
convertible indebtedness.

7.5.5 Licensing Transactions. PB shall have the right, without SFJ's consent, to enter into any
Excluded Licensing Transaction. PB shall not, without SFJ's prior written consent, enter into a
Licensing Transaction unless such Licensing Transaction is an Excluded Licensing Transaction (in
which case such prohibition shall not apply and no such consent of SFJ shall be required); provided
that SFJ shall only be entitled to withhold such consent as to a Licensing Transaction other than an
Excluded Licensing Transaction in the event SFJ reasonably determines, and provides PB with written
notice of its determination within [***] of PB providing to SFJ a non-binding term sheet or
comparable document summarizing the material terms of the proposed Licensing Transaction [***], that
PB entering into such Licensing Transaction would [***] ("Material Impact"). If PB disagrees with
SFJ's determination, the matter shall be submitted to arbitration before a single neutral arbitrator
under the American Arbitration Association's (AAA's) expedited arbitration rules, which arbitrator
shall be mutually agreeable to both Parties and have significant expertise on the subject matter to
be decided (provided that if the Parties have not mutually agreed on such arbitrator within [***]
after the applicable demand for arbitration, the AAA shall designate such arbitrator), such
arbitration to be concluded and the arbitrator's award to be rendered within [***] of the applicable
demand for arbitration. The sole issue to be decided in the arbitration shall be whether the entry
into such Licensing Transaction by PB would have a substantial likelihood of having a Material
Impact. In the event the arbitrator agrees with SFJ, PB shall not be entitled to enter into such
Licensing Transaction. In the event the arbitrator agrees with PB, PB shall be entitled to enter
into the Licensing Transaction; [***], and, [***].

7.5.6 Sales of Royalty Streams. PB shall not sell, transfer or assign, directly or indirectly, in
whole or in part, any rights to receive payments of royalties or license fees with respect to the
Product or the PB Intellectual Property (including any Accounts with respect to such royalties or
license fees), other than to a wholly owned direct or indirect subsidiary of PB (it being understood
that the foregoing shall not restrict the creation of any Permitted Lien).

7.5.7 Further Negative Pledges. PB shall not, from and after the Effective Date, enter into any
agreement that prohibits or limits the ability of PB to create, incur, assume or suffer to exist any
Lien upon any PB Intellectual Property (including any Accounts with respect to such royalties or
license fees), whether now owned or hereafter acquired, to secure the PB Obligations, other than (a)
agreements with SFJ (including this Agreement), (b) any agreements governing purchase money Liens or
capital lease obligations otherwise permitted hereby (in which case, any such prohibition or
limitation shall only be effective on the assets financed thereby), (c) customary restrictions on
assignment contained in leases, licenses or other

Source: PHASEBIO PHARMACEUTICALS INC, 10-K, 3/30/2020
<!-- page 56 -->
agreements or (d) the SVB Loan Agreement and any loan documents entered into in connection
therewith.

7.6 Affirmative Covenants. PB shall do all of the following:

7.6.1 Execution of Additional Security Agreements and Other Further Assurances.

7.6.1.1 PB shall, upon request of SFJ from time to time hereafter, execute such security agreements,
stock pledge agreements, deposit account control agreements, and take such further action, as
reasonably required to perfect or continue the SFJ Security Interest or to effect the purposes of
this ARTICLE 7, including without limitation by taking the following actions:

(a) (i) PB shall execute and deliver to SFJ, promptly upon PB's receipt of the Initial Development
Cost Payment on the Initial Funding Date, such patent and trademark security agreements as SFJ may
reasonably request, in each case in form and substance reasonably acceptable to SFJ (each an "IP
Security Agreement"), and shall record such agreements with the U.S. Patent and Trademark Office,
and shall take such other action as may be necessary or as SFJ may reasonably request to perfect
SFJ's security interest in any Intellectual Property of PB in existence as of the Effective Date
constituing SFJ Collateral. (ii) Within [***] of the last day of [***], PB shall notify SFJ in
writing of [***], and [***].

(b) No later than [***] after PB's receipt of the Initial Development Cost Payment on the Initial
Funding Date, PB shall deliver to SFJ fully executed deposit account control agreements or
securities account control agreements, as applicable, in favor of SFJ in form and substance
reasonably satisfactory to SFJ with respect to all deposit accounts (as such term is defined in the
UCC, each a "Deposit Account") and securities accounts (as such term is defined in the UCC, each a
"Securities Account" and collectively with any Deposit Account, each a "Collateral Account")
maintained within the United States by PB, including without limitation the Collateral Accounts set
forth on Schedule 7.6.1.1(b) to that certain disclosure letter, dated as of the Effective Date,
delivered by PB to SFJ (the "Disclosure Letter"). PB represents and warrants to SFJ that, as of the
Effective Date, it maintains no Collateral Accounts other than the Collateral Accounts described on
Schedule 7.6.1.1(b) to the Disclosure Letter. In addition to and without limiting the foregoing, PB
shall provide SFJ with [***] prior written notice before establishing any additional Collateral
Account at or with any bank or financial institution. For each such additional Collateral Account
that PB at any time maintains after PB's receipt of the Initial Development Cost Payment on the
Initial Funding Date, PB shall cause the applicable bank or financial institution at or with which
any Collateral Account is maintained to execute and deliver a deposit account control agreement,
securities account control agreement or other appropriate instrument with respect to such account to
perfect SFJ's Lien in such account in accordance with the terms hereunder within [***] after the
opening of each such account (or, if later, [***] after PB's receipt of the Initial Development Cost
Payment on the Initial Funding Date), which agreement may not be terminated without the prior
written consent of SFJ. The provisions of this Section 7.6.1.1(b) shall not apply to deposit
accounts exclusively used for payroll, payroll taxes, and other employee wage and benefit

Source: PHASEBIO PHARMACEUTICALS INC, 10-K, 3/30/2020
<!-- page 57 -->
payments to or for the benefit of SFJ employees and identified to SFJ by PB as such. Except to the
extent permitted by the preceding sentence, PB shall [***]:

(i) [***] prior to [***];

(ii) [***] after [***]; and

(iii) [***] after [***].

For the avoidance of doubt, the Parties agree that [***].

7.6.1.2 PB shall obtain such consents from SVB and WestRiver Innovation Lending Fund VIII, L.P. as
are required by the SVB Loan Agreement to grant a security interest in the SFJ Collateral to SFJ and
to incur the PB Obligations as set forth herein (the "SVB Consent"). The failure of PB to obtain the
SVB Consent within [***] of the Effective Date shall be deemed to be a Material Adverse Event.

7.6.2 Government Compliance.

7.6.2.1 Maintain its and all its subsidiaries' legal existence and good standing in their respective
jurisdictions of formation and maintain qualification in each jurisdiction in which the failure to
so qualify would reasonably be expected to have a material adverse effect on PB's business or
operations, provided that any subsidiary may liquidate or dissolve so long as such liquidation or
dissolution would not reasonably be expected to have a material adverse effect on PB's consolidated
business or operations, and provided that in connection with such liquidation or dissolution all
assets and property of any such subsidiary shall be transferred to PB or another subsidiary of PB.
PB shall comply, and shall cause each subsidiary to comply, in all material respects, with all laws,
ordinances and regulations to which it is subject noncompliance with which would reasonably be
expected to have a material adverse effect on PB's business.

7.6.2.2 Obtain all of the Governmental Approvals, if any, necessary for the grant of a security
interest to SFJ in the SFJ Collateral.

7.6.3 Regulatory Compliance. PB shall not become an "investment company" or a company "controlled"
by an "investment company" under the Investment Company Act of 1940, as amended. PB shall not become
engaged as one of its important activities in extending credit for margin stock (under Regulations
X, T and U of the Federal Reserve Board of Governors). Neither PB's nor any of its Subsidiaries'
properties or assets shall be used by PB or any Subsidiary in disposing, producing, storing,
treating, or transporting any hazardous substance other than legally. PB and each of its
subsidiaries shall obtain all consents, approvals and authorizations of, make all declarations or
filings with, and give all notices to, all Governmental Authorities that are necessary to continue
their respective businesses as currently conducted, unless such failure could not reasonably be
expected to have a material adverse effect on PB's business.

Source: PHASEBIO PHARMACEUTICALS INC, 10-K, 3/30/2020
<!-- page 58 -->
7.6.4 Protection of Intellectual Property Rights. PB shall use Commercially Reasonable Efforts in
the exercise of its business judgment to prosecute, protect, defend and maintain the validity and
enforceability of the PB Intellectual Property.

7.6.5 Acceleration. In the event that, following an applicable Regulatory Approval, PB shall fail to
make any Approval Payment associated with such Regulatory Approval within [***] of the due date
therefor in accordance with ARTICLE 6, all remaining unpaid Approval Payments that are based on such
Regulatory Approval shall become immediately due and payable; provided that, in the event of any
such acceleration, SFJ's rights to receive such Approval Payments, if any, shall be adjusted as set
forth in Section 6.2 and reduced by any amounts previously paid to SFJ.

7.7 Certain Defined Terms. As used in this ARTICLE 7 and elsewhere in this Agreement:

7.7.1 "PB Obligations" means all indebtedness, liabilities and other obligations of PB to SFJ under
or in connection with this Agreement and any other documents executed in connection herewith,
including, without limitation, all amounts payable to SFJ pursuant to ARTICLE 6 hereof, all interest
accrued thereon, all fees and all other amounts payable by PB to SFJ thereunder or in connection
therewith, whether now existing or hereafter arising, and whether due or to become due, absolute or
contingent, liquidated or unliquidated, determined or undetermined, and including interest that
accrues after the commencement by or against PB of any bankruptcy or insolvency proceeding naming
such individual or entity as the debtor in such proceeding, and including performing the PB Services
but excluding obligations under the Warrant.

7.7.2 "Contingent Obligation" is, for any Person, any direct or indirect liability, contingent or
not, of that Person for (a) any indebtedness, letter of credit or other Indebtedness of another
Person, in each case, directly or indirectly guaranteed, endorsed or co-made by that Person, or for
which that Person is directly or indirectly liable; (b) any obligations for undrawn letters of
credit for the account of that Person; and (c) all obligations from any interest rate, currency or
commodity swap agreement, interest rate cap or collar agreement, or other agreement or arrangement
designated to protect a Person against fluctuation in interest rates, currency exchange rates or
commodity prices, but only to the extent such transaction is entered into for speculative purposes
(and not to mitigate any risk to which PB or any subsidiary is subject). The amount of a Contingent
Obligation is the stated or determined amount of the primary obligation for which the Contingent
Obligation is made or, if not determinable, the maximum reasonably anticipated liability for it
determined by the Person in good faith; but the amount may not exceed the maximum of the obligations
under any guarantee or other support arrangement.

7.7.3 "Indebtedness" means (a) indebtedness for borrowed money or the deferred price of property or
services (excluding accounts payable incurred in the ordinary course of business, earn-out or
similar obligations with respect to deferred purchase price and deferred compensation), (b)
obligations evidenced by notes, bonds, debentures or similar instruments, (c) capital lease
obligations (as such term is understood under GAAP as in effect on

Source: PHASEBIO PHARMACEUTICALS INC, 10-K, 3/30/2020
<!-- page 59 -->
the date of this Agreement, but excluding obligations treated as operating leases prior to adoption
of changes described by ASC Topic 842) and (d) Contingent Obligations.

7.7.4 "Investment" means any beneficial ownership interest in any Person (including stock,
partnership interest or other securities), and any loan, advance or capital contribution to any
Person.

7.7.5 "Lien" means a mortgage, deed of trust, levy, charge, pledge, security interest or other
encumbrance of any kind, whether voluntarily incurred or arising by operation of law or otherwise
against any property.

7.7.6 "Permitted Indebtedness" means:

7.7.6.1 PB Obligations;

7.7.6.2 Indebtedness owed to SVB pursuant to the SVB Loan Agreement, subject in all respects to the
terms and conditions of the subordination agreement contemplated by Section 7.4 hereof;

7.7.6.3 Subordinated Debt;

7.7.6.4 unsecured Indebtedness;

7.7.6.5 Indebtedness incurred as a result of endorsing negotiable instruments received in the
ordinary course of business;

7.7.6.6 Indebtedness secured by Liens permitted under subsections 7.7.7.1 and 7.7.7.3 of the
definition of "Permitted Liens" hereunder;

7.7.6.7 Letters of credit issued for the payment of purchase obligations for equipment, materials
and inventory and for the payment of equipment and real estate lease obligations (including security
deposits in connection therewith); and

7.7.6.8 Other Indebtedness not to exceed [***] in the aggregate at any time outstanding.

7.7.7 "Permitted Liens" means:

7.7.7.1 Liens in favor SVB pursuant to the SVB Loan Agreement (subject in all respects to the terms
and conditions of the subordination agreement contemplated by Section 7.4 hereof) and Liens in favor
of SFJ;

7.7.7.2 Liens for taxes, fees, assessments or other government charges or levies, either (i) not due
and payable or (ii) being contested in good faith and for which PB maintains adequate reserves on
its books and records, provided that no notice of any such Lien has been filed or recorded under the
IRC;

Source: PHASEBIO PHARMACEUTICALS INC, 10-K, 3/30/2020
<!-- page 60 -->
7.7.7.3 Purchase money Liens or capital leases (i) on equipment acquired or held by PB incurred for
financing the acquisition of the equipment securing no more than [***] in the aggregate amount
outstanding, or (ii) existing on equipment when acquired, if the Lien is confined to the property
and improvements and the proceeds of the equipment;

7.7.7.4 Leases or subleases of real property granted in the ordinary course of PB's business (or, if
referring to another Person, in the ordinary course of such Person's business), and leases,
subleases, non-exclusive licenses or sublicenses of personal property (other than Intellectual
Property) granted in the ordinary course of PB's business (or, if referring to another Person, in
the ordinary course of such Person's business), if the leases, subleases, licenses and sublicenses
do not prohibit granting SFJ a security interest therein;

7.7.7.5 Interests of lessors and licensors under leases and licenses to PB of real property and
personal property;

7.7.7.6 The Existing Licenses;

7.7.7.7 Excluded Licensing Transactions;

7.7.7.8 Liens of carriers, warehousemen, suppliers, or other Persons that are possessory in nature
arising in the ordinary course of business so long as such Liens attach only to inventory, securing
liabilities in the aggregate amount which are not delinquent or remain payable without penalty or
which are being contested in good faith and by appropriate proceedings which proceedings have the
effect of preventing the forfeiture or sale of the property subject thereto;

7.7.7.9 Liens to secure payment of workers' compensation, employment insurance, old-age pensions,
social security and other like obligations incurred in the ordinary course of business (other than
Liens imposed by ERISA);

7.7.7.10 Liens arising from attachments or judgments, orders, or decrees occurring after the
Effective Date in circumstances not constituting or arising from a Fundamental Breach by PB;

7.7.7.11 Liens in favor of financial institutions arising in connection with PB's deposit and/or
securities accounts held at such institutions, provided that SFJ has a first priority perfected
security interest in the amounts held in such deposit and/or securities accounts;

7.7.7.12 Liens incurred in the extension, renewal or refinancing of the indebtedness secured by
Liens described in Sections 7.7.7.1 through 7.7.7.11 (excluding Liens securing the SVB Loan, solely
to the extent of any obligations thereunder permitted in accordance with the terms and conditions of
the subordination agreement contemplated by Section 7.4 hereof), but any extension, renewal or
replacement Lien must be limited to the property encumbered by the existing Lien and the principal
amount of the indebtedness may not increase;

Source: PHASEBIO PHARMACEUTICALS INC, 10-K, 3/30/2020
<!-- page 61 -->
7.7.7.13 Deposits securing bids or contracts;

7.7.7.14 Liens securing the payment of purchase obligations for equipment, materials and inventory
and for the payment of equipment and real estate lease obligations (including security deposits in
connection therewith); and

7.7.7.15 Other Liens securing liabilities in an aggregate amount not to exceed [***].

7.7.8 "Prohibited Investment" means:

7.7.8.1 Investments in equity interests including convertible notes of privately held companies
(other than wholly owned subsidiaries of PB and, where Applicable Law prevents whole ownership,
other than subsidiaries that are wholly owned by PB except for nominal Third Party ownership that is
required under Applicable Law);

7.7.8.2 Investments in or purchases of any real property (excluding real property to be occupied or
used by PB or its subsidiaries) commercial or residential mortgages or mortgage backed securities;

7.7.8.3 Investments in auction rate securities, corporate high yield bonds (i.e. less than BBB
quality), precious metals, derivatives including margin trades, options, futures, options on
futures, short sales, forward contracts, swaps, repurchase agreements and reverse repurchase
agreements (but excluding, in each case, interest rate, currency or commodity swap agreements,
interest rate caps or collar agreements, or other agreements or arrangements designed to protect a
Person against fluctuation in interest rates, currency exchange rates or commodity prices not
entered into for speculative purposes); and

7.7.8.4 [***].

7.7.9 "SFJ Collateral" has the meaning set forth in Section 7.1.

7.7.10 "Subordinated Debt" means indebtedness incurred by PB that is subordinated to any PB
Obligations (pursuant to a subordination, intercreditor, or other similar agreement in form and
substance reasonably satisfactory to SFJ entered into between SFJ and the other creditor), on terms
reasonably acceptable to SFJ.

ARTICLE 8

WARRANT ISSUANCE

8.1 Warrant Issuance. PB shall issue to SFJ on the Effective Date a warrant ("Warrant") exercisable
for two million two hundred thousand (2,200,000) shares of PB common stock ("Stock") at an exercise
price per share ("Exercise Price") equal to the greater of (a) five dollars ($5.00) or (b) 120% of
the volume weighted average closing price of the Stock over the thirty (30) consecutive trading days
ending on the last trading day immediately preceding the Effective Date and exercisable as follows:
(i) one million one hundred thousand (1,100,000)

Source: PHASEBIO PHARMACEUTICALS INC, 10-K, 3/30/2020
<!-- page 62 -->
shares may be exercised at any time after the Effective Date provided that any such shares may be
transferred by SFJ to its Affiliates but may not be resold by SFJ or its Affiliates until one (1)
year after the Effective Date and (ii) one million one hundred thousand (1,100,000) shares may be
exercised at any time after the date of Successful Phase 3 Interim Analysis.

8.2 Form of Warrant. The Warrant shall in the form attached hereto as Exhibit H, shall have a term
of ten (10) years, and shall contain "net-exercise" issuance provisions.

ARTICLE 9

RECORDS

9.1 Accounting. Each Party will maintain materially complete and accurate accounting records related
to this Agreement in accordance with GAAP. Each Party will retain such records for [***] after the
earlier of expiration or early termination of this Agreement.

9.2 Clinical Trials-Related Records. Each Party shall, and shall cause its Affiliates and its and
their Permitted Third Parties conducting Development of the Product to, maintain, in good scientific
manner, complete and accurate books and records pertaining to Development of the Product hereunder,
in sufficient detail to verify compliance with its obligations under this Agreement. Such books and
records shall (a) be appropriate for patent and regulatory purposes, (b) be in compliance with
Applicable Law, (c) properly reflect all work done and results achieved in the performance of its
Development activities hereunder, and (d) be retained by such Party for such period as may be
required by Applicable Law.

ARTICLE 10

CONFIDENTIAL INFORMATION

10.1 Confidentiality. Except to the extent expressly authorized by this Agreement or otherwise
agreed in writing by the Parties (including, if applicable, in the Program Transfer Agreement), each
Party (each, a "Receiving Party") agrees that, during the Term and for the [***] period following
the expiration or termination of this Agreement (except that the obligations will survive thereafter
with respect to any Confidential Information that constitutes a trade secret under Applicable Law)
or such longer periods for which such Confidential Information may be maintained pursuant to ARTICLE
9, it will keep confidential and will not publish or otherwise disclose and will not use for any
purpose other than as provided for in this Agreement or, if applicable, the Program Transfer
Agreement (which includes the exercise of any rights or the performance of any obligations hereunder
or thereunder) any Confidential Information furnished to it by or on behalf of the other Party
(each, a "Disclosing Party") or its Affiliates in connection with this Agreement or, if applicable,
the Program Transfer Agreement. The foregoing obligations will not apply to any portion of such
information or materials that the Receiving Party can demonstrate:

10.1.1 was publicly disclosed by the Disclosing Party before or after such Confidential Information
becomes known to the Receiving Party;

Source: PHASEBIO PHARMACEUTICALS INC, 10-K, 3/30/2020
<!-- page 63 -->
10.1.2 was already known to the Receiving Party or any of its Affiliates, other than under an
obligation of confidentiality or non-use, prior to when it was received from the Disclosing Party;

10.1.3 is subsequently disclosed to the Receiving Party or any of its Affiliates by a Third Party
lawfully in possession thereof without obligation to keep such Confidential Information
confidential;

10.1.4 has been published by a Third Party or otherwise enters the public domain through no fault of
the Receiving Party or any of its Affiliates in breach of this Agreement; or

10.1.5 has been independently developed by the Receiving Party or any of its Affiliates, without the
aid, application or use of any Confidential Information of the other Party.

10.2 Authorized Disclosure. Each Party may disclose Confidential Information belonging to the other
Party to the extent such disclosure is reasonably necessary for complying with Applicable Laws,
including regulations promulgated by securities exchanges, provided that the Party required to
disclose such information promptly notifies the Disclosing Party prior to making any such disclosure
and cooperates with the Disclosing Party's efforts to seek confidential treatment or to otherwise
limit disclosure. Each Receiving Party may disclose the other Party's Confidential Information to
its Affiliates, employees, agents, advisors, and independent contractors (including Permitted Third
Parties) engaged by such Receiving Party, in each case (a) only to the extent such Persons need to
know the Confidential Information solely in connection with the performance of this Agreement or, if
applicable, the Program Transfer Agreement and (b) provided that each Person receiving Confidential
Information must be bound by obligations of confidentiality and non-use at least as stringent as an
equivalent in scope to those set forth in this ARTICLE 10 prior to any such disclosure and the Party
making such disclosure to such Person shall be liable to the other Party for any breach of such
obligations by such disclosee. PB may disclose SFJ Confidential Information to MedImmune as
necessary to comply with PB's obligations or exercise PB's rights under the AZ License (it being
understood that any such disclosure will be made under the terms of Article 6 of the AZ License and
that PB shall not be required to enter into any further confidentiality agreement with MedImmune for
such purpose). Each Party may also disclose the material terms of this Agreement (including the form
of Program Transfer Agreement) or provide a copy of this Agreement or a summary of such Party's
findings during its due diligence investigation of the Products (if applicable) to any bona fide
potential or actual investor, investment banker, acquirer, provider of debt or royalty financing, or
other potential or actual financial partner without consent of the other Party, and provided that in
connection with such disclosure, each disclosee must be bound by obligations of confidentiality and
non-use at least as stringent as an equivalent in scope to those set forth in this ARTICLE 10 prior
to any such disclosure and the Party making such disclosure to such disclosee shall be liable to the
other Party for any breach of such obligations by such disclosee. Notwithstanding anything in the
foregoing to the contrary, Exhibit D constitutes PB's Confidential Information and not SFJ's
Confidential Information, and PB may disclose Exhibit D to Third Parties as determined by PB in its
sole discretion. In any event, each Party agrees to

Source: PHASEBIO PHARMACEUTICALS INC, 10-K, 3/30/2020
<!-- page 64 -->
take all reasonable action to avoid unauthorized use or disclosure of Confidential Information of
the other Party hereunder.

10.3 Return of Confidential Information. Except as otherwise provided herein, upon expiration or
earlier termination of this Agreement, all Confidential Information (including any copies thereof)
in written or other tangible form will, at the Disclosing Party's direction, be returned to the
Disclosing Party or destroyed by the Receiving Party, and any Person(s) to whom the Receiving Party
disclosed (with such destruction being certified in writing by an authorized officer of the
Receiving Party), except (i) to the extent such Confidential Information is necessary to exercise
any license and/or rights hereunder that survive such expiration or earlier termination; and (ii)
one (1) copy of each document may be retained by the Receiving Party solely to the extent necessary
to permit it to comply with any ongoing rights and responsibilities with respect to such
Confidential Information.

10.4 MedImmune Confidential Information. With respect to any Confidential Information of PB that
constitutes MedImmune Confidential Information, SFJ hereby agrees to be bound by the provisions of
Sections 6.1, 6.2 and 6.7 of the AZ License to the same extent as PB is.

10.5 Confidential Status of the Agreement. Subject to Section 10.2 and Section 10.6, the terms of
this Agreement, including the form of Program Transfer Agreement (whether or not executed by the
Parties), are deemed to be Confidential Information and will be subject to the confidentiality
requirements of this ARTICLE 10, with each Party being deemed a Receiving Party for such purposes.
The Parties each acknowledge that it will be necessary for PB to file this Agreement with the US
Securities and Exchange Commission and to make other required public disclosures regarding the terms
of this Agreement, and accordingly PB shall prepare a confidential treatment request in connection
with such filing and provide SFJ a reasonable opportunity to review and comment on such filing as
well as on such other required public disclosures and thereafter use Commercially Reasonable Efforts
to obtain confidential treatment as to the terms of this Agreement.

10.6 Publicity. The Parties recognize that following the Effective Date the Parties (either
individually or jointly) shall issue mutually agreed press release(s) announcing the execution of
this Agreement, and thereafter each Party may from time to time desire to issue additional press
releases and make other public statements or disclosures regarding the subject matter of this
Agreement, and hereby agree that such additional press releases, public statements and disclosures
regarding the terms of this Agreement will be permitted only with the other Party's written consent
(which shall not be unreasonably withheld, conditioned or delayed). Any publication, news release or
other public announcement relating to the terms of this Agreement will first be reviewed and
approved in writing by both Parties; provided, however, that any disclosure of the minimum
information which is required by Applicable Law (including the rules of a securities exchange), as
reasonably advised by the disclosing Party's counsel, may be made without the prior consent of the
other Party, although the other Party will be given prompt notice of any such legally required
disclosure and to the extent practicable will be provided an opportunity to comment on the proposed
disclosure and the disclosing Party will consider in

Source: PHASEBIO PHARMACEUTICALS INC, 10-K, 3/30/2020
<!-- page 65 -->
good faith any comments provided by the other Party on such proposed disclosure. For avoidance of
doubt, this Section 10.6 shall not restrict PB from releasing public statements or disclosures
regarding PB's development and Commercialization activities with respect to the Product.

10.7 Use of Name. Unless otherwise expressly permitted herein, PB will obtain the written consent of
SFJ (which consent will not unreasonably be withheld, conditioned or delayed) prior to referring to
SFJ in any correspondence with any Regulatory Authority or Governmental Authority, except as may be
required by Applicable Law. SFJ agrees to be bound by Section 6.3 of the AZ License to the same
extent as PB is.

ARTICLE 11

INTELLECTUAL PROPERTY AND PERSONALLY IDENTIFIABLE INFORMATION

11.1 Ownership and Rights.

11.1.1 Ownership.

11.1.1.1 Existing Intellectual Property. Subject to Section 11.1.1.2, it is agreed between the
Parties that each Party will retain all right, title and interest in, to and under all Intellectual
Property that is Controlled by such Party as of the Effective Date.

(a) Without limiting the generality of the foregoing, as between the Parties, PB shall be and remain
the sole and exclusive owner of all right, title and interest in and to all PB Intellectual Property
existing as of the Effective Date ("Existing PB Intellectual Property"), including, in the case of
Patents within the Existing PB Intellectual Property ("Existing PB Patents"), all patent
applications filed after the Effective Date that claim priority to, or are foreign counterparts of,
patent applications within the Existing PB Patents ("Corresponding PB Patent Applications") and all
Patents that may issue or be granted from any patent application within the Existing PB Patents or
any Corresponding PB Patent Application after the Effective Date. In addition, PB shall be and
remain the sole and exclusive owner of all right, title and interest in and to all PB Intellectual
Property arising during the term of this Agreement independent of the conduct of the activities
contemplated by this Agreement.

(b) SFJ acknowledges that the PB Intellectual Property includes Licensed Know-How and Licensed
Patents licensed to PB pursuant to, and subject to the terms and conditions of, the AZ License. SFJ
further acknowledges and agrees that, as required by the AZ License, MedImmune shall own and retain
all right, title and interest in and to any and all Licensed Know-How and Licensed Patents
(including Patents that become Licensed Patents pursuant to the last two sentences of Section 5.1.2
of the AZ License). SFJ shall, and hereby does, assign to MedImmune and will cause each of its
officers, directors, employees and Affiliates, and its and their respective Permitted Third Parties,
to assign to MedImmune all right, title and interest in and to all Patents filed by or on behalf of
PB claiming any Licensed Know-How, without additional compensation, as is necessary to fully effect
the

Source: PHASEBIO PHARMACEUTICALS INC, 10-K, 3/30/2020
<!-- page 66 -->
sole ownership provided for in the second sentence of this Section 11.1.1.1(b). In the event of any
conflict between the terms of this Agreement (including the form of Program Transfer Agreement) and
the terms of the AZ License, in each case, as applicable to Licensed Know-How or Licensed Patents,
the terms of the AZ License shall prevail.

11.1.1.2 MedImmune Intellectual Property.

(a) SFJ acknowledges and agrees that, as required by the AZ License, MedImmune shall own and retain
all right, title and interest in and to any and all AstraZeneca Product Improvements, AstraZeneca
Product Know-How and AstraZeneca Product Patents. SFJ shall, and hereby does, assign to MedImmune
and will cause each of its officers, directors, employees and Affiliates, and its and their
respective Permitted Third Parties, to assign to MedImmune all right, title and interest in and to
all (i) AstraZeneca Product Improvements that are conceived, discovered, developed or otherwise made
by or on behalf of SFJ or any of its Affiliates (including by any of their respective Third Party
contractors), (ii) AstraZeneca Product Know-How generated by or on behalf of SFJ or any of its
Affiliates (including by any of their respective Third Party contractors), and (iii) AstraZeneca
Product Patents claiming any such AstraZeneca Product Improvement(s) or AstraZeneca Product
Know-How; in each case, without additional compensation, as is necessary to fully effect the sole
ownership provided for in the first sentence of this Section 11.1.1.2(a).

(b) SFJ shall cause each employee, individual consultant and Third Party contractor that SFJ or its
Affiliate proposes to engage to conduct any Clinical Trial activity under or in connection with this
Agreement (including, if applicable, in connection with the Program Transfer Agreement) on its
behalf who conceives, discovers, develops or otherwise makes any AstraZeneca Product Improvement
under or in connection with activities conducted pursuant to this Agreement to be under an
obligation to assign to PB their rights in any such AstraZeneca Product Improvement, so that PB may
comply with its obligations with respect to AstraZeneca Improvements, AstraZeneca Product Know-How
and AstraZeneca Product Patents under the AZ License. If (i) SFJ is unable to cause any such Third
Party contractor or consultant (including any contractor who is, or a consultant who is employed by,
a governmental, not-for-profit, or public institution that has standard policies against such an
assignment) to agree to such assignment obligation with respect to AstraZeneca Product Improvements
despite SFJ's using commercially reasonable efforts to negotiate such assignment obligation, or (ii)
Applicable Law would prohibit SFJ from requiring such an assignment from such Third Party contractor
or consultant, in each case ((i) and (ii)), SFJ and its Affiliates shall refrain from using such
Third Party contractor or consultant to conduct activities pursuant to this Agreement unless PB
obtains MedImmune's written consent thereto.

(c) The Parties acknowledge and agree that in the event of any conflict between the terms of this
Agreement and the terms of the AZ License, in each case, as applicable to AstraZeneca Product
Improvements, AstraZeneca Product Know-How or AstraZeneca Product Patents, the terms of the AZ
License shall prevail.

Source: PHASEBIO PHARMACEUTICALS INC, 10-K, 3/30/2020
<!-- page 67 -->
11.1.1.3 Trial Inventions.

(a) PB shall be the exclusive and sole owner of, and retain all right, title and interest in and to,
all Trial Inventions (which shall constitute PB Intellectual Property), regardless of inventorship.
SFJ will promptly disclose, and will cause its Affiliates and all Permitted Third Parties engaged by
SFJ or its Affiliates to perform any of SFJ's obligations hereunder promptly to disclose, to PB in
writing in reasonable detail each Trial Invention made, developed, created, generated, conceived or
reduced to practice in whole or in part by or on behalf of SFJ, such Affiliate or such Permitted
Third Party, which written disclosure shall include all available information and data necessary to
support the filing of patent applications Covering such Trial Invention. SFJ, for itself and on
behalf of its Affiliates, hereby assigns, and shall cause such other Permitted Third Parties to
assign (subject to Section 11.1.1.3(c)), to PB all its right, title and interest in and to Trial
Inventions and all information and data necessary to support the filing of patent applications
Covering such Trial Inventions. SFJ will cooperate, and will cause the foregoing Persons to
cooperate, with PB to effectuate and perfect the foregoing ownership, including by promptly
executing and recording assignments and other documents consistent with such ownership.

(b) SFJ shall cause each employee and individual consultant of such SFJ or its Affiliates (but
excluding Permitted Third Parties of SFJ and its Affiliates, which are separately addressed in
Section 11.1.1.3(c)) who conceives, discovers, develops or otherwise makes any Trial Invention to be
under an obligation to assign to PB their rights in any such Trial Invention. In the case of any
individual consultant of SFJ or its Affiliates (excluding SFJ's and its Affiliates' Permitted Third
Parties), if SFJ is unable to cause such consultant to agree to such assignment obligation despite
SFJ's using commercially reasonable efforts to negotiate such assignment obligation, then SFJ shall
either: (A) cause such consultant to grant an exclusive, worldwide, royalty-free, fully-paid,
freely-assignable license, with the right to sublicense through multiple tiers, under their rights
in such Trial Invention to develop, make, have made, use, sell, have sold, offer for sale and import
the Product for any and all uses, except where Applicable Law requires otherwise and except in the
case of consultants who are employed by governmental, not- for-profit, or public institutions that
have standard policies against such an assignment (in which case, SFJ shall use commercially
reasonable efforts to obtain a suitable license, or right to obtain such a license); or (B) refrain
from using such consultant to conduct activities pursuant to this Agreement unless PB obtains
MedImmune's written consent thereto.

(c) SFJ shall use commercially reasonable efforts to obtain from each Third Party contractor that
SFJ or its Affiliate proposes to engage to conduct activities under or in connection with this
Agreement on behalf of SFJ or its Affiliates (i) an assignment, (ii) an exclusive, worldwide,
royalty-free, fully-paid, freely-assignable license, with the right to sublicense through multiple
tiers, or (iii) a non‑exclusive, worldwide, royalty-free, fully-paid, freely-assignable license,
with the right to sublicense through multiple tiers ((i) through (iii) in order of preference), to
PB of any Trial Invention that such Third Party contractor conceives, discovers, develops or
otherwise makes in connection with activities conducted relating to this Agreement. The Parties
acknowledge that it may not be possible to obtain such assignment or license from any such Third
Party contractor with respect to technology of broad applicability to

Source: PHASEBIO PHARMACEUTICALS INC, 10-K, 3/30/2020
<!-- page 68 -->
the operation of such Third Party contractor's business or improvements, or improvements to such
Third Party contractor's own proprietary technology used in the performance of services on behalf of
SFJ or its Affiliate, in each case, on acceptable terms or at all, and accordingly, the Parties
agree that the inability of SFJ or its Affiliate, despite the use of commercially reasonable
efforts, to obtain such assignment or license from a Third Party contractor on acceptable terms or
at all shall not constitute a breach of SFJ's obligations under this Agreement.

11.1.1.4 Trial Data Package. SFJ shall be the sole and exclusive owner of the Trial Data Package
including the Research Results included therein. In consideration of the Approval Payments to be
made under this Agreement (if and to the extent applicable), and in further consideration of the
payment by PB to SFJ of [***], SFJ shall sell and transfer to PB, and PB shall acquire from SFJ, the
sole and exclusive ownership, even as to SFJ, of the Trial Data Package including all Research
Results as set forth below in this Section 11.1.1.4. Upon the earliest of (A) receipt of Regulatory
Approval of the Product for the Indication in at least one of the US, the EU, any Designated
European Country, Japan or China or (B) termination of this Agreement in accordance with any
termination clause or section of this Agreement, in each case, PB and SFJ will promptly enter into
the Trial Data Package Purchase Agreement attached hereto as Exhibit K, and PB will purchase, and
SFJ will sell to PB, sole and exclusive ownership of all Research Results, including the Trial Data
Package.

11.1.1.5 Inventorship; Further Assurances. Inventorship of Trial Inventions will be determined
according to the principles of US patent law. SFJ agrees to cooperate fully, to cause its Affiliates
to cooperate fully, and to use Commercially Reasonable Efforts to cause its and their respective
Permitted Third Parties to cooperate fully, in each case: (a) with PB in the preparation, filing,
prosecution and maintenance of Patents Covering Trial Inventions; and (b) with MedImmune in the
preparation, filing, prosecution and maintenance of Patents (x) Covering AstraZeneca Product
Improvements described in clause (i) of Section 11.1.1.2(a) or AstraZeneca Product Know-How
described in clause (ii) of Section 11.1.1.2(a) or (y) filed by or on behalf of PB claiming any
Licensed Know-How. Such cooperation includes executing all papers and instruments, or requiring its
employees, consultants and Permitted Third Parties, to execute such papers and instruments, so as to
(i) effectuate (A) the ownership of AstraZeneca Product Improvements, AstraZeneca Product Know-How
and AstraZeneca Product Patents set forth in Section 11.1.1.2, (B) the ownership of Patents that
become Licensed Patents pursuant to the last two sentences of Section 5.1.2 of the AZ License as set
forth in Section 11.1.1.1(b), and (C) the ownership of Trial Inventions set forth in Section
11.1.1.3(a), including Patents claiming or disclosing Trial Inventions, and (ii) enable (A)
MedImmune to apply for and to prosecute patent applications claiming AstraZeneca Product
Improvements and Patents that become Licensed Patents pursuant to the last two sentences of Section
5.1.2 of the AZ License in any country and (B) PB to apply for and to prosecute patent applications
claiming Trial Inventions in any country.

11.1.1.6 No Other Rights. The delivery or disclosure by or on behalf of PhaseBio to SFJ of any
information or materials hereunder will not be construed to grant SFJ any rights or license to use
any Intellectual Property Controlled by PB other than as necessary to comply with its obligations
hereunder or as expressly set forth herein. Except as otherwise

Source: PHASEBIO PHARMACEUTICALS INC, 10-K, 3/30/2020
<!-- page 69 -->
expressly permitted in this Agreement, SFJ may not use, publish or otherwise disclose any
Intellectual Property Controlled by PB without PB's prior written consent.

11.2 Patent Prosecution. As between SFJ and PB, PB will have sole and exclusive right to prepare,
file, prosecute and maintain all Patents within the PB Intellectual Property, including all Patents
that cover the Trial Inventions, at its own expense (provided that PB shall use Commercially
Reasonable Efforts to prosecute and maintain such Patents). At PB's request and expense (for
reasonable out-of-pocket expenses), SFJ will reasonably cooperate with PB in preparing, filing,
prosecuting, and maintaining such Patents.

11.3 Intellectual Property Enforcement.

11.3.1 PB Intellectual Property. PB will use Commercially Reasonable Efforts to enforce Intellectual
Property Controlled by PB, including Intellectual Property that covers the Trial Inventions, against
Third Party Infringements.

11.3.2 Infringement of Third Party Rights. If either Party learns of Third Party allegations that it
or the other Party or any of its or the other Party's Affiliates or Permitted Third Parties, have
infringed, misappropriated or otherwise violated, or are infringing, misappropriating or otherwise
violating, any Intellectual Property of a Third Party in connection with either the Clinical Trials
or performing its obligations or duties hereunder, such Party will promptly notify the other Party.
PB will have sole control and responsibility of, and discretion with respect to, such allegations
and any related actions and/or litigation.

11.4 Personally Identifiable Information.

11.4.1 In conducting the Clinical Trials and its other obligations under this Agreement and, if
applicable, the Program Transfer Agreement, each Party will comply, and will use Commercially
Reasonable Efforts to require each applicable Permitted Third Party of such Party to comply, with
Applicable Laws relating to privacy or data protection applicable to such Party or the Clinical
Trials being conducted by or on behalf of such Party, including ensuring that all necessary (a)
consents from Clinical Investigators, Subjects and any others from whom Personally Identifiable
Information will be received are obtained; (b) regulatory notifications are filed in all countries
for which Sites have been selected; and (c) approvals are obtained in all countries for which Sites
have been selected, prior to collection or transfer of such Personally Identifiable Information.
Without prejudice to the generality of the foregoing, each Party shall (i) work together with the
other Party in good faith to ensure the information referred to in applicable laws and, if
applicable, in particular Articles 13 and 14 of the General Data Protection Regulation (2016/679)
("GDPR") is made available to data subjects (as defined in the GDPR) in relation to the processing
of their Personally Identifiable Information by either Party when acting as a data controller (as
defined in the GDPR), and the information is in a concise, transparent, intelligible and easily
accessible form, using clear and plain language as required by Article 12 of the GDPR; (ii) if
either Party (the "Data Receiving Party") receives any complaint, notice or communication from a
supervisory authority (as defined in the GDPR) which relates directly or indirectly to the other
Party's (A) processing of the Personally Identifiable Information; or (B) potential failure to
comply with the provisions of the GDPR, the Data Receiving Party shall,

Source: PHASEBIO PHARMACEUTICALS INC, 10-K, 3/30/2020
<!-- page 70 -->
to the extent permitted by law, promptly forward the complaint, notice or communication to the other
Party and provide the other Party with reasonable co-operation and assistance in relation to the
same; (iii) if a data subject makes a written request to a Party to exercise their rights in
relation to their Personally Identifiable Information that concerns processing in respect of which
the other Party is the data controller, that Party shall forward the request to the other Party
promptly and in any event within [***] from the date on which it received the request and, upon the
other Party's reasonable written request, provide that other Party with reasonable co-operation and
assistance in relation to that request to enable the other to respond to such request and meet
applicable timescales set out under the GDPR; (iv) if either Party becomes aware of a personal data
breach (as defined in the GDPR), it shall notify the other Party without undue delay, and each Party
shall co-operate with the other, to the extent reasonably requested, in relation to any
notifications to supervisory authorities or to data subjects which either Party is required to make
under the GDPR.

11.4.2 Each Party will not process, and will use Commercially Reasonable Efforts to require each
applicable Permitted Third Party of such Party to not process, any Personally Identifiable
Information in a way that is contrary to Applicable Laws or any Informed Consent.

11.4.3 Each Party will use Commercially Reasonable Efforts to maintain, and will use Commercially
Reasonable Efforts to require each applicable Permitted Third Party of such Party to maintain,
appropriate and sufficient technical and organizational security measures to maintain the
confidentiality of Personally Identifiable Information and to protect such data against accidental
or unlawful destruction or accidental loss, damage, alteration, unauthorized disclosure or access,
in particular where such data is transmitted over a network. These technical and organizational
security measures shall ensure a level of security appropriate to the risk, including, as
appropriate, (a) pseudonymisation and encryption; (b) the ability to ensure the ongoing
confidentiality, integrity, availability and resilience of processing systems and services; (c) the
ability to restore the availability and access to the Personally Identifiable Information in a
timely manner in the event of a physical or technical incident; and (d) a process for regularly
testing, assessing and evaluating the effectiveness of those measures.

11.4.4 Each Party shall notify the other Party of: (a) any unauthorized use or disclosure or breach
of any Personally Identifiable Information promptly upon discovery of such occurrence; and (b) the
transmittal of any related breach notification to any affected person, Governmental Authority or the
media. Each Party will use Commercially Reasonable Efforts to require each applicable Permitted
Third Party of such Party to notify the such Party of: (i) any unauthorized use or disclosure or
breach of any Personally Identifiable Information promptly upon discovery of such occurrence and
(ii) the transmittal of any related breach notification to any affected person, Governmental
Authority or the media.

Source: PHASEBIO PHARMACEUTICALS INC, 10-K, 3/30/2020
<!-- page 71 -->
ARTICLE 12

INDEMNIFICATION AND INSURANCE

12.1 Indemnification by Each Party.

12.1.1 By SFJ. SFJ will indemnify and hold PB; its Affiliates and their respective officers,
directors, employees and agents (the "PB Indemnified Parties"), harmless from any and all Losses,
net of any related tax benefit actually realized in the same year as the payment or incurrence of
such Losses or any prior year, arising or resulting from any Claims by a Third Party against any PB
Indemnified Parties to the extent arising from (a) the gross negligence or willful misconduct of SFJ
or any of its Affiliates or any of its or their respective Permitted Third Parties in performing
SFJ's obligations under this Agreement or, if applicable, the Program Transfer Agreement; (b) SFJ's
material breach of this Agreement or, if applicable, the Program Transfer Agreement; (c) any
material breach of a Protocol by SFJ, or its Affiliate, or any of its or their respective Permitted
Third Parties; (d) any breach by SFJ of any provision of the AZ License by which SFJ has agreed to
be bound in this Agreement; (e) a physical injury or death of a subject that is caused by the
subject's participation in any clinical trial conducted by or on behalf of SFJ or any of its
Affiliates after a Program Transfer whether or not directly attributable to the Product(other than
the Product manufactured by PB); and/or (f) from any after any Program Transfer, product liability
claims resulting from the Commercialization of Product other than Product manufactured by PB by or
on behalf of SFJ or any of its Affiliates, licensees or sublicensees; except to the extent that any
of the foregoing (a) through (f) was caused by (i) the gross negligence or willful misconduct of any
PB Indemnified Party, or (ii) material breach of this Agreement, or, if applicable, the Program
Transfer Agreement, by PB.

12.1.2 By PB. PB will indemnify and hold SFJ, its Affiliates, SFJ's investors and their respective
officers, directors, employees and agents (the "SFJ Indemnified Parties"), harmless from any and all
Losses, net of any related tax benefit actually realized in the same year as the payment or
incurrence of such Losses or any prior year, arising or resulting from any Claims by a Third Party
against any SFJ Indemnified Parties to the extent arising from (a) a Product supplied by PB; (b) a
physical injury or death of a Subject that is caused by the Subject's participation in the Clinical
Trials whether or not directly attributable to the Product (excluding any Clinical Trial conducted
by or on behalf of SFJ or its Affiliate after a Program Transfer); (c) PB's gross negligence or
willful misconduct in performing its obligations under this Agreement or, if applicable, the Program
Transfer Agreement; (d) PB's material breach of this Agreement or, if applicable, the Program
Transfer Agreement, (e) any material breach of a Protocol by PB, or its Affiliate, or of its or
their respective Permitted Third Parties, (f) actual or alleged infringement of any Third Party's
Intellectual Property by the Product or by either Party in performing its duties or obligations
hereunder with respect to the Product; and (g) injuries sustained by Subjects in connection with the
Clinical Trials, including Claims arising prior to the Effective Date based upon physical injury or
death of a Subject in connection with the Clinical Trials, or from the Commercialization of the
Product; except to the extent that any of the foregoing (a) through (g) were caused by (i) the gross
negligence or willful misconduct of any

Source: PHASEBIO PHARMACEUTICALS INC, 10-K, 3/30/2020
<!-- page 72 -->
SFJ Indemnified Party, or (ii) material breach of this Agreement, or, if applicable, the Program
Transfer Agreement by, SFJ.

12.2 Indemnification Procedure.

12.2.1 Notice of Claim. A Party believing that it is entitled to indemnification under Section
12.1.1 or 12.1.2 (an "Indemnified Party") will give prompt written notice (each, an "Indemnification
Claim Notice") to the other Party (the "Indemnifying Party") upon receipt of notice of the
commencement of any Claim for which indemnification may be sought, or if earlier, upon the assertion
of any such Claim by a Third Party (it being understood and agreed, however, that the failure by an
Indemnified Party to give notice of a Claim of a Third Party as provided in this Section 12.2.1 will
not relieve the Indemnifying Party of its indemnification obligation under this Agreement except and
only to the extent that such Indemnifying Party is actually prejudiced as a result of such failure
to give notice). Each Indemnification Claim Notice will contain a description of the Claim and the
nature and amount of the Loss (to the extent that the nature and amount of such Loss are known at
such time). The Indemnified Party will furnish promptly to the Indemnifying Party copies of all
papers and official documents received in respect of any Losses.

12.2.2 Control of Defense. At its option, the Indemnifying Party may assume the defense of any Claim
by giving written notice to the Indemnified Party within [***] after the Indemnifying Party's
receipt of an Indemnification Claim Notice. The assumption of the defense of a Claim by the
Indemnifying Party will not be construed as an acknowledgment that the Indemnifying Party is liable
to indemnify the Indemnified Party in respect of the Claim, nor will it constitute a waiver by the
Indemnifying Party of any defenses it may assert against the Indemnified Party's claim for
indemnification. Upon assuming the defense of a Claim, the Indemnifying Party may appoint as lead
counsel in the defense of the Claim any legal counsel selected by the Indemnifying Party that is
reasonably satisfactory to the Indemnified Party. In the event the Indemnifying Party assumes the
defense of a Claim, the Indemnified Party will promptly deliver to the Indemnifying Party all
original notices and documents (including court papers) received by the Indemnified Party in
connection with the Claim. Should the Indemnifying Party assume the defense of a Claim, the
Indemnifying Party will not be liable to the Indemnified Party for any legal expenses subsequently
incurred by such Indemnified Party in connection with the analysis, defense or settlement of such
Claim.

12.2.3 Right to Participate in Defense. Without limiting Section 12.2.2, the Indemnified Party will
be entitled to (a) participate in, but not control, the defense of such Claim and to engage counsel
of its choice for such purpose; provided, however, that such engagement will be at the Indemnified
Party's own expense unless the engagement thereof has been specifically authorized by the
Indemnifying Party in writing, and (b) control its defense of such Claim and to engage counsel of
its choice for such purpose, at the expense of the Indemnifying Party, if the Indemnifying Party has
failed to assume the defense and engage counsel in accordance with Section 12.2.2.

12.2.4 Settlement. With respect to any Losses related solely to payment of money damages in
connection with a Claim and that includes a complete and unconditional

Source: PHASEBIO PHARMACEUTICALS INC, 10-K, 3/30/2020
<!-- page 73 -->
release of the Indemnified Party, will not result in the Indemnified Party admitting liability,
becoming subject to injunctive or other equitable relief that will otherwise adversely affect the
business of the Indemnified Party in any manner, and as to which the Indemnifying Party will have
acknowledged in writing the obligation to indemnify the Indemnified Party hereunder, the
Indemnifying Party will have the sole right to consent to the entry of any judgment, enter into any
settlement or otherwise dispose of such Loss, on such terms as the Indemnifying Party, in its sole
discretion, will deem appropriate. With respect to all other Losses in connection with Claims, where
the Indemnifying Party has assumed the defense of the Claim in accordance with Section 12.2.2, the
Indemnifying Party will have authority to consent to the entry of any judgment, enter into any
settlement or otherwise dispose of such Loss provided it obtains the prior written consent of the
Indemnified Party (which consent will not be unreasonably withheld, conditioned or delayed). The
Indemnifying Party will not be liable for any settlement or other disposition of a Loss by the
Indemnified Party that is reached without the written consent of the Indemnifying Party (which
consent will not be unreasonably withheld, conditioned or delayed). Regardless of whether the
Indemnifying Party chooses to defend or prosecute any Claim, the Indemnified Party will not admit
any liability with respect to, or settle, compromise or discharge, any Claim without the prior
written consent of the Indemnifying Party, not to be unreasonably withheld or delayed.

12.2.5 Cooperation. Regardless of whether the Indemnifying Party chooses to defend or prosecute any
Claim, the Indemnified Party will reasonably cooperate in the defense or prosecution thereof and
will furnish such records, information and testimony, provide such witnesses and attend such
conferences, discovery proceedings, hearings, trials and appeals as may be reasonably requested in
connection therewith. Such cooperation will include access during normal business hours afforded to
the Indemnifying Party to, and reasonable retention by the Indemnified Party of, records and
information that are reasonably relevant to such Claim, and making employees and agents available on
a mutually convenient basis to provide additional information and explanation of any material
provided hereunder, and the Indemnifying Party will reimburse the Indemnified Party for all its
reasonable out-of-pocket expenses in connection therewith.

12.3 Insurance.

12.3.1 Generally. Commencing as of the Effective Date and thereafter during the Development Term,
and subject to Section 12.3.2 below, each Party will carry and maintain, at its own expense,
insurance coverage of the kind and with liability limits that, at a minimum, satisfy the
requirements of Section 12.3.2, to protect itself and the other Party against any claims or
liabilities that may arise from the conduct of the Clinical Trials and all other rights and
obligations hereunder with insurers with a minimum "A-" A.M. Best rating. Any deductibles for such
insurance policies will be assumed by the insuring Party. Such insurance policies will be primary
and non-contributing with respect to any other similar insurance policies available to other Party
and their Affiliates. Prior to the Effective Date, and annually, at each anniversary of the
Effective Date (unless, during such year, expiration of the applicable policy occurs first, in which
case, on such expiration date), at a Party's written request the other Party will supply
documentation of such insurance coverage via original certificates of insurance, if applicable.

Source: PHASEBIO PHARMACEUTICALS INC, 10-K, 3/30/2020
<!-- page 74 -->
Each Party will provide the other Party a minimum of [***] prior written notice if it is unable to
obtain appropriate insurance coverage or if its coverage is canceled, unable to be renewed or
materially changed. For clarity, any insurance coverage or the failure to maintain adequate
insurance coverage does not limit or reduce a Party's liability under this Agreement. Each Party
will ensure that no subcontractor, including any Permitted Third Party, will continue to perform the
work unless such subcontractor is insured as deemed appropriate by the Party engaging the Permitted
Third Party.

12.3.2 Minimum Requirements. Commencing as of the start of the Clinical Trials and thereafter,
during the Term (or longer if otherwise stated below), at a minimum, each Party will maintain the
following types of insurance coverage at a minimum level that is the greater of (a) the highest
minimum level required by Applicable Law in the countries in which the Clinical Trials and other
obligations hereunder are being performed or (b) the following (to the extent different).

12.3.2.1 Commercial General Liability: [***] dollars ($[***]) per occurrence; [***] dollars ($[***])
Product and Completed Operations aggregate, including Premises & Operations, Personal Injury,
Product and Completed Operations; [***] dollars ($[***]) combined single limit on all owned,
non-owned and hired vehicles of such Party.

12.3.2.2 Umbrella Excess Liability: [***] dollars ($[***]) per occurrence.

12.3.2.3 Clinical Trials Liability: [***] dollars ($[***]) per occurrence. PB will obtain such
Clinical Trials Liability insurance on a global basis, and, if required, supplemented Clinical
Trials Liability Insurance in the US, at its expense and SFJ will obtain supplemental Clinical
Trials Liability insurance for the SFJ Territory and on a country specific basis in the European
Clinical Trial Countries as required by Applicable Law at its expense, which will be considered
Development Costs. Coverage must be maintained for as long as required by Applicable Law in each
country after release of the last Subject from the Clinical Trials or where there is no legal
requirement at least [***] after the termination of this Agreement.

12.3.2.4 Professional Liability: Any subcontractor, including any Permitted Third Party, who
provides professional services to such Party for the Clinical Trials, will obtain Professional
Liability Insurance in lieu of Clinical Trial Insurance, with a minimum limit of [***] dollars
($[***]) per occurrence. Coverage must be maintained for at least [***] after the later of (i)
expiration or early termination of this Agreement and (ii) release of the last Subject from the
Clinical Trials.

12.3.3 Additional Insured. Each Party will include the other Party and its Affiliates as additional
insured parties on such Party's Clinical Trial Liability insurance, as set forth in Section 12.3.2.3
for [***] after the later of termination of this Agreement or release of the last Subject from the
Clinical Trials.

12.3.4 Product Liability Insurance. Prior to a Program Transfer, PB will be responsible for
maintaining product liability insurance related to the Development and

Source: PHASEBIO PHARMACEUTICALS INC, 10-K, 3/30/2020
<!-- page 75 -->
Commercialization of the Product at its expense with SFJ to be named as an additional insured party.
From and after a Program Transfer, SFJ will be responsible for maintaining product liability
insurance related to the Development and Commercialization of the Product at its expense with PB to
be named as an additional insured party.

ARTICLE 13

REPRESENTATIONS AND WARRANTIES

13.1 Representations, Warranties and Covenants of Both Parties.

13.1.1 Each Party hereby represents and warrants that it has the requisite corporate power and
authority to enter into this Agreement and that this Agreement constitutes a legal and valid
obligation binding upon such Party, enforceable in accordance with its terms.

13.1.2 Each Party hereby represents and warrants that it is not a party to any agreement that would
prevent it from fulfilling its obligations under this Agreement.

13.1.3 Each Party agrees, on behalf of itself and its Affiliates, and its and their respective
officers, directors, employees, agents, representatives, consultants, and Permitted Third Parties
engaged in connection with the subject matter of this Agreement ("Representatives"), that for the
performance of its obligations hereunder:

13.1.3.1 such Party, its Affiliates and its and their respective Representatives shall comply with
the Anti- Corruption Laws and shall not take any action that will, or would reasonably be expected
to, cause the other Party or its Affiliates to be in violation of any Anti-Corruption Laws; and

13.1.3.2 such Party shall promptly provide the other Party with written notice of the following
events: (a) upon becoming aware of any breach or violation by such Party, its Affiliate or any of
its or their respective Representatives of any representation, warranty or undertaking set forth in
Section 13.1.3.1, or (b) upon receiving a formal notification that it is the target of a formal
investigation by a Governmental Authority for a Material Anti-Corruption Law Violation or upon
receipt of information from any of its Representatives connected with this Agreement that any of
them is the target of a formal investigation by a governmental authority for a Material
Anti-Corruption Law Violation.

13.1.4 Each Party certifies that neither it, nor its Affiliates, nor to its knowledge any Permitted
Third Parties engaged by it to perform activities in relation to the Product are debarred under
subsections 306(a) or (b) of the US Federal Food, Drug, and Cosmetic Act (US Generic Drug
Enforcement Act of 1992; 21 USC 335a (a) or (b)), and that it has not and will not knowingly use in
any capacity the services of any Person or Permitted Third Party debarred under this law to conduct
the Clinical Trials. Each Party further certifies that neither it, nor any of its Affiliates are
excluded from any federal health care program, including but not limited to Medicare and Medicaid.
Each Party will notify the JSC immediately if either of these certifications needs to be amended in
light of new information.

Source: PHASEBIO PHARMACEUTICALS INC, 10-K, 3/30/2020
<!-- page 76 -->
13.1.5 Each Party further covenants that it and its Permitted Third Parties have, or will have at
the required times, such certifications, permits, and authorizations as are required to conduct the
Clinical Trials and perform any and all of their obligations in connection with the Clinical Trials
supervised by it.

13.2 Additional PB Representations, Warranties and Covenants.

13.2.1 Licensure, Registration and Accreditation. PB hereby represents and warrants that it is
licensed, registered, or otherwise qualified in all material respects under all Applicable Laws to
do business in each jurisdiction where such licenses, registrations or other qualifications are
required. PB further represents and warrants that there has not been and covenants that there will
not be during the Term any breach or default by PB under AZ License which has not been or will not
be, as applicable, timely cured as permitted thereunder, and that the AZ License is and shall
continue to be in full force and effect during the Term, except to the extent that such a breach,
default or failure as to the AZ License would not have a material adverse effect on PB's ability to
satisfy its obligations under this Agreement. During the Term, PB shall: (a) not take any action
that would entitle MedImmune to terminate the AZ License pursuant to Section 9.2.3 thereof (b) take
such actions as are necessary to cure any action by a Sublicensee (as defined in the AZ License)
that would entitle MedImmune to terminate the AZ License; and (c) not mutually agree with MedImmune
to terminate the AZ License, without the prior written consent of SFJ, to be given or withheld in
its sole discretion. In addition, during the Term, PB shall not take any action to terminate the AZ
License without providing [***] prior written notice to SFJ of PB's intent to terminate so that SFJ
may, in its sole discretion, elect to obtain the Program Transfer, and if SFJ elects in writing
within such [***] period to obtain the Program Transfer, then PB shall not terminate the AZ License
but shall assign it to SFJ in accordance with the Program Transfer Agreement and in such event PB
shall not be entitled to any royalty payments as set forth in Section 3 of the Program Transfer
Agreement.

13.2.2 Disclosure of Regulatory Notices and Communications. PB hereby represents and warrants that,
as of [***] prior to the Effective Date, the regulatory communications and, if any, notices of
inspection, inspection reports, warning letters and deficiency letters related to the Product made
available by PB in the Data Room were true and complete copies of such documents. To the knowledge
of PB, such documents comprise all material written regulatory communications related to Clinical
Trials design or the chemistry, manufacturing or controls of the Product from all Regulatory
Authorities in the possession of PB as of [***] prior to the Effective Date.

13.2.3 CRO Inquiry. PB hereby represents and warrants that, up to and as at the Effective Date,
after due inquiry to its CRO responsible for conducting the Clinical Trials, PB has not received any
verbal or written notice of the occurrence of any Serious Safety Issue in the Clinical Trials.

13.2.4 Compliance. PB represents and warrants that, prior to the Effective Date, (a) it has
conducted all preclinical and clinical activities related to the development of the Product for the
Indication in material compliance with Applicable Laws, and (b) to PB's knowledge, all Third Parties
utilized by PB to perform any portion of the preclinical and clinical

Source: PHASEBIO PHARMACEUTICALS INC, 10-K, 3/30/2020
<!-- page 77 -->
activities have conducted such portion of such preclinical activities in material compliance with
Applicable Laws. PB will manufacture or have manufactured the Product for the Clinical Trials in
accordance with GMP.

13.2.5 Intellectual Property. PB [***]. The development, manufacture and commercialization of the
Product by PB [***]. There are no outstanding options, licenses or agreements of any kind granted by
PB relating to the development, manufacture and commercialization of the Product. PB has not
received any communications alleging that PB has violated or that the development, manufacture and
commercialization of the Product would violate any of the patents, trademarks, service marks, trade
names, copyrights, trade secrets or other proprietary rights of any Third Party.

13.2.6 PB Data Provided as of the Effective Date. PB hereby represents and warrants that, up to and
as of the Effective Date, (i) the CMC Information set forth in the Data Room is accurate in all
material respects, (ii) the descriptions of, protocols for, and data and other results of, the
Clinical Trials of the Product for the Indication conducted by or on behalf of PB set forth in the
Data Room are accurate and complete in all material respects and there are no material omissions
from such documents, data and other results that render such documents, data or other results
materially misleading and (iii) the summaries of primary data regarding the Product and the
Comparators set forth in the Data Room are accurate and complete in all material respects, and there
are no material omissions from such summaries as so presented that render such summaries materially
misleading.

13.3 Outstanding Indebtedness. PB hereby represents and warrants that, as at the Effective Date, PB
and its subsidiaries have no indebtedness for borrowed money other than indebtedness under the SVB
Loan Agreement and obligations in respect of corporate credit cards.

13.4 Contingent Liabilities. PB hereby represents and warrants that, except as reflected in PB's
consolidated balance sheet for the quarter ended September 30, 2019 included its Quarterly Report on
Form 10-Q for the quarter ended September 30, 2019, as of the Effective Date, PB and its
subsidiaries do not have any Contingent Liabilities that would be required to be reflected on PB's
balance sheet in accordance with GAAP except for (i) obligations in connection with this Agreement,
and (ii) other Contingent Liabilities incurred in the ordinary course of business that are not
material to the business of PB and its subsidiaries, taken as a whole.

13.5 SFJ Representation, Warranty and Covenant. SFJ hereby represents, warrants and covenants that
it will have, as and when needed, sufficient funds to satisfy its obligations hereunder.

13.6 DISCLAIMER OF REPRESENTATIONS AND WARRANTIES.

13.6.1 Each Party hereby agrees and understands that because the Clinical Trials and the Product are
experimental in nature, the outcome is inherently uncertain and unpredictable. Each Party hereby
agrees and understands that the other Party makes no

Source: PHASEBIO PHARMACEUTICALS INC, 10-K, 3/30/2020
<!-- page 78 -->
representation, guarantee or warranty, express or implied, regarding the outcome of the Clinical
Trials (including achievement of the Phase 3 Success Criteria), any Research Results generated after
the Effective Date, the ability to obtain Regulatory Approval or the patentability, legal
protectability or usefulness of any Intellectual Property arising from the Clinical Trials.

13.6.2 EXCEPT AS OTHERWISE SET FORTH IN THIS ARTICLE 13, NEITHER PARTY MAKES, AND EACH PARTY
EXPRESSLY DISCLAIMS, ANY REPRESENTATION OR WARRANTY OF ANY KIND WITH RESPECT TO THE SUBJECT MATTER
OF THIS AGREEMENT, EITHER ORAL OR WRITTEN, EXPRESS, IMPLIED, STATUTORY OR OTHERWISE, INCLUDING ANY
REPRESENTATION OR WARRANTY REGARDING THE USE, RESULTS OR EFFICACY OF THE PRODUCT.

ARTICLE 14

TERM AND TERMINATION

14.1 Term. The term of this Agreement (the "Term") will commence on the Effective Date and will
expire upon the earliest of (i) termination of this Agreement in accordance with Section 14.2, or
(ii) the date of payment of the last Approval Payment due based on all applicable Regulatory
Approvals which have been received.

14.2 Termination.

14.2.1 Termination for Breach.

Either Party may terminate this Agreement immediately in the event of a material breach of this
Agreement by the other Party provided that the breaching Party has received written notice from the
non-breaching Party of such breach, specifying in the reasonable detail the particulars of the
alleged breach and such breach has not been cured within [***] after the date of the relevant
notice. The non-breaching Party shall have the right to pursue remedies it may have at law or equity
for such breach, including the right to seek damages from the breaching Party. In the event that SFJ
terminates this Agreement pursuant to this Section 14.2.1 then in exchange for purchasing the Trial
Data Package including the Research Results included therein as set forth in Section 11.1.1.4, PB
will pay SFJ, within [***] of the date of termination, an amount equal to three hundred percent
(300%) of Development Costs paid or incurred by SFJ prior to such termination. Additionally, if PB
elects to continue development of the Product and obtains Regulatory Approval following such
termination, PB will remain obligated to pay any Approval Payments that become due and payable
pursuant to ARTICLE 6 at such time as such payments become due and payable (if ever) (except to the
extent PB pays any Buy-Out Payment(s) pursuant to Section 6.7), provided that each Approval Payment
(or Buy-Out Payment, as applicable) shall be adjusted as set forth in Section 6.2, and reduced by
the amount previously paid by PB to SFJ pursuant to this Section 14.2.1.

In the event that PB terminates this Agreement pursuant to this Section 14.2.1 then, if PB elects to
continue development of the Product and obtains Regulatory Approval following such termination, in
exchange for purchasing the Trial Data Package including the Research Results

Source: PHASEBIO PHARMACEUTICALS INC, 10-K, 3/30/2020
<!-- page 79 -->
therein as set forth in Section 11.1.1.4, PB shall remain obligated to pay to SFJ any Approval
Payments that become due and payable (if ever) pursuant to ARTICLE 6 (except to the extent of the
amount of any Buy-Out Payment pursuant to Section 6.7), provided that such Approval Payments (or
Buy-Out Payment paid by PB, as applicable) shall be adjusted as set forth in Section 6.2.

Notwithstanding the foregoing, if PB terminates this Agreement pursuant to this Section 14.2.1 above
based on SFJ's failure to make any payment due to PB in accordance with ARTICLE 4, then, if PB
elects to continue development of the Product and obtains Regulatory Approval following such
termination, PB shall remain obligated to pay to SFJ fifty percent (50%) of any Approval Payments
that become due and payable pursuant to ARTICLE 6 at such time that such payments become due and
payable (if ever) pursuant to ARTICLE 6 (or, as applicable, fifty percent (50%) of any Buy-Out
Payment that PB elects to pay pursuant to Section 6.7), provided that such Approval Payments (or
Buy-Out Payment, as applicable) shall also be adjusted as set forth in Section 6.2.

14.2.2 At-Will Termination by PB. PB may terminate this Agreement at any time after SFJ has paid or
incurred a total of $60 million of Development Costs and prior to the date of receipt of the first
Regulatory Approval upon [***] prior written notice to SFJ. In the event that PB terminates this
Agreement pursuant to this Section 14.2.2 then in exchange for purchasing the Trial Data Package
including the Research Results included therein as set forth in Section 11.1.1.4, PB will pay SFJ,
within [***] of the date of termination, an amount equal to three hundred percent (300%) of
Development Costs paid or incurred by SFJ prior to such termination. Additionally, if PB elects to
continue development of the Product and obtains Regulatory Approval following such termination, PB
will remain obligated to pay any Approval Payments that become due and payable pursuant to ARTICLE 6
at such time as such payments become due and payable (if ever) pursuant to ARTICLE 6 (except to the
extent of the amount of any Buy-Out Payment paid by PB pursuant to Section 6.7), provided that each
Approval Payment (or the Buy-Out Payment, as applicable) shall be adjusted as set forth in Section
6.2, and reduced by the amount previously paid by PB to SFJ pursuant to this Section 14.2.2.

14.2.3 Termination by SFJ for Material Adverse Event. SFJ may terminate this Agreement at any time
in the event of a Material Adverse Event immediately upon written notice to PB. In the event that
SFJ terminates this Agreement pursuant to this Section 14.2.3, then, if PB elects to continue
development of the Product and obtains Regulatory Approval following such termination, in exchange
for purchasing the Trial Data Package including the Research Results included therein as set forth
in Section 11.1.1.4, PB shall remain obligated to pay SFJ an amount equal to fifty percent (50%) of
the Approval Payments (as adjusted as set forth in Section 6.2, subject, to the extent applicable,
to Sections 2.3.3 and 3.12.2) that become due and payable under ARTICLE 6 at such time as they
become due and payable (if ever) pursuant to ARTICLE 6 (or, as applicable, 50% of any Buy-Out
Payment that PB elects to pay pursuant to Section 6.7), provided that such Approval Payments (or
Buy-Out Payment, as applicable) shall also be adjusted as set forth in Section 6.2.

Source: PHASEBIO PHARMACEUTICALS INC, 10-K, 3/30/2020
<!-- page 80 -->
14.2.4 Termination for Failure to Receive Regulatory Approval.

14.2.4.1 This Agreement will, upon written notice from either Party to the other Party, terminate
with no further action from either Party if the Product has not received Regulatory Approval from at
least one of (i) the FDA, (ii) EMA, (iii) PMDA, or (iv) NMPA after completion of the Clinical
Trials, submission by PB of applications for Regulatory Approval to the FDA and EMA, and submission
by SFJ of applications for Regulatory Approval to the PMDA and NMPA, and after Commercially
Reasonable Efforts to obtain such Regulatory Approvals based on such submitted applications as may
be amended from time to time. For the avoidance of doubt, if Regulatory Approval is received from
any of the FDA, EMA, PMDA, or NMPA then this Agreement may not thereafter be terminated pursuant to
this Section 14.2.4.1.

14.2.4.2 This Agreement will, upon written notice from either Party to the other Party, terminate
with no further action from either Party, if the Phase 3 Trial is completed or terminated and either
(a) the primary endpoint in the Phase 3 Trial is not achieved or (b) SFJ reasonably determines that
the Research Results of the Phase 3 Trial do not support Regulatory Approval. For avoidance of
doubt, if an application for Regulatory Approval is submitted to any of the FDA, EMA, PMDA or NMPA
then this Agreement may not thereafter be terminated pursuant to this Section 14.2.4.2.

14.2.4.3 In the event that this Agreement is terminated pursuant to this Section 14.2.4, then, if PB
elects to continue development of the Product and obtains Regulatory Approval following such
termination, in exchange for purchasing the Trial Data Package including the Research Results
included therein as set forth in Section 11.1.1.4, PB shall remain obligated to make any Approval
Payments that become due and payable pursuant to ARTICLE 6 at such time that such payments become
due and payable (if ever) pursuant to ARTICLE 6 (except to the extent of the amount of any Buy-Out
Payment paid by PB pursuant to Section 6.7), provided that such Approval Payments (or Buy-Out
Payment, as applicable) shall be adjusted as set forth in Section 6.2.

14.2.5 Termination for Bankruptcy. Either Party may terminate this Agreement upon written notice to
the other Party if the other Party makes an assignment for the benefit of creditors, or commences a
case or proceeding under any bankruptcy, reorganization, insolvency, or similar laws, has a trustee
or receiver or similar officer of any court appointed for such Party, or for substantial part of the
property of such Party, or bankruptcy, reorganization, insolvency, or liquidation proceedings are
instituted by or against such Party without such proceedings being dismissed, in each of the
foregoing cases for a period of at least [***].

14.2.5.1 In the event that PB terminates this Agreement pursuant to this Section 14.2.5, then, if PB
elects to continue development of the Product and obtains Regulatory Approval following such
termination, in exchange for purchasing the Trial Data Package including the Research Results
included therein as set forth in Section 11.1.1.4, PB shall remain obligated to pay to SFJ any
Approval Payments that become due and payable pursuant to ARTICLE 6 at such time as such Approval
Payments become due and payable (if ever) pursuant to ARTICLE 6 (except to the extent of the amount
of any Buy-Out Payment paid by PB pursuant

Source: PHASEBIO PHARMACEUTICALS INC, 10-K, 3/30/2020
<!-- page 81 -->
to Section 6.7), provided that such Approval Payments (or Buy-Out Payment, as applicable) shall be
adjusted as set forth in Section 6.2.

14.2.5.2 In the event SFJ terminates this Agreement pursuant to this Section 14.2.5, then in
exchange for purchasing the Trial Data Package including the Research Results included therein as
set forth in Section 11.1.1.4, PB will pay SFJ within [***] of the date of termination an amount
equal to three hundred percent (300%) of Development Costs paid or incurred by SFJ prior to such
termination. Additionally, PB will remain obligated to pay any Approval Payments that become due and
payable pursuant to ARTICLE 6 at such time as such payments become due and payable (if ever)
pursuant to ARTICLE 6 (except to the extent of the amount of any Buy-Out Payment paid by PB pursuant
to Section 6.7), provided that such Approval Payments (or Buy-Out Payment, as applicable) shall be
adjusted as set forth in Section 6.2, and reduced by the amount previously paid by PB to SFJ
pursuant to this Section 14.2.5.2.

14.2.6 Termination for Change of Control of PB. PB will notify SFJ in writing promptly (and in any
event within [***]) following the entering into of a definitive agreement with respect to a Change
of Control of PB. SFJ may, in its sole discretion, terminate this Agreement in its entirety at any
time following a Change of Control of PB that occurs prior to the date of payment by PB of the final
Approval Payment. In the event that SFJ terminates this Agreement pursuant to this Section 14.2.6,
then, in exchange for purchasing the Trial Data Package including the Research Results included
therein as set forth in Section 11.1.1.4, PB will pay to SFJ within [***] of the date of termination
an amount equal to one hundred fifty percent (150%) of Development Costs which were paid or incurred
by SFJ. PB or its successor (whose performance shall be guaranteed by PB) shall be obligated to
continue to exercise Commercially Reasonable Effort to develop the Product and seek Regulatory
Approval as set forth herein following the date of such termination including the Trial Data Package
including the Research Results included therein as set forth in Section 11.1.1.4, PB shall remain
obligated to pay any Approval Payments that become due and payable pursuant to ARTICLE 6 at such
time as such Approval Payments become due and payable (if ever) pursuant to ARTICLE 6 (except to the
extent of the amount of any Buy-Out Payment paid by PB pursuant to Section 6.7), provided that such
Approval Payments (or Buy-Out Payment, as applicable) shall be adjusted as set forth in Section 6.2,
and shall be reduced by the amount previously paid to SFJ as set forth in this Section 14.2.6.

14.2.7 Termination for Safety Concerns. Either Party may terminate this Agreement upon written
notice to the other Party if (a) the independent data monitoring committee for the Phase 3 Trial
recommends termination of the Phase 3 Trial for reasons pertaining to the health or safety of the
Subjects or for futility, or (b) the Parties mutually agree a material health or safety concern with
respect to the Subjects exists. In the event that this Agreement terminates pursuant to this Section
14.2.7, then PB will not be obligated to pay to SFJ any Development Costs or Approval Payments.
Notwithstanding the foregoing, (A) if this Agreement terminates pursuant to this Section 14.2.7 and
such termination: (i) arises as a result of gross negligence on the part of PB; or (ii) is due to
(x) the applicable independent data monitoring committee recommending termination of the Phase 3
Trial or (y) PB and SFJ

Source: PHASEBIO PHARMACEUTICALS INC, 10-K, 3/30/2020
<!-- page 82 -->
mutually agreeing to terminate the Phase 3 Trial, in either case ((x) or (y)), due to a Serious
Safety Issue that was previously known, demonstrated or identified by PB as being material as of the
Effective Date and the material data showing, demonstrating, or identifying such Serious Safety
Issue were not included in the Data Room, disclosed in writing to SFJ or otherwise publicly known
prior to the Effective Date; then, in either case ((i) or (ii)), PB will pay SFJ within [***] of the
date of termination an amount equal to three hundred percent (300%) of Development Costs paid or
incurred by SFJ, and (B) if PB elects to continue development of the Product and obtains Regulatory
Approval following such termination, in exchange for purchasing the Trial Data Package including the
Research Results included therein as set forth in Section 11.1.1.4, PB will remain obligated to pay
any Approval Payments that become due and payable pursuant to ARTICLE 6 at such time as such
Approval Payments become due and payable (if ever) pursuant to ARTICLE 6 (except to the extent of
the amount of any Buy-Out Payment paid by PB pursuant to Section 6.7), provided that such Approval
Payments (or Buy-Out Payment, as applicable) shall be adjusted as set forth in Section 6.2 and shall
be reduced by the amount previously paid by PB to SFJ pursuant to this Section 14.2.7.

14.2.8 Termination for Certain Breaches/Actions.

14.2.8.1 SFJ may terminate this Agreement if (i) PB has breached by its own actions, or by the
actions of any of its Representatives, either of Section 13.1.3 or Section 13.1.4 in any material
respect, (ii) a Representative of PB has breached the policy attached as Exhibit F‑1 in any material
respect and such breach results in a Material Anti-Corruption Law Violation, or (iii) SFJ learns (a)
that improper payments are being or have been made to Government Officials or any other person by PB
or any of its Representatives on behalf of PB or (b) that PB or any of its Representatives with
respect to services performed on behalf of PB has accepted any payment, item, or benefit, regardless
of value, as an improper inducement to award, obtain or retain business or otherwise gain or grant
an improper business advantage from or to any other person or entity (in any such case ((i), (ii) or
(iii)), a "PB Compliance Breach"), unless such PB Compliance Breach can be cured without having a
materially adverse impact on the probability of completing the Clinical Trials or obtaining
Regulatory Approval for the Product. In the event of such termination, PB will not be entitled to
any further payments under ARTICLE 4, regardless of any activities undertaken or agreements with
additional Third Parties entered into prior to termination. In the event that SFJ terminates this
Agreement pursuant to this Section 14.2.8.1, then (a) in exchange for purchasing the Trial Data
Package including the Research Results included therein as set forth in Section 11.1.1.4, PB will
pay SFJ, within [***] of the date of termination, an amount equal to one hundred fifty percent
(150%) of Development Costs paid or incurred to PB by SFJ prior to such termination, and (b) if PB
elects to continue development of the Product and obtains Regulatory Approval following such
termination, PB shall remain obligated to pay to SFJ any Approval Payments that become due and
payable pursuant to ARTICLE 6 at such time that such payments become due and payable (if ever)
pursuant to ARTICLE 6 (except to the extent of the amount of any Buy-Out Payment paid by PB pursuant
to Section 6.7), provided that such Approval Payments (or Buy-Out Payment, as applicable) shall be
adjusted as set forth in Section 6.2, and reduced by the amount previously paid by PB to SFJ
pursuant to this Section 14.2.8.1.

Source: PHASEBIO PHARMACEUTICALS INC, 10-K, 3/30/2020
<!-- page 83 -->
14.2.8.2 PB may terminate this Agreement if (i) SFJ has breached by its own actions, or by the
actions of any of its Representatives, either of Section 13.1.3 or Section 13.1.4 in any material
respect, (ii) a Representative of SFJ has breached the policy attached as Exhibit F‑2 in any
material respect and such breach results in a Material Anti-Corruption Law Violation, or (iii) PB
learns (a) that improper payments are being or have been made to Government Officials or any other
person by SFJ or any of its Representatives on behalf of SFJ or (b) that SFJ or any of its
Representatives with respect to services performed on behalf of SFJ has accepted any payment, item,
or benefit, regardless of value, as an improper inducement to award, obtain or retain business or
otherwise gain or grant an improper business advantage from or to any other person or entity (in any
such case ((i), (ii) or (iii)), an "SFJ Compliance Breach"), unless such SFJ Compliance Breach can
be cured without having a materially adverse impact on the probability of completing the Clinical
Trials or obtaining Regulatory Approval for the Product. In the event of such termination, SFJ will
not be entitled to any further payments hereunder except as set forth below. In the event that PB
terminates this Agreement pursuant to this Section 14.2.8.2, then, if PB elects to continue
development of the Product and obtains Regulatory Approval following such termination, in exchange
for purchasing the Trial Data Package including the Research Results included therein as set forth
in Section 11.1.1.4, PB shall remain obligated to pay to SFJ any Approval Payments that become due
and payable pursuant to ARTICLE 6 at such time that such payments become due and payable (if ever)
pursuant to ARTICLE 6 (except to the extent of the amount of any Buy-Out Payment paid by PB pursuant
to Section 6.7), provided that such Approval Payments (or Buy-Out Payment, as applicable) shall be
(A) adjusted as set forth in Section 6.2, and (B) reduced by the amount of all documented
out-of-pocket expenses incurred by or on behalf of PB as a result or arising out of such violation
by SFJ or any of its Representatives (including any and all amounts paid by PB as penalties or fines
for such violation, in settlement of legal or administrative proceedings relating to such violation,
or otherwise).

14.2.8.3 If a Party learns that any of its Permitted Third Parties has materially breached Section
13.1.3 or Section 13.1.4, or Exhibit F‑1 or Exhibit F‑2, as applicable, or that improper payments
are being or have been made to Government Officials by any of its Permitted Third Parties with
respect to services performed on behalf of such Party or in connection with the Clinical Trials,
such Party will notify the other Party and, at the other Party's option, such Party will terminate
its relationship with such Permitted Third Party with respect to the Clinical Trials.

14.2.9 Termination Because of Adverse Patent Impact. SFJ may terminate this Agreement if (a) PB is
enjoined from further developing or commercializing the Product for the Indication in any of the US,
the Designated European Countries or the Designated Asian Countries or (b) the future value of the
Product is materially adversely affected due to (i) Third Party patents that were not publicly
disclosed or known to SFJ at the Effective Date that would be infringed by the manufacture, use,
sale, offer for sale or import of the Product for the Indication in any of the US, the Designated
European Countries or the Designated Asian Countries or (ii) invalidity or unenforceability of all
Patents within the PB Intellectual Property Covering the Product for the Indication in any of the
US, the Designated European Countries or the Designated Asian Countries (in either case ((a) or
(b)), "Adverse Patent Impact"), upon

Source: PHASEBIO PHARMACEUTICALS INC, 10-K, 3/30/2020
<!-- page 84 -->
written notice to PB if PB does not cure such Adverse Patent Impact within a period of six (6)
months from the date of SFJ's notice to PB of an Adverse Patent Impact. In the event that SFJ
terminates this Agreement pursuant to this Section 14.2.9, then in exchange for purchasing the Trial
Data Package including the Research Results included therein as set forth in Section 11.1.1.4, PB
shall pay to SFJ, within [***] of the date of termination, an amount equal to all Development Costs
paid or incurred by SFJ as of the date of termination.

14.2.10 Termination for JSC Decision. SFJ may, in its sole discretion, terminate this Agreement in
its entirety at any time prior to the date of receipt of the first Regulatory Approval in the event
PB exercises its decision-making authority under Section 5.2.4 to approve a matter set forth in
Section 5.2.2 and, after escalation to the Executive Officers in accordance with Section 5.2.4, SFJ
continues in good faith to disagree with such decision. In the event that SFJ terminates this
Agreement pursuant to this Section 14.2.10, then in exchange for purchasing the Trial Data Package
including the Research Results included therein as set forth in Section 11.1.1.4, PB will pay to
SFJ, within [***] of the date of termination, an amount equal to the Development Costs paid or
incurred by SFJ plus interest at the annual rate of twenty-five percent (25%) from the date such
Development Costs were paid or incurred by SFJ and, if PB elects to continue development of the
Product and obtains Regulatory Approval following such termination, PB shall remain obligated to pay
any Approval Payments that become due and payable pursuant to ARTICLE 6 at such time as such
Approval Payments become due and payable (if ever) pursuant to ARTICLE 6 (except to the extent of
the amount of any Buy-Out Payment paid by PB pursuant to Section 6.7), provided that such Approval
Payments (or Buy-Out Payment, as applicable) shall be adjusted as set forth in Section 6.2, and
reduced by the amount previously paid to SFJ as set forth in this Section 14.2.10.

14.3 Certain Additional Consequences of Termination. In the event of any termination of this
Agreement pursuant to Section 14.2, then, if SFJ has not caused a Program Transfer to occur pursuant
to Section 3.20:

14.3.1 to the extent not previously assigned to PB pursuant to Section 11.1.1.4, SFJ shall, and it
hereby does, assign sole and exclusive ownership of the Trial Data Package including the Research
Results included therein to PB, such assignment to be effective in accordance with Section 11.1.1.4;

14.3.2 effective as of such termination, SFJ shall, and it hereby does, assign to PB all of SFJ's
and its Affiliates' right, title and interest in and to all Product Filings then owned or Controlled
by SFJ or any of its Affiliates; provided that if any such Product Filing is not immediately
transferable in a country, SFJ shall provide PB with all benefit of such Product Filing and such
assistance and cooperation as necessary or reasonably requested by PB to timely transfer such
Product Filing to PB or its designee or, at PB's option, to enable PB to obtain a substitute for
such Product Filing without disruption to PB's development or Commercialization of the Product in
the SFJ Territory;

14.3.3 within [***] after assignment of the Product Filings pursuant to Section 14.3.2, SFJ shall
deliver to PB: (a) true, correct and complete copies of all Product Filings in such country (in each
case, whether held in the name of SFJ or any of its Affiliates),

Source: PHASEBIO PHARMACEUTICALS INC, 10-K, 3/30/2020

and disclose to PB in writing all previously-undisclosed Research Results within the Trial Data
Package; (b) formally transfer or assign, or cause to be formally transferred or assigned, into the
name of PB or its designee all Product Filings in such country (in each case, whether held in the
name of SFJ or any of its Affiliates); and (c) take such other actions and execute such other
instruments, assignments and documents as may be necessary to effect, evidence, register and record
the transfer, assignment or other conveyance of such rights to PB or its designee;
<!-- page 85 -->
14.3.4 at PB's written request and election in PB's sole discretion, SFJ shall and hereby does, and
shall cause its Affiliates to either: (i) wind down in accordance with Applicable Law and observing
applicable ethical and regulatory guidelines any or all Clinical Trials being conducted by or on
behalf of SFJ or its Affiliate as of the effective date of termination, at SFJ's cost and expense;
or (ii) (x) transfer control to PB of any or all Clinical Trials being conducted by or on behalf of
SFJ or its Affiliate as of the effective date of termination and (y) continue to conduct such
Clinical Trials being conducted by or on behalf of SFJ or an Affiliate as of the effective date of
termination for up to [***] to enable such transfer to be completed without interruption of any such
Clinical Trial, in each case ((x) and (y)), at PB's cost and expense; and

14.3.5 SFJ shall, and shall cause its Affiliates to, promptly assign to PB or its designee any and
all Clinical Trial Agreements, CRO Agreements and other Vendor Agreements to which any of them is a
party and cooperate in good faith with PB to provide appropriate notice and new contact information
to the applicable Sites, Clinical Investigators, CROs and other Vendors and PB shall accept such
assignment of all obligations of SFJ and its Affiliates thereunder without recourse to SFJ other
than any indemnification obligations which SFJ may be liable for thereunder.

14.4 Surviving Obligations.

14.4.1 Accrued Rights and Obligations. Except as expressly set forth in Sections 3.20 and 14.4.2,
and, if applicable, the Program Transfer Agreement, expiration or termination of this Agreement for
any reason will not release either Party from any obligation or liability which, at the time of such
expiration or termination, has already accrued to the other Party or which is attributable to a
period prior to such expiration or termination.

14.4.2 Exclusive Remedy. Notwithstanding anything herein to the contrary, termination of this
Agreement by a Party will be without prejudice to other remedies such Party may have at law or
equity; provided that the payment by PB to SFJ of the amounts specified as being payable upon a
given termination in Section 14.2 shall be in lieu of any claim for damages that SFJ may have
arising out of or in connection with the circumstances that formed the basis for such termination..

14.4.3 Surviving Obligations. The following provisions of this Agreement, together with any other
provisions that expressly specify that they survive, will survive expiration or earlier termination
of this Agreement:

14.4.3.1 ARTICLE 1, ARTICLE 9, ARTICLE 10, ARTICLE 11, ARTICLE 12, Section 13.1, Section 13.6,
Section 14.4 and ARTICLE 15; and

Source: PHASEBIO PHARMACEUTICALS INC, 10-K, 3/30/2020
<!-- page 86 -->
14.4.3.2 solely in the case of termination of this Agreement after payment by SFJ to PB of the
Initial Development Cost Payment on the Initial Funding Date, but not in the case of expiration of
this Agreement, Sections 3.20, 6.1- 6.7, 7.1-7.7 (in the case of such Sections 7.1-7.7, such
provisions shall terminate only after all PB Obligations, other than contingent indemnity
obligations, have been paid to SFJ or otherwise satisfied in accordance with this Agreement in
full), 14.2 and 14.3.

ARTICLE 15

MISCELLANEOUS

15.1 Relationship with Affiliates. Each Party will be responsible for any breach by its Affiliates
of its obligations in connection with this Agreement, and each such Party will remain responsible
for any responsibilities that it has delegated to an Affiliate as though such Party had performed
(or failed to perform) such responsibilities itself.

15.2 Prior Agreements. The Parties agree on behalf of themselves and their respective Affiliates
that any prior Confidentiality Agreement, by and between PB and SFJ (the "Prior CDA") is hereby
terminated and superseded by this Agreement and that all Information disclosed under or pursuant to
the Prior CDAs will constitute Confidential Information disclosed pursuant to this Agreement and
will be subject to the terms of ARTICLE 10, with the confidentiality and non-use provisions of
ARTICLE 10 applying retroactively to such Confidential Information from the date of disclosure.

15.3 Notices. Any notice or other communication required or permitted to be given by either Party
under this Agreement will be in writing and will be effective when delivered if delivered by fax,
e-mail, hand, reputable courier service, or five (5) days after mailing if mailed by registered or
certified mail, postage prepaid and return receipt requested, addressed to the other Party at the
following addresses or such other address as may be designated by notice pursuant to this Section
15.3.:

15.3.1 If to PB:

PhaseBio Pharmaceuticals, Inc. 1 Great Valley Parkway, Suite 30 Malvern, PA 19355 USA Attn: Chief
Executive Officer

with a copy to:

Attn: Vice President, Head of Legal (at the address set forth above)

Source: PHASEBIO PHARMACEUTICALS INC, 10-K, 3/30/2020
<!-- page 87 -->
and to:

Cooley LLP 11951 Freedom Drive Reston, VA 20190 USA Attn: Christian E. Plaza

15.3.2 If to SFJ:

SFJ Pharmaceuticals X, Ltd SIX, 2nd Floor, Cricket Square PO Box 2681 Grand Cayman, KY1-1111 Cayman
Islands

Attn: Robert DeBenedetto

with a copy to:

Morrison & Foerster LLP 755 Page Mill Road Palo Alto, CA 94304-1018 Attention: Michael O'Donnell

15.4 Force Majeure. Neither Party will be liable for any breach or delay in performance of any
obligation under this Agreement to the extent caused by any of the following: war, terrorism, riot,
fire, explosion, accident, flood, sabotage, changes in Applicable Laws, actions of Governmental
Authorities, or any other event beyond the reasonable control of such Party. The Party invoking this
Section 15.4 must provide prompt written notice and full particulars of such event to the other
Party and will use diligent and commercially reasonable efforts to mitigate the effects of any such
force majeure event on such Party's compliance with and performance under this Agreement.

15.5 Use of Names. Neither Party will use the other Party's nor any of its Affiliates' (including
the limited partners of SFJ's or its Affiliates') names or trademarks in any promotional materials
or advertising without the prior written consent of the other Party except as otherwise expressly
permitted in this Agreement.

15.6 Assignment. Without the prior written consent of the other Party hereto, neither Party will
sell, transfer, assign, pledge or otherwise dispose of, whether voluntarily, involuntarily, by
operation of law or otherwise, this Agreement or any of its rights or duties hereunder; provided,
however, that either Party may assign, sublicense or transfer this Agreement and all of its rights
and obligations hereunder, in their entirety, to any of its Affiliates or to a successor in
connection with the sale or other transfer of all or substantially all of its business or assets to
which this Agreement relates, whether by merger, sale of stock, sale of assets or otherwise, and

Source: PHASEBIO PHARMACEUTICALS INC, 10-K, 3/30/2020
<!-- page 88 -->
whether this Agreement is actually assigned or is assumed by a Third Party acquirer or the surviving
corporation resulting from such transaction by operation of law (e.g., in the context of a reverse
triangular merger). Notwithstanding the foregoing, any assignment of the rights or obligations under
this Agreement by a Party (i) to an Affiliate shall require such Party to guarantee the performance
of such Affiliate's financial and performance obligations hereunder or (ii) in connection with the
sale or other transfer of all or substantially all of such Party's business or assets to which this
Agreement relates shall require the ultimate Affiliate controlling the other party in such
transaction to guarantee such Party's financial and performance obligations hereunder and such Party
shall remain liable for such financial and performance obligations notwithstanding such sale or
other transfer of all or substantially all of such Party's business or assets to which this
Agreement relates. Notwithstanding any of the foregoing, without the consent of PB, which consent
may be withheld in PB's sole discretion, SFJ shall not sell, assign, sublicense or otherwise
transfer this Agreement to an entity whose primary business is the development or commercialization
of pharmaceutical or biotechnology products prior to the date of Program Transfer. For the avoidance
of doubt the preceding sentence shall not apply after the date of Program Transfer. Furthermore,
notwithstanding any of the foregoing, SFJ may assign its right to receive Approval Payments to (a)
the limited partners in SFJ, provided that such limited partners agree that a majority in interest
shall be entitled to take all actions and make any consents on behalf of SFJ hereunder and provided
that such limited partners notify PB of a single account to which PB can make all payments that may
become due hereunder and assume sole responsibility for distributing all such payments, or to a
liquidating trust or similar entity that is established to receive and distribute Approval Payments
for the benefit of the limited partners in SFJ, that is required to carry out such responsibilities
as a single entity, and provided that such limited partners or liquidating trust takes such rights
to receive and distribute Approval Payments subject to all of PB's rights and defenses hereunder
(and in any case under this clause (a), PB shall have the unconditional right to follow any
instruction it receives or rely on any actions, consents and communications received from or taken
by such limited partners or liquidating trust or similar entity without any duty to verify or
otherwise determine the validity thereof) or (b) an other Third Party to which SFJ assigns this
Agreement in its entirety as permitted by the preceding provisions of this Section 15.6, provided
that, following any assignment of this Agreement by SFJ to a Third Party pursuant to the foregoing
clause (b) the JSC shall terminate, such assignee shall not have any further rights under ARTICLE 5,
such assignee shall not have any further rights to approve or consent (and PB shall not have any
further obligation to seek SFJ's approval or consent) as to any matter relating to PB's development
and Commercialization of the Product, [***]. This Agreement is binding upon and will inure to the
benefit of each of the Parties, its successors and permitted assigns.

15.7 Further Assurances. The Parties will execute such further reasonable documents and perform such
further reasonable acts as may be necessary to comply with or more fully effectuate the terms of
this Agreement.

15.8 Fees and Expenses. Each Party to this Agreement will bear its own costs and expenses, including
attorneys' fees and expenses, in connection with the closing of the transactions contemplated
hereby.

Source: PHASEBIO PHARMACEUTICALS INC, 10-K, 3/30/2020
<!-- page 89 -->
15.9 Governing Law. The construction and validity of this Agreement and the provisions hereof, and
the rights and obligations of the Parties hereunder, will be governed by the internal laws of the
State of Delaware, USA, and, to the extent applicable to Patents and Trademarks, the applicable
federal laws of the USA, in each instance without regard to conflict of laws principles.

15.10 Dispute Resolution. The Parties recognize that disputes as to certain matters relating to this
Agreement may arise from time to time. It is the objective of the Parties to establish procedures to
facilitate the resolution of disputes in an expedient manner by mutual cooperation and without
resort to litigation. Accordingly, the Parties agree that any dispute, controversy or claim arising
under, out of or in connection with this Agreement, including any subsequent amendments, or the
validity, enforceability, construction, performance or breach hereof (and including the
applicability of this Section 15.10 to any such dispute, controversy or claim) (each a "Dispute")
shall be resolved as follows:

15.10.1 Either Party shall have the right to refer such Dispute to the Executive Officers for
attempted resolution by good faith negotiations for a period of [***]. Any final decision mutually
agreed to by the Executive Officers in writing shall be conclusive and binding on the Parties. With
respect to any Dispute that remains unresolved after the expiration of [***] after a Dispute is
notified to the Executive Officers, then such Dispute shall be submitted to the International Centre
for Dispute Resolution ("ICDR") for final and binding arbitration pursuant to the arbitration clause
set forth in Section 15.10.2. Notwithstanding the foregoing, no matters relating to breach or
alleged breach of the ownership of intellectual property or rights in intellectual property or the
validity or enforceability thereof shall be resolved by arbitration, but rather shall be determined
by a U.S. federal court of appropriate jurisdiction. Notwithstanding the foregoing, any dispute
between the Parties as to whether entering into a Licensing Transaction would have a Material Impact
shall be resolved as set forth in Section 7.5.5. Notwithstanding anything in this Agreement to the
contrary, either Party shall be entitled to seek preliminary injunctive relief in any court of
competent jurisdiction immediately if necessary to prevent irreparable harm to that Party.

15.10.2 Arbitration Process.

15.10.2.1 Either Party shall have the right to initiate arbitration at any time after the expiration
of thirty (30) days after a Dispute is notified to the Executive Officers. Any disputes concerning
the propriety of the commencement of the arbitration shall be finally settled by the arbitral
tribunal.

15.10.2.2 Any Dispute including the determination of the scope or applicability of this agreement to
arbitrate, shall be determined by the ICDR in accordance with its International Arbitration Rules,
except as they may be modified herein. The seat, or legal place, of arbitration shall be New York,
and the language of the arbitration shall be English. References herein to any arbitration rules or
procedures mean such rules or procedures as amended from time to time, including any successor rules
or procedures, and references herein to the ICDR include any successor thereto. The arbitration
shall be before a tribunal comprised of three (3) arbitrators. Each Party shall select one
arbitrator and within fifteen (15) days of the

Source: PHASEBIO PHARMACEUTICALS INC, 10-K, 3/30/2020
<!-- page 90 -->
second arbitrator's appointment, the two (2) Party appointed arbitrators shall select the third, who
shall serve as the tribunal's chair or president. All three (3) arbitrators shall be professionals
with substantial experience in development and Commercialization of biopharmaceutical products. An
arbitrator shall be deemed to meet these qualifications unless a Party objects within fifteen (15)
after the arbitrator is appointed. This arbitration provision, and the arbitration itself, shall be
governed by the Federal Arbitration Act, 9 U.S.C. §§ 1 et. seq.

15.10.2.3 Consistent with the expedited nature of arbitration, each Party will, upon the written
request of the other Party, promptly provide the other with copies of documents on which the
producing Party may rely in support of or in opposition to any claim or defense. At the request of a
Party, the arbitrators shall have the discretion to order examination by deposition of witnesses to
the extent the arbitrator deems such additional discovery relevant and appropriate. [***]. All
objections are reserved for the arbitration hearing except for objections based on privilege and
proprietary or confidential information. [***]. Any Dispute regarding discovery, or the relevance or
scope thereof, shall be determined by the arbitrators, which determination shall be conclusive. All
discovery shall be completed within [***] following the appointment of the arbitrators. All costs
and/or fees relating to the retrieval, review and production of electronic discovery shall be paid
by the Party requesting such discovery.

15.10.2.4 The arbitrators shall have no authority to award punitive or other damages not measured by
the prevailing Party's actual damages, except as may be required by statute. Each Party expressly
waives and foregoes any right to consequential, punitive, special, exemplary or similar damages or
lost profits. The arbitrators shall have no power or authority, under the ICDR rules and procedures
or otherwise, to relieve the Parties from their agreement hereunder to arbitrate or otherwise to
amend or disregard any provision of this Agreement. The cost of the arbitration, including the fees
of the arbitrators and reasonable attorney's fees of the prevailing Party, shall be borne by the
Party the arbitrator determines has not prevailed in the arbitration.

15.10.2.5 If an arbitral award does not impose an injunction on the losing Party or contain a money
damages award in excess of [***] dollars USD ($[***]), then the arbitral award shall be final and
binding and shall only be subject to such challenges as would otherwise be permissible under the
Federal Arbitration Act, 9 U.S.C. § 1 et. seq. . Judgment on such an award may be entered in any
court of competent jurisdiction and the Parties undertake to carry out the award without delay. In
the event that an arbitral award imposes an injunction or contains a monetary award in excess of
[***] dollars USD ($[***]), the Parties agree that such award may be appealed pursuant to the AAA's
Optional Appellate Arbitration Rules ("Appellate Rules") and should not be considered to be final
and binding until after the time for filing the notice of appeal under the Appellate Rules has
expired. Appeals must be initiated within [***] of receipt of the award, as defined by the Appellate
Rules, by filing a Notice of Appeal within any AAA office. Following the appeal process, the
decision rendered by the appeal tribunal shall be final and binding and judgment on that award may
be entered in any court of competent jurisdiction and the Parties undertake to carry out the award
without delay.

Source: PHASEBIO PHARMACEUTICALS INC, 10-K, 3/30/2020
<!-- page 91 -->
15.10.2.6 Except as may be required by law, or to protect or pursue a legal right to enforce or
challenge an award in legal proceedings, where needed for the preparation or presentation of a claim
or defense in this arbitration, or by order of the arbitral tribunal upon application of a Party,
neither a Party nor an arbitrator may disclose the existence, content, or results of any arbitration
hereunder without the prior written consent of both Parties.

15.11 Limitation of Liability. TO THE MAXIMUM EXTENT PERMITTED BY LAW AND NOTWITHSTANDING ANY
PROVISION IN THIS AGREEMENT TO THE CONTRARY, NEITHER PARTY WILL BE LIABLE TO THE OTHER PARTY FOR ANY
INDIRECT, INCIDENTAL, CONSEQUENTIAL, SPECIAL, RELIANCE OR PUNITIVE DAMAGES OR LOST OR IMPUTED
PROFITS OR ROYALTIES OR COST OF PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES, WHETHER LIABILITY IS
ASSERTED IN CONTRACT, TORT (INCLUDING NEGLIGENCE AND STRICT PRODUCTS LIABILITY), INDEMNITY OR
CONTRIBUTION, AND IRRESPECTIVE OF WHETHER THAT PARTY OR ANY REPRESENTATIVE OF THAT PARTY HAS BEEN
ADVISED OF, OR OTHERWISE MIGHT HAVE ANTICIPATED THE POSSIBILITY OF, ANY SUCH LOSS OR DAMAGE. THE
PARTIES AGREE THAT THE LIMITATIONS SPECIFIED IN THIS SECTION 15.11 WILL APPLY EVEN IF ANY LIMITED
REMEDY SPECIFIED IN THIS AGREEMENT IS FOUND TO HAVE FAILED OF ITS ESSENTIAL PURPOSE. WITHOUT
LIMITING THE GENERALITY OF THE FOREGOING, "CONSEQUENTIAL DAMAGES" WILL BE DEEMED TO INCLUDE, AND
NEITHER PARTY WILL BE LIABLE TO THE OTHER PARTY OR ANY OF SUCH OTHER PARTY'S AFFILIATES,
REPRESENTATIVES OR STOCKHOLDERS FOR ANY DAMAGES BASED ON OR MEASURED BY LOSS OF PROJECTED OR
SPECULATIVE FUTURE SALES OF THE PRODUCT, ANY PAYMENT DUE UPON ANY UNACHIEVED EVENT UNDER ARTICLE 6,
OR ANY OTHER UNEARNED, SPECULATIVE OR OTHERWISE CONTINGENT PAYMENTS PROVIDED FOR IN THIS AGREEMENT.
FOR THE AVOIDANCE OF DOUBT, THIS SECTION 15.11 IS NOT MEANT TO LIMIT PB'S OBLIGATION TO PAY SFJ THE
AMOUNTS SET FORTH IN ARTICLE 6 OR SECTION 14.2.

15.12 Cumulative Remedies. Unless expressly set forth in this Agreement, all rights and remedies of
the Parties, including all rights to payment, rights of termination, rights to injunctive relief,
and other rights provided under this Agreement, will be cumulative and in addition to all other
remedies provided for in this Agreement, in law, and in equity.

15.13 Relationship of the Parties.

15.13.1 Independent Contractors. Nothing contained herein will be deemed to create a partnership,
joint venture, or similar relationship between the Parties, including for tax purposes. Neither
Party is the agent, employee, joint venturer, partner, franchisee, or representative of the other
Party. Each Party specifically acknowledges that it does not have the authority to, and will not,
incur any obligations or responsibilities on behalf of the other Party. Notwithstanding anything to
the contrary in this Agreement, each Party (and its officers, directors, agents, employees, and
members) will not hold themselves out as employees, agents,

Source: PHASEBIO PHARMACEUTICALS INC, 10-K, 3/30/2020
<!-- page 92 -->
representatives, or franchisees of the other Party or enter into any agreements on such Party's
behalf.

15.13.2 Direction. Neither Party will be subject to the supervisory direction of the other Party in
regard to the conduct of the Clinical Trials.

15.14 No Third Party Beneficiaries. This Agreement and the provisions herein are for the benefit of
the Parties only, and are not intended to confer any rights or benefits to any Third Party.

15.15 Rights Reserved. No license or any other right is granted to either Party, by implication or
otherwise, except as specifically set forth in this Agreement. All rights not exclusively granted to
SFJ are reserved to PB and its Affiliates. Notwithstanding any other provision of this Agreement to
the contrary, and for clarity, no Intellectual Property or other proprietary rights Controlled by PB
or its Affiliates will be assigned or licensed to SFJ in connection with this Agreement, except, if
executed by the Parties, as expressly set forth in the Program Transfer Agreement.

15.16 Nonsolicitation. During the Term and for a period of [***] thereafter, neither Party shall
solicit an employee of the other Party who is or has been involved in the performance or oversight
of any of the development activities hereunder to terminate his or her employment and accept
employment or work as a consultant with the soliciting Party. Notwithstanding the foregoing, nothing
herein shall restrict or preclude the Parties' right to make generalized searches for employees by
way of a general solicitation for employment placed in a trade journal, newspaper or website.

15.17 Amendments; No Waiver. Unless otherwise specified herein, no amendment, supplement, or
modification of this Agreement will be binding on either Party unless it is in writing and signed by
both Parties. No delay or failure on the part of a Party in the exercise of any right under this
Agreement or available at law or equity will be construed as a waiver of such right, nor will any
single or partial exercise thereof preclude any other exercise thereof. All waivers must be in
writing and signed by the Party against whom the waiver is to be effective. Any such waiver will
constitute a waiver only with respect to the specific matter described in such writing and will in
no way impair the rights of the Party granting such waiver in any other respect or at any other
time.

15.18 Severability. If any provision (or portion thereof) of this Agreement is determined by a court
or arbitration to be unenforceable as drafted by virtue of the scope, duration, extent, or character
of any obligation contained herein, it is the Parties' intention that such provision (or portion
thereof) will be construed in a manner designed to effectuate the purposes of such provision to the
maximum extent enforceable under such Applicable Law. The Parties will enter into whatever amendment
to this Agreement as may be necessary to effectuate such purposes.

15.19 Entire Agreement. This Agreement, including all Exhibits hereto and the Disclosure Letter,
contains the entire understanding of the Parties and supersedes, revokes, terminates, and cancels
any and all other arrangements, understandings, agreements, term sheets,

Source: PHASEBIO PHARMACEUTICALS INC, 10-K, 3/30/2020
<!-- page 93 -->
or representations and warranties, whether oral or written, between the Parties relating to the
subject matter of this Agreement.

15.20 Counterparts. This Agreement will be executed in two (2) counterparts, one (1) for either
Party, which, taken together, will constitute one and the same agreement. This Agreement will not be
binding on the Parties or otherwise effective unless and until executed by both Parties.

15.21 Construction. This Agreement has been negotiated by the Parties and their respective counsel.
This Agreement will not be construed in favor of or against either Party by reason of the authorship
of any provisions hereof.

[Signature Page Follows]

Source: PHASEBIO PHARMACEUTICALS INC, 10-K, 3/30/2020

IN WITNESS WHEREOF, the Parties, intending to be legally bound hereby, have caused this Agreement to
be executed in duplicate by their duly authorized representatives as of the Effective Date.

PHASEBIO PHARMACEUTICALS, INC.
<!-- page 94 -->
By: /s/ Jonathan Mow Name: Jonathan Mow Title: CEO

Date: January 9, 2020

SIGNATURE PAGE TO THE CO-DEVELOPMENT AGREEMENT

Source: PHASEBIO PHARMACEUTICALS INC, 10-K, 3/30/2020

IN WITNESS WHEREOF, the Parties, intending to be legally bound hereby, have caused this Agreement to
be executed in duplicate by their duly authorized representatives as of the Effective Date.

SFJ PHARMACEUTICALS X, LTD.
<!-- page 95 -->
By: /s/ Robert DeBenedetto Name: Robert DeBenedetto Title: Director

Date: January 9, 2020

SIGNATURE PAGE TO THE CO-DEVELOPMENT AGREEMENT

Source: PHASEBIO PHARMACEUTICALS INC, 10-K, 3/30/2020
<!-- page 96 -->
EXHIBIT LIST

Exhibit A The Product

Exhibit B Current Approved CROs

Exhibit C Current Approved Vendors

Exhibit D Development Plan

Exhibit E Executive Officers

Exhibit F‑1 PB Anti-Bribery and Anti-Corruption Practices

Exhibit F‑2 SFJ Anti-Bribery and Anti-Corruption Practices

Exhibit G SFJ European Operational Support

Exhibit H Warrant

Exhibit I Timeline

Exhibit J Manufacturer

Exhibit K Trial Data Package Purchase Agreement

Exhibit L AZ License

Exhibit M Amendment to AZ License

Exhibit N MedImmune Pharmacovigilance Agreement

Exhibit O Program Transfer Agreement

Exhibit P Terms of SVB Subordination Agreement

Source: PHASEBIO PHARMACEUTICALS INC, 10-K, 3/30/2020
