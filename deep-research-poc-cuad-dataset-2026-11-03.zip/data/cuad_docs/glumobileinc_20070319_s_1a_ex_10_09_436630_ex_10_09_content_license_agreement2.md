<!-- page 1 -->
# Wireless Content License Agreement Number 12965
| Field | Value |
|---|---|
| Document Type | License Agreement |
| Agreement Date | 2005-11-18 |
| Parties | Fox Mobile Entertainment ("Fox"); Glu Mobile, Inc. f/k/a Sorrent, Inc. ("Licensee") |
| Source | CUAD v1 / GluMobileInc_20070319_S-1A_EX-10.09_436630_EX-10.09_Content License Agreement2 |

AMENDMENT NO. 1

Dated as of November 11, 2005

Reference is hereby made to that certain fully executed Wireless Content License Agreement Number
12965 dated as of December 16, 2004 ("Agreement"), between TWENTIETH CENTURY FOX LICENSING &
MERCHANDISING, division of Fox Entertainment Group, Inc. ("Fox"), as Administrator for Twentieth
Century Fox Film Corporation ("Trademark Licensor") and Glu Mobile, Inc. f/k/a Sorrent, Inc.
("Licensee").

The parties agree to modify the Agreement as follows:

1. PARTIES

(a) FOX ASSIGNMENT OF AGREEMENT: Pursuant to Twentieth Century Fox Licensing and Merchandising's
assignment of rights and obligations through an assignment dated as of October 1, 2005 by and
between Twentieth Century Fox Licensing and Merchandising and Fox Mobile Entertainment Inc., Fox
Mobile Entertainment, Inc. is hereby substituted for Twentieth Century Fox Licensing and
Merchandising as "Fox" under the Agreement.

(b) LICENSEE CHANGE OF NAME: The parties hereby acknowledge that Licensee's change of name from
Sorrent, Inc. to Glu Mobile, Inc.

2. WIRELESS PRODUCTS

(a) "IN HER SHOES": Consistent with Paragraph 1(a)(ii), Exhibit A is amended to include the Property
"In Her Shoes" as a Targeted Release. Subject to talent restrictions with respect to the use of
likeness in merchandising and specifically excluding, without limitation, any use of the likeness of
Cameron Diaz for any content intended for sale, Licensee shall develop the following Wireless
Product in conjunction with "In Her Shoes": one (1) 2-D casual-style puzzle game. ("IN HER SHOES
Wireless Product")

(i) "IN HER SHOES" Porting: Licensee shall work with Fox's United Kingdom office to determine the
appropriate porting and support a potential release of the Wireless Product developed in connection
with "IN HER SHOES".

(ii) "IN HER SHOES" GUARANTEE AND ROYALTY: There shall be no Individual Property Guarantee
attributable to the Targeted Release "IN HER SHOES". Licensee may recoup the Guarantee Forfeiture
Payment (as defined in Paragraph 3 of this Amendment below) from the sales of the IN HER SHOES
Wireless Product. At such time that ***** percent (*****%) of the Guarantee Forfeiture Payment is
recouped by Licensee, Fox shall earn and Licensee shall pay to Fox Royalties at the rate of *****
percent (*****%) of Licensee's gross receipts from Licensee's sale, license, distribution or other
exploitation of the IN HER SHOES Wireless Product.

***** The omitted portions of this exhibit have been filed with the Securities and Exchange
Commission pursuant to a request for confidential treatment under Rule 406 promulgated under the
Securities Act of 1933.

Source: GLU MOBILE INC, S-1/A, 3/19/2007
<!-- page 2 -->
(iii) FOX INTELLECTUAL PROPERTY: Consistent with Paragraph 11(b) of the Agreement all music
developed and used in connection with the "IN HER SHOES" Wireless Product shall be owned exclusively
by Fox.

(b) "IDIOCRACY": Consistent with Paragraph 1(a)(ii), Exhibit A is amended to include the Property
"Idiocracy" as a Targeted Release. Licensee shall develop the following Wireless Product in
conjunction with "Idiocracy": one (1) game entitled "OW, MY ##@@@s" ("IDIOCRACY Wireless Product").

(i) "IDIOCRACY" GUARANTEE AND ROYALTY: There shall be no Individual Property guarantee attributable
to the targeted Release "IDIOCRACY". Licensee may recoup the guarantee Forfeiture Payment (as
defined in Paragraph 3 of this Amendment below) from the sales of the IDIOCRACY Wireless Product. At
such time that ***** percent (*****%) of the Guarantee Forfeiture Payment is recouped by Licensee,
Fox shall earn and Licensee shall pay to Fox Royalties at the rate of ***** percent (*****%) of
Licensee's gross receipts from Licensee's sale, license, distribution or other exploitation of the
IDIOCRACY Wireless Product.

(c) "ICE AGE 2":

(i) "ICE AGE 2" WIRELESS PRODUCTS: Licensee shall develop and distribute the following Wireless
Products in connection with the property "ICE AGE 2": (i) 1 Java Game; (ii) 1 Java Application
('Screensaver') where feasible; (iii) up to 5 MMS; (iv) up to 10 Wallpapers; (v) and up to 5
Voicetones ("ICE AGE 2 Wireless Products") in each of the following five (5) languages: English,
French, German, Italian, Spanish, with Portuguese, Greek, Dutch and Swedish to be made available
where practicable. Licensee shall have the non-exclusive right and license to develop and distribute
ICE AGE 2 Wireless Products during the Term of the Agreement for all Wireless Products set forth in
this Paragraph 2(c) except the Game, for which Licensee shall have the exclusive right and license
to develop and distribute until December 31, 2006. For the avoidance of doubt, Licensee's right and
license to develop and distribute the Game in connection with the Property "ICE AGE 2" shall become
non-exclusive after December 31, 2006.

(A) "ICE AGE 2" RESERVATION OF RIGHTS: Fox hereby reserves the right to develop, publish and/or
distribute (or grant a third party the right to develop, publish, and/or distribute) any wireless
products or wireless content or any nature which may be derived from the property "ICE AGE 2".
Notwithstanding the foregoing, in no event will Fox develop, publish and/or distribute games derived
from the Property "ICE AGE 2" prior to January 1, 2007.

(ii) "ICE AGE 2" GUARANTEE AND ROYALTY: In addition to any outstanding Guarantee payments which
Licensee shall pay to Fox as set forth in Paragraph 3 of this Amendment below, Licensee shall pay to
Fox a minimum recoupable guarantee of ***** dollars (US$*****) on or before ***** ("ICE AGE 2
Guarantee"), and

***** The omitted portions of this exhibit have been filed with the Securities and Exchange
Commission pursuant to a request for confidential treatment under Rule 406 promulgated under the
Securities Act of 1933.

Source: GLU MOBILE INC, S-1/A, 3/19/2007
<!-- page 3 -->
Fox shall earn, and Licensee shall pay the applicable Major Release Royalties as set forth in
Paragraph 7(a)(i) of the Agreement in connection with the property "ICE AGE 2". For the avoidance of
doubt, there shall be no cross- collateralization of the Royalties collected from Licensee's sale,
license, distribution or other exploitation of the Wireless Products derived from the Property "ICE
AGE 2", with the Royalties collected from any other Wireless Products released by Licensee under
this Agreement.

(d) "KINGDOM OF HEAVEN" VIDEO RIGHTS:

(i) Exhibits A and C are amended to replace "Untitled Ridley Scott Film" with "KINGDOM OF HEAVEN."
Exhibit C is further amended to include the KOH Video Clips as defined in Paragraph 3(b) below, with
the minimum number of clips to be determined by Fox.

(ii) Paragraph 1(a) of the Agreement is amended to provide that Fox grants Licensee a worldwide,
exclusive (except as otherwise may be provided in the Agreement), non-transferable right and license
to distribute video clips for the property "KINGDOM OF HEAVEN" ("KOH Video Clips"). Notwithstanding
the foregoing, Fox retains the right to develop and distribute promotional KOH Video Clips for the
purpose of marketing the Property and DVD, which shall consist of different video clips than those
developed for Licensee's distribution. Licensee's term of exclusivity with respect to the KOH Video
Clips shall expire on October 29, 2005, and Licensee's right and license to distribute the KOH Video
Clips shall expire twelve (12) months after the initial theatrical release of the Property "KINGDOM
OF HEAVEN". Fox shall produce the KOH Video Clips, and Licensee shall reimburse Fox for all
production costs associated with such production of the KOH Video Clips, which costs may not be used
by Licensee to recoup Licensee's Guarantee payable to Fox under the Agreement.

(iii) Paragraph 7 of the Agreement is amended to provide that with respect to the KOH Video Clips,
Fox shall be entitled to receive an amount equal to ***** percent (*****%) of ***** percent (*****%)
of the Gross Receipts derived from the distribution of the KOH Video Clips from the first dollar
Licensee earns ("KOH Video Clips Revenue"). With respect to KOH Video Clips which Licensee
distributes to VGSL, VGSL will remit directly to Fox, Fox's contractual share (pursuant to the VGSL
Agreement ) of such VGSL Revenue. Fox will remit all VGSL Revenue to Licensee and such VGSL Revenue
shall be treated as Gross Receipts for the purpose of this Agreement, and pursuant to this
Amendment, Licensee shall remit to Fox the KOH Video Clips Revenue derived from the VGSL Revenue.
The KOH Video Clips Revenue remitted by Licensee to Fox may not be used by Licensee to recoup the
Individual Property Guarantee for "KINGDOM OF HEAVEN" as set forth in Paragraph 6(b)(i) of the
Agreement.

3. GUARANTEE PAYMENT: Consistent with paragraph 15(c) of the Agreement, Licensee shall forfeit the
Guarantee paid to date of ***** dollars

***** The omitted portions of this exhibit have been filed with the Securities and Exchange
Commission pursuant to a request for confidential treatment under Rule 406 promulgated under the
Securities Act of 1933.

Source: GLU MOBILE INC, S-1/A, 3/19/2007
<!-- page 4 -->
(US$*****), and shall immediately pay the remaining Guarantee of ***** dollars (US$*****), equaling
a total Guarantee payment by Licensee to Fox of ***** dollars (US$*****) ("Guarantee Forfeiture
Payment"). The Guarantee Forfeiture Payment may be recouped from Licensee's sales of the IN HER
SHOES Wireless Product and the IDIOCRACY Wireless Product, as set forth in Paragraphs 2(a)(ii) and
2(b)(i) of this Amendment. Furthermore, pursuant to Paragraph 2(c)(ii) of this Amendment, Licensee
shall pay to Fox an additional minimum recoupable guarantee of ***** dollars (US$*****).

4. DIRECT-TO-CONSUMER DISTRIBUTION: Fox hereby reserves the right to distribute all Wireless
Products through Fox's direct-to-consumer distribution channels, for which Fox shall retain a
Distribution Fee as defined in Paragraph 4(a) of this Amendment.

(a) DISTRIBUTION FEE FOR DIRECT-TO-CONSUMER DISTRIBUTION: Should Fox or its assigns choose to
distribute the Wireless Products through Fox's and its assigns' direct-to-consumer distribution
channels, Fox or its assigns shall deduct a percentage of Fox's Gross Receipts (defined as monies
received by or credited to Fox or its assigns from Fox's or its assigns' direct-to-consumer
distribution channels, for the download of the Wireless Products by end users, or the sale or
download of Wireless Products to end users) collected from the sale of such Wireless Products
("Distribution Fee") in the amount of ***** percent (*****%) of Fox's Gross Receipts. After Fox or
its assigns deducts its Distribution Fee, it shall remit the remainder to Licensee and Licensee
shall pay to Fox or its assigns or such other party as Fox or its assigns may designate in writing,
Royalties in the amounts set forth in the Agreement or this Amendment.

5. MUTUTAL RELEASE: With the exception of Licensee's Royalties payment obligations with respect to
all Wireless Products released as of the date of this Amendment, and the obligations set forth in
this Amendment, neither party shall have any further obligation under the Agreement, and all claims
arising under the Agreement shall be mutually released.

***** The omitted portions of this exhibit have been filed with the Securities and Exchange
Commission pursuant to a request for confidential treatment under Rule 406 promulgated under the
Securities Act of 1933.

Source: GLU MOBILE INC, S-1/A, 3/19/2007
<!-- page 5 -->
By signing in the places indicated below, the parties hereto accept and agree to all of the terms
and conditions hereof.

Glu Mobile, Inc. f/k/a Sorrent, Inc. Fox Mobile Entertainment, Inc. ("Fox") ("Licensee") By: /s/
Paul Zuzelo By: /s/ Jamie Samson Name: Paul Zuzelo Jamie Samson Its: Chief Administrative Officer
Its: Senior Vice President Date: November 18, 2005 Date: 11/18/05

Source: GLU MOBILE INC, S-1/A, 3/19/2007
