<!-- page 1 -->
# Strategic Alliance Agreement
| Field | Value |
|---|---|
| Document Type | Strategic Alliance Agreement |
| Agreement Date | 2017-06-30 |
| Parties | Turnkey Capital Inc. ("TKCI"); Seminole Indian Company ("SIC") |
| Source | CUAD v1 / TURNKEYCAPITAL,INC_07_20_2017-EX-1.1-Strategic Alliance Agreement |

1.

2.

2.1

2.2

3.

3.1

3.2

4.

4.1

EXHIBIT 1.1 Strategic Alliance Agreement

This Agreement is made and entered into this 30th day of June 2017,

Between: Turnkey Capital Inc., having its office located at 2929 E. Commercial Blvd, Suite PH-D, Ft.
Lauderdale, Florida, hereinafter referred to as "TKCI";

And:

A Seminole Indian Company to be formed by Former Seminole Tribal Chairman James E. Billie and Craig
Talesman, having an office located at 1800 Frank Huff Road, Seminole Reservation, Okeechobee, FL
34974, hereinafter referred to as "SIC".

Overview

The purpose and intent of this strategic alliance is to combine the resources and talents of, TKCI
and SIC, in order to take advantage of every opportunity permitted by tribal sovereignty to create
revenue streams in multiple areas in conjunction with operating partners that have existing
marketing and customers in place, thereby limiting the capital requirements and risk. New marketing
advantages based upon competitive pricing, cross marketing and new revenue streams from expansion
into other industries will grow the business beyond anything previously imagined. The structure may
also be used for additional compatible acquisitions which will also fuel growth. TKCI believes that
structuring operations with Tribal Sovereignty will deliver the financial advantages of operating in
a tax free environment with limited liability, plus other benefits such as permit and zoning ease,
supporting an ideal structure for investment capital and successful entrepreneurial ventures.

Term

The term of this Agreement is twenty-four (24) months. The Agreement may be renewed, subject to
mutual written approval.

Notwithstanding the completion, expiration or termination of this Agreement, the indemnities
warranties and undertakings contained or referred to in this Agreement shall continue to subsist for
as long as may be necessary for the purpose of giving effect to each one and every one of them.

TKCI Committments

TKCI shall establish a wholly-owned subsidiary (the "Holding Company") for the sole purpose of
conducting and developing business on behalf of this alliance. The utilization of this subsidiary
will provide for separate record keeping, reporting and tracking of all business related to this
agreement.

In addition to capital recruitment functions, TKCI shall perform all of the functions and accept all
of the responsibilities of the position of Chief Financial Officer including but not limited to
management of accounts receivable and accounts payable, interfacing with Holding Company accountants
on tax matters, interfacing with Holding Company accountants and lawyers on regulatory and
compliance matters, and all other tasks typically and reasonably associated with the post and
position of Chief Financial Officer.

Committments and Rights of SIC

SIC acknowledges and agrees that the ability of TKCI to render its services is uniquely dependent
upon

4.2

4.3

4.4

4.5

4.6

4.7

5.

5.1

5.1.1

5.1.2

5.2

5.5.1

5.5.2

5.3

5.4
<!-- page 2 -->
the cooperation and provision of information to TKCI by Chief James E. Billie and Craig Talesman for
SIC. In the event that information is required, it shall be provided in writing.

SIC, represented by Chief James E. Billie and Craig Talesman, will assist in the closing of the
transactions by: 1) participating in meetings with key decision makers, providing process overview,
and describing case histories of similarly situated projects; and 2) providing advice on issues such
as i) location; (ii) deal structure; (iii) funding; (iv) timing/phasing; (v) cash flow/revenue
collection issues; and (vi) other major implementation issues.

SIC shall allow TKCI to review and analyze all business opportunities that could be mutually
beneficial to TKCI and SIC within the time frame of this alliance.

SIC, represented by Chief James E. Billie and Craig Talesman, will assist in the finalization of
project structuring plans geared toward maximizing all available revenue streams.

SIC, represented by Chief James E. Billie and Craig Talesman, will provide access to other
opportunities.

The decision to join this alliance is at the absolute discretion of Chief James E. Billie and Craig
Talesman. TKCI affirms that it shall not have any claim towards SIC if the management decides not to
sign the agreement in the investigation stage, and before any agreements are signed, for any reasons
whatsoever.

SIC may try to locate, or authorize others to locate potential investors who are not Reserved
Investors (or Rejected Investors), and SIC may accept investments from such other investors, without
incurring any liability towards TKCI

Fees and Financial Structuring

A wholly-owned subsidiary (the "Holding Company") shall be established by TKCI to accomplish the
following:

To hold the assets and liabilities of the TKCI/SIC alliance and provide for separate management of
the alliance business operations.

Operating capital may be raised and a growing shareholder base may be established to support future
expansion.

Net revenue from business operations created by Holding Company for the alliance will be distributed
by Holding Company equally - 50/50 - to TKCI and SIC:

SIC's original business concepts and plans, as well as opportunities brought to the table through
its connections, and third-party contracts, are ways that we anticipate business could be generated,
and revenues created; TKCI's advisory and management services and capital resources will provide the
critical structure and business mechanism to carry concepts through to revenue. Turnkey Capital Inc.
(TKCI) will reserve ten percent (10%) of the shares of TKCI for SIC. These shares will be issued
once an exclusivity agreement is reached. Once the Holding Company is raising funds and generating
revenue, the parties will negotiate a monthly fee.

6

7.

8. 8.1

8.2

9. 9.1

9.2

9.3
<!-- page 3 -->
Confidentiality and non-compete During the term of this Agreement and for one (1) year thereafter,
TKCI will keep in confidence, not reveal, not use and not allow or assist others to use, any
information marked "Confidential" received from or through SIC in the context of its activities
hereunder, except as authorized in writing by SIC. However, TKCI may assume that unless SIC
specifically advises it to the contrary, in writing, with respect to an item of information, it may
reasonably make such information available to third parties that TKCI is attempting to introduce to
SIC. Such information includes, but is not limited to SIC's business plans and proprietary
disclosures. The above provisions will survive the termination of this Agreement, except they will
not apply to information that (i) is in the public domain or later becomes available to the public
through no breach of this Agreement by either party; (ii) is obtained by either party from a third
party who had the legal right to disclose the information to that party; (iii) is already in the
possession of the receiving party on the date this Agreement becomes effective; (iv) is
independently developed by either party or (v) is required to be disclosed by law, government
regulation, or court order.

Termination This Agreement may be terminated early if mutually agreed to by both parties in writing,
or for cause, which is defined as conviction of either party of a criminal offense, actions in bad
faith, and knowing or intentional misconduct, failure to perform as determined by SIC, or a material
breach of this Agreement. The expiration or early termination of this Agreement shall not affect any
of its provisions which are expressed to operate or have an effect afterwards or any right of action
already accrued to either party in respect of any breach by the other party.

Warranties and Indemnification SIC represents and warrants to TKCI that the undersigned are duly
authorized to execute and enter into this Agreement, and that all information relating to SIC
furnished by Chief James E. Billie and Craig Talesman, or its other representatives, to TKCI will be
complete, accurate and not misleading.

Each party ("the Defaulting party") shall indemnify the other party ("the Innocent party") and keep
the Innocent Party indemnified and harmless from and against any claims brought against the Innocent
Party as a result of any acts or omissions of the Defaulting Party, whether such acts or omissions
relate to the Defaulting Party's tasks under this Agreement or not. The Defaulting Party's liability
under this provision shall extend to legal fees and to court and/or arbitration expenses, as the
case may be as well as any other expenses incurred by the Innocent Party in the course of defending
and/or handling and/or settling such claim.

Strategic Alliance TKCI is performing under this Agreement as a Strategic Alliance member and is not
a legal or implied agent or employee of SIC. This Agreement does not create agency or employment
relationship between the parties hereto.

TKCI shall not, by reason of this Agreement or the performance of the services delineated herein, be
or be deemed to be, an employee of SIC, and TKCI shall have no power to enter into any agreement on
behalf of, or otherwise bind SIC. Without limiting the foregoing, TKCI shall not enter into any
contract or commitment on behalf of SIC.

SIC acknowledges and agrees that TKCI shall have no liability resulting from TKCI's failure to
obtain any financing for any of its programs or business concepts. Neither party shall have any
claim whatsoever against the other if an investment or a sales opportunity was lost because of any
of the other party's acts or omissions.

9.4

9.5

10. 10.1 10.2

10.3

11. 11.1

11.2

11.3

11.4

11.5
<!-- page 4 -->
SIC understands that TKCI is not acting as a broker-dealer or dealer in securities with respect to
any transaction contemplated hereunder, and that any securities which may be sold in respect to any
such transaction are being sold directly by or to SIC, to or by TKCI parties to such transaction.
SIC acknowledges and agrees that no liability will be attributed to TKCI in connection with the
issuance of any equity or securities. Any fees due to TKCI are to be paid solely as finder's fee and
as remuneration for other services provided for under this Agreement.

TKCI will have First Right of Refusal with regard to any sale or disposition of any part or the
whole of companies or projects developed in relationship with this alliance.

Arbitration This Agreement shall be governed by the laws of the State of Florida. Any disputes
arising under or in connection with the validity, interpretation and performance of this Agreement
that cannot be resolved amicably by the parties shall be settled in arbitration before a single
arbitrator. If arbitration fails to render a mutually agreement resolution the Courts of the State
of Florida will be deemed to have jurisdiction. In addition to all other remedies provided in this
Agreement, the prevailing party shall be entitled to all costs and expenses reasonably incurred as a
result of said breach, including arbitration and court costs, and reasonable attorney's fees.

Miscellaneous This Agreement, together with any added Appendices, constitutes the entire agreement
between the parties with respect to its subject matter and supersedes any prior agreement. This
Agreement may be changed only by mutual agreement between the parties, expressed in writing.

All notices under this Agreement shall be in writing and shall be deemed given if delivered to the
party personally, or five (5) days after sent by registered airmail or by an express courier, as
well as delivery by confirmed facsimile transmission or confirmed electronic mail. The addresses for
notices given under this Agreement shall be those provided above.

If any provision of this Agreement is held by an arbitrator to be invalid, void or unenforceable,
the remaining provisions shall nevertheless continue in full force, and the stricken provision shall
be replaced by a valid, legal and enforceable provision having as nearly as possible the same
economic and practical effect.

This Agreement shall be binding on all parties' respective assigns and successors.

Facsimile copies of this Agreement, with signatures, shall be given the same legal effect as an
original with original signatures.

And in witness, the parties sign on the day and date first above written:

For Chief James E. Billie Craig Talesman Turnkey Capital Inc. Sign: /s/ Chief James E. Billie /s/
Craig Talesman /s/ Neil Swartz Name: Craig Talesman Neil Swartz Title: Chief Executive Officer
