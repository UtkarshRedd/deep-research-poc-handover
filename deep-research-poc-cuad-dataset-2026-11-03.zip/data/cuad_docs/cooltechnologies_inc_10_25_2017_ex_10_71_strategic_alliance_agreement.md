<!-- page 1 -->
# Strategic Alliance Agreement
| Field | Value |
|---|---|
| Document Type | Strategic Alliance Agreement |
| Agreement Date | 2017-05-26 |
| Parties | Cool Technologies Inc. ("COOL TECH"); VETERAN TECHNOLOGY GROUP, LLC ("VET TECH") |
| Source | CUAD v1 / COOLTECHNOLOGIES,INC_10_25_2017-EX-10.71-Strategic Alliance Agreement |

EXHIBIT 10.71

May 04, 2017 Strategic Alliance Agreement This Strategic Alliance Agreement (this "Agreement") is
entered into as of the 26t h day of May, 2017 (hereinafter referred to as the effective date of the
Agreement), by and between Cool Technologies Inc.., a Nevada corporation (hereinafter referred to as
"COOL TECH"), and VETERAN TECHNOLOGY GROUP, LLC, a Missouri corporation (hereinafter referred to as
"VET TECH"). WITNESSETH: WHEREAS, COOL TECH and VET TECH wish to enter into a strategic alliance to
market and perform certain complementary business consulting services; NOW, THEREFORE, in
consideration of the foregoing and of the mutual premises hereinafter expressed, the parties hereto
do mutually agree as follows: ARTICLE I. SCOPE OF STRATEGIC ALLIANCE. A. COOL TECH shall, in a
professional manner, take all steps necessary to market and produce its Mobile Generation Program
and its other services (collectively the "COOL TECH Services") for clients referred to COOL TECH by
VET TECH. Any engagement to perform COOL TECH Services shall be on such terms and conditions as COOL
TECH may approve at its sole discretion. COOL TECH will perform, schedule, staff and manage all COOL
TECH Services or with COOL TECH/VET TECH approved team. Notwithstanding the foregoing, VET TECH may,
at its election, bill the client directly for COOL TECH Services and under such circumstances COOL
TECH shall bill VET TECH the pre-agreed amount for the engagement as adjusted by any client-approved
change orders. For any Government Sales brought by VET TECH COOL TECH agrees to be held to the same
billing and payment terms as is dictated under the Federal Acquisition Regulation (FAR) guidelines
and requirements; otherwise, COOL TECH will bill the client directly. VET TECH agrees to include
reference to COOL TECH in each contract and proposal involving COOL TECH Services. COOL TECH's
Mobile Generation ("MG"), and other proprietary information and associated products, copyrights,
trademarks, trade names and logos developed by COOL TECH shall remain the property of COOL TECH and
reference to COOL TECH's rights shall be made in all uses of such materials in at least 12 point
type. 1
<!-- page 2 -->
B. VET TECH shall, in a professional manner, take all steps necessary to market and perform its
business management consulting, GAIT Software and other AI services (collectively the "VET TECH
Services") for clients referred to VET TECH by COOL TECH. Any engagement to perform VET TECH
Services shall be on such terms and conditions as VET TECH may approve in its sole discretion. VET
TECH will perform, schedule, staff and manage all VET TECH Services or a joint VET TECH/COOL TECH
team. VET TECH will perform, schedule, staff and manage all VET TECH Services or with VET TECH/COOL
TECH approved team. Notwithstanding the foregoing, COOL TECH may, at its election, bill the client
directly for VET TECH Services and under such circumstances VET TECH shall bill COOL TECH the
pre-agreed amount for the engagement as adjusted by any client-approved change orders; otherwise,
VET TECH will bill the client directly. COOL TECH agrees to include reference to VET TECH in each
contract and proposal involving VET TECH Services. VET TECH's GAIT Software and other AI services
(collectively the "VET TECH Services"), and other proprietary information and associated products,
copyrights, trademarks, trade names and logos developed by VET TECH shall remain the property of VET
TECH and reference to VET TECH's rights shall be made in all uses of such materials in at least 12
point type. ARTICLE II. PERIOD OF PERFORMANCE. This Agreement shall be effective as of the date
first set forth above and, shall expire on the later of (i) five (5) years from the date hereof, or
(ii) with respect to any projects identified in any contract for which VET TECH is billing the
client directly, upon the completion of COOL TECH's Services and receipt of payment by COOL TECH
from VET TECH for said services. This Agreement shall be automatically renewed for successive one
year periods unless either party gives written notice of termination to the other party at least
thirty (30) days prior to the date of expiration. Notwithstanding the foregoing, this Agreement
shall be earlier terminated (x) by mutual agreement of the parties, or (y) at any time upon sixty
(60) days advance written notice to the other party. Time is of the essence in this Agreement. 2
<!-- page 3 -->
ARTICLE III. MANAGEMENT. Each party shall designate a partner, officer or other senior person to be
responsible for the overall administration of this Agreement. VET TECH shall have ultimate
responsibility for client relationships for those clients that it elects to bill directly for COOL
TECH Services and COOL TECH will respond to VET TECH's direction. ARTICLE IV. CONFIDENTIAL
INFORMATION. The parties acknowledge and agree that in the course of the performance of the VET TECH
Services and the COOL TECH Services (collectively, the "Services") or additional services pursuant
to this Agreement, that each may be given access to, or come into possession of, confidential
information of the other party which information may contain trade secrets, proprietary data or
other confidential material of that party. Therefore the parties have executed a Non-Disclosure
Agreement which is attached hereto as Exhibit A, and incorporated by reference as if fully set forth
herein. Materials used in any engagement undertaken pursuant to this Agreement shall not be altered
or changed without the consent of both parties. ARTICLE V. NO PARTNERSHIP. Nothing herein contained
shall be construed to imply a joint venture, partnership or principal- agent relationship between
VET TECH and COOL TECH, and neither party shall have the right, power or authority to obligate or
bind the other in any manner whatsoever, except as otherwise agreed to in writing. The parties do
not contemplate a sharing of profits relating to the VET TECH Services or the COOL TECH Services so
as to create a separate taxable entity under Section 761 of the Internal Revenue Code of 1986, as
amended, nor co-ownership of a business or property so as to create a separate partnership under the
law of any jurisdiction, including, without limitation, MISSOURI or NEVADA. Accordingly, for tax,
property and liability purposes VET TECH will provide the VET TECH Services, and COOL TECH will
perform the COOL TECH Services, each on a professional basis and as an independent contractor of the
other. JOINT SERVICES WILL BE DEFINED IN ADDENDUM XX. Revenues and expenses relating to the Services
and any additional services shall be reported separately by the parties for tax purposes. During the
performance of the any of the Services, VET TECH's employees will not be considered employees of
COOL TECH, and vice versa, within the meaning or the applications of any federal, state or local
laws or regulations including, but not limited to, laws or regulations covering unemployment
insurance, old age benefits, worker's compensation, industrial accident, labor or taxes of any kind.
VET TECH's personnel who are to perform the VET TECH Services or additional services to be provided
by VET TECH hereunder shall be under the employment, and ultimate control, management and
supervision of VET TECH. COOL TECH's personnel who are to perform the COOL TECH Services or
additional services to be provided by COOL TECH hereunder shall be under the employment, and
ultimate control, management and supervision of COOL TECH. It is understood and agreed that COOL
TECH's employees shall not be considered VET TECH's employees within the meaning or application of
VET TECH's employee fringe benefit programs for the purpose of vacations, holidays, pension, group
life insurance, accidental death, medical, hospitalization, and surgical benefits, and vice versa. 3
<!-- page 4 -->
ARTICLE VI. TRADEMARK, TRADE NAME AND COPYRIGHTS. Except as expressly provided herein, this
Agreement does not give either party any ownership rights or interest in the other party's trade
name, trademarks or copyrights. ARTICLE VII. INDEMNIFICATION. Each of VET TECH and COOL TECH, at its
own expense, shall indemnify, defend and hold the other, its partners, shareholders, directors,
officers, employees, and agents harmless from and against any and all third-party suits, actions,
investigations and proceedings, and related costs and expenses (including reasonable attorney's
fees) resulting solely and directly from the indemnifying party's negligence or willful misconduct.
Neither VET TECH nor COOL TECH shall be required hereunder to defend, indemnify or hold harmless the
other and/or its partners, shareholders, directors, officers, directors, employees and agents, or
any of them, from any liability resulting from the negligence or wrongful acts of the party seeking
indemnification or of any third- party. Each of VET TECH and COOL TECH agrees to give the other
prompt written notice of any claim or other matter as to which it believes this indemnification
provision is applicable. The indemnifying party shall have the right to defend against any such
claim with counsel of its own choosing and to settle and/or compromise such claim as it deems
appropriate. Each party further agrees to cooperate with the other in the defense of any such claim
or other matter. ARTICLE VIII. NON-SOLICITATION OF PERSONNEL. COOL TECH and VET TECH agree not to
engage in any attempt whatsoever, to hire, or to engage as independent contractors, the other's
employees or independent contractors during the term of this Agreement and for a period of six (6)
months following expiration or termination of this Agreement except as may be mutually agreed in
writing. ARTICLE IX. INTELLECTUAL PROPERTY Work performed on engagements pursuant to this Agreement
by either VET TECH and/or COOL TECH and information, materials, products and deliverables developed
in connection with engagements pursuant to this Agreement shall be the property of the respective
parties performing the work or creating the information. All underlying methodology utilized by COOL
TECH and VET TECH respectively which was created and/or developed by either prior to the date of
this Agreement and utilized in the course of performing engagements pursuant to this Agreement shall
not become the property of the other. Each party's rights, titles and interests are described in the
Non-Disclosure Agreement attached hereto as Exhibit A. 4
<!-- page 5 -->
ARTICLE X. GENERAL PROVISIONS. A. Entire Agreement: This Agreement together with all documents
incorporated by reference herein, constitutes the entire and sole agreement between the parties with
respect to the subject matter hereof and supersedes any prior agreements, negotiations,
understandings, or other matters, whether oral or written, with respect to the subject matter
hereof. This Agreement cannot be modified, changed or amended, except for in writing signed by a
duly authorized representative of each of the parties. B. Conflict: In the event of any conflict,
ambiguity or inconsistency between this Agreement and any other document which may be annexed
hereto, the terms of this Agreement shall govern. C. Assignment and Delegation: Neither party shall
assign or delegate this Agreement or any rights, duties or obligations hereunder to any other person
and/or entity without prior express written approval of the other party. D. Notices: Any notice
required or permitted to be given under this Agreement shall be in writing, by hand delivery,
commercial overnight courier or registered or certified U.S. Mail, to the address stated below for
COOL TECH or to the address stated below for VET TECH, and shall be deemed duly given upon receipt,
or if by registered or certified mail three (3) business days following deposit in the U.S. Mail.
The parties hereto may from time to time designate in writing other addresses expressly for the
purpose of receipt of notice hereunder. If to VET TECH: If to COOL TECH: E. Severability: If any
provision of this Agreement is declared invalid or unenforceable, such provision shall be deemed
modified to the extent necessary and possible to render it valid and enforceable. In any event, the
unenforceability or invalidity of any provision shall not affect any other provision of this
Agreement, and this Agreement shall continue in full force and effect, and be construed and
enforced, as if such provision had not been included, or had been modified as above provided, as the
case may be. F. Governing Law: This Agreement shall be governed by and construed in accordance with
the laws of the State of Missouri. Without giving effect to its choice of law principles. 5
<!-- page 6 -->
G. Paragraph Headings: The paragraph headings set forth in this Agreement are for the convenience of
the parties, and in no way define, limit, or describe the scope or intent of this Agreement and are
to be given no legal effect. H. Counterparts: This Agreement may be executed in two or more
counterparts, each of which shall be deemed an original, but all of which together shall constitute
one and the same instrument. I. Exhibits: The Exhibits attached hereto are made a part of this
Agreement as if fully set forth herein. IN WITNESS WHEREOF, the parties, by their duly authorized
representatives, have caused this Agreement to be executed as of the date first written above.
Veteran Technology Group, LLC Cool Technologies Inc. By: Name: /s/ Michael Grimes___ /s/ Timothy
Hassett___ By: Name: _Michael Grimes ____ ___Timothy Hassett__ 6
