<!-- page 1 -->
# JOINT CONTENT LICENSE AGREEMENT
| Field | Value |
|---|---|
| Document Type | License Agreement |
| Agreement Date | 2018-02-01 |
| Parties | WPT Enterprises, Inc. (“WPT”); ZYNGA INC. (“Zynga US”); ZYNGA GAME IRELAND LIMITED ("Zynga Ireland", and together with Zynga US and their respective Affiliates, “Zynga”) |
| Source | CUAD v1 / AlliedEsportsEntertainmentInc_20190815_8-K_EX-10.19_11788293_EX-10.19_Content License Agreement |

Exhibit 10.19 JOINT CONTENT LICENSE AGREEMENT This JOINT CONTENT LICENSE AGREEMENT (the
"Agreement"), dated February 1, 2018 (the "Effective Date"), is made by and between WPT Enterprises,
Inc., a Delaware corporation, with offices located at 1920 Main Street, Suite 1150, Irvine, CA 92614
("WPT"), and ZYNGA INC., a Delaware corporation with offices located at 699 8th Street, San
Francisco CA, 94103 ("Zynga US") and ZYNGA GAME IRELAND LIMITED, a limited company organized under
the laws of Ireland, resident in Ireland and having its registered office located at The Oval,
Building One, Third Floor 160 Shelbourne Road Ballsbridge 4 Co. Dublin Ireland ("Zynga Ireland," and
together with Zynga US and their respective Affiliates, "Zynga"). In addition to the Definitions set
forth in Section 1 of the Additional Provisions (attached and incorporated by reference), all
capitalized terms used herein shall have the meanings set forth below. In consideration of the
mutual promises herein contained and for other good and valuable consideration, the receipt and
sufficiency of which are hereby acknowledged, the parties hereby agree as follows: BASIC PROVISIONS
1. Joint Content License Relationship. Among other games, Zynga produces and distributes the ZYNGA
POKER® game on a number of global platforms, including Apple iOS, Google Android, Facebook and the
zynga.com website. The ZYNGA POKER® game features a Zynga Poker Tournaments Mode that Zynga can
customize. Among other things, WPT is the creator of the World Poker Tour, WPT Tournaments and the
WPT Invitational Tournaments. WPT Tournaments and WPT Invitational Tournaments are televised poker
tournaments where a partner can promote its brand. The parties desire to work cooperatively, but
independently, to use commercially reasonable efforts to engage in the marketing and promotional
activities described in Exhibit A, including, but not limited to Zynga promoting the WPT brand in a
WPT-branded Zynga Poker Tournament Mode, and WPT promoting the Zynga brand in WPT Tournaments and
WPT Invitational Tournaments. This Agreement describes the terms of a content license and
cooperative marketing relationship under which each party will independently or cooperatively engage
in mutually agreed activities to promote each other's products and services throughout the Territory
(as defined below). 2. Territory. The Territory for this Agreement is worldwide, but not including
Asian countries (including, but not limited to, Bangladesh, Bhutan, Brunei, Cambodia, East Timor,
Hong Kong, India, Indonesia, Japan, Laos, Macau, Malaysia, Maldives, Mongolia, Myanmar, Nepal, North
Korea, Pakistan, People's Republic of China, Philippines, Singapore, South Korea, Sri Lanka, Taiwan,
Thailand, Vietnam). The parties acknowledge and agree that the rights granted hereunder by Zynga (a)
with respect to the United States are granted to, held and exercised by Zynga US and (b) with
respect to all other parts of the Territory are granted to, held and exercised by Zynga Ireland.

1

Source: ALLIED ESPORTS ENTERTAINMENT, INC., 8-K, 8/15/2019
<!-- page 2 -->
3. Term. This Agreement will be in effect for three (3) years from the Effective Date ("Initial
Term") unless terminated earlier in accordance with this Agreement. This Agreement shall
automatically extend for an additional two (2) years on the same terms herein ("Renewal Term")
provided WPT receives payments greater than twelve million U.S. dollars ($12,000,000) within the
Initial Term. The Initial Term and any such Renewal Term are collectively referred to as the "Term."
4. Annual Minimum Guarantee. Zynga will pay WPT three million U.S. dollars ($3,000,000) per year
according to the following schedule (which the parties may alter upon mutual agreement) (the "Annual
Minimum Guarantee"): a. Within thirty (30) days of executing this Agreement: $1.5M b. July 1, 2018:
$1.5M c. January 1, 2019: $1.5M d. July 1, 2019: $1.5M e. January 1, 2020: $1.5M f. July 1, 2020:
$1.5M 5. Royalty. Zynga will pay to WPT ten percent (10%) of the cumulative Net Revenue (as defined
in Section 3.b. of the Additional Provisions) ("Royalty") from the WPT-branded Zynga Poker
Tournament Mode or other such use of the WPT brand on the Zynga platform. Zynga shall not be
required to pay the Royalty to the extent offset by the Annual Minimum Guarantee payments previously
paid to WPT during the Term. Conversely, Zynga shall not be required to make Annual Minimum
Guarantee payments to the extent offset by the Royalty previously paid to WPT during the Term. The
Additional Provisions and any attached Exhibits are incorporated by reference. Signature page to
follow.

2

Source: ALLIED ESPORTS ENTERTAINMENT, INC., 8-K, 8/15/2019
<!-- page 3 -->
IN WITNESS WHEREOF ZYNGA INC. Signature: ______________________ Name: _________________________
Title: __________________________

WPT ENTERPRISES, INC. Signature: _________________________ Name: ____________________________ Title:
_____________________________ ZYNGA GAME IRELAND LIMITED Signature: ______________________ Name:
_________________________ Title: __________________________

3

Source: ALLIED ESPORTS ENTERTAINMENT, INC., 8-K, 8/15/2019
<!-- page 4 -->
ADDITIONAL PROVISIONS The following Additional Provisions form part of the Agreement dated February
1, 2018 entered into by and between ZYNGA INC. and ZYNGA GAME IRELAND LIMITED and their respective
affiliates ("Zynga"), and WPT Enterprises, Inc. ("WPT"). 1. DEFINITIONS a. "Affiliate" means an
entity, directly or indirectly, controlled by, controlling of, or under common control with a party,
either now or in the future, and their respective successors and assigns. b. "Artwork" means,
without limitation, all pictorial, graphic, visual, audio, audio-visual, digital, literary,
animated, artistic, dramatic, sculptural, musical or any other type of creation or application,
whether finished or not, including, without limitation, animation, drawings, designs, sketches,
images, illustrations, film, video, electronic, digitized or computerized information, software,
object code, source code, on-line elements, music, text, dialogue, stories, visuals, effects,
scripts, voiceovers, logos, one-sheets, promotional pieces, packaging, display materials, printed
materials, photographs, interstitials, notes, shot logs, character profiles and translations. c.
"Agreement" means the Basic Provisions, these Additional Provisions, and any and all attached
Exhibits. d. "Licensed Property" means those specific trademarks, service marks, publicity rights,
copyrights, intellectual property rights, and any other items set forth in this Agreement, which the
parties may utilize in connection with the marketing and promotional activities in Exhibit A. A list
of the Licensed Property for each party is described in Exhibit B. e. "Annual Minimum Guarantee"
means the guaranteed minimum amount due to WPT by Zynga in consideration of the rights granted
herein, which amount may be recoupable from Royalties as set forth below and in the Basic
Provisions. f. "Royalty" means the amount(s) set forth in the Basic Provisions and calculated as
described in the Additional Provisions. g. "Term" means the term of this Agreement as set forth in
the Basic Provisions. h. "Territory" means the territory throughout which the parties are authorized
to engage in the marketing and promotional activities as described in Exhibit A and in the Basic
Provisions. 2. TRADEMARKS, APPROVALS, AND RESERVATION OF RIGHTS a. Materials. To the extent
indicated on Exhibit A, each party will provide the other party with electronic files containing the
Licensed Property of such party to be used under this Agreement, as specified in Exhibit B, if any.
b. License by Zynga. Subject to the terms and conditions of this Agreement, Zynga grants to WPT a
non-exclusive, non- assignable, non-sublicensable, royalty-free, paid up, limited worldwide license
to use and display Zynga's Licensed Property solely as necessary to perform WPT's obligations under
this Agreement and as specifically described on Exhibit A, in any and all media now known or
hereafter devised, for the Term (subject to Section 7.e. of Additional Provisions). c. License by
WPT. Subject to the terms and conditions of this Agreement, WPT grants to Zynga a non-exclusive,
non-assignable, non-sublicensable, royalty-free, paid up, limited license in the Territory to use
and display WPT's Licensed Property solely as necessary to perform Zynga's obligations under this
Agreement and as specifically described on Exhibit A, for the Term. d. Trademark Guidelines. In its
use of the Licensed Property of the other party ("Licensee"), each party ("Licensor") will comply
with any trademark usage guidelines that Licensor may communicate to Licensee from time to time.
Each use of Licensor's marks by Licensee will be accompanied by the appropriate trademark symbol
(either "™" or "®") and a legend specifying that such marks are trademarks of Licensor as specified
on Exhibit B, and will be in accordance with Licensor's then-current trademark usage policies as
provided in writing to Licensee from time to time. Licensee will provide Licensor with copies of any
materials bearing any of Licensor's marks as requested by Licensor from time to time. If Licensee's
use of any of Licensor's marks, or if any material bearing such marks, does not comply with the
then-current trademark usage policies provided in writing by Licensor, Licensee will promptly remedy
such deficiencies upon receipt of written notice of such deficiencies from Licensor. Other than the
express licenses granted herein with respect to each Licensor's marks, nothing herein will grant to
Licensee any other right, title or interest in Licensor's marks. All goodwill resulting from
Licensee's use of Licensor's marks will inure solely to Licensor. Each party recognizes the great
value of the publicity and good will associated with the Licensed Property and acknowledges that:
(a) such good will is exclusively that of Licensor or Licensee, as applicable; and (b) the Licensed
Property have acquired a secondary meaning as trademarks and/or identifications of Licensor or
Licensee, as applicable, in the mind of the purchasing public. Licensee will not, at any time during
or after this Agreement, register, attempt to register, claim any interest in, contest the use of,
or otherwise adversely affect the validity of any of Licensor's marks (including, without
limitation, any act or assistance to any act, which may infringe or lead to the infringement of any
such marks).

4

Source: ALLIED ESPORTS ENTERTAINMENT, INC., 8-K, 8/15/2019
<!-- page 5 -->
e. Approvals. The Licensed Property shall be displayed or used only in such form and in such manner
as has been approved in writing (which may be by email) by Licensor pursuant to this Section 2 and
Licensee shall ensure its usage of the Licensed Property solely as approved. Throughout the Term,
including any renewals or extensions (if applicable), Licensee shall comply with reasonable quality
standards, style guides and clear specifications communicated to Licensee and rights of approval of
Licensor set forth in this Section 2 with respect to any and all of its usage of the Licensed
Property. Subject to Licensor's prior written approval of any applicable Licensed Property
(hereinafter the "Approved Content"), all Conforming Content will be deemed approved by Licensor.
"Conforming Content" means any and all elements of the Approved Content which (i) do not represent
deviations in quality, style, look-and-feel or other aspects of use from the Approved Content and
(ii) are consistent with the aesthetic style or tone of the Approved Content. The parties will come
to agreement with respect to Exhibit A as to whether prior written approval is needed in every
instance or whether it is not needed after the first instance has been approved in writing (e.g.,
given exigencies in television production business, it is reasonable that Zynga would approve the
use of its brand conceptually in elements of an episode but not need to re-approve the use in a
similar manner for every episode the brand is used in; and similarly, given exigencies in the social
gaming business, it is reasonable that WPT would approve use of its brand conceptually in elements
of the Zynga platform but not need to re-approve the use in a similar manner for every poker
tournament the brand is used in). i. Licensee may use textual and/or pictorial matter pertaining to
the Licensed Property on such promotional, display and advertising material as may, in Licensee's
reasonable judgment, promote the awareness, consumption and sale of the Licensed Property. All final
advertising and promotional material using the Licensed Property must be submitted to Licensor for
its prior written approval. All press releases respecting this Agreement or the relationship of the
parties herein shall require prior written approval by the other party. ii. Licensor will use
commercially reasonable efforts to provide approval and/or feedback within five (5) business days
after its receipt of a creative submission, or re-submission, with respect to the Licensed Property
or marketing materials; provided that: (a) if Licensor declines to approve any submission or
re-submission, then it shall provide reasonably detailed feedback in order to enable Licensee to
modify the Licensed Property or marketing material accordingly in order to address Licensor's
concerns and obtain Licensor's approval, and (b) if Licensor fails to (1) approve or (2) disapprove
and provide feedback within such timeframe, then such submission or re-submission is deemed to have
been approved. No approval may be unreasonably withdrawn by Licensor once delivered. iii. Zynga
shall advise WPT to Zynga's knowledge as to which jurisdictions where it may be illegal to advertise
Zynga's Licensed Property (if any) given local laws or regulations. iv. WPT or its affiliates shall
not authorize a Zynga Competitor to commercially exploit the Licensed Property in connection with
social poker gaming via a license similar to the license granted herein for the Term. A "Zynga
Competitor" means: 1) Aristocrat Technologies Australia Pty Ltd. Or Big Fish Games, Inc.; 2) HUUUGE
Inc.; 3) Activision Blizzard, Inc., King.com Ltd. Or King.com (US) LLC; 4) Scientific Games
Corporation; 5) Tencent Holdings Limited; and 6) Murka Ltd. The parties agree to work together in
good faith to amend the definition of a Zynga Competitor if that meaning for Zynga reasonably
changes during the Term. f. Reservation of Rights. The parties acknowledge and agree that, except
for the rights and licenses expressly granted by each party to the other party under this Agreement,
each party will retain all right, title and interest in and to its products, services, marks,
copyrights or other intellectual property, and all content, information and other materials on its
website(s), and nothing contained in this Agreement will be construed as conferring upon such party,
by implication, operation of law or otherwise, any other license or other right. 3. PAYMENT a.
Annual Minimum Guarantee. Zynga will pay to WPT the Annual Minimum Guarantee as set forth in the
Basic Provisions. The Annual Minimum Guarantee shall be recoupable from such Royalties as are, or
have become, paid to WPT. For clarification, the Annual Minimum Guarantee will operate as an advance
payment, such that when accrued Royalties exceed the Annual Minimum Guarantee payments already paid,
then the excess Royalties will be paid by Zynga to WPT. b. Royalty. The Royalties to be paid by
Zynga to WPT is the percentage of Net Revenue as set forth in Section 5 of the Basic Provisions.
"Net Revenue(s)" shall be defined as one hundred percent (100%) of gross revenues and all other
receivables of any kind whatsoever received by Zynga or any of Zynga's affiliates attributable to
the use of Paid Currency or in connection with the sale of Virtual Digital Goods derived from use of
the WPT-brand on the Zynga platform, less the following actual and verifiable "Allowable
Deductions": (i) out-of-pocket, third-party payment processing and currency system fees,
commissions, and platform distribution fees (e.g., Apple, Google or Facebook platform fees); (ii)
any governmental taxes (e.g., VAT, excise or sales or use tax, etc.) arising in connection with
related receipts, but excluding any taxes on Licensee's net income; and (iii) charge-
backs/refunds/cancellations/fraud. "Paid Currency" means virtual currency purchased using real
money. "Virtual Digital Goods" means any virtual, digital representation of any actual or fictional
thing or item within Zynga Poker, which is capable of being made available for distribution,
placement, download or other display by electronic means. Any other deductions must be mutually
agreed upon in advance and in writing by the parties.

5

Source: ALLIED ESPORTS ENTERTAINMENT, INC., 8-K, 8/15/2019
<!-- page 6 -->
c. Payment. All amounts payable and due will be made in U.S. dollars. If withholding taxes are
required, Zynga may account for the required amount of such withholding taxes when calculating the
Royalty or other payments payable prior to remittance to WPT. Zynga shall provide WPT with an
official receipt or other equivalent documentation issued by the appropriate taxing authority or
other evidence as is reasonably requested by WPT to establish that such taxes have been paid. Zynga
shall pay all amounts accruing under this Agreement for any reporting period to WPT by check or wire
transfer to the account specified by WPT in writing, concurrently with Zynga's delivery of the
applicable report under Section 3(d), provided that payments will only be paid if the amount owed to
WPT for any reporting period is greater than five hundred dollars ($500.00). An amount due of less
than five hundred dollars ($500.00) will be accumulated to the next payment and will be included in
the amount to be paid to WPT on the next payment date, again provided that the amount owed to WPT in
the subsequent month exceeds five hundred dollars ($500.00). Accumulated amounts do not accrue any
interest. d. Reporting. Zynga will, within thirty (30) days of the end of each calendar quarter,
commencing with the first full calendar quarter following the Effective Date, furnish WPT with
complete statements containing the following information with respect to all Net Revenue from the
use of the WPT-brand on the Zynga platform, during the preceding period covered by such statement:
the Territory; the amount due WPT (or the remaining unrecouped Annual Minimum Guarantee balance as
applicable); Net Revenue; Royalties rate; the distribution channels or portals, the platform, the
territory(ies), and itemized Allowable Deductions ("Royalty Statement(s)"). The amount shown to be
payable to WPT shall be paid simultaneously with the rendition of the respective Royalty Statement.
The statements and payments remitted hereunder shall be delivered to WPT via email to the following
email address: Deborah.Frazzetta@wpt.com (ATTN: Deborah Frazzetta, VP, Finance. e. Audit Rights.
Zynga shall keep full, complete and accurate books of account and records (collectively "records")
covering all transactions relating to the subject matter of this Agreement in sufficient detail to
enable the Royalties payable hereunder to be determined and verified. Zynga shall permit such
records to be examined by authorized representatives of WPT, including such independent auditors as
WPT may designate, during usual business hours, with advance notice, to verify to the extent
necessary the Royalties paid hereunder, and WPT and its representatives shall use reasonable efforts
to minimize disruptions to Zynga's business. Prompt adjustment shall be made by Zynga to compensate
for any errors or omissions disclosed by such examination. If the adjustment is more than $1,500 in
favor, then out-of-pocket costs of such examination shall be borne by Zynga. f. No Other Charges or
Expenses. Neither party will be liable to pay the other party any other types of charges or expenses
not agreed to in this Agreement or any related amendment signed by the Parties. 4. REPRESENTATIONS
AND WARRANTIES; LIMITATIONS OF LIABILITY a. Each party represents and warrants to the other as
follows: (i) it is duly authorized under applicable law and has the authority to enter into and
perform this Agreement; (ii) this Agreement constitutes a valid and binding obligation of such party
enforceable in accordance with its terms; (iii) the making of this Agreement by such party does not
violate any agreement, right or obligation existing between such party and any third party; (iv) the
marketing and promotional activities in Exhibit A shall not infringe or misappropriate third party
rights, including, without limitation, any patent, trade name, trademark, copyright or other
intellectual property or proprietary right and shall not invade or violate any right of privacy,
publicity, personal or proprietary right, or other common law or statutory right, nor defame any
person or entity in the United States and European Union (the "Principal Territories"), and to the
knowledge of such party, outside the Principal Territories; provided that such party makes no
representations regarding the Licensed Property or any other materials provided by Licensor as
contemplated under this Agreement. b. DISCLAIMER. EXCEPT AS EXPRESSLY STATED IN THIS AGREEMENT,
NEITHER PARTY MAKES ANY REPRESENTATIONS OR WARRANTIES OF ANY KIND WITH RESPECT TO THE SUBJECT MATTER
HEREOF, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
PARTICULAR PURPOSE OR ANY LEVEL OF BUSINESS OR SERVICE THAT MAY RESULT FROM THIS AGREEMENT, OR ANY
WARRANTY OR CONDITION ARISING FROM ANY COURSE OF DEALING, COURSE OF PERFORMANCE OR USAGE IN THE
INDUSTRY. c. LIMITATIONS ON LIABILITY/NO INJUNCTIVE RELIEF. EXCEPT IN CASES OF GROSS NEGLIGENCE,
WILLFUL MISCONDUCT OR FRAUD, INDEMNIFICATION CLAIMS UNDER SECTION 5 OR BREACHES OF SECTION 2
(TRADEMARKS), 8 (CONFIDENTIALITY), OR 9 (NO AGENCY RELATIONSHIP), IN NO EVENT SHALL EITHER PARTY OR
ITS OFFICERS, DIRECTORS, OR EMPLOYEES BE LIABLE TO THE OTHER PARTY IN CONNECTION WITH THE SUBJECT
MATTER HEREOF, FOR ANY SPECIAL, INDIRECT, CONSEQUENTIAL OR PUNITIVE DAMAGES OF ANY KIND, LOST
PROFITS OR LOST REVENUE, WHETHER ARISING IN CONTRACT, TORT, NEGLIGENCE, STATUTE, OR OTHERWISE, EVEN
IF ADVISED OF THE POSSIBILITY THEREOF. IN NO EVENT SHALL THE NON-BREACHING PARTY BE ENTITLED TO
EQUITABLE OR INJUNCTIVE RELIEF OF ANY KIND.

6

Source: ALLIED ESPORTS ENTERTAINMENT, INC., 8-K, 8/15/2019
<!-- page 7 -->
5. INDEMNIFICATION a. WPT shall indemnify, defend, and hold harmless Zynga and its Affiliates, and
the respective directors, officers and employees of the foregoing (the "Zynga Indemnified Parties")
from and against any and all third party claims, actions, suits, costs, liabilities, judgments,
obligations, losses, penalties, expenses or damages (including, without limitation, reasonable legal
fees and expenses) of whatsoever kind and nature imposed on, incurred by or asserted against any of
the Zynga Indemnified Parties arising out of: (i) any breach or alleged breach by WPT of any
representation, warranty or covenant made, by WPT pursuant to this Agreement; or (ii) WPT's
non-compliance with any applicable federal, state or local laws or with any applicable regulations
in connection with its performance of this Agreement. b. Zynga shall indemnify, defend, and hold
harmless WPT and its Affiliates, and the respective directors, officers and employees of the
foregoing (the "WPT Indemnified Parties") from and against any and all third party claims, actions,
suits, costs, liabilities, judgments, obligations, losses, penalties, expenses or damages
(including, without limitation, reasonable legal fees and expenses) of whatsoever kind and nature
imposed on, incurred by or asserted against any of the WPT Indemnified Parties arising out: (i) any
breach or alleged breach by Zynga of any representation, warranty or covenant made by Zynga pursuant
to this Agreement; or (ii) Zynga's non-compliance with any applicable federal, state or local laws
or with any applicable regulations in connection with its performance of this Agreement. c. In order
to seek or receive indemnification hereunder in cases involving third-party claims the party seeking
indemnification (the "Indemnified Party") must have promptly notified the other (the "Indemnifying
Party") of any claim or litigation of which the Indemnified Party is aware and to which the
indemnification relates; and the Indemnified Party must reasonably cooperate with Indemnifying Party
in the defense or settlement of such claim or litigation. With regard to any claim or litigation to
which the Indemnifying Party itself is not a party, the Indemnifying Party must have afforded the
Indemnified Party the opportunity to participate in any compromise, settlement, litigation or other
resolution or disposition of such claim or litigation. 6. TERMINATION a. Each party shall have the
right at any time to terminate this Agreement without prejudice to any rights which it may have,
whether pursuant to the provisions of this Agreement or otherwise in law or in equity or otherwise,
upon the occurrence of any one or more of the following events: i. The other party breaches or fails
to perform any of its material obligations provided for in this Agreement; ii. The other party is
unable to pay its debts when due, or makes any assignment for the benefit of creditors, or files any
petition under the bankruptcy or insolvency laws of any jurisdiction, county or place, or has or
suffers a receiver or trustee to be appointed for its business or property, or is adjudicated a
bankrupt or an insolvent; or iii. The other party asserts any rights in or to the terminating
party's intellectual property in violation of this Agreement. a. In the event that any of these
events of default should occur and a party elects to exercise its right to terminate this Agreement,
such party shall give notice of termination in writing to the other party, which notice shall
specify in reasonable detail the event(s) of default that give rise to such termination. The other
party shall have thirty (30) days from the effective date of such notice in which to correct any
such default(s) (except those which are not curable), and failing such correction by the end of such
thirty (30) day cure period, this Agreement shall thereupon immediately terminate. 7. RIGHTS AND
OBLIGATIONS UPON TERMINATION OR EXPIRATION. Upon expiration or termination of this Agreement: a. All
rights granted to WPT by Zynga shall immediately revert to Zynga, and WPT shall promptly cease any
and all marketing and promotional activities using Zynga's Licensed Property. b. All rights granted
to Zynga by WPT shall immediately revert to WPT, and Zynga shall promptly cease any and all
marketing and promotional activities using WPT's Licensed Property. c. Notwithstanding the
foregoing, for each end user that previously downloaded a Zynga game that includes WPT's Licensed
Property, and stored such Zynga game within such end user's device, WPT grants a license and right
to continue to use, activate, operate, perform, store, use and display that game on the end user's
device in perpetuity at no additional charge; provided, however, that Zynga shall use best efforts
to offer end users updates to its games which no longer include WPT's Licensed Property after the
Term. d. Notwithstanding any termination of this Agreement, nothing herein will obligate Zynga, any
users of a Zynga game that includes WPT's Licensed Property or any third party platform or
distribution partners to remove from the publicly available content regarding Zynga services or any
user accounts with Zynga, any of the references to user interactions, experience points,
achievements, item purchases or other engagements or metrics in the Zynga game(s) that were
generated prior to the expiration or termination of this Agreement.

7

Source: ALLIED ESPORTS ENTERTAINMENT, INC., 8-K, 8/15/2019
<!-- page 8 -->
e. Notwithstanding any termination of this Agreement, any Approved Content that includes Zynga's
Licensed Property may remain in perpetuity in any media in which such Licensed Property was
integrated into during the Term (e.g., televised WPT Tournaments or WPT Invitational Tournaments,
social media posts, repurposed integrations for "best of" television programs) or for historical
purposes (e.g., reference on WPT's website that Zynga-sponsored tour events took place as part of
the tour). f. Sections 1, 3-7, and 8-10 of the Additional Provisions shall survive termination or
expiration of this Agreement. 8. CONFIDENTIALITY. The parties acknowledge and agree that the subject
matter of this Agreement constitutes "Business Purpose" and this Agreement and any Exhibits
hereunder are "Confidential Information" of the parties as defined as "Information" in the Non-
Disclosure Agreement between the parties dated August 24, 2017, and accordingly the restrictions
relating to confidentiality and use thereof provided in the Non-Disclosure Agreement apply to any
party's Confidential Information disclosed pursuant to this Agreement. In the event of a conflict
between the Non-Disclosure Agreement and this Agreement, the terms of this Agreement will govern. 9.
INDEPENDENT CONTRACTORS. The parties are independent contractors with respect to each other and
nothing herein shall create any association, partnership, joint venture or agency relationship
between them. Neither party shall have the right to obligate or bind the other party in any manner
whatsoever, and nothing herein contained shall give, or is intended to give, any rights of any kind
to any third persons. 10. MISCELLANEOUS a. Insurance. Each party agrees to carry liability insurance
sufficient to cover the risks posed under this Agreement. b. Counterparts. This Agreement may be
executed in any number of counterparts, each of which shall be an original and all of which shall
constitute together but one and the same document. c. Notices. All notices and other communications
given hereunder shall be in writing and shall be sent by courier service, express mail, personal
delivery or mail to the respective addresses of the parties set forth above (or at such other
address as such party may designate by notice to the other party). A copy of any notice to WPT shall
also be sent to WPT Enterprises, Inc., ATTN: Legal, 1920 Main Street, Suite 1150, Irvine, CA 92614.
A copy of any notice to Zynga shall also be sent to Office of the General Counsel, Zynga Inc., 699
8th Street, San Francisco, CA 94103 with a copy to legalnotices@zynga.com. Notice shall be deemed
given as follows: upon delivery if sent by courier service, express mail or personal delivery; and
five (5) days after the date of mailing, postage prepaid, certified or registered mail if sent by
mail. d. Entire Agreement. This Agreement contains the full and complete understanding between the
parties hereto with respect to the license granted hereunder and supersedes all prior agreements and
understandings, whether written or oral, pertaining thereto. This Agreement cannot be modified
except by a written instrument signed by each party hereto. e. Waiver. No waiver of any term or
condition of this Agreement shall be construed as a waiver of any other term or condition and no
waiver of any default under this Agreement shall be construed as a waiver of any other default. f.
Force Majeure. In the event that either party is prevented from engaging in the marketing and
promotional activities in Exhibit A manufacturing, distributing or selling the Licensed Property
because of any act of God; unavoidable accident; fire, epidemic; strike, lockout, or other labor
dispute; war, riot or civil commotion; act of public enemy; enactment of any rule, law, order or act
of government or governmental instrumentality (whether federal, state, local or foreign); or other
cause beyond such party's control, and such condition continues for a period of two (2) months or
more, either party hereto shall have the right to terminate this Agreement effective at any time
during the continuation of such condition by giving the other party at least thirty (30) days'
notice to such effect. In such event, all payments made shall become immediately due and payable and
this Agreement shall be automatically terminated. g. Governing Law and Forum. This Agreement will
for all purposes be governed by and interpreted in accordance with the laws of the State of
California without giving effect to any conflict of laws principles that require the application of
the laws of a different state. Each of the parties hereto (i) irrevocably agrees that the federal
and state courts in the Northern District of California shall have sole and exclusive jurisdiction
over any suit or other proceeding arising out of or based upon this Agreement, (ii) submits to the
venue and jurisdiction of such courts, and (iii) irrevocably consents to personal jurisdiction by
such courts. h. Assignment. This Agreement shall bind and inure to the benefit of each party, its
successors and assigns. Without the prior written consent of the other party, neither party shall
assign or transfer any of its rights or obligations hereunder, in whole or in part, to any third
party, and any purported assignment without such prior written consent shall be null and void and of
no force and effect; except that notice, but no consent shall be required for such assignment or
transfer in connection with an internal reorganization or sale of the transferring party, including
by merger or other business combination, or a sale of substantially all of the assets of the
transferring party. None of either party's rights hereunder shall devolve by operation of law or
otherwise upon any receiver, liquidator, trustee or other party. i. Severability. In case any one or
more of the terms contained in this Agreement shall be invalid, illegal or unenforceable in any
respect, the validity, legality and enforceability of the remaining terms shall not in any way be
affected or impaired thereby. The parties shall endeavor in good faith negotiations to replace the
invalid, illegal or unenforceable terms with valid terms the economic effect of which comes as close
as possible to that of the invalid, illegal or unenforceable terms.

8

Source: ALLIED ESPORTS ENTERTAINMENT, INC., 8-K, 8/15/2019
<!-- page 9 -->
EXHIBIT A MARKETING AND PROMOTIONAL ACTIVITIES (the parties mutually agree to provide additional
details and commitments) BY WPT: WPT shall promote the Zynga brand in the following activities: ●
Prominent display of the Zynga or Zynga Poker brand in WPT Tournaments and WPT Invitational
Tournaments, subject to venue approval, network approval and inventory space given existing
sponsorship deals BY ZYNGA: Zynga shall promote the WPT brand in the following activities: ●
Creation of a WPT-branded Zynga Poker Tournament Mode playable in the Zynga Poker game or other such
use of the WPT brand on the Zynga platform as Zynga determines

9

Source: ALLIED ESPORTS ENTERTAINMENT, INC., 8-K, 8/15/2019
<!-- page 10 -->
EXHIBIT B LICENSED PROPERTY (the parties mutually agree to provide additional details on allowable
IP) WPT MARKS: ● WPT® ● WORLD POKER TOUR® ZYNGA MARKS: ● ZYNGA® ● ZYNGA POKER®

10

Source: ALLIED ESPORTS ENTERTAINMENT, INC., 8-K, 8/15/2019
