<!-- page 1 -->
# CONSULTING AGREEMENT
| Field | Value |
|---|---|
| Document Type | Consulting Agreement |
| Agreement Date | 2020-06-01 |
| Parties | GROUPE PARAMEUS CORP ("Consultant"); Sphere 3D Corp. ("Company") |
| Source | CUAD v1 / SPHERE3DCORP_06_24_2020-EX-10.12-CONSULTING AGREEMENT |

Exhibit 10.12 CONSULTING AGREEMENT

THIS CONSULTING AGREEMENT is made and entered into as of June 1st, 2020 (the "Effective Date") by
and between GROUPE PARAMEUS CORP , a (hereinafter, the "Consultant"), with an address at 80
Cumberland street, suite 1707 Toronto Ont. (the "Consultant"), and Sphere 3D Corp., with an address
at 895 Don Mills Road Bldg 2 Toronto Ontario Canada ("Company").

WHEREAS, Consultant has experience in the area of corporate finance, investor communications and
financial and investor public relations and the Company and Consultant wish for Consultant to
provide services to the Company as hereinafter provided.

NOW, THEREFORE, in consideration of the premises and the mutual covenants set forth herein and other
good and valuable consideration, the receipt and sufficiency of which are hereby acknowledged, the
Company and the Consultant hereby agree as follows:

DUTIES.

The Company hereby engages the Consultant and the Consultant hereby accepts engagement as a
consultant. It is understood and agreed, and it is the express intention of the parties to this
Agreement, that the Consultant is an independent contractor, and not an employee or agent of the
Company for any purpose whatsoever. Consultant shall perform all duties and obligations as described
on Exhibit A hereto (the "Services") and agrees to be available at such times as may be scheduled by
the Company. It is understood, however, that the Consultant will maintain Consultant's own business
in addition to providing services to the Company. The Consultant agrees to promptly perform all
services required of the Consultant hereunder in an efficient, professional, trustworthy and
businesslike manner. A description of the Consultant's services are attached hereto as Exhibit A and
incorporated by reference herein.

In connection with Consultant's performance of the Services specified in the Statement of Work,
Company agrees to provide Consultant and/or each subcontractor, such materials as may be necessary
for the Services to be performed (the "Materials"). The Company hereby represents, warrants,
covenants and agrees that the Materials will be true and accurate and shall be free of any material
omissions or misstatements and otherwise compliant will all applicable laws.

The Company shall provide disclosures in each of its Forms 10-K and 10-Q as to the existence of this
Agreement and any Statement of Work, the amount paid or to be paid in connection with each Statement
of Work and the types of services to be provided under each Statement of Work.

During the Term, the Company shall advise Consultant of any and all promotional activities with
respect to its securities, prior to the commencement of such activities, including, but not limited
to, press releases and engagements with other investment relations firms or other service providers
providing services similar to those or the Services provided in a Statement of Work.

CONSULTING SERVICES & COMPENSATION. Commencing on the Effective Date, the Consultant will be
retained as a Consultant and independent contractor for the Company for the Term as set forth in
Section 3. For services rendered hereunder during the term, the Consultant shall receive:

A cash pre-payment of US$150,000 which Consultant acknowledges it received directly from an investor
participating in the Company's March 2020 convertible debenture offering and that no additional cash
payment is due and payable under this Agreement.

A total of 100,000 of the Company's restricted common stock issued under and pursuant to the terms
of Regulation D under the Securities Act of 1933 (the "Shares") shall be issued upon execution of
this contract provided that the issuance of the Shares shall be subject to prior approval of the
Board of Directors. The company shall cause its counsel to provide an opinion letter for removal of
any legend when and if such legend may be removed in accordance with applicable law.
<!-- page 2 -->
A one time issuance of 50,000 Common Stock options priced at the Nasdaq Official Closing Price
("NCOP") on the date of approval of the Board of Directors of the company. All options shall vest
monthly for six months.

A total of 100,000 RSA's ("Restricted Stock Awards") that vest immediately, subject to prior
approval of the Board of Directors.

TERM & TERMINATION. This Agreement is for a term (the "Term") of 12 months from the Effective Date
on June 1s t 2020 and expiring May 31st 2021.

(a) In the case that the company would not like to extend the terms of agreement for an additional
month. The company must notify the consultant within 5 days of the conclusion of the 12 month term.
Without notification the contract will automatically extend for an additional month of service.

Upon termination, Consultant agrees to perform the necessary information transfer required at the
time.

CONFIDENTIALITY. All knowledge and information of a proprietary and confidential nature relating to
the Company which the Consultant obtains during the Consulting period, from the Company or the
Company's employees, agents or Consultants shall be for all purposes regarded and treated as
strictly confidential for so long as such information remains proprietary and confidential and shall
be held in trust by the Consultant solely for the Company's benefit and use and shall not be
directly or indirectly disclosed in any manner whatsoever by the Consultant.

CONSULTANT'S REPRESENTATIONS & WARRANTIES. Consultant represents and warrants to the Company as
follows:

The Consultant (i) has adequate means of providing for the Consultant's current needs and possible
personal contingencies; (ii) is acquiring the Shares for investment and not with a view to their
distribution and has no need for liquidity in this investment; (iii) is able to bear the substantial
economic risks of an investment in the Shares for an indefinite period; and (iv) is an "accredited
investor" as defined in Rule 501 of Regulation D of the Securities Act of 1933, as amended.

Consultant is not under any legal obligation, including any obligation of confidentiality or
non-competition, which prevents Consultant from executing or fully performing this Consulting
Agreement, or which would render such execution or performance a breach of contract with any third
party, or which would give any third party any rights in any intellectual property which might be
developed by Consultant hereunder; and

Consultant shall perform the Services hereunder in accordance with the terms of this Agreement and
applicable regulations, guidelines and licensing requirements; and

Consultant has all requisite power and authority to execute, deliver, and perform this Agreement,
and this Agreement has been duly authorized, executed and delivered by Consultant and is
Consultant's legal, valid and binding obligation, and is enforceable as to Consultant in accordance
with its terms.

The Consultant certifies, under penalties of perjury that the Consultant is not subject to backup
withholding as a result of a failure to report all interest or dividends, or because the Internal
Revenue Service has notified the Consultant that the Consultant is no longer subject to backup
withholding, and that Consultant has provided the Company an accurate taxpayer ID number.

SEVERABILITY. In the event any provision of this Consulting Agreement is determined by a court of
competent jurisdiction to be unenforceable, the parties will negotiate in good faith to restore the
unenforceable provision to an enforceable state and to provide reasonable additions or adjustments
to the terms of the other provisions of this Consulting Agreement so as to render the whole
Consulting Agreement valid and binding to the fullest extent possible, and in any event, this
Consulting Agreement shall be interpreted to be valid and binding to the fullest extent possible.

NON-DISCLOSURE OF TERMS. The terms of this Agreement shall be kept confidential, and no party,
representative, attorney or family member shall reveal its contents to any third party except as
required by law or as necessary to comply with law or preexisting contractual commitments.
<!-- page 3 -->
INDEMNIFICATION. Consultant shall indemnify, defend and hold harmless the Company, the Parent, and
each of their members, their affiliates and their respective directors, officers, employees,
representatives, agents, successors and assigns (collectively, "Indemnitees") from and against any
and all claims, losses, liabilities, damages, costs, expenses (including, without limitation,
attorneys fees and expenses) demands, fines, penalties, injunctions, suits and causes of action of
any kind or nature whatsoever (collectively referred to as "Damages") instituted by any third party
and arising out of Consultant's performance of services under this Consulting Agreement, unless said
Damages arise out of the negligence or willful misconduct of the Company, its members, affiliates
and their respective directors, officers, employees, representatives, agents, successors and
assigns.

SEC & LEGAL COMPLIANCE. Consultant hereby represents that it has in place policies and procedures
relating to, and addressing, with the commercially reasonable intent to ensure compliance with, all
applicable securities laws, rules and regulations, including but not limited to the use, release or
other publication of forward-looking statements within the meaning of Section 27A of the Securities
Act and Section 21E of the Exchange Act and disclosure requirements outlined in Section 17B of the
Exchange Act regarding the required disclosure of the nature and terms of its relationship with the
Company in any and all literature or other communication(s) relating to these services, including
but not limited to: Press Releases, letters to investors and telephone or other personal
communication(s) with potential or current investors. In addition, Consultant acknowledges that
United States securities laws and the rules and regulations promulgated thereunder prohibit any
person with material, non- public information about a company from purchasing, selling, trading, or
entering into options, puts, calls or other derivatives in respect of securities of such issuer or
from communicating such information to any other person or entity and Consultant shall comply with
such laws, rules and regulations. Consultant will take no action to manipulate the market price of
the Company's securities in violation of law or regulation, nor pay or otherwise induce others to
take any such actions, nor publish comments about the Company without appropriately disclosing
payments received therefor.

MISCELLANEOUS

This Consulting Agreement shall be governed by, and construed pursuant to the laws of the State of
New York, applicable to agreements made and performed wholly within such State. Any disputes under
this Consulting Agreement shall be resolved by appropriate proceedings in the state of New York.

This Consulting Agreement may not be changed orally, but may be changed only in a writing executed
by the party to be charged with enforcement.

If any terms and conditions of this Consulting Agreement shall be held to be illegal, invalid or
otherwise unenforceable by a court of competent jurisdiction, all remaining terms and conditions
shall remain in full force and effect

IN WITNESS WHEREOF, the parties hereto have duly executed this Agreement as of the Effective Date.

Sphere 3D Corp.

/s/ Peter Tassiopoulos

Name: Peter Tassiopoulos

Title: CEO

GROUPE PARAMEUS CORP.

/s/ Samuel Kafkas

Name:

Title: President
<!-- page 4 -->
EXHIBIT A

Consultant Services

The Consultant agrees, to the extent reasonably require in the conduct of its business with the
Company, to place at the disposal of the Company its judgment and experience and to provide business
development services to the Company, including, but not limited to, the following:

a. Advise and assist the company in developing and implementing appropriate plans and materials for
presenting the Company and its business plan, strategy and personnel to the financial community.

b. With the cooperation of the Company, maintain an awareness during the term of the agreement of
the Company's plan's and strategy as it relates to the financial community.

c. Create awareness of the company among investors and media.

d. Assist the Company in steps for financial and public relations.
