<!-- page 1 -->
# First Amendment to Credit Agreement — Acme Industrial LLC
Document Type: Amendment
Effective Date: 2025-01-10
Parties: Acme Industrial LLC; First National Bank
Facility ID: FAC-2024-0117

## 1. Amendments
Section 3 is amended to read: Borrower shall maintain a Leverage Ratio not exceeding 4.00 to 1.00.
<!-- page 2 -->
## 2. Effect
Except as amended hereby, the Credit Agreement remains in full force and effect.
The Applicable Margin is increased to 2.50% per annum.
