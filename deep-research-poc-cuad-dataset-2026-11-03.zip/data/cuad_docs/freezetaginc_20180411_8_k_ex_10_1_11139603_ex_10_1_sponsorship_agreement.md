<!-- page 1 -->
# Corporate Sponsorship Agreement
| Field | Value |
|---|---|
| Document Type | Sponsorship Agreement |
| Agreement Date | 2018-03-22 |
| Parties | Freeze Tag Inc. ("Company"); American Diabetes Association ("Association") |
| Source | CUAD v1 / FreezeTagInc_20180411_8-K_EX-10.1_11139603_EX-10.1_Sponsorship Agreement |

EXHIBIT 10.1

Corporate Sponsorship Agreement Between American Diabetes Association and Freeze Tag, Inc. This
Agreement ("Agreement") is made effective March 22, 2018, by and between Freeze Tag Inc., a Delaware
Corporation ("Company"), with its principal place of business located at 1720 Bray Central Drive,
McKinney, TX 75069 and the American Diabetes Association, Inc. ("Association"), an Ohio not-for
profit corporation, with its principal place of business located at 2451 Crystal Drive, Suite 900,
Arlington, VA 22202. ADA and/or Company may be referred to as a "Party" or collectively as the
"Parties." 1. Purpose: The purpose of this Agreement is to benefit the Association and advance its
not-for-profit mission through a National Sponsorship of Get Fit Don't Sit DayT M. Company desires
to assist the Association to carry out its mission and agrees to provide the support described in
this Agreement. Company understands that as a not-for-profit charitable organization Association
cannot promote or endorse Company's products or services, either explicitly or implicitly. The
Association may require that a disclaimer stating that Company's participation in this Agreement
does not convey or imply the Association's approval, endorsement, certification, acceptance, or
referral of any product or service of Company. 2. Scope: The Association agrees to identify and
acknowledge Company as a supporter of the organization and the diabetes cause, as permitted in
connection with qualified sponsorship payments and royalties under Section 513(i) and Section 512 of
the Internal Revenue Code and Treasury regulations thereunder ("Code"). Company agrees not to
knowingly take any actions that would jeopardize the tax-exempt status of Association under section
501(c)(3) of the Code. Company agrees to inform its business partners about Association's tax-exempt
status. Company agrees to provide its services, as defined in Attachment A, in accordance with all
applicable laws and in accordance with standards of decorum and taste so as not to adversely reflect
upon the Association or its mission. 3. Term: This Agreement shall commence on March 15, 2018 and
will expire on March 14, 2020 unless terminated earlier pursuant to Section 13 of the Agreement (the
"Term"). 4. Intellectual Property: The Association is the sole and exclusive owner of its name and
logos, with or without accompanying words, and has the legal right to enter into this Agreement. In
addition, any materials provided by or developed by the Association remain the property of the
Association. The Association's names, logos, and various marks, are "the Association Marks", as
listed in Attachment B. The Association's ownership of the Association Marks is or shall be secured
through registration, or under common law, or both. Company's use of the Association Marks does not
create ownership rights in the Association Marks for Company. Company shall not, during the period
of this Agreement, or any time thereafter, challenge Association's exclusive ownership or
registration of Association's Marks, including any and all moral rights. Company is the sole and
exclusive owner of its name, logos, and marks (the "Company Marks"), which include, without
limitation, the names, logos, and marks listed in Attachment B as Company Marks. 1

Source: FREEZE TAG, INC., 8-K, 4/11/2018
<!-- page 2 -->
5. License: The Association grants Company a non-exclusive, limited, revocable and conditional
license during the term to use the Association Marks, solely to identify Company as a supporter of
the Association. Use by Company of the Association Marks is limited to the particular Association
Marks as authorized by the Association, which may not be revised or altered in any way, without
prior written consent, must be displayed in the same form and colors, and does not extend to any
other marks of the Association. Use by Company of the Association Marks on and in conjunction with
its product or brand is conditioned upon Company's observance of the specifications for permissible
uses of the Association Marks as stated herein and as may be given to Company, from time to time ,
in writing by the Association. Nothing shall prohibit the Association, during the period of this
Agreement, from licensing the use of substantially similar marks for substantially similar uses in
working with other companies or industries. Company may not permit any third party to use the
Association Marks without the express prior written approval of the Association, which may be
withheld for any reason. The Association Marks must be used in a professional manner and solely in
connection with the activities authorized under this Agreement. The Company grants the Association a
non-exclusive, limited, revocable and conditional license during the term to use the Company Marks,
solely to identify Company as a supporter of the Association. The Company Marks must be used solely
in connection with the activities authorized under this Agreement. 6. Use of Association Marks: The
Association Marks shall not be placed adjacent to the mark of another organization concerned with
diabetes, or those of a company that manufactures products or provides services related to diabetes,
without the Association's specific prior written consent, which may be withheld for any reason. The
Association Marks may not be used for individual, personal or professional gain, or other private
benefit, and Company shall not use the Association Marks in any manner that, in the Association's
sole discretion and judgment; diminishes their value or otherwise dilutes the Association Marks;
discredits the Association or tarnishes its reputation and goodwill; is false, misleading or likely
to cause confusion, mistake or deception; violates the rights of others; violates any federal, state
or local law, regulation or other public policy; or mischaracterizes the relationship between the
Parties, including but not limited to the fact that Company is a separate and distinct legal entity
from, and is not an agent of, the Association. The use of Company Marks by Association shall be in
furtherance of the sponsorship elements set forth in Attachment A. 7. Quality: All products,
materials, services or other items of Company with which the Association Marks are used shall be
maintained throughout the period of this Agreement at or above their quality at the beginning of the
term. Company shall provide to the Association on a quarterly basis two (2) samples of any items or
materials that contain the Association Marks. 8. Review: All uses of the Association Marks,
including the specific placement of the Association Marks on Company's product and all promotional
materials and packaging, are subject to the Association's prior written approval, which approval
shall be in its sole discretion. Any reference to the Association in electronic or other publication
or broadcast is subject to the Association's respective prior written approval, which approval shall
not be unreasonably withheld. Approval or disapproval shall be provided by the respective Party
within five (5) business days of request. Failure to have materials and/or products featuring the
Association Marks reviewed in advance of making then available in the marketplace may be considered
breach of the Agreement and cause for immediate cancellation. 2

Source: FREEZE TAG, INC., 8-K, 4/11/2018
<!-- page 3 -->
9. Infringement: Each Party shall take measures it deems necessary to assure that none of the
material which is prepared, or which shall be prepared, pursuant to this Agreement, violates or
infringes upon any trademark or copyright, or any other right of any person, company or other
entity. Both Parties shall protect against infringement of the Association Marks. Each Party shall
provide reasonable assistance to the other party in protecting the Association Marks upon request.
Each Party shall notify the other party immediately if it learns of any infringement of the
Association Marks or Company. 10. Mark. The Party owning the infringed mark shall have sole
discretion to determine whether to pursue such infringement. 11. Indemnification: Each Party agrees
to defend, indemnify and hold harmless the other Party, its officers, directors, employees,
volunteers, subcontractors and agents, from any and all claims, losses, damages, liabilities,
judgments, or settlements, including reasonable attorneys' fees, costs and other expenses incurred
on account of the their respective negligent acts or omissions, and those of their directors,
employees, agents, contractors and sub- contractors, in connection with this Agreement. 12.
Notification: Except as may be limited by applicable law, each of the Parties hereto shall promptly
notify the other of, and reasonably cooperate in responding to or defending any inquiry,
investigation, claim, suit or other cause of action instituted, asserted or threatened against
either Party hereto or any of their respective Affiliates, shareholders, directors, officers,
agents, independent contractors or employees and arising out of or relating to either Party's
obligations under this Agreement or any other matter contemplated hereby. 13. Insurance: During the
term of this Agreement, and before any sponsorship or promotional activities are conducted under
this Agreement, Company shall obtain and maintain at its expense, Commercial General Liability
Insurance coverage with an insurance carrier with a Best's rating of A+. The insurance shall be in
an amount of: $2,000,000 per occurrence and $2,000,000 aggregate with a $2,000,000 aggregate for
products and completed operations. The Association must be a named additional insured, and shall be
provided at least 30 days' notice for cancellation of policy and 10 days' notice for non-payment of
premium. Such insurance shall be primary and non-contributory. 14. Termination: Before expiration of
the Term, either Party may terminate this Agreement upon: (i) any material breach of the Agreement
by the other Party, if such breach is not remedied to the reasonable satisfaction of the
non-breaching Party within ten (10) business days after written notice; (ii) ten (10) business days
written notice to the other Party whenever the notifying Party in its sole discretion determines
that the continuation of the Agreement will damage its reputation or good will; or (iii) written
notice in the event one Party (a) becomes or is declared insolvent or bankrupt or is subject to the
appointment of a trustee or receiver or any equivalent thereof, (b) is the subject of any proceeding
related to its liquidation or insolvency (whether voluntary or involuntary) which is not dismissed
within ninety (90) days, (c) makes an assignment for the benefit of creditors, or (d) is subject to
any sale, lease or other transfer of all or substantially all of its assets to any entity; or (e) is
subject to a change of control (whether by merger, stock transfer or otherwise), except in the case
of an initial public offering. 15. Effect of Termination or Expiration: Upon termination or
expiration, no further use may be made of the Association Marks, or other proprietary property or
materials provided, developed or intended for use in connection with the Sponsorship, without prior
written authorization, other than as set out in this section. All other originals and copies of the
Association Marks (whether in printed, electronic, recorded, and/or other tangible form) shall be
discarded or destroyed within five (5) business days. The obligations under sections 8, 9, 10, and
11 and 19 and this section 14 shall survive the termination or expiration of this Agreement. 3

Source: FREEZE TAG, INC., 8-K, 4/11/2018
<!-- page 4 -->
16. Force Majeure: Neither Party shall be in breach of this Agreement if Program or Event activities
are cancelled as a result of forces beyond the Party's reasonable control, such as unusually severe
weather, fire, explosion, civil disturbance, terrorism or act of God. Whenever possible, any
schedule for performance stated above shall be extended as necessary to overcome the effects of such
force majeure, or the company promotion shall be transferred to another Association program or
event. 17. Liability: Company and Association agree that each is responsible for its own business
activities and for its action or inaction relating to the specific Program or Event activities under
this Agreement. Company shall be responsible for securing any necessary release forms from
participants in any Company activity not held at the Association's Program or Event activity. 18.
Non-Assignment: This Agreement shall be between the Parties only, and does not grant rights to any
other party. This Agreement may not be assigned by either Party without the prior written consent of
the other Party. Any amendment of this Agreement must be in writing signed by authorized
representatives of each of the Parties. 19. Confidentiality. The provisions of this Agreement shall
be maintained by the Parties as confidential during the Term and thereafter. In addition, any and
all aspects of Company's business, including without limitation all non-public information or trade
secrets directly or indirectly related thereto, that Association becomes exposed to during the Term,
and extensions or renewals, of this Agreement shall be maintained as confidential, and shall not be
further disclosed by Association, or used by Association for any purpose other than performing
hereunder during the Term or thereafter. Company shall at all times retain full ownership in and to
all information respecting its business, and shall be the sole and exclusive owner of all materials
created by or for the Company hereunder, with the exception of the Association Marks. 20.
Independence. Nothing in this Agreement shall create a partnership, joint venture or establish the
relationship of principal and agent or any other relationship of a similar nature between the
Parties. The Parties to this Agreement shall be considered independent contractors and neither Party
is granted the right or authority to assume or create any obligation on behalf of or in the name of
the other. 21. Survival. Any and all warranties, provisions, rights and obligations of the Parties
herein described and agreed to be performed subsequent to the termination of this Agreement,
including but not limited to obligations respecting confidentiality and indemnification, shall
survive the termination of this Agreement. 22. Successors and Assigns. This Agreement shall be
binding on the parties, and on their successors and assigns, without regard to whether it is
expressly acknowledged in any instrument of succession or assignment. However, Company may only
assign its responsibilities under this Agreement with Association's prior written approval as
provided in Section 18. 23. Entire Agreement. This Agreement, including any attachments, if
applicable, and any other documents and agreements contemplated herein, constitute the entire
agreement between the Parties with regard to the subject matter. This Agreement supersedes all
previous agreements between or among the Parties respecting such, and there are no other agreements
or understandings between or among the Parties other than as set forth herein. 4

Source: FREEZE TAG, INC., 8-K, 4/11/2018
<!-- page 5 -->
24. Amendment. No amendment, alteration, modification of or addition to this Agreement, and no
waiver of rights or remedies hereunder, shall be valid or binding unless expressed in writing and
signed by the Party to be bound thereby. 25. Compliance with Anti-discrimination Laws and Policies.
Company states that it is its practice to adhere to all applicable federal, state and local laws
relating to discrimination in the workplace and Company does not have any rule or policy that
automatically excludes a person with diabetes from employment in any position with Company. 26.
Notice: All written notices required to be given pursuant to the terms set forth in this Agreement
shall be deemed given on the day notice is either delivered personally, or by fax or overnight or
certified delivery or deposited in the mail addressed as specified below: If to the American
Diabetes Association: Address: 2451 Crystal Drive, Suite 900 Arlington, VA 22202 Email: Attn: Daryl
Hayes, Corporate Development Officer Attn: Jonathan Webb, Vice President, Corporate Alliances (cc)
Attn: Sean McDonough, Vice President and General Counsel, Legal Affairs (cc)

If to Freeze Tag, Inc. Address: 17200 Bray Central Drive McKinney, TX 75069 Email: Fax: Attn: Craig
Holland, CEO

27. Governing Law: This Agreement is subject to and shall be construed in accordance with the laws
of the Commonwealth of Virginia with jurisdiction and venue in federal and Virginia courts in
Alexandria and Arlington, Virginia. If any terms of this Agreement are invalid or unenforceable
under any statute, regulation, ordinance, executive order or other rule or law, such term shall be
deemed reformed or deleted only to the extent necessary to comply with such statute, regulation,
ordinance order or rule, and the remaining provisions of this Agreement shall remain in full force
and effect. Signatures: American Diabetes Association Freeze Tag, Inc.

By: By: Name Name Title Title Date Date 5

Source: FREEZE TAG, INC., 8-K, 4/11/2018
<!-- page 6 -->
ATTACHMENT A ACKNOWLEDGEMENT OF SUPPORT The following outlines the type of acknowledgment that has
been agreed upon by the Company and the Association and describes the appropriate recognition of
support, in accordance with the Internal Revenue Code. (All advertising, promotional and educational
materials, with the Association marks, are subject to the Association's advance review and
approval.) Products/Brand covered by this Agreement: Freeze Tag App Products, ZeeTour App
Sponsorship Type: National Get Fit Don't Sit DayTM Sponsor As a National Sponsor, Company shall
participate in and receive recognition for the following activities, for the Term, as agreed upon by
Company and the Association. The Association shall review with Company on a semi-annual basis the
recognition of Company's participation in the activities outlined below. Use of Association
Intellectual Property- Association Name and Logo ("Association Mark"): The Association hereby grants
Company the right to use the Association Name and Logo ("the Association Marks") on educational,
promotional and or advertising materials throughout the Term (see Attachment "B"). All materials
containing the Association Marks are subject to advance review and written approval by the
Association and Company acknowledges that the Association is the final arbiter in determining
whether or not its Marks are suitable to appear on materials. Any display of Association Mark must
be accompanied by one of the following relationship statements: a. "Freeze Tag is a national sponsor
of Get Fit Don't Sit DayTM, a wellness engagement day of American Diabetes Association®" b. "Freeze
Tag is a national sponsor of American Diabetes Association®" A. 2018 National Get Fit Don't Sit
DayTM

National Get Fit Don't Sit DayT M, (NGFDS) May 2, 2018 is the Association's high-profile wellness
day that brings a message around physical activity into the workplace; it is designed to bring
awareness about the importance of getting up and moving throughout the day. As a sponsor of the 2018
NGFDS Day event, Company shall include: i. E-Toolkit E-toolkit shall include cobranded assets which
can be downloaded by participating companies and organizations. Cobranded assets include: ·
Cobranded cover · Print Ad/Poster o Field Toolkit: Template campaign materials leveraged by field
staff to customize for local area. Logo is included on: · Cobranded cover · Print Ad/Poster ·
Association shall provide Freeze Tag with customized social media messaging that can be used to
promote the company's role in the campaign (estimated timeline March). 6

Source: FREEZE TAG, INC., 8-K, 4/11/2018
<!-- page 7 -->
ii. Association Channels: Company shall receive recognition in the following Association Channels:
Website Company logo shall be prominently featured on the campaign landing page for National Get Fit
Don't Sit Day. Media and Public Relations Company shall be acknowledged as a national sponsor in the
Association's press release announcing the third annual National Get Fit Don't Sit Day. Association
Consumer E-News Company shall be recognized as a sponsor of National Get Fit Don't Sit Day content
featured in Consumer e-newsletters - Stop Diabetes® and Living with Type 2 Diabetes Email Marketing
Company shall be recognized as a national campaign sponsor in one (1) to two (2) email
announcements, to the Association's corporate lists and to our engaged consumer base. Corporate
lists include current Association sponsors and wellness-minded companies who have engaged in past
wellness day initiatives. Social Media Association shall leverage its social media channels to
engage participants in National Get Fit Don't Sit Day: · The Association will mention/tag Freeze Tag
in posts announcing National Get Fit Don't Sit Day on May 2. · The Association will also
share/retweet up to three (3) social media posts on Facebook, Twitter and Instagram-one before
National Get Fit Don't Sit Day, one on May 2 and one after the campaign. Internal Communications
Company shall be mentioned as the national sponsor of National Get Fit Don't Sit Day in all internal
communications to Association staff, including but not limited to Notable News and ADA News. B.
Company Pin Pad/POS Donation Campaign for Tour de Cure® and Step Out (2018-2019) In 2018 Company
shall commit to developing a customized version of its ZeeTour app to support Tour de Cure® and Step
Out Walk to Stop Diabetes® events across the US. By way of the ZeeTour app, Company agrees to ask
their customers to participate in a voluntary pin pad/POS donation campaign to support the
Association's events. The pin pad campaign donation levels are to be mutually determined by Company
and Association. (See Attachment "C" for volunteer donations guidelines) Company shall provide all
tracking reports to Association which shall include total participants and funds raised through the
pin pad/POS campaign per event site for the duration of the Term. For the purposes of this
Agreement, funds raised through the pin pad/POS donation campaign shall be applied towards Company's
total sponsorship of $150,000 for the Term. 7

Source: FREEZE TAG, INC., 8-K, 4/11/2018
<!-- page 8 -->
Company and Association shall collaborate to: · Strategically identify markets in 2018 to act as
test sites for implementation · Identify number of events both Tour and Step Out prior to 2019 Tour
season · Develop a marketing strategy prior to implementation C. Association Media Channels:
Promotions That Give Back The Association shall leverage its Promotions That Give Back website and
e-news to help raise awareness about Company's Cause Promotion and national support. a. Promotions
That Give Back webpage Description: 3-4 lines that outline the relationship with Association and
co-venture arrangement (% of every purchase of in store apps goes to Association) b. Promotions That
Give Back e-Newsletter Audience: Shoppers and purchasers from Association (ShopD.org website),
DiabetesForecast e-news subscribers, excludes donors in December. Circulation: 510,000; Frequency:
Quarterly. Description: Photo/graphic, headline, and 20-25 word blurb with link to Promotions That
Give Back webpage. A final schedule determining the dates and activities shall be mutually agreed to
by the parties. D. Additional Rights and Benefits The Association agrees to provide the following
additional rights and benefits: · Explore additional opportunities to be presented throughout the
duration of this agreement · If requested, a quote from the Association for Company to use in a
press release(s) · Recognition on the "Corporate Supporter - National Sponsors" web pages of
diabetes.org that includes a paragraph describing Company's relationship and commitment to the
Association · Opportunity to work with Association local market offices to encourage awareness for
Company's support, which may include but is not limited to engaging in Company's social media posts
via Facebook or Twitter, where appropriate · Single account executive for all Association-related
communications · Strategy meeting(s) with account executive to guide relationship or as needed ·
Monthly report detailing results/status of commitment, fifteen (15) to thirty (30) days post
activation and following the conclusion of the Agreement 8

Source: FREEZE TAG, INC., 8-K, 4/11/2018
<!-- page 9 -->
E. Relationship Structure & Payment Schedule Company agrees to pay to the Association the cash
rights fee in the amount of $150,000 for this Sponsorship Agreement. Payments to Association shall
be payable according to the following schedule: Year 1 - Due: December 31, 2018 - $50,000 Year 2 -
Due: December 31, 2019 - $75,000 Remaining Balance Due: March 30, 2020 - $25,000 Signatures:
American Diabetes Association Freeze Tag, Inc.

By: By: Name Name Title Title Date Date 9

Source: FREEZE TAG, INC., 8-K, 4/11/2018
<!-- page 10 -->
ATTACHMENT B Use of the Association's Marks Any use of the Association's Marks requires the review
and approval of the Association. Any modification to taglines or to the 'locked up' imagery
(Association brand and Cause brand) also requires review and written approval by the Association to
ensure that with any modification, there is prominent proximity between the brands. Approved
Association Cause or Activity Marks: "American Diabetes Association Stop Diabetes®" and "Tour de
Cure®" and "Tour de Cure 'year'®" - as logos change, attachments shall be added to this contract

PROMOTIONAL SUPPORTER

NATIONAL SPONSOR Get Fit Don't Sit Day® 10

Source: FREEZE TAG, INC., 8-K, 4/11/2018
<!-- page 11 -->
ATTACHMENT C CAUSE MARKETING COMPLIANCE GUIDELINES DONATION AT CHECKOUT a. Definition Invitation to
consumer to make a voluntary donation, separate and apart from the purchase price of any product or
service. b. Legal Requirements The company must not either: (a) keep any of the donated money, or
(b) be compensated in any way by the Association. A signed contract between the company and the
Association is required. Check with the Legal Department. c. Tracking Funds. A reliable system must
be implemented to keep track of all consumer donations and to assure that 100% of the donated funds
are delivered to the Association on a regular and timely basis. d. Disclosures Several states have
special disclosure requirements when consumers are asked to make donations. Check with Company Legal
Department for required disclosures. 11

Source: FREEZE TAG, INC., 8-K, 4/11/2018
