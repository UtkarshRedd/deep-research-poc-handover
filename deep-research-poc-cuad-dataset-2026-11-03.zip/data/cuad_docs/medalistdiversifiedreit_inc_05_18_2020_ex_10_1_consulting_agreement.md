<!-- page 1 -->
# CONSULTING AGREEMENT
| Field | Value |
|---|---|
| Document Type | Consulting Agreement |
| Agreement Date | 2020-03-01 |
| Parties | Gunston Consulting, LLC ("CONSULTANT"); Medalist Diversified REIT, Inc. ("REIT", "Company"); CONSULTANT and Company (collectively the "Parties") |
| Source | CUAD v1 / MEDALISTDIVERSIFIEDREIT,INC_05_18_2020-EX-10.1-CONSULTING AGREEMENT |

Exhibit 10.1 CONSULTING AGREEMENT This CONSULTING AGREEMENT ("Agreement") effective as of this 1st
day of March 2020 is hereby entered into between Gunston Consulting, LLC ("CONSULTANT"), a Virginia
limited liability company, and Medalist Diversified REIT, Inc. ("REIT" or the "Company"), a Maryland
corporation, collectively the "Parties." NOW THEREFORE, in consideration of the mutual promises and
other good and valuable consideration, the Parties hereby agree as follows: 1. Consulting Services.
REIT hereby retains CONSULTANT and CONSULTANT hereby accepts appointment to serve as an independent
contractor to the Company. During the term of this Agreement, CONSULTANT shall consult with REIT and
provide the services outlined in the attached Statement of Work in a timely and professional manner
in accordance with industry standards. CONSULTANT further agrees that it will not assign the
responsibilities set forth in the attached Statement of Work to any other CONSULTANT, subcontactor
or other individual without the express written agreement of the Company's Chief Executive Officer.
2. No Control by the Company. The Parties agree that CONSULTANT shall use its own judgment as to the
time, place, details, and means by which CONSULTANT will accomplish the results of CONSULTANT's
services under this Agreement, that CONSULTANT is not required to work set hours of the day or week
established by the Company or perform specific services in a sequence determined by the Company, and
that nothing contained herein shall be construed to create the relationship of employer and employee
between the Company or CONSULTANT; provided, however, that CONSULTANT is expected to provide the
services contemplated by this Agreement in a timely and competent manner in order to meet the needs
and expectations of the Company. 3. Independent Contractor. The Parties expressly intend and agree
that CONSULTANT is acting as an independent contractor and not as an employee of REIT. Under no
circumstances shall CONSULTANT look to REIT as its employer, or as a partner, agent, or principal.
CONSULTANT has no right or authority to act as an agent of REIT or for or on behalf of the Company
in any capacity whatsoever or to assume or create any obligation of any kind - express or implied -
on behalf of REIT. 4. Compensation and Reimbursement. CONSULTANT shall be compensated and reimbursed
for the services as set forth in the attached Statement of Work. Completeness of work product shall
be determined by REIT in its sole discretion, and CONSULTANT agrees to make all revisions,
additions, deletions or alterations as requested by the Company. No other fees and/or expenses will
be paid to CONSULTANT, unless such fees and/or expenses have been approved in advance by the
appropriate Company executive. CONSULTANT shall be solely responsible for any and all taxes, Social
Security contributions or payments, disability insurance, unemployment taxes, and other payroll-type
taxes applicable to such compensation.

1
<!-- page 2 -->
5. Confidentiality. 5.1 Acknowledgment of Proprietary Interest. REIT now owns and will hereafter
develop, compile, and own certain Proprietary Information, including proprietary techniques, trade
secrets, and confidential information, which have great value in its business. As used herein, the
term "Proprietary Information" includes any and all of REIT's confidential or proprietary
information, including without limitation, the existence of, and the terms of, this Agreement, any
and all confidential information of REIT encompassed in any and all reports, designs, devices,
diagrams, software codes, test results, processes, research products and product development,
technical memoranda and correspondence, work in progress, plans, proposals, marketing and sales
information and data, financial projections, cost summaries, pricing formula, and all concepts or
ideas, materials or information related to the business, products, or properties of REIT or REIT's
tenants, suppliers, employees or contractors, which has not previously been released to the public
at large by duly authorized representatives of REIT, whether or not such information would be
enforceable as a trade secret or the copying of which would be enjoined or restrained by a court as
constituting unfair competition, and any Work Product, as defined in Section 6 of this Agreement,
developed or created by the CONSULTANT. CONSULTANT acknowledges and agrees that any and all
Proprietary Information of REIT is the property of REIT. 5.2 Covenant Not to Divulge Proprietary
Information. CONSULTANT acknowledges and agrees that REIT is entitled to prevent the disclosure of
Proprietary Information of REIT. CONSULTANT agrees that at all times during or subsequent to the
performance of the consulting services under this Agreement, CONSULTANT will keep confidential and
will not divulge, communicate, or use Proprietary Information, except for CONSULTANT's own use
during the Term of this Agreement to the extent necessary to perform the consulting services.
CONSULTANT further agrees not to cause the transmission, removal or transport of tangible
embodiments of, or electronic files containing, Proprietary Information from REIT's principal place
of business, without prior approval of the Company. CONSULTANT shall disseminate Proprietary
Information only to those employees of CONSULTANT with a special need to know such Proprietary
Information. CONSULTANT warrants that such employees shall be informed of the proprietary nature of
the Proprietary Information and shall be bound by this Agreement in the same manner that CONSULTANT
is bound. 5.3 No Licenses. No rights or licenses in or to the Proprietary Information of REIT are
granted to CONSULTANT by virtue of this Agreement. 6. Intellectual Property, Inventions and Patents.
CONSULTANT acknowledges that CONSULTANT's rights in all discoveries, concepts, ideas, inventions,
innovations, improvements, developments, methods, designs, analyses, drawings, reports, patent
applications, copyrightable work and mask work (whether or not including any Proprietary
Information) and all registrations or applications related thereto, all other proprietary
information and all similar or related information (whether or not patentable) which relate to the
Company's actual or anticipated business, research and development or existing or future products or
services and which were or are conceived, developed, contributed to or made or reduced to practice
by CONSULTANT (whether alone or jointly with others) while under contract with the Company, whether
before or after the date of this Agreement ("Work Product"), belong to the Company. CONSULTANT shall
promptly disclose such Work Product to the Chief Executive Officer of the Company and, at the
Company's expense, perform all actions reasonably requested by the Chief Executive Officer of the
Company (whether during or after the consultancy) to establish and confirm such ownership (including
assignments, consents, powers of attorney and other instruments). CONSULTANT acknowledges that all
copyrightable Work Product which is capable of being classified as "works made for hire" under the
U.S. Copyright Act of 1976, as amended, shall be deemed "works made for hire" and that the Company
shall be the author of, and own all rights therein. To the extent that any such copyrightable work
is not a "work made for hire," CONSULTANT hereby assigns and agrees to assign to the Company all
right, title and interest, including a copyright, in and to such copyrightable work. Furthermore,
CONSULTANT agrees to sign any written instrument of transfer for any rights relating to the Work
Product which may be required to effect or evidence the assignment of rights in the Work Product to
the Company. The foregoing provisions of this Section 6 shall not apply to any invention that
CONSULTANT developed entirely on CONSULTANT's own time without using the Company's equipment,
supplies, facilities or trade secret information, except for those inventions that (i) relate to the
Company's business or actual or demonstrably anticipated research or development, or (ii) result
from any work performed by CONSULTANT for the Company.

2
<!-- page 3 -->
7. Restrictive Covenants. 7.1 Solicitation of Employees. CONSULTANT agrees that during its
consultancy for REIT and for a period of twelve (12) months immediately following the termination of
its consultancy with the Company for any reason, whether with or without cause, it will not, for
itself or any other person or entity: (a) solicit, induce, recruit or encourage any of the Company's
employees, contractors, independent contractors or any person who provides services to the Company
to terminate or reduce their employment or other relationship with the Company; (b) hire any
individual who is (or was within the six (6) months immediately preceding such hiring, unless such
employee was terminated from such employment by Company) an employee, exclusive contractor, or
exclusive independent contractor of the Company; or (c) attempt to do any of the foregoing. 7.2
Solicitation of Customers. CONSULTANT agrees that during its consultancy for REIT and for a period
of twelve (12) months immediately following the termination of its consultancy with the Company for
any reason, whether with or without cause, it will not: (a) solicit, entice or induce any Customer
for the purpose of providing, or provide, products or services that are competitive with the
products or services provided by the Company, or (b) solicit, entice, or induce any Customer to
terminate or reduce its business with (or refrain from increasing its business with) the Company. As
used in this Section 7.2, "Customer" means any person or entity to which the Company provided
products or services, including any tenants of the Company's properties, (or was invested in real
estate owned by the Company), and with which CONSULTANT had contact on behalf of the Company, within
the last twelve (12) months of its consultancy with the Company.

3
<!-- page 4 -->
7.3 Noncompetition. CONSULTANT agrees that during its consultancy for REIT and for a period of
twelve (12) months immediately following the termination of its consultancy with the Company for any
reason, whether with or without cause, it will not: (a) have any ownership interest in, or
participate in the financing, operation, management or control of, any Competitor; or (b) engage in
or perform services for any Competitor, if such services either (1) are the same as or similar to
(individually or in the aggregate) the services CONSULTANT performed for the Company during its
consultancy with the Company, or (2) are performed with respect to products or services of the
Competitor that are competitive with the products or services provided by the Company with which
CONSULTANT was involved during its consultancy with the Company or about which it received
Proprietary Information during its consultancy with the Company. As used in this section,
"Competitor" means: (i) any private or publicly traded real estate investment trust, fund or other
investment vehicle or program whose principal place of business is in Virginia or any other state in
which the Company owns real estate and whose business strategy is based on investing in, acquiring
or developing flex/industrial, retail, multifamily and limited service hotel real estate, whether
directly or indirectly through joint ventures, or (ii) any entity whose principal place of business
is in Virginia or any other state in which the Company owns real estate and that advises (including
any external advisor) such investment vehicles or programs. It is agreed that ownership of no more
than 1% of the outstanding voting stock of a publicly traded corporation will not constitute a
violation of Section 7.3. 7.4 Non-Disparagement. CONSULTANT acknowledges that any disparaging
comments by him against the Company are likely to substantially depreciate the business reputation
of the Company. CONSULTANT agrees to act in good faith so as to not harm the business reputation of
the Company in any way. CONSULTANT further agrees that it will not directly or indirectly defame,
disparage, or publicly criticize the services, business, integrity, veracity or reputation of the
Company or its owners, officers, directors, or employees in any forum or through any medium of
communication. Nothing in this Agreement will preclude CONSULTANT from supplying truthful
information to any governmental authority or in response to any lawful subpoena or other legal
process. 8. Termination. This Agreement shall terminate immediately upon the occurrence of any of
the following events: (a) upon the death or bankruptcy of CONSULTANT; or (b) upon the close of
business on the date the Company gives CONSULTANT written notice of Termination for Cause (as
defined below); (c) ninety (90) days following the date the Company gives CONSULTANT written notice
of termination for any or no reason; or (d) CONSULTANT may terminate this Agreement by giving ninety
(90) days' written notice to REIT.

4
<!-- page 5 -->
For purposes of this Agreement, "Termination for Cause" shall mean termination of this Agreement by
the Company as the result of: (i) any act of fraud, dishonesty or neglect of services by CONSULTANT
in connection with the services to be provided under this Agreement or against any Company customer,
vendor or affiliated company; or (ii) the breach or prospective breach of any provision of this
Agreement by CONSULTANT. 8.1 Return of Materials at Termination. In the event of any termination of
CONSULTANT's appointment, with or without cause, CONSULTANT shall promptly deliver to REIT any and
all materials, property, documents, data, and all other information belonging to REIT or pertaining
to Proprietary Information, whether prepared by REIT or CONSULTANT, in CONSULTANT's possession or
control, and regardless of how stored or maintained, including all originals, copies, and
compilations, and all information stored or maintained on computer, PDAs, electronic or other
devices, tapes, discs, or any other form of technology. CONSULTANT shall not take any materials,
property, documents, or other information, or any reproduction or excerpt thereof, belonging to REIT
or pertaining to any Proprietary Information. 8.2 Obligations Surviving Termination. The obligations
of Sections 3, 5, 6 and 7 shall survive any termination of this Agreement. 8.3 Change of Control. In
the event of a 'Change of Control' of Company, then if CONSULTANT's services are terminated without
cause at any time within a twelve (12) month period following such Change of Control, CONSULTANT
shall receive a termination fee equal to twelve (12) months compensation hereunder at the then
current monthly rate, including any stock compensation. A Change of Control shall be any purchase of
equity in the Company by a party that results in the party acquiring (i) voting control of the
Company or (ii) the authority to replace or appoint, a majority of the Board, or the CEO or COO or
CFO of the Company. 9. General Provisions. 9.1 Entire Agreement. This Agreement constitutes the
entire and exclusive agreement between the Parties with respect to the subject matter hereof and
supersedes any prior or contemporaneous agreements, representations, and understandings of the
Parties regarding their consulting relationship. 9.2 Severability. In the event that a court of
competent jurisdiction determines that any portion of this Agreement is in violation of any law or
public policy, only the portions of this Agreement that violate such law or public policy shall be
stricken. All portions of this Agreement that do not violate any statute or public policy shall
continue in full force and effect. Further, any court order striking any portion of this Agreement
shall modify the stricken terms as narrowly as possible to give as much effect as possible to the
intentions of the parties under this Agreement. 9.3 Representations and Warranties. CONSULTANT
represents and warrants to Company that (a) CONSULTANT has full power and authority to enter into
this Agreement including all rights necessary to make the foregoing assignments to Company; that in
performing under the Agreement; (b) CONSULTANT will not violate the terms of any agreement with any
third party; and (c) the Services and any work product thereof are the original work of CONSULTANT,
and to CONSULTANT's knowledge (i) do not and (ii) will not (unless noted to Company otherwise by
CONSULTANT) infringe upon, violate or misappropriate any patent, copyright, trade secret, trademark,
contract, or any other publicity right, privacy right, or proprietary right of any third party. For
clarity, while CONSULTANT may create original ideas that are Work Product herein, CONSULTANT cannot,
and does not warrant that those ideas can be exploited by Company with out infringing the rights of
other parties.

5
<!-- page 6 -->
9.4 Successors and Assigns. The rights and obligations of REIT under this Agreement shall inure to
the benefit of and shall be binding upon the successors and assigns of REIT. CONSULTANT shall not be
entitled to assign any of CONSULTANT's rights or obligations under this Agreement. 9.5 Taxes, Fees
and Benefits. Because this Agreement creates an independent contractor relationship, the parties
understand that the Company has no obligation to withhold any state or federal income taxes, social
security, or other taxes from payments to CONSULTANT, nor shall it make any workers' compensation or
unemployment benefit payments, contributions or payroll tax payments on behalf of CONSULTANT.
CONSULTANT agrees that it shall not be eligible for or entitled to participate in any PTO, benefit
plans, retirement and insurance coverage provided by the Company or its subsidiary and affiliated
entities to their respective employees. CONSULTANT also acknowledges and agrees that the Company
will issue a Form 1099 for all compensation paid to CONSULTANT, and it is CONSULTANT's obligation to
report and pay all federal, state and local income, payroll, self-employment and other taxes due for
her on all compensation from the Company as may be required by law. CONSULTANT agrees to indemnify
REIT for any claims, losses, costs, fees, liabilities, damages, or injuries suffered by REIT arising
out of CONSULTANT's breach of this section. 9.6 Governing Law; Jurisdiction. This Agreement shall be
interpreted, construed, governed, and enforced according to the laws of the Commonwealth of
Virginia, without giving effect to its conflict of laws principles. The Parties hereby agree and
consent that any and all causes of action arising under this Agreement shall only have jurisdiction
and venue in the United States District Court for the Eastern District of Virginia and/or the
Circuit Court for Chesterfield County. Each of the parties consents to the jurisdiction and venue of
either court for the resolution of all causes of action arising under this Agreement upon proper
service of process. 9.7 Indemnity. (a) Indemnity by the Company. The Company hereby agrees to
indemnify and hold harmless Consultant against any and all losses, claims, damages, liabilities and
expenses (including reasonable costs of investigation and legal counsel fees) to the extent not
funded by applicable insurance, in addition to any liability the Company may otherwise have, arising
out of, related to or based upon (i) any violation of law, rule or regulation by the Company or the
Company's agents, employees, representatives or affiliates or (ii) any third party action or claim
against the Company in which Consultant is alleged to be additionally liable. In this regard
CONSULTANT shall be an additional insured under Company's applicable insurance coverages. Company
shall provide CONSULTANT evidence of all such coverage.

6
<!-- page 7 -->
(b) Indemnity by Consultant. Consultant hereby agrees to indemnify and hold harmless the Company and
each person and affiliate associated with the Company against any and all losses, claims, damages,
liabilities and expenses (including reasonable costs of investigation and legal counsel fees) to the
extent not funded by applicable insurance, in addition to any liability the Consultant may otherwise
have, arising out of, related to or based upon: (i) Any breach by Consultant of any representation,
warranty or covenant contained in or made pursuant to this Agreement; or (ii) Any violation of law,
rule or regulation by Consultant or Consultant's agents, employees, representatives or affiliates.
(c) Actions Relating to Indemnity. If any action or claim shall be brought or asserted against a
party entitled to indemnification under this Agreement (the "Indemnified Party") or any person
controlling such party and in respect of which indemnity may be sought from the party obligated to
indemnify the Indemnified Party pursuant to this Section 9.7 (the "Indemnifying Party"), the
Indemnified Party shall promptly notify the Indemnifying Party in writing, and the Indemnifying
Party shall assume the defense thereof, including the employment of legal counsel and the payment of
all expenses related to the claim against the Indemnified Party or such other controlling party. If
the Indemnifying Party fails to assume the defense of such claims, the Indemnified Party or any such
controlling party shall have the right to employ a single legal counsel, reasonably acceptable to
the Indemnifying Party, in any such action and participate in the defense thereof and to be
indemnified for the reasonable legal fees and expenses of the Indemnified Party's own legal counsel.
(d) This Section shall survive any termination of this Agreement for a period of three (3) years
from the date of termination of this Agreement. Notwithstanding anything herein to the contrary, no
Indemnifying Party will be responsible for any indemnification obligation for the gross negligence
or willful misconduct of the Indemnified Party. 9.8 Modification. This Agreement may not be amended
except by an instrument in writing signed by or on behalf of all the Parties to this Agreement. IN
WITNESS WHEREOF, the Parties have executed this Agreement as of the effective date set forth above.
Gunston Consulting, LLC REIT: By: /s/ Brent Winn By: /s/ Thomas E. Messier NAME: Brent Winn NAME:
Thomas E. Messier Its: Authorized Signatory Title: Chief Executive Officer

7
<!-- page 8 -->
STATEMENT OF WORK Nature of Services: CONSULTANT shall have the duties, authorities and
responsibilities as are required by CONSULTANT's position commensurate with the duties, authorities
and responsibilities of persons in similar capacities in similarly sized companies, and such other
duties, authorities and responsibilities as may reasonably be assigned to CONSULTANT as the Chief
Executive Officer or the Board of Directors of the REIT (the "Board of Directors" or the "Board")
shall designate from time to time that are not inconsistent with CONSULTANT's position and that are
consistent with the bylaws of the REIT and/or the limited partnership agreement of the REIT's
operating partnership, Medalist Diversified Holdings, L.P., each as may be amended from time to
time, including, but not limited to, managing the affairs of the Company. Term: twelve (12) months
from the date of the Agreement which term shall automatically renew for an additional twelve (12)
months on such date if the Agreement is not otherwise terminated according to Section 8 of the
Agreement. Compensation: REIT agrees to pay CONSULTANT the following consulting fees, for services
performed by CONSULTANT: 1. $200,000 annual fee payable in 12 equal monthly installments or 24 equal
semi-monthly installments, at CONSULTANT's election. 2. Annual stock grants as awarded by the
Compensation Committee of the Company's Board of Directors. 3. Except for limited authorized
expenditures expressly agreed to and authorized by REIT, such as pre-approved, reasonable travel
expenses, CONSULTANT shall be responsible for paying all expenses incurred by him/her in the
performance of this Agreement. It is expressly understood that the Company will not wholly or
partially reimburse non-authorized expenses. Moreover, invoices for approved expenses must be
itemized and substantiated by appropriate receipts prior to payment.

8
