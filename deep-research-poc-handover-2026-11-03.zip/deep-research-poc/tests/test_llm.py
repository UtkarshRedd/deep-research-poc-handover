"""dr.llm: .env loading and role -> endpoint resolution (no network)."""
import dr.llm as llm_mod
from dr.llm import ROLE_DEFAULTS, endpoint_for, load_dotenv


def test_load_dotenv_sets_without_overriding(tmp_path, monkeypatch):
    env = tmp_path / ".env"
    env.write_text(
        "# comment\n"
        "DR_TEST_A=plain\n"
        "export DR_TEST_B='single quoted'\n"
        'DR_TEST_C="x=y=z"\n'
        "DR_TEST_PRESET=from-file\n"
        "not a kv line\n",
        encoding="utf-8",
    )
    for k in ("DR_TEST_A", "DR_TEST_B", "DR_TEST_C"):
        monkeypatch.delenv(k, raising=False)
    monkeypatch.setenv("DR_TEST_PRESET", "from-env")
    keys = load_dotenv(env)
    assert keys == ["DR_TEST_A", "DR_TEST_B", "DR_TEST_C"]
    assert llm_mod.os.environ["DR_TEST_A"] == "plain"
    assert llm_mod.os.environ["DR_TEST_B"] == "single quoted"
    assert llm_mod.os.environ["DR_TEST_C"] == "x=y=z"
    assert llm_mod.os.environ["DR_TEST_PRESET"] == "from-env"       # existing variables win
    assert load_dotenv(env, override=True).count("DR_TEST_PRESET") == 1
    assert llm_mod.os.environ["DR_TEST_PRESET"] == "from-file"
    assert load_dotenv(tmp_path / "missing.env") == []


def test_endpoint_for_defaults_and_overrides(monkeypatch):
    for k in list(llm_mod.os.environ):
        if k.startswith("DR_"):
            monkeypatch.delenv(k)
    monkeypatch.setattr(llm_mod, "_dotenv_done", True)   # do not pick up a real .env in the repo
    ep = endpoint_for("researcher")
    assert ep.model == ROLE_DEFAULTS["researcher"] and ep.base_url.endswith("/v1") and ep.supports_tools
    monkeypatch.setenv("DR_ENDPOINT_DEFAULT", "https://example.test/v1")
    monkeypatch.setenv("DR_MODEL_WRITER", "some/writer")
    monkeypatch.setenv("DR_TOOLS_WRITER", "0")
    monkeypatch.setenv("DR_EFFORT_RESEARCHER", "low")
    w = endpoint_for("writer")
    assert w.base_url == "https://example.test/v1" and w.model == "some/writer" and not w.supports_tools
    assert endpoint_for("researcher").reasoning_effort == "low"
