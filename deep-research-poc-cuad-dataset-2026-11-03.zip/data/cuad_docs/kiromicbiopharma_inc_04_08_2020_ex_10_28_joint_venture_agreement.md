<!-- page 1 -->
# JOINT VENTURE AGREEMENT
| Field | Value |
|---|---|
| Document Type | Joint Venture Agreement |
| Agreement Date | 2020-04-02 |
| Parties | KIROMIC BIOPHARMA Inc.; MOLIPHARMA S.R.L. ("Party" and, together, the "Parties") |
| Source | CUAD v1 / KIROMICBIOPHARMA,INC_04_08_2020-EX-10.28-JOINT VENTURE AGREEMENT |

Exhibit 10.28

[*] Certain information in this document has been omitted from this exhibit because it is both (i)
not material and (ii) would be competitively harmful if publicly disclosed.

JOINT VENTURE AGREEMENT

BETWEEN

KIROMIC BIOPHARMA Inc., a Delaware Company, Fannin South Professional Building, 7707, Fannin St.
Suite 140, Houston TX 77054 USA, in person of the Legal Representative of the Chief Executive
Officer dr. Prof. Maurizio Chiriva Internati, PhD

AND

MOLIPHARMA S.R.L. an Italian Company stated in Campobasso, Via del Castello n. 3, FISCAL CODE AND
VAT NUMBER: 01655870705 in person of the Legal Representative Avv. Giovanni Meliadò;

each a Party and, together, the Parties.

WHEREAS A. Kiromic is a Company active in the fields of:

Research and development, in the field of immunotherapy, immuno-oncology, infectious diseases,
cardiovascular disease, auto immune diseases, inflammatory diseases and gene editing that develops
highly effective and safe immuno-therapies to address and defeat different types of cancer and
serious diseases and unmet medical needs;

Research and development of Artificial Intelligence technologies and a multi-purpose computational
platform capable of identifying new cancer immunological targets for T and B cells. B. Molipharma
s.r.l. is a spin-off of the Università Cattolica del Sacro Cuore and active in the fields of:

research, development, production and marketing, also through licensing, of new products, synthetic
drugs and applications, new technologies and innovative process and product applications in the
pharmaceutical, pharmacological, clinical and therapeutic fields, also -1-
<!-- page 2 -->
protectable under the regulations for intellectual property, with the consequent possibility of
exploitation and industrial exploitation;

analysis, research, reports, pre-clinical and clinical studies, consultancy, technical development
activities, on its own behalf or for third parties, in the field of genetic, muscular, immune,
haematological, oncological, gynecological, urological pathologies C. The Parties wish to
collaborate for the common purposes about the research and development of at least two clinical
trial programs: a. Pre-clinical validation and clinical trial development of several targets in
different clinical indications, and particularly in Ovarian Cancer b. Pre-clinical validation and
clinical trial development of countermeasures against Covid19 Sars CoV2 outbreak, including oral
vaccines, as well as therapeutic and diagnostic solutions.

NOW, THEREFORE, the Parties agree as follows: 1. SCOPE AND AREAS OF THE JV

The Parties wish to collaborate to the Joint Venture ("JV"), with their respective efforts and
possibilities of support, assistance, advice, co-operation, and resources for the common purposes
about the research and development of the pre-clinical and clinical trial programs mentioned above.
2. PARTIES OBLIGATIONS

Notwithstanding as referred to the point 1, the Parties wish to collaborate to the JV in the
respective R&D areas; for the firsts two clinical trial programs, they undertake to collaborate as
follow:

Topic 1. Clinical trial program in Oncology.

With regard to the JV between the Parties about the Clinical trial program in Oncology, the
respective obligations are regulated below: - Molipharma, through a separate agreement with UCSC,
undertakes to provide the tissue samples and parts of tumors; - Molipharma undertakes to make UCSC
the site for clinical trials and in particular Molipharma undertakes to make UCSC the main site for
clinical trials in cancer using -2-
<!-- page 3 -->
the specific isoforms CAR (Chimeric Antigen Receptor) and/or check inhibitor technology, Exhibit A -
Kiromic is committed to bear all costs necessary for R&D, including all clinical development costs,
according to the terms and conditions set out in point n. 3;

Topic 2. Clinical trial program in Covid19 Sars CoV2 Vaccine

With regard to the JV between the Parties about the clinical trial program in Covid19 Sars CoV2
Vaccine, the respective obligations are regulated below: - Kiromic is committed to sharing patents
and know-how in relation to the following products which will be licensed to the JV exclusively for
the application in the specific and limited field of sars-cov-2 threat and relative disease
COVID-19: (i) VAPAs-Viral Antigen Proteins Associated © (Kiromic-2020) derived from Diamonds AI -
Artificial Intelligence Platform for Discovery and Prediction Antigen Protein (ii) Platform of DC
Vaccines (dendritic cell vaccine) - for therapeutic purposes - nominated BSK 01; (iii) Oral Delivery
Platform for Prophylactic Vaccine - accompanying immuno-boosting therapy - therapeutic vaccine
administration - nominated BSK02 (iv) Other patents eventually applicable in the specific field. -
Molipharma provides skills, competencies, relationships, financial resources and means for
development; - Molipharma is committed to ensuring that the development and testing of the vaccine
and any associated clinical trial studies are carried out through the specialized structures of the
UCSC. - Molipharma provides skills, competencies, relationships, financial resources and means for
development; - Molipharma is committed to ensuring that the development and testing of the vaccine
and any associated clinical trial studies are carried out through the specialized structures of the
UCSC. - Molipharma undertakes to make UCSC the site for clinical trials and in particular -
Molipharma, through a separate agreement with UCSC, undertakes to provide the biological samples
necessary to carry out the Research and Development, such as, but not limited, blood, serum, saliva,
clinical data, tissues samples of living and dead patients etc ; - Molipharma is committed to bear
all costs necessary for R&D, including all clinical development costs, according to the terms and
conditions set out in point n. 3; 3. STEERING COMMITTEE AND TECHNICAL CO-ORDINATION COMMITTEE

The Parties agree to establish a "Steering Committee", which will remain in force for the entire
period of the JV, composed of two members for each Company [e.g. Americo Cicchetti - To Be Nominated
and Maurizio Chiriva - Gianluca Rotino], with the task of identifying the strategic objectives of
the collaboration and providing general guidelines.

The Steering Committee shall appoint, within 30 days of the signature of this JV, a Technical
Committee composed of one representative of each of the Parties in relation to each specific -3-
<!-- page 4 -->
clinical trial program, which shall have the function of coordinating the technical and
administrative activities to be undertaken in the framework of this JV.

The tasks assigned to the Technical Committee are to: a. propose any new project to be developed to
the Steering Committee; b. define the specific guidelines for each project and check the execution
processes and timelines implemented under this JV; c. check at least quarterly the progress of the
clinical development programs, the correct implementation of the commitments undertaken, including
the economic ones; in the event of failure by one of the Parties to comply with these commitments,
the Technical Committee shall promptly inform the Steering Committee; d. report, every six months,
to the Steering Committee on the activities carried out and the results achieved under the
Agreement; e. propose to the Steering Committee any changes in the projects referred to in point 2
and/or any changes in the economic commitments made and their utilization.

The parties undertake, within 30 days from the signing of this JV, to grant a specific written and
notarial mandate, which gives Molipharma the power to represent the JV vis-à-vis third parties for
the performance of ordinary and extraordinary acts deemed necessary for the quickest and most
profitable achievement of the objectives set forth in point 2, including the right to enter into
partnership and/or collaboration contracts with external entities. 4. JV FUND

Kiromic undertakes to financially support the entire research program in oncology;

By way of example, Kiromic undertakes to finance the following items: a. The expenses for the supply
of equipment and materials, as well as those related to their ordinary and extraordinary
maintenance, necessary for the development of the program; b. Medical and subsistence expenses in
favor of the patients who will be selected for the clinical trials and any expenses necessary for
third party vendors (such as Contract Research Organizations, central labs, couriers, etc…)
necessary for planning and executing such clinical trials; -4-

c. Funding of scholarships and/or research grants for the staff who will be assigned to the research
and development of the projects referred to in point 2; d. Funding of educational or training
initiatives.
<!-- page 5 -->
Subsequent contributions will be provided by Kiromic to the common fund upon presentation of
individual purchase orders and/or proofs of expenditure —which will be paid for each time starting
upon the successful IPO (Initial Public Offering) of the Kiromic's common shares.

Molipharma undertakes to financially support the entire research program against sars-cov-2.

By way of example, Molipharma undertakes to finance the following items, either directly or
indirectly through research grants or other non-diluting funds, awarded by European and/or Italian
Institutions: a. The expenses for the supply of equipment and materials, as well as those related to
their ordinary and extraordinary maintenance, necessary for the development of the program; b.
Medical and subsistence expenses in favour of the patients who will be selected for the clinical
trials and any expenses necessary for third party vendors (such as Contract Research Organizations,
central labs, couriers, etc…) necessary for planning and executing such clinical trials; c. Funding
of scholarships and/or research grants for the staff who will be assigned to the research and
development of the projects referred to in point 2; d. Funding of educational or training
initiatives.

Subsequent contributions will be provided by Molipharma to the common fund upon presentation of
individual purchase orders and/or proofs of expenditure - which will be paid for each time. 5. STAFF
ACCESS

Molipharma allows Kiromic's staff in charge of the above research programs to have access to its own
structures, identified from time to time, as well as the possible use of its own equipment, in
compliance with the law provisions and the regulations therein applied, in compliance and observance
of the protection, safety and health standards therein applied.

Alternatively, Kiromic allows Molipharma' staff in charge of the above programs to have access to
its own structures and to its laboratory equipment, identified from time to time, in compliance -5-

with the law provisions and the regulations therein applied, in compliance and observance of the
protection, safety and health standards therein applied.
<!-- page 6 -->
The staff of each of the Parties to this JV who, by this Agreement, have access to the structures
and equipment of the other company, shall be liable for any damage caused to such equipment and to
third parties.

The Parties shall provide civil liability insurance cover to their own personnel with respect to
accidents and damages charged to them. 6. INTELLECTUAL PROPERTY RIGHTS AND PROHIBITION OF TRANSFER
TO THIRD PARTIES

The Parties undertake to promptly notify each other about the achievement of the Scope, as mentioned
in point 2 ("the Results") , that may be subject to Industrial and Intellectual Property Rights,
within 30 days from the achievement of such Results and to cooperate in the evaluation of the
existence of the necessary requirements for the patenting/registration of such Results.

The Industrial Property Rights on the Results, as well as the Intellectual Property Rights realized
in the research activities covered by this JV, are due jointly to the parties in equal shares (50%
for each Party), without prejudice to the possibility of agreeing in writing, during the course of
every specific activity, about the modification of the respective shares of co-ownership, based upon
the actual contribution of each of the Parties to the research activities, and also without
prejudice to the recognition of the intellectual rights due to each inventor pursuant to current
legislation.

The parties will agree, by separate agreement, on the specific discipline relating to the management
of rights in co-ownership; it is agreed that Molipharma may always use the Results for teaching and
research purposes.

If one of the Parties has no interest in applying for a patent, it will inform the other Party
within 30 days from the communication of the Results referred to in paragraph 1. In this case the
Party concerned shall have the right to proceed with the submission of the application on the
Results at its own expense and in co-ownership with the other Party, subject to written notice. The
Party which is not interested in the application shall undertake to transfer its own share of
ownership to the other Party, free of charge once it has obtained the patent title. -6-
<!-- page 7 -->
Each Party is the owner of the Industrial and Intellectual Property Rights relating to its own: a.
"Background": All knowledge, information and intangible assets protected under national Law System
and international intellectual and industrial property laws and regulations, created or otherwise
obtained by a Party prior to the begin of the activity covered by this Agreement. b. "Sideground":
All knowledge, information and intangible property protected under national Law System and
international intellectual and industrial property laws and regulations made or otherwise obtained
by a Party during the term of this Agreement but not in the execution of this Agreement.

Notwithstanding the foregoing, the Parties shall grant each other, free of charge, a non-exclusive
right to use their respective Backgrounds in connection with the activities which will be carried
out by this JV and by reason of their execution. This right is granted for the duration of the
Agreement only, with the express denial of sublicensing or transferring it to any third party for
any reason whatsoever.

The Sideground of each Party may not be used by the other Party without the express written
authorization of the owner.

The sale, licensing or any other type of agreement providing for the transfer, even temporary, to
third parties of intellectual and industrial property rights deriving from the research programs
referred to in point 2 is excluded, unless there is prior agreement between the Parties.

Kiromic assigns to Molipharma all the rights of publication of the research, unless they are
considered confidential for patenting. To this purpose, before each publication, Molipharma will
send in advance the text of the publication to Kiromic for approval. The consent of Kiromic will be
tacitly granted after 30 days from receipt of the request for authorization of disclosure.

The same procedure indicated in the previous paragraph will be also applied to Kiromic in case it
wants to perform a publication on the research. 7. ECONOMIC RIGHTS

The commercial rights arising from the research programs referred to in point 2 are divided as
follows:

Oncology

All economics rights are solely owned by Kiromic Biopharma.

Kiromic will grant to Molipharma the follows royalties: - *% of the realized turnover by the
marketing of Ovarian Cancer research results in Italy; -7-
<!-- page 8 -->
- *% of the realized turnover by the marketing of Ovarian Cancer research results in Europe.

Sars-cov-2 - The economic rights for Europa will be an exclusive ownership of Molipharma - The
economic rights in the U.S. will be an exclusive ownership of Kiromic. - For the rest of the world,
the economic rights will be divided as follows: *% Kiromic; *% Molipharma. 8. DURATION

This JV Agreement shall become effective on the signing date and shall have a duration of * years,
extendable for a further * years, unless notice of non- renewal is sent one year before the natural
expiry date.

This JV shall automatically cease to be effective on the date when the JV is wound-up or is the
target of any kind of insolvency procedure.

Termination of this JV Agreement shall not relieve the Parties of their obligations due at the time
of such termination, nor shall such termination prejudice any claim of either Party accrued, or to
accrue, on account of any default or breach by the other Party. 9. WITHDRAWAL AND RESOLUTION

The Parties may withdraw from this JV only for serious and justified reasons or by mutual consent.
The withdrawal must be exercised by written notice, to be sent to the other Party by certified
letter or PEC, with minimum notice of 30 days.

Withdrawal or termination by mutual consent shall only have effect for the future and shall not
affect the part of the Agreement already executed.

In case of withdrawal according to the previous paragraph, Kiromic is obliged to cover Molipharma
for the expenses incurred and for those committed, related to the research programs being developed,
until receipt of the notice of withdrawal. -8-
<!-- page 9 -->
Pursuant to art. 1456 of the Italian Civil Code, this JV shall be terminated by right in the
following cases: a. Breach of confidentiality obligations; b. Unilateral and unagreed variation of
the Scope of the JV; c. Failure of each Party to comply with its obligations, including the economic
commitments.

The Party concerned must communicate by registered letter with return receipt, or PEC, its intention
to avail itself of the termination clause.

In the event of termination of the Agreement pursuant to this clause or, in any case, to termination
due to Kiromic's default, the same is required; in addition, Kiromic undertakes to the reimbursement
of expenses incurred and/or committed by Molipharma, and agrees to recognize financially the
additional damage suffered by Molipharma by such a default.

Upon termination of the contract, the agreement set forth in clause 5 ("Intellectual property rights
and prohibition of transfer to third parties") and clause 6 ("Economic rights") will remain into
force. 10. TERMINATION

Each Parties shall have the right to terminate its obligations, if one of the following events
occurs: the Company (i) applies for or consents to the appointment of a receiver, trustee, custodian
or liquidator of itself or substantially all of its property, (ii) becomes subject to the
appointment of a receiver, trustee, custodian or liquidator of itself or substantially all of its
property, (iii) makes an assignment for the benefit of creditors, (iv) institutes any proceedings
under or state bankruptcy, reorganization, receivership, insolvency or other similar law affecting
the rights of creditors generally, or files a petition or answer seeking reorganization or an
arrangement with creditors to take advantage of any insolvency law, or files an answer admitting the
material allegations of a bankruptcy, reorganization or insolvency petition filed against it, or (v)
becomes subject to any involuntary proceedings under the state bankruptcy, reorganization,
receivership, insolvency or other similar law affecting the rights of creditors generally, when
proceeding is not dismissed within thirty (30) days of filing, or have an order for relief entered
against it in any proceedings under Bankruptcy Code. -9-
<!-- page 10 -->
11. SENSITIVE INFORMATION

The Parties shall keep confidential any information exchanged between them in connection with the
negotiation, execution and performance of this JV Agreement; it is agreed that these confidentiality
obligations shall not apply with respect to any information which: (a) becomes generally available
to the public other than as a result of an unauthorised disclosure by a Party, (b) was available to
a Party prior to its disclosure by the other Party, (c) is disclosed pursuant to a requirement of a
court or other public authority or for the purpose of enforcing the rights and obligations set forth
in this Agreement. 12. GENERAL PROVISIONS

All notices, demands, requests or other communications which may be or are required to be given,
served or sent by any Party to any other Party pursuant to this JV Agreement shall be in writing and
shall be hand delivered, sent by DHL (or by comparable international air courier) or mailed by
first- class, registered or certified mail, return receipt requested, postage prepaid, or
transmitted by telecopy, and shall be addressed as follows: (i) If to KIROMIC:

To the attention of the managing director

Telephone (ii) if to MOLIPHARMA:

To the attention of Mr. Giovanni Meliadò

Telephone

Each Party may designate by written notice an address to which any notice, demand, request or
communication may thereafter be so given, served or sent.

Each of the communications mentioned herein, given in the way described herein, shall be deemed
sufficiently given, served, sent, received or delivered for all purposes at the time it is received,
if made by hand delivery, or at the time indicate in the return receipt if made -10-
<!-- page 11 -->
by mail or courier, or at the time indicated in the answer-back of the telefax machine of the
receiving Party in case it is made by telefax.

No delay or failure on the part of any Party hereto in exercising any right, power or privilege
under this JV Agreement or under any other documents in connection with or pursuant to this
Agreement shall impair any such right, power or privilege or be construed as a waiver of any default
or any acquiescence therein. No single or partial exercise of any such right, power or privilege
shall preclude the further exercise of such right, power or privilege, or the exercise of any other
right, power or privilege. No waiver shall be valid against any Party hereto unless made in writing
and signed by the Party against whom enforcement of such waiver is sought and then only to the
extent expressly specified therein.

If any part of any provision of this JV Agreement or of any other document given pursuant to or in
connection with this JV Agreement shall be invalid or unenforceable in any respect, such part shall
be ineffective to the extent of such invalidity or unenforceability only, without in any way
affecting the remaining parts of such provision or the remaining provisions. The void provision
shall be substituted by a valid provision, the nature and economic consideration of which comes as
close as possible to the void provision. In the event that matters relevant to the subject matter of
this JV Agreement are not addressed herein, the Parties shall negotiate in good faith to agree a
provision or provisions which, given the nature and economic considerations of the JV Agreement and
related agreements, the Parties would have agreed upon had they considered the matter at the time of
the execution of this JV Agreement. If the invalidity or unenforceability of any provision hereof is
due to the excessive scope of such provision, such provision shall be deemed valid and enforceable
to the greatest extent permitted by applicable law.

This JV Agreement cannot be assigned by a Party, also as a result of the transfer of a business as a
going concern, of a merger, of a de-merger or of a spin-off, without the prior written consent of
the other Party. Subject to the above, this JV Agreement shall be binding upon and shall inure to
the benefit of the Parties hereto and their respective successors, heirs, executors, administrators,
legal representatives and assigns.

Each of the Parties hereby agrees to take or cause to be taken such further actions, to make and
receive or cause to be made and received any legal declarations, execute, deliver and file or cause
to be executed, delivered and filed such further documents, and will obtain -11-
<!-- page 12 -->
such consents, as may be necessary or as may be reasonably requested in order to fully effectuate
the purposes, terms and conditions of this JV Agreement mentioned. Without limiting the generality
of the foregoing, in case the Commission of the European Union, or any other competent regulatory
authority, both national and supranational, makes the clearance of any of the transactions
contemplated by this JV Agreement conditional upon changes or additions to the regulation herein set
forth, the Parties shall negotiate in good faith all those amendments that are necessary or proper
to comply with such requests by keeping unaltered the spirit of this JV Agreement and the balance of
interests herein reflected.

Each of the Parties hereto guarantees to the other Party that it has not engaged any broker, finder
or agent in connection with the transactions contemplated by this JV Agreement and has not incurred
(and will not incur) any unpaid liability to any broker, finder or agent for any brokerage fees,
finders' fees or commissions, with respect to the transactions contemplated by this JV Agreement.
Each Party agrees to indemnify, defend and hold harmless the other Party from and against any and
all claims asserted against it for any such fees or commissions by any persons purporting to act or
to have acted for or on behalf of the indemnifying Party.

Each Party hereto shall pay its own expenses incident to this JV Agreement and the transactions
contemplated hereunder, including all legal and accounting fees and disbursements. 13.
CONFIDENTIALITY

In this Clause, Confidential Information means (without limitation) the existence and contents of
the Documents and the existence and contents of any agreement or arrangement entered into pursuant
to any of the Documents and information relating to: - the customers, suppliers, business, assets or
affairs (including financial information) of any Party,

including information relating to the marketing of any products or services (for example, customer
names and lists and any other details of customers, sales targets, sales statistics, market share
statistics, prices, market research reports and surveys and advertising) and other promotional
materials; future projects; business development or planning; and -12-
<!-- page 13 -->
commercial relationships or negotiations, but excluding in any case the information in Clause 6.2.

Information is not Confidential Information if: (a) it is or becomes generally available to the
public (other than as a result of its disclosure in breach of this Agreement); (b) the disclosing
Party can establish to the reasonable satisfaction of the other Party that it found out the
information from a person not connected with the other Party or its Associated Companies or the
Company and that such person is not under any obligation of confidence in respect of the
information; or (c) the disclosing Party can establish to the reasonable satisfaction of the other
Party that the information was known to the disclosing Party before the date of this Agreement and
that it was not under any obligation of confidence in respect of the information.

Each Party irrevocably agrees, undertakes and covenants with the other Party and the Company and any
Subsidiary of the Company that it shall at all times keep confidential (and use all reasonable
endeavours to ensure that its employees, agents and Associated Companies, and the employees and
agents of such Associated Companies, and the Company shall keep confidential) any Confidential
Information and shall not use such Confidential Information except for the purpose of exercising or
performing its rights and obligations under or in connection with this Agreement, and shall not
disclose such Confidential Information except: (a) to an Associated Company or to a Party's
professional advisers where such disclosure is for a purpose related to the operation of this
Agreement; (b) with the written consent of such of the Company or the Party or any Associated
Company to which the information relates; (c) as may be required by law or by the rules of any
recognized stock exchange, or governmental or other regulatory authority or by a court or other
authority of competent jurisdiction, provided that, to the extent it is legally permitted to do so,
it gives the other Party as much notice of such disclosure as possible; -13-
<!-- page 14 -->
(d) a Party may, provided it has reasonable grounds to believe that the other party is involved in
activity that may constitute a criminal offence under the Anti-Corruption Rules, disclose
Confidential Information to the relevant governmental or other regulatory authority without first
informing the other party of such disclosure; (e) to any tax authority to the extent reasonably
required for the purposes of the tax affairs of the party concerned or any of its Associated
Companies; or (f) Confidential Information relating to the Company and any Subsidiary of the Company
(including copies of the Documents) to a bank or financial adviser of a Shareholder and/or to any
potential Buyer(s) in connection with a proposed sale pursuant to Clause 20, provided that: (i) such
bank, financial adviser and/or potential Buyer shall first have entered into confidentiality
undertakings for the benefit of the Company and any Subsidiary of the Company upon terms no less
stringent that those set out in this Clause 10or otherwise in a form reasonably satisfactory to the
Board; and (ii) the disclosing Party gives notice to the other Shareholder specifying, in general
terms, the information to be disclosed.

Each Party shall inform (and shall use all reasonable endeavors to procure that any of its
Associated Companies and the Company shall inform) any officer, employee or agent or any
professional adviser advising it in relation to the matters referred to in this Agreement, or to
whom it provides Confidential Information, that such information is confidential and shall require
them: (a) to keep it confidential; and (b) not to disclose it to any third party (other than those
persons to whom it has already been disclosed in accordance with the terms of this Agreement).

On termination of this Agreement, each Party shall (and shall use all reasonable endeavors to
procure that its Associated Companies, and its officers and employees and those of its Associated
Companies and the Company shall): (a) return to the other Party all documents and materials (and any
copies) containing, reflecting, incorporating or based on the other Party's Confidential
Information; and -14-
<!-- page 15 -->
(b) erase all the other Party's Confidential Information from computer and communications systems
and devices used by it, including such systems and data storage services provided by third parties
(to the extent technically and legally practicable),

provided that a recipient party (and/or the Company, as the case may be) may retain documents and
materials containing, reflecting, incorporating or based on the other Party's Confidential
Information to the extent required by law or any applicable governmental or regulatory authority.

The provisions of this Clause shall continue to apply after termination of this Agreement for any
cause. 14. ANTI-CORRUPTION RULES

Each Party recognizes and acknowledges that it is obliged to comply with the Anti-Corruption Rules.

Kiromic acknowledges receipt of a copy of MOLIPHARMA's Anti-Corruption Policies and confirms that it
has Anti-Corruption Policies in place that are at least comparable to MOLIPHARMA's.

Each Party warrants and undertakes to the other that: (a) it has not, and to its best knowledge and
belief none of its current or former directors, managers, officers or employees has, and, so far as
it is aware, no other person who otherwise is or has been one of its Associated Persons has, at any
time in the last [five (5)] years before the date of this Agreement: (i) made, given, authorized or
offered, or promised to make, give, authorize or offer any Prohibited Advantage to any person in
order to assist it or any of its Subsidiaries in improperly obtaining or retaining business for or
with any person, in improperly directing business to any person or in securing any improper
advantage; (ii) taken any other action which would violate applicable Anti-Corruption Rules; (iii)
been the subject of any investigation, inquiry or litigation, administrative or enforcement
proceedings by any Authority or any customer or other person regarding any offence or alleged
offence under any Anti-Corruption Rules and no such investigation, inquiry, litigation or proceeding
has been threatened or is pending and, so far as it is aware, -15-
<!-- page 16 -->
there are no circumstances likely to give rise to any such investigation, inquiry, litigation or
proceeding; (b) for so long as it is a Party to this Agreement it will not, and to the extent it is
legally able will procure that none of its Associated Persons will, engage in any of the conduct
described in sub-Clauses (a)(i) or (a)(ii); (c) it is not ineligible or, so far as it is aware,
treated by any Authority as ineligible to tender for any contract or business with, or be awarded
any contract or business by, such Authority, or to tender for or perform any sub-contracting work
under a contract with such Authority; (d) it has in place, and for so long as it is a Party to this
Agreement will maintain, and, to the extent it is legally able will procure that the Company will
maintain, adequate Anti-Corruption Policies; (e) it requires its Associated Persons to act in
accordance with the requirements of applicable Anti-Corruption Rules and uses all reasonable
endeavors to procure that they do so. So far as it is aware, each of its Associated Person which is
a legal person has in place policies, systems, controls and procedures designed to prevent, and
which are reasonably expected to continue to prevent it and its Associated Persons from violating
applicable Anti-Corruption Rules; and (f) in performing its obligations under and carrying out the
transactions contemplated by this Agreement and any other Document, neither it, nor any of its
Subsidiaries nor any of their respective Associated Persons has engaged or will engage in any
conduct described in sub- Clauses (a)(i) or (a)(ii). 15. DATA PROTECTION RULES PURSUANT TO REG.EU
679/2016 (GDPR)

Pursuant to and for the purposes of the Privacy Code and EU Reg. 679/2016 ("GDPR") ("Law") on
"Protection of persons and other subjects with regard to the processing of personal data", the
Parties - as autonomous Data Controllers - acknowledge that they have exchanged information on the
use of their personal data.

The Parties undertake to communicate to each other - in execution of this Contract - only the common
and/or sensitive personal data of third parties to whom they have given prior information and from
whom they have previously acquired (where necessary) their -16-
<!-- page 17 -->
consent, in accordance with the Privacy Code. and EU Reg. 679/2016 ("GDPR") In particular, such
consent must be informed, expressed, specific; documented in writing, in the case of common data;
given in writing under penalty of nullity, in the case of sensitive data.

Each Party shall be individually responsible for any communication of common and/or sensitive data
made without the prior fulfilment of the aforementioned obligations. The Party to whom the
communication is addressed will therefore be released from any responsibility and/or claim of third
parties, related to the possible communication of common and/or sensitive data made in breach of the
provisions of this clause and the Privacy Code and EU Reg. 679/2016. 16. GOVERNING LAW AND DISPUTE
ACCORDANCE

All disputes arising out of or in connection with this Agreement shall be finally settled under the
Rules of Arbitration of the International Chamber of Commerce by one or more arbitrators appointed
in accordance with the said Rules. Any such arbitration shall (i) be subject to the application of
the Italian Law, (ii) take place in Paris, France and (iii) be conducted in English.

Each of the parties to this Agreement consents to personal jurisdiction for any emergency injunction
sought in the Court of Rome. However, subsequent to the emergency injunction hearing, the merits of
the matter will be decided by the ICC as per the procedure set forth above.

IN WITNESS WHEREOF, Parties have severally subscribed to these articles, or caused them to be
subscribed in their name and on behalf by their respective officers thereunto duly authorized.

Rome/Houston, 2 April 2020 Kiromic Biopharma Inc. Molipharma s.r.l.

Prof Maurizio Chiriva Internati Avv. Giovanni Meliadò -17-
