<!-- page 1 -->
# Split-Dollar Endorsement Agreement
| Field | Value |
|---|---|
| Document Type | Endorsement Agreement |
| Agreement Date | 2017-06-01 |
| Parties | Prudential Bank ("Employer"); Jeffrey Hanuscin ("Employee") |
| Source | CUAD v1 / PrudentialBancorpInc_20170606_8-K_EX-10.4_10474434_EX-10.4_Endorsement Agreement |

Exhibit 10.4 Split-Dollar Endorsement Agreement

THIS AGREEMENT is made and entered into this 1st day of June, 2017 by and between Prudential Bank
(hereinafter referred to as the "Employer"), located in Philadelphia, Pennsylvania and Jeffrey
Hanuscin, (hereinafter referred to as the "Employee"), residing at 2406 Sanibel Circle, Palmyra, NJ
08065.

WHEREAS, the Employee has performed his duties in an efficient and capable manner; and

WHEREAS, the Employer is desirous of retaining the services of the Employee; and

WHEREAS, the Employer is desirous of assisting the Employee in obtaining life insurance on his own
life; and

WHEREAS, the Employer has determined that this assistance can best be provided under a
"split-dollar" arrangement; and

WHEREAS, the Employer and the Employee have applied for insurance policies issued by various
insurance companies; and WHEREAS, it is now understood and agreed that this split-dollar agreement
is to be effective as of the date first listed above;

WHEREAS, it is now understood and agreed that this agreement shall supersede any previous split
dollar agreements that are currently in place between the Employer and Employee.

NOW, THEREFORE, for value received and in consideration of the mutual covenants contained herein,
the parties agree as follows:

ARTICLE I "Definitions"

For purposes of this Agreement, the following terms will have the meanings set forth below:

"Base Salary" means the Employee's total base salary as of each January 1st exclusive of special
payments such as bonuses or commissions, but including any salary reductions made in accordance with
Section 125 or 401(k) of the Code.

"Cash Surrender Value of the Policies" will mean the Cash Value of the Policies; plus any dividends
and/or earnings added hereto; and less any Policy Loan Balance.

"Cash Value of the Policies" will mean the cash value as calculated according to the provisions of
the Policies.

"Current Loan Value of the Policies" will mean the Loan Value of the Policies reduced by any
outstanding Policy Loan Balance.

"Loan Value of the Policies" will mean the amount which with loan interest and Monthly Deductions
for the Cost of Insurance, plus any applicable Surrender Charge, will equal the Cash Value of the
Policies on the next loan interest due date.

"Net Amount at Risk" will mean the total face amount of the policies (including death benefit by
rider if applicable) reduced by the Cash Value of the Policies.

"Employer's Interest in the Policies" is defined in Articles IV and V.

"Policy" or "Policies" refers to the life insurance contracts listed below:

Source: PRUDENTIAL BANCORP, INC., 8-K, 6/6/2017
<!-- page 2 -->
Policy Number Carrier

39132041 Mass Mutual 755073 Midland National

However, a contract will be considered part of the "Policy" only to the extent the contract is
approved and issued by the Carrier. The Employer is under no obligation to enter into a substitute
contract for a contract that is not issued by the Carrier.

"Policy Loan Balance" at any time will mean policy loans outstanding plus interest accrued to date.

"Insurer" means the carrier of the Policy or Policies.

ARTICLE II "Allocation of Gross Premium"

The Employer will pay all premiums on the Policies when due, according to the Schedule of Premiums
in the Policies.

ARTICLE III "Rights in the Policies"

The Employee will have the sole right to designate the beneficiary for the amount specified in
Article IV of the death proceeds of the Policies. The Employer will have and may exercise, except as
limited hereinafter, all ownership rights in the Policies. The Employer will not take any action in
dealing with the Insurer that would impair any right or interest of the Employee in the Policies.
The Employer will have the right to borrow from the Insurer, and to secure that loan by the Policies
an amount which together with the unpaid interest accrued thereon, will at no time exceed the lesser
of (a) the Employer's Interest in the Policies and (b) the Loan Value of the Policies. During the
Employee's life time "The Employer's Interest In The Policies" will mean, at any time at which the
value of such interest is to be determined under this Agreement, the Cash Value of the Policies at
such time, reduced by any then outstanding Policy Loan Balance with respect to any loans made or
charged automatically against the Policies by the Employer.

ARTICLE IV "Rights to the Proceeds at Death"

Upon the death of the Employee while this Agreement is in force, the Employee's beneficiary as named
in the Beneficiary Designation Form on page 6 (or as it may be amended according to the terms set
forth on page 6) for this Agreement will be entitled to receive from the Policy proceeds an amount
equal to the lesser of: (a) (two (2) times the Employee's annualized base salary at the time of
death as provided by the Employer's payroll department) plus $100,000, reduced by any amount payable
under the Employer's group term life insurance plan, or (b) the Net Amount At Risk. The Employer
shall be the beneficiary of the remaining death proceeds of the policy after the Employee's interest
is determined. Within 60 days after the death of the Employee, the Employer will provide to the
"Insurer" a written statement indicating the amount of each policy's proceeds the Employee's
beneficiary is entitled to receive.

ARTICLE V "Taxes"

Any income or employment taxes due for a year on the value of current life insurance coverage
provided to the Employee under this Agreement will be the responsibility of the Employee. To the
extent that the value of current life insurance coverage is taxable income, it will be subject to
withholding requirements and will be reported as income by the Employer to the IRS and state-taxing
authorities on the Employee's W-2 Form or other IRS or state-required reporting form to the extent
required by law.

2

Source: PRUDENTIAL BANCORP, INC., 8-K, 6/6/2017
<!-- page 3 -->
ARTICLE VI "Termination of Agreement"

This Agreement may be terminated at any time while the Employee is living by written notice thereof
by either the Employer or the Employee to the other; and, in any event, this Agreement will
terminate upon termination of the Employee's employment. ARTICLE VII "Plan Management"

For purposes of the Employee Retirement Income Security Act of 1974, the Employer will be the "Named
Fiduciary" and Plan Administrator of the split-dollar life insurance plan for which this Agreement
is hereby designated the written plan instrument. The Employer's board of directors may authorize a
person or group of persons to fulfill the responsibilities of the Employer as Plan Administrator.
The Named Fiduciary or the Plan Administrator may employ others to render advice with regard to its
responsibilities under this Plan. The Named Fiduciary may also allocate fiduciary responsibilities
to others and may exercise any other powers necessary for the discharge of its duties to the extent
not in conflict with the Employee Retirement Income Security Act of 1974.

ARTICLE VIII "Claims Procedure"

(1) Filing claims. Any insured, beneficiary or other individual (hereinafter "Claimant") entitled to
benefits under the Plan or under the Policies will file a Claim request with the Plan Administrator
with respect to benefits under the Plan and with the "Insurer", with respect to benefits under the
Policies. The Plan Administrator will, upon written request of a Claimant, make available copies of
any claim forms or instructions provided by the "Insurer" or advise the Claimant where such forms or
instructions may be obtained.

(2) Notification to Claimant. If a claim request is wholly or partially denied, the Plan
Administrator will furnish to the Claimant a notice of the decision within 90 days in writing and in
a manner calculated to the understood by the Claimant, which notice will contain the following
information: (a) The specific reason or reasons for the denial; (b) Specific reference to the
pertinent Plan provisions upon which the denial is based; (c) A description of any additional
material or information necessary for the Claimant to perfect the Claim and an explanation of why
such material or information is necessary; and (d) An explanation of the Plan's claims review
procedure describing the steps to be taken by a Claimant who wishes to submit his claim for review.

(3) Review Procedure. A Claimant or his authorized representative may with respect to any denied
claim: (a) Request a review upon written application filed within 60 days after receipt by the
Claimant of notice of the denial of his claim; (b) Review pertinent documents; and (c) Submit issues
and comments in writing

Any request or submission will be in writing and will be directed to the Named Fiduciary (or his
designee). The Named Fiduciary (or its designee) will have sole responsibility for the review of any
denied claim and will take all steps appropriate in the light of its findings.

(4) Decision on Review. The Named Fiduciary (or its designee) will render a decision upon review of
a denied claim within 60 days after receipt of a request for review. If special circumstances
warrant additional time, the decision will be rendered as soon as possible, but not later than 120
days after receipt of request for review. Written notice of any such extension will be furnished to
the Claimant prior to the commencement of the Extension. The decision on review will be in writing
and will include specific reasons for the decision, written in a manner calculated to be understood
by the Claimant, as well as specific references to the pertinent provisions of the Plan on which the
decision is based. If the decision on review is not furnished to the Claimant within the time limits
prescribed above, the claim will be deemed denied on review.

3

Source: PRUDENTIAL BANCORP, INC., 8-K, 6/6/2017
<!-- page 4 -->
ARTICLE IX "Satisfaction of Claim"

The Employee rights and interests, and rights and interests of any person taking under or through
him, will be completely satisfied upon compliance by the Employer with the provisions of the
Agreement.

ARTICLE X "Amendment and Assignment"

This Agreement may be altered, amended or modified, including the addition of any extra policy
provisions, by a written instrument signed by the Employer and the Employee. Either party may,
subject to the limitations of Article IV, assign its interest and obligations under this Agreement,
provided, however, that any assignment will be subject to the terms of this Agreement.

ARTICLE XI "Possession of Policies"

The Employer will keep possession of the Policies. The Employer agrees from time to time to make the
policies available to the Employee or to the "Insurer" for the purpose of endorsing or filing any
change of beneficiary on the Policies but the Policies will promptly be returned to the Employer.

ARTICLE XII "Governing Law"

This Agreement sets forth the entire Agreement of the parties hereto, and any and all prior
agreements, to the extent inconsistent herewith, are hereby superseded. This Agreement will be
governed by the laws of the State of Pennsylvania.

ARTICLE XIII "Interpretation"

Where appropriate in this Agreement, words used in the singular will include the plural and words
used in the masculine will include the feminine.

IN WITNESS WHEREOF, the parties have hereunto set their hand, the Employer by its duly authorized
officer, on the day and year first above written.

/s/Jeffrey Hanuscin Employee Prudential Bank by: /s/Jack Rothkopf Senior Vice President and Chief
Financial Officer

4

Source: PRUDENTIAL BANCORP, INC., 8-K, 6/6/2017
<!-- page 5 -->
Split Dollar Policy Endorsement Beneficiary Designation

Pursuant to the terms of the Prudential Bank Split Dollar Agreement dated as of June 1st, 2017, the
undersigned Owner requests that the Policies referenced in the Agreement and issued by the Insurer
provide for the following beneficiary designation and limited contract ownership rights to the
Employee:

1. Upon the death of the Employee, proceeds shall be paid in one sum to the Owner, its successors or
assigns, to the extent of its interest in the Policy as described in the Agreement. It is hereby
provided that the Insurer may rely solely upon a statement from the Owner as to the amount of
proceeds it is entitled to receive under this paragraph.

2. Any proceeds at the death of the Employee in excess of the amount paid under the provisions of
the preceding paragraph shall be paid in one sum to the following beneficiaries designated by the
Employee: Primary Beneficiary, Relationship, Address Contingent Beneficiary, Relationship, Address

The Contingent Beneficiary shall receive the benefit only if the Primary Beneficiary does not
survive the Employee.

The exclusive right to change the beneficiary for the proceeds payable under this section 2, to
elect any optional method of settlement for the proceeds paid under this section 2 that are
available under the terms of the policy, and to assign all rights and interests granted under this
section 2 are hereby granted to the Employee. The sole signature of the Employee shall be sufficient
to exercise said rights.

The Owner retains all contract rights not granted to the Employee under this section 2.

3. It is agreed by the undersigned that this designation and limited assignment of rights shall be
subject in all respects to the contractual terms of the Policy.

4. Any payment directed by the Owner under this endorsement shall be a full discharge of the
Insurer, and such discharge shall be binding on all parties claiming any interest under the policy.

The undersigned for the Owner is signing in a representative capacity and warrants that he or she
has the authority to bind the entity on whose behalf this document is being executed.

Signed at Philadelphia, PA this __________ day of ________________, 2017.

EMPLOYEE:

Signature: _______________________________________ Name: _____________________

OWNER: Prudential Bank

Signature: _______________________________________ Name: _____________________

5

Source: PRUDENTIAL BANCORP, INC., 8-K, 6/6/2017
