<!-- page 1 -->
# NON-EXCLUSIVE DISTRIBUTOR AGREEMENT
| Field | Value |
|---|---|
| Document Type | Distributor Agreement |
| Agreement Date | 2018-07-19 |
| Parties | iMine Corporation ("JRVS"); SUNWAI Technology ("Distributor") |
| Source | CUAD v1 / ImineCorp_20180725_S-1_EX-10.5_11275970_EX-10.5_Distributor Agreement |

EXHIBIT 10.5 NON-EXCLUSIVE DISTRIBUTOR AGREEMENT This Non-Exclusive Distributor Agreement (the
"Agreement") is made and entered into as of this 19th day of July 2018, by and between iMine
Corporation, (hereinafter referred to as "JRVS") and SUNWAI Technology, a Taiwanese company, with
its principal office at 6th Floor, No. 258, Section 3, Nanjing East Road, Songshan District, Taipei
10051 (hereinafter referred to as the "Distributor"). RECITAL WHEREAS, Distributor desires to be, a
nonexclusive distributor of JRVS for certain cryptocurrency mining rig products; JRVS wishes to sell
its products through Distributor on a continuing basis on the terms and conditions set forth below.
AGREEMENT NOW, THEREFORE, in consideration of the mutual agreements and covenants, JRVS and the
Distributor agree as follows: 1. DEFINITIONS 1.1 "Confidential Information" of a party shall mean
any information disclosed by that party to the other party pursuant to this Agreement which is in
written, graphic, machine readable or other tangible form. Confidential Information may also include
oral information disclosed by one party to the other pursuant to this Agreement. 1.2 "Customers"
shall mean the purchasers of the Products whose principal offices and operations are located in the
Territory. 1.3 "iMine Products" shall mean those Products known as cryptocurrency mining rigs and
its parts and components, as JRVS and the Distributor shall maintain and modify from time to time.
1.4 "House Accounts" shall mean those Customers in the Territory who purchase Products directly from
JRVS. 1.5 "Non-standard Products" shall mean those Products that are not standard mining rigs that
require special testing, packaging or otherwise to be modified as requested by the Distributor and
approved by JRVS in writing. 1.6 "Proprietary Rights" shall mean all rights in the Products and
JRVS's Confidential Information, including, but not limited to, patents, copyrights, trademarks,
trade names, know-how, show-how, and trade secrets, irrespective of whether such rights arise under
U.S. or international intellectual property, unfair competition or trade secret laws. 1.7 "Products"
shall mean the products offered by JRVS for sale to the Distributor; the Products shall include
iMine cryptocurrency mining rigs and its parts and components. 1.8 "Territory" shall mean the
geographic area of Taiwan. 2. APPOINTMENT 2.1 Appointment of Nonexclusive Distributor. Subject to
the terms and conditions of this Agreement, JRVS appoints the Distributor, and the Distributor
hereby accepts such appointment, as JRVS'S non-exclusive authorized distributor for sale of the
Products to the Customers (other than House Account) in the Territory (as these terms are defined in
Section 1.8, above). Under no circumstances shall Distributor sell Products for use outside the
Territory. 1

Source: IMINE CORP, S-1, 7/25/2018
<!-- page 2 -->
2.2 Designation of House Account. In the event JRVS notifies the Distributor that JRVS has
designated a Customer of the Distributor as a new House Account, such Customer will become a House
Account effective Ninety (90) days following such notice. At JRVS's sole discretion, JRVS may
compensate the Distributor for extraordinary sales and distribution efforts rendered prior to the
designation of the new House Account. 3. DISTRIBUTOR RESPONSIBILITIES 3.1 Market Promotion. The
Distributor shall use its best efforts, consistent with prudent business practice, and shall devote
such time as may be commercially reasonably necessary, to conduct an aggressive marketing and
selling program and to promote the sale of the Products. 3.2 No Product Change. The Distributor
shall not modify or change the Products in any way without the express prior written consent of
JRVS. 3.3 Conflict of Interest. The Distributor shall not, during the term of this Agreement,
directly or indirectly market, sell, distribute, solicit orders within the Territory for any
products which are competitive with the iMine Products unless JRVS consents thereto in writing in
advance, based upon the Distributor's full disclosure of the material facts in seeking such consent.
Any such marketing, sale, distribution or solicitation of the competitive products is considered to
be a material breach of this Agreement. 3.4 Reports. Distributor shall submit periodical reports to
iMine to include information on how many buyers or potential buyers were contacted. 3.5 Compliance
with Laws. The Distributor shall comply at its own expense with all applicable laws and regulations
currently existing in Taiwan relating to the sale, distribution and promotion of the Products.
Distributor shall not export, directly or indirectly, any Products or related information outside of
Taiwan. 3.6 Feedbacks. The Distributor shall provide JRVS with prompt written notification of any
comments or complaints about the Products that are made by Customers, and of any problems with the
Products or their use that the Distributor becomes aware of. Such written notification shall be the
property of JRVS, and shall be considered to be part of JRVS's Confidential Information. 3.7
Referral. The Distributor agrees to refer all prospective customers to JRVS when the Distributor
cannot aggressively pursue distribution to such customers because of geographic location or any
other reason; provided, however, that if the Distributor cannot aggressively pursue distribution
because of price and/or volume, the parties will negotiate a reasonable referral fee to be mutually
agreed upon. The Distributor shall also refer directly to JRVS inquiries relating to bundling,
partnership or other business opportunities with third party vendors, hardware and system
manufacturers and software developers. 3.8 Inventory. The Distributor shall maintain an inventory of
Products in reasonably sufficient quantities to provide adequate and timely delivery to the
Customers. At a minimum, such inventory shall include not less than the quantity of Products
necessary to meet Distributor's reasonably anticipated demands for a thirty (30) day period. 3.9
Audits. JRVS shall be entitled at any time to audit the Distributor's books and records upon
reasonable notice in order to confirm the accuracy of the Reports set forth in Section 3.4;
provided, that no more than one such audit may be conducted in any three-month period. Any
JRVS-elected audit shall be performed at JRVS's own expense during normal business hours;
Distributor shall provide reasonable assistance to JRVS for the audit. Additionally, the Distributor
shall provide JRVS with its audited financial statements within three (3) months of the end of its
fiscal year. 4. ORDERS AND ACCEPTANCE 4.1 Rolling Forecast. The Distributor shall provide JRVS at
least one month in advance with a good faith rolling quarterly sales forecast for the units of the
Products to be provided by JRVS to the Distributor hereunder during each month in such calendar
quarter. Subject to Section 4.4, not later than the 15t h day of each month, Distributor will
provide JRVS with a binding purchase order for the third month following the month in which the
purchase order is placed and a non-finding forecast for the following three months (i.e., the
fourth, fifth and sixth months following the month in which the forecast is given. 2

Source: IMINE CORP, S-1, 7/25/2018
<!-- page 3 -->
4.2 Purchase Orders. The Distributor shall initiate purchases under this Agreement by submitting
written purchase orders (each, an "Order") to JRVS. Such orders shall state unit quantities, unit
descriptions, requested delivery dates, and shipping instructions. No purchase order shall be
binding upon JRVS until accepted by JRVS in writing. JRVS reserves the right to reject orders in
whole or in part. Partial shipment of an order shall not constitute acceptance of the entire order.
In the event that JRVS is unable to fill an accepted purchase order in accordance with the schedule
set forth therein as long as the purchase order does not exceed 110% of the iMine Products set forth
on the most recent forecast for such month, JRVS will use commercially reasonable efforts to fill
such order on an allotment basis. This Agreement shall govern all orders placed by the Distributor
for units of the Product. No terms on purchase orders, invoices or like documents produced by the
Distributor shall alter or add to the terms of this Agreement. Any other terms and conditions of
sale in conflict with or inconsistent with the terms and conditions of this Agreement, whether
contained in the Distributor's preprinted forms or otherwise, notwithstanding JRVS's acceptance
otherwise, shall have no force or effect to the extent of such conflict or inconsistency. 4.3 Order
Requirements. The Distributor's single purchase order amount shall be a minimum of five units.
Non-standard Products may have higher minimum purchase requirements and longer lead time as
determined by JRVS. 4.4 Lead Time. The Distributor shall submit purchase orders to JRVS in
accordance with a lead time of twenty-eight (28) to one hundred and twenty (120) days according to
the schedule advised by JRVS. In no event shall the lead time for Non-standard Products be less than
two (2) months. JRVS shall use commercially reasonable efforts to deliver units of Product at the
times set forth in JRVS's written acceptances of the Distributor's purchase orders. 4.5
Demonstration Units. Orders by Distributor for samples and/or pilot run may be subject to smaller
amount and shorter cycle time as shall be requested by Distributor and accepted by JRVS. In such
cases, products may be ordered in multiples of smaller units (calculated in number of reels or
tubes), and in no events shall exceed three such units. 4.6 Cancellations. Except as provided
herein, all Orders for Products are non-cancelable, and Products are non-returnable (NC/NR). Subject
to JRVS's written approval, orders for mining rigs may be rescheduled or cancelled subject to the
cancellation fees, which are based on the number of days in advance of the scheduled shipment date
that the Distributor notifies JRVS of cancellation and shall be set by JRVS from time to time. The
Nonstandard Products are at all times non-cancelable. Distributor shall contact JRVS in advance for
pricing and delivery information for orders of Non-standard Products. 5.1 JRVS Price. Subject to the
terms and conditions of this Agreement, the Distributor shall pay for the Products at the then
current price of JRVS (the "JRVS Price") at the time of placement of the Order. 5.2 Price Change.
JRVS shall have the right to revise JRVS Price at any time. Price changes shall apply to all
purchase orders received after the effective date with the notice, except that any price increase
shall be effective immediately upon notice to Distributor and apply to those accepted but
undelivered orders. 5.3 Special Pricing. Notwithstanding the JRVS Price, special pricing on any one
of the Products may be extended to the Distributor, in JRVS sole discretion, in situations where
special pricing is necessary for the Distributor to obtain sale of the Products to a Customer. If
JRVS elects to extend such special pricing, it will issue a confidential meet comp quote number
documenting the special price quoted. Upon receipt of the meet comp quote number, the Distributor
may ship the Products to the Customer from stock and debit JRVS for the difference between their
invoiced amount, less any prior credits granted by JRVS, and the new special pricing. The meet comp
quote number shall be included on all such debits. 5.4 Taxes. All JRVS Prices are exclusive of any
export, withholding, federal, state and local taxes, duties or excises other than taxes based on
JRVS's net income. If JRVS pays any taxes, duties or excises which are not included in the fees
charged for the Product, JRVS shall itemize such taxes, duties or excises as a separate item on its
invoices to the Distributor, and the Distributor shall reimburse JRVS for such taxes, duties or
excises; provided, that the Distributor shall not be required to make any such reimbursement if it
provides a valid tax exemption certificate to JRVS prior to shipment. 3

Source: IMINE CORP, S-1, 7/25/2018
<!-- page 4 -->
6. TERMS OF PAYMENT 6.1 Payment Terms. JRVS shall submit an invoice to the Distributor upon shipment
of Products to the Distributor. The invoice shall state the amount to be paid by the Distributor for
all Products in such shipment, as well as any taxes, duties or excises paid by JRVS which shall be
reimbursed by the Distributor in accordance with Section 5.4. Terms of payment shall be net thirty
(30) days. All payments shall be in U.S. Dollars. 6.2 Late Payments. All amounts which are not
timely paid by the Distributor as required by this Agreement shall be subject to a late charge equal
to one and one-half percent (1.5%) per month (or, if less, the maximum allowed by applicable law).
In the event that any payment due hereunder is overdue, JRVS reserves the right to suspend
performance until such delinquency is corrected. 7. DELIVERY 7.1 Packing and Shipping. All Products
to the Distributor shall be packaged in JRVS's standard containers, or, at the Distributor's
expense, in accordance with instructions provided by the Distributor, and shall be shipped to the
Distributor's address set forth above, or to an address specified in the purchase order. Unless
otherwise agreed, shipment shall conform to JRVS's standard shipping procedures, or such terms as
both shall agree. Title and risk of loss shall pass to the Distributor at the Delivery Point. All
customs duties, freight, insurance and other shipping expenses from the Delivery Point, as well as
any other special packing expenses requested by the Distributor, shall be borne by the Distributor.
The Distributor agrees to satisfy all import formalities pertaining to shipment of units of the
Product to destinations outside the United States. 7.2 Inspection and Acceptance. The Distributor
shall have thirty (30) days (the "Inspection Period") upon receipt of each shipment to inspect and
test the Products. If the Distributor determines any unit of Products defective, the Distributor
shall promptly notify JRVS of such defects. Defective Products may be returned for retest,
evaluation and examination subject to JRVS Returned Material Authorization ("RMA") procedure;
provided, that such written notification and request for an RMA number must be received by JRVS
during the Inspection Period. Returns must be prepaid by Distributor. When requesting a return
authorization, Distributor must supply Distributor's purchase order number and JRVS's invoice
number. Product description must include lot number and wafer numbers. 7.3 Exclusion. JRVS will
inspect all Products returned pursuant to the foregoing RMA procedures, and JRVS will not replace
products where the defect is due to misuse, neglect, alteration or improper storage by the
Distributor. 8. PROPRIETY RIGHTS 8.1 Acknowledgement. The Distributor acknowledge and agree that
JRVS owns all of the Proprietary Rights. The use by the Distributor of the Proprietary Rights is
authorized only for the purposes herein set forth and upon termination of this Agreement for any
reason, such authorization will cease. 8.2 No Other Rights. The Distributor may not, directly or
through any person or entity, in any form or manner, copy, distribute, reproduce, incorporate, use
or allow access to the Products or modify, prepare derivative works of, decompile, reverse engineer,
disassemble or otherwise attempt to derive source code or object code from the Products, except as
explicitly permitted under this Agreement or otherwise agreed in writing. 8.3 Proprietary Notice.
The Distributor will ensure that all copies of the Products will incorporate copyright and other
proprietary notices in the same manner that JRVS incorporates such notices in the Products or in any
manner reasonably requested by JRVS. The Distributor will not remove any copyright or other
proprietary notices incorporated on or in the Products by JRVS. 8.4 Use of Trademarks. During the
term of this Agreement, the Distributor may (i) announce to the public that it is an authorized
non-exclusive the Distributor of the Products, and (ii) advertise the Products under the trademarks,
service marks, marks, and trade names that JRVS may adopt from time to time (the "JRVS Trademarks").
JRVS shall provide the Distributor JRVS Trademarks on disk or camera-ready art for production. The
Distributor understands that JRVS has applied for applicable federal and state registration of
certain of its trademarks and agrees, upon JRVS's request, to so indicate on the box containing the
Products and, in any advertisement,, promotional materials or other documents that contain the
Products' names. Nothing herein will grant to the Distributor any right, title or interest in JRVS
Trademarks. At no time during or after the term of this Agreement will the Distributor challenge or
assist others to challenge JRVS Trademarks or the registration thereof or attempt to register any
trademarks, marks or trade names confusingly similar to those of JRVS. The Distributor shall follow
reasonable trademark usage guidelines communicated by JRVS. Distributor's use of JRVS's trademarks
and trade names shall be subject to JRVS' prior approval and shall be used only in a manner
consistent with JRVS' trademark use policy. 4

Source: IMINE CORP, S-1, 7/25/2018
<!-- page 5 -->
8.5 Use of Trade Names. The Distributor will present and promote the sale of the Products fairly.
The Distributor may use JRVS's product names in the Distributor's advertising and promotional media
provided (i) that the Distributor conspicuously indicates in all such media that such names are
trademarks of JRVS and (ii) that the Distributor submits all such media to JRVS for prior approval
and complies with the requirements set forth in Section 8.4. Upon termination of this Agreement for
any reason, the Distributor will immediately cease all use of Products' names and JRVS Trademarks
and, at the Distributor's election, destroy or deliver to JRVS all materials in the Distributor's
control or possession which bear such names and trademarks, including any sales literature. The
Distributor will not challenge any intellectual property rights claimed by JRVS in such trademarks.
9. CONFIDENTIAL INFORMATION 9.1 Nondisclosure, Non Use. Each party shall treat as confidential all
Confidential Information of the other party, shall not use such Confidential Information except as
set forth herein, and shall use reasonable efforts not to disclose such Confidential Information to
any third party. Without limiting the foregoing, each of the parties shall use at least the same
degree of care which it uses to prevent the disclosure of its own confidential information of like
importance to prevent the disclosure of Confidential Information disclosed to it by the other party
under this Agreement. Each party shall promptly notify the other party of any actual or suspected
misuse or unauthorized disclosure of the other party's Confidential Information. 9.2 Exception.
Notwithstanding the above, neither party shall have liability to the other with regard to any
Confidential Information of the other which the receiving party can prove: (a) was in the public
domain at the time it was disclosed or has entered the public domain through no fault of the
receiving party; (b) was known to the receiving party, without restriction, at the time of
disclosure, as demonstrated by files in existence at the time of disclosure; (c) is disclosed with
the prior written approval of the disclosing party; (d) was independently developed by the receiving
party without any use of the Confidential Information, as demonstrated by files created at the time
of such independent development; (e) becomes known to the receiving party, without restriction, from
a source other than the disclosing party without breach of this Agreement by the receiving party and
otherwise not in violation of the disclosing party's rights; (f) is disclosed generally to third
parties by the disclosing party without restrictions similar to those contained in this Agreement;
or (g) is disclosed pursuant to the order or requirement of a court, administrative agency, or other
governmental body; provided, however, that the receiving party shall provide prompt notice thereof
to the disclosing party to enable the disclosing party to seek a protective order or otherwise
prevent or restrict such disclosure. 9.3 Return of Confidential Information. Upon expiration or
termination of this Agreement, each party shall return all Confidential Information received from
the other party. 9.4 Remedies. Any breach of the restrictions contained in this Section 9 is a
breach of this Agreement which may cause irreparable harm to the nonbreaching party. Any such breach
shall entitle the nonbreaching party to injunctive relief in addition to all legal remedies. 5

Source: IMINE CORP, S-1, 7/25/2018
<!-- page 6 -->
10. LIMITED WARRANTY 10.1 Sole Warranty. THE SOLE WARRANTY, IF ANY, PROVIDED IN CONNECTION WITH THE
PRODUCT SHALL BE PROVIDED BY THE COMPONENT MANUFACTURER. JRVS MAKES NO WARRANTIES TO THE DISTRIBUTOR
OR CUSTOMERS. 10.2 Warranty Period. JRVS shall NOT provide a warranty of any kind for each of the
Products against defects in material and workmanship under normal use and service from the date of
delivery to the Distributor. 10.3 No Other Warranty. EXCEPT AS EXPRESSLY PROVIDED IN THIS SECTION
10, JRVS PROVIDES NO WARRANTY, EXPRESS, IMPLIED, STATUTORY, OR OTHERWISE, AND SPECIFICALLY DISCLAIMS
ANY WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE, WITH RESPECT TO THE PRODUCT AND
DOCUMENTATION. 11. INDEMNIFICATION 11.1 Indemnification by the Distributor. The Distributor agrees
to indemnify, defend and hold JRVS and its affiliated companies and their directors, officers,
employees, and agents (collectively, "Protected Parties") harmless from and against any and all
claims (including those for personal injury or death) and liabilities (including attorneys' and
other professional fees and other costs of litigation) by any other party arising out of or
attributable to the Distributor's representation of the Products in a manner inconsistent with
JRVS's Product descriptions and warranties or from the Distributor's marketing, distribution, use or
sale of the Products. 12. TERM AND TERMINATION 12.1 Term. This Agreement shall become effective upon
the date first written above and shall remain in full force and effect for a period of two years
(2), unless earlier terminated pursuant to the provisions in this Agreement. This Agreement shall
expire unless extended by both parties in writing prior to the termination. 12.2 Termination for
Convenience. This Agreement may be terminated by either party for any reason or no reason, whether
or not extended beyond the initial term, by giving the other party written notice ninety (90) days
in advance. 12.3 Termination for Cause. Except as set forth in the last sentence of this Section
12.3, if either party defaults in the performance of any material provision of this Agreement, then
the non-defaulting party may give written notice to the defaulting party that if the default is not
cured within thirty (30) days the Agreement will be terminated. If the non-defaulting party gives
such notice and the default is not cured during the thirty (30) day period, then the Agreement shall
automatically terminate at the end of that period. Notwithstanding the foregoing, if the Distributor
breaches the provisions of Section 9 hereof, then JRVS shall be entitled to terminate this Agreement
effective immediately upon delivery of written notice to the Distributor. 12.4 Termination for
Insolvency and Other Events. This Agreement shall terminate, without notice, (i) upon the
institution by or against either party of insolvency, receivership or bankruptcy proceedings or any
other proceedings for the settlement of such party's debts, (ii) upon either party's making an
assignment for the benefit of creditors, or (iii) upon either party's dissolution or ceasing to do
business. 12.5 Effect of Termination. Upon termination of this Agreement, the Distributor shall make
such disposition of price lists, advertising materials and other materials furnished by JRVS as JRVS
may direct. JRVS's name, JRVS's Trademarks, and similar identifying symbols shall not be displayed
or used by the Distributor thereafter. 12.6 No Liability. In the event of termination by either
party in accordance with any of the provisions of this Agreement, neither party shall be liable to
the other, because of such termination, for compensation, reimbursement or damages on account of the
loss of prospective profits or anticipated sales or on account of expenditures, inventory,
investments, leases or commitments in connection with the business or goodwill of either party.
Termination shall not, however, relieve either party of any obligations incurred prior to the
termination, including, without limitation, the obligation of the Distributor to pay JRVS for
Products purchased prior to such termination. 12.7 Survival of Certain Terms. The provisions of
Sections 1, 3.9, 5, 6, 8, 9, 10, 11, 12, 13, 14, and 15 of this Agreement, and all payment
obligations incurred during the term of this Agreement, shall survive the expiration or termination
of this Agreement for any reason. The provisions of Section 9 shall survive the expiration or
termination of this Agreement for five (5) years. All other rights and obligations of the parties
shall cease upon termination of this Agreement. 6

Source: IMINE CORP, S-1, 7/25/2018
<!-- page 7 -->
13. LIMITATION OF LIABILITIES 13.1 Limitation of Liabilities. IN NO EVENT SHALL JRVS'S LIABILITY
ARISING OUT OF THIS AGREEMENT EXCEED THE AMOUNT RECEIVED BY JRVS FROM THE DISTRIBUTOR HEREUNDER FOR
THE PRODUCT GIVING RISE TO THE LIABILITY. IN NO EVENT SHALL JRVS BE LIABLE FOR COSTS OF PROCUREMENT
OF SUBSTITUTE PRODUCTS OR SERVICES, LOST PROFITS OR ANY CONSEQUENTIAL, SPECIAL, INCIDENTAL, OR
INDIRECT DAMAGES, HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY (INCLUDING NEGLIGENCE OR STRICT
LIABILITY), ARISING OUT OF THIS AGREEMENT. THE DISTRIBUTOR ACKNOWLEDGES AND AGREES THAT THESE
LIMITATIONS SHALL APPLY NOTWITHSTANDING ANY FAILURE OF ESSENTIAL PURPOSE OF ANY LIMITED REMEDY. 13.2
Limitation on Actions. NO ACTIONS, REGARDLESS OF FORM, ARISING OUT OF THIS AGREEMENT, MAY BE BROUGHT
BY DISTRIBUTOR MORE THAN ONE (1) YEAR AFTER THE CAUSE OF ACTION HAS ARISEN. 14. NOTICES 14.1 All
notices required or permitted hereunder shall be in writing and shall be delivered (a) by facsimile,
(b) personally, or (c) mailed by certified or registered mail, return receipt requested and postage
prepaid, addressed to the addressed below. Delivery by facsimile is effective upon receipt of
successful fax transmission and shall be followed by delivery by mail as set forth above. Notice by
personal delivery is effective upon receipt of the notice. Notice sent by mail shall for all
purposes of this Agreement be treated as being effective or having been given ten days after mail.
To JRVS: iMine Corporation 8520 Allison Point Blvd Ste. 223 #87928 Indianapolis, Indiana 46250
Attention: Mr. Daniel Tsai, Chief Executive Officer To DISTRIBUTOR: Sunwai Technology 6th Floor, No.
258, Section 3, Nanjing East Road, Songshan District, Taipei 10051 Attention: Mr. SEI-PENG TU,
President 15. GENERAL 15.1 Authority. Both parties represent and warrant to each other that they
have the right and lawful authority to enter into this Agreement. 15.2 Entire Agreement. This
Agreement constitutes the entire agreement of the parties pertaining to the subject matter hereof,
and merges all prior negotiations and drafts of the parties with regard to the transactions
contemplated herein. Any and all other written or oral agreements existing between the parties
hereto regarding such transactions are expressly canceled. 15.3 No Conflict. In the event of a
conflict or inconsistency between the terms of this Agreement and those of any order, quotation,
solicitation or other communication from one party to the other, the terms of this Agreement shall
be controlling. 7

Source: IMINE CORP, S-1, 7/25/2018
<!-- page 8 -->
15.4 Amendments and Waivers. No modification, change or amendment to this Agreement, or any waiver
of any rights in respect hereto, shall be effective unless in writing signed by both parties in the
case of a modification, change or amendment or by the party granting the waiver in the case of a
waiver. 15.5 Successors and Assigns. The Distributor shall not assign any of its rights, obligations
or privileges (by operation of law or otherwise) hereunder without the prior written consent of
JRVS. JRVS shall have the right to assign its rights, obligations and privileges hereunder to an
assignee that agrees in writing to be bound by the terms and conditions of this Agreement. The terms
and conditions of this Agreement shall inure to the benefit of and be binding upon the respective
permitted successors and assigns of the parties. Nothing in this Agreement, express or implied, is
intended to confer upon any party other than the parties hereto or their respective successors and
assigns any rights, remedies, obligations, or liabilities under or by reason of this Agreement,
except as expressly provided in this Agreement. 15.6 Independent Contractor. Neither party shall,
for any purpose, be deemed to be an agent of the other party and the relationship between the
parties shall only be that of independent contractors. Neither party shall have any right or
authority to assume or create any obligations or to make any representations or warranties on behalf
of any other party, whether express or implied, or to bind the other party in any respect
whatsoever. 15.7 Export Control. Distributor understands that JRVS may be subject to regulation by
agencies of the U.S. government, including the U.S. Department of Commerce, which prohibit export or
diversion of certain products and technology to certain countries. Any and all obligations of JRVS
to provide Products, as well as any technical assistance, will be subject in all respects to such
United States laws and regulations and will from time to time govern the license and delivery of
technology and products abroad by persons subject to the jurisdiction of the United States,
including the Export Administration Act of 1979, as amended, any successor legislation, and the
Export Administration Regulations issued by the Department of Commerce, International Trade
Administration, or Office of Export Licensing. Distributor warrants that it will comply in all
respects with the export and re-export restrictions for all Products shipped to Distributor.
Distributor will take all actions which may be reasonably necessary to assure that no end-user
contravenes such United States laws or regulations. 15.8 Force Majeure. In the event that either
party is prevented from performing or is unable to perform any of its obligations under this
Agreement (other than a payment obligation) due to any Act of God, fire, casualty, flood,
earthquake, war, strike, lockout, epidemic, destruction of production facilities, riot,
insurrection, material unavailability, or any other cause beyond the reasonable control of the party
invoking this section, and if such party shall have used its best efforts to mitigate its effects,
such party shall give prompt written notice to the other party, its performance shall be excused,
and the time for the performance shall be extended for the period of delay or inability to perform
due to such occurrences. Notwithstanding the foregoing, if such party is not able to perform within
thirty (30) days after the event giving rise to the excuse of force majeure, the other party may
terminate this Agreement. 15.9 Severability. If one or more provisions of this Agreement are held to
be unenforceable under applicable law, the parties agree to renegotiate such provision in good
faith, in order to maintain the economic position enjoyed by each party as close as possible to that
under the provision rendered unenforceable. In the event that the parties cannot reach a mutually
agreeable and enforceable replacement for such provision, then (i) such provision shall be excluded
from this Agreement, (ii) the balance of the Agreement shall be interpreted as if such provision
were so excluded and (iii) the balance of the Agreement shall be enforceable in accordance with its
terms. 15.10 Titles and Subtitles. The titles and subtitles used in this Agreement are used for
convenience only and are not to be considered in construing or interpreting this Agreement. 15.11
Choice of Law; Dispute Resolution. This Agreement shall be governed by and construed pursuant to the
laws of the State of Indiana, U.S.A., without reference to principals of conflicts of laws. All
disputes arising out of this shall be settled by final binding arbitration in Hamilton County,
Indiana, pursuant to the Commercial Arbitration Rules of the American Arbitration Association.
Judgment on the award rendered by the arbitrators may be entered in any court having competent
jurisdiction thereof. Notwithstanding the foregoing, the parties may apply to any court of competent
jurisdiction in Hamilton County, Indiana, U.S.A., for a temporary restraining order, preliminary
injunction, or other interim or conservatory relief, as necessary, without breach of this
arbitration agreement and without any abridgment of the powers of the arbitrators, and agree that
such courts shall have exclusive jurisdiction of any such action. 15.12 Advice of Legal Counsel.
Each party acknowledges and represents that, in executing this Agreement, it has had the opportunity
to seek advice as to its legal rights from legal counsel and that the person signing on its behalf
has read and understood all of the terms and provisions of this Agreement. This Agreement shall not
be construed against any party by reason of the drafting or preparation thereof. 8

Source: IMINE CORP, S-1, 7/25/2018
<!-- page 9 -->
IN WITNESS WHEREOF, THE PARTIES HERETO HAVE EXECUTED THIS AGREEMENT AS OF THE DATE FIRST WRITTEN
ABOVE. Sunwai Technology iMine Corporation

/s/ Sei-Peng Tu /s/ Daniel Tsai By: Sei-Peng Tu By: Daniel Tsai Title: President Title: Chief
Executive Officer 9

Source: IMINE CORP, S-1, 7/25/2018
