# Which jurisdiction's law governs the Program Content License Agreement between Phoenix ...

*Question:* Which jurisdiction's law governs the Program Content License Agreement between Phoenix Satellite Television Company Limited and Beijing Tianying Jiuzhou Network Technology Co., Ltd (dated 2009-11-24)?

## Identify agreement and governing law clause

The Program Content License Agreement is dated 2009-11-24 and is between Phoenix Satellite Television Company Limited ("Party A""Phoenix Satellite TV") and Beijing Tianying Jiuzhou Network Technology Co., Ltd ("Party B"). [c346e375d9a9e38b p.1] Article Eleven, Section 11.1 states: "The execution, validity, interpretation, enforcement and dispute resolution of this Agreement shall be governed by the PRC Law.". [c346e375d9a9e38b p.9] Therefore, the law of the People's Republic of China governs the Program Content License Agreement dated 2009-11-24. [c346e375d9a9e38b p.9]

## Verification appendix

Claims: 3 · supported: 3 · partially: 0 · dropped: 0 · gaps: 0 · tier-1 support rate: 1.00

| claim | section | tier 1 | score | sources | note |
|---|---|---|---|---|---|
| s1.1 | s1 | keep | 1.00 | e1→[c346e375d9a9e38b p.1] |  |
| s1.2 | s1 | keep | 1.00 | e2→[c346e375d9a9e38b p.9] |  |
| s1.3 | s1 | keep | 1.00 | e2→[c346e375d9a9e38b p.9] |  |

### Evidence

- e1 [c346e375d9a9e38b p.1 L2-8] keep (1.0): "# Program Content License Agreement
| Field | Value |
|---|---|
| Document Type | License Agreement |
| Agreement Date | 2009-11-24 |
| Parties | Phoenix Satellite Television Company Limited ("Party A""Phoenix Satellite TV"); Beijing Tianyi…"
- e2 [c346e375d9a9e38b p.9 L226-227] keep (1.0): "ARTICLE ELEVEN APPLICABLE LAW; DISPUTE RESOLUTION 11.1 The execution, validity, interpretation, enforcement and dispute resolution of this Agreement shall be governed by the PRC Law."
