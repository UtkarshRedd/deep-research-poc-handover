<!-- page 1 -->
# Distribution Agreement
| Field | Value |
|---|---|
| Document Type | Reseller Agreement |
| Agreement Date | 2004-08-01 |
| Parties | American Express Incentive Services, L.L.C. ("AEIS"); Schoolpop, Inc. ("Schoolpop") |
| Source | CUAD v1 / LOYALTYPOINTINC_11_16_2004-EX-10.2-RESELLER AGREEMENT |

EXHIBIT 10.2

[LOGO AMERICAN EXPRESS] INCENTIVE SERVICES

-------------------------------------------------------------------------------- RESELLER
INFORMATION

Company Name: Schoolpop, Inc. Address:3885 Crestwood Parkway, Suite 550

City: Duluth State: GA Zip: 30096 Contact Name: Paul Robinson Phone: 770-638-5101 Fax: 770-638-5101
TAX ID #: E mail Add: probinson@Schoolpop.com

AMERICAN EXPRESS INCENTIVE SERVICES STORED VALUE PRODUCTS RESELLER AGREEMENT

This Distribution Agreement (the "Agreement") is entered into by and between American Express
Incentive Services, L.L.C., a Missouri limited liability company ("AEIS"), and its Reseller,
Schoolpop, Inc., a Delaware corporation ("Schoolpop"). This Agreement is effective as of August 1,
2004, (the "Effective Date") and shall terminate on July 31, 2009, (the "Termination Date") unless
earlier terminated or extended as provided for herein.

The following points outline this agreement:

1. PURPOSE

Under and subject to the terms of this Agreement:

a. AEIS will provide Schoolpop for resale the following stored value cards: Encompass(R) Select,
Persona(R) Select, Fill It Up(R), and Be My Guest(R), and any other stored value products developed
by AEIS and mutually agreed upon by both parties, ("Cards"). The Cards shall be sold only to those
of Schoolpop's clients and prospective clients (the "Clients"), in the United States who are
nonprofit organizations, ("NPO Marketplace"), which are defined as organizations that are (i) a
school, (ii) an organization formed as not-for-profit under its charter documents, or (iii) an
organization related to (i) or (ii) such as a participating school's Parent Teacher Organization or
other similarly related organization.

b. Period One shall mean the Effective Date through the date that Schoolpop has met all of the
Security Requirements as such term is defined herein and has received approval from AEIS to assume
all Card inventory, distribution and fulfillment responsibilities as currently managed by AEIS.
Period Two shall commence with the end of Period One through the Termination Date.

2. EXCLUSIVITY

a. Schoolpop shall have the exclusive right to resell Cards in the NPO Marketplace. Notwithstanding
the foregoing, Schoolpop shall fund from AEIS a minimum of $52,000,000 of Cards (the "Guaranteed
Minimum") in each Contract Year in order to maintain the exclusive right to sell Cards in the NPO
Marketplace. A Contract Year shall be the period of August 1 through July 31 of the succeeding year.
In any Contract Year in which Schoolpop fails to fund the Guaranteed Minimum, AEIS shall have the
right, in its sole discretion, to (a) terminate the Agreement or (b) revoke the exclusivity.

b. In consideration of the exclusivity referred to above, Schoolpop shall pay AEIS a marketing
rights fee ("Marketing Rights Fee"), of $1,250,000. The Marketing Rights Fee shall be paid in five
(5) equal installments of $250,000 on March 15th of each year with the first such payment being due
on March 15, 2005 and with the final payment due on March 15, 2009.

c. Schoolpop shall also pay AEIS a fee of $250,000, (the "Encompass(R) Select Fee") as consideration
for the right to sell the Encompass(R) Select Card through December 31, 2004. The Encompass(R)
Select Fee shall be payable concurrently with the execution of this Agreement.

d. Schoolpop understands and agrees that this Agreement does not grant Schoolpop any exclusive right
to market the Cards or any other AEIS products and services outside of the NPO Marketplace. AEIS, on
its own behalf, reserves the right to market its Cards and other products and services directly as

1

well as through additional firms on terms and conditions that it selects in its sole discretion,
provided that no such sales shall take place within the NPO Marketplace.
<!-- page 2 -->
3. INVENTORY AND FORECASTING

a. Schoolpop shall secure a physical location for maintaining, distributing, and fulfilling Card
inventory no later than August 1, 2004 which location shall be subject to such security requirements
(the "Security Requirements") as shall be required by AEIS or American Express Travel Related
Services, Inc. all as further set forth in the Trust Agreement attached hereto as Exhibit 1.

b. Schoolpop shall effectively manage its Card inventory and Ordering schedule such that all Cards
are resold and distributed to the Client with the following Card expiration lives (the "Card Life")
intact:

i. Persona(R) Select - nine (9) months ii. Encompass(R) Select, Be My Guest(R), Fill It Up(R) -
three (3) months The Card life of any Cards other than Cards specifically indicated in b(i). and
b(ii) above ("New Cards"), shall be mutually agreed upon in writing.

c. During Period One, Card expiration shall be determined by the date Schoolpop places an Order (the
"Order") and provides full payment and clearance of funding. During Period Two, Card Life shall be
determined by the date Schoolpop places an Order.

d. Should any Card expire or lose Card Life prior to distribution, Schoolpop shall assume all loss
associated with the Card funding, if applicable, and shall pay AEIS a $2.00 per Card destruction
fee. Schoolpop shall not return such Cards to AEIS, and shall follow the destruction process as
detailed in the Trust Agreement.

e. Card Life shall be unaffected by the termination of this Agreement.

f. From the Effective Date through September 30, 2004, Schoolpop may order non-standard Encompass(R)
Select denominations (other than 25, 50, 75, and 100 Points) up to a maximum of 200 Points. Such
non-standard Encompass(R) Select denominations require eight (8) weeks to fulfill and must be
ordered in boxes of 100 Cards of like denominations. Schoolpop shall discontinue reselling
Encompass(R) Select Cards on December 31, 2004 and shall effectively manage and forecast
Encompass(R) Select Card needs to deplete such inventory as of December 31, 2004. In the event that
any unsold Encompass(R) Select Cards remain in inventory by Schoolpop on December 31, 2004,
Schoolpop shall provide to AEIS, no later than January 5, 2005, the Encompass(R) Select Card
numbers, the respective expiration dates and denominations of the Cards. AEIS shall invoice
Schoolpop for the applicable Card destruction fees which shall be payable by Schoolpop within thirty
days (30) of receipt of invoice. Such Card list shall be submitted on a disk/CD and shall be sent
via a form of shipment where signature is required upon delivery.

g. Effective with Period Two, Schoolpop shall provide to AEIS a twelve (12) month sold Card forecast
and Card inventory forecast (hereinafter defined). In addition, Schoolpop shall provide AEIS with a
monthly forecast, no later than the third business day of each month, of the number of Cards to be
sold to its clients, ("Sold Card Forecast") as well as the number of Cards to be stocked in
inventory, ("Card Inventory Forecast"), (collectively referred to as the "Forecasts") for the month,
ninety-days out. For example, Schoolpop shall provide AEIS with the Card Inventory Forecast and Sold
Card Forecast in August for the month of November. The Forecasts will be relied on, ("Locked") at
the time they are reported.

h. Changes to the Forecasts within the Locked period are expected. However, any changes to Locked
Forecasts will not impact any applicable penalties as detailed below in subsections (i) and (j).
AEIS will place reliance on the Forecasts provided by Schoolpop to align resources and ensure
adequate production, fulfillment and customer service capabilities. Schoolpop shall provide AEIS
with any changes to the Locked Forecasts on a monthly basis including any respective changes to
either Forecast for the remaining twelve (12) month period.

i. In any consecutive three (3) month period in which the difference between the Card Inventory
Forecast less the actual Card Order volume for that period is a shortage of ten percent or greater
(10%+), AEIS reserves the right to assess a penalty, ("Card Inventory Penalty") of sixteen and
one-half cents ($0.165) per Card for such difference as detailed in Examples 1 and 2 below.

---------------------------------------------------------------------------------------------
EXAMPLE 1 --------------- --------------------- ------------------ ------------------
----------------- FORECAST PERIOD ACTUAL VOLUME FORECASTED VOLUME DIFFERENCE ---------------
--------------------- ------------------ ------------------ -----------------
<!-- page 3 -->
MONTH 1 10/1/04-10/31/04 8,000 10,000 (2,000) 20% --------------- ---------------------
------------------ ------------------ ----------------- MONTH 2 11/1/04-11/30/04 8,500 10,000
(1,500) 15% --------------- --------------------- ------------------ ------------------
----------------- MONTH 3 12/01/04-12/31/04 8750 10,000 (1,250) 12.5%
------------------------------------------------------- -------------------------------------
PENALTY 4,750 X $0.165 = $783.75
---------------------------------------------------------------------------------------------

2

---------------------------------------------------------------------------------------------
EXAMPLE 2 --------------- --------------------- ----------------- -------------------
----------------- MONTH 1 12/1/04-12/31/04 10,500 11,000 (500) 4.5% ---------------
--------------------- ----------------- ------------------- ----------------- MONTH 2 1/1/05-1/31/05
10,000 13,000 (3,000) 23% --------------- --------------------- -----------------
------------------- ----------------- MONTH 3 02/01/05-02/28/05 12,000 12,500 (500) 4%
------------------------------------------------------- -------------------------------------
PENALTY NO PENALTY -------------------------------------------------------
-------------------------------------

j. In any given month where the difference between the Sold Card Forecast less the actual Card
activation volume, ("Cards in Force") is a shortage of ten percent or greater (10%+), AEIS reserves
the right to assess a penalty, the ("Customer Service Penalty") which shall be calculated by
converting Cards in Force into call volume minutes as follows:

i. Cards in Force times the call to card ratio times the average handle time equals the total call
volume minutes. AEIS will calculate the respective product's average year-to-date call to Card ratio
and the average year-to-date handle time monthly to calculate the call volume minutes. For purposes
of example, the year-to-date through August 2004, Encompass(R) Select average call to Card ratio is
2.43 and the average handle time is 4.0 minutes.

&sbsp; ii. Actual call volume minutes under 90% of the Card Sold Forecast will be charged at 90% of
Locked Rolling Forecast at the standard rate of $0.50 per minute. Schoolpop's Customer Service
Penalty shall be calculated at the difference between actual call volume minutes and 90% of Card
Sold Forecast call volume minutes.

iii. The Customer Service Penalty shall be calculated based upon the a) call volume minutes plus b)
Cards in Force as detailed in the example below:

-------------- ------------------- ----------------- -----------------
-------------------------------- FORECASTED CARDS CALL TO CARD TOTAL CARDS AVERAGE HANDLING TIME IN
FORCE RATIO -------------- ------------------- ----------------- -----------------
-------------------------------- MONTH 1 10,500 2.43 255 4.00 minutes
-------------------------------------------------------------------------------------------------------
(10,500 x 2.43 = 255) x 4.00 minutes = 1020 Call Volume Minutes
-------------------------------------------------------------------------------------------------------
ACTUAL CARDS IN CALL TO CARD TOTAL CARDS AVERAGE HANDLING TIME FORCE RATIO --------------
------------------- ----------------- ----------------- -------------------------------- MONTH 1
5,000 2.43 121 4.00 minutes
-------------------------------------------------------------------------------------------------------
(5,000 x 2.43 = 121) x 4.00 minutes = 486 Call Volume Minutes
-------------------------------------------------------------------------------------------------------
PENALTY: 90% x 1020 = 918, (918-486 = 432) x $.50 = $216 Total Penalty for the Month
-------------------------------------------------------------------------------------------------------

l. Schoolpop shall pay AEIS all incurred penalties within thirty (30) days of receipt of invoice for
such penalties by AEIS.

m. At any given time during this Agreement, Schoolpop's inactive Card inventory shall be limited to
$3,000,000 in Card value as determined by the Point denomination on each Card. This limit &sbsp;
shall consist of a maximum Card value of $1,500,000 in Encompass(R) Select Cards and $1,500,000 Card
value in any other product (s). Effective January 1, 2005, after which Encompass(R) Select shall no
longer be available to Schoolpop, the maximum inactive Card value shall not exceed $3,000,000 in any
combination of products at any given time. In the event that Schoolpop exceeds either of these
limits, AEIS shall cease fulfilling Orders from Schoolpop until such time that Schoolpop's inventory
returns to an acceptable level based on the established maximums.
<!-- page 4 -->
n. Any New Cards shall be excluded from the forecasting and penalty provisions of this Section 3 for
the three (3) month period commencing on the date of the first order of such New Cards.

4. CARD ISSUANCE

a. Schoolpop agrees that it will review all requests for each Program requested by the Client and
will use reasonable and customary business practices to qualify and recommend Clients proposed for a
Program. Schoolpop shall take commercially reasonable efforts to ensure all information requested
for a Client is true, accurate and correct.

b. AEIS may, from time to time, provide Schoolpop with commercially reasonable qualification
standards for Clients. Schoolpop shall not knowingly submit an Order to AEIS on behalf of any Client
that does not meet any such standards. Schoolpop agrees that it will sell Cards only to Clients and
only for use in connection with a bona fide fund raising program. Schoolpop will not knowingly sell
Cards to any Client who does not meet any AEIS qualification standard(s) or to any

3

Client or potential Client that Schoolpop has reason to believe would be unsatisfactory to AEIS.

c. AEIS reserves the right at any time, with or without cause, with reasonable written notice to
Schoolpop, to cancel or decline any Client's participation in the Program.

d. AEIS may, at its sole discretion, decline to provide Cards to Clients.

e. Cards are intended for use in the United States and must be designated for receipt of shipment
within the United States.

f. AEIS' designated vendor will be responsible for shipping Cards in accordance with Schoolpop's
instructions.

g. AEIS's designated vendor will ship the Cards as follows:

i. During Period One, AEIS' designated vendor will use reasonable commercial efforts to ship the
Cards as detailed below, following receipt and clearance by AEIS of Card Funding.

ii. During Period Two, AEIS' designated vendor will use reasonable commercial efforts to ship the
Cards as detailed below, following receipt of Card Order placed by Schoolpop.

The initial Order of (a) standard non-branded Cards within 5 business days after set-up; subsequent
Orders, (b) of less than 5,000 Cards per day within three (3) to five (5) business days of receipt
of Order; (c) forecasted Orders of 5,000 or more Cards per day within eight (8) to thirteen (13)
business days of receipt of Order; and (d) non-forecasted Orders of 5,000 or more Cards per day
within twenty (20) to thirty (30) business days of receipt of Order. All shipment timelines are
subject to change without notice due to seasonal or unforecasted production volume and AEIS shall
work with its Card production vendor and use reasonable commercial efforts to secure the most
favorable shipment date commitment and shall notify Schoolpop accordingly.

h. One point is worth one (1) U.S. Dollar ($1.00 USD) ("Point").

i. AEIS shall ship Cards in bulk shipment via its designated vendor to Schoolpop, F.O.B. Atlanta,
Georgia. Schoolpop shall distribute to each Cardholder the Cardholder agreement as provided with
each Card and which includes instructions on "How to Use the Card". Should Schoolpop or its Client
distribute Cards without such Cardholder agreement, Schoolpop shall indemnify and hold harmless
AEIS, its parents, subsidiaries and their respective affiliates, officers, directors, employees and
agents, against any and all Loss, hereinafter defined, that AEIS may incur or be subjected to as a
result of such action, including, without limitation, any claims brought by any entity including but
not limited to governmental entities and Cardholders.

j. Purchases made with a Card having insufficient Points will be deemed a deniable transaction. The
correct way to handle the purchase is described in the Cardholder agreement. If there is a purchase
made on a Card where there are insufficient Points on the Card, the negative amount will be the
responsibility of the person whose signature appears on the Card, as described in the Cardholder
agreement.
<!-- page 5 -->
k. CARDS LOST OR STOLEN IN TRANSIT IN THE INITIAL SHIPMENT FROM AEIS WILL BE THE RESPONSIBILITY OF
AEIS. The full risk of loss for ordered Cards shall pass to Schoolpop immediately upon their
delivery to Schoolpop by AEIS and AEIS shall not reimburse Schoolpop or Client for any delivered
Card that is lost, stolen, misappropriated, or that otherwise disappears or is fraudulently or
inappropriately used (together referred to as "Loss"). Schoolpop shall remain solely liable for any
Loss caused by the negligence or willful misconduct of its employees, agents or representatives
after the shipment has been received by Schoolpop. AEIS will not reimburse Schoolpop or its Client
or be responsible for any Loss in connection with or after delivery of Cards to Schoolpop, its
Clients or the Cardholder whether they are shipped to Schoolpop, its Client, or to either of their
pre-designated delivery agents. Only Cardholders are eligible to receive replacements from AEIS and
replacements are given only in accordance with the agreement between the Cardholder and AEIS. Cards
are usually shipped in packaging with AEIS' designated vendor as the return address. Notwithstanding
the foregoing, AEIS shall bear no risk of Loss and of non-receipt of Cards by the intended
Cardholder in the event that AEIS is instructed to use another address as the return address, the
address provided to AEIS for Schoolpop or the Client was incorrect, the request for the Card was
unauthorized, and/or any information received by AEIS with regard to the processing of the Order was
fraudulent or incorrect.

l. All agreements entered into between Schoolpop and its Clients, shall contain a provision
substantially similar to the preceding Section 3 (k).

4

m. During the term hereof, Schoolpop shall maintain at all times the following information with
respect to Card resale and distribution to Client:

i. For each box of Cards, or partial thereof, sent from AEIS's designated vendor to Schoolpop, the
UPS(TM) Tracking number appearing on the shipping label of the box and the respective Card numbers
for the Cards contained in the box (AEIS's shipping vendor shall include a list of Card numbers
within each box.), and

ii. The Client name and delivery date of each box of Cards or partial thereof, sent from Schoolpop
via their designated shipping vendor, to the Client, including proof of signature and tracking
number for the box, specific to Schoolpop's shipping vendor.

n. Schoolpop shall comply with all applicable Federal, State and local laws concerning the use of
Cards, including anti-money laundering and anti-terrorism laws, and currency control regulations.
Schoolpop warrants it shall take measures to track information about its Clients which shall meet
compliance requirements related to the above stated laws, track all Card shipment(s) to each such
Client, and maintain appropriate records for its Clients for a period of seven (7) years after
termination of the Agreement and to provide such records and other information to AEIS upon
reasonable request and subject to applicable law. Schoolpop shall further inform in writing all of
its Clients of their requirement to comply with all applicable laws concerning the use of Cards,
including those laws stated in the previous sentence. School shall inform its Clients of the
requirement to maintain records with respect to the Cards and Cardholders, and to verify the
identity of Cardholders as required by law, to maintain records of the information used to verify
each Cardholder's identity, to retain such records for at least seven (7) years following the date
of distribution, including &sbsp; name, home address, Card number, and other identifying
information, and the name, title and phone number of the individual responsible for maintaining such
records, and to provide such records and other information to AEIS upon reasonable request and
subject to applicable law. Schoolpop and Schoolpop's Clients shall establish and maintain an
anti-money laundering program with an assigned compliance officer and compliance program. Details of
such shall be provided to AEIS upon request. Schoolpop and Schoolpop's Clients shall not accept
cash, coin or currency in exchange for Cards. Schoolpop shall indemnify and hold harmless AEIS its
parents, subsidiaries and their respective affiliates, officers, directors, employees and agents,
against any and all Loss that AEIS may incur or be subjected to as a result of or arising out of
Schoolpop's failure to comply with such laws and regulations, including, without limitation, any
Loss resulting from any claims brought by any entity including but not limited to governmental
entities, unless due to the acts or omissions of AEIS. AEIS reserves the right, at its sole
discretion, to monitor and enforce Schoolpop's compliance with all applicable laws and regulations,
including but not limited to those contained in this Section 3 (n). Schoolpop shall monitor and use
reasonable commercial efforts to enforce its
<!-- page 6 -->
Clients' compliance with all applicable laws and regulations including, but not limited to those
contained in this Section 3 (n). All agreements entered into between Schoolpop and its Clients shall
contain a provision substantially similar to this Section 3 (n).

o. Schoolpop agrees that it will indemnify and hold AEIS harmless for any claims or losses resulting
from its failure to comply with the requirements of Sections 4 (k), (m-n), unless due to the acts or
omissions of AEIS.

p. AEIS will not hold Schoolpop responsible for or seek to collect from Schoolpop any Loss caused by
or resulting from any Cardholder's fraud, misuse, or negative balance transactions involving the
Cards except to the extent such Loss was caused by Schoolpop's breach of a representation, warranty,
or covenant of this Agreement or if Schoolpop (or Schoolpop's employees, agents or representatives)
participated in or had knowledge of any deceptive, fraudulent or other illegal activity.

q. Schoolpop acknowledges that Points must be used prior to the expiration date of the Cards. No
refund will be made with respect to Points remaining on Cards at the time of expiration to
Schoolpop, its Clients or the Cardholders, subject to applicable law. Schoolpop further acknowledges
the Cardholder Agreement contains such notice to Cardholders.

5. PAYMENT INSTRUCTIONS

a. Effective Period One, Schoolpop shall provide full payment of Card funding via wire transfer for
Orders placed through the end of Period One. AEIS shall fulfill such Orders upon receipt and
clearance of funds.

b. Effective Period Two, Schoolpop shall provide the full payment of Card funding via ACH Debit at
the time Schoolpop requests activation of Cards. AEIS shall activate the Cards by loading the
appropriate number of Points onto the Cards as determined by the denomination, and at which time the
Cards shall be ready for use by Cardholders within two (2) business days.

5

c. Schoolpop shall pay AEIS $25.00 each time a wire transfer is used for amounts under $5,000.

d. The Schoolpop account number as detailed on Exhibit 3, attached hereto, must be on each form of
payment along with the amount of funding to be applied to each account number. Failure to provide
AEIS with this account number and funding detail may result in a delay in Funding.

e. Schoolpop shall pay AEIS $15.00 for each returned ACH Debit payment.

f. All instruments bearing funds for Cards should be made payable to American Express Incentive
Services, L.L.C. AEIS' required payment method is in U.S. currency. AEIS reserves the right to
decline payment made in any other currency.

g. The following instructions should be used for Electronic Settlements to AEIS:

American Express Incentive Services c/o Bank of America Dallas, TX Routing/ABA #111000012 Account
#375-100-6936 Reference: XXXX (Client Name and Account #)

All invoices for Schoolpop should be sent to the following address:

Schoolpop, Inc. Attn: Paul Robinson Address: 3885 Crestwood Parkway, Suite 550 City, State, Zip:
Duluth, GA 30096 Phone #: 770-638-5101 Fax #: 770-678-3334 Email address: probinson@Schoolpop.com

Schoolpop agrees to notify AEIS promptly in the event the address or contact for invoice submission
changes.

6. ORDERING INSTRUCTIONS

a. Effective Period One, Schoolpop's designated contact shall place Orders by submitting data in an
electronic document via email to AEIS.

b. Schoolpop will be assigned a user name and password that will be used for identification when
placing Orders using easyorder(TM). Schoolpop authorizes AEIS to accept and process Orders from
anyone using Schoolpop's password. AEIS will have
<!-- page 7 -->
no obligation or responsibility for verifying the identity of anyone using Schoolpop's password.
Schoolpop shall have the responsibility of safeguarding Schoolpop's password and should not reveal
its password to anyone. AEIS will not ask Schoolpop in an unsolicited telephone call or email for
its password. In addition, Schoolpop should take precautions when using a computer that is not its
own or in a public setting. If Schoolpop suspects that someone else may have had access to its
password, Schoolpop shall notify AEIS immediately.

c. Effective with Period Two, the following ordering terms and conditions apply:

i. Schoolpop shall order Cards in increments of 100 per box and shall not place Orders for any
partial box (es) of 100, nor request any partial activation of any box (es).

ii. Cards within each box shall be of the same product and Point value. AEIS shall not mix products
and/or Point values within any single box.

iii. Upon receipt of Cards, Schoolpop shall confirm receipt of such Cards as detailed in the Trust
Agreement.

iv. AEIS shall use commercially reasonable efforts to activate each full box of Cards within two (2)
&sbsp; business days upon receipt of the UPS(TM) Tracking number (used by AEIS's designated shipping
vendor) for the box of Cards from Schoolpop along with the receipt and clearance of Card funding for
the box of Cards.

v. Once activated, all Cards become the property of Schoolpop, excluding all Marks as detailed in
Section 8, and further defined within the Trust Agreement.

vi. Activation terms for New Cards shall follow the process established for existing Cards.

6

7. PROGRAM COMMUNICATIONS

a. All rights to the name, logo, service marks and/or trademarks (the "Marks"), trade names, tag
lines, or any other proprietary designation ("Proprietary Designation") of AEIS remains the sole
property of AEIS. Certain use of the Marks and Proprietary Designation of American Express Travel
Related Services Company and Maritz Inc. has been granted to AEIS under license agreements. It is
understood that the Marks may be necessary to enhance the impact and clarity of Program
communications. All use of Marks and Proprietary Designations of AEIS, American Express and Maritz
Inc. requires prior written approval from AEIS and use of the Marks shall follow and be subject to
requirements issued by AEIS and attached hereto as Exhibit 4 and 4.A and 4.B, including any such
Marks used by Schoolpop's Clients.

b. Camera-ready artwork is available from AEIS for inclusion of the AEIS logo or to display a
picture of a Card in Program communications. Requests for camera-ready artwork should be directed to
the address below.

c. Schoolpop shall inform AEIS in writing, and obtain prior written consent (which consent shall not
be unreasonably withheld), for any and all television, radio, newspaper, magazine, Internet,
Intranet, or other advertising, promotional or marketing campaign or strategy using the Marks or
when referring directly to American Express Travel Related Services Company, Maritz Inc. or AEIS or
any American Express merchant.

d. Schoolpop is solely responsible for ensuring that any names and/or logos, designs, pictures or
other intellectual property, which are provided by Schoolpop to be used in the Program (including
collateral material), does not infringe or violate the intellectual property rights of any other
party and shall indemnify AEIS from any and all claims made by any third party respecting such
infringement.

e. Schoolpop shall discontinue its use and shall notify its Clients to discontinue use of the Marks,
including all American Express merchant marks, and all associated promotions, including but not
limited to Client promotions, upon termination of this Agreement.

f. Schoolpop, at its option, may request that AEIS include in the shipment of Cards, Program
specific collateral materials. Program specific collateral materials are subject to review and
approval by AEIS and additional charges may apply.

g. AEIS retains the right to immediately terminate this Agreement should Schoolpop distribute any
promotional materials or
<!-- page 8 -->
communications that are not approved by AEIS and/or do not meet AEIS' branding guidelines, including
American Express merchant marks.

h. Schoolpop shall send all materials for review to:

Branding and Product Communications Specialist American Express Incentive Services, L.L.C. 1309 N.
Highway Drive Fenton, MO 63099 Tel: 636-226-2071 Fax: 636-226-2002 AEIS shall review all submissions
within seven (7) business days.

8. JOINT MARKETING AND COMMUNICATIONS

a. AEIS shall provide standard Card plastic design and standard Card carrier design including
pre-printed paper and electronic copy, and standard Card envelope design for all Card packaging
(collectively "Card Packaging"). In the event Schoolpop or its Clients request any non-standard Card
plastic design or Card Packaging, AEIS and Schoolpop shall mutually agree upon such materials. AEIS
shall provide to Schoolpop pricing for non-standard materials

b. AEIS shall provide standard promotional materials, and communication to provide market exposure
for Cards. In the event Schoolpop or its Clients request any non-standard promotional or
communication materials, AEIS and Schoolpop shall mutually agree upon such materials. AEIS shall
provide to Schoolpop pricing for non-standard materials, which may or may not include Cardholder
website customization.

c. AEIS and Schoolpop shall mutually develop, market, and implement two (2) new Cards for Program
use no later than October 1, 2004 as follows:

i. A category Card, where AEIS shall put forth a commercially reasonable effort to secure contracts
with a select group of merchants to participate in the Card program as identified on Exhibit 5,
attached hereto, and to make changes to such categories and/or merchants.

7

ii. A grocery Card, where AEIS shall put forth a commercially reasonable effort to secure contracts
with a select group of merchants leveraging Schoolpop's existing relationships with grocery store
companies, as identified on Exhibit 5.A, attached hereto, and to add other merchants as mutually
agreed upon by both parties.

iii. AEIS shall communicate and maintain participating merchants in the category and grocery Cards
through the Card website, an Interactive Voice Response fax-back service listing of current
merchants, and through a merchant listing that shall accompany each Card.

iv. AEIS and Schoolpop mutually agree to pursue additional Card products, as market conditions
warrant, for use in the NPO marketplace and shall document such products in a separate Agreement.

d. The parties agree that the minimum number required for the category Card shall be not less than
70% of the consumer categories contained within Exhibit 5; and the grocery Card not less than 70%
national coverage to launch each respectively. The parties shall mutually agree upon any New Card
minimum numbers required for each&sbsp;New Card launch.

9. PROGRAM TERMS

a. From the Effective Date through September 30, 2004, Schoolpop may order non-standard Encompass(R)
Select denominations (other than 25, 50, 75, and 100 Points) up to a maximum of 200 Points. Such
non-standard Encompass(R) Select denominations require eight (8) weeks to fulfill and must be
ordered in boxes of 100 Cards of like denominations. Schoolpop shall be limited to $26,500,000 in
total Encompass(R) Select sales through December 31, 2004. Such limit may be increased in the event
Persona Select actual sales exceed its forecasted sales for the period ending December 31, 2004. The
limit increase shall be calculated on three-to-one ratio of Encompass Select sales to Persona Select
Sales. Schoolpop shall discontinue reselling Encompass(R) Select Cards on December 31, 2004 and
shall effectively manage and forecast Encompass(R) Select Card needs to deplete such inventory as of
December 31, 2004. In the event that any unsold Encompass Select Cards remain in inventory by
Schoolpop on December 31, 2004, Schoolpop shall provide to AEIS, no later than January 5, 2005, the
<!-- page 9 -->
Encompass(R) Select Card numbers, the respective expiration dates and denominations of the Cards.
Such Card list shall be provided to AEIS by Schoolpop via disk/CD and sent via a form of shipment
where signature is required upon delivery. AEIS shall invoice Schoolpop for applicable destruction
fees of $2.00 per Card which shall be payable by Schoolpop within thirty (30) days upon receipt of
invoice.

b. Cards shall not be used to purchase gift certificates and/or gift cards at participating
merchants.

c. Schoolpop acknowledges it will be listed as a current Client of AEIS. Schoolpop agrees to be used
as a reference to current and future AEIS Clients with prior approval from Schoolpop.

d. Schoolpop agrees to an annual review to take place forty-five (45 days) prior to each contract
anniversary, on or about June 15th of each contract year. This review will include, but is not
limited to, a review of volume performance, economics of the products, and branding.

e. Schoolpop agrees to product and program training as required by AEIS.

f. The parties agree to jointly develop a Cardholder appeasement &bbsp; program. Such appeasement
program shall require Schoolpop develop a process with its Clients to mutually resolve Cardholder
appeasement issues prior to raising them with any third party(ies).

g. AEIS may from time to time provide Schoolpop with certain reasonable terms and provisions to be
included in the agreements to be entered into between Schoolpop and its Clients and Schoolpop agrees
that any such terms and provisions shall be included in such agreements.

10. PROGRAM SERVICING

a. AEIS will provide:

i. 24-hour customer service representation, via a 24x7 English speaking toll-free telephone number,
for Program Cardholders who have questions concerning a Card. The toll-free numbers as of the
drafting of this Agreement are:

Persona(R) Select 800-259-9526 Encompass(R) Select 888-210-9821 Fill It Up(R) 800-575-7365 Be My
Guest(R) 877-243-5082

8

ii. Cardholders with the ability to obtain point balance information through the following
Cardholder Web sites:

www.personaselect.com Persona(R) Select www.encompass-select.com Encompass(R) Select
www.rewardearner.com/fillitup Fill It Up(R) www.rewardearner.com/bmg Be My Guest(R)

iii. Merchant Management - includes the management of the authorization network, merchant settlement
and dispute handling, and

iv. AEIS will provide reasonable assistance to Schoolpop in managing the Program as needed and
requested by Schoolpop. Additional charges may apply.

v. AEIS and Schoolpop shall mutually agree upon a Client and/or Cardholder appeasement process and
the respective financial responsibility.

b. AEIS reserves the right to change program servicing from time to time.

11. REPRESENTATIONS AND WARRANTIES

a. Schoolpop and AEIS each represents and warrants that participation in the Program shall at all
times conform to the highest standards of business ethics and practices and at no time will they
permit any act to be done by their employees or representatives that will damage the name,
reputation or goodwill of the other party or its affiliated companies.

b. Schoolpop and AEIS each further represents and warrants that its participation in the Program is
and will remain during the term of this Agreement in compliance with all laws, rules and regulations
applicable to it.

c. Schoolpop and AEIS each further represents and warrants that they are authorized to enter into
this Agreement and that this Agreement does not violate any other agreement to which it is a party.
<!-- page 10 -->
12. CONFIDENTIALITY

a. The terms, procedures, any applicable criteria for success and results of this Agreement and all
information furnished by and between the parties in connection with this Agreement shall be
confidential and shall not be disclosed by either party without the express written consent of the
other party; provided that Schoolpop shall have the right to disclose such information as may be
required to comply with applicable SEC regulations.

b. Both parties acknowledge that they may have access to or receive confidential information, data,
and materials about the other party, their Clients and Cardholders, and their entities, including,
without limitation, marketing philosophies and objectives, pricing information, business materials
and data, processes, customer lists, product information, financial data, competitive advantages and
disadvantages, and other confidential information received ("Confidential Information"), and that
disclosure or misuses of such Confidential Information, would be irreparably damaging to the other
party. Accordingly, both parties agree to receive and hold in confidence all Confidential
Information considered proprietary or confidential by the other party, and &sbsp; agree not to
disclose or use such information in any manner except for uses contemplated by this Agreement unless
permitted in writing in advance by the other party (except for information disclosed to Cardholders
in accordance with the Cardholder Agreement). Both parties also agree to bind their employees, and
subcontractors to compliance with this paragraph and to take all other reasonable action to ensure
protection of the Confidential Information.

c. Such Confidential Information is subject to the terms and conditions of this Agreement, if (a)
such Confidential Information is either Party's marketing philosophies and objectives, financial and
pricing information, Client lists, business processes or competitive advantages and disadvantages;
(b) such Confidential Information is disclosed verbally and is verbally identified as proprietary or
confidential at the time of disclosure, and there exists a written record that such Confidential
Information was disclosed and identified verbally as proprietary or confidential; or (c) such
Confidential Information is in written, graphic or electronic form when disclosed and the media that
contains such Confidential Information is clearly marked "confidential" or "proprietary", or
something substantially similar. Notwithstanding the foregoing, Confidential Information shall not
include (d) information that is publicly known, already known by, or in the possession of the
non-disclosing party, or (e) is independently developed by the non-disclosing party without use or
reference to the other party's Confidential Information, or (f) is rightly

9

obtained by the non-disclosing party from a source other than the disclosing party without such
restrictions.

d. Each party agrees that during the term of this Agreement and thereafter (a) it will use
Confidential Information belonging to the other party solely for purposes outlined in this
Agreement, (subject to the terms and conditions thereof), (b) it will not disclose Confidential
Information belonging to the other Party to any third party other than the receiving Party's
employees, affiliates, agents, permitted vendors, subcontractors and/or professional advisors on a
need-to-know basis who are advised of the confidential nature of the Confidential Information and
under a similar confidentiality agreement, and (c) each Party will treat the Confidential
Information of the other Party with the same care that the receiving party normally affords its own
proprietary and confidential information. If any such employee, affiliate, agent, subcontractor or
professional advisor discloses or uses the Confidential Information in a manner not permitted under
this Agreement, the party disclosing the Confidential Information to such employee, affiliate,
agent, subcontractor or professional advisor will be liable therefore. If either party is required
by law to disclose Confidential Information, it may be disclosed, provided that, unless prohibited,
sufficient prior notice is given to the non-disclosing party to afford it an opportunity to take
whatever steps it deems necessary to protect the confidential nature of the Confidential
Information. In the event a party is required to disclose the other party's Confidential Information
in connection with any judicial proceeding or government investigation, a notification of such
requirement shall promptly occur allowing a reasonable time for the appropriate party to seek a
protective Order from the appropriate court or government agency. Thereafter, Confidential
Information may be disclosed to the extent required by law, subject to any applicable protective
Order.

e. Upon request of the other party, each party will promptly
<!-- page 11 -->
return to the other any or all Confidential Information of the other then in its possession or under
its control provided, however, that each party may retain one copy of all such Confidential
Information solely for its own internal records, such Confidential Information to remain subject to
the restrictions on use and disclosure contained in this Agreement

f. Authorized users, ("Authorized Users") include Schoolpop, its affiliates and its Client's
personnel involved in administering the Program and eligible Cardholders of a Schoolpop Program.
Schoolpop acknowledges that it will likely receive private information ("PI") from Authorized Users
that will be subject to various privacy laws and regulations in the various States in which the
Authorized Users and the parties hereto reside. Furthermore, Schoolpop, and/or its Client, will
likely be providing such PI to AEIS for identification of such Authorized Users. Schoolpop shall,
and shall cause its Client to, (a) comply with all applicable privacy laws and regulations, (b)
shall provide to AEIS evidence of such compliance upon request, (c) and shall obtain such
permissions, clearances, or other allowances as shall be necessary for AEIS to use such PI as
contemplated hereunder. Schoolpop shall, and shall cause its Client to, (d) cooperate with AEIS with
respect to complying and avoiding any claims based on PI rights of others including without
limitation Schoolpop and/or its Client communicating to AEIS all necessary acts and safeguards
required of AEIS in handling PI, (e) providing such notices and information to Authorized Users as
required, (f) identifying all PI as PI at the time of its transmission to AEIS, (g) segregating any
PI required to be handled differently as necessary to ensure its proper treatment including without
limitation not providing PI to AEIS and, if applicable, (h) PI that has been "opted out" of
Schoolpop's or its Client's permission for use hereunder. Schoolpop and its Client shall
respectively bear the cost of compliance with all privacy laws and regulations. Schoolpop will, at
its sole cost and expense, defend, indemnify and hold harmless AEIS and each of its respective
officers, directors, employees, agents, contractors, affiliates, service providers and insurers
(collectively, "AEIS Indemnified Parties") from and against any and all loss or liability, claims,
demands, damages, losses and expenses including, without limitation, reasonable attorneys,
accountants and expert witness fees, costs and expenses that the AEIS Indemnified Parties, or any
one or more of them, may sustain or incur as a result of a claim of violation of any law or
regulation or personal right directed to protecting the PI rights of individuals or the use, misuse,
collection, loss of privacy or confidentiality, or other mishandling or improper or illegal act with
respect to such PI including without limitation governmental enforcement action as well as civil
claims involved with any such Schoolpop Program. Excluded from the obligation to defend and
indemnify shall be any claims or damages attributable &bbsp; solely to the negligence or intentional
misconduct of any AEIS Indemnified Party, and solely as to that AEIS Indemnified Party to which such
negligence or intentional misconduct is attributable. The obligations under this Section 12 shall
survive the termination, cancellation, and expiration of this Agreement.

10

13. INSURANCE

a. Schoolpop shall, during the term of this Agreement, at its own cost and expense, procure with
sound and reputable insurers, the following insurance coverage's: (i) Workers' Compensation
Insurance in an amount not less than the statutory limits for the state(s), country or province in
where the services are to be performed; (ii) Employer's Liability Insurance not less than (a)
$100,000 per occurrence, and not less than $100,000 aggregate limit of liability per policy year for
disease, including death at any time resulting therefrom, not caused by accident or (b) such amount
as required by law, whichever is higher; (iii) Comprehensive General Liability Insurance, including
blanket extended coverage against all hazards, including personal injury and death resulting
therefrom, for not less than $1,000,000 per occurrence, and not less than $2,000,000 aggregate; (iv)
Automobile Liability insurance against liability arising from the maintenance or use of all owned,
non-owned and hired automobiles and trucks used to provide services, with (a) a minimum limit of
liability for bodily injury of $1,000,000 in the aggregate, and with a minimum limit of liability
for property damage of $500,000 per accident, or (b) amount as required by law, whichever is higher;
and (v) fidelity or crime policy of not less than $3,000,000 in the aggregate against
misappropriation and/or destruction of Cards.

b. Schoolpop's insurance shall be deemed primary. Schoolpop shall provide AEIS with certificates of
insurance evidencing the coverage's required hereunder within fifteen (15) days after
<!-- page 12 -->
execution of this Agreement. Each policy required hereunder shall provide that AEIS shall receive
thirty (30) days advance written notice in the event of a cancellation or material change in such
policy. Each policy of insurance which Schoolpop is required to possess under this Agreement shall
name AEIS, and its Directors, Officers, and Employees, as additional insured in the insurance policy
limits herein required. In the event that any service under this Agreement is to be rendered by
persons other than Schoolpop's employees, Schoolpop shall furnish AEIS with evidence of insurance
for such persons subject to the same terms and conditions as set forth above and applicable to
Schoolpop prior to commencement of service by such person(s).

14. GENERAL TERMS & CONDITIONS

a. This Agreement along with the Trust Agreement constitute the entire Agreement between the parties
hereto and supersedes all prior communications and agreements between the parties with respect to
the subject matter hereof. Except for changes in AEIS product rules and other procedural or
operational changes in terms initiated by AEIS as described herein, this Agreement may not be
modified or otherwise amended except by a further writing executed by both parties hereto, which
writing makes specific reference to this Agreement.

b. No right or interest in this Agreement shall be assigned by Schoolpop without prior written
permission of AEIS, which shall not be unreasonably withheld.

c. This Agreement shall be deemed to have been made and executed in the State of Missouri and any
dispute arising thereunder shall be resolved in accordance with the laws of the State of Missouri,
without reference to its rules governing conflicts of law.

d. Either party may terminate this Agreement with written notice to the other party as follows:

i. Should either party (1) admit in writing its inability to pay its debts generally as they become
due; (2) make a general assignment for the benefit of creditors; (3) institute proceedings to be
adjudicated a voluntary bankrupt; (4) consent to the filing of a petition or bankruptcy against it;
(5) be adjudicated by a court of competent jurisdiction as being bankrupt or insolvent; (6) seek
reorganization under any bankruptcy act; (7) consent to the filing of a petition seeking such
reorganization; or (8) have a decree entered against it by a court of competent jurisdiction
appointing a receiver, liquidator, trustee, or assignee in bankruptcy or in insolvency covering all
or substantially all of such party's property or providing for the liquidation of such party's
property or business affairs; then, in any such event, the other party, at its option and without
prior notice, may terminate this Agreement effective immediately; or

ii. Upon the occurrence of a breach by the other party, which breach has not been cured within (30)
days after the date of written notice to the breaching party by the non-breaching party; or

iii. For non-payment of any amounts due hereunder. In the event this Agreement is terminated for any
reason prior to May 31, 2009, all unpaid Marketing Rights Fees incurred to the termination date,
will be fully due and payable by Schoolpop to AEIS. Upon termination, each party will return to the
other or destroy, and provide written certification of destruction of, all information furnished by
such other party hereunder, prior to termination and follow necessary termination instructions
detailed in the Trust Agreement. All Cards ordered by Schoolpop and supplied by AEIS shall be
governed by the terms and conditions of this Agreement and the Trust Agreement.

11

e. Notwithstanding anything contained herein to the contrary, the cumulative liability of the
parties to one another for any claims, liabilities, losses, damages or expenses, direct or indirect,
arising out of or related to this Agreement shall not exceed the lesser of $50,000 or (not including
other funding amounts such as the Point value of Cards) or the amount paid by Schoolpop to AEIS for
the immediately preceding twelve (12) months provided, however, that in no event shall this
limitation of liability apply to any claims, liabilities, losses, damages, or expenses, direct or
indirect, arising out of or related to this Agreement brought by the actions of Schoolpop pursuant
to paragraphs 4(e), 4(i), 4(k), 4(p), 5(a), 5(b), 6(b), 7(a), 7(d), 14(d.iii), 9(f) and Sections 2,
3 11, 12, and 13, and Exhibit 1 of this Agreement. In no event shall
<!-- page 13 -->
either party be liable to the other, under any theory, for lost profits, exemplary, punitive,
special incidental, indirect, or consequential damages.

f. In the event that either party breaches or violates any covenant or agreement contained in this
Agreement, or in the event of any breach or violation (or alleged breach or violation) of any
covenants or agreement made by LoyaltyPoint with any Client or other third party, the breaching
party shall indemnify and hold harmless the other party, its affiliates, parent company(ies),
officers, directors, employees, and agents against and in respect of any and all costs, expenses,
deficiencies, litigation, proceedings, taxes, levies, assessments, attorneys' fees, damages or
judgments of any kind or nature whatsoever, related to, arising from, or associated with such breach
or violation (or alleged breach of violation). The non-breaching party shall give the breaching
party prompt notice of the non-breaching party's intention to make a claim for indemnification
hereunder. the breaching party shall have the opportunity to defend the underlying claims, suit or
proceeding by competent counsel of its own choosing, provided that non-breaching party has approved
such counsel, which approval shall not be unreasonably withheld. The non-breaching party shall
cooperate in the defense of such claim, suit or proceeding. The obligations under this Section 14
shall survive the termination, cancellation, and expiration of this Agreement.

g. Any notice required or permitted under this Agreement will be effective if in writing and
delivered personally, sent by certified U.S. Mail, return receipt requested, postage prepared, sent
by a national overnight delivery service (such as Federal Express), or sent by telefax, in each
instance addressed and delivered personally or sent for delivery as provided on the signature page
of this Agreement. Any notice shall be deemed given (a) if personally delivered when received by the
intended recipient, (b) if sent by telefax, when sent and receipt is confirmed, provided that the
recipient is sent another copy by one of the other means of notice specified in this section, or (c)
if sent by certified mail or overnight delivery, on the earlier of the date of receipt by the
intended recipient or three (3) days after the date on which the notice is sent.

h. Upon termination of this Agreement, Schoolpop shall have the right to continue to sell any Cards
in its possession for a period of three (3) months following the effective date of termination,
subject to compliance with the applicable terms and conditions set forth herein, provided however,
that termination of the Agreement is not due to a breach of representation or warranty of the
Agreement by Schoolpop in which case Schoolpop shall discontinue selling Cards immediately upon
termination.

[Signature Pages Attached]

12

Signed for and on behalf of SCHOOLPOP INC.

Name: Paul Robinson -------------------------------------------- Title: Chief Executive Officer

Its duly authorized agent in the presence of:

Witness --------------------------------------------

Printed name --------------------------------------------

Name: Sheree Herr -------------------------------------------- Title: VP, Legal Management

Its duly authorized agent in the presence of:

Witness --------------------------------------------

Printed name --------------------------------------------

13
<!-- page 14 -->
EXHIBIT 1

TRUST AGREEMENT - FULL LIABILITY

AGREEMENT between

American Express Incentive Services, L.L.C. organized under the laws of the State of Missouri, USA,
with an office at 1309 North Highway Drive, Fenton, MO 63099, USA ("AEIS")

And

Schoolpop, Inc., a Delaware corporation, with an office at 3100 Five Forks Trickum Road, Suite 410,
Liliburn, GA 30047 USA ("Seller").

1. AEIS and Seller have entered into an American Express Stored Value Products reseller Agreement of
even date herewith pursuant to which Seller is authorized to resell certain Cards as such term is
defined therein. As such, AEIS hereby appoints Seller as trustee and agent to sell incentive cards
issued by AEIS including Persona Select(R), Be My Guest(R), Fill It Up(R), Encompass Select(R), and
any other incentive Card offered by AEIS (hereinafter collectively referred to as "Cards") in
standard denominations of 25 Points, 50 Points and 100 Points according to the specific terms in the
Reseller Agreement Effective August 1, 2004, and any amendments thereto.

2. In consideration of its entitlement to the charges referred to in paragraph (g) below, Seller
accepts appointment as such trustee and agent and agrees:

a. To receive and hold in trust for AEIS, any Cards which are delivered to Seller until paid for by
Seller. AEIS or their representatives or vendors may deliver Cards to any employee or representative
of Seller and such employees and representatives are hereby authorized to accept such Cards on
behalf of Seller.

b. To acknowledge Seller's receipt of such Cards in writing to: (i) confirm and inform AEIS of the
physical inventory of each Card delivery, and (ii) provide written confirmation of each Card
delivery to an AEIS authorized representative by returning a completed Acknowledgement of Receipt
form attached hereto as Schedule I and following the directions included thereon within 24 hours of
receipt of each Card delivery received by or on behalf of Seller.

c. To retain Cards in trust for AEIS in an "inactive" status as sent by AEIS until paid in full by
Seller to AEIS. Inactive Cards do not have points loaded on the Cards and are not ready for sale to
or use by any consumer.

d. To prepay for each box of Cards to be sold by Seller. Upon clearance of funds for each box of
Cards, AEIS shall activate the box of Cards at which time such box of Cards shall become property of
Seller. Following such activation, each Card shall generally be ready for use at an appropriate
establishment within two (2) business days.

e. To sell the Cards in accordance with the written instructions of AEIS.

f. To deliver to AEIS or their representatives any unsold Cards upon demand by AEIS.

g. To collect any charges for the sale of Cards as may be established by Seller.

h. To safeguard all Cards received by Seller at all times, including inactive and active Cards and
when the Cards are in transit, as a prudent financial or commercial institution should safeguard a
like amount of its own cash. All Cards kept on Seller's premises, both active and inactive, shall be
kept locked in Seller's safe which safe must be satisfactory to AEIS. AEIS and/or their appointed
representatives of AEIS or American Express Travel Related Services Inc. as solely determined by
AEIS, shall be entitled to inspect and approve Seller's safekeeping facilities at any time during
normal business hours.

i. To notify AEIS at destination indicated on the Acknowledgement of Receipt Form, as soon as
possible upon any loss of the Cards due to theft, burglary, fire or other cause. All notifications
of loss must include the Card number for all lost Card stock. In the event an entire shipment was
lost, the Card tracking number must also be provided. AEIS reserves the right to hold Seller liable
for any loss, as to which Seller might not otherwise have been liable for under subparagraph 2(k)
below, if Seller has unreasonably delayed reporting the loss to AEIS, and such delay has
disadvantaged AEIS or prejudiced AEIS' ability to mitigate or eliminate its damages.

14

j. To maintain accurate records of all Cards sold or held in inventory, including Card numbers,
shipment tracking numbers,
<!-- page 15 -->
account numbers, and the Acknowledgement Receipt form, etc.

k. To be responsible for any loss of any Cards received in accordance with subsection (a) above
prior to the time such Cards are paid for by Seller, whether such loss occurs by theft, burglary,
hold-up, fire, dishonesty of employees, mysterious disappearance, or any other cause irrespective of
such cause. In the case of loss of Cards, Seller shall pay AEIS from time to time upon demand the
amount of any Cards so reported as lost and later used at any merchant or other location or
otherwise appear for sale for any reason whatsoever. Seller shall be fully liable for the amounts
paid by AEIS and/or their affiliates with respect to such Cards together with any additional
reasonable costs incurred by AEIS and/or their affiliates arising out of such Cards. Such liability
shall survive termination of this Agreement.

l. Not to sell Cards on credit or post-paid method of any kind to any individual, company, or entity
whatsoever nor to utilize the Cards for the benefit of Seller, Seller's owners, officers, employees,
representatives or any third party.

m. To increase Seller's inventory of Cards by following AEIS' process.

n. To destroy Cards for purposes of past expiration or reason other than termination that causes
Seller to remove from inventory. Such Cards must be completely destroyed by cremating or shredding
to the point where such Cards cannot be reconstructed in any way or Card numbers cannot be read in
any way. Such destruction must be evidenced by execution of AEIS' Destruction Certificate, which is
attached hereto as Schedule II. The Destruction Certificate shall be executed by Seller through two
authorized signatures and shall particularly describe the Cards by (1) Card product name, (2) Card
number, (3) denomination, (4) shipment tracking number, and (5) quantity by product and
denomination, and account number. Seller shall pay AEIS associated destruction fees for such Card
destruction as detailed within the Destruction Certificate. In the event any Cards certified as
destroyed by Seller are later used at any establishment or other location or otherwise appear for
sale for any reason whatsoever, Seller shall be fully liable for the amounts paid by AEIS and/or
their affiliates with respect to such Cards together with any additional costs incurred by AEIS
and/or their affiliates arising out of such Cards. In no event shall Seller throw away discard
expired or spoiled or otherwise unwanted Cards in any other manner than described in this Section
2(n). Such liability shall survive termination of this Agreement.

o. To pass to a security audit as performed by AEIS and/or their appointed representatives of AEIS
or American Express Travel Related Services Inc. at a time and frequency solely determined by AEIS
during the term of this Agreement. This Agreement shall be terminated by AEIS at AEIS' choice
immediately upon Seller receiving a non-passing status of such security audit. AEIS may chose to
allow Seller to conform to non-passing elements of security audit within a time so specified by AEIS
in writing to Seller. Seller shall choose to make necessary changes to conform to the security audit
or terminate the Agreement as so indicated in Section 4 below.

3. This Agreement (a) may not be assigned by Seller without the written consent of AEIS, except to
an entity controlling, controlled by or under common control with Seller, provided, however,
Schoolpop shall remain liable for the obligations contained herein including the attachments and
Exhibits thereto, and (b) may be modified only by an agreement in writing signed on behalf of AEIS
by an executive officer. No other employees of AEIS have authority to modify or waive any term of
this Agreement. This Agreement may be assigned by AEIS to any parent, subsidiary, affiliated or
associate corporation without Seller's consent and shall, whether or not so assigned, inure to the
benefit of any AEIS parent, subsidiary, associate or affiliate thereof which pays or becomes liable
upon any Cards delivered to Seller under this Agreement.

4. This Agreement shall remain in force until terminated by either party by notice given in
accordance with paragraph 8, below and in accordance with Section 14(h) of the Agreement.

a. Notices so given shall, unless otherwise specified therein, be effective upon receipt whereupon
both parties shall cooperate in an effective wrap up of all outstanding issues and transition of
inventory and other termination responsibilities as determined by AEIS.

b. Upon such termination, Seller shall forthwith remit to AEIS or their agents all unsold Cards and
shall safeguard such Cards during transit to AEIS in such a manner as detailed in Section 2(h)
herein.

15

5. The rights of AEIS hereunder shall not be prejudiced or restricted by
<!-- page 16 -->
any time given or forbearance extended to Seller in the enforcement of its rights and no waiver by
AEIS of their rights in respect of any breach hereof by Seller shall be deemed to operate as a
waiver in respect of any subsequent breach hereof.

6. It is agreed between the parties that if any provision of this Agreement is held to be invalid,
the remainder of this Agreement shall continue in full force and effect and shall be binding and
effective on the parties thereto.

7. This Agreement shall be subject to and governed by the laws of the State of Missouri, USA.

8. All notices hereunder&sbsp;shall be mailed or faxed to the other party as follows: Notices to
Seller shall be addressed or faxed to it at the address or fax number set forth on the first page
hereof. Notices to AEIS shall be addressed or faxed as to:

American Express Incentive Services, L.L.C. with a copy to: General Counsel's Office 1309 North
Highway Drive American Express Fenton, MO 63099 200 Vesey Street Attn: Legal Management New York,
N.Y. 10285-4908 Fax: (636) 226-2009 Attn: Marcy Wilkov Fax: (212) 640-0360

[Signature Pages Attached]

16

Signed for and on behalf of SCHOOLPOP INC.

Name: Paul Robinson -------------------------------------------- Title: Chief Executive Officer

Its duly authorized agent in the presence of:

Witness --------------------------------------------

Printed name --------------------------------------------

Name: Sheree Herr -------------------------------------------- Title: VP, Legal Management

Its duly authorized agent in the presence of:

Witness --------------------------------------------

Printed name --------------------------------------------

17

EXHIBIT 1.A

ACKNOWLEDGEMENT OF RECEIPT FORM

Schoolpop Inc., a for-profit company incorporated under the laws of the state of Delaware, USA with
an office at 3885 Crestwood Parkway, Suite 550, Duluth, GA 30096 USA (hereinafter referred to as
"Seller").

Seller, named above, as trustee and agent of AEIS, acknowledges receipt of the Cards listed on page
2 of the Acknowledgement of Receipt Form hereof ("Cards") and agrees: (1) to hold the Cards IN TRUST
for AEIS pursuant to the terms of the Trust Agreement; (2) to sell the Cards only in accordance with
written instructions from AEIS; (3) to collect such charges for the sale of Cards as Seller may
establish from time to time; (4) to safeguard the Cards as a prudent person would safeguard a like
amount of his own cash; (5) to notify AEIS promptly, at the address listed on page 2 of the
Acknowledgement of Receipt Form hereof, of any loss of Cards due to theft, burglary, fire or any
other cause. (6) (A) to be responsible for any loss of Cards unless the Cards were safeguarded in
accordance with Section 2.h of the Trust Agreement and the loss occurred without Seller's fault. (B)
to be absolutely responsible without regard to Seller's fault for any loss of Cards due to failure
to safeguard the Cards in accordance with Section 2(h) of the Trust Agreement or due to the
dishonesty of Seller's employees or agents or due to a disappearance which Seller cannot explain.
(7) to pay AEIS upon demand for any Cards so lost which have been presented to any establishment or
retailer in exchange for service(s) or product(s) so reported by Seller as lost and later used at
any establishment or other location or otherwise appear for sale for any reason whatsoever, Seller
shall be fully liable for an amount of money equal to the face value of amounts paid by AEIS and/or
their affiliates with respect to such Cards together with any additional costs incurred by AEIS
and/or their affiliates arising out of such Cards. and (8) that the terms hereof shall not relieve
Seller of any obligation or liability under any other agreement relating to the sale of Cards
<!-- page 17 -->
existing between Seller and AEIS, its parent, subsidiaries or affiliates. WARNING: Except in the
event of termination of the Agreement Do Not Return Any of the Cards Listed on page 2 of the
Acknowledgement of Receipt Form. If it is necessary to reduce Seller's inventory of Cards, including
spoiled or expired Cards, destroy such Cards by cremating or shedding and evidence their destruction
by a Destruction Certificate attached to the Agreement as Exhibit 1.C, applicable destruction fees
shall apply. The Destruction Certificate shall be (i) on the Seller's letterhead, (ii) executed by
Seller through two authorized signatures and (iii) shall particularly describe the Cards by (a) name
of Card product, (b) Card number, (c) denomination, (d) shipment tracking number, and (e) quantity
by product, denomination and account number. Schoolpop shall forward the original Destruction
Certificate to AEIS and Schoolpop shall confirm receipt by AEIS. If this procedure is not practical,
contact AEIS Client Service Support for specific instructions regarding disposition.

AMERICAN EXPRESS INCENTIVE SERVICES, L.L.C., is the designated servicing agent for the following
Cards:

Persona(R) Select, Be My Guest(R), Fill It Up(R), Encompass(R) Select, and any other pre-denominated
incentive card offered by AEIS.

18

ACKNOWLEDGEMENT OF RECEIPT FORM - PAGE 2

Schoolpop, Inc., a for-profit company incorporated under the laws of the state of Georgia, USA with
an office at 3885 Crestwood Parkway, Suite 550, Duluth, GA 30096 USA (hereinafter referred to as
"Seller")

------------------ --------------- -------------- --------------- -------------------
--------------------- ----------------- DATE RECEIVED UPS TRACKING PRODUCT ACCOUNT # DENOMINATION
BEGINNING CARD ENDING CARD NUMBER NUMBER NUMBER ------------------ --------------- --------------
--------------- ------------------- --------------------- ----------------- ------------------
--------------- -------------- --------------- ------------------- ---------------------
-----------------

------------------ --------------- -------------- --------------- -------------------
--------------------- -----------------

------------------ --------------- -------------- --------------- -------------------
--------------------- -----------------

------------------ --------------- -------------- --------------- -------------------
--------------------- -----------------

------------------ --------------- -------------- --------------- -------------------
--------------------- -----------------

------------------ --------------- -------------- --------------- -------------------
--------------------- -----------------

------------------ --------------- -------------- --------------- -------------------
--------------------- -----------------

------------------ --------------- -------------- --------------- -------------------
--------------------- -----------------

------------------ --------------- -------------- --------------- -------------------
--------------------- -----------------

------------------ --------------- -------------- --------------- -------------------
--------------------- -----------------

------------------ --------------- -------------- --------------- -------------------
--------------------- -----------------

------------------ --------------- -------------- --------------- -------------------
--------------------- -----------------

------------------ --------------- -------------- --------------- -------------------
--------------------- -----------------

Fax completed Acknowledgement of Receipt Form to Gregg Baum, 636.226.2004, or by certified mail to
1309 North Highway Drive, Fenton, MO 63099, attention: Gregg Baum.

19

EXHIBIT 1.B

AMERICAN EXPRESS INCENTIVE SERVICES, L.L.C. 1309 N. HIGHWAY DRIVE FENTON, MO 63099

Seller, named above, as trustee and agent of CERTIFICATE OF INVENTORY DESTRUCTION FOR ANONYOMOUS
CARDS ONLY

MUST BE RECEIVED BY AEIS AT LEAST 15 DAYS PRIOR TO VALID THROUGH DATE ON CARD.

CLIENT NAME: SCHOOLPOP, INC. DATE OF ORIGINATING ORDER:______________

CLIENT ADDRESS: 3885 CRESTWOOD PARKWAY, SUITE 550, DULUTH, GA 30096 USA

CLIENT ACCOUNT #:______________ DESTROYING WHOLE OR PART OF AN ORDER____________

1. The undersigned hereby certifies that:

[X] Each of the cards described on the attached Schedule A (the "Cards") has been destroyed; [X]
Destruction of the Cards was necessary because _______________________________________________ [X]
The Cards were destroyed by this Method:_____________________________________________________ [X] At
the time of destruction, Schoolpop Inc. was the unconditional trustee of each of the Cards and was
holding in trust for AEIS, and
<!-- page 18 -->
none of the Cards described herein have been assigned, transferred, or issued to any person, firm,
or corporation.

2. Schoolpop, Inc., on behalf of itself and its successors and assigns, agrees that should any
charge(s) be incurred with respect to any of the Cards, Schoolpop, Inc. will, upon request of
American Express Incentive Services, LLC ("AEIS"), pay AEIS the full amount of such charge(s) and
Schoolpop Inc. shall indemnify AEIS, its officers, and members, and hold each of them harmless from
and against any and all claims, actions and suits, whether groundless or otherwise, and from and
against any and all liabilities, losses, damages, costs, charges and any other expenses (including
but not limited to attorneys' fees and expenses) of every nature and character by reason of the
cancellation and destruction of the Cards or the making of any payment or costs incurred as a result
of any use of the Cards described herein.

SCHOOLPOP INC.

By: ----------------------------------- Return this original Destruction Certificate and completed
Certificate of Name: Inventory Destruction to AEIS at the --------------------------------- above
address via certified mail or &bbsp; other tracked shipment method. Title:
--------------------------------

Date: ---------------------------------

WITNESS WITNESS

Name: --------------------------------- ---------------------------------------

Title: -------------------------------- ---------------------------------------

Date: --------------------------------- --------------------------------------- (Signature)
(Signature)

20

EXHIBIT 1.C CERTIFICATION OF INVENTORY DESTRUCTION FOR SCHOOLPOP, INC.

If the number of Cards destroyed requires more rows, use multiple pages of this form or type the
denomination and Card numbers into a spreadsheet and attach the printed spreadsheet to this form.

----------------------- --------------------------------------------- ----------------------
DENOMINATION CARD # CARD STATUS (active or inactive) -----------------------
--------------------------------------------- ---------------------- -----------------------
--------------------------------------------- ----------------------

----------------------- --------------------------------------------- ----------------------

----------------------- --------------------------------------------- ----------------------

----------------------- --------------------------------------------- ----------------------

----------------------- --------------------------------------------- ----------------------

----------------------- --------------------------------------------- ----------------------

----------------------- --------------------------------------------- ----------------------

----------------------- --------------------------------------------- ----------------------

----------------------- --------------------------------------------- ----------------------

----------------------- --------------------------------------------- ----------------------

----------------------- --------------------------------------------- ----------------------

----------------------- --------------------------------------------- ----------------------

Total number of ACTIVE Cards:________________________________

Total number of INACTIVE Cards:______________________________

Total number of CARDS________________________________________

Destruction Date:____________________________________________

Aggregate total denomination of Cards:_______________________
<!-- page 19 -->
Client Authorized Signature:_________________________________

Printed Name:________________________________________________

Title:_______________________________________________________

21

EXHIBIT 2

SCHOOLPOP CARD PRICING

The following pricing is effective with the Effective date of this Agreement through the term of the
Agreement and is subject to change as detailed in the Agreement.

Off-face point value based on volume mix:

Persona Select 8% Encompass Select 2% Fill It Up 4% Be My Guest 4% Category Card 3% (Contingent upon
achieving a four and one-half percent (4.5%) weighted average commission via the contracted
merchant.) Grocery Card 3% (Contingent upon achieving a four percent (4%) weighted average
commission via the contracted merchant.)

22

EXHIBIT 3

SCHOOLPOP ACCOUNT NUMBERS

1. Effective with Period One, the following account numbers shall be used by Schoolpop when placing
Orders for Cards.

----------------------------------- -----------------------------------------
--------------------------- PRODUCT DENOMINATION ACCOUNT NUMBER -----------------------------------
----------------------------------------- --------------------------- Persona(R) Select 25, 50, and
100 Points 8531 ----------------------------------- -----------------------------------------
--------------------------- Encompass(R) Select 25, 50, and 100 Points 8536
----------------------------------- -----------------------------------------
--------------------------- Fill It Up(R) 25, and 50 Points 8533 -----------------------------------
----------------------------------------- ---------------------------

2. Effective with Period Two, the following account numbers are to be used by Schoolpop.

----------------------------------- ------------------------------------------
-------------------------- PRODUCT DENOMINATION ACCOUNT NUMBER -----------------------------------
------------------------------------------ -------------------------- Persona(R) Select 25 Points
8684 ----------------------------------- ------------------------------------------
-------------------------- Persona(R) Select 50 Points 8685 -----------------------------------
------------------------------------------ -------------------------- Persona(R) Select 100 Points
8686 ----------------------------------- ------------------------------------------
--------------------------

----------------------------------- ------------------------------------------
-------------------------- Encompass(R) Select* 25 Points 8705 -----------------------------------
------------------------------------------ -------------------------- Encompass(R) Select 50 Points
8687 ----------------------------------- ------------------------------------------
-------------------------- Encompass(R) Select 100 Points 8801 -----------------------------------
------------------------------------------ --------------------------

----------------------------------- ------------------------------------------
-------------------------- Fill It Up(R) 25 Points 8681 -----------------------------------
------------------------------------------ -------------------------- Fill It Up(R) 50 Points 8683
----------------------------------- ------------------------------------------
--------------------------

----------------------------------- ------------------------------------------
-------------------------- Be My Guest(R) 25 Points 12095 -----------------------------------
------------------------------------------ -------------------------- Be My Guest(R) 50 Points 12098
----------------------------------- ------------------------------------------
--------------------------

3. Account numbers and effective dates for any products and/or denominations in addition to the
account numbers detailed above will be provided to Schoolpop by AEIS upon completion of setup of
such products and/or denominations.
<!-- page 20 -->
*Encompass(R) Select account numbers shall not be submitted with Orders effective December 31, 2004.

23

EXHIBIT 4

BRANDING QUICK REFERENCE GUIDE

1. All communication pieces/media referencing Gift Cheques, all AEIS Card products, American Express
Incentive Services, AEIS, American Express, and/or any American Express merchant must be submitted
for approval. Please allow five (5) to seven (7) business days for the branding review. Typical
turnaround is three (3) to five (5) days, however, unusual circumstances may cause a delay in the
typical turnaround. You will be notified of any delay.

2. Types of communications that require approval: Web sites, audio/visual productions, printed
materials (brochures, fact sheets, direct mailings, newsletters, point of purchase displays), news
releases, etc.

3. Our agreement with our parent company, American Express, is that they retain the authority to
review every communication piece containing references to the sources in the first bullet above.
These approvals are forwarded by AEIS to:

The American Express Advertising Review Board ("ARB") who will review the following: Communications
from an advertising perspective How the product is being communicated Card images General Counsel's
Office ("GCO") who will review the following: Communications from a legal perspective Sweepstakes
rules Charitable mentions Copyright infringements

4. Product marks should be represented as follows:

Persona(R) Select Encompass(R) Select Fill It Up(R) Be My Guest(R)

5. Since American Express is not a bank and not affiliated with a bank, terminology implying as much
should not be used. Please refer to the following examples:

---------------------------------------------------------
--------------------------------------------------------------- DO NOT USE REPLACE WITH
---------------------------------------------------------
--------------------------------------------------------------- American Express Gift Card; American
Express Incentive Services gift card; American Express Reward Card; American Express Incentive
Services reward card; Gift/Reward Card from American Express American Express branded reward card;
Reward card with the American Express brand
---------------------------------------------------------
--------------------------------------------------------------- Statement Transaction Summary
---------------------------------------------------------
--------------------------------------------------------------- Deposit; Credit Load; add; fill
---------------------------------------------------------
--------------------------------------------------------------- Available funds/points; Balance
Remaining funds/points Point balance ---------------------------------------------------------
--------------------------------------------------------------- Account Card
---------------------------------------------------------
--------------------------------------------------------------- Merchants Establishments
---------------------------------------------------------
--------------------------------------------------------------- Similar to a debit card; A prepaid
Card; Debit/Credit Card &sbsp; Stored-value Card; Reward Card
---------------------------------------------------------
---------------------------------------------------------------

6. The AEIS or American Express logos (Blue Box) are not to be used on Client pieces, as it implies
that AEIS and/or American Express are more involved in the program than providing the reward
product. The words "new" and "introducing" are limited to the first six months of use.

24

7. Development of Cards or communication materials associated with the following industries
(including showing images related to these industries, e.g. pictures of guns, cigarettes, etc.) must
be reviewed on a case-by-case basis. Alcohol Tobacco Gambling Firearms Under no circumstances may
any advertising appear in the following media:
<!-- page 21 -->
Howard Stern Rush Limbaugh Don Imus

8. Development of Cards with company names or logos from adult entertainment or pornography
industries is strictly prohibited.

9. Use the correct service Mark or registered Mark the first mention of the name on each page.

10. AEIS and American Express will treat communications sent through the branding process as
confidential.

11. This Quick Reference Guide is not all-inclusive. All communications are subject to the sole
approval of American Express.

25

EXHIBIT 4.A

BRANDING APPROVAL PROCESS OVERVIEW

GET READY You have the idea for the piece We send you a low-resolution card or Gift Cheque image, if
needed, for placement purposes only (FPO) You develop the layout

GET SET You send us the layout and copy We will review it in AEIS Branding and send to American
Express Review Units You should allow a five (5) day turnaround* We will return any revisions with
the high-resolution image, if needed

GO! You produce and distribute the piece You send us three (3) copies of the final printed piece to
keep on file You (and we) celebrate your success!

* Standard turnaround is three to five business days, however, if unusual circumstances occur, the
turnaround may take longer. Should this occur, we will notify you of any delay.

26

EXHIBIT 4.B

AEIS MERCHANT APPROVAL GUIDELINES AND PROCESS

INTRODUCTION / OVERVIEW

The AEIS Communications Group requires review of any new or revised materials, which include any
mention of Merchant Partners -- in order to ensure proper merchant guidelines. This includes ALL
advertising, promotional and marketing materials in any medium (INCLUDING: COMMUNICATIONS,
ADVERTISING, SALES PROMOTION COLLATERAL, DIRECT MAIL, PRESS RELEASES, VIDEOS, WEB SITES, PROMOTIONAL
ITEMS, SALES PRESENTATIONS AND SIMILAR MATERIALS.) Copy and layout should be submitted as early as
possible. Due to the type of communications piece, approval could take anywhere from 3 to 10
business days.

MERCHANT SUPPORTING DOCUMENTATION FOR APPROVAL GUIDELINES

Consumer applications are typically more involved. Generally, consumer programs are targeted to a
wider audience; therefore, the implications are greater for the merchant. For this reason, the
merchants mandate that AEIS seek individual approvals from each and every merchant.

Any standard applications using customized collateral should be reviewed by AEIS for content and
accuracy. Even in the cases where standard program materials are to be used, AEIS will need to
internally review any customized announcements and/or teasers. More than likely, these pieces
feature only merchant names or merchant lists in print and can typically be approved within 24-48
hours.

Pieces using only select groups of merchants, photos or logos will generally require a higher level
of approval and depending on the merchants used, may require approval from the merchant as well. The
approval timeline will range from three to ten (3-10) business days for existing/ongoing.

Once, layout and copy are approved by AEIS Communications Group, Merchant Partnerships, Operations
and American Express, any ongoing and additional changes must also be approved.

IMAGES, LOGOS, PRODUCT PATENT, AND REGISTERED/SERVICE MARKS

IMAGES AND LOGOS The following are examples of merchant image and logo usage, which require merchant
approval through Merchant Partnerships:

o Any communication or collateral, whether standard or customized, containing merchant images or
logos must be reviewed by Merchant Partnerships o Any new design work of merchant logos and images
not previously approved o Use of standard merchant logos in any color other than the original color
o Unique positioning of merchant images - surrounding merchants, etc.
<!-- page 22 -->
o "Direct mail" pieces, which include merchant references when only "select" merchants are
referenced. o Unusual type of creative print work such as posters o Borders around logos and busy
backgrounds o Any copy or tag-lines not previously approved o Under no circumstances are press
release photos to be used on or in association with any form of communication relating to incentive
card programs unless approved by Merchant Partnerships' contact. o Images and/or logos are not to be
altered (cropped, inset, or overlaid) unless approved by Merchant Partnerships' contact. o All
images used in magazine format must be obtain merchant copy write information next to the image

MERCHANT PARTNERSHIPS RESERVES THE RIGHT TO REMOVE IMAGES AT ANY TIME THAT MAY BE DEEMED
INAPPROPRIATE REPRESENTATION OF THE MERCHANT (THIS INCLUDES OUTDATED OR SEASONAL IMAGES AND LOGOS).

ALL QUESTIONS REGARDING MERCHANT COMMUNICATION APPROVAL SHOULD BE SUBMITTED TO ANN FINK AT
ANN.FINK@AEIS.COM, 636-226-2043.

27

EXHIBIT 5

CATEGORY CARD TARGET ACQUISITIONS

----------------------------------------------------------------------------------------------
PRIMARY CARD MARKETING CATEGORIES TARGET MERCHANTS
----------------------------------------------------------------------------------------------
CONSUMER CATEGORIES:
----------------------------------------------------------------------------------------------
Entertainment - Electronics & Misc Electronics Best Buy
----------------------------------------------------------------------------------------------
Apparel & Services Apparel TJ Maxx, Marshalls
----------------------------------------------------------------------------------------------
Household Furnishings & Equipment - Major and Small Best Buy Major and Small Appliance & Misc
Appliances household equipment
----------------------------------------------------------------------------------------------
Telephone Services Phones and Accessories Best Buy
----------------------------------------------------------------------------------------------
Household Furnishings & Equipment - Home furnishings and textiles and Furniture decorations Home
Goods ----------------------------------------------------------------------------------------------
Restaurants Restaurants Darden (Red Lobster, Olive Garden, etc.)
---------------------------------------------------------------------------------------------- Gifts
- combined from all categories Gifts Fossil Crabtree & Evelyn* Barnes & Nobles
----------------------------------------------------------------------------------------------
Entertainment - Tickets & Admissions Entertainment Regal Theatres, Hollywood Video, Ticketsnow.com
----------------------------------------------------------------------------------------------
Gasoline & Motor Oil Auto Accessories Autozone/TBD
----------------------------------------------------------------------------------------------
Entertainment - Toys Gifts Toys R Us
----------------------------------------------------------------------------------------------
Personal Care Products & Drugs Drugs Walgreens
----------------------------------------------------------------------------------------------
ALTERNATE CATEGORIES:
----------------------------------------------------------------------------------------------
Office Supplies Office Supplies Staples
----------------------------------------------------------------------------------------------
Sporting Goods Sporting Goods Sports Authority
----------------------------------------------------------------------------------------------
Entertainment Pet Supplies Petsmart
----------------------------------------------------------------------------------------------

28

EXHIBIT 5.A

GROCERY CARD TARGET ACQUISITIONS

Longs HEB Piggly Wiggly Save Mart ShopKo Safeway Staters

29
