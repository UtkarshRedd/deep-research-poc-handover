<!-- page 1 -->
# PRODUCT MANUFACTURING AGREEMENT
| Field | Value |
|---|---|
| Document Type | Manufacturing Agreement |
| SEC Filing Date | 2019-03-26 |
| Parties | DEXCEL LTD. ("Dexcel"); KITOV Pharma Ltd. ("Kitov")("Parties" and individually a "Party") |
| Source | CUAD v1 / KitovPharmaLtd_20190326_20-F_EX-4.15_11584449_EX-4.15_Manufacturing Agreement |

Exhibit 4.15 THE SYMBOL "****" DENOTES PLACES WHERE PORTIONS OF THIS DOCUMENT HAVE BEEN OMITTED
PURSUANT TO A REQUEST FOR CONFIDENTIAL TREATMENT. SUCH MATERIAL WILL BE FILED SEPARATELY WITH THE
SECURITIES AND EXCHANGE COMMISSION. PRODUCT MANUFACTURING AGREEMENT This Product Manufacturing
Agreement ("Agreement") is made as of the Effective Date by and between DEXCEL LTD., with its
registered address at ****, Israel ("Dexcel") and KITOV Pharma Ltd., with its registered office at
132 Menachem Begin Road, Azrieli Center, Tel Aviv, 6701101, Israel ("Kitov"). Dexcel and Kitov are
hereinafter jointly the "Parties" and individually a "Party." WHEREAS: Dexcel is a pharmaceutical
company engaged in various activities including, but not limited to, the research, development,
manufacture, and marketing of various drugs and pharmaceutical specialties in various dosage forms;
WHEREAS: Kitov is a pharmaceutical company engaged in various activities including, but not limited
to, the development of pharmaceutical products; WHEREAS: Kitov and Dexcel entered into a Development
Services Agreement on April 1, 2014 ("Development Agreement"), pursuant to which Dexcel performed
certain development services for Kitov with respect to the Product; WHEREAS: Kitov desires that
Dexcel manufacture and package the Product for Kitov in accordance with the terms of this Agreement,
and Dexcel is willing to manufacture and package the Product for Kitov in accordance with the terms
of this Agreement. NOW, THEREFORE, in consideration of the mutual covenants herein contained, the
Parties, intending to be legally bound, hereby agree as follows: 1 Definitions For the purpose of
this Agreement, the terms set forth in this clause, whether used in singular or plural form, shall
mean, unless otherwise expressly provided for in this Agreement or the context otherwise requires,
the following: 1.1 "Affiliate" of a Party shall mean any corporation or other business entity
directly or indirectly Controlled by, under common Control with, or in the Control of such Party.
1.2 "Anti-Corruption and Anti-Bribery Laws" shall mean the United States Foreign Corrupt Practices
Act of 1977, as amended, the Bribery Act 2010 (2010 Chapter 23) of the Parliament of the United
Kingdom, any rules or regulations under such acts, and any other anti-corruption or anti-bribery
statutes, laws or regulations applicable to a Party. 1.3 "API" shall mean the active pharmaceutical
ingredients Celecoxib and Amlodipine Besylate.

Source: KITOV PHARMA LTD., 20-F, 3/26/2019
<!-- page 2 -->
1.4 "Batch" shall mean the defined quantity of the Product processed in a single process or series
of processes in a manner designed to be homogeneous. The Batch size for the Product is **** tablets.
1.5 "cGMPs" or "Good Manufacturing Practice" shall mean the part of quality assurance which ensures
that the Product is consistently produced and controlled to the quality standards appropriate to
their intended use, the principles and guidelines of which are specified in European Commission
Directive 2003/94/EC and the FDA's current Good Manufacturing Practices, particularly 21 CFR § 210
et seq., and 21 CFR §§ 600-610, as both may be amended from time to time. 1.6 "Change of Control"
shall mean (i) any change, sale, merger, reorganization, or any other event or action that results
in a third party, which is a material competitor to the other Party to this agreement, acquiring:
(a) all or substantially all of the business or assets of a Party relating to this Agreement, (b)
Control, directly or indirectly, of such Party (and/or any corporate entity that Controls, directly
or indirectly, such Party), or (ii) any assignment or delegation of, sale or transfer of a Party's
rights and obligations under this Agreement (or any part hereof) to a third party. Notwithstanding
anything in the immediately preceding paragraph to the contrary, where the Party in question is
Dexcel, any of the foregoing events or actions shall not be considered a Change of Control where any
one or more of the relevant third party or parties referred to in clause (i) above is (A) a Family
Member, or (B) any entity Controlled by Mr. **** and/or a Family Member. 1.7 "Claims" shall mean any
demands, claims, actions, causes of action, assessments, losses, damages, injuries, liabilities,
costs and expenses (including, without limitation, reasonable attorneys' fees and expenses) filed,
raised, initiated or made by any governmental authority and/or third party. 1.8 "Confidential
Information" shall have the meaning set forth in Section ​7.1. 1.9 "Confirmed Order" shall have the
meaning set forth in Section 3.3.2. 1.10 "Control" or "Controlled" shall mean possession of more
than fifty percent (50%) of the share capital of a corporation or other business entity, and/or the
power to direct or cause the direction of the management and policies of a corporation or other
entity whether through the ownership of voting securities, by contract or otherwise. 1.11 "Delivery"
shall mean the time when the Product is placed at the disposal of Kitov at Dexcel's Facility based
on an **** (Incoterms® 2010). 1.12 "Distributors" shall mean any Person under contract with Kitov or
any of its Affiliates for the distribution of the Product in a certain territory or territories.
1.13 "Effective Date" shall mean the date of signature of the last Party to execute this Agreement.
1.14 "EMA" means the European Medicines Agency or any successor entity. 1.15 "Family Member" shall
mean ****. 1.16 "FDA" means the U.S. Food and Drug Administration or any successor entity.

2

Source: KITOV PHARMA LTD., 20-F, 3/26/2019
<!-- page 3 -->
1.17 "Force Majeure" shall mean an event beyond a Party's reasonable control which prevents such
Party from performing its obligations hereunder, such events may include, but not be limited to,
Acts of God (including fire, flood, earthquake, storm, hurricane or other natural disaster), war,
invasion, act of foreign enemies, hostilities (regardless of whether war is declared), civil war,
rebellion, revolution, insurrection, military or usurped power or confiscation, terrorist
activities, any extraordinary military operation which requires a large military reserve
mobilization, nationalization, governmental activities relating to emergency situations, blockage,
embargo, strikes or lockouts. 1.18 "Human Trafficking" shall mean the recruitment, transportation,
transfer, harboring, or receipt of men, women and/or children by improper means (such as force,
abduction, fraud, or coercion) for an improper purpose including forced labor or sexual
exploitation. 1.19 "Intellectual Property Rights" shall mean any inventions, information, results,
data, hypotheses, discoveries, developments, know- how, production methods, laboratory test results,
owned or in the possession of a Party, including, but not limited to, any patent, copyright,
registered design, trademarks, trade secrets, or other industrial or intellectual property right,
including any and all improvements, enhancements, derivatives and residuals, whether registered or
unregistered and applications for any of the foregoing in any country, and any other intellectual
property rights. 1.20 "Joint IP" shall have the meaning set forth in Section 8.3 of the Development
Agreement as shown in Exhibit A 1.21 "Kitov Data" shall mean, Kitov Foreground IP, including Patent
families embodied in Patents applications no. 13/026,741, 12/990,724, WO2009/154944 and
WO2011/100659, and Kitov's Confidential Information.. 1.22 "Kitov Foreground IP" shall have the
meaning set forth in Section 8.1 of the Development Agreement as shown in Exhibit A. 1.23 "Kitov
Product IP" shall have the meaning set forth in Section ​2.1.1. 1.24 "Label", "Labeled" or
"Labeling" shall refer to: (i) all labels and other written, printed or graphic matter on the
Product or any Packaging utilized with the Product, or (ii) any written material accompanying the
Product, including, without limitation, patient information leaflets ("PIL"). 1.25 "Livery" or
"Liveries" shall mean the graphics and text appearing on each Pack of the Product, including the
Trademark and any logos of Kitov and/or its Distributors, including, inter alia, the requirements
for serialization, as notified by Kitov to Dexcel in writing from time to time. 1.26 "Marketing
Authorization" shall mean an application to the appropriate Regulatory Authority for approval to
market the Product in any particular jurisdiction and all amendments and supplements thereto 1.27
"Minimum Order Requirements" shall mean multiples of a full Batch. 1.28 "Pack" shall mean a bottle
containing either **** or **** tablets of the Product, Labeled with the Livery. 1.29 "Packaging"
shall mean all primary containers (including bottles or blisters) for the Product, plus cardboard
cartons, PILs, shipping cases or any other like matter used in packaging and/or accompanying the
Product.

3

Source: KITOV PHARMA LTD., 20-F, 3/26/2019
<!-- page 4 -->
1.30 "Person" means any individual, entity or corporation of any kind, domiciled in any
jurisdiction. 1.31 "Product" shall mean tablets containing the APIs Celecoxib/Amlodipine in three
dosage strengths (200/10mg, 200/5mg and 200/2.5mg), Labelled with the Livery and in Packs. 1.32
"Quality Agreement" shall mean the agreement to be entered into by the Parties pursuant to Section
​4.1 below, which allocates the pharmaceutical responsibilities and obligations of the Parties with
respect to Product quality. 1.33 "Quarter" shall mean the relevant three (3) month period ending on
31 March, 30 June, 30 September and 31 December in any calendar year, and any shorter period
commencing on a day following the end of a Quarter and ending on the expiration or termination of
this Agreement. 1.34 "Regulatory Authority" shall mean, in a particular country or jurisdiction, any
applicable governmental authority involved in granting a Marketing Authorization in such country or
jurisdiction, including, inter alia, the FDA and EMA. 1.35 "Specifications" shall mean the
pharmacochemical, manufacturing, stability and other specifications of a Product defined in such
Product's Marketing Authorization, subject to change from time to time as reasonably required to
meet any requirements of the relevant Health Authorities. 1.36 "Supply Commencement Date" shall mean
the date upon which Dexcel makes the first Delivery of the Product to Kitov pursuant to an Confirmed
Order. 1.37 "Supply Price" shall have the meaning set forth in Section ​3.4. 1.38 "Term" shall have
the meaning set forth in Section ​5.1. 1.39 "Trademark" shall mean Kitov's trademark Consensi™. 1.40
"Working Day" shall mean a day excluding Friday and Saturday and, for the avoidance of doubt,
excluding statutory holidays in the State of Israel. 1.41 "Year" shall mean the twelve (12) months
following the Supply Commencement Date and each successive twelve (12) month period commencing on
the anniversary of the Supply Commencement Date. 2 Basics of the Agreement 2.1 Grant of Rights;
Exclusivity 2.1.1 Kitov hereby grants to Dexcel a fully paid, limited license right to use all of
its Confidential Information and Intellectual Property Rights (including, inter alia, the Kitov
Foreground IP, Kitov Data, Kitov's share of the Joint IP, and the Trademark ("Kitov Product IP"))
necessary in order for Dexcel to manufacture, Label, package with the Livery, test and release the
Product for shipment, exclusively for Kitov, for and during the Term.

4

Source: KITOV PHARMA LTD., 20-F, 3/26/2019
<!-- page 5 -->
2.2 Kitov shall be responsible (itself or through its Affiliates and Distributors) for all costs
related to the maintenance of or changes to the Specifications, materials, suppliers of the API
and/or other materials used for the manufacture or Packaging of the Product, regulatory dossiers,
and/or the Marketing Authorizations for the Product. Dexcel shall provide any and all reasonable
assistance to Kitov in this respect during the Term. 3 Purchase and Supply of Product 3.1 Packaging
3.1.1 Kitov shall provide Dexcel with reasonable Packaging and Labelling instructions for the Livery
(by SKU), including, but not limited to, artwork for Labels and patient leaflets, as soon as
practicable following the Effective Date; provided, however, that Kitov shall provide such
instructions at least one hundred and twenty (120) days prior to the anticipated Supply Commencement
Date. Kitov shall provide Dexcel with its Product Packaging and Labeling instructions, including,
but not limited to, approved artwork, with respect to any new SKU (for a new Product Distributor or
new country), as well as changes to or destruction of existing materials at least one hundred and
fifty (150) days prior to the anticipated first supply of each such SKU. 3.1.2 Kitov shall ensure
that the Packaging and Labelling instructions and the Livery shall comply in all respects with the
relevant Marketing Authorizations. 3.1.3 In the event that Kitov has Packaging requirements that are
not standard for Dexcel, the Parties shall discuss the implementation and costs of the same in good
faith. Any additional costs and expenses incurred by Dexcel as a result of such additional
requirements shall be borne solely by Kitov. 3.1.4 Dexcel shall order the Packaging materials
required for the Product Packaging (including, but not limited to, all Labeling); provided that such
orders shall not exceed the forecasted demand of such materials for the next following twelve (12)
months. In the event that any Product artwork needs to be changed and/or discarded further to
Kitov's written instructions or due to requirements of a relevant Regulatory Authority, Kitov shall
fully bear any costs arising from any such changes, including the costs of any discarded Packaging
materials and/or any destruction costs. However, if such changes are required to be carried out at
Dexcel's request, the cost for such changes shall be assumed by Dexcel. 3.2 Kitov shall provide
Dexcel with a twelve (12) month rolling forecast of its Product requirements (by SKU), no later than
the fifteenth (15th) Working Day of each Quarter ("Forecast"). The first Forecast will be provided
by Kitov to Dexcel at least six (6) months less one week prior to the anticipated Supply
Commencement Date and shall represent Kitov's best estimates of the quantity of each Product SKU to
be ordered during the twelve (12) months period covered by the Forecast;. 3.3 Purchase Orders 3.3.1
Kitov shall provide Dexcel with written purchase orders meeting the Minimum Order Requirements and
in a form reasonably acceptable to Dexcel, and which shall specify at least the following: a
description of the Product ordered, the quantity ordered, the current Supply Price, and the required
delivery date thereof, such required delivery date to be not less than one hundred and twenty (120)
days from the purchase order placement date (one hundred and eighty (180) days before the
anticipated Supply Commencement Date and/or the launch of a new SKU).

5

Source: KITOV PHARMA LTD., 20-F, 3/26/2019
<!-- page 6 -->
3.3.2 All Kitov purchase orders are subject to confirmation in writing by Dexcel, which confirmation
shall be delivered by e-mail within ten (10) Working Days of Dexcel's receipt of each purchase order
(each, a "Confirmed Order"). If Kitov does not receive a response from Dexcel within such ten (10)
Working Days, Kitov shall contact Dexcel to confirm that Dexcel has received the purchase order.
Except as provided in Section ​3.3.3, Dexcel shall use its best endeavors to accept all purchase
orders placed by Kitov, which meet the Minimum Order Requirements and the remaining terms and
conditions of this Agreement. 3.3.3 In the event that a Kitov purchase order is greater than Kitov's
Forecast by more than **** percent (****%), Dexcel shall make a good faith determination of its
ability to accept such purchase order, consistent with its manufacturing schedule, the availability
of the Product API and other materials, and its other planning requirements, in Dexcel's sole
discretion. 3.3.4 Dexcel will supply the Product only on the terms of this Agreement or any
additional terms specifically agreed upon in writing by both parties; in the event of any conflict,
the provisions of this Agreement shall prevail. 3.3.5 Dexcel shall use reasonable commercial efforts
to deliver the Confirmed Orders to Kitov in full on the required delivery date. Each shipment shall
be accompanied by certificates of analysis and such other documents required to be included pursuant
to the Quality Agreement. 3.3.6 Dexcel shall supply the Product with at least **** percent (****%)
of the shelf life upon Delivery unless otherwise agreed by the Parties. 3.3.7 The Parties shall
store and transport the Product in compliance with applicable laws and regulations for
pharmaceutical products, the Quality Agreement and the relevant Marketing Authorization. Dexcel will
be responsible for packaging the Product in a manner appropriate for shipment and for including data
loggers with each such shipment in accordance with the provisions of the Quality Agreement. 3.3.8
Kitov shall be solely responsible, at its own cost and expense, for all activities related to the
sale, marketing, shipping, distribution, storage following the delivery of the Products, order
fulfilment, invoicing, collection, and any other activities directly or indirectly related to the
promotion, marketing, distribution, or sale of the Product in any country. 3.4 The Supply Prices for
the Product shall be:

Strength Pack Size Supply Price/Pack (in US Dollars) 200/10mg Bottle **** tablets **** 200/10mg
Bottle **** tablets **** 200/5mg Bottle **** tablets **** 200/5mg Bottle **** tablets **** 200/2.5mg
Bottle **** tablets **** 200/2.5mg Bottle **** tablets ****

6

Source: KITOV PHARMA LTD., 20-F, 3/26/2019
<!-- page 7 -->
3.5 Supply Price modification 3.5.1 Commencing with ****, Dexcel may adjust the Supply Price for the
next following Year not more often than ****. 3.5.2 Dexcel shall deliver to Kitov, ****, a revised
Supply Price to be effective for Product delivered on or after the first day of the next Year; such
revised Supply Price shall not be applicable to then-outstanding Confirmed Orders. 3.6 Payment Terms
3.6.1 All payments shall be made by bank transfer to such account as may be indicated by Dexcel,
Dexcel and Kitov each bearing their own bank transfer costs, net thirty (30) days from Delivery. All
payments shall be made in U.S. Dollars. 3.6.2 With the exception of amounts in legitimate dispute,
in the event that Kitov is more than twenty one (21) Working Days late in meeting the payment
schedule set forth in Section ​3.6.1, Dexcel may, upon seven (7) Working Days' written notice to
Kitov (i) delay the delivery of Product ordered until the amounts in arrears are paid, (ii) charge
penalties on late payment with interest at the rate of **** per month from the due date for payment
until payment is actually made, and/or (iii) change or limit the terms of payment for future orders,
including requiring the prepayment for new orders or the provision of a letter of credit by Kitov
(at Kitov's expense) from a bank reasonably acceptable to Dexcel. 3.6.3 With the exception of
amounts in legitimate dispute, in the event that Kitov fails to make any payment due hereunder
within ninety (90) days following the original due date, it shall be deemed a material breach of
this Agreement and shall entitle Dexcel, in its sole discretion, to terminate this Agreement with
immediate effect. 3.7 Product Acceptance 3.7.1 The Product supplied by Dexcel to Kitov shall
correspond to the respective Product Specifications and the relevant Marketing Authorization and
shall be manufactured in compliance with cGMP and the Quality Agreement. 3.7.2 Kitov shall provide
Dexcel with written notification of any shortfalls in shipment quantity, and (a) any
out-of-specification temperature excursions based on the downloaded data logger information
following compliance with the provisions of the Quality Agreement, and/or (b) any failure of the
Product to meet the Specifications which are apparent upon visual inspection and/or identification
testing of the Product delivered to it by Dexcel (each of (a) and (b) being an "Apparent Defect"),
such notification to be provided within thirty (30) Working Days of receipt of the Product at
Kitov's warehouse, accompanied by samples of any such allegedly defective Product and any such
Product shall not be removed from quarantine until their status is resolved. In the event that a
defect is not apparent upon visual inspection during the shelf life of the Product ("Hidden
Defect"), Kitov shall use commercially reasonably best efforts to provide Dexcel with written
notification within thirty (30) Working Days of discovering the same, to be accompanied by samples
of any such allegedly defective Product, if such samples are available In the event of any failure
by Kitov to provide Dexcel with written notification of any such shortfall, Apparent Defect or
Hidden Defect within the respective aforementioned periods, it shall be deemed as Kitov having
accepted the relevant consignment.

7

Source: KITOV PHARMA LTD., 20-F, 3/26/2019
<!-- page 8 -->
3.7.3 Dexcel shall use its best efforts to make up any shortfall in shipment quantity as soon as
practicable after being notified by Kitov of such shortfall. In the event of Product which Kitov
claims have Apparent Defects or Hidden Defects, Dexcel shall have up to thirty (30) Working Days
after receipt of the samples to show that the Product in question meets the Specifications
("Period"). In the event that no agreement is reached by the end of the Period, Kitov shall have the
right to submit a new purchase order, which Dexcel shall satisfy as soon as possible using
reasonable commercial efforts ("Replacement Shipment"), and Dexcel shall require proof that Kitov
has destroyed that part or all of the original shipment with claimed defective Product. In the event
that Kitov has fully paid the Supply Price for the claimed defective Product, Dexcel shall supply
the Replacement Shipment at no additional Transfer Price. In the event that Kitov has not fully paid
the Supply Price for the claimed defective Product, Kitov will pay for the Replacement Shipment in
accordance with the provisions of this Agreement (assuming the Replacement Shipment meets the
Specifications). 3.7.4 Dexcel's responsibility for Product supplied by it to Kitov failing to meet
the Specifications shall be limited to the replacement of the Product or the refund of the Supply
Price paid by Kitov for such order, as agreed by the parties, except as otherwise provided under
this Agreement. 3.7.5 In the event that the Parties do not agree on whether the Product meets the
Specifications by the end of the Period, the Parties agree to nominate an independent, reputable
laboratory approved by the Regulatory Authority ("Laboratory"), acceptable to both Parties, which
shall examine representative samples taken from such consignment, using the methods of analysis
agreed upon by both Parties. The result shall be binding upon both Parties. Any charges for such
examination shall be borne by the Party found to be wrong in its assessment. In the event that Kitov
receives a Replacement Shipment and the Laboratory decides that the first shipment failed to meet
the Specifications, Kitov shall only have to pay Dexcel for the Replacement Shipment. In the event
that Kitov receives a Replacement Shipment and the Laboratory decides that the first shipment met
the Specifications, Kitov shall have to pay for both shipments. 4 Quality Agreement; Product
Complaints and Recalls 4.1 The Parties shall conclude the Quality Agreement as soon as practicable
after the Effective Date, but not later than ninety (90) days prior to the shipment of the initial
order of the Product to Kitov. 4.2 In case of a conflict between this agreement and the Quality
Agreement, this agreement shall prevail on any business matters, and the Quality Agreement shall
prevail on any quality related matters.

8

Source: KITOV PHARMA LTD., 20-F, 3/26/2019
<!-- page 9 -->
4.3 Kitov shall have the right (at reasonable intervals, with reasonable prior written notice and
during normal business hours, and not more often than annually) to inspect Dexcel's manufacturing
facilities used in the manufacture, storage, testing, and/or release for shipment of the Product.
4.4 Kitov shall be responsible for the execution of Product recall and crisis management policies
regarding Product issues in the Territory. In the event of a Product recall in the Territory, Kitov
shall promptly advise Dexcel and the Parties shall reasonably cooperate with each other to take all
necessary actions in that regard. 4.5 Kitov shall be responsible for bearing the cost and expenses
of any recall resulting from any of the following: (i) damage to the Products which occurred after
Delivery of the Products from Dexcel; (ii) any failure of the Livery for the Product to comply with
local laws or regulations in the relevant Territory; or (iii) any other action or non-action of
Kitov or a Distributor as promoter, marketer, distributor and seller of the Product in the
Territory. 4.6 Dexcel shall be responsible for bearing the cost and expenses of any recall resulting
from: (i) Dexcel's acts or omissions as manufacturer of the Product, or (ii) the Product supplied by
Dexcel not being in conformity with the Specifications at Delivery. 5 Term and Termination 5.1 The
Agreement shall commence on the Effective Date and remain in full force and effect for an initial
term of **** from the Supply Commencement Date of the Product ("Initial Term"). Following the
Initial Term, the Agreement shall automatically be renewed for additional periods of **** (each, a
"Renewal Term," and, together with the Initial Term, the "Term")), unless a Party provides written
notification of non-renewal to the other Party at least **** of the Initial Term or a Renewal Term.
5.2 This Agreement may be terminated: 5.2.1 by either Party, effective immediately upon written
notice to the other Party, if (i) a receiver, trustee, or liquidator of the other Party is appointed
for any of properties or assets of the other Party; (ii) the other Party makes a general assignment
for the benefit of its creditors; (iii) the other Party files a petition under the relevant statute
for the bankruptcy or reorganization of the other Party or any arrangement with its creditors or
readjustment of its debt, or its dissolution or liquidation, or such a petition is filed against the
other Party and is not dismissed within sixty (60) days thereafter; or (iv) the other Party ceases
doing business generally or commences dissolution or liquidation proceedings; 5.2.2 in the event
that a Party is in material breach of this Agreement or the Quality Agreement and fails to remedy
such breach within thirty (30) calendar days from receipt of written notification of same, by the
non-breaching Party; 5.2.3 by Dexcel, in the event that the provisions of Section ​3.6.3 is
applicable; or 5.3 in the event of a Change of Control, the Party which was not subject to the
Change of Control may terminate this Agreement upon six (6) months advance written notification. The
affected Party is obligated to notify the other Party of its decision to terminate within thirty
(30) days following notice of the Change of Control.

9

Source: KITOV PHARMA LTD., 20-F, 3/26/2019
<!-- page 10 -->
5.4 Rights and Obligations Following Expiration or Termination It is specifically understood by
Dexcel and Kitov that, upon any expiration or termination of this Agreement for any reason, the
rights and obligations of the Parties shall include the following: 5.4.1 Neither Party shall be
relieved of its duty to discharge in full all obligations accrued or due prior to the date of
termination, cancellation or expiration; all sums owed by either Party to the other shall become
immediately due and payable thirty (30) days after such date. 5.4.2 Each Party shall remove all
references to the other, if any, from its letterhead, business forms, advertising literature,
websites and place of business, and shall not thereafter use any name or trademark suggesting that
it has any current relationship with the other Party. 5.4.3 Each Party shall return to the other all
of the other's Confidential Information and any other material, information or samples relating to
the Product which have been provided or made available to the other and shall not retain any copies
and the Parties further agree not to make any further use of each other's Confidential Information
or any other information, data or samples relating to the Product provided or made available by the
other Party, except as necessary to comply with its statutory, regulatory or licensing obligations;
provided, however, that Kitov may retain such material, information and/or samples relating to the
Product as may be necessary for Kitov to continue to sell the Product as permitted by Section ​5.4.4
below, following which, Kitov shall refrain from making any further use of Dexcel's Confidential
Information or any other information, data or samples and shall return any remaining Confidential
Information and material, information or samples relating to the Product. 5.4.4 The provisions of
this Section ​5.4.4 shall not be applicable if Dexcel shall have terminated this Agreement pursuant
to Sections ​5.2.2 or ​5.2.3. Any Confirmed Orders made by Dexcel on or before the expiration or
termination of this Agreement but not yet delivered by Dexcel shall be delivered to Kitov and Kitov
shall be liable to pay for the same in accordance with the provisions of the Agreement. Kitov shall
be entitled to sell or otherwise dispose of its remaining stock of the Product until the end of the
inventory's shelf life. 5.4.5 In no event shall any expiration or termination of this Agreement
excuse either Party from any breach or violation of this Agreement and full legal and equitable
remedies shall remain available therefor. The rights and obligations of the Parties to this
Agreement set forth in 4, 5, 6, 7, 9 and 10 shall survive any expiration or termination of this
Agreement. 6 Force Majeure 6.1 If a Party asserts the occurrence of an event of Force Majeure as an
excuse for its failure or inability to perform such Party's obligations, then the obligations of the
Parties hereunder shall be suspended for so long as the Force Majeure event renders performance of
the Agreement impossible or impractical; provided, however, that (a) the nonperforming Party shall
timely notify the other Party in writing of the likelihood or actual occurrence of an event of Force
Majeure by the nonperforming Party; (b) the nonperforming Party must reasonably prove that it took
all commercially reasonable steps to minimize delay or damages caused by such event; and (c) the
nonperforming Party substantially fulfilled all non-excused obligations, unless the other Party has
notified the nonperforming Party to the contrary.

10

Source: KITOV PHARMA LTD., 20-F, 3/26/2019
<!-- page 11 -->
6.2 In the event that such event of Force Majeure continues for a period in excess of sixty (60)
days, the Parties agree to undertake good faith discussions with a view to reaching some other
mutually acceptable and reasonable arrangement for alleviating the effects of such Force Majeure. In
the event that the Parties are unable to agree on such an arrangement, either Party shall be
entitled to provide immediate written notice of termination to the other Party. 7 Confidential
Information 7.1 For the purposes of this Agreement, "Confidential Information" shall mean, with
respect to a Party, all information of any kind whatsoever (including but not limited to, data,
compilations, formulae, models, patent disclosures, procedures, processes, projections, protocols,
results of experimentation and testing, specifications, strategies and techniques), and all tangible
and intangible embodiments thereof of any kind whatsoever (including but not limited to apparatus;
compositions; documents; drawings; machinery; patent applications; records and reports), which is
proprietary to the disclosing Party or that is marked or identified by the disclosing Party or
otherwise acknowledged by the recipient Party to be confidential to the disclosing Party at the time
of disclosure to the other Party. 7.2 Confidential Information shall not include: 7.2.1 Information
that, at the time of disclosure by the disclosing Party, is in the public domain or that, after
disclosure, becomes part of the public domain except through a breach of this Agreement by the
recipient Party; or 7.2.2 Information that, at the time of disclosure by the disclosing Party, was
known to the recipient Party and was not acquired directly or indirectly from the disclosing Party
and which the recipient Party can establish by competent proof was in its possession at the time of
disclosure; or 7.2.3 Information that the recipient Party can establish by competent proof was
lawfully received from a third Party 7.3 The Parties recognize that a Party within the framework of
this Agreement may disclose Confidential Information only in accordance with the terms of this
Agreement (including this section 7)and that such disclosure represents confidential and valuable
proprietary information. Each Party promises and undertakes not to disclose the other Party's
Confidential Information to any other person other than those of its and its Affiliates' employees,
directors, officers, consultants, and Distributors ("Representatives") who must have access to such
information in order to utilize it for the purposes of this Agreement. The recipient Party will take
all reasonable steps to encourage and require its Representatives to preserve such trust and
confidence. 7.4 The recipient Party shall accord the Confidential Information disclosed by the
disclosing Party with at least as careful treatment as the recipient Party accords to its own trade
secrets, know how, and other proprietary information, but no less than a reasonable level of care.

11

Source: KITOV PHARMA LTD., 20-F, 3/26/2019
<!-- page 12 -->
7.5 The recipient Party agrees not to use Confidential Information for any purpose other than within
the framework of the co-operation with the disclosing Party and to exercise its rights and carry out
its obligations under this Agreement. Upon any expiration or termination of this Agreement, at the
disclosing Party's request, the recipient Party agrees to return to the disclosing Party all
Confidential Information disclosed to the recipient Party by the disclosing Party. 7.6 Nothing in
this Agreement, nor any disclosure of Confidential Information by the disclosing Party to the
recipient Party before or after its execution, shall operate to confer any rights upon the recipient
Party (other than the rights set forth in this Agreement) nor be effective to license or transfer to
the recipient Party any right, title or interest in the Confidential Information, which rights shall
remain the disclosing Party's exclusive property. 7.7 The Parties agree that neither Party may issue
or release, directly or indirectly, any press release, marketing material or other communications to
third parties, the media or the public regarding the terms of this Agreement, the other Party
hereto, the Product, or the transactions contemplated hereby without the prior written approval of
the other Party hereto, such approval not to be unreasonably withheld, delayed or conditioned;
provided, however, that nothing contained in this Agreement shall prevent or preclude any Party from
making such disclosures as may be required by applicable law, including, but not limited to, any
disclosures required by applicable securities laws. 7.8 Required Disclosure. Notwithstanding the
provisions of this Section 7, the recipient Party may disclose the Confidential Information of the
disclosing Party to the extent that such disclosure is reasonably necessary to: 7.8.1 prosecute or
defend litigation; 7.8.2 comply with applicable governmental laws and regulations (including,
without limitation, the applicable laws, rules, regulations or requirements of a securities exchange
or another similar regulatory body); or 7.8.3 respond to a valid order, inquiry or request of, or
make filings and submissions to, or correspond or communicate with, any government authority. In the
event that the recipient Party deems it reasonably necessary to disclose the Confidential
Information of the disclosing Party pursuant to this sub-Section 7.8, the recipient Party shall, to
the extent possible, provide the disclosing Party with reasonable advance notice of such disclosure
to afford the disclosing Party a reasonable opportunity to take the necessary measures to prevent or
otherwise limit the disclosure, and in any event, the recipient Party shall limit the disclosure to
the extent necessary to fulfill the subject purpose described above and take reasonable measures to
ensure confidential treatment of such information. 8 Warranties, Indemnities and Insurance 8.1 Kitov
represents, warrants and covenants as follows: 8.1.1 All necessary actions have been taken to enable
it to execute and deliver this Agreement and perform its obligations hereunder.

12

Source: KITOV PHARMA LTD., 20-F, 3/26/2019
<!-- page 13 -->
8.1.2 This Agreement is a valid and binding obligation of Kitov enforceable against it in accordance
with its terms. Kitov has the unencumbered right to enter into this Agreement and to fulfill its
duties hereunder. It is not and will not become Party to any agreement in conflict herewith. 8.1.3
No approval, consent, order, authorization or license by, giving notice to or taking any other
action with respect to, any governmental or regulatory authority is required in connection with the
execution and delivery of this Agreement by Kitov and the performance by Kitov of its obligations
hereunder. 8.1.4 With respect to the Kitov Product IP, the Trademark and any remaining Kitov
trademarks and logos, Kitov warrants that, to the best of its knowledge, it has not interfered with,
infringed upon, misappropriated, or otherwise come into conflict with any valid intellectual
property rights of any third party, nor has Kitov received, to the best of its knowledge, any
communications alleging any such interference, infringement, misappropriation, or violation
(including any claim that Kitov must license or refrain from using any intellectual property rights
of any third party). 8.1.5 The corporate policy of Dexcel is that all business be conducted within
the letter and the spirit of the law. Kitov warrants and represents that it will conduct the
business contemplated hereunder in a manner which is consistent with the Anti- Corruption and
Anti-Bribery Laws, and it further warrants and represent that it will not: a) Offer or give, either
directly or indirectly, money or anything else of value to any person or organization (including any
government official) that is intended to, or could be seen as an attempt to, improperly influence or
reward such other person or organization in order to obtain or retain business or secure a business
advantage for such person or organization, Kitov (including its Affiliates, Distributors, agents, or
other person associated with or acting on its or their behalf) or Dexcel. b) Request or accept,
directly or indirectly, money or anything else of value if it is intended, or could be seen as an
attempt, to compromise Kitov's independence or judgment, or to improperly influence a business
decision of Kitov or Dexcel. 8.1.6 Kitov warrants that it has established and maintains a compliance
program and reasonable internal controls and procedures appropriate to ensure that Human Trafficking
is not taking place in any part of its supply chain and in any part of its own business, including,
inter alia, the following: a) Kitov and its Affiliates (and including any Distributors, agents, or
other person associated with or acting on their behalf) do not employ any person younger than the
applicable legal minimum age for working, and children and young people less than eighteen years of
age are not employed in hazardous conditions. a) Kitov and its Affiliates (and including any
Distributors, agents, or other person associated with or acting on their behalf) do not employ any
person on an involuntary basis and do not use forced, prison, bonded, or indentured labor.

13

Source: KITOV PHARMA LTD., 20-F, 3/26/2019
<!-- page 14 -->
b) Kitov and its Affiliates (and including any Distributors, agents, or other person associated with
or acting on their behalf) fairly compensate their employees by paying wages and providing benefits
that meet or exceed the applicable, legally mandated minimum requirements in the countries in which
they operate. 8.2 Dexcel represents, warrants and covenants as follows: 8.2.1 All necessary actions
have been taken to enable it to execute and deliver this Agreement and perform its obligations
hereunder. 8.2.2 Dexcel owns or has a valid license to all Dexcel IP rights relating to the Product.
This Agreement is a valid and binding obligation of Dexcel enforceable against it in accordance with
its terms. Dexcel has the unencumbered right to enter into this Agreement and to fulfill its duties
hereunder. It is not and will not become Party to any agreement in conflict herewith. 8.2.3 No
approval, consent, order, authorization or license by, giving notice to or taking any other action
with respect to, any governmental or regulatory authority is required in connection with the
execution and delivery of this Agreement by Dexcel and the performance by Dexcel of its obligations
hereunder. 8.2.4 Dexcel warrants and represents that it will conduct the business contemplated
hereunder in a manner which is consistent with the Anti-Corruption and Anti-Bribery Laws, and it
further warrants and represent that it will not: a) Offer or give, either directly or indirectly,
money or anything else of value to any person or organization (including any government official)
that is intended to, or could be seen as an attempt to, improperly influence or reward such other
person or organization in order to obtain or retain business or secure a business advantage for such
person or organization, Kitov or Dexcel. b) Request or accept, directly or indirectly, money or
anything else of value if it is intended, or could be seen as an attempt, to compromise Dexcel's
independence or judgment, or to improperly influence a business decision of Kitov or Dexcel. 8.2.5
Dexcel warrants and represents that it has established and maintains a compliance program and
reasonable internal controls and procedures appropriate to ensure that Human Trafficking is not
taking place in any part of its supply chain and in any part of its own business. 8.2.6 Dexcel
warrants that its facilities for manufacturing the Product are cGMP-approved and that it will
manufacture the Product in accordance with this Agreement, cGMPs, the Marketing Authorization and
the Specifications. 8.3 Any breach of warranty, representation or covenant hereunder shall
constitute a breach of contract.

14

Source: KITOV PHARMA LTD., 20-F, 3/26/2019
<!-- page 15 -->
8.4 EXCEPT AS EXPRESSLY SET FORTH IN THIS AGREEMENT, DEXCEL MAKES NO WARRANTY, EXPRESSED OR IMPLIED,
AND SPECIFICALLY MAKES NO WARRANTY OF MERCHANTABILITY OR WARRANTY OF FITNESS FOR ANY PARTICULAR
PURPOSE, REGARDING THE PRODUCTS OR ANY OTHER MATTER WITH RESPECT TO THE TRANSACTIONS CONTEMPLATED
HEREBY. 8.5 Indemnification 8.5.1 Dexcel agrees to defend, indemnify and hold Kitov and its
Affiliates, and their respective officers, directors, and employees (collectively, the "Kitov
Indemnitees") harmless from and against any Claims arising from (i) any product liability claims
related solely to Dexcel's actions as the manufacture of the Product, or (ii) any breach by Dexcel
or its Affiliates of its representations, warranties, covenants, agreements or obligations under
this Agreement, in all cases except to the extent such damages give rise to an indemnification claim
by Dexcel under Section ​8.5.2 below. 8.5.2 Kitov agrees to defend, indemnify and hold Dexcel and
its Affiliates, and their respective shareholders, officers, directors, and employees (collectively,
the "Dexcel Indemnitees") harmless from and against any Claims arising from (i) the handling,
possession, use, marketing, distribution, promotion or sale of any Product by Kitov or its
Affiliates or any of their Distributors, employees or subcontractors or agents following Delivery of
the Product to Kitov, (ii) any breach by Kitov or its Affiliates of its representations, warranties,
covenants, agreements or obligations under this Agreement, (iii) any intellectual property
infringement claims with respect to the Product or the Trademark; or (iv) any product liability
claims, whether arising out of warranty, negligence, strict liability (including manufacturing,
design, warning or instruction claims) or any other product or quality based claims in relation to
the Product, in all cases except to the extent such damages give rise to an indemnification claim by
Kitov under Section ​​8.5.1 above. 8.5.3 Unless and to the extent otherwise specifically provided
herein, in the event that the Dexcel Indemnitees or the Kitov Indemnitees intend to claim
indemnification under this Section ​8.5 with respect to any third party claim or action (such one of
the Dexcel Indemnitees or the Kitov Indemnitees being herein referred to as the "Indemnitee") shall
promptly notify the other Party (the "Indemnitor") of any loss, claim, damage, or liability arising
out of any third party claim or action in respect of which the Indemnitee intends to claim such
indemnification, and the Indemnitor shall assume the defense thereof with counsel of its own
choosing. Additionally, an Indemnitee shall have the right to retain its own counsel with the
reasonable fees and expenses to be paid by the Indemnitor, however only in the event the
representation of such Indemnitee by the counsel retained by the Indemnitor would be inappropriate
due to an actual conflict of interest between such Indemnitee and any other Party represented by the
Indemnitor's counsel in such proceedings. a) An Indemnitee shall not be entitled to indemnification
under this Section ​8.5 if any settlement or compromise of a third party claim is concluded by the
Indemnitee without the prior written consent of the Indemnitor, which consent shall not be
unreasonably withheld, delayed or conditioned. b) An Indemnitor shall not enter into any settlement
or compromise of any third party claim or consent to the entry of any judgment or other order with
respect to any claim: (i) which does not contain, as a part thereof, an unconditional release of the
Indemnitee for liability for all loss, cost or damage that may arise from such claim; or (ii) which
contains any injunctive or other non-monetary relief that might in any way interfere with the future
conduct of business by the Indemnitee, unless, in either case, the Indemnitee otherwise consents
thereto in writing.

15

Source: KITOV PHARMA LTD., 20-F, 3/26/2019
<!-- page 16 -->
c) Any Indemnitee, and its employees, agents and representatives, shall cooperate fully with the
Indemnitor and its legal representatives, at the Indemnitor's sole expense for out-of-pocket costs,
in the investigation of any action, claim or liability covered by this indemnification provision.
8.6 Each Party shall maintain (a) comprehensive general liability insurance (including without
limitation, coverage for bodily injury, personal injury, property damage, casualty loss and
contractual and trademark liability); and (b) product liability insurance, providing full
indemnification and defense against claims, liabilities, damages, demands and causes of action,
alleged or actual, arising out of any defects in or use of the Product under this Agreement
(including manufacturing, design, warning, or instruction claims), in such amounts as it customarily
maintains for similar products and activities, but in no event less than $5,000,000 per individual
claim and $10,000,000 in the aggregate. At the time of entering this Agreement, each Party shall be
fully insured and shall duly maintain such insurance during the term of this Agreement and
thereafter for so long as it customarily maintains insurance for itself for similar products and
activities. Each Party shall provide the other Party with proof of such insurance upon request. Each
Party shall cause such insurance policies to provide that the other Party shall be given at least
thirty (30) days' notice of any cancellation, termination or change in such insurance. 8.7 Without
prejudice to any other limitation (whether effective or not) of either Party's liability, neither
Party shall be liable to the other Party (whether in contract, tort (including negligence) or for
breach of statutory duty or otherwise) for any loss of profits, use, opportunity, goodwill, business
or anticipated savings, for any indirect, incidental, special, indirect, punitive or consequential
losses (in each case, irrespective of any negligence or other act, default or omission of a Party
(or its employees or agents) and regardless of whether such loss or claim was foreseeable or not and
whether the other Party has been informed of the possibility of such loss). Nothing in this Section
​8.7 shall operate to limit or exclude any liability under Section ​8.5 with respect to a Claim, or
for fraud, or for breach by a Party of the provisions of Article ​7. 9 Intellectual Property Rights
9.1 It is agreed that the Parties shall keep each other informed, on a complete and timely basis,
about any claim, demand, award, or damages, whether direct or consequential, that is asserted or
assessed based upon any allegation, suit or judgment that the Kitov Product IP infringes any patent
or other intellectual property right of a third party (an "IP Claim") and about any action resulting
therefrom. The Parties shall exchange, free of charge, any documentation received from the third
party filing the IP Claim, and shall also send each other copies of the documents issued by any of
them, regarding such IP Claim. 9.2 In the event that any third party files, in or out of court, any
IP Claim against Kitov or Dexcel, alleging infringement of intellectual property rights as a
consequence of or derived from the performance of any of the operations contemplated in this
Agreement, Kitov shall, in its reasonable judgment, decide the defense strategy, the means of proof,
the choice of counsel, and the appeals. Neither Party shall settle and/or negotiate, or start
conversations to seek a settlement or a negotiation, either in or out of court, any IP Claim without
having obtained the prior written approval of the other Party. Both Parties shall collaborate on the
necessary exchange of documentation and information available in order to be able for each Party to
take action with respect to an IP Claim.

16

Source: KITOV PHARMA LTD., 20-F, 3/26/2019
<!-- page 17 -->
9.3 All of the Kitov Product IP, including the Marketing Authorizations (but excluding any of
Dexcel's Intellectual Property Rights), shall be retained by Kitov at all times, and Dexcel shall
have no rights with respect to the Kitov Product IP, except for any rights provided to it pursuant
to the terms of this Agreement and the Development Agreement. 10 Governing Law; Venue 10.1 This
Agreement shall be interpreted and enforced exclusively under the laws of the State of Israel,
without regard to the conflict of laws provisions thereof. 10.2 The Parties submit to the exclusive
jurisdiction of the competent courts of Tel-Aviv in any dispute related to this Agreement without
giving effect to choice of law rules. Notwithstanding the aforesaid, the Parties shall endeavour in
good faith to settle amicably any dispute which may arise between them under or in connection to
this Agreement. 11 Miscellaneous 11.1 The provisions of this Agreement shall be binding upon and
inure to the benefit of the Parties hereto and their respective successors and assigns.
Notwithstanding the aforesaid, either Party shall be entitled to assign, delegate, and/or
subcontract its rights and obligation under this Agreement, in whole or in part, to one or more of
its Affiliates on prior written notice to the other Party. For purposes of this Agreement, any
merger, consolidation, or change of corporate structure following which there is a Change of Control
of Kitov shall be considered as an assignment by Kitov, allowing Dexcel to terminate the Agreement
as heretofore provided. 11.2 This Agreement (including all attachments hereto and the Quality
Agreement), sets forth the entire agreement between the Parties relating to the subject matter
contained herein and may not be modified, amended or discharged except as expressly stated in this
Agreement or by a written agreement signed by the Parties hereto, except that this Agreement shall
not supersede or serve to amend (i) any separate confidentiality or non-disclosure agreement that
may have been entered into by the Parties, or (ii) the Development Agreement, each of which shall
remain in effect in accordance with its terms. 11.3 The provisions of this Agreement shall be deemed
separate. Therefore, if any part of this Agreement is rendered void, invalid or unenforceable, such
rendering shall not affect the validity and enforceability of the remainder of this Agreement unless
the part or parts which are void, invalid or unenforceable shall substantially impair the value of
the whole Agreement to either Party. 11.4 Unless otherwise stated in this Agreement, any and all
communications required as provided for in this Agreement shall be in writing to the addresses noted
above and shall be sent by (i) Certified or Registered Mail, postage prepaid, return receipt
requested, (ii) confirmed email or facsimile followed by a letter of confirmation sent by any of the
methods stated in (i) and/or (iii) of this clause, or (iii) by an express overnight courier service
(for example, Federal Express or Airborne), postage prepaid, return receipt requested and addressed
as set forth above. Notices shall be deemed given three (3) days following mailing by Certified or
Registered Mail, and one (1) day following overnight courier. Either Party may give written notice
of a change of address. After such notice has been received, any notice thereafter shall be given to
such Party as above provided at such changed address.

17

Source: KITOV PHARMA LTD., 20-F, 3/26/2019
<!-- page 18 -->
11.5 The headings used in this Agreement are for the convenience of the Parties only, and shall not
be considered in interpreting or applying the provisions of this Agreement. 11.6 Nothing in this
Agreement shall be deemed or construed to constitute between the Parties the relationship of
principal and agent, or employer and employee, nor to create any partnership, joint venture or other
form of legal association of any nature whatsoever. Neither Party is hereby constituted a legal
representative of the other Party for any purpose whatsoever and neither is granted any right or
authority hereunder to assume or create, whether in writing or otherwise, any obligation or
responsibility, express or implied, or to make any representation, warranty or guarantee, or
otherwise to act in any manner in the name of the other Party. 11.7 This Agreement may be executed
in any number of counterparts, each of which shall be deemed an original and all of which taken
together shall be one and the same agreement. Signatures to this Agreement transmitted by facsimile,
by electronic mail in "portable document format" (".pdf"), or by any other electronic means which
preserves the original graphic and pictorial appearance of the Agreement, shall have the same effect
as physical delivery of the paper document bearing the original signature. IN WITNESS WHEREOF, the
Parties have caused their authorized officials to execute this Agreement as of the date first set
forth above. Dexcel Ltd. Kitov Pharma Ltd. By: By: Name: Name: Title: Title: Date: Date: By: Name:
Title: Date:

18

Source: KITOV PHARMA LTD., 20-F, 3/26/2019
<!-- page 19 -->
Exhibit A 8.1. Any Intellectual Property Rights or Confidential Information belonging to either
Kitov or Dexcel prior to the execution of this Agreement will remain the sole property of either
Kitov or Dexcel, respectively ("Kitov Foreground IP" and "Dexcel Foreground IP", respectively). 8.2.
Kitov hereby grants to Dexcel a fully paid, limited, non exclusive, license to use Kitov Data in as
much as required for the provision of the Services by Dexcel. 8.3. Subject to the provisions of
sections 8.1 and 8.2 above and without derogating therefrom, any and all rights, title and interest
in any Intellectual Property Rights resulting from any development made by Dexcel which is related
to the Product and embodied in the Deliverables or conceived in connection with the services
provided hereunder by Dexcel to Kitov, which is only applicable for the manufacture, research,
development, making of, use, sale, production, commercialisation and distribution of the Product,
shall be jointly and equally (50%/50%) owned by Dexcel and Kitov (the "Joint. IP"). 19

Source: KITOV PHARMA LTD., 20-F, 3/26/2019
