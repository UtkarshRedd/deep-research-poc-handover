<!-- page 1 -->
# EXCLUSIVE DISTRIBUTOR AGREEMENT
| Field | Value |
|---|---|
| Document Type | Distributor Agreement |
| Agreement Date | 2019-11-12 |
| Parties | WATER NOW, INC.; ("Water Now"); Hydraspin USA, Inc. ("Subsidiary", collectively with Water Now, "Hydraspin"); BESTEV MANAGEMENT, LLC ("Distributor"); Hydraspin and Distributor (“Party” and collectively as the “Parties.”) |
| Source | CUAD v1 / WaterNowInc_20191120_10-Q_EX-10.12_11900227_EX-10.12_Distributor Agreement |

Exhibit 10.12 EXCLUSIVE DISTRIBUTOR AGREEMENT THIS EXCLUSIVE DISTRIBUTOR AGREEMENT (this
"Agreement") is made and entered into as of the 12th day of November, 2019 (the "Effective Date"),
by and among WATER NOW, INC., a Texas corporation ("Water Now"), Hydraspin USA, Inc., a Texas
corporation and a subsidiary of Water Now (the "Subsidiary," and collectively with Water Now,
"Hydraspin") and BESTEV MANAGEMENT, LLC, a Texas limited liability company ("Distributor").
Hydraspin and Distributor are sometimes hereinafter referred to individually as a "Party" and
collectively as the "Parties." RECITALS: A. Hydraspin holds the exclusive distribution rights in the
United States of America for certain commercial oil and gas products,and the associated technology,
used to separate and remove Hydrocarbons from natural and injected water involved in the extraction
process. B. Hydraspin desires to appoint Distributor, and Distributor desires to be appointed, as
the exclusive distributor of products of Hydraspin in the Territory (as defined below), pursuant to
the terms and conditions of this Agreement. NOW, THEREFORE, in consideration of the premises and the
mutual promises and covenants herein contained, and for other good and valuable consideration, the
receipt and sufficiency of which are hereby acknowledged, the Parties hereby agree as follows:
ARTICLE I. DEFINITIONS 1.1 For purposes of this Agreement, the following terms, where written with
an initial capital letter, shall have the meanings assigned to them in this Article I unless the
context otherwise requires: "Affiliate" means an individual or legal entity that directly or
indirectly, through one or more intermediaries, controls or is controlled by, or is under common
control with, another Person. The term "Control" as utilized herein means the possession, directly
or indirectly, of the power to direct or cause direction of the management and policies of a Person,
whether through management, ownership, by contract, or otherwise; provided, however, in no event
shall Hydraspin be deemed an Affiliate of the Distributor. "Change of Control" means the sale,
conveyance or disposition of all or substantially all of the assets of Hydraspin, the effectuation
by Hydraspin of a transaction or series of transactions in which more than 50% of the voting power
of Hydraspin is disposed of, or any consolidation, merger or other business combination of Hydraspin
with or into any other Person or Persons where Hydraspin is not the survivor. "Customer" means any
Person that is a customer of the Distributor and any Affiliate of Distributor that has an interest
in or ultimately utilizes the Product (as defined below). "Distributor Share" means, with respect to
Net Revenue, the percentage of Net Revenue that the Distributor is entitled to receive, as follows:
(i) for the first ten (10) Products installed, 7.5% of Net Revenue, and (ii) for the eleventh (11th)
Product installed and all Products installed thereafter, 15% of Net Revenue. Notwithstanding
anything to the contrary contained herein, the 1

Source: WATER NOW, INC., 10-Q, 11/20/2019
<!-- page 2 -->
Distributor Share with respect to the split of Net Revenue between Hydraspin and the Distributor
with respect to any particular Production installation or group Product installation may be
negotiated by Hydraspin and the Distributor and set forth in a separate written agreement between
the Parties, and in such case, the Distributor Share set forth in the separate written agreement
shall supersede and control over the Distributor Share set forth above. "Governmental Entity" means
any and all federal, state or local governments, governmental institutions, public authorities and
any other governmental entities of any nature whatsoever, and any subdivisions or instrumentalities
thereof, including, but not limited to, departments, boards, bureaus and panels, and any divisions
or instrumentalities thereof, whether permanent or ad hoc and whether now or hereafter constituted
or existing. "Hydraspin Share" means, with respect to Net Revenue, the percentage of Net Revenue
that Hydraspin is entitled to receive, as follows: (i) for the first ten (10) Products installed,
92.5% of Net Revenue, and (ii) for the eleventh (11th) Product installed and all Products installed
thereafter, 85% of Net Revenue. Notwithstanding anything to the contrary contained herein, the
Hydraspin Share with respect to the split of Net Revenue between Hydraspin and the Distributor with
respect to any particular Production installation or group Product installation may be negotiated by
Hydraspin and the Distributor and set forth in a separate written agreement between the Parties, and
in such case, the Hydraspin Share set forth in the separate written agreement shall supersede and
control over the Hydraspin Share set forth above. "Hydrocarbons" means and includes oil, gas,
casinghead gas, condensate, natural gas liquids, and all components of the foregoing. "Law" means
any constitution, law, ordinance, principle of common law, regulation, order, statute or treaty of
or issued by any Governmental Entity. "Loss" means any damage, deficiency, penalty, fine, cost,
amount paid in settlement, liability, obligation, tax, loss, expense or fee, including court costs
and reasonable attorneys' fees and expenses. "Marks" means mean the trademark(s), service mark(s)
and/or logo(s) applicable to each Product and owned by either Hydraspin or African Horizon
Technologies (PTY) Ltd ("AHT"). "Net Revenue" means the gross revenue derived from the sale of the
Hydrocarbons resulting from the Products, less (i) the share of gross revenue due to the Customers
under the agreements between the Customers and the Distributor or any Affiliate of the Distributor,
which is generally 50%, but may be greater or less than 50%, and (ii) ordinary and customary costs,
expenses and fees that are deducted from the gross revenue. "Person" means natural persons,
corporations, ventures, limited liability companies, partnerships, trusts and all other entities and
organizations. "Performance Benchmarks" shall mean the following requirements necessary for
Distributor to maintain the exclusivity granted in Section 2.1 hereof: (a) the execution of
contracts to deploy Products in 25 new locations approved in advance by Hydraspin ("Customer
Locations") during each 12 month period following the Effective Date and (b) all Customer Locations
in the aggregate shall generate an average of 7,500 barrels of fluid per day on a trailing 12 month
basis. Customer Locations must be available for installation within 90 days of approval by Hydraspin
to be applied toward the satisfaction of the Performance Benchmark. All Customer Locations in excess
of 2

Source: WATER NOW, INC., 10-Q, 11/20/2019
<!-- page 3 -->
25 secured during an applicable 12 month period shall be credited toward the satisfaction of the
Performance Benchmark for the subsequent 12 month period. If this Agreement is extended beyond the
Initial Term, as hereinafter defined, the number of Customer Locations to be secured to maintain
exclusivity during the pendency of the Agreement shall be increased to 50 from 25. "Products" shall
mean, collectively, (i) the products listed on Exhibit A attached hereto, as such Exhibit may be
amended from time to time by the Parties, (ii) all modifications, alterations, improvements,
upgrades, and replacements to the products listed on Exhibit "A", now existing and existing in the
future, and (iii) all other products, now existing and existing in the future, distributed by
Hydraspin or any Affiliate thereof that perform substantially the same functions as the products
listed on Exhibit "A", now existing and existing in the future. "Revenue Event" means any payment in
cash, or by check or wire transfer resulting from the sale of Hydrocarbons to oil and gas companies
or other third parties, due to the use of one or more Products to separate such Hydrocarbons from
water during the extraction of such Hydrocarbons from the earth. "Support Services" shall mean (a)
promptly responding to all inquiries from Customers, (b) servicing the Products, (c) educating
Customers how to properly use and maintain the Products, (d) liaising between Customers, Distributor
and Hydraspin, (d) distributing instructions for use, and any updates thereto, of each Product, and
(e) any other related services performed for or on behalf of Customers. "Territory" shall mean the
geographic territories described on Exhibit B attached hereto, as such Exhibit may be amended from
time to time by the Parties. 1.2 Other Definitions. In addition to the terms defined in Section 1.1
hereof, certain other terms are defined elsewhere in this Agreement, and whenever such terms are
used in this Agreement, they shall have their respective defined meanings, unless the context
expressly or by necessary implication otherwise requires. ARTICLE II. APPOINTMENT 2.1 Exclusivity
and Territory. Hydraspin hereby appoints Distributor, and Distributor hereby accepts appointment, as
Hydraspin's exclusive distributor of the Products in the Territory during the term of this
Agreement, subject to the terms and conditions of this Agreement, including, but not limited to, the
satisfaction of the Performance Benchmarks. The Territory may be amended with the mutual agreement
of both Parties from time to time to add or delete geographic territories by amending Exhibit B
attached hereto. If Hydraspin desires to enter a new territory in the United States, Hydraspin will
offer Distributor the first opportunity to become the exclusive distributor for the new territory.
If the Parties are unable to reach an agreement on the terms of exclusivity within ten (10) business
days of the date the opportunity is presented to Distributor, Hydraspin shall have no obligation to
enter into a contract with Distributor regarding the new territory. In the event the Distributor
loses exclusivity on a territory due to not meeting Performance Benchmarks, the Distributor shall
maintain exclusivity on any and all existing Products that are in the field and operating at them
time exclusivity if forfeited. 2.2 Sales Outside the Territory. Distributor shall be entitled to
advertise, promote, market or 3

Source: WATER NOW, INC., 10-Q, 11/20/2019
<!-- page 4 -->
solicit any Customers that have a business presence outside the Territory, except that Distributor
shall not conduct solicitation activities in any outside territory where Hydraspin is bound to an
exclusive distributor agreement with a third party, provided that Hydraspin has notified Distributor
in writing of its arrangements with the other distributor and of the territory which is subject to
exclusivity in favor of the other distributor. 2.3 Noncircumvention. Hydraspin certifies,
stipulates, and agrees that the Hydraspin will deal exclusively with and through the Distributor in
relation to the distribution of the Products in the Territory. Hydraspin will not in any way or in
any capacity, either directly or indirectly (including without limitation acting by, with or through
one or more Persons in which the Hydraspin has an interest and/or with whom Hydraspin has a
relationship): except pursuant to an agreement with the Distributor, (a) contact, approach or
negotiate with any Customer outside of the Distributor, or (b) contact, approach or negotiate with
any Person other than the Distributor and its representatives on any matter with respect to the
Products, without the prior written consent of the Distributor. Hydraspin agrees that the Hydraspin
will not, in any manner, directly or indirectly, circumvent or attempt to circumvent this Agreement,
including, without limitation, forming, joining, or in any way participating in any Person or
otherwise act in concert with any Person, for the purpose of taking any actions in circumvention of
this Agreement or which are restricted or prohibited under this Agreement. ARTICLE III. GENERAL
OBLIGATIONS 3.1 Marketing. Distributor shall use its commercially reasonable efforts to further the
advertising, promotion, marketing, distribution and sale of the Products throughout the Territory.
3.2 Support Services. Hydraspin shall install all Products and train Distributor to provide
necessary maintenance of the Products. Following installation and necessary training, Distributor
shall provide any and all necessary and appropriate Support Services to Customers in the Territory.
Hydraspin, if requested and the nature of the request is reasonable, shall assist Distributor in
providing Support Services to the Customers in the Territory. 3.3 Licenses. Hydraspin shall obtain
such authorizations, licenses, permits, and other governmental or regulatory agency approvals, if
any, as are required for the distribution and sale of the Products in the Territory. Distributor
will incur no liability arising from Hydraspin's possession, or lack of possession, of such
requisite governmental authorizations and approvals. 3.4 Proprietary Right. Distributor will not
modify or remove any trademark, copyright and other notices of proprietary rights included by AHT or
Hydraspin on the Products.

ARTICLE IV. PRODUCT AND INVENTORY 4.1 Products. Hydraspin reserves the right, from time to time and
in its sole discretion, to modify, alter, change, or improve any or all of the Products covered by
this Agreement; provided, that this Agreement shall continue to apply to all Products in their
altered, changed or improved state. Hydraspin shall promptly send Distributor written notice of any
modification, alteration, change or improvement to any Product. 4

Source: WATER NOW, INC., 10-Q, 11/20/2019
<!-- page 5 -->
4.2 Unauthorized Sales of Products. If during the term of this Agreement, Hydraspin has actual
knowledge of any unauthorized sale of any of the Products in the Territory, Hydraspin shall take
commercially reasonable action as soon as reasonably possible to bring such selling activities to an
end. 4.3 Product Adulteration. Distributor shall not modify, alter and/or change any Product as
provided by Hydraspin without the prior written consent of Hydraspin. 4.4 Supply of Products.
Hydraspin shall use its commercially reasonable efforts to supply the Products as provided in this
Agreement. In the event that the demand for any Product exceeds Hydraspin's delivery capabilities,
Hydraspin shall exercise a good faith effort to allocate available Products production resources on
a pro rata basis so that Distributor will receive Product in the same ratio as Distributor's
purchases of such Product during the period contemplated by the purchase order bears to Hydraspin's
total distribution of such Product during such period. 4.5 Regulatory Approvals. Hydraspin shall be
responsible, at its sole expense, for obtaining all required approvals, notices, filings and
applications for Products in the Territory under all applicable Laws and shall own all regulatory
approvals with respect to Products. Distributor shall have the right to rely on all such approvals,
notices, filings and applications in the Territory to the extent necessary to perform its
obligations hereunder. Hydraspin shall be responsible for undertaking all activities required under
all applicable Laws in the Territory. If any separate regulatory approval is required to be made by
Distributor, Hydraspin shall assist Distributor in obtaining such regulatory approval. 4.6 Product
Information. Hydraspin will, at its sole cost and to the extent it is available from the
manufacturer of the Product, furnish Distributor with a reasonable supply of sales and technical
information, literature and other marketing materials regarding Hydraspin and the Products in order
to aid Distributor in effectively carrying out its activities under this Agreement. 4.7 Problem
Identification. During the term of this Agreement, Distributor shall provide Hydraspin with written
notice of any claim or legal proceeding in the Territory involving any of the Products promptly
after Distributor has actual knowledge of such claim or legal proceeding. Likewise, during the term
of this Agreement, Hydraspin shall provide Distributor with written notice of any claim or legal
proceeding in the Territory involving any of the Products promptly after Hydraspin has actual
knowledge of such claim or legal proceeding. Distributor will also keep Hydraspin informed as to any
problems encountered with any of the Products. Hydraspin will repair or replace all defective or
damaged Products at the time of delivery at its sole cost and expense. ARTICLE V. ORDERS AND
DELIVERY 5.1 Orders. Distributor shall order Products from Hydraspin by submitting purchase orders
and an installation plan identifying the number(s) and type(s) of Products ordered, the requested
delivery date(s) (each, an "Order"). The requested delivery date shall be no less than 120 days from
the date the Order is accepted by Hydraspin. Hydraspin will not unreasonably reject any Order for
Products. Hydraspin will accept or reject each Order submitted by Distributor within ten (10) days
after receipt of the Order. Any Orders not expressly rejected by Hydraspin within such ten (10) day
period shall be deemed accepted by Hydraspin. Notwithstanding the foregoing, Distributor may cancel
any Order for Products that are not delivered within sixty (60) days after the delivery date
specified therein. 5.2 Delivery; Storage; Risk of Loss. Hydraspin shall use commercially reasonable
efforts to deliver Products to Customers by the delivery dates specified in Distributor's Orders.
Products shall be 5

Source: WATER NOW, INC., 10-Q, 11/20/2019
<!-- page 6 -->
delivered directly to the Customer. All costs and expenses of shipping, freight, delivery,
transportation and storage, including, without limitation, insurance covering the Products during
transportation and while stored at any facility will be borne solely by Hydraspin and the
Distributor shall not be liable therefor. Risk of loss shall be borne entirely by Hydraspin, even
while Products are in the possession or control of Distributor or any customer, and the Distributor
and the customers shall not be liable therefor, except solely in the case of Distributor's or any
customer's intentional misconduct or gross negligence. Hydraspin may request Distributor to store
Products at Distributor's facilities, and Distributor shall use commercially reasonable efforts to
accommodate Hydraspin's storage requests; provided, that Hydraspin shall bear the full risk of loss
with respect to Products stored at Distributor's facility and Distributor shall not be liable
therefor, except solely in the case of Distributor's intentional misconduct or gross negligence.
ARTICLE VI. NET REVENUE AND REPORTS 6.1 No Cost. Hydraspin shall provide the Products to
Distributor's Customers at no cost to Distributor or the Customers, except solely for the Hydraspin
Share of Net Revenue, which shall be due and payable to Hydraspin as set forth in this Article VI.
Likewise, Hydraspin shall install, service and maintain the Products, with the commercially
reasonable assistance of Distributor, at no cost to Distributor or the customers except solely for
the Hydraspin Share of Net Revenue, which shall be due and payable to Hydraspin as set forth in this
Article VI. 6.2 Net Revenue. With respect to each Revenue Event, Distributor shall be entitled to
receive the Distributor Share of Net Revenue, and Hydraspin shall be entitled to receive the
Hydraspin Share of Net Revenue. Hydraspin and the Distributor will cooperate to ensure that the
Parties each receive the correct percentages of Net Revenue. If Hydraspin receives any payment in
excess of the Hydraspin Share, then Hydraspin agrees to remit promptly to the Distributor such
excess amount. Likewise, if the Distributor receives any payment or in excess of the Distributor
Share, then the Distributor agrees to remit promptly to Hydraspin such excess amount. 6.3
Calculation of Net Revenue. The Parties hereto acknowledge and agree that the Net Revenue is
determined, in part, by the method under which the Hydrocarbons are measured, that such methods
differ from Customer to Customer, and are outside of the control of the Parties. Likewise, the
Parties hereto acknowledge and agree that the timing of receipt of Net Revenue is outside of the
control of the Parties. No Party shall be liable to another Party as a result of any Losses
sustained by such Party resulting from the measurement of Hydrocarbons and the resulting Net Revenue
derived from the Products or the timing of receipt of a Party's share of Net Revenue. 6.4 Records.
During the term of this Agreement and for any additional time period thereafter required by
applicable Law, Distributor shall maintain complete and accurate books and records relating to the
Products, including, without limitation, the names and addresses of Customers, the location of the
Products, the sales of Hydrocarbons relating to the Products, the Net Revenue, the Hydraspin Share
of Net Revenue, and the Distributor Share of Net Revenue. During the term of this Agreement,
Distributor shall afford to Hydraspin and its authorized representatives full access at all
reasonable times and upon reasonable prior notice, to all such books and records with respect to the
Products. ARTICLE VII. REPRESENTATIONS AND WARRANTIES 7.1 Representations of Hydraspin. Hydraspin
represents and warrants to Distributor as follows: 6

Source: WATER NOW, INC., 10-Q, 11/20/2019
<!-- page 7 -->
(a) Due Organization, Existence and Authority. Hydraspin (i) is duly organized, validly existing and
in good standing under the laws of its jurisdiction of organization, and (ii) has full power and
authority to own its properties, carry on its business as presently conducted and as proposed to be
conducted, and to enter into and perform its obligations under this Agreement. (b) Authorization.
The execution and delivery by Hydraspin of this Agreement and the other documents related thereto
and the full and timely performance of all obligations thereunder have been duly authorized by all
necessary action under the constituent documents of Hydraspin and otherwise. (c) Valid, Binding and
Enforceable. This has been duly and validly executed, issued and delivered by Hydraspin and
constitutes the valid and legally binding obligations of Hydraspin, enforceable in accordance with
its terms, except as limited by bankruptcy, insolvency, reorganization or other similar laws
relating to or affecting enforcement of creditor's rights. (d) No Violation. The execution, delivery
and performance by Hydraspin of this Agreement does not and will not (i) contravene the constituent
documents of Hydraspin, (ii) contravene any law, rule or regulation, or any order, writ, judgment,
injunction or decree or any contractual restriction binding on or affecting Hydraspin or the
Products, and (iii) require any approval or consent of any general partner, board, manager, member,
lender or any other person or entity, other than approvals or consents that have been previously
obtained and disclosed in writing to the Distributor, [including, without limitation, the consent of
AHT.] No authorization or approval or other action by, and no notice to or filing with, any
Governmental Authority is required for the due execution, delivery and performance by Hydraspin of
this Agreement, other than approvals or consents that have been previously obtained and disclosed in
writing to the Distributor. 7.2 Representations of Distributor. Distributor represents and warrants
to Hydraspin as follows: (a) Due Organization, Existence and Authority. Distributor (i) is duly
organized, validly existing and in good standing under the laws of its jurisdiction of organization,
and (ii) has full power and authority to own its properties, carry on its business as presently
conducted and as proposed to be conducted, and to enter into and perform its obligations under this
Agreement. (b) Authorization. The execution and delivery by Distributor of this Agreement and the
other documents related thereto and the full and timely performance of all obligations thereunder
have been duly authorized by all necessary action under the constituent documents of Distributor and
otherwise. (c) Valid, Binding and Enforceable. This has been duly and validly executed, issued and
delivered by Distributor and constitutes the valid and legally binding obligations of Distributor,
enforceable in accordance with its terms, except as limited by bankruptcy, insolvency,
reorganization or other similar laws relating to or affecting enforcement of creditor's rights. (d)
No Violation. The execution, delivery and performance by Distributor of this Agreement does not and
will not (i) contravene the constituent documents of Distributor, (ii) contravene any law, rule or
regulation, or any order, writ, judgment, injunction or decree or any contractual restriction
binding on or affecting Distributor, or (iii) require any approval or consent of any general
partner, board, manager, member, lender or any other person or entity, other than approvals or
consents that have been previously obtained and disclosed in writing to the Hydraspin. 7

Source: WATER NOW, INC., 10-Q, 11/20/2019
<!-- page 8 -->
No authorization or approval or other action by, and no notice to or filing with, any Governmental
Authority is required for the due execution, delivery and performance by Distributor of this
Agreement, other than approvals or consents that have been previously obtained and disclosed in
writing to Hydraspin. ARTICLE VIII.

INTELLECTUAL PROPERTY RIGHTS 8.1 Limited Grant. Hydraspin hereby grants to Distributor an exclusive
non-transferable and royalty-free right and license to use Hydraspin's Marks in connection with the
advertising, promotion, marketing, distribution and sale of the Products in the Territory in
accordance with Hydraspin's standards and instructions. Distributor shall acquire no right, title or
interest in or to the Marks, other than the above license, and Distributor shall not use any Mark as
part of Distributor's corporate or trade name or permit any third person or party to do so without
the prior written consent of Hydraspin. 8.2 Notice of Infringements. Distributor shall notify
Hydraspin in writing of any and all infringements of the intellectual property relating to the
Products in the Territory that may come to Distributor's attention, and Distributor shall assist
Hydraspin in taking such action against such infringements as Hydraspin in its sole discretion may
decide; provided, however, that Hydraspin shall bear any and all expenses and costs incident to such
action. 8.3 Termination of Use. Distributor acknowledges Hydraspin's proprietary rights in and to
the intellectual property relating to the Products, and Distributor waives in favor of Hydraspin all
rights to the intellectual property relating to the Products, including any additions to the
intellectual property hereafter originated by Hydraspin or AHT. Distributor shall not adopt, use or
register any words, phrases or symbols which are identical to or confusingly similar to any of the
Marks. Upon termination of this Agreement, Distributor shall immediately cease using the Marks. 8.4
Ownership. Except for the limited rights expressly granted herein by Hydraspin to Distributor,
nothing in this Agreement will serve to transfer to Distributor any patent, copyright, trademark or
other intellectual property rights in or to any Product, the Marks, or other intellectual property
owned or claimed by Hydraspin or AHT. Distributor acknowledges and agrees that Hydraspin or AHT have
sole right, title and interest in and to all intellectual property rights covering, claiming or
associated with the Products, the Marks and all goodwill associated therewith. 8.5 Maintenance of
Intellectual Property Rights. During the term of this Agreement, Hydraspin shall be responsible for
maintaining, at Hydraspin's sole cost and expense, any and all intellectual property rights related
to the Products, including, without limitation, (i) patents and patent applications, and any and all
divisions, continuations, continuations-in-part, reissues, continuing patent applications,
reexaminations, and extensions thereof (iii) trademarks and service marks, trade names, trade dress,
and logos; and (iii) copyrights and other works of authorship.

ARTICLE IX. CONFIDENTIAL AND/OR PROPRIETARY INFORMATION 9.1 Confidentiality. Each Party acknowledges
that in the course of performing its respective duties under this Agreement, such Party may obtain
information related to the other Party, which is of a 8

Source: WATER NOW, INC., 10-Q, 11/20/2019
<!-- page 9 -->
confidential or proprietary nature ("Confidential Information"). Each Party agrees not to use such
other party's Confidential Information, either directly or indirectly, for any purpose other than as
required for performance of such Party's obligations hereunder. Such Confidential Information may
include but is not limited to copyright, trade secrets or other proprietary information, techniques,
processes, schematics, software source documents, pricing and discount lists and schedules, customer
lists, contract terms, customer leads, financial information, sales and marketing plans, and
information regarding the responsibilities, skills and compensation of employees. Title to
Confidential Information shall remain with the owner of the Confidential Information at all times.
Each Party agrees to treat the Confidential Information with at least the degree of care and
protection with which it treats its own confidential information, but in any event with no less than
reasonable care and protection, and to use the Confidential Information only for the purpose set
forth in this Agreement. Except as otherwise required by law, applicable regulations or the terms of
this Agreement or as mutually agreed upon by the parties hereto, each Party shall treat as
confidential the terms and conditions of this Agreement. Notwithstanding anything contained in this
Agreement to the contrary, Confidential Information shall not include information that:

(a) is or becomes available to the public other than through a disclosure in breach hereof by the
receiving Party or any of its representatives;

(b) was in the possession of the receiving Party or its representatives prior to the Effective Date;

(c) was communicated by the disclosing Party to an unaffiliated third party free of any obligation
of confidentiality, and the unaffiliated third party communicated the Confidential Information to
the receiving Party or its representatives;

(d) becomes available to the receiving Party or its representatives from a source other than the
disclosing Party, provided, that such source is not known to the receiving Party or its
representatives to have made such information available in violation of an obligation of
confidentiality owed to the disclosing Party; or

(e) is independently developed by or on behalf of a Party or its representatives without use of the
Confidential Information of the other Party.

9.2 Nondisclosure. Each Party agrees not to disclose or otherwise make such Confidential Information
available to third parties without the other Party's prior written consent. Each Party agrees that
it will take appropriate action by instruction, agreement, or otherwise with such Party's employees
to satisfy its obligations under this Agreement with respect to the use, copying, modification,
protection, and security of Confidential Information. Nothing in this section prohibits any
disclosure required by applicable law, a valid court order or subpoena; provided, that the
disclosing Party gives the other Party prior notice of, and if possible a reasonable opportunity to
contest, such required disclosure. 9.3 Return of Confidential Information. Each Party will promptly
return all Confidential Information to the other Party upon expiration or termination of this
Agreement, or upon receipt by such Party of written notice from the other Party requesting return of
such Confidential Information. Such Confidential Information shall be returned promptly and the
non-disclosing Party shall not retain any documents or materials or copies thereof containing any
Confidential Information. 9.4 Injunctive Relief. Any breach of the restrictions contained in this
Article IX is a breach of this 9

Source: WATER NOW, INC., 10-Q, 11/20/2019
<!-- page 10 -->
Agreement that may cause irreparable harm to a party and as such each Party is entitled to
injunctive relief to enforce this Agreement without the need to post bond and that such relief shall
be, in addition to, and not in lieu of, any monetary damages or other legal or equitable remedies
that may be available. ARTICLE X. TERM AND TERMINATION 10.1 Term. The initial term of this Agreement
shall commence on the Effective Date and end on the five (5) year anniversary of the Effective Date
(the "Initial Term"), unless sooner terminated pursuant to the terms hereof. Upon expiration of the
Initial Term of this Agreement, this Agreement will automatically renew for additional, successive
five (5) year periods unless either Party provides the other Party written notice of its desire to
terminate at least one hundred twenty (120) days prior to the end of the Initial Term or any
renewal. 10.2 Termination. This Agreement may be terminated as follows: (a) In the event that the
Parties mutually determine that the arrangements contemplated by this Agreement are no longer in the
best interests of the Parties or the Parties are not otherwise compatible, the Parties may at any
time, by mutual written agreement, terminate this Agreement. (b) Immediately upon the occurrence of
any of the following events and effective upon delivery of notice: (1) by Hydraspin, i f Distributor
ceases to do business, or otherwise terminates Distributor's business operations; (2) by
Distributor, if Hydraspin ceases to do business, or otherwise terminates Hydraspin's business
operations;

(3) by Hydraspin, if Distributor fails to satisfy the Performance Thresholds; (4) by either Party,
if any representation by the other Party made in this Agreement was false or misleading in any
material respect when made; (5) by Distributor, if Hydraspin fails to secure or renew any license,
permit, authorization, or approval for the conduct of Hydraspin's business or the distribution of
the Products or if any such license, permit, authorization, or approval is revoked or suspended
provided that such failure, revocation or suspension results in Hydraspin's failure or inability to
perform substantially all of its obligations hereunder; (6) by either Party, if the other Party
engages in fraud, criminal/negligent conduct in connection with this Agreement or the business
relationship of the parties or if the other Party makes any material false representations, reports,
or claims in connection with this Agreement or any Product; (7) by either Party, if the other Party
breaches any of its obligations under this Agreement and such violation is not cured to the
satisfaction of the non-breaching party within thirty (30) days after written notice is given from
the non-breaching Party to the breaching Party; 10

Source: WATER NOW, INC., 10-Q, 11/20/2019
<!-- page 11 -->
(8) by either Party, if Hydraspin undergoes a Change of Control; or (9) by either Party, if such
other Party seeks protection under any bankruptcy, receivership, trustee, creditors arrangement,
composition, or comparable proceeding, or if any such proceeding is instituted against such other
Party. 10.3 Effect of Termination.

(a) Termination or expiration of this Agreement will not relieve either Party of any obligation
incurred hereunder prior to such termination or expiration. Each Party will be entitled to cancel
any outstanding Orders, to the extent Products have not been delivered. Hydraspin shall be entitled
to retrieve its Products from the Customers at its sole cost and expense. (b) If termination is the
result of a Change of Control, Distributor shall be entitled to receive a onetime payment, within
three (3) business days of the effective date of the Change of Control, equal to the greater of the
following 1) the aggregate amount of the Distributor Share received during the 18 months prior to
the effective date of such Change of Control or 2) the aggregate amount of the Distributor Share
received on the 30 days prior to the effective date of such Change of Control multiplied by 18. (c)
Neither Party will incur liability for any Losses of any kind suffered or incurred by the other
Party arising from or incident to termination of this Agreement by such party as permitted by this
Article X. ARTICLE XI.

MISCELLANEOUS 11.1 Notices. (a) Manner of Notice. All notices, requests and other communications
under this Agreement shall be in writing (including in portable document format (or similar format)
delivered by email transmission) and shall be deemed to have been duly given if delivered
personally, or sent by either certified or registered mail, return receipt requested, postage
prepaid, or by overnight courier guaranteeing next day delivery, or by email transmission, addressed
as follows: (i) If to Hydraspin: Water Now, Inc. Hydraspin USA, Inc. 5000 South Freeway, Suite 110
Fort Worth, Texas 76115 Attn: David King Email: dking@waternowinc.com or at such other address or
email address as Hydraspin may have advised Distributor in writing; and (ii) If to Distributor:
Bestev Management, LLC 11

Source: WATER NOW, INC., 10-Q, 11/20/2019
<!-- page 12 -->
Attn: Email: or at such other address or email address as Distributor may have advised Hydraspin in
writing. (b) Deemed Delivery. All such notices, requests and other communications shall be deemed to
have been received (i) on the date of delivery thereof, if delivered by hand, (ii) on the fifth day
after the mailing thereof, if mailed, (iii) on the next business day after the sending thereof, if
sent by overnight courier, (iv) on the day of sending, if sent by email transmission prior to 5:00
p.m. on any business day, or (v) on the next business day, if sent by email transmission after 5:00
p.m. on any business day or on any day other than a business day. 11.2 Waivers and Amendments. No
amendment or waiver of any provision of this Agreement, nor consent to any departure therefrom,
shall be effective unless the same shall be in writing and signed by a duly authorized officer of
each of the Parties, and then such waiver or consent shall be effective only in the specific
instance and for the specific purpose for which given. No failure on the part of a Party hereto to
exercise, and no delay in exercising, any right hereunder shall operate as a waiver thereof; nor
shall any single or partial exercise of any right hereunder preclude any other or further exercise
thereof or the exercise of any other right. The remedies provided in this Agreement are cumulative
and not exclusive of any remedies provided by law. 11.3 Assignment. Neither Party may assign any
right, or delegate any duty under this Agreement, in whole or in part, without the prior written
consent of the other Party, which shall not be unreasonably withheld or delayed. Any attempted
assignment without such consent shall be void and of no effect. Notwithstanding anything contained
in this Section to the contrary, Hydraspin may assign this Agreement upon written notice to
Distributor to any entity which controls, is controlled by or under common control with Hydraspin or
to any successor to or purchaser of all or substantially all of its assets or stock, by merger or
otherwise. 11.4 Force Majeure. The obligations of the Parties under this Agreement shall be
suspended to the extent that a Party is hindered or prevented from complying therewith because of
labor disturbances (including strikes or lockouts), war, acts of God, terrorism, fires, storms,
accidents, governmental regulations or any other cause whatsoever reasonably beyond a Party's
reasonable control. For so long as such circumstances prevail, the Party whose performance is
delayed or hindered shall continue to use all commercially reasonable efforts to recommence
performance without delay. 11.5 Relationship of Parties. Each Party hereto shall be, and at all
times will remain, an independent contractor and will not represent itself to be the agent, joint
venturer, or partner of the other party or related to such Party. No representations will be made or
acts done by either Party which would establish any apparent relationship of agency, joint venture
or partnership. Nothing herein is intended or may be construed to create any employer/employee
relationship between the Parties. 11.6 Binding Effect. This Agreement shall be binding upon and
inure to the benefit of the Parties and their respective successors and permitted assigns. 11.7
Exhibits. The Exhibits attached hereto or referred to herein are incorporated herein and made a part
hereof for all purposes. As used herein, the expression "this Agreement" means this document and
such Exhibits. 12

Source: WATER NOW, INC., 10-Q, 11/20/2019
<!-- page 13 -->
11.8 Governing Law. THIS AGREEMENT, AND THE RIGHTS AND OBLIGATIONS OF THE PARTIES, SHALL BE GOVERNED
BY AND CONSTRUED AND ENFORCED IN ACCORDANCE WITH THE SUBSTANTIVE LAWS OF THE STATE OF TEXAS, U.S.A.
WITHOUT REGARD TO ITS PRINCIPLES OF CONFLICTS OF LAWS. 11.9 Arbitration. The Parties shall use their
respective best efforts to settle amicably any disputes, differences or controversies arising
between the Parties out of or in connection with or in respect of this Agreement. However, if not so
settled, then the same shall be submitted to arbitration and, to the fullest extent permitted by
law, be solely and finally settled by confidential binding arbitration, except as specifically
provided otherwise herein. The confidential arbitration proceeding shall be held in Collin County,
Texas and shall be conducted in accordance with the alternative dispute resolution rules of the
American Arbitration Association. The arbitration proceeding shall be held before a single
arbitrator unless (i) the matter in controversy exceeds Five Hundred Thousand Dollars ($500,000),
(ii) the Parties cannot agree on the arbitrator, or (iii) either Party requests a panel of three (3)
arbitrators. Judgment upon the award rendered by the arbitrator may be entered in any court having
jurisdiction, or application may be made to such court for a judicial acceptance of the award and
any order of enforcement as the case may be. The arbitrator shall not award any Party punitive,
exemplary, multiplied or consequential damages, and each Party hereby irrevocably waives any right
to seek such damages in arbitration or in judicial proceedings. Each Party shall bear its own costs
in the arbitration, and the fees and expenses of the arbitration shall be shared equally by the
Parties. Notwithstanding the foregoing, the arbitrator shall have the right and authority to
apportion among the parties all reasonable costs, including attorneys' fees and witness fees, taking
into account the relative fault of the Parties. The foregoing provisions of this Section 11.9 do not
limit the right of a Party to seek injunctive or other equitable relief from a court of competent
jurisdiction pending resolution of a dispute by arbitration. 11.10 Jurisdiction and Venue. Subject
to the arbitration provisions set forth in Section 11.10, any judicial proceeding brought by or
against either of the Parties on any dispute arising out of this Agreement or any matter relating
thereto shall be brought in any federal or state court sitting or having jurisdiction in the County
of Collin, State of Texas, and by execution and delivery of this Agreement, each Party hereby
accepts for itself the exclusive jurisdiction and venue of the aforesaid courts as trial courts, and
irrevocably agrees to be bound by any final non-appealable judgment rendered in connection with this
Agreement. 11.11 Number and Gender. Whenever herein the singular number is used, the same shall
include the plural where appropriate, and words of any gender shall include each other gender where
appropriate. 11.12 Captions. The captions, headings and arrangements used in this Agreement are for
convenience only and do not in any way affect, limit or amplify the provisions hereof. 11.13 Invalid
Provisions. If any provision of this Agreement is held to be illegal, invalid or unenforceable under
present or future laws effective during the term hereof, such provision shall be fully severable,
this Agreement shall be construed and enforced as if such illegal, invalid or unenforceable
provision had never comprised a part hereof, and the remaining provisions of this Agreement shall
remain in full force and effect and shall not be affected by the illegal, invalid or unenforceable
provision or its severance from this Agreement. Furthermore, in lieu of such illegal, invalid or
unenforceable provision, there shall be added automatically as part hereof a provision as similar in
terms, but in any event no more restrictive than, such illegal, invalid or unenforceable provision
as may be possible and be legal, valid and enforceable. 11.14 Entirety. This Agreement and the
documents executed and delivered pursuant hereto, executed on the date hereof or in connection
herewith, contain the entire agreement between the Parties with 13

Source: WATER NOW, INC., 10-Q, 11/20/2019
<!-- page 14 -->
respect to the matters addressed herein and supersede all prior representations, inducements,
promises or agreements, oral or otherwise, which are not embodied herein or therein. 11.15
Counterparts. This Agreement may be executed in multiple counterparts, each of which shall be deemed
an original for all purposes and all of which shall be deemed collectively to be one agreement.
Signatures given by facsimile or portable document format (or similar format) shall be binding and
effective to the same extent as original signatures. 11.16 Third Party Beneficiaries. Nothing
contained herein, express or implied, is intended to confer upon any person or entity other than the
Parties and their respective successors in interest and permitted assigns any rights or remedies
under or by reason of this Agreement. 11.17 Interpretation. This Agreement has been prepared in the
English language which language shall be controlling in all respects. 14

Source: WATER NOW, INC., 10-Q, 11/20/2019
<!-- page 15 -->
IN WITNESS WHEREOF, the Parties have caused their authorized representatives to execute this
Agreement as of the date first set forth above.

WATER NOW: WATER NOW, INC.

By: Name: David King Title: Chief Executive Officer

HYDRASPIN: HYDRASPIN USA, INC.

By: Name: David King Title: Chief Executive Officer WATER NOW: WATER NOW, INC.

By: Name: Title:

DISTRIBUTOR: BESTEV MANAGEMENT, LLC

By: Name: Title:

15

Source: WATER NOW, INC., 10-Q, 11/20/2019
<!-- page 16 -->
EXHIBIT A PRODUCTS African Horizon Technologies Hydraspin Units

16

Source: WATER NOW, INC., 10-Q, 11/20/2019
<!-- page 17 -->
EXHIBIT B TERRITORY The Territory consists of all of the following: A. The San Juan Basin located
near the Four Corners region of the Southwestern United States. The San Juan Basin Territory
includes, without limitation, that certain area covering 7,500 square miles and resides in
northwestern New Mexico, southwestern Colorado, and parts of Utah and Arizona. Specifically, the San
Juan Basin occupies space in the San Juan, Rio Arriba, Sandoval, and McKinley counties in New
Mexico, and La Plata and Archuleta counties in Colorado. B. The Permian Basin located in the
southwestern part of the United States. The Permian Basin Territory includes, without limitation,
the Mid-Continent Oil Field province located in western Texas and southeastern New Mexico, reaching
from just south of Lubbock, past Midland and Odessa, south nearly to the Rio Grande River in
southern West Central Texas, and extending westward into the southeastern part of New Mexico. C. The
Eagle Ford Group Basin (also called the Eagle Ford Shale Basin) covering much of the state of Texas.
The Eagle Ford Group Basin Territory includes, without limitation, the Eagle Ford outcrop belt
trending from the Oklahoma/Texas border southward to San Antonio, westward to the Rio Grande, Big
Bend National Park, and the Quitman Mountains of West Texas.

Source: WATER NOW, INC., 10-Q, 11/20/2019
