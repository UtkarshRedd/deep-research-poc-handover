<!-- page 1 -->
# CO-BRANDING AGREEMENT
| Field | Value |
|---|---|
| Document Type | Co-Branding Agreement |
| Agreement Date | 2003-01-21 |
| Parties | Lucent Technologies Inc. ("Lucent"); mPhase Technologies Inc. ("mPhase")("a Party" and collectively, "the Parties") |
| Source | CUAD v1 / MphaseTechnologiesInc_20030911_10-K_EX-10.15_1560667_EX-10.15_Co-Branding Agreement |

EXHIBIT 10.15

CO-BRANDING AGREEMENT

This Agreement is made this 21st day of January 2003 by and between Lucent Technologies Inc., a
Delaware corporation having a principal place of business at 600 Mountain Avenue, Murray Hill, New
Jersey 07974 ("Lucent") and mPhase Technologies Inc., a New Jersey corporation located at 587
Connecticut Avenue, Norwalk, Connecticut 068545 ("mPhase") (each individually, "a Party" and,
collectively, "the Parties"}.

WHEREAS, mPhase wishes to use the Lucent Technologies name and Logo and the slogan TECHNOLOGY BY
LUCENT TECHNOLOGIES on printed circuit boards, product packaging and in printed marketing materials
("Approved Uses") in connection with its multi-access product (the "Goods") and Lucent wishes to
permit mPhase to do so.

NOW THEREFORE, the Parties, for good and valuable consideration, the receipt and sufficiency of
which are hereby acknowledged, agree as follows:

1. mPhase may apply only the exact logo shown on Schedule A of this Agreement (the "Lucent
Co-Branding Logo"} in Approved Uses for mPhase's Goods.

2. mPhase agrees to abide by the guidelines appearing on Schedule B of this Agreement specifying the
dimensions, requirements and specifications, and the review process related to use of the Lucent
Co-Branding Logo. mPhase understands that these guidelines may be updated from time to time and
agrees to abide by those updates as well as the guidelines provided herein.

3. In the event that mPhase's use of the Lucent Co-Branding Logo, in the sole judgment of Lucent,
may adversely affect Lucent's rights to the mark shown on Schedule A or the marks and names LUCENT,
LUCENT TECHNOLOGIES or LUCENT INNOVATION RING DESIGN, Lucent may upon written notification to
mPhase, terminate this Agreement.

4. mPhase agrees that it acquires no rights to the Lucent Co-Branding Logo nor to the marks LUCENT,
LUCENT TECHNOLOGIES or LUCENT INNOVATION RING DESIGN, by its use and that any use of the Lucent
Co-Branding Logo by mPhase inures to the benefit of Lucent.

5. mPhase agrees not to adopt any designation which is confusingly similar to the Lucent Co-Branding
Logo or Lucent's marks LUCENT, LUCENT TECHNOLOGIES or LUCENT INNOVATION RING DESIGN. Any attempt to
do so shall be a breach of this Agreement and Lucent may terminate this Agreement without notice in
the event of such a breach.

6. This Agreement shall terminate in the event of a significant change in the management or
ownership of mPhase or in the event mPhase is the subject of any bankruptcy proceedings.

7. Lucent is generally aware of the current quality of mPhase's Goods. mPhase agrees to maintain the
quality of its Goods associated with the Lucent Co-Branding Logo to a level of quality comparable to
the current quality of their Goods.

8. If Lucent determines that mPhase's Goods are no longer maintained at the current level of
quality, Lucent shall so notify mPhase, in writing, and Lucent shall have the right to terminate
this Agreement.

9. mPhase agrees to allow Lucent to inspect the Approved Uses bearing the Lucent Co-Branding Logo,
to ensure that those uses reviewed and approved pursuant to the procedure set forth in Schedule B
continue to be in compliance with the terms of this Agreement.

10. In the event that mPhase becomes aware of any unauthorized use of the Lucent Co-Branding Logo or
other Lucent marks by third parties, mPhase agrees to promptly notify Lucent and to cooperate fully,
at Lucent's expense, in any enforcement of Lucent's rights against such third

Source: MPHASE TECHNOLOGIES INC, 10-K, 9/11/2003
<!-- page 2 -->
parties. Nothing contained in this paragraph shall be construed to require Lucent to enforce any
rights against third parties or to restrict Lucent's rights to license or consent to such third
parties' use of the Lucent Co-Branding Logo or any other Lucent marks.

11. The Term of this Agreement will commence on the date above, and shall continue for a term of one
(1) year. mPhase shall have the right to annually renew this agreement for a period of one year upon
each annual expiration with the written consent of Lucent, which written consent shall not be
unreasonably withheld. Either party wishing to terminate the Agreement must give written notice to
the other party at least thirty (30) days prior to the desired date of termination.

12. Upon termination of this Agreement, mPhase shall immediately cease use of the Lucent Co-Branding
Logo, provided, however, that mPhase shall have no obligation to remove such Co-Branding Logo from
any Goods sold prior to the date of such termination.

-2-

13. Neither Party shall be liable to the other for special, incidental, or consequential damages,
even if such Party has been advised of the possibility of such damages.

14. This Agreement shall not be assigned by mPhase without the prior written consent of Lucent.

15. The validity, construction and performance of this Agreement shall be governed by the laws of
the State of New York.

16. This Agreement, including the Schedules and Addenda hereto, constitutes the entire Agreement
between the Parties concerning the subject matter hereof and supersedes all proposals, oral or
written, all negotiations, conversations, and/or discussions between the Parties relating to this
Agreement and all past courses of dealing or industry customs.

IN WITNESS WHEREOF, the Parties by their duly authorized representatives, have executed this
Agreement on the respective dates indicated below.

Lucent Technologies Inc. mPhase, Inc.

By: /s/ D. Laurence Padilla By: /s/ Ron Durando ----------------------- ---------------------- D.
Laurence Padilla Ron Durando President - Chief Executive Officer Intellectual Property Business

Date: 1/28/03 Date: 01/21/03 ----------------------- ----------------------

-3-

Schedule A ----------

------------------

Technology By

[graphic] Lucent Technologies

------------------

-4-

Source: MPHASE TECHNOLOGIES INC, 10-K, 9/11/2003
<!-- page 3 -->
Schedule B ----------

Co-Branding Guidelines

Control Specifications

o Consistent with our guidelines, 'Bell Labs Innovations' from the Lucent Logo can never appear on
co-branded offers.

o The 2-logos of each company can never be combined to form a compositE logo or suggest the "two
company's" are part of one company.

o Our Logo must always maintain a staging of 1/2 the diameter of the Innovation Ring of clearspace.

o The Lucent Logo may be reproduced in black or with the Innovation Ring in Lucent Red with black
type.

o The Lucent co-branding Art shown in Schedule A above may not be altered in any way from the form
in which it is provided to mPhase by Lucent Technologies.

o Since our mark is prominent, it is important that a form of each new or initial use of the Lucent
Co-Branding Logo be reviewed individually prior to implementation. Although mPhase may receive
Co-branding approval for one application, it has not been granted 'blanket use' of the Co-Branding
Logo or the Lucent Marks on all other applications.

o Samples of each new or initial use of the Lucent Co-Branding Logo should be sent to Corporate
Identity, Lucent Technologies, Attn: Bob Cort, Room 3A 405, 600 Mountain Avenue, Murray Hill, NJ
07974-0636; and to Lucent Technologies Inc., Attn: Trademarks & Copyrights, Room 2F 181, 600
Mountain Avenue, Murray Hill, NJ 07974-0636 for approval prior to any use of the materials.

-5-

Source: MPHASE TECHNOLOGIES INC, 10-K, 9/11/2003
