"""Router (PLAN Phase 4): decide single | breadth | long_context.

The model proposes (prompts/router.md, JSON with one repair); the harness enforces:
  * default `single`.
  * `breadth` needs sub_questions; if the model gave none, doc batches of FANOUT_BATCH_SIZE are
    built from the first-move candidates so Approach 3 has a contract to run.
  * `long_context` only if the first move's candidate evidence is under LONG_CONTEXT_MAX_TOKENS;
    otherwise it is downgraded to `single` with the reason recorded in the rationale.
A failed or skipped model call yields `single`.
"""
from __future__ import annotations

import time
from typing import Any

from langchain_core.messages import HumanMessage
from pydantic import BaseModel, Field

from ..config import DEFAULT, Config
from ..models import FirstMoveResult, RouteDecision, RouteMode
from ..prompts import load
from ..structured import ModelCaller
from ..trace import Trace
from ..workspace import Workspace


class RouteJSON(BaseModel):
    mode: str = "single"
    rationale: str = ""
    sub_questions: list[str] = Field(default_factory=list)


def route(ws: Workspace, question: str, fm: FirstMoveResult | None, caller: ModelCaller | None,
          config: Config = DEFAULT) -> RouteDecision:
    proposed = RouteJSON()
    if caller is not None:
        got = caller.json([HumanMessage(content=load(
            "router", n_docs=len(ws.manifest), question=question, max_units=config.agents.FANOUT_UNITS_MAX,
            opening_observation=fm.opening_observation if fm else "(no first move)",
        ))], RouteJSON)
        if got is not None:
            proposed = got
    return apply_guards(proposed, fm, config)


def apply_guards(proposed: RouteJSON, fm: FirstMoveResult | None, config: Config = DEFAULT) -> RouteDecision:
    mode = proposed.mode.strip().lower()
    rationale = proposed.rationale.strip()
    est = fm.estimated_candidate_tokens if fm else None
    if mode not in {m.value for m in RouteMode}:
        rationale = f"unknown mode {mode!r}; defaulting to single. {rationale}".strip()
        mode = "single"
    if mode == "long_context" and (fm is None or est is None or est >= config.agents.LONG_CONTEXT_MAX_TOKENS):
        rationale = (f"long_context refused: candidate evidence ~{est} tokens >= {config.agents.LONG_CONTEXT_MAX_TOKENS}"
                     if est is not None else "long_context refused: no first move") + f". {rationale}"
        mode = "single"
    subs = [s.strip() for s in proposed.sub_questions if s.strip()][: config.agents.FANOUT_UNITS_MAX]
    batches: list[list[str]] = []
    if mode == "breadth" and not subs:
        ids = fm.candidate_doc_ids if fm else []
        size = config.agents.FANOUT_BATCH_SIZE
        batches = [ids[i : i + size] for i in range(0, len(ids), size)][: config.agents.FANOUT_UNITS_MAX]
        if not batches:
            rationale = f"breadth without sub-questions or candidates; defaulting to single. {rationale}".strip()
            mode = "single"
    return RouteDecision(mode=RouteMode(mode), rationale=rationale, sub_questions=subs if mode == "breadth" else [],
                         doc_batches=batches, estimated_evidence_tokens=est)


def run_router(ws: Workspace, question: str, fm: FirstMoveResult | None, config: Config = DEFAULT,
               llm: Any | None = None, trace: Trace | None = None, deadline_ts: float | None = None) -> RouteDecision:
    if llm is None:
        from ..llm import get_llm

        llm = get_llm("router")
    t0 = time.perf_counter()
    caller = ModelCaller(llm, trace, "route", "router", deadline_ts=deadline_ts)
    decision = route(ws, question, fm, caller, config)
    if trace:
        trace.stage("route", "end", mode=decision.mode.value, n_sub_questions=len(decision.sub_questions),
                    n_batches=len(decision.doc_batches), est_tokens=decision.estimated_evidence_tokens,
                    ms=int((time.perf_counter() - t0) * 1000))
    return decision
