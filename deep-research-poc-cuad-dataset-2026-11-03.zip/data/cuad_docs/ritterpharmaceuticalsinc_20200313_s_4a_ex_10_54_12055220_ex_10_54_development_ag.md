<!-- page 1 -->
# DISTRIBUTION AND DEVELOPMENT AGREEMENT
| Field | Value |
|---|---|
| Document Type | Development Agreement |
| Agreement Date | 2016-05-01 |
| Parties | Sekisui Diagnostics, LLC and its Affiliates ("Sekisui"); Qualigen, Inc. and its Affiliates ("Qualigen") |
| Source | CUAD v1 / RitterPharmaceuticalsInc_20200313_S-4A_EX-10.54_12055220_EX-10.54_Development Agreement |

Exhibit 10.54 DISTRIBUTION AND DEVELOPMENT AGREEMENT This Distribution and Development Agreement
(this "Agreement") is made and entered into as of May 1, 2016 by and between Sekisui Diagnostics,
LLC and its Affiliates, a Delaware limited liability company with principal offices at 4 Hartwell
Place, Lexington, Massachusetts 02421 ("Sekisui"), and Qualigen, Inc. and its Affiliates, a Delaware
corporation with principal offices at 2042 Corte Del Nogal, Carlsbad, California 92011 ("Qualigen"
and together with Sekisui, each a "Party" and together the "Parties"). WHEREAS, Qualigen is engaged
in the manufacture, supply and development of certain clinical rapid diagnostic test devices and
controls; and WHEREAS, Qualigen wishes to appoint Sekisui as its exclusive distributor for such
products in the Territory (as defined below); and WHEREAS, Sekisui wishes to be appointed as the
exclusive distributor of such products and to fund the development of certain future products. NOW,
THEREFORE, in consideration of the mutual covenants hereinafter contained, the parties hereto agree
as follows: 1. Definitions 1.1. Adverse Event shall mean an incident in which the Product was
alleged to have caused or contributed to the death or serious injury of a patient or operator and
would require submitting a Medical Devices Report to the FDA (as hereinafter defined) as per 21 CFR
803, or a similar report to a Competent Authority (as hereinafter defined) as per Vigilance Guidance
MEDDEV 2.12-1. 1.2. Affiliate shall mean, (i) with respect to Qualigen, any corporation or other
form of business organization, which directly or indirectly owns, controls, is controlled by, or is
under common control with Qualigen, and (ii), with respect to Sekisui, shall mean Sekisui
Diagnostics (UK) Ltd., Sekisui Diagnostics PEI, Inc., SEKISUI MEDICAL CO., LTD., and Sekisui
Diagnostics GmbH. An entity shall be regarded as being in control of another entity if the former
entity has the direct or indirect power to vote more than fifty percent (50%) of the outstanding
voting securities (or other ownership interest for a business organization other than a corporation)
of that entity, or the direct or indirect ability to direct or cause the direction of the general
management and policies of the other entity. 1.3. Applicable Markets shall mean the United States,
Canada, the European Union, Japan and other additional geographies that are added from time to time
at the request of Sekisui, but only to the extent that it is commercially reasonable for Qualigen to
expand to such additional geographies. 1.4. Available Margin is defined on Exhibit A. 1.5. Business
Plan shall mean the business plan attached as Exhibit B hereto, which business plan may be amended
from time to time by mutual agreement of Qualigen and Sekisui. 1.6. COGS is defined on Exhibit A.

Source: RITTER PHARMACEUTICALS INC, S-4/A, 3/13/2020
<!-- page 2 -->
1.7. Competent Authority shall mean the governmental authority in a member state of the European
Union which has competence in relation to the Products. 1.8. Development Plan shall mean the
development plan attached as Exhibit C hereto, which development plan may be amended from time to
time by mutual agreement of Qualigen and Sekisui. 1.9. Effective Date shall mean May 1, 2016. 1.10.
European Union shall mean the countries in Europe that are under the CE mark regulatory regime.
1.11. Exclusivity Period shall mean the period from the Effective Date until December 31, 2018.
1.12. FDA shall mean the U.S. Food and Drug Administration or any successor agency. 1.13. Health
Canada shall mean the department of the government of Canada with responsibility for national public
health. 1.14. Intellectual Property Rights means all intellectual property rights in any
jurisdiction worldwide, including, without limitation: (a) Patent Rights; (b) rights associated with
works of authorship including copyrights, copyright applications, and copyright registrations; (c)
rights relating to the protection of trade secrets, know-how or confidential information; and (d)
rights in any trade names, trademarks, service marks, domain names, logos, trade dress and brand
features. 1.15. Net Revenue is defined on Exhibit A. 1.16. Patent Rights means all patents, patent
applications and inventions on which patent applications are filed and all patents issuing therefrom
worldwide, together with any extensions, registrations, confirmations, reissues, continuations,
divisionals, continuations- in-part, re-examination certificates, substitutions or renewals,
supplemental protection certificates, term extensions (under applicable patent law or other law),
provisional rights and certificates of inventions. 1.17. Potentially Serious Complaint shall mean
any information coming to the notice of Qualigen or Sekisui which might relate to a Serious Incident
(as hereinafter defined), or to a significant lapse in the quality of the Products, or might lead to
significant adverse public or media comment, or otherwise significantly, adversely affect the
reputation or business of Sekisui or Qualigen. 1.18. Products shall mean all of Qualigen's current
and future products, including without limitation those listed on Exhibit D, for sale under the
trade names listed with such products, including any improvements thereto. 1.19. Qualigen Retained
Customers shall mean certain of Qualigen's existing direct sales customers, all as listed on Exhibit
E. 1.20. Regulatory Approval shall mean the approval of the applicable Regulatory Authority required
for the promotion, marketing, distribution and/or sale of the Products in any territory in which
they are being sold, including any Product registration or license, and any supplement, amendment or
variation thereto, required before the commencement of commercial sales of the Products in such
territory, and export and import approvals for the Products. 2

Source: RITTER PHARMACEUTICALS INC, S-4/A, 3/13/2020
<!-- page 3 -->
1.21. Regulatory Authorities shall mean the FDA, each Competent Authority, Health Canada and the
Japanese Pharmaceuticals and Medical Devices Agency. 1.22. Revenue Affiliate shall mean any entity
of which Sekisui has the direct or indirect power to vote more than fifty percent (50%) of the
outstanding voting securities (or other ownership interest for a business organization other than a
corporation) of that entity, or the direct or indirect ability to direct or cause the direction of
the general management and policies of that entity. 1.23. Sale Transaction shall mean (i) any
transaction in which Qualigen, Qualigen's business or control of Qualigen is acquired, (ii) any
license, sale, lease, transfer, or other disposition, in a single transaction or series of related
transactions, of all or substantially all of Qualigen's assets other than in the ordinary course of
business, (iii) any sale of a majority of the outstanding shares of capital stock of Qualigen, (iv)
any sale or license of any rights to any Qualigen products, now or hereafter existing, other than in
the ordinary course of business, (v) any liquidation or dissolution of Qualigen, (vi) any similar
transaction resulting in a change of control of Qualigen, or (vii) any of the foregoing with respect
to any now or hereafter existing subsidiary of Qualigen which holds, on a consolidated basis, all or
substantially all of Qualigen's assets (i.e., of the assets of Qualigen and all its Affiliates
considered together). 1.24. Serious Incident shall mean an incident involving the Products, which is
reportable to a Competent Authority and as defined in Section 5 of Annex III of the IVD Directive,
and the European Commission Medical Devices Vigilance Guidelines 2.12-1 or such other Guidelines as
may be issued from time to time. 1.25. Territory shall mean worldwide excluding Qualigen Retained
Customers. 1.26. Third Party shall mean a party other than Sekisui or Qualigen or any Affiliate of
Sekisui or Qualigen. 2. Appointment and Term 2.1. Appointment. Qualigen hereby appoints Sekisui, and
Sekisui accepts the appointment to act on an exclusive basis pursuant to the terms and conditions of
this Agreement, as a distributor for the sale of the Products in the Territory. Sekisui shall be
permitted to appoint sub-distributors in the Territory (including any current Qualigen distributors)
with the approval of Qualigen, not to be unreasonably withheld or delayed. Sekisui shall purchase
the Products exclusively from Qualigen, and Qualigen shall supply the Products exclusively to
Sekisui, in each case for the Territory. Qualigen shall assign to Sekisui Qualigen's agreements with
Qualigen's current distributors (such that such current Qualigen distributors shall become Sekisui
subdistributors), each of which is set forth on Schedule 2.1 hereto; if any of such agreements do
not allow such assignment and the current distributor declines to consent to such an assignment to
Sekisui, Qualigen shall (if Sekisui so requests) act pursuant to such agreement to terminate such
agreement. 2.2. Term. The initial term of this Agreement shall commence on the Effective Date and
shall continue for a period of five (5) years unless earlier terminated pursuant to Section 14
hereof (the "Term"). The initial term of this Agreement and any renewal term thereof shall be
automatically extended at the end of the initial term and any renewal term thereof for an additional
one (1) year period unless either Party notifies the other Party not less than six (6) months before
the end of the then in effect term of its intent to terminate this Agreement. References in this
Agreement to "Term" shall be deemed to include the initial five (5) year term as well as a reduction
or extension of that time period that may occur as a result of the provision of this Section 0 or
the provisions of Section 14. 3

Source: RITTER PHARMACEUTICALS INC, S-4/A, 3/13/2020
<!-- page 4 -->
2.3. Customer Product Rentals. All instruments placed with customers under a rental program during
the Term shall be owned by Sekisui ("Sekisui Instruments"), while Qualigen shall retain ownership of
instruments placed with customers under a rental program before the execution of this Agreement
("Qualigen Instruments") and any instruments (including FastPack® 2.0) placed by Qualigen to the
Qualigen Retained Customers. 2.4. Qualigen Retained Customers. In addition to the retention of the
Qualigen Instruments, Qualigen shall be permitted to continue selling the existing Qualigen products
directly to the Qualigen Retained Customers. However, Qualigen shall not engage any distributors
(whether exclusive or non-exclusive) other than Sekisui for the Qualigen Retained Customers. Sekisui
shall not, and shall cause its subdistributors not to, market, rent or sell any Products to the
Qualigen Retained Customers. 3. Supply; Orders 3.1. Supply. Qualigen shall supply Sekisui with all
of Sekisui's commercial requirements for the Product in the Applicable Markets. All Products
supplied by Qualigen to Sekisui shall have on the date of shipment by Qualigen a shelf life of not
less than a minimum three (3) month shelf life for products shipped within the United States and not
less than a minimum four (4) month shelf life for products shipped outside the United States (or
such longer shelf-life as may be mutually agreed by Qualigen and a Sekisui customer with respect to
a specific customer order). Qualigen shall use reasonable efforts to assure that the Products, as
manufactured by Qualigen, conform to the applicable product specifications and requirements of the
Regulatory Authorities in, and are manufactured in accordance with all Regulatory Approvals, laws
and regulations applicable to the Products in the Applicable Markets. Qualigen shall maintain the
necessary records to comply with all Regulatory Approvals and other applicable rules and regulations
in the Applicable Markets. 3.2. Forecast. Sekisui shall submit to Qualigen by the fifth day of each
calendar month a rolling twelve (12) month (month-by-month) forecast of the quantity of each Product
that Sekisui anticipates selling during the following twelve (12) months (the "Forecast"). As to
Reagent Kits each respective Forecast shall represent reasonable estimates to be used for planning
and inventory stocking purposes as indicated in Exhibit D, and shall not be binding on Sekisui;
provided, however, that as to Instruments the quantities for each of the first three months of each
respective Forecast shall be deemed to constitute and shall constitute firm, binding orders for such
quantities of Instruments in such respective months (but in no event for a lesser quantity for a
month than the quantity for such month which, pursuant to an earlier Forecast, had already become a
firm, binding order). 4

Source: RITTER PHARMACEUTICALS INC, S-4/A, 3/13/2020
<!-- page 5 -->
3.3. Orders. Orders shall be processed as set forth in Exhibit F. Each purchase order shall be
governed by the terms and conditions of this Agreement (regardless of whether such purchase order
references the Agreement). Sekisui shall be allowed to, for convenience, document its purchase
orders by using Sekisui's standard form of purchase order, but in no event shall anything in such
purchase order vary, contradict or augment the terms of this Agreement, and the parties agree that
any "preprinted" provisions in the purchase orders shall, if they are inconsistent with or additive
to this Agreement, simply be disregarded and shall be deemed inapplicable and/or rejected
(regardless of acceptance, performance or apparent acquiescence, none of which shall constitute or
be construed to constitute Qualigen's or Sekisui's consent to or recognition of terms, conditions or
provisions that are different from or are not contained in this Agreement), unless in a separate and
nonboilerplate agreement which expressly identifies and waives this Section 3.3 Qualigen agrees to
accept such "preprinted" term. Similarly, Qualigen shall be allowed to, for convenience, document
its acknowledgements, confirmations and similar instruments by using Qualigen's standard form of
acknowledgement, confirmation and similar instruments, but in no event shall anything in such
acknowledgements, confirmations and similar instruments vary, contradict or augment the terms of
this Agreement, and the Parties agree that any "preprinted" provisions in the acknowledgements,
confirmations and similar instruments shall, if they are inconsistent with or additive to this
Agreement, simply be disregarded and be deemed inapplicable and/or rejected (regardless of
acceptance, performance or apparent acquiescence, none of which shall constitute or be construed to
constitute Qualigen's or Sekisui's consent to or recognition of terms, conditions or provisions that
are different from or are not contained in this Agreement), unless in a separate and nonboilerplate
agreement which expressly identifies and waives this Section 3.3 Sekisui agrees to accept such
"preprinted" term. 3.4. Product Records. Qualigen shall test or cause to be tested each lot of
Product purchased by Sekisui. Qualigen shall provide Sekisui with copies of any Product test records
requested or Sekisui may audit Qualigen to review the Product test records. 3.5. No Alterations or
Mishandling. Sekisui shall not, and shall also cause its subdistributors not to, alter or modify (or
add to or subtract from) in any way any Products delivered by Qualigen hereunder. Sekisui shall, and
shall also cause its subdistributors to, handle, store and transport the Products in accordance with
Qualigen's guidelines and shall not, and shall also cause its subdistributors not to, subject such
Products to abuse, mishandling or unusual physical, thermal, chemical or electrical stress or sell
any Product after its expiration date. 3.6. Packaging and Labeling. The Products shall be delivered
by Qualigen, and Sekisui shall cause the Products to be delivered to end users, in Qualigen
packaging and with Qualigen labeling, all as intended to be received by the end user. Such packaging
and labeling (and the Products themselves) (and "product inserts," which Qualigen may provide online
so long as it is done in compliance with all legal requirements of the applicable jurisdiction)
shall include such Qualigen trade names, brand names, trademarks and logos (and patent notices) as
Qualigen shall select and with such size, colors, positioning and prominence as Qualigen shall
select in its sole discretion, and shall not include any Sekisui trade names, brand names,
trademarks or logos (except that, if so required by applicable law, Qualigen shall include a
statement that Sekisui is the distributor and/or that Sekisui is the importer). Sekisui shall not
imprint or affix any of its (or any non-Qualigen person's) trade names, brand names, trademarks or
logos to any Product or its packaging or labeling, and shall also cause its subdistributors not to
do so. Sekisui shall not deface, cover, obscure, erase, alter or remove any Qualigen trade names,
brand names, trademarks or logos (or patent notices) applied by Qualigen to the Products or to the
Products' packaging or labeling, and shall also cause its subdistributors not to do so. 5

Source: RITTER PHARMACEUTICALS INC, S-4/A, 3/13/2020
<!-- page 6 -->
4. Price, Shipment and Payment 4.1. Price. The price that Sekisui shall pay for the Products shall
be established separately for the Reagent Kits and for the products other than Reagent Kits. The
price that Sekisui shall pay for the Reagent Kits Products shall be based upon a formula intended to
ensure that Sekisui will receive 90% of the total Available Margin for all Products during the first
12 months of this Agreement, 70% of the total Available Margin for all Products during months 13-24
of this Agreement, and 65% of the total Available Margin for all Products thereafter. Accordingly,
the prices (established separately for the Reagent Kits and for the products other than Reagent
Kits) to be paid by Sekisui for the Products shall be fixed (subject to a later lookback true up)
for each respective prospective six month period in the manner set forth in Exhibit D. The initial
prices Sekisui agrees to pay for the respective Products for the first such prospective "six month
period" (in this instance actually a five month period: May-September 2016) shall be fixed (subject
to a later lookback true up) in the manner set forth in Exhibit D. Thereafter such prices shall be
revisited and recalculated (prospectively) every six months in the manner set forth in Exhibit D
(i.e., for purposes of such calculations for establishing the new prospective prices for the reagent
products, the applicable Net Revenue, COGS and Available Margin shall be the Net Revenue, COGS and
Available Margin for the applicable historical 6-month period as defined in Exhibit D). In addition,
on a semi-annual basis, such amount shall be reviewed based on the actual Net Revenue, COGS and
Available Margin for the 6 months then ended. In the event that such review results in a difference
from the intended share of Available Margin between the Parties as contemplated above, the Parties
shall make a true up payment between them in order to compensate for such overpayment or shortfall,
all as provided in Exhibit D. Any true-up payments shall be paid by the applicable Party within 30
days of the receipt of an invoice for the agreed to true up amount. Sekisui shall set the customer
selling prices in good faith and in a commercially reasonable manner. 4.2. Shipment. The shipment of
orders to Sekisui's customers shall be subject to the ability of Sekisui and Qualigen to obtain all
required licenses and permits then in effect. Qualigen agrees (i) to assist Sekisui in obtaining
such required licenses or permits, (ii) to comply with all Regulatory Approvals in, including all
approvals and licenses necessary to import the Product into, the Applicable Markets, and (iii) to
maintain the necessary records to comply with all Regulatory Approvals and other applicable rules
and regulations in the Applicable Markets. Qualigen shall not be subject to unreasonable requests
for assistance in applying for Regulatory Approvals such as providing original or proprietary
documents, submitting free product samples or extensive translations. All Product ordered by
Sekisui's customers shall be suitably packed for shipment and storage by Qualigen on behalf of
Sekisui in accordance with Qualigen's standard commercial shipping practices. Each order shall be
shipped as designated by Sekisui's customers in the order. If the carrier noted on the Sekisui
customer's purchase order is not available, or if the purchase order does not designate a carrier,
then Sekisui shall select the mode of shipment or, if Sekisui does not select the mode of shipment,
Qualigen shall select the mode of shipment. Qualigen's responsibility shall be to deposit the
ordered goods with the designated carrier within the shipping periods specified, and Qualigen shall
not be liable for late delivery if so accomplished. 4.3. Delivery Terms. Qualigen shall deliver
Products ordered by Sekisui, FCA (Incoterms 2010) Qualigen's facility in Carlsbad, California. Title
to Products ordered by Sekisui shall pass to Sekisui upon delivery to the designated Sekisui
storeroom at Qualigen's facility. While held at the Sekisui storeroom, any physical inventory loss
will be the responsibility of Qualigen. Sekisui undertakes that all Sekisui inventory of Products
shall be kept at such designated Sekisui storeroom at Qualigen's facility, until resale to Sekisui's
customers. 6

Source: RITTER PHARMACEUTICALS INC, S-4/A, 3/13/2020
<!-- page 7 -->
4.4. Sales Expense; Business Plan. For the avoidance of doubt, Sekisui shall be responsible for all
sales and related sales expense except for Qualigen Retained Customers. The Business Plan sets forth
Sekisui's plans for the sale and distribution of the Products, including target budget and resource
allocations for the marketing and sales of the Products and estimated forecasts of sales to
customers. Sekisui shall in good faith use commercially reasonable efforts, in conformance with good
commercial practice and standards, government regulations and other applicable requirements, to
promote, market and sell the Products, to execute the Business Plan and to achieve its objectives.
Except as set forth in Section 3.2, such forecasts and budgets are intended for guidance purposes
only and are not binding obligations. Sekisui shall be responsible for bad debt (customer
nonpayment) and credit card merchant fees and expenses. 4.5. Financing Payments; Development Plan.
In addition to the payments for the purchase of Products set forth in Section 4.1 above, in
connection with this Agreement and in furtherance of the Development Plan, Sekisui shall provide to
Qualigen up to $6,200,000 of financing in accordance with the timing and other provisions of the
Development Plan and the achievement of the applicable milestones set forth therein (the "Financing
Payments"). All such Financing Payments shall be used in accordance with the Development Plan and
shall be non-refundable once paid, other than as set off in connection with a Sale Transaction as
further described below. Time is of the essence for the payment by Sekisui of the resulting
Financing Payments upon confirmation of achievement by Qualigen of the respective Development Plan
milestones as set forth in Section 6.2 and the Development Plan. 4.6. Personnel Matters. Sekisui
shall offer employment to four Qualigen sales representatives to become employees of Sekisui with
primary responsibility for the sale of the Products, and Qualigen hereby consents to and permits
such employment. Such offers of employment are subject to Sekisui's employment policies, including
the successful completion of customary background checks, and are not a guarantee of ongoing
employment. Upon the expiration or termination of the Term (other than in connection with a Sale
Transaction in which Sekisui acquires Qualigen), Sekisui shall cooperate in permitting Qualigen to
offer to rehire any Sekisui sales representatives who are primarily responsible for selling the
Products. A sales person "primarily responsible for selling the Products" is one that spends more
than half of his or her time and receives more than half of his or her commission based compensation
based on sales of the Products. 4.7. Invoice Terms. Sekisui shall pay for each Product sold by
Qualigen within 30 days after Sekisui has received the applicable invoice from Qualigen. 4.8.
Marketing Claims. Sekisui covenants to Qualigen that Sekisui will not make any written or oral
representation or marketing claim (either formal or informal) about any Product's capabilities or
characteristics other than those representations and claims that are fully and directly supported by
factual materials provided by Qualigen to Sekisui. Sekisui shall not make any false or misleading
representations to customers or others regarding Qualigen or the Products. Sekisui shall not make
any representations, warranties or guarantees with respect to the specifications, features or
capabilities of the Products that are not contained within Qualigen's documentation accompanying the
Products or Qualigen's literature describing the Products, including Qualigen's standard limited
warranty and disclaimers. 7

Source: RITTER PHARMACEUTICALS INC, S-4/A, 3/13/2020
<!-- page 8 -->
4.9. Taxes. Qualigen's stated Product prices do not include any foreign, federal, state or local
sales taxes that may be applicable to the Products, but in the event that such sales taxes are
applicable and Qualigen has the legal obligation to collect such sales taxes (or are sales taxes
imposed on a seller), Qualigen shall be entitled to add to its invoice the amount of such sales
taxes and Sekisui shall pay such amount unless Sekisui provides Qualigen with a valid tax exemption
certificate authorized by the appropriate taxing authority. As between the Parties, all customs
duties shall be the responsibility of Sekisui, and all duty expenses will be included as an element
of COGS as referenced in Exhibit A and will be included as part of the Actual Margin True-Up as
defined in Exhibit D. The parties agree to cooperate with one another and use reasonable efforts to
avoid or reduce tax withholding or similar obligations in respect of Financing Payments, Product
purchase payments, and other payments made by Sekisui to Qualigen under this Agreement. To the
extent Sekisui is required to withhold taxes on any payment to Qualigen, Sekisui shall pay the
amounts of such taxes to the proper governmental authority in a timely manner and promptly transmit
to Qualigen evidence of such payment and/or an official tax certificate, or such other evidence as
Qualigen may reasonably request, to establish that such taxes have been paid. Qualigen shall provide
Sekisui any tax forms that may be reasonably necessary in order for Sekisui to not withhold tax or
to withhold tax at a reduced rate under an applicable bilateral income tax treaty. Each Party shall
provide the other with reasonable assistance to enable the recovery, as permitted by applicable law,
of withholding taxes, value added taxes, or similar obligations resulting from payments made under
this Agreement, such recovery to be for the benefit of the Party bearing such withholding tax or
value added tax. 4.9.1. Medical Device Tax. The party responsible for paying any applicable medical
device excise tax pursuant to Section 4191 of the U.S. Internal Revenue Code or any successor
thereto will be as determined under such tax provisions. If any, such medical device excise tax will
be treated as a cost element to be included in COGS as referenced in Exhibit A. 4.10. Interest.
Accrual and payment of interest shall not be deemed to excuse or cure breaches of contract arising
from late payment or nonpayment. Cumulative with and not exclusive of any and all other available
remedies, payments that are more than 30 days past due hereunder, and which are not otherwise
subject to a good faith dispute, shall accrue interest, from the due date until paid, at an annual
rate equal to the prime rate, as reported in The Wall Street Journal, Eastern U.S. Edition, on the
date such payment is due, plus an additional 200 basis points (2%). 4.11. Currency. All invoices
under this Agreement shall be paid in United States dollars. 5. Manufacturing and Quality Assurance
5.1. Manufacturing Conformance. Qualigen represents and warrants that it shall manufacture all
Products in accordance with the applicable product specifications and all applicable federal, state
and local laws, regulations, and guidelines. Qualigen represents and warrants that no Product
delivered by Qualigen under this Agreement will be adulterated or misbranded within the meaning of
21 U.S.C. Sections 351-352, or within the meaning of any other applicable law as such laws are
constituted and effective at the time of such shipment or delivery. Qualigen shall maintain
appropriate certification status and compliance with the FDA's Quality System Regulation, the
Directive of 27 October 1998 on In Vitro Diagnostic Medical Devices (IVDD) and/or all other
applicable regulations. Upon request, Qualigen shall furnish to Sekisui any such information
required to enable Sekisui to comply with all applicable regulations and standards that pertain to
distributors for the Products. 5.2. Manufacturing Changes. Qualigen shall notify Sekisui in writing
no less than 3 months prior to any material changes which affect (i) the form, fit or function of
any Products, or (ii) the labeling or regulatory status of the Products in any of the Applicable
Markets. 5.3. Manufacturing Site. During the Term, Qualigen shall manufacture all Products using
Qualigen's facilities located in Carlsbad, California. Qualigen shall give at least six (6) months
prior written notice to Sekisui of any proposed relocation of the manufacturing of any Product. Any
new facility proposed to be used by Qualigen in manufacturing any Product shall be subject to a new
and separate audit by Sekisui personnel in accordance with Quality Systems Regulations (QSR), as
well as ISO 13485. 8

Source: RITTER PHARMACEUTICALS INC, S-4/A, 3/13/2020
<!-- page 9 -->
5.4. Approved Supplier. It is acknowledged that Qualigen is an "Approved Supplier" as to Products
manufactured at Qualigen's Carlsbad, California facility. As part of Sekisui's supplier approval
program, Sekisui will have the option to perform an audit (applying Sekisui's standard supplier
criteria for qualification as an "Approved Supplier") at Qualigen's Carlsbad, California
manufacturing facility annually and at each relocated manufacturing facility at which Qualigen will
manufacture the Products within sixty (60) days of Qualigen's notice to Sekisui of the relocation of
such manufacturing facility. Within thirty (30) days after the completion of an audit, Sekisui shall
inform Qualigen in writing of the results of such audit. If Qualigen does not pass such audit and
the reasons for such failure can be remedied within a reasonable period of time (which shall not be
less than sixty (60) days), then Sekisui shall provide Qualigen with a list of proposed remedial
action items and a proposed timeframe within which to accomplish such action items. If Qualigen does
not pass such audit and the reasons for such failure cannot be remedied within a reasonable period
of time or Qualigen fails or elects not to complete any remedial actions reasonably suggested by
Sekisui, then Sekisui's sole and exclusive remedy shall be to terminate this Agreement in accordance
with the provisions of Section 14 of this Agreement, with such termination to be effective upon
receipt of a termination notice by Qualigen sent by Sekisui at any time after the sixty day remedy
period described in this Section 5.4 has passed. As scheduled, Sekisui may perform an audit during
reasonable business hours to confirm ongoing compliance with the Quality System Regulations and
confirm adequate process controls. Sekisui shall notify Qualigen at least one month in advance of a
planned audit and Qualigen shall make reasonable efforts to accommodate the desired schedule.
Sekisui further agrees that any information obtained from Qualigen or its Affiliates or agents in
connection with any such audit shall be deemed Qualigen Confidential Information and subject to the
provisions of Section 13 of this Agreement. 5.5. Technical Support. Qualigen shall provide to
Sekisui and its customers commercially reasonable technical support (i) for the promotion, sale,
after-sale service and support of Products sold in the Territory pursuant to this Agreement; (ii) in
connection with any customer inquiries or complaints and (iii) in connection with interactions with
the Regulatory Authorities. Qualigen shall be responsible for the management and costs of all such
service. Qualigen shall be entitled to charge customers for, and to retain, commercially reasonable
fees for service and support of out-of-warranty Instruments. 5.6. Trade Compliance. Upon execution
of this Agreement, Qualigen, with Sekisui's assistance, shall provide to Sekisui the Export
Commodity Control Number (ECCN) and Harmonized Tariff Codes (HTS), Country of Origin (COO), Trade
Agreement Act (TAA) and Buy America Act (BAA) determinations or other relevant information for any
Product supplied to Sekisui pursuant to this Agreement. 9

Source: RITTER PHARMACEUTICALS INC, S-4/A, 3/13/2020
<!-- page 10 -->
5.7. REACH and RoHS Compliance. If any Product supplied by Qualigen is manufactured in or imported
into the European Union, Qualigen shall, at its sole cost and expense, comply with applicable
requirements under Regulation (EC) 1907/2006 concerning the Registration, Evaluation, Authorization
and Restriction of Chemicals ("REACH"), and Directive 2011/65/EC concerning the Restriction of the
Use of Certain Hazardous Substances in Electrical and Electronic Equipment ("RoHS"), each as may be
amended from time to time. Upon reasonable request, Qualigen shall provide reasonable proof of
compliance with REACH and RoHS, including any registration, communication, safety data sheet,
chemical report, or technical or other supporting documentation. Qualigen represents and certifies
that it has gathered, or will gather, the compliance documentation information with appropriate
methods to ensure its accuracy and that such information is true, correct and complete to the best
of its knowledge and belief as of the date that Qualigen provides its declaration. Qualigen
acknowledges that Sekisui will rely on this certification in determining the compliance of the
Products with REACH and RoHS. Sekisui acknowledges that Qualigen may have relied on information
provided by Third Parties in completing its compliance review, and that Qualigen may not have
independently verified such information, provided that Qualigen has conducted appropriate due
diligence and its reliance on such Third Parties is reasonable and that Qualigen has no reason to
question the reliability of such Third Parties' information and certifications. Qualigen-controlled
manufacturing processes shall be in compliance with REACH and RoHS in that they do not add any
substances to the resultant Product to the extent currently prohibited by REACH and RoHS. Based upon
the information supplied by Third Parties along with Qualigen's knowledge of its own manufacturing
processes, Qualigen will certify that, to the best of its knowledge, each of the Products identified
in any certification is in compliance with the substance restrictions of REACH and RoHS or is exempt
from REACH and RoHS, unless Qualigen has advised Sekisui in advance that any Product or any material
incorporated into, or used to produce, any Product ("Material") do not comply with REACH or RoHS.
Qualigen has processes in place to ensure proper control of Materials declarations, and segregation
of ROHS- compliant and non-compliant Material within Qualigen's manufacturing processes. Qualigen
shall maintain REACH and RoHS records and compliance documentation for the amount of time required
under REACH or RoHS. Qualigen and Sekisui agree to promptly notify each other if either learns of
any developments relating to REACH or RoHS that might impact Sekisui's ability to use any Product or
place it on the market in the European Union. Qualigen agrees to notify Sekisui promptly: (1) if
there are changes to the REACH registration relevant to the Product; (2) if any of the substances,
preparations, or substances in articles purchased by Sekisui meet the criteria referred to in Art.
57 of REACH or are on the candidate list for eventual inclusion in Annex XIV of REACH; (3) if a
REACH registration has been rejected by the European Chemicals Agency (ECHA); or (4) of any other
development relating to any Product's status under REACH or RoHS where such development might affect
Sekisui's ability to use any Product or to place it on the market in the European Union. 6.
Management Committee 6.1. Management Committee. Each Party shall, within five (5) business days
after the Effective Date, designate four (4) representatives, at least one of whom shall have
sufficient authority to enable him or her to make decisions on behalf of the Party he or she
represents, to comprise the management committee (the "Management Committee") overseeing the
implementation and revision of the Business Plan and Development Plan. Each Party shall (A) promptly
notify the other Party in writing of any change in its appointed representatives; and (B) be solely
responsible for all travel-related costs and expenses for its respective representatives to attend
meetings or to otherwise participate in, or carry out its obligations under, the Management
Committee. The Qualigen representatives on the Management Committee shall initially be Paul
Rosinack, Michael Poirier, Chris Lotz and Shishir Sinha. The Sekisui representatives on the
Management Committee shall initially be Bob Schruender, Lee Lipski, Alan Bauer and Tom Cummins. 10

Source: RITTER PHARMACEUTICALS INC, S-4/A, 3/13/2020
<!-- page 11 -->
6.2. Meetings. The Management Committee shall be responsible for: (A) meeting quarterly unless
otherwise specified in writing by the Parties (in person or via phone/webmeeting) to monitor,
review, and discuss the progress under the Business Plan and Development Plan; (B) resolving
disputes or disagreements between the Parties with respect to the implementation of the Business
Plan and Development Plan; (C) coordinating the exchange of information between the Parties in
connection with the activities contemplated by the Business Plan, the Development Plan and this
Agreement; (D) confirming the achievement of any milestones resulting in an additional payment under
the Development Plan, and (E) carrying out any other responsibilities as are set forth in this
Agreement, or that are assigned to it by the Parties. Each Party may invite other representatives of
such Party to join any management committee meeting if it would be useful to have their input for a
particular agenda topic. For the avoidance of doubt, the Management Committee shall not have the
power to amend this Agreement or to waive a Party's compliance with the terms and conditions
contained in this Agreement. 6.3. R&D Subcommittee. The Management Committee shall also organize
research and development review meetings, which may include members of the Management Committee as
well as other representatives of either Party, meeting monthly unless otherwise specified in writing
by the Parties (in person or via phone/webmeeting) to monitor, review, and discuss the progress of
the development of future Products and manufacturing capability in accordance with the Development
Plan, including a review of all applicable data and an assessment of resources. 6.4. Quality
Subcommittee. The Management Committee may also organize quality review meetings, which may include
members of the Management Committee as well as other representatives of either Party, meeting
quarterly unless otherwise specified in writing by the Parties (in person or via phone/webmeeting)
to monitor, review, and discuss various aspects of Qualigen's quality assurance programs, including
a one day Quality program management review and one day of internal auditing of quality matters.
6.5. Other Subcommittees. The Management Committee may establish other subcommittees from time to
time as it deems appropriate. 7. Information Rights 7.1. Development Plan. Qualigen shall maintain
complete and accurate records and data regarding the work completed under the Development Plan.
Representatives of Sekisui may, upon reasonable advance notice, (a) visit the facilities where the
Development Plan activities are being performed, and (b) consult with any such Qualigen personnel
performing such activities. 7.2. Delivery of Financial Statements and Other Information. Qualigen
shall deliver to Sekisui: 7.2.1. as soon as practicable, but in any event within one-hundred eighty
(180) days after the end of each fiscal year of Qualigen (i) a balance sheet as of the end of such
year, (ii) a statement of income for such year, and (iii) a comparison between (x) the actual
amounts as of and for such fiscal year and (y) the comparable amounts for the prior year and as
included in Qualigen's budget for such year, with an explanation of any material differences between
such amounts, all such financial statements in the form of a compilation prepared by independent
public accountants; 7.2.2. as soon as practicable, but in any event within thirty (30) days after
the end of each quarter of each fiscal year of Qualigen, an unaudited statement of income for such
fiscal quarter, and an unaudited balance sheet as of the end of such fiscal quarter, all prepared in
accordance with GAAP (except that such financial statements may (i) be subject to normal year-end
audit adjustments; and (ii) not contain all notes thereto that may be required in accordance with
GAAP); 11

Source: RITTER PHARMACEUTICALS INC, S-4/A, 3/13/2020
<!-- page 12 -->
7.2.3. as soon as practicable, but in any event within thirty (30) days of the end of each month, an
unaudited income statement for such month, and an unaudited balance sheet as of the end of such
month, all prepared in accordance with GAAP (except that such financial statements may (i) be
subject to normal year-end audit adjustments and (ii) not contain all notes thereto that may be
required in accordance with GAAP); 7.2.4. as soon as practicable, but in any event within forty five
(45) days after the end of each quarter of each fiscal year of Qualigen, a progress report setting
forth Qualigen's business results and progress against the Development Plan; and 7.2.5. as soon as
practicable, but in any event no later than sixty (60) days before the end of each fiscal year, a
budget and business plan for the next fiscal year, prepared on a monthly basis, including balance
sheets and income statements. 8. Intellectual Property Rights 8.1. Background Intellectual Property
Rights. Each Party shall own and retain all right, title and interest in and to all of its
Intellectual Property Rights created before or independently from the Development Plan and this
Agreement ("Qualigen Background IP" and "Sekisui Background IP," respectively). 8.2. Development
Plan Intellectual Property Rights. Except as set forth in this Section, Qualigen shall own all
right, title and interest in and to all Intellectual Property Rights (if any) resulting from
Qualigen's activities under the Development Plan ("Development IP"), but excluding all Sekisui
Background IP. In the event that any Development IP is jointly invented by the Parties in accordance
with applicable intellectual property laws, then the ownership of such Development IP that has been
jointly invented shall be co-owned by the Parties in accordance with such applicable intellectual
property laws; provided, however, that neither Party shall have any duty or obligation to account to
the other for any use or exploitation of such jointly invented Development IP and as between the
Parties, each Party shall be entitled to retain any and all benefit, financial or otherwise, derived
by such Party from such jointly invented Development IP. 8.3. Prosecution and Enforcement of
Development IP. Except as set forth below, Qualigen shall have the sole right to prepare, file
applications on and registrations for, prosecute, obtain, maintain, defend and enforce all
Intellectual Property Rights in the Development IP in such manner as Qualigen deems appropriate in
its sole discretion, including incurring and paying all expenses required for such purposes.
Notwithstanding the foregoing, Qualigen shall use commercially reasonable efforts to preserve,
obtain and maintain in the Applicable Markets all material Development IP and Qualigen Background IP
related to or used in connection with the development and manufacturing of the Products as well as
any improvements or alternative embodiments thereof, and shall consult Sekisui before determining
not to pursue in any Applicable Market any particular Intellectual Property Rights related to any
product development efforts covered by the Development Plan. In the event that Qualigen elects not
to prosecute or maintain in a particular Applicable Market country any Patent Rights in the jointly
developed Development IP (the "Abandoned Joint IP"), Sekisui may elect to prosecute such Abandoned
Joint IP in such particular Applicable Market country, in which case the Patent Rights for such
Abandoned Joint IP in such particular in Applicable Market country shall be owned solely by Sekisui.
12

Source: RITTER PHARMACEUTICALS INC, S-4/A, 3/13/2020
<!-- page 13 -->
8.4. Marks. During and after the Term, neither Party shall register, use or claim ownership or other
rights in any logo, trade name, brand name or trademark of the other Party in existence during the
Term (nor any logo, trade name, brand name or trademark confusingly similar to any logo, trade name,
brand name or trademark of the other Party in existence during the Term), nor assist anyone else to
do so, nor make or assist in any challenge to any logo, trade name, brand name or trademark of the
other Party in existence during the Term. 9. Sale Transaction 9.1. Exclusivity Period. The parties
anticipate that they will entertain a potential acquisition of Qualigen by Sekisui during 2018 on
terms to be mutually agreed. Accordingly, Qualigen hereby agrees that during the Exclusivity Period,
Qualigen shall not, directly or indirectly, through its affiliates, agents, stockholders, officers,
directors or otherwise solicit, initiate, participate in discussions or negotiations or otherwise
cooperate in any way with, or provide any information to any person, entity or group other than
Sekisui concerning a Sale Transaction. In the event that Qualigen nonetheless receives an
unsolicited offer to engage in a Sale Transaction during such Exclusivity Period, Qualigen may
engage with such party to the extent legally required to comply with its fiduciary duties, so long
as Qualigen (i) promptly communicates to Sekisui the material terms of any proposal or offer or
request for information which it may receive in respect of any such proposed Sale Transaction,
including the purchase price, form and timing of consideration and the identity of the acquirer, and
(ii) complies with Sekisui's Right of First Refusal (as defined below). 9.2. Negotiation Period. No
later than July 1, 2018 (and sooner upon Sekisui's written request at any time before July 1, 2018),
the parties shall engage in good faith negotiations for a period of up to 6 months (the "Negotiation
Period") with respect to a potential acquisition by Sekisui of Qualigen. During the Negotiation
Period, Qualigen shall provide to Sekisui all due diligence information reasonably requested by
Sekisui so that it may make an informed offer to acquire Qualigen. Any Financing Payments made by
Sekisui will be credited against any such Sale Transaction agreed to between Sekisui and Qualigen.
If the parties do not mutually agree to the terms of such potential acquisition within the
Negotiation Period then the Exclusivity Period shall end and, subject to Sekisui's Right of First
Refusal, Qualigen shall be free to negotiate the terms of a Sale Transaction with any Third Party.
9.3. Right of First Refusal. During the Term, Sekisui shall have a right of first refusal to match
the terms of any arms length, bona fide proposed Sale Transaction with a Third Party ("Sekisui's
Right of First Refusal"). Qualigen shall provide Sekisui with at least 30 days prior written notice
and access to all due diligence materials provided to any potential acquirer, such 30 day period to
commence upon the notification to Sekisui that Qualigen's board of directors has approved such
Proposed Sale Transaction (as set forth in a term sheet or draft definitive agreement provided to
Sekisui), subject to Sekisui's Right of First Refusal. At any time during such 30 day period,
Sekisui may elect to match the terms of such proposal. Sekisui will be credited in any such proposal
by the cumulative amount of all Financing Payments made to date. For example, if a Third Party
offers to acquire Qualigen for $50,000,000 and Sekisui has funded the full $6,200,000 of Financing
Payments, Sekisui's Right of First Refusal to match the proposed transaction would be a price of
$43,800,000. In the event that Sekisui elects not to move forward with such proposal for a Sale
Transaction, Qualigen shall have a period of 120 days to consummate a Sale Transaction on the same
terms as provided to Sekisui. If a Sale Transaction has not been consummated within such 120 days
period, any Sale Transaction must once again comply with the provisions of this Section 9.3. 13

Source: RITTER PHARMACEUTICALS INC, S-4/A, 3/13/2020
<!-- page 14 -->
9.4. Penalty for Breach. In the event of any breach of Sections 9.1 through 9.3, including without
limitation, any actions by stockholders of Qualigen that result in a Sale Transaction without
complying with Sections 9.1 through 9.3 above, or otherwise hinder the intent and purpose of the
provisions of Sections 9.1 through 9.3 above, in addition to any other remedies available to Sekisui
under the terms of this Agreement, including the right to specific performance and other equitable
remedies, Sekisui shall be entitled to liquidated damages in the amount of three times any and all
Financing Payments made to date. For the avoidance of doubt, this clause does not apply to a failure
of the stockholders of Qualigen to approve a Sale Transaction proposed by Sekisui, so long as such
stockholders did not approve a Sale Transaction on the same terms with a Third Party during the
Term. 9.5. Molecular Clinical Diagnostics. In furtherance of the foregoing, during the Exclusivity
Period, Qualigen shall, in consultation with Sekisui, take commercially reasonable steps to seek to
regain any rights in any Qualigen molecular clinical diagnostic product technology that Qualigen has
previously granted to Gen-Probe, Hologic, or any of their affiliates. 10. Representations and
Warranties 10.1. By Qualigen. Qualigen hereby represents, warrants and covenants that: (a) Qualigen
has the full right, power and corporate authority to enter into this Agreement, and to make the
promises set forth in this Agreement, and to grant the rights herein, and that there are no
outstanding agreements, assignments or encumbrances in existence inconsistent with the provisions of
this Agreement and that this Agreement is enforceable against Qualigen. (b) The Products supplied to
Sekisui under this Agreement shall conform to the applicable product specifications and shall not
infringe upon the patents or proprietary rights of any Third Party. To the extent any Third Party
owns any patents or proprietary rights relating to the use, sale, or manufacture of a Product in the
Territory, Qualigen represents and warrants that it has sufficient valid rights from such Third
Party under which (1) Qualigen may manufacture and sell such Product to Sekisui, and (2) Sekisui may
use and sell such Products royalty free in the Territory. (c) As of the Effective Date, Qualigen has
not been notified with respect to, and to Qualigen's best knowledge there is no patent infringement
action pending before any court or governmental agency or other tribunal relating to any Product.
(d) As of the Effective Date, Qualigen has not been notified with respect to, and to Qualigen's best
knowledge no material actions are pending before any court or governmental agency or other tribunal
relating to any Product. (e) All Product delivered to Sekisui or Sekisui's customers pursuant to
this Agreement, at the time of such delivery, shall not be adulterated or misbranded within the
meaning of any applicable law, regulation or guideline effective at the time of delivery and shall
not be an article which may not be introduced into interstate commerce under any applicable law,
regulation or guideline. 14

Source: RITTER PHARMACEUTICALS INC, S-4/A, 3/13/2020
<!-- page 15 -->
(f) The manufacturing facilities and processes utilized for the manufacture of each Product shall
comply with applicable FDA regulations including, without limitation, applicable current Good
Manufacturing Practices as described in 21 CFR 820. Qualigen does not represent, warrant or covenant
that the Development Plan will be successfully accomplished, that the Development Plan will produce
any particular results or any favorable results, that the Development Plan will result in any
Development IP (or in any valuable Development IP), that the Products (if any) arising from the
Development Plan can ever receive Regulatory Approvals or be successfully or profitably
commercialized, or that any other current or future Products can be successfully or profitably
commercialized by Sekisui. Moreover, Sekisui acknowledges and accepts the risks inherent in
attempting to develop and commercialize any medical product. There is no implied representation that
any Products can be successfully developed or commercialized. Qualigen shall provide to Sekisui and
for the benefit of Sekisui's customers of Products a standard commercial written warranty that the
Products will be free of defects in materials or workmanship starting from the date the Product has
been received by Sekisui's customer and ending after the length of time stated for the applicable
Product on Exhibit D hereto (the "User Warranty"). The User Warranty is contingent upon proper use
of a Product in the application for which such Product was intended and does not cover Products that
were altered or modified (or added to or subtracted from), that were used after the expiration date
thereon or that were subjected by the carrier, distributor or the customer to abuse, mishandling or
unusual physical, thermal, chemical or electrical stress. 10.2. By Sekisui. Sekisui represents,
warrants and covenants that: (a) Sekisui has the full right, power and corporate authority to enter
into this Agreement and to make the promises set forth in this Agreement and that there are no
outstanding agreements, assignments or encumbrances in existence inconsistent with the provisions of
this Agreement and that this Agreement is enforceable against Sekisui. (b) As of the Effective Date,
Sekisui has not been notified in writing with respect to, nor is there, to Sekisui's best knowledge,
any patent infringement action pending before any court or governmental agency or other tribunal
relating to Sekisui's sale or distribution of the Products. (c) As of the Effective Date, Sekisui
has not been notified in writing with respect to, nor is there, to Sekisui's best knowledge, any
action pending preventing Sekisui from selling and distributing the Products in the Territory. (d)
Sekisui shall use its commercially reasonable efforts to obtain before distribution of each Product,
all licenses, registrations and permits required to enable Sekisui to act as a distributor of such
Product in the Territory. (e) Sekisui shall not make, or advise its customers to make, any
alterations or modifications to, or any additions to or subtractions from, any Product. (f) Sekisui
shall make no attempt to reverse-engineer any Product nor encourage or assist anyone else to do so.
15

Source: RITTER PHARMACEUTICALS INC, S-4/A, 3/13/2020
<!-- page 16 -->
10.3. No Implied Warranties. The express warranties set forth in this Section 10 and elsewhere in
this Agreement are provided in lieu of, and EACH PARTY HEREBY DISCLAIMS, all other warranties,
express and implied, relating to the subject matter of this Agreement. EXCEPT FOR THE EXPRESS
WARRANTIES SET FORTH IN THIS AGREEMENT, NEITHER PARTY MAKES ANY OTHER WARRANTY, EXPRESS, IMPLIED OR
STATUTORY, TO THE OTHER PARTY WITH RESPECT TO THE PRODUCTS OR THE OTHER SUBJECT MATTER OF THIS
AGREEMENT. THE PARTIES EXPRESSLY EXCLUDE ANY IMPLIED WARRANTIES OF FITNESS FOR A PARTICULAR PURPOSE
OR OF MERCHANTABILITY. Each Party's representations, warranties and/or covenants under this
Agreement are solely for the benefit of the other Party and may be asserted only by the other Party
and not by anyone else (including without limitation any customer of the other Party; provide,
however, that end user customers may assert the User Warranty against Qualigen). 11. Indemnities
11.1. Indemnification by Sekisui. Sekisui shall indemnify, defend and hold harmless Qualigen, and
its directors, officers, employees, agents and representatives (collectively, the "Qualigen
Indemnitees") from and against any and all claims, suits and proceedings by a Third Party
(individually and collectively, "Claims"), and any and all losses, obligations, damages,
deficiencies, costs, penalties, liabilities, assessments, judgments, amounts paid in settlement,
fines and expenses (including court costs and reasonable fees and expenses of attorneys), incurred
in the investigation, defense and/or settlement of any Claims (individually and collectively,
"Losses"; it being expressly understood, however, that incidental, special, indirect and
consequential damages and lost profits, lost savings and interruptions of business are expressly
excluded therefrom and from such defined term): (a) arising out of the negligence or willful
misconduct of Sekisui or its directors, officers, employees, agents or representatives in the
performance of Sekisui's obligations under this Agreement; or (b) arising out of or in connection
with a breach or violation by Sekisui or its subdistributor of any applicable law or a material
breach by Sekisui of any of its obligations under this Agreement, including any representations or
warranties set forth herein; provided, however, that Sekisui shall have no liability or obligation
to any Qualigen Indemnitee for any Claims or Losses to the extent that such Claims or Losses are
primarily caused by a Qualigen Indemnitee's breach of applicable law, breach of this Agreement,
negligence or willful misconduct. 11.2. Indemnification by Qualigen. Qualigen shall indemnify,
defend and hold harmless Sekisui and its directors, officers, employees, agents and representatives
(collectively, the "Sekisui Indemnitees") from and against any and all Losses incurred in the
investigation, defense and/ or settlement of any Claims: (a) related to bodily injury, death or
property damage directly caused by any Product which has not been altered or modified (or added to
or subtracted from) in any way, has been handled, stored, transported and used in accordance with
Qualigen's guidelines and has not been used after its expiration date or subjected to abuse,
mishandling or unusual physical, thermal, chemical or electrical stress; (b) arising out of the
negligence or willful misconduct of Qualigen or its directors, officers, employees, agents or
representatives; (c) arising out of a breach or violation by Qualigen of any applicable law or a
material breach by Qualigen of any of its obligations under this Agreement, including any
representations or warranties set forth herein; or (d) arising out of any claim that any of the
manufacture, marketing, import, offer for sale, sale, or use of any Product infringes upon any
patent, proprietary, or intellectual property right of any Third Party in the Territory; provided,
however, that Qualigen shall have no liability or obligation to any Sekisui Indemnitee for any
Claims or Losses to the extent that such Claims or Losses are primarily caused by a Sekisui
Indemnitee's (or any other entity or person within the Sekisui corporate family's) breach of
applicable law, breach of this Agreement, negligence or willful misconduct. 16

Source: RITTER PHARMACEUTICALS INC, S-4/A, 3/13/2020
<!-- page 17 -->
11.3. Patent Indemnity. Qualigen and Sekisui shall notify each other promptly in writing of any
action (and all prior claims relating to such action) brought against Qualigen or Sekisui alleging
that the manufacture, marketing, import, offer for sale, sale or use of a Product constitute
infringement of the intellectual property rights of a Third Party, and (provided that such a Claim
does not arise from Sekisui's noncompliance with Sections 3.6, 8.4, 10.2(b), 10.2(c), 10.2(e) or
10.2(f) of this Agreement (e.g., Sekisui has altered a Product or has used a Sekisui trademark in
connection with a Product)) Qualigen agrees to defend Sekisui in such action at its expense and
shall pay any costs or damages finally awarded against Sekisui in any such action; provided, that
Qualigen shall have had sole control of the defense of any such action and all negotiations for its
settlement or compromise and provided further that no settlement or compromise shall be binding on a
Party hereto without its prior written consent, which consent shall not be unreasonably withheld. In
the event a lawsuit is filed against Sekisui or Qualigen alleging that the manufacture, marketing,
import, offer for sale, sale or use of a Product constitute infringement of the intellectual
property rights of a Third Party, or Qualigen files an action for declaratory judgment because of a
serious threat of such a lawsuit, or if in Qualigen's reasonable business judgment a Product is
likely to become the subject of a claim of infringement of a patent or other intellectual property
right; then Qualigen may, at its expense, and may request Sekisui's assistance to, attempt to obtain
a license to such patent or other intellectual property right. 11.4. Indemnification Procedures. The
Party or other Indemnitee intending to claim indemnification under this Section 11 (an "Indemnified
Party") shall promptly notify the other Party (the "Indemnifying Party") of any Claim in respect of
which the Indemnified Party intends to claim such indemnification (provided, that no delay or
deficiency on the part of the Indemnified Party in so notifying the Indemnifying Party will relieve
the Indemnifying Party of any liability or obligation under this Agreement except to the extent the
Indemnifying Party has suffered actual prejudice directly caused by the delay or other deficiency),
and the Indemnifying Party shall assume the defense thereof (with counsel selected by the
Indemnifying Party and reasonably satisfactory to the Indemnified Party) whether or not such Claim
is rightfully brought; provided, however, that an Indemnified Party shall have the right to retain
its own counsel and participate in the defense thereof, with the fees and expenses to be paid by the
Indemnified Party, unless the Indemnifying Party does not assume the defense or unless a
representation of both the Indemnified Party and the Indemnifying Party by the same counsel would be
inappropriate due to the actual or potential differing interests between them, in which case the
reasonable fees and expenses of counsel retained by the Indemnified Party shall be paid by the
Indemnifying Party. Notwithstanding the previous sentence, in no event shall the Indemnifying Party
be required to pay for more than one separate counsel no matter the number or circumstances of all
Indemnified Parties. If the Indemnifying Party shall fail to timely assume the defense of and
reasonably defend such Claim, the Indemnified Party shall have the right to retain or assume control
of such defense and the Indemnifying Party shall pay (as incurred and on demand) the fees and
expenses of counsel retained by the Indemnified Party and all other expenses of investigation and
litigation. The Indemnified Party, and its directors, officers, advisers, agents and employees,
shall cooperate fully with the Indemnifying Party and its legal representatives in the
investigations of any Claim. The Indemnifying Party shall not be liable for the indemnification of
any Claim settled (or resolved by consent to the entry of judgment) without the written consent of
the Indemnifying Party. Also, if the Indemnifying Party shall control the defense of any such Claim,
the Indemnifying Party shall have the right to settle such Claim; provided, that the Indemnifying
Party shall obtain the prior written consent (which shall not be unreasonably withheld or delayed)
of the Indemnified Party before entering into any settlement of (or resolving by consent to the
entry of judgment upon) such Claim unless (A) there is no finding or admission of any violation of
law or any violation of the rights of any person or entity by an Indemnified Party, no requirement
that the Indemnified Party admit fault or culpability, and no adverse effect on any other claims
that may be made by or against the Indemnified Party and (B) the sole relief provided is monetary
damages that are paid in full by the Indemnifying Party and such settlement does not require the
Indemnified Party to take (or refrain from taking) any action. 17

Source: RITTER PHARMACEUTICALS INC, S-4/A, 3/13/2020
<!-- page 18 -->
Regardless of who controls the defense, the other Party hereto shall reasonably cooperate in the
defense as may be requested. Without limitation, the Party hereto which is not the Indemnifying
Party and (if different) the Indemnified Party, and their respective directors, officers, advisers,
agents and employees, shall cooperate fully with the Indemnifying Party and its legal
representatives in the investigation and defense of any Claim. 11.5. Expenses of Enforcement. As the
Parties intend complete indemnification, all costs and expenses of enforcing any provision of this
Section 11 shall also be reimbursed by the Indemnifying Party except as otherwise set forth in
Section 11.4. 11.6. Insurance. Qualigen, at its own expense, shall procure and maintain during the
Term, insurance policies with the minimum coverages set forth below ("Insurance"). Sekisui shall be
named as an additional insured with respect to the Insurance. The Insurance shall be primary for all
purposes to other insurance coverage, whether such other insurance is stated to be primary,
contributory, excess, contingent or otherwise, without recourse to or contribution from any
Sekisui-owned coverage. (a) Commercial General Liability Insurance - Combined single limit for
bodily and property damage of not less than $1,000,000 for each occurrence and $2,000,000 annual
aggregate providing: ● Assault and Battery coverage, ● Broad form property damage coverage, ● Broad
form contractual liability coverage, ● Products and completed operations coverage, and ● Personal
and advertising injury coverage. (b) Workers' Compensation and Employer's Liability Insurance - With
limits of liability for: ● Workers' compensation as required by statute; ● Employer's liability for
bodily injury by accident: $500,000 each accident; bodily injury by disease: $500,000 policy limit;
and bodily injury by disease: $500,000 each employee. All Qualigen's Insurance shall be placed with
an insurer that (a) has an A.M. Best rating of A- or better or (b) is a qualified self- insurance
program that is approved by Sekisui. Qualigen shall provide Sekisui, upon request, with written
evidence of the Insurance, including where it is provided through qualified self-insurance. Nothing
in this Section shall be deemed to limit Qualigen's responsibility to the amounts stated above or to
any limits of Qualigen's insurance policies. 12. Regulatory Matters 12.1. Regulatory Approval.
Qualigen shall be responsible for maintaining, at its sole cost, the Regulatory Approvals required
for the marketing and sale of the Products in the Applicable Markets. Qualigen shall hold in its
name all Regulatory Approvals required for the marketing and sale of the Products in a country or
region and shall (to the extent commercially reasonable to do so) maintain in good standing all
existing Regulatory Approvals. Qualigen and Sekisui shall provide reasonable advice and assistance
to each other as may be necessary to maintain required Regulatory Approvals. In addition, Qualigen
shall use commercially reasonable efforts to obtain Regulatory Approval for any additional
territories upon Sekisui's commercially reasonable request. 18

Source: RITTER PHARMACEUTICALS INC, S-4/A, 3/13/2020
<!-- page 19 -->
12.2. Distribution Approvals. Sekisui shall be responsible for seeking, obtaining and maintaining
(i) all licenses, registrations and permits (excluding patents) required to be obtained by Sekisui
to enable Sekisui to act as a distributor of the Product pursuant to this Agreement, and (ii) all
approvals from the Regulatory Authorities regarding marketing and advertising materials to be used
by Sekisui to promote the Product. Qualigen shall cooperate with Sekisui in making and maintaining
all filings that may be necessary or desirable in connection with obtaining and maintaining any
regulatory approvals necessary for Sekisui to act as a distributor of the Product in the Applicable
Markets. 12.3. Communication With Agencies. In the Applicable Markets, Qualigen shall have
responsibility for communications with the Regulatory Authorities concerning any required Regulatory
Approvals, approval of Product related marketing and advertising materials, and Product quality
matters. 12.4. Governmental Warnings. Each Party shall advise the other Party promptly (but in any
event within no more than 48 hours) of any warning (including any FDA Form 483), citation,
indictment, claim, lawsuit, or proceeding issued or instituted by any federal, state or local
governmental entity or agency against the Party, or of any revocation of any license or permit if,
and only to the extent that, the manufacture, storage, or handling of the Product, or the marketing,
selling, promotion or distribution of the Product, is affected. 12.5. Adverse Events, Recalls and
Field Corrections. Qualigen shall have responsibility to determine whether any Adverse Events,
Recalls or Field Corrections information must be reported to the FDA (under United States law) or
any other Regulatory Authorities and Qualigen shall have responsibility to prepare and submit
notification of Adverse Events, Recalls and/or Field Corrections to respective Regulatory
Authorities for the Products. Qualigen shall provide prompt notice to Sekisui of any Adverse Events,
Recalls or Field Corrections, which notice shall in any event be delivered within no more than 3
business days from Qualigen learning of such occurrence. 12.6. Complaints. Qualigen shall receive,
investigate in a timely manner, and as appropriate, resolve customer complaints in the Territory. If
an investigation is needed in response to a complaint or inquiry related to the Product, Qualigen
shall perform the investigation and shall bear the cost of such investigation. The documentation of
such investigation shall include, but not be limited to, investigation results, cause analysis,
corrective and preventative action and health hazard/medical assessment, as appropriate. In the
event a Product is returned by a customer for investigation, Qualigen shall ship a replacement
Product to the customer. (Provided, that if a request for a return of Product is due to a change of
mind over using the Product or the Sekisui customer has overstocked the product, rather than due to
a warranty issue, Qualigen need not accept the return or provide any replacement or substitute.)
Qualigen shall retain records of all Product related complaints, or Adverse Events for a period of
not less than five (5) years beyond the expiration date of the Product or for such longer period as
may be required by applicable law. Qualigen shall use commercially reasonable efforts to ensure that
all complaints are appropriately closed within 90 days or less from the receipt of such complaint.
19

Source: RITTER PHARMACEUTICALS INC, S-4/A, 3/13/2020
<!-- page 20 -->
12.7. Product Recalls. In the event that (i) any Applicable Market governmental agency or authority
issues a request or directive or orders that the Products be recalled or retrieved, (ii) an
Applicable Market court of competent jurisdiction orders that the Products be recalled or retrieved,
or (iii) Qualigen and Sekisui reasonably determine, after mutual consultation, that the Products
should be recalled, corrected or retrieved in any particular country or countries, Qualigen and/or
Sekisui shall conduct such activity and the parties shall take all appropriate corrective actions
and shall execute the steps detailed in the recall strategy. Qualigen shall be responsible for the
content of any communication to the customers regarding any Recall or Field Correction. In the event
such action results from Sekisui's gross negligence or willful misconduct, Sekisui shall be
responsible for the expenses thereof. Otherwise, Qualigen shall be responsible for the expenses of
the action. Sekisui and Qualigen shall cooperate fully with one another in conducting any such
action. Sekisui shall destroy units of Products lawfully recalled only upon Qualigen's (or any
governmental authority's) written instruction to destroy such units of Products, and only then in
accordance with Qualigen's procedures and instructions. Otherwise, Sekisui shall return the recalled
units of Product to Qualigen in accordance with Qualigen's procedures and instructions after
completion of the action. 12.8. European Union Vigilance and Canada Mandatory Problem Reporting. In
the event that Qualigen receives any Potentially Serious Complaints regarding the Products from a
customer located in the European Union or Canada, then Qualigen shall notify Sekisui promptly, but
in any event within no more than (3) business days. If Qualigen receives a complaint from any
Competent Authority or Health Canada with regard to the Products, Qualigen shall notify Sekisui
promptly, but in any event within no more than 48 hours. Qualigen shall have the responsibility to
correspond with the Competent Authority or Health Canada, as the Authorized Representative or
Regulatory Correspondent, regarding any such complaints. If corrective actions are required, the
cost of the corrective action shall be borne by Qualigen up to the extent such complaint is related
to the manufacturing of the Products by Qualigen, or some other cause or event attributable to
Qualigen, and shall be borne by Sekisui up to the extent such complaint is due to some other cause
or event attributable to Sekisui. 20

Source: RITTER PHARMACEUTICALS INC, S-4/A, 3/13/2020
<!-- page 21 -->
13. Confidential Information; Audit Rights 13.1. Confidentiality Obligation. It is contemplated that
in the course of the performance of this Agreement each Party may, from time to time, disclose
proprietary and confidential information to the other ("Confidential Information"). Except to the
extent expressly authorized by this Agreement or otherwise agreed to in writing, during the Term and
for a period of five (5) years following the expiration or termination of this Agreement, the
receiving Party shall disclose the other Party's Confidential Information only to its own (or its
Affiliates') officers, employees, consultants, Third Party service providers, attorneys,
accountants, agents, bankers, lenders, prospective lenders and prospective equity investors, and in
each case only if and to the extent necessary to carry out their respective responsibilities under
this Agreement or in accordance with the exercise of their rights under this Agreement or in
accordance with customary permitted practice (such as to seek or maintain financing or credit), and
such disclosure shall be limited to the maximum extent possible consistent with such
responsibilities and rights. Except as set forth in the foregoing sentence, neither Party shall
disclose Confidential Information of the other to any Third Party without the other's prior written
consent. In all events, however, any and all disclosure to a Third Party (or to any such Affiliate)
shall be pursuant to the terms of a non-disclosure/nonuse agreement no less restrictive than this
Section 13 (or, in the case of attorneys, to a duty and obligation of nondisclosure/nonuse pursuant
to the applicable rules of the profession). The Party which disclosed Confidential Information of
the other to any Third Party (or to any such Affiliate) shall be responsible and liable for any
disclosure or use by such Third Party or Affiliate (or its disclosees) which would have violated
this Agreement if committed by the Party itself. Neither Party shall use Confidential Information of
the other except as expressly allowed by and for the purposes of this Agreement or in accordance
with the exercise of their rights under this Agreement or in accordance with customary permitted
practice (such as to seek or maintain financing or credit) or and, after the Term, by Qualigen only
to the extent required to continue to offer and provide goods and services to former Sekisui
customers of Products. Each Party shall take such action to preserve the confidentiality of each
other's Confidential Information as it would customarily take to preserve the confidentiality of its
own Confidential Information (but in no event less than a reasonable standard of care). Upon
expiration or termination of this Agreement, each Party, upon the other's request, promptly shall
return or destroy all the Confidential Information disclosed to the other Party pursuant to this
Agreement, including all copies, reflections, analyses and extracts of documents, except for one
archival copy (and such electronic copies that exist as part of the Party's computer systems,
network storage systems and electronic backup systems) of such materials solely to be able to
monitor its obligations that survive under this Agreement. The non-use and non-disclosure
obligations set forth in this Section 13 shall not apply to any Confidential Information, or portion
thereof, that the receiving Party can demonstrate: (a) is at the time of disclosure in the public
domain; 21

Source: RITTER PHARMACEUTICALS INC, S-4/A, 3/13/2020
<!-- page 22 -->
(b) after disclosure, becomes part of the public domain, by publication or otherwise, through no
fault of and or without violation of any duty of confidentiality of the receiving Party or its
disclosees; (c) at the time of disclosure is already in the receiving Party's possession with no
duty of confidentiality, and such prior possession can be demonstrated by the receiving Party by
written proof (provided that this subsection shall not apply to Confidential Information exchanged
between the Parties before the execution of this Agreement that was subject to a confidentiality
obligation at the time of such disclosure); (d) is rightfully received by the receiving Party on a
non-confidential basis from an independent Third Party without obligation of confidentiality;
provided, however, that to the receiving Party's best knowledge, such information was not obtained
by said Third Party, directly or indirectly, from the disclosing Party; or (e) is independently
developed by or expressly for the receiving Party, in either case solely by personnel without any
access to or use of the disclosing Party's Confidential Information, as shown by receiving Party's
contemporaneous written records. In the event either Party must disclose the other Party's
Confidential Information in order to comply with applicable governmental regulations or as otherwise
required by law or judicial process, such Party shall give reasonable advance notice to the other
Party of such proposed disclosure in order that the non-disclosing Party may intercede and oppose
such process, and shall use its best efforts to secure a protective order or confidential-treatment
order preventing or limiting (to the greatest possible extent and for the longest possible period)
the disclosure and/or requiring that the Confidential Information so disclosed be used only for the
purposes for which the law or regulation required, or for which the order was issued. The Parties
acknowledge that the defined term "Confidential Information" shall include not only a disclosing
Party's own Confidential Information but also Confidential Information of an Affiliate or of a Third
Party which is in the possession of a disclosing Party. However, both Parties agree not to disclose
to the other Party any Confidential Information of a Third Party which is in the possession of such
Party, unless the other Party has given an express prior written consent (which specifies the owner
of such Confidential Information) to receive such particular Confidential Information. 22

Source: RITTER PHARMACEUTICALS INC, S-4/A, 3/13/2020
<!-- page 23 -->
Notwithstanding anything to the contrary in this Agreement or any other agreement between Sekisui
and Qualigen, nothing in this Agreement or any other agreement between the Parties prohibits, or is
intended in any manner to prohibit, either Sekisui or Qualigen from reporting possible violations of
federal law or regulation to any governmental agency or entity, including but not limited to the
Department of Justice, the Securities and Exchange Commission, the Congress, and any agency
Inspector General, or making other disclosures that are protected under the whistleblower provisions
of federal law or regulation. Sekisui and Qualigen do not need the prior authorization of anyone at
the other Party or the other Party's legal counsel to make any such reports or disclosures and they
are not required to notify the other Party that it has made such reports or disclosures. 13.2. Use
of Names. During the Term, Sekisui is hereby permitted to use the Qualigen name and any Qualigen
content (including the content of any existing sales collateral and marketing materials) in any
sales collateral, marketing materials or other communications used in connection with the marketing
and sales of the Product with the prior written consent of Qualigen, which consent shall not be
reasonably withheld or delayed. Other than as provided in the foregoing sentence or to the extent
such use is based on a public disclosure previously made by the other Party, during the Term neither
Qualigen nor Sekisui shall use the name of the other in any verbal or written communications with
any Third Party, except as allowed or contemplated herein, without the prior written consent of the
other Party. 13.3. Press Releases. Neither Party shall make any press release or other similar
public announcement concerning this Agreement without the prior written consent of the other Party,
which consent shall not be unreasonably withheld. Notwithstanding the foregoing, in the event such
disclosure or public announcement is required to be made on a more immediate basis to comply with
applicable laws, then approval will be deemed granted if no response is received from the
non-disclosing Party within the time frames required by law; provided, however, that the disclosing
Party provides the non-disclosing Party with notice of the legally required time frame for the
approval of the disclosure. Neither Party shall use the trademark or logo of the other Party, its
Affiliates or their respective employee(s) in any publicity, promotion, news release or public
disclosure relating to this Agreement or its subject matter, except as may be required by law or
except with the prior express written permission of such other Party, such permission not to be
unreasonably withheld or delayed, or except in Sekisui's advertisement, promotion and sale of the
Products in compliance with this Agreement in the ordinary course of business. Notwithstanding the
above, once a public disclosure has been made, either Party shall be free to disclose to Third
Parties any information contained in said public disclosure, without further pre-review or
pre-approval. 13.4. Audit Rights. Each Party shall keep accurate books and records in sufficient
detail to comply with applicable laws, rules and regulations and this Agreement and enable the other
Party to determine the correctness of any report made under this Agreement and monitor compliance
with applicable laws, rules and regulations and this Agreement through the process below. Upon
reasonable written notice (and no more often than once every 150 days), the auditing Party shall
have the right, during normal business hours, to audit the books and records maintained by the
audited Party pursuant to this Agreement to ensure the accuracy of all reports and payments made
hereunder. 23

Source: RITTER PHARMACEUTICALS INC, S-4/A, 3/13/2020
<!-- page 24 -->
14. Termination 14.1. Termination by Either Party. Either Party may terminate this Agreement (i)
immediately upon written notice in the event of the closing of a Sale Transaction; or (ii)
immediately upon written notice if the other files a voluntary bankruptcy petition or makes a
general assignment for the benefit of creditors or becomes subject to any order for relief or
involuntary bankruptcy petition under any bankruptcy, liquidation, insolvency or similar law which
is not dismissed within 60 days. 14.2. Termination by Qualigen. Qualigen may terminate this
Agreement (i) upon thirty (30) days prior written notice in the event of any failure of Sekisui to
make a Financing Payment that is determined to be due, which failure is not cured within such 30 day
period, or (ii) upon sixty (60) days prior written notice in the event of any material breach of the
diligence obligations (which is understood not to include failing to meet forecasts for sales to
customers) set forth in the Business Plan (as it may be amended by the Parties from time to time),
which breach is not cured within such 60 day period. 14.3. Termination by Sekisui. Sekisui may
terminate this Agreement upon prior written notice (i) in the event of any failure of Qualigen to
meet a milestone set forth in the Development Plan (as it may be amended by the Parties from time to
time), or (ii) at any other time upon ninety (90) days' prior written notice of impending
termination. 14.4. Effect of Termination. Sections 4.6, 5.5, 8.1, 8.2, 11.1-11.4, 13, 14.4 and 15
shall survive the later of the expiration or termination of the Term. In addition, all provisions
that survive termination, that are irrevocable or that arise due to termination shall survive in
accordance with their terms. Any other provisions of this Agreement contemplated by their terms to
pertain to a period of time following termination or expiration of this Agreement shall survive only
for the specified period of time. Upon the expiration or termination of the Term, (i) Sekisui shall
cooperate in permitting Qualigen to offer to rehire any Sekisui sales representatives who are
primarily responsible for selling the Products as set forth in Section 4.6, (ii) Sekisui shall
transfer to Qualigen the ownership of any Sekisui Instruments (subject to reimbursement from
Qualigen for the book value (original cost less depreciation) of such Sekisui Instruments), (iii)
Qualigen shall reimburse Sekisui for a prorated portion of all prepaid distribution fees paid by
Sekisui during the final year of this Agreement to subdistributors, (iv) Sekisui shall assign to
Qualigen each subdistributor agreement which Qualigen requests be assigned to Qualigen, and (v) each
Party shall remain liable for its obligations accrued before the effective date of such expiration
or termination (and for avoidance of doubt: upon expiration or termination Sekisui shall remain
liable to pay Qualigen all Financing Payments then due under the Development Plan based upon the
milestones that Qualigen has completed by the date of such expiration or termination). In the event
there are unfulfilled orders for Products outstanding as of termination of this Agreement, Sekisui
may, at its option, cancel such orders upon notice to Qualigen (in which case Qualigen agrees to
fill such orders to Sekisui's end customers directly unless such customer chooses to cancel such
order) or cause Qualigen to fulfill such orders and invoice Sekisui for amounts owed with respect
thereto. If either Party is aware of an impending expiration or termination of the Term, it shall
conduct its business with respect to the subject matter of this Agreement in the ordinary course
(and not otherwise than in the ordinary course) for the duration of the Term. 24

Source: RITTER PHARMACEUTICALS INC, S-4/A, 3/13/2020
<!-- page 25 -->
15. Miscellaneous 15.1. Independent Contractor. For the purpose of the Agreement each Party shall
be, and shall be deemed to be, an independent contractor and not an agent, partner, joint venturer
or employee of the other Party. Neither Party shall have authority to make any statements,
representations or commitments of any kind, or to take any action which shall be binding on the
other Party (except as may be explicitly provided for herein or authorized in writing), and each
Party agrees not to purport to do so. 15.2. Assignment. The Agreement shall not be assigned and is
not assignable or delegable by either Party without the written consent of the other, which consent
shall not be unreasonably withheld; provided, that Sekisui and Qualigen each may assign this
Agreement without the consent of the other to a successor in connection with the merger,
consolidation or sale of such Party or of all or substantially all of its assets or the portion of
its business to which this Agreement relates. 15.3. No Waiver. Failure of either Party to enforce
(or reasonable delay in enforcing) a right under this Agreement shall not act as a waiver of that
right or the ability to later assert that right relative to the particular situation involved or to
terminate this Agreement arising out of any subsequent default or breach. A waiver by a Party of any
of the terms and conditions of this Agreement in any instance shall not be deemed or construed to be
a waiver of such term or condition for the future, or of any other term or condition hereof. 15.4.
Severability. This Agreement is divisible and separable. If any provision of this Agreement is
determined by a final and binding court judgment (for which no further appeal is possible) to be
invalid, illegal or unenforceable to any extent, such provision shall not be not affected or
impaired up to the limits of such invalidity, illegality or unenforceability; the validity, legality
and enforceability of the remaining provisions of this Agreement shall not be affected or impaired
in any way; and the affected provision shall (if at all possible) be construed as if it had been
written in such a way as to both be valid, legal and enforceable and to achieve, to the greatest
lawful extent, the evident economic, business and other purposes of such invalid, illegal or
unenforceable provision (or portion of provision). 15.5. Notices. All notices required or permitted
under this Agreement shall be in writing and shall be deemed given and made (i) if by personal
delivery, on the date of such delivery, (ii) if by recognized overnight courier specifying
next-business-day delivery, on the next business day after the date of deposit with such courier (by
the courier's stated time for enabling next-business-day delivery), (iii) if by email, on the date
sent by email if sent during normal business hours of the recipient, and on the next business day if
sent after normal business hours of the recipient, and (iv) if by US registered mail, on the fifth
business day following such mailing in the US, in each case addressed at the address shown below
for, or such other address as may be designated by 10 days' advance written notice hereunder by,
such Party. If to Sekisui: Sekisui Diagnostics, LLC 4 Hartwell Place Lexington, MA 02421 Attn:
President Email: bob.schruender@sekisuidiagnostics.com 25

Source: RITTER PHARMACEUTICALS INC, S-4/A, 3/13/2020
<!-- page 26 -->
With copies (which shall not constitute notice) to: Sekisui Diagnostics LLC 4 Hartwell Place
Lexington, MA 02421 Attn: Vice President, Legal Affairs Email:
elizabeth.mcevoy@sekisuidiagnostics.com Foley Hoag LLP Seaport West 155 Seaport Boulevard Boston, MA
02210 Attn: Mark A. Haddad Email: mhaddad@foleyhoag.com If to Qualigen: Qualigen, Inc. 2042 Corte
Del Nogal Carlsbad, CA 92011 Attn: President Email: prosinack@qualigeninc.com With a copy (which
shall not constitute notice) to: Stradling Yocca Carlson & Rauth, P.C. 4365 Executive Drive, Suite
1500 San Diego, CA 92121 Attn: Hayden Trubitt Email: htrubitt@sycr.com 15.6. Entire Agreement and
Modification. The Agreement, including the Exhibits thereto, constitutes the entire understanding
between the parties with respect to the subject matter hereof and supersedes and cancels any
previous or contemporaneous agreements or understandings, whether oral, written or implied,
heretofore in effect, including any letter of intent, and sets forth the entire agreement between
Sekisui and Qualigen with respect to the subject matter hereof (provided, that any and all previous
nondisclosure/nonuse obligations, including the July 7, 2015 Confidential Disclosure Agreement) are
not superseded and remain in full force and effect for all disclosures made prior to the date of
this Agreement). Each Party acknowledges that it has not relied, in deciding whether to enter into
this Agreement on this Agreement's expressly stated terms and conditions, on any representations,
warranties, agreements, commitments or promises which are not expressly set forth within this
Agreement. No agreements amending, altering, supplementing or waiving the terms hereof may be made
except by the express terms of a written document signed by duly authorized representatives of the
Parties. 15.7. Governing Law. This Agreement shall be governed by, and construed and interpreted in
accordance with, the laws of the State of Delaware, without reference to its conflicts of laws
principles. The parties agree that the United Nations Convention on Contracts for the International
Sale of Goods shall be inapplicable to this Agreement. 15.8. Attorney Fees. If litigation becomes
necessary to enforce the provisions of this Agreement, the successful Party shall be entitled to
recover from the other Party reasonable expenses, including attorneys' and other professional fees,
in addition to any other available remedies. 26

Source: RITTER PHARMACEUTICALS INC, S-4/A, 3/13/2020
<!-- page 27 -->
15.9. Headings. The headings contained in this Agreement are for reference purposes only and are in
no way intended to describe, interpret, define or limit the scope, extent or intent of this
Agreement or any provision hereof. 15.10. Counterparts; Delivery. This Agreement may be executed in
one or more counterparts, each of which shall be deemed an original, but all of which together shall
constitute one and the same instrument. Signatures to this Agreement may be delivered by email
attachment or other electronic transmission, and such signatures and such delivery shall be fully
effective and binding on the Party sending the same. 15.11. Further Assurances. Each Party covenants
and agrees to, without the necessity of any further consideration, execute, acknowledge and deliver
any and all such further or other documents and instruments and take any such further or other
action as may be necessary or appropriate in order to carry out the purposes and intent of this
Agreement. 15.12. Force Majeure. No Party shall be liable to any other Party or be deemed to have
breached or defaulted under this Agreement for failure or delay in the performance of any of its
obligations under this Agreement (other than obligations for the payment of money) for the time and
to the extent such failure or delay is caused by or results from acts of God, earthquake, riot,
civil commotion, terrorism, war, strikes or other labor disputes, fire, flood, failure or delay of
transportation, omissions or delays in acting by a governmental authority, acts of a government or
an agency thereof or judicial orders or decrees or restrictions or any other like reason which is
beyond the control of the respective Party. The Party affected by force majeure shall provide the
other Party with full particulars thereof as soon as it becomes aware of the same (including its
best estimate of the likely extent and duration of the interference with its activities), and shall
use commercially reasonable efforts to overcome the difficulties created thereby and to resume
performance of its obligations hereunder as soon as practicable, and the time for performance shall
be extended for a number of days equal to the duration of the force majeure. 15.13. Equitable
Relief. Each Party recognizes that the covenants and agreements herein and their continued
performance as set forth in this Agreement are necessary and critical to protect the legitimate
interests of the other Party, that the other Party would not have entered into this Agreement in the
absence of such covenants and agreements and the assurance of continued performance as set forth in
this Agreement, and that a Party's breach or threatened breach of such covenants and agreements will
cause the opposed Party irreparable harm and significant injury, the amount of which will be
extremely difficult to estimate and ascertain, thus making any remedy at law or in damages
inadequate. Therefore, each Party agrees that an opposed Party shall be entitled to specific
performance, an order restraining any breach or threatened breach of Section 13 and all other
provisions of this Agreement, and any other equitable relief (including but not limited to
temporary, preliminary and/or permanent injunctive relief), without the necessity of posting of any
bond or security. This right shall be in addition to and not exclusive of any other remedy available
to such other Party at law or in equity. 15.14. Rights and Remedies are Cumulative. Except to the
extent as may be expressly set forth herein, all rights, remedies, undertakings, obligations and
agreements contained in or available upon violation of this Agreement shall be cumulative and none
of them shall be in limitation of any other remedy or right authorized in law or in equity, or any
undertaking, obligation or agreement of the applicable Party. 27

Source: RITTER PHARMACEUTICALS INC, S-4/A, 3/13/2020
<!-- page 28 -->
15.15. Third Party Beneficiaries. Except as expressly set forth in Section 11, the terms and
provisions of this Agreement are intended solely for the benefit of each Party hereto and their
respective successors or permitted assigns and it is not the intention of the Parties to confer
third-party beneficiary rights upon any other person. 15.16. No Implied License. No right or license
is granted to Sekisui by implication, estoppel, or otherwise to any know-how, patent or other
intellectual property right owned or controlled by Qualigen. 15.17. Exhibits. The Exhibits referred
to in the Agreement are deemed incorporated by reference at each place in the Agreement when
reference is made thereto. IN WITNESS WHEREOF, the parties hereto have caused this Agreement to be
duly executed by their duly authorized representatives as of the date first above written. SEKISUI
DIAGNOSTICS, LLC QUALIGEN, INC. By: /s/ Robert T. Schruender By: /s/ Paul A. Rosinack Name: Robert
T. Schruender Name: Paul A. Rosinack Title: President and COO Title: President and CEO 28

Source: RITTER PHARMACEUTICALS INC, S-4/A, 3/13/2020
<!-- page 29 -->
Exhibit A Revenue, Cost and Available Margin April 28, 2016 Revenue Actual Gross Revenue -
Consistent with GAAP revenue recognition, Gross Revenue reflects amounts invoiced or otherwise
charged by Sekisui Diagnostics, LLC and its Affiliates to unrelated Third Parties for Products sold
to customers, including amounts for any shipping, handling, freight, postage, insurance and
transportation charges, to the extent included as a separate line item in the gross amount invoiced.
Actual Gross Revenue does not include the following: ● any sales or value added taxes imposed on the
sale, delivery or use of the Products. ● Reagent Rental Early Termination Fees. Any such fees
collected shall belong exclusively to Qualigen. ● Warranty Agreement Revenue and other Service
Contract Revenue. Any such revenue shall belong exclusively to Qualigen. Notwithstanding the
foregoing, amounts invoiced by Sekisui and its Affiliates for sales of Products among Sekisui and
its Affiliates ('Sekisui Intercompany Sales') for resale shall not be included in the computation of
Net Revenue. Actual 'Gross to Net' (GTN) Adjustments - consist of: a) discounts, refunds, rebates,
sub distributor "channel" fees, chargebacks, retroactive price adjustments, and any other allowances
given and taken which effectively reduce the net selling price (other than such which have already
diminished the gross amount invoiced), including, without limitation, volume discounts. b) Product
returns and allowances Net Revenue - Actual Gross Revenue less Actual GTN Adjustments Cost of Goods
Sold (COGS) Components of COGS include: Actual Material Costs - Consists of: ● Qualigen Bill of
Material (BOM) Standard Costs (for instrument, reagent kit and related consumable products sold by
Sekisui): ○ raw materials ○ component materials ○ packaging materials ● Allocated standard shipping
material costs, including envirocoolers, shipping boxes and filler materials ● Actual cost of ice
packs ● Actual outbound freight expense (as applicable based on shipping terms) for sales and
rentals of instruments, and sales of reagents and related consumables. Exhibit A-1

Source: RITTER PHARMACEUTICALS INC, S-4/A, 3/13/2020
<!-- page 30 -->
(Note: Qualigen records costs of raw material, component, packaging and shipping materials
(excluding ice packs) at standard, and records manufacturing variances including purchase price and
material usage variances as part of Labor & Overhead. If Qualigen's manufacturing variances exceed
3% of its total production costs in any True-Up Period referenced in Exhibit D, such variances are
to be allocated between inventory and COGS based on total inventory turns for the applicable True-Up
Period) Actual Labor & Overhead Costs - Consists of: Instrument and Reagent Manufacturing Cost
Center Expenses - Including direct instrument and reagent manufacturing-related wages and related
taxes and benefits, direct Property Plant & Equipment depreciation, direct production supplies,
direct production-related repairs & maintenance expenses, inbound freight expenses, material
variances and allocated manufacturing-related occupancy expenses for expenses such as rent,
utilities, janitorial services, telephone expense, supplies and depreciation. Reagent manufacturing
also includes an allocation of R&D department expenses relating to formulation oversight. In
Qualigen's FY 2016 financial data, this allocation represented approximately $60k. Workers' comp
insurance is included as part of the occupancy allocation in Qualigen's FY2016 financial results.
Beginning with Qualigen's FY 2017 financial reporting, Workers' comp insurance will be included as a
direct allocation to the Instrument and Reagent Manufacturing cost centers based on salary amounts.
Quality Cost Center Expenses - Including wages and related taxes and benefits, equipment repairs and
maintenance expenses, professional consulting services, supplies, dues & subscriptions, filing fees,
depreciation and allocated Quality occupancy expenses. Wages include expenses for VP - Operations.
The Quality Cost Center is responsible for: ● Regulatory filings ● Quality System Management ●
Complaint review ● Batch record review ● Document Control ● Quality Control (QC), including: Ø Test
incoming raw materials, WIP, and FG items Ø Complaint testing confirmation Ø Product troubleshooting
Exhibit A-2

Source: RITTER PHARMACEUTICALS INC, S-4/A, 3/13/2020
<!-- page 31 -->
Materials Management Cost Center Expenses - Including wages and related taxes and benefits,
professional consulting services, supplies, depreciation and allocated Material Management occupancy
expenses. The Materials Management Cost Center is responsible for: ● Production planning ●
Scheduling ● Purchasing ● Shipping & Receiving Occupancy allocations to Instrument and Reagent
manufacturing, Quality and Materials Management departments are based on applicable square footage
percentages. Actual Labor & Overhead Costs also include the standard cost of FastPacks consumed for
QC testing, retainage, scrap, and obsolete inventory write-downs. Actual Labor & Overhead Costs do
not include instrument repair costs. Such costs shall be the responsibility of Qualigen with respect
to instruments under warranty that are repaired or replaced, and shall be included in the instrument
transfer prices with respect to refurbished instruments sold to Sekisui. Currently, the Medical
Device Excise Tax provision of the Affordable Care Act is repealed (from Jan. 2016 through December
2017). However, should this provision be re-enacted, or similar such provision enacted, the cost of
such excise taxes will be included as a cost element included in Actual Cost of Goods. The margin
share and true-up process will reflect this cost. Any duty expenses incurred by Sekisui Diagnostics
to enable sales of Products will be included as a cost element included in Actual Cost of Goods. The
margin share and true-up process will reflect this cost. Actual 'Reagent Rental' Instrument
Depreciation Costs - Reflects depreciation expenses for all Product-related instruments placed in
service before and after execution of the DISTRIBUTION AND DEVELOPMENT AGREEMENT. Assets placed in
service before April 2015 reflect a 5 year useful life. Assets placed in service beginning April
2015 reflect a 3 year useful life. Sekisui Diagnostics has a $5,000 Asset Capitalization Threshold
(ACT) and all capitalized instruments will utilize a 3 year life for all Reagent Rental units it
owns. (all instruments purchased at costs < $5,000 will be expensed, with the expense included as
part of COGS in the Margin Sharing True-Up process.) All depreciation expenses reflect straight-line
depreciation. Available Margin Available Margin is defined and calculated as: Net Revenue less Cost
of Goods Sold (COGS) Exhibit A-3

Source: RITTER PHARMACEUTICALS INC, S-4/A, 3/13/2020
<!-- page 32 -->
Exhibit B-1

Source: RITTER PHARMACEUTICALS INC, S-4/A, 3/13/2020
<!-- page 33 -->
Exhibit B-2

Source: RITTER PHARMACEUTICALS INC, S-4/A, 3/13/2020
<!-- page 34 -->
Exhibit C Development Plan April 28, 2016 FY 2016 Target Review Month April 2016 August 2016
December 2016 Payment ($000) $1,000 $1,000 $1,000 Payment Due Date May 1, 2016 September 1, 2016
January 1, 2017 Criteria for Payment Milestones Completed (Dates shown are projected Completion
dates)

Execution of Definitive Agreement ● FP2.0 Analyzer Validated Software 8/15 ● Vitamin D-Clinical
Studies 11/18

● Delivery of first 5 FP2.0 Analyzer Prototypes 8/8 ● Vitamin D-510k Submission 12/16

● Vitamin D- Design Verification 8/12 ● Testosterone-Feasibility 12/16 ● FP2.0 Analyzer Production -
Order Production Tooling 10/24 Milestones in progress and on schedule (Dates shown are projected
start and completion dates)

● Vitamin D- Design Transfer/ Design Validation (8/22 - 10/21) ● Vitamin D-CE Mark (12/19 - 1/13)

● Testosterone-Feasibility (7/11 - 12/16) ● Vitamin D-CLIA Waiver Study (12/12 - 3/10) ● FP2.0
Analyzer Production - Order Production Tooling (7/19 - 10/24) ● Testosterone- Design Verification
(12/19 - 3/10) ● Pouch Production Line, Issuance of Purchase Order to Manufacturer ($600K on
10/28/16)

● TSH-Feasibility (1/9 - 6/16) ● FP2.0 Analyzer Production - Draft Production Documents (10/25-
12/19) ● Pouch Production Line - Concept Design (10/31 - 1/6) ● Pouch Production Line - Engineering
Drawings ($600K on 3/17/17) Exhibit C-1

Source: RITTER PHARMACEUTICALS INC, S-4/A, 3/13/2020
<!-- page 35 -->
Exhibit C Development Plan April 28, 2016 FY 2017 Target Review Month April 2017 August 2017 January
2018 Payment ($000) $1,300 $800 $375 Payment Due Date May 1 and June 1, 2017 September 1, 2017
February 1, 2018 Criteria for Payment May be split ½ May 1 and ½ June 1 if underlined milestones not
completed by May 1. Milestones Completed (Dates shown are projected Completion dates)

● Vitamin D-CE Mark 1/13 ● Vitamin D-510k Clearance 5/19 ● Vitamin D-Commercialized 10/30 ● Vitamin
D-CLIA Waiver Study 3/10 ● Vitamin D-CLIA Waiver Submission 5/22 ● Testosterone-510k Clearance 12/22
● Vitamin D-510k Clearance 5/19 ● Testosterone-CE Mark 8/18 ● Testosterone-CLIA Waiver Study 10/13 ●
Vitamin D-CLIA Submission 5/22 ● Testosterone-510k Submission 7/21 ● Testosterone-CLIA Waiver
Submission 12/25 ● Testosterone- Design Verification Review 3/24 ● TSH-Feasibility 6/16 ● TSH-
Design Transfer/Design Validation 9/25, 10/30 ● FP2.0 Analyzer Production - Setup Production
Line/Training/QC Documents 3/6

● FP2.0 Analyzer Pilot Builds 1 through 3 8/14 ● PSA-Feasibility 12/15

● Pouch Production Line - Hardware/Software Design 1/9 ● Pouch Production Line - Acceptance Review
7/7 ● FT4-Feasibility 12/15

● Pouch Production Line Installation 8/18 ● Pouch Production Line in service 10/20 ($200K)
Milestones in progress and on schedule (Dates shown are projected start and completion dates)

● Testosterone-Design Transfer/Design Validation (3/27 - 5/26)

● Testosterone-CLIA Waiver Study (7/17 - 10/13) ● TSH-Clinical Studies (11/27 - 12/29)

● TSH-Feasibility (1/9 - 6/16) ● TSH- Design Verification (6/19 - 9/22) ● PSA-Design Verification
(12/18 - 3/23) ● FP2.0 Analyzer Production - Order Parts (3/7 - 7/24) ● TSH- Design Transfer/ Design
Validation (9/25 - 11/24) ● FT4-Design Verification (12/18 - 3/23) ● Pouch Production Line
Fabrication (3/6 - 5/12) ● PSA-Feasibility (7/10 - 12/15)

● Pouch Production Machine Acceptance Test ($600K on 7/17/17)

● FT4-Feasibility (7/10 - 12/15)

● Pouch Production Line Training (8/21 - 9/1) Exhibit C-2

Source: RITTER PHARMACEUTICALS INC, S-4/A, 3/13/2020
<!-- page 36 -->
Exhibit C Development Plan April 28, 2016 FY 2018 Target Review Month April 2018 August 2018 January
2019 Payment ($000) $365 $232 $100 Payment Due Date May 1, 2018 September 1, 2018 February 1, 2019
Criteria for Payment Milestones Completed (Dates shown are projected Completion dates)

● TSH-510k Submission 1/19 ● Testosterone-Commercialized 6/4 ● TSH-Commercialized 12/3 ● TSH-CE Mark
2/16 ● TSH-510k Clearance 6/22 ● PSA-CLIA Waiver Study 9/14 ● TSH-CLIA Waiver Study 4/13 ● TSH-CLIA
Waiver Submission 6/25 ● PSA-510k Clearance 12/21

● PSA- Design Verification 3/9 ● PSA-CE mark 7/23 ● PSA-CLIA Submission 12/24 ● FT4- Design
Verification 3/9 ● FT4-CE mark 7/23 ● FT4-CLIA Waiver Study 9/14 ● FT4-510 Clearance 12/21 ●
FT4-CLIA Submission 12/24 Milestones in progress and on schedule (Dates shown are projected start
and completion dates)

● Testosterone CLIA Waiver Submission under review (12- 26 - 4/30)

● TSH-CLIA Waiver Submission under review (6/26 - 10/29)

● PSA- Design Transfer/ Design Validation (3/26 - 5/25) ● PSA-CLIA Waiver Study (7/16 - 9/14) ● FT4-
Design Transfer/ Design Validation (3/26 - 5/25) ● FT4-CLIA Waiver Study (7/16 - 9/14) ● Payments
made based on progress against the Development Plan as evidenced by completion of milestones
indicated and progress against milestones yet to be completed. Target review month is estimated
timing only. ● Completion of milestones will be based upon the completion of the deliverables, to
Sekisui's satisfaction, in accordance with Qualigen's standard product development practices as
defined in Qualigen's Quality System Procedure Document #91000002 Rev018. Key terms, such as
Feasibility, Verification, Validation and Transfer, are also defined in Qualigen's Quality System
Procedure Document #91000002 Rev018. Exhibit C-3

Source: RITTER PHARMACEUTICALS INC, S-4/A, 3/13/2020
<!-- page 37 -->
Exhibit D-1

Source: RITTER PHARMACEUTICALS INC, S-4/A, 3/13/2020
<!-- page 38 -->
Exhibit D Transfer Price and True-Up Process April 22, 2016 Transfer Prices Initial Transfer Prices
for all Products in aggregate are based on Qualigen's actual April 2015 - December 2015 COGS plus an
amount estimated to represent Qualigen's 10% share of the actual April 2015 - December 2015
Available Margin as defined in Exhibit A and summarized in Table C. Going forward, transfer prices
for Products other than reagent kits will be set as of each October 1 and April 1 for the
prospective 6-month period based on Qualigen's standard unit cost in effect on the first day of the
month prior to the date the new transfer prices are agreed upon (either September 1 and March 1) for
the prospective 6-month period. Going forward, transfer prices for reagent kits will be set as of
each October 1 and April 1 for the prospective 6-month period based on historical COGS for the
earliest 6 months of the 9-month period ended the day before such date plus an amount that is
estimated to represent Qualigen's applicable share of Available Margin with regard to the
retrospective 6-month period as noted in Table A below. Table A below provides timeframes for the
contract term. Both companies' fiscal years run from April 1st to March 31st. Table A

Transfer Price Effective Transfer Price Basis: Retrospective Periods 5/1/2016 - 9/30/2016 4/1/2015 -
12/31/2015 10/1/2016 - 3/31/2017 1/1/2016 - 6/30/2016 4/1/2017 - 9/30/2017 7/1/2016 - 12/31/2016
10/1/2017 - 3/31/2018 1/1/2017 - 6/30/2017 4/1/2018 - 9/30/2018 7/1/2017 - 12/31/2017 10/1/2018 -
3/31/2019 1/1/2018 - 6/30/2018 4/1/2019 - 9/30/2019 7/1/2018 - 12/31/2018 10/1/2019 - 3/31/2020
1/1/2019 - 6/30/2019 4/1/2020 - 9/30/2020 7/1/2019 - 12/31/2019 10/1/2020 - 3/31/2021 1/1/2020 -
6/30/2020 Exhibit D-2

Source: RITTER PHARMACEUTICALS INC, S-4/A, 3/13/2020
<!-- page 39 -->
True-Up Process Per Table B below, for each "True-Up Period", an all-Products true-up will be
prepared to ensure each party receives their contractual margin share of the actual Available
Margin. The true-up process will result in a payment due from either party, depending on which party
has received excess Available Margin for the True-Up Period. True-ups will be determined every six
months. The first true-up will be based on a stub period consisting of results from the first day of
this Agreement to September 30, 2016. Table B below provides the true-up periods and Available
Margin shares. Table B True-Up Period True-up Completed Available Margin Split Sekisui/Qualigen
5/1/2016 - 9/30/2016 10/5/2016 90% / 10% 10/1/2016 - 3/31/2017 4/5/2017 90% / 10% 4/1/2017 -
9/30/2017 10/4/2017 90% Apr, 70% May - Sep / 10% Apr, 30% May - Sep 10/1/2017 - 3/31/2018 4/4/2018
70% / 30% 4/1/2018 - 9/30/2018 10/3/2018 70% Apr, 65% May - Sep / 30% Apr, 35% May - Sep 10/1/2018 -
3/31/2019 4/3/2019 65% / 35% 4/1/2019 - 9/30/2019 10/3/2019 65% / 35% 10/1/2019 - 3/31/2020 4/4/2020
65% / 35% 4/1/2020 - 9/30/2020 10/3/2020 65% / 35% 10/1/2020 - 3/31/2021 4/3/2021 65% / 35% Sekisui
and Qualigen jointly have the responsibility to review and approve each true-up calculation. The
process follows the following steps: 1) Qualigen provides Qualigen-incurred COGS information to
Sekisui (see Table C) 2) Sekisui adds its Net Revenue information and Sekisui-incurred COGS
information (see Table C) to the Qualigen-incurred COGS information and develops the first draft of
the true-up calculation 3) Qualigen and Sekisui review and agree on the calculation. Both parties
will use best efforts to complete the review and approval process in a timely manner. Note: to
ensure the True-up calculation is available for recording in September or March results, both
Qualigen and Sekisui need to be diligent in providing their data on a timely basis according to the
dates set forth in Table B above. Exhibit D-3

Source: RITTER PHARMACEUTICALS INC, S-4/A, 3/13/2020
<!-- page 40 -->
Table C Available Margin Element Qualigen Sekisui Notes Net Revenue x Sales to customer (e.g.
McKesson, Direct or EMEA), less deductions expressly allowed by the Exhibit A definition Material
cost within COGS x x Sekisui cost is for outbound freight and expensed Sekisui Instruments after
5/1/2016 (instruments sold to customers by Sekisui, and provided to customers through the reagent
rental program when instrument cost is less than Sekisui's capitalization threshold) Labor &
Overhead within COGS x Qualigen's manufacturing variances will be charged to COGS in the period
unless such variances exceed 3% of its total production costs, in which case the variances are to be
allocated between inventory and COGS based on total inventory turns for the True-Up Period
Instrument Depreciation x x Sekisui's cost is for Sekisui Instruments purchased after 5/1/2016 and
provided to customers through the reagent rental program (when instrument cost is greater than
Sekisui's capitalization threshold). All Available Margin Elements referenced above shall not
include any of Qualigen's sales to Sekisui that have not been sold at the end of the True- Up Period
by Sekisui to its customers. Exhibit D-4

Source: RITTER PHARMACEUTICALS INC, S-4/A, 3/13/2020
<!-- page 41 -->
EXHIBIT E Qualigen Retained Customers Acct # Name City State 11436 Low T Centers, Inc. and
Affiliates Southlake TX 08260 Chicago Prostate Cancer Center Westmont IL 02217 Elias Tawil, MD
Pittsburg KS 03268 Lake Success Urological Lake Success NY 01815 Mason City Clinic Mason City IA
02358 Surgical Assoc. Northwest PC Federal Way WA 03197 Surgical Assoc. Northwest, PC Auburn WA
02845 Urological Assoc. Grand Island Grand Island NE 02575 Urology Care, Inc.- Jefferson Jefferson
City MO 01343 Warren L. Lowry, M.D., S.C Rockford IL 00051 Iowa Clinic West Des Moines IA Exhibit
E-1

Source: RITTER PHARMACEUTICALS INC, S-4/A, 3/13/2020
<!-- page 42 -->
Exhibit F Qualigen Financial Process flow overview: Requirements for Purchasing/OTC/Finance
reporting Updated 4/15/16 All customer and inventory transactions will be recorded at SD at a
summary level. Qualigen would maintain all supporting detail on their accounting system. Procure to
Pay 1) Qualigen to provide SD purchasing an SD inventory report by SKU on the first work day of the
month. 2) SD and Qualigen to prepare and agree to a monthly rolling 12 month product forecast by SKU
to be provided to Qualigen by SD purchasing the fifth work day of the month. 3) SD Purchasing will
coordinate with Qualigen to determine safety stock levels and re-order timing based on current SD
inventory levels and lead times. 4) SD Purchasing will submit a purchase order for inventory to
Qualigen monthly. 5) Qualigen will invoice SD for inventory purchased according to the SD Purchase
order. 6) SD A/P to pay invoice from Qualigen per agreed upon terms of payment. Order to Cash 1) SD
customer to submit Purchase order to Qualigen for Qualigen products. 2) Sales order entered into
Qualigen ERP system by Qualigen customer service on behalf of SD. 3) Credit card customers provide
credit card information to Qualigen customer service via SD credit card form. Qualigen customer
service provides to SD finance credit card information for verification prior to shipment. 4) Order
fulfilled and shipped to SD customer by Qualigen. 5) Qualigen generates SD invoice to customer at
full commercial value on behalf of SD. 6) Freight charges should be managed as freight collect on
Customer account or SD account. 7) Invoice sent to SD customer by Qualigen on behalf of SD. 8)
Customer remits to SD lock box 9) Qualigen manages the cash applications for SD accounts receivable.
10) Customer relationship for management of debt collections to be managed by SD. Exhibit F-1

Source: RITTER PHARMACEUTICALS INC, S-4/A, 3/13/2020
<!-- page 43 -->
Finance month end reporting 1) Qualigen to provide no later than work day 2 the following
information for SD related data to SD Finance: a. A/R balances by Customer b. Inventory Balances by
SKU - quantity, and SD cost (transfer price) c. Units Sold in the month by SKU and cost (transfer
price, if available) d. Summary Invoiced Revenue by Customer by SKU e. Prompt pay, channel fees,
chargebacks information f. Fixed Asset information, e.g. instrument by customer, location, serial #,
etc. 2) SD Finance will create journal entries to record Sales, A/R, COGS, Inventory and any related
reserve or revenue adjustments using monthly reports with information provided by Qualigen. 3) SD
Finance will coordinate with Qualigen to conduct an annual physical count of inventory at their
location. 4) SD finance and Qualigen finance will schedule routine meetings to discuss monthly
reports or discrepancies. 5) SD finance reconciles margin split, per the agreement terms, with
Qualigen. Qualigen will have custodial responsibility for Sekisui inventory held at Qualigen. Any
inventory shrinkage or damage to Sekisui inventory while at Qualigen will be Qualigen's
responsibility. Exhibit F-2

Source: RITTER PHARMACEUTICALS INC, S-4/A, 3/13/2020
<!-- page 44 -->
Exhibit F-3

Source: RITTER PHARMACEUTICALS INC, S-4/A, 3/13/2020
<!-- page 45 -->
Exhibit F-4

Source: RITTER PHARMACEUTICALS INC, S-4/A, 3/13/2020
<!-- page 46 -->
Exhibit F-5

Source: RITTER PHARMACEUTICALS INC, S-4/A, 3/13/2020
<!-- page 47 -->
SCHEDULE 2.1 Qualigen Distribution Agreements 1. McKesson Distribution Agreement effective April 20,
2010 as amended August 12, 2013 and April 20, 2015 2. McKesson Marketing Service Agreement effective
July 1, 2014 3. Woongbee MeDiTech Inc. Distribution Agreement dated November 12, 2002 4. Nanova Co.,
Ltd. Distribution Agreement dated October 29, 2014 5. Axon Lab A.G. Distribution Agreement effective
September 22, 2015 The following Distribution Agreements also shall be assigned upon Sekisui's
request. A. Alpha Diagnostics Sp. Z o.o Distribution Agreement dated November 15, 2010 B. Cariad
Technologies Ltd. distribution Agreement dated April 15, 2005, as amended May 30, 2005 C. CliniLine,
S.A. Distribution Agreement dated February 5, 2003, as amended October 27, 2004 Schedule 2.1

Source: RITTER PHARMACEUTICALS INC, S-4/A, 3/13/2020
