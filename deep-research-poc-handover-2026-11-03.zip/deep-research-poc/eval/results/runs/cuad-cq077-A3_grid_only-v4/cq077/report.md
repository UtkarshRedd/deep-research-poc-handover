# Among the following 8 agreements, which contain a non-compete clause? For each, quote t...

*Question:* Among the following 8 agreements, which contain a non-compete clause? For each, quote the clause. Agreements: the Endorsement Agreement between Eco Science Solutions, Inc and Stephen Marley (dated 2017-11-14); the Network Affiliate Agreement between National CineMedia, LLC and Digital Cinema Destinations Corp. (dated 2011-03-14); the Exclusive Distributor Agreement between Erchonia Corporation and InnerScope Hearing Technologies Inc (filed 2018-11-09); the Supply Agreement between Integra LifeSciences Corporation and PcoMed, LLC (dated 2013-05-15); the Reseller Agreement between Touchstar Software Corporation and Worldwide Strategies (filed 2005-11-02); the Cooperation Agreement between e.l.f. Beauty, Inc. and Marathon Partners Equity Management, LLC (dated 2020-07-01); the Sponsorship Agreement between Stallings Capital Group Consultants, Ltd. and GAINSCO, INC. (dated 2010-01-01); the Strategic Alliance Agreement between Freedom Mortgage Corporation and Cherry Hill Mortgage Investment Corp. (filed 2013-09-26).

## Identify agreements containing non-compete clauses

The Endorsement Agreement between Eco Science Solutions, Inc and Stephen Marley does not contain a non-compete clause. [4cb98e07400203bf p.1]

[GAP] Evidence for the Network Affiliate Agreement between National CineMedia, LLC and Digital Cinema Destinations Corp. is missing.

[GAP] Evidence for the Exclusive Distributor Agreement between Erchonia Corporation and InnerScope Hearing Technologies Inc is missing.

[GAP] Evidence for the Supply Agreement between Integra LifeSciences Corporation and PcoMed, LLC is missing.

[GAP] Evidence for the Reseller Agreement between Touchstar Software Corporation and Worldwide Strategies is missing.

[GAP] Evidence for the Cooperation Agreement between e.l.f.

Beauty, Inc. and Marathon Partners Equity Management, LLC is missing. [uncited]

[GAP] Evidence for the Sponsorship Agreement between Stallings Capital Group Consultants, Ltd. and GAINSCO, INC. is missing.

[GAP] Evidence for the Strategic Alliance Agreement between Freedom Mortgage Corporation and Cherry Hill Mortgage Investment Corp. is missing.

## Not established by the evidence

[GAP] No evidence was found for: Quote the exact non-compete clause text from each agreement identified as containing one.

## Verification appendix

Claims: 10 · supported: 1 · partially: 0 · dropped: 0 · gaps: 9 · tier-1 support rate: 1.00

Notes: 1 empty section(s) collapsed into gaps: Extract non-compete clauses

| claim | section | tier 1 | score | sources | note |
|---|---|---|---|---|---|
| s1.1 | s1 | keep | 1.00 | e1→[4cb98e07400203bf p.1] |  |
| s1.2 | s1 | gap |  |  |  |
| s1.3 | s1 | gap |  |  |  |
| s1.4 | s1 | gap |  |  |  |
| s1.5 | s1 | gap |  |  |  |
| s1.6 | s1 | gap |  |  |  |
| s1.7 | s1 | gap |  |  | no evidence cited |
| s1.8 | s1 | gap |  |  |  |
| s1.9 | s1 | gap |  |  |  |
| gaps.1 | gaps | gap |  |  |  |

### Evidence

- e1 [4cb98e07400203bf p.1 L18-20] keep (1.0): "1. Engagement. ESSI engages Talent and Talent hereby accepts the engagement to act as a Spokesperson for ESSI, and to provide his endorsement of all ESSI products and services, domestically and worldwide."
