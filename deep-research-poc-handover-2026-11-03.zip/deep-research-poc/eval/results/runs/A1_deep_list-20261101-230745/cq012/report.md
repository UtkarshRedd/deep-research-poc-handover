# Which jurisdiction's law governs the Business Development Agreement between LIQUIDMETAL...

*Question:* Which jurisdiction's law governs the Business Development Agreement between LIQUIDMETAL TECHNOLOGIES, INC. and EUTECTIX, LLC (filed 2020-02-05)?

## Answer

[GAP] The writer produced nothing for: Answer the question: Which jurisdiction's law governs the Business Development Agreement between LIQUIDMETAL TECHNOLOGIES, INC. and EUTECTIX, LLC (filed 2020-02-05)?

## Verification appendix

Claims: 1 · supported: 0 · partially: 0 · dropped: 0 · gaps: 1

Notes: OpenAIRateLimitError: Error code: 429; OpenAIRateLimitError: Error code: 429; OpenAIRateLimitError: Error code: 429

| claim | section | tier 1 | score | sources | note |
|---|---|---|---|---|---|
| s1.1 | s1 | gap |  |  |  |

### Evidence

