<!-- page 1 -->
# DISTRIBUTOR AGREEMENT
| Field | Value |
|---|---|
| Document Type | Distributor Agreement |
| Agreement Date | 2020-03-19 |
| Parties | Co-Diagnostics, Inc. ("Principal"); PreCheck Health Services, Inc. ("Distributor") |
| Source | CUAD v1 / PrecheckHealthServicesInc_20200320_8-K_EX-99.2_12070169_EX-99.2_Distributor Agreement |

EXHIBIT 99.2 Page 1 of 3 DISTRIBUTOR AGREEMENT Agreement made this 19t h day of March, 2020 Between:
Co-Diagnostics, Inc. (herein referred to as "Principal") And PreCheck Health Services, Inc. (herein
referred to as "Distributor"). In consideration of the mutual terms, conditions and covenants
hereinafter set forth, Principal and Distributor acknowledge and agree to the following descriptions
and conditions: DESCRIPTION OF PRINCIPAL The Principal is a company located in Utah, United States
and is in the business of research and development of reagents. The Principal markets and sells it
products globally through direct sales and distributors. DESCRIPTION OF DISTRIBUTOR The Distributor
is a company operating or planning to operate in the United States of America, Latin America, Europe
and Russia. The Distributor represents that the Distributor or a subsidiary of the Distributor is or
will be fully licensed and registered in the Territory and will provide professional distribution
services for the products of the Principal. CONDITIONS: 1. The Principal appoints the Distributor as
a non-exclusive distributor, to sell Principal's qPCR infectious disease kits, Logix Smart COVID-19
PCR diagnostic test and Co-Dx Box™ instrument (the "Products"). The Products are described on
Exhibit A to this Agreement. 2. The Principal grants Distributor non- exclusive rights to sell these
products within the countries of Romania (the "Territory"), which may be amended by mutual written
agreement.

Source: PRECHECK HEALTH SERVICES, INC., 8-K, 3/20/2020
<!-- page 2 -->
3. The Distributor accepts the appointment and shall use its commercially reasonable efforts to
promote, market and sell the Products within the Territory, devote such time and attention as may be
reasonably necessary and abide by the Principal's policies. 4. The Principal shall maintain the
right to contact and market its products to potential customers in the Territory; but agrees to pass
on all sales leads and orders to the Distributor. 5. The parties agree that the list of Products
and/or prices may be amended from time to time. The Principal may unilaterally remove Products from
the catalog or change prices. Additions to the Products shall be by mutual agreement. However, in
the event the Distributor rejects a new product addition to the product list, the Principal shall
then retain the right to market and distribute the new product that is rejected by the Distributor.
6. Unless accepted by the Principal, the Distributor agrees that during the term of this Agreement,
the Distributor, either directly or indirectly, shall handle no products that are competitive with
the Products within the Territory. 7. The Distributor shall obtain at its own expense, all necessary
licenses and permits to allow the Distributor to conduct business as contemplated herein. The
Distributor represents and warrants that the Distributor shall conduct business in strict conformity
with all local, state and federal laws, rules and regulations. 8. The Principal agrees that the
Distributor may employ or engage representatives or sub-distributors in furtherance of this
Agreement and the Distributor agrees that the Distributor shall be solely responsible for the
payment of wages or commissions to those representatives and sub-distributors, and that under no
circumstances shall Distributor's representatives be deemed employees of Principal for any purpose
whatsoever. 9. Principal will grant Distributor a discount based on the Products and Prices. The
proposed discount is expected to be ¨%. Discount may vary depending on product volume ordered or
promotions. 10. This Agreement shall be in effect until March 18. 2021, unless sooner terminated by
either party upon (30) days written notice, without cause. 11. In the event of termination, the
Distributor shall be entitled to receive all orders accepted by the Principal prior to the date of
termination and may sell the ordered Products in the Territory. Payment to be made upon shipment.

Source: PRECHECK HEALTH SERVICES, INC., 8-K, 3/20/2020
<!-- page 3 -->
12. In the event of termination, neither party, their heirs nor successors shall issue any challenge
whatsoever to contest the termination. 13. The Distributor is an independent contractor and nothing
contained in this agreement shall be deemed or interpreted to constitute the Distributor as a
partner or employee of the Principal, nor shall either party have any authority to bind the other in
any respect, it being understood and agreed that all orders submitted by the Distributor are subject
to acceptance by Principal in its sole discretion. 14. It is agreed between the parties that there
are no other agreements or understandings between them relating to the subject matter of this
Agreement. This Agreement supersedes all prior agreements, oral or written, between the parties and
is intended as a complete and exclusive statement of the agreement between the parties. No change or
modification of this Agreement shall be valid unless the same be in writing and signed by the
parties. 15. This Agreement shall not be assigned by the Distributor without the prior written
consent of the Principal. 16. Official communication from Distributor or the Principal shall be in
written form or by email, acknowledged by the recipient. 17. This Agreement shall be construed in
accordance with and governed by the laws of the State of Texas without regard to principles of
conflicts of laws. 18. Each of Principal and Distributor represents that it has the right to enter
into this Agreement and that this Agreement does not violate any agreement to which it is a party.
Principal represents that it owns or has rights to the intellectual property embodied in the
Products. Intending to be legally bound, the parties hereto have caused this Agreement to be
executed as of the date first above written. BY /s/ Cameron Gundry BY /s/ Justin Anderson Cameron
Gundry, Dir. of Commercialization Justin Anderson, CEO Co-Diagnostics, Inc. PreCheck Health
Services, Inc. (Principal) (Distributor)

Source: PRECHECK HEALTH SERVICES, INC., 8-K, 3/20/2020
<!-- page 4 -->
.EXHIBIT A LIST OF PRODUCTS

Source: PRECHECK HEALTH SERVICES, INC., 8-K, 3/20/2020
<!-- page 5 -->
Source: PRECHECK HEALTH SERVICES, INC., 8-K, 3/20/2020
<!-- page 6 -->
Source: PRECHECK HEALTH SERVICES, INC., 8-K, 3/20/2020
