<!-- page 1 -->
# MARKETING AND TRANSPORTATION SERVICES AGREEMENT
| Field | Value |
|---|---|
| Document Type | Transportation Agreement |
| Agreement Date | 1995-11-20 |
| Parties | Purolator Courier Ltd. ("Purolator"); Parcelway Courier Systems Canada Ltd. a subsidiary of Dynamex Inc. ("Dynamex") |
| Source | CUAD v1 / DYNAMEXINC_06_06_1996-EX-10.4-TRANSPORTATION SERVICES AGREEMENT |

1 EXHIBIT 10.4

MARKETING AND TRANSPORTATION SERVICES AGREEMENT

THIS AGREEMENT made in duplicate this 20 day of November, 1995.

B E T W E E N:

PUROLATOR COURIER LTD. ("Purolator") - and - PARCELWAY COURIER SYSTEMS CANADA LTD. a subsidiary of
Dynamex Inc. ("Dynamex")

WHEREAS Purolator inter alia, is licensed to provide courier services for compensation across Canada
and the United States of America;

AND WHEREAS Dynamex inter alia, is licensed to provide courier services for compensation across
Canada and the United States of America;

AND WHEREAS Purolator's principal business activity is next day or multiple day service:

AND WHEREAS Dynamex' principal business is sameday service;

AND WHEREAS Purolator and Dynamex wish to cooperate, as independent contractors, in the marketing of
their respective services and in the provision of those services to their respective customers;

NOW THEREFORE in consideration of the mutual covenants contained in this Agreement, the Parties
hereto agree as follows:

1.0 DEFINITIONS

1.1 The following words shall have the following meanings throughout this Agreement: a) "Agreement"
means this Agreement and all Schedules annexed hereto, as amended from time to time by the Parties;

b) "Freight" means any goods directed to one Party by the other for pick up and/or delivery;

c) "Force Majeure" means

i) An Act of God;

ii) A strike, lock out or other labour disturbance;

2 - 2 -

iii) A war, revolution, insurrection, riot, blockade or any other unlawful act against public order
authority; iv) A storm, fire, flood, explosion, lightening or other hazardous weather condition; v)
Any Ministry of Transportation road closure or other acts of government or transport authorities
which are beyond the control of the Parties; vi) Any air traffic control delays, cancellations,
reroutes or other acts of government, airport or aviation authorities, which are beyond the control
of the Parties; vii) Any loss, hijacking, government seizure or diversion.

1.2 All references to currency in this Agreement shall be to Canadian currency, unless otherwise
indicated.

1.3 All references to days in this Agreement are references to calendar days unless the reference is
to business days, in which case business days shall be interpreted as business days as designated in
the Province of Ontario.

2.0 TERM

2.1 This Agreement shall be effective from the date first above written and shall continue
indefinitely until terminated by either Party in accordance with the provisions of this Agreement.

3.0 SCOPE OF SERVICES

3.1 Subject to the terms and conditions hereinafter set out, Purolator agrees to do the following:

i) Offer sameday courier services to its customers under the Purolator name and trade-mark;
<!-- page 2 -->
ii) Tender to Dynamex all sameday courier service requests that it receives;

iii) In connection with such sameday service requests, Purolator will handle the customer request,
will dispatch the pickup request to Dynamex, will be responsible for billing the customer for the
service and collecting the revenue and provide such sales and marketing service, in conjunction with
Dynamex, as may be necessary;

iv) Will provide its next day and multiple day transportation services to Dynamex' customers as may
be required from time to time, such services to be provided in accordance with the service standards
set out in Schedule "A" attached hereto, which service standards may be amended from time to time;

3 - 3 -

v) In providing such next day or multiple day services, agrees to provide customer service,
dispatch, pickup and delivery, tracing and tracking, together with joint sales and marketing efforts
with Dynamex, and will invoice Dynamex for the services provided at the rates provided for herein.

3.2 Subject to the terms and conditions hereinafter set out, Dynamex agrees to do the following:

i) Offer overnight courier services to its customers under the Dynamex name and trade-mark;

ii) Tender to Purolator all overnight courier service requests that it receives;

iii) In connection with such overnight service requests, will handle the customer request, will
dispatch the pickup request to Purolator, will be responsible for billing the customer for the
service and collecting the revenue and provide such sales and marketing service, in conjunction with
Purolator, as may be necessary;

iv) Will provide its sameday transportation services to Purolator's customers as may be required
from time to time, such services to be provided in accordance with the service standards set out in
Schedule "B" attached hereto, which service standards may be amended from time to time;

v) In providing such sameday services, agrees to provide customer service, dispatch, pickup and
delivery, tracing and tracking, together with joint sales and marketing efforts with Purolator, and
will invoice Purolator for the services provided, at the rates provided for herein.

3.3 For greater certainty, it is understood and agreed that either Party, in providing the services
referred in 3.1 and 3.2 above, may agree to a variation of the services to be provided, including
but not limited to who shall provide pick up and delivery, tracking, tracing, dispatch or other
services.

3.4 Each Party agrees to provide the services outlined above at an on time performance level of no
less than ninety percent (90%) of the scheduled delivery time, excluding delays caused by the other
Party or events of Force Majeure. Monthly, the performance level shall be measured as set out above.
Failure to provide services as set out herein constitutes a Monthly Service Failure.

3.5 Except for the joint marketing efforts referred to in Section 3.1 (v) above, Purolator agrees
not to directly or indirectly solicit next day or multiple day freight from existing sameday
customers of Dynamex. 4 3.6 Except for the joint marketing efforts referred to in Section 3.1 (v)
above, Dynamex agrees not to directly or indirectly solicit overnight freight from customers of
Purolator.

3.7 Purolator agrees to tender to Dynamex all sameday service requests that it receives.

3.8 Dynamex agrees to tender to Purolator all next day and multiple day transportation requests to
Purolator for delivery.

3.9 Dynamex agrees not to provide sameday delivery services for any other provider of next day or
multiple day courier services. It is understood and agreed that Dynamex, from time to time and upon
request, may provide pick-up and/or delivery services for other next-day or multiple day courier
service providers, as part of their next-day and multiple day service commitment, provided Dynamex'
services will not result in the provision of same day service to the customer of the provider of
next-day or multiple day courier service.
<!-- page 3 -->
Dynamex may continue to provide the same day service it currently provides to Alltours customers,
provided revenue to Dynamex from this business does not exceed Five Thousand Dollars ($5,000.00) per
month provided there is no change in control, direct or indirect, in Alltours.

3.10 It is understood and agreed by the Parties that each Party presently offers a number of
services which are complementary to those provided for herein, including but not limited to mail
room management services and building distribution services. In that regard, Dynamex offers its
services as Dynamex while Purolator offers its services under the name Distribution Management
Services Inc. or DMS. It is understood and agreed that nothing in this Agreement shall prevent the
Parties from continuing to provide such services or their continued development of such
services/operations.

3.11 The Parties covenant and agree that this Agreement shall cover their services throughout Canada
and the United States of America. If either Party desires to enter into an agreement with another
party providing for services similar to those provided for herein, in either Canada or the United
States of America or both, or to provide services similar to those provided for herein without an
agreement, then same can only be done with the prior written consent of the other Party. It is
understood and agreed that Dynamex may enter into an Agreement with another party to provide its
services as described herein in the United States, provided however that any such agreement shall
not preclude or prevent Dynamex from providing such Services to Purolator in the United States.

3.12 Attached hereto as Schedule "C" to this Agreement is the Operational Plan for this Agreement.
The Operational Plan details the obligations and responsibilities of the Parties pursuant to this
Agreement, including but not limited to details as to the handling of freight, the exchange of
freight, customer service, billing, invoicing, track and

5 tracing responsibilities. Monthly, the Parties shall conduct operational meetings to adjust
co-ordination, operational planning and any other requirements determined by the Parties from time
to time.

4.0 RATES

4.1 Subject to all other terms and conditions of this Agreement, Purolator shall pay to Dynamex the
rates set forth in Schedule "D".

4.2 Subject to all other terms and conditions of this Agreement, Dynamex shall pay to Purolator the
rates set forth in Schedule "E".

5.0 PAYMENT PROCEDURES

5.1 Each Party shall invoice the other twice a month, effective the fifteenth (15th) day and the
last day of the month for services rendered for the period since the last invoicing.

5.2 Every invoice shall be accompanied by supporting documentation to substantiate same. Failure to
provide such documentation shall result in payment of only the invoiced amount which is supported by
the documentation.

Any amounts invoiced which are not supported by documentation shall not be paid until such time as
documentation is provided by the invoicing Party.

It is understood and agreed that Bills of Lading will not be required as supporting documentation.

5.3 Dynamex must forward all invoices in duplicate and required documentation pertaining to this
Agreement, to the attention of:

Purolator Courier Ltd. 5995 Avebury Road, Suite 500 Mississauga, Ontario L5R 3T8

Attention: Finance

5.4 Purolator must forward all invoices in duplicate and required documentation pertaining to this
Agreement, to the attention of:

Dynamex Express 2630 Skymark Avenue Mississauga, Ontario L4W 5A4

5.5 Every invoice shall be reviewed by the invoiced Party and subject to paragraphs 5.2, shall pay
the invoice net fifteen (15) days from the date of invoicing. Invoices shall be delivered to the
invoiced Party within three (3) days of the date of invoicing.

6 - 6 -
<!-- page 4 -->
5.6 Interest, at the prime rate then charged to commercial customers by the Canadian Imperil Bank of
Commerce (Toronto Main Branch), shall be payable on all amounts overdue for thirty (30) days or
more.

5.7 Any discrepancy in an invoice which is discovered by either Party may result in the issuance of
a debit note or credit note by the appropriate Party, and notwithstanding any prior payment, the
same shall be accompanied by supporting documentation. Payment shall be made by the appropriate
Party net fifteen (15) days from receipt and acceptance of the documentation.

5.8 (a) The Parties acknowledge and agree that the Services to be provided hereunder constitute the
supply of freight transportation services in the course of the continuous movement of freight, also
referred to as interlining. Accordingly, the Services under this Agreement are zero-rated for the
purposes of the Goods and Services Tax (hereinafter referred to as "GST") pursuant to Section 1 of
Part VII of Schedule VI of the Excise Tax Act, R.S.C. 1985, Chapter E-15, as amended from time to
time.

(b) In the event that "GST" or any other value added or sales taxes are applicable at any time
during the Term of this Agreement:

(i) Either party shall be liable for the same, if applicable;

(ii) Either Party shall identify such tax separately on each invoice; and

(iii) Either Party's GST registration number shall appear on each invoice.

6.0 LIABILITY FOR LOSS OR DAMAGE

6.1 A Party shall be liable to the other for loss, damage or delay to Freight due to its acts or
omissions, including its negligence, and those of its employees, agents and those for whom in law it
is responsible and occurring while Freight is in its care, custody or control. For the purpose of
this Agreement, Freight shall be considered in the care, custody or control of a Party from the time
it is tendered to it by the other Party or the other Party's customer until the time of its delivery
to the other Party or the consignee, as intended. For greater certainty, a Party shall not be liable
hereunder if the Freight is damaged solely as a result of improper packing.

6.2 A Party shall, in the event of loss, damage or delay to Freight while in its care, custody or
control, immediately notify the other Party of the loss or damage, carry out an investigation of the
incident to determine the cause of such loss, damage or delay and shall within

7 thirty (30) days of the event of loss, damage or delay or knowledge of such incident of loss,
damage or delay, whichever is later, as the case may be, report its findings to the other Party. All
costs associated with such investigation shall be the responsibility of such Party if the loss,
damage or delay was due to the acts or omissions or those of its employees, agents or those for whom
in law its is responsible; otherwise, the costs shall be shared equally by the Parties hereto.

6.3 A party shall, for any loss, damage or delay to Freight while in its care, custody or control,
forthwith pay to the other Party the actual damages suffered by such other Party. Such liability
shall not exceed the other Party's contractual liability to its customers. The Parties acknowledge
that their contract of carriage with their customers provides that liability for loss, damage or
delay, including liability for consequential loss, is limited to Four Dollars and Forty One Cents
($4.41) per kilogram or Two Dollars ($2.00) per pound unless a higher value has been declared for
insurance purposes.

7.0 SET-OFF

7.1 A Party shall pay to the other the full amount of any paid claim, loss or damage for which it is
liable within forty five (45) days following presentation of supporting documentation. If a Party
fails to pay following presentation of supporting documentation then the other Party shall have the
right to deduct the amount of such claim, loss or damage from any monies due or becoming due to the
first Party by the second Party.

8.0 INDEMNIFICATION

8.1 Each Party shall at all times indemnify and hold harmless the other, its directors, officers,
employees and any others for whom it may be responsible in law, from and against all claims,
including claims made by the indemnifying Party's personnel under worker's compensation legislation,
demands, awards, judgments, actions and proceedings by whomsoever made, brought or prosecuted in
respect of loss of, damage to or destruction of property (including loss or damage sustained by the
indemnifying party) or personal injury including death and from and against any and all loss or,
damage to or destruction of property, expenses and costs (including legal fees and disbursements)
suffered or incurred by the indemnifying Party, its directors, officers, employees
<!-- page 5 -->
and any others for whom it may be responsible in law, arising out of or in any way connected with
the indemnifying Party, its directors, officers, employees and any others for whom it may be
responsible in law, arising out of or in any way connected with the indemnifying Party provision of
Services under this Agreement and whether or not caused by the indemnifying Party's negligence. Loss
or damage sustained by the indemnifying Party shall also include loss as a result of loss of use.

8 - 8 -

8.2 Notwithstanding anything contained herein to the contrary, the indemnifying party's liability to
the other hereunder shall not exceed the insurance coverage set out in Section 9.0.

9.0 INSURANCE

9.1 Each Party shall purchase and maintain, at its own expense, the following insurance coverages:

(a) cargo liability insurance, subject to a combined single limit of not less than One Hundred
Thousand dollars ($100,000.00) inclusive per occurrence. The other Party shall be named as an
additional insured and the policy shall contain a cross liability clause;

(b) automobile, non-owned automobile, fleet, comprehensive general, public and property liability
insurance with a limit of not less than Two Million dollars ($2,000,000.00) inclusive of bodily
injury and property damage for any one occurrence arising out of one (1) cause. The policy shall
cover all non-air operations, non-owned automobile, contractual liability and liability specifically
assumed under this Agreement. The other party shall be named as an additional insured and the policy
shall contain a cross liability clause;

9.2 Each Party shall deliver to the other, prior to commencing to provide the Services and
thereafter, annually, a certificate or certificates of insurance evidencing that the required
insurance coverages as provided for in paragraph 9.1 are in effect and that each Party shall be
given thirty (30) days prior written notice of cancellation or expiry of or material change to such
insurance coverages.

9.3 The Policies set out in paragraph 9.1 shall contain a waiver of subrogation rights in favour of
the other Party, its officers, directors, employees and any others for whom it may be responsible in
law.

9.4 Each Party shall maintain the insurance coverages provided for in paragraph 9.1 hereof, in full
force and effect during the term of this Agreement and covenants that nothing shall be done whereby
any policy will be cancelled and shall pay all renewal premiums thereon on or before the due date
and shall forthwith furnish the other Party with copies of certificates of insurance of such
renewals.

9.5 The policies set out in paragraph 9.1 shall not limit the insurance required by municipal,
provincial, federal or other law. It shall be the sole responsibility of each Party to determine
what additional insurance coverages, if any, are necessary and advisable for its own protection

9 - 9 -

or to fulfil its obligations under this Agreement. Any such additional insurance shall be provided
and maintained by that Party at its own expense.

9.6 Each Party shall ensure that any subcontractor or other party with whom it contracts in
providing the Services shall carry adequate insurance coverage, but not less than that provided in
paragraph 9.1.

10.1 COMPLIANCE WITH LAW

10.1 (a) Each Party shall comply with all legislation directly or indirectly applicable to the
performance of its obligations under this Agreement.

(b) Each Party shall notify the other at least thirty (30) days or in any event as soon as possible,
before any change is made in its licences or operating authorities which may affect in any way the
performance of any of its obligations under this Agreement.

11.0 PROTECTION OF FREIGHT

11.1 Each Party shall take all reasonable measures to ensure that Freight in its care, custody or
control is protected at all times from theft, weather and all other damage or danger, and without
restricting the foregoing, shall ensure that:

(a) Freight is not kept out-of-doors except for purposes of loading or off loading; and

(b) If at any time Freight is not under its complete visual and physical control, it shall provide a
secure storage area
<!-- page 6 -->
in a facility at its own cost.

12.0 SECURITY

12.1 Each Party shall ensure that all reasonable security and investigation measures are implemented
including but not limited to the provisions set forth in Schedule "F" respecting the provision of
Services.

12.2 Each Party shall implement and put in place security and investigation procedures to ensure the
protection and security of Freight. These procedures shall include spot checks, inspections,
reporting, investigations and any other procedures to ensure not only that the Services required by
the other Party are provided but that the Services are provided in accordance with industry
standards.

10 - 10 -

13.0 DANGEROUS GOODS

13.1 The Parties acknowledge that the Transportation of Dangerous Goods Act, S.C. 1992, c.34, as
amended from time to time (hereinafter referred to as the "TDGA") prohibits transportation of any
explosive, dangerous or destructive substance, or anything likely to injure or damage property or
persons (hereinafter referred to as "Dangerous Goods") unless the requirements of the TDGA are met.
The Parties agree that they only intend for Dangerous Goods to be carried pursuant to this Agreement
if the requirements of the TDGA are met and both Parties are aware that such goods are being
carried. Notwithstanding the foregoing, the Parties agree that neither Dynamex nor Purolator shall
be under any obligation or duty whatsoever to open for prior inspection any Freight tendered to
Dynamex pursuant to this Agreement. Neither Party shall be responsible for any losses or damage
whatsoever that may be sustained by the other Party, its directors, officers, employees and any
persons for whom it may become responsible in law, as a result of any Dangerous Goods contained in
Freight unless such Party had actual prior knowledge of the presence of Dangerous Goods. In the
event a Party had actual prior knowledge of the presence of Dangerous Goods, then it shall be liable
for loss or damage to the other Party if it would otherwise be liable under this Agreement or at
law.

13.2 Each Party must comply with the placarding and all other regulations applicable to the handling
of Dangerous Goods. The Parties agree to maintain at their own expense a current Dangerous Goods
Training Certificate for both air and ground shipments for itself and its operators during the term
of this Agreement and to provide the other Party with a copy of same upon execution of the Agreement
and thereafter, as the Parties request, failure of which may result in the termination of this
Agreement immediately by the other Party.

13.3 The Parties agree to ensure that their respective Dangerous Goods Handling Procedures are
compatible to ensure complete adherence with the Legislation and Regulations. Each Party agrees to
promptly advise the other of any changes to its Dangerous Goods Handling Procedures.

14.0 RECORDS AND REPORTS 14.1 Each Party shall maintain performance reports, comparing actual to
scheduled departure and arrival times for Services provided. Such reports shall be made available
for review by the other Party and in connection with same, a Party shall provide copies of all data
and records relating thereto.

11 - 11 -

14.2 Each Party shall maintain complete maintenance and operational records.

14.3 Each Party shall keep accurate books, accounts and records covering all transactions relating
to this Agreement, including books of original entry, and upon request from the other Party, shall
allow access to same.

14.4 Either Party shall have the right to request the other to provide, through an auditor agreed to
by the Parties, validation of the information and data referred to herein.

15.0 CONTINGENCY PLANS

15.1 In the event a Party is unable to provide the Services as a result of a strike or other labour
disruption caused by its employees, it shall attempt to subcontract the Services to another operator
or operators, acceptable to the other Party. Such Services shall be provided by such
subcontractor/subcontractors on the same terms and conditions herein set out and will be continued
to be provided during the period of any such strike or labour disruption, unless this Agreement is
otherwise terminated pursuant to the provisions of this Agreement. It is understood and agreed that,
if such Party provides the Services by subcontracting to another operator/operators, then it shall
be deemed not to be in default pursuant to paragraph 17.1(c). Notwithstanding same, all other
default provisions as set out in paragraph 17, continue to apply.
<!-- page 7 -->
16.0 SERVICE FAILURE REMEDIES

16.1 In the event that Monthly Performance Failures occur more than three (3) times in any twelve
(12) month period, an Event of Default shall have occurred.

17.0 DEFAULT PROVISIONS

17.1 For the purposes of this Agreement, the following shall constitute events of default by a Party
(hereinafter referred to as "Events of Default"):

(a) if a petition is filed against it under any applicable bankruptcy legislation and is not
withdrawn or dismissed within sixty (60) days thereafter;

(b) if a resolution is passed by it respecting the sale of all or substantially all of its assets,
or an order for the winding up of its business is made, or it otherwise agrees to make a bulk sale
of it's assets;

(c) if it ceases or threatens to cease to carry on its business;

12 - 12 -

(d) if it commits or threatens to commit an act of bankruptcy, or if it becomes insolvent or
bankrupt or makes an assignment or if a receiver or receiver manager is appointed in respect of its
business and affairs of either by way of private instrument or through court proceedings;

(e) if a judgment or order is entered with respect to it under the Company Creditors Arrangement Act
R.S.C. 1985, Chapter C-36, as amended, or similar legislation, or it takes advantage of the
provisions of any bankruptcy or insolvency legislation;

(f) if any execution, or any other process of any court becomes enforceable against all or
substantially all of it's property or if a distress or analogous process is levied against all or
substantially all of its property;

(g) if it is in default as per paragraph 16.1 hereof; or

(h) if it otherwise neglects or fails to perform or observe any of its obligations under this
Agreement and fails to cure the breach or default within thirty (30) days of written notice to the
other Party.

17.2 Upon the occurrence of an Event of Default and in addition to any rights or remedies available
to it under this Agreement or at law or in equity, the Party not in default may exercise any or all
of the following remedies:

(a) terminate this Agreement, upon giving one hundred and twenty (120) days written notice,
otherwise upon written notice with respect to 17.1 (g) and (h);

(b) recover from the defaulting Party any and all monies then due and to become due; and

(c) take possession, immediately, without demand or notice, without any court order or other process
of law, any and all of its property (including bags and containers) and Freight received by the
defaulting Party under this Agreement.

17.3 Termination of this Agreement shall be without prejudice to any other rights of the Party not
in default, including the right to claim damages, and to the rights of the Parties that have accrued
prior to termination.

17.4 In the event the Defaulting Party fails to pay any amount due pursuant to paragraph 17.2, then
the other Party shall have the right to deduct same from any amount due or to become due to the
defaulting Party. 13 - 13 -

18.0 PERFORMANCE PENALTIES

18.1 In the event a Party has, in any twelve (12) month period, more than three (3) Monthly
Performance Failures, then the defaulting Party shall pay a penalty to the Party not in default,
which the Parties acknowledge is a pre-estimation of damages suffered by the non-defaulting Party
due to the current month's Monthly Performance Failure ("Default Month").

For each Default Month, the Party in default shall pay a penalty equal to five (5) times the Party
not in default's corporate average yield during the Default Month for each shipment below the
performance
<!-- page 8 -->
commitment.

For example, if the defaulting Party, in a Default Month, provided services at an eighty five
percent (85%) level and the average yield for the Default Month of the Party not in default is ten
dollars ($10.00) and the total number of shipments handled by the defaulting Party pursuant to this
Agreement is one hundred (100), then the penalty would be equal to 5 x[(Performance Commitment -
Actual Performance Level) x # of shipments] x average yield or 5 x [(90-85) x 100] x 10 = $250.00.
100 19.0 TERMINATION WITHOUT CAUSE

19.1 Either Party may terminate this Agreement, without cause, by giving two (2) years written
notice.

19.2 In the event of a change in control of a Party, the other Party shall have the right, upon
written prior notice, to terminate this Agreement.

20.0 NOTICE

20.1 Any notice or other communication with respect to this Agreement shall be in writing and shall
be effectively given if delivered, or sent (postage or other charges prepaid) by letter, facsimile
or electronic means addressed:

(a) in the case of Purolator to: Purolator Courier Ltd. 5995 Avebury Road, Suite 500 Mississauga,
Ontario L5R 3T8 Attention:

(b) in the case of Dynamex:

Dynamex Inc. 2630 Skymark Avenue Suite 610 Mississauga, Ontario L4W 5A4 14 - 14 -

or to any other address of which the Party in question advises to the other Party in writing. Any
notice that is delivered shall be deemed to have been received on delivery; any notice sent by
facsimile or electronic means shall be deemed to have been received when sent and receipt confirmed
and any notice that is mailed shall be deemed to have been received five (5) business days after
being mailed. In the event of a postal disruption, service to be effective must be delivered or sent
by facsimile.

21.0 REPRESENTATIONS AND WARRANTIES

21.1 Dynamex represents and warrants that:

(a) it has the capacity, power and lawful authority to enter into this Agreement and to fulfill any
and all covenants set forth in this Agreement to be fulfilled by it;

(b) the terms of this Agreement are not in breach of any law, regulation, by-law, agreement, charter
document or covenant by which Dynamex is governed or bound;

(c) all necessary licenses, permits, consents or approvals of, notices to or registrations with or
the taking of any other action in respect of any governmental authority or agency required to be
obtained or accomplished by Dynamex has been obtained or accomplished and are in good standing; and

(d) there are no pending or threatened actions or proceedings to Dynamex is a Party, or which is
before any court or administrative agency, which might materially adversely affect the financial or
other condition, business, assets, liabilities or operations of Dynamex or the ability of Dynamex to
perform its obligations under this Agreement;

20.2 Purolator represents and warrants that:

(a) it has the capacity, power and lawful authority to enter into this Agreement and to fulfill any
and all covenants set forth in this Agreement to be fulfilled by it;

(b) the terms of this Agreement are not in breach of any law, regulation, by-law, agreement, charter
document or covenant by which Purolator is governed or bound;

(c) all necessary licenses, permits, consents or approvals of, notices to or registrations with or
the taking of any other action in respect of any 15 - 15 - governmental authority or agency required
to be obtained or accomplished by Purolator has been obtained or accomplished

and are in good standing; and
<!-- page 9 -->
(d) there are no pending or threatened actions or proceedings to which Purolator is a Party, or
which is before any court or administrative agency, which might materially adversely affect the
financial or other condition, business, assets, liabilities or operations of Purolator or the
ability of Dynamex to perform its obligations under this Agreement;

22.0 FORCE MAJEURE

22.1 No Party hereto shall be in breach of this Agreement by reason of a delay in the performance
of, or failure to perform, any of its obligations hereunder if such a delay or failure is a result
of an event of Force Majeure. 22.2 Each of the Parties hereto shall minimize, to the extent
reasonably practicable, the impact on either Party of any of the events of Force Majeure in its
performance of its obligations under this Agreement.

22.3 The Party invoking an event of Force Majeure shall immediately notify in writing the other
Party of such occurrence, whereupon the other Party shall confirm in writing having received such
notice of the occurrence of an event of Force Majeure.

23.0 ASSIGNMENT

23.1 Neither Party shall sell, assign, subcontract, transfer or dispose of this Agreement or any
part thereof, without the prior written consent of the other Party or otherwise enter into an
agreement with any other Party for Services contemplated herein.

23.2 The terms and conditions of any such subcontract shall respect the terms and conditions of this
Agreement and in all cases shall be of equivalent or higher standards. Neither Party shall reveal
the contents of this Agreement; however a Party may enter into identical agreements with its
connectors, and/or subcontractors, as the case may be, with respect to the terms and conditions of
this Agreement, save and except rates.

24.0 ENTIRE AGREEMENT

24.1 This Agreement and all Schedules attached hereto, embody the entire agreement of the Parties
hereto and no representation, understanding, or agreement, verbal or otherwise exists between the
Parties except as herein expressly provided. 16 - 16 -

24.2 The following order of precedence shall be given in the event of a conflict between the
documents comprising the Agreement:

(a) Agreement (b) Schedules, and (c) the operating plan and any amendments thereto.

25.0 WAIVER

25.1 Failure of any Party to enforce or insist upon compliance with any of the terms or conditions
of this Agreement shall not constitute a general waiver or relinquishment of any such terms or
conditions but the same shall be and remain at all times in full force and effect.

26.0 HEADINGS AND CAPTIONS

26.1 Headings and captions are inserted for each section of this Agreement for convenience only and
in no way define, limit or describe the scope of intent of this Agreement, nor shall they have any
effect in regard to its interpretation.

27.0 AMENDMENTS

27.1 Unless otherwise provided herein, this Agreement shall not in any manner be supplemented,
amended or modified except by written instrument executed on behalf of both Parties by their duly
authorized representatives.

28.0 SINGULAR/PLURAL

28.1 Whenever, in this Agreement, the context requires or permits the singular number shall be read
as if plural were expressed.

29.0 SEPARATE COUNTERPARTS

29.1 This Agreement may be executed in several counterparts, each of which, when so executed, shall
be deemed to be an original of this Agreement and such counterparts together shall constitute but
one and the same instrument.

30.0 TIME

30.1 Time shall, in all respects, be of the essence in each and every of the terms, covenants,
obligations and conditions in this Agreement.

31.0 SEVERABILITY
<!-- page 10 -->
31.1 In the event that any provision of this Agreement is invalid, unenforceable or illegal, then
such provision shall be severed from this Agreement and this Agreement shall be read as if such
provision were not part of this Agreement and provided such severance does not 17 - 17 -

substantially frustrate the intention of this Agreement, such invalidity or unenforceability or
illegality shall not affect any other provision of this Agreement.

32.0 BINDING EFFECT

32.1 This Agreement shall enure to the benefit of and be binding upon the Parties hereto, successors
and assigns.

33.0 RELATIONSHIP OF THE PARTIES

33.1 The Parties recognize that they operate as an independent business and declare that nothing in
this Agreement shall be construed as creating a relationship of employment, joint venture,
partnership or agency between Purolator and Dynamex, and no act or omission of either Party shall
bind or obligate the other except as expressly set forth in this Agreement. The Parties agree that
no representation will be made or acts undertaken by either of them which could establish or imply
any apparent relationship of agency, partnership, joint venture or employment and neither Party
shall be bound in any manner whatsoever by any agreements, warranties, representatives or actions of
the other Party to such effect.

34.0 CONFIDENTIAL INFORMATION

34.1 The Parties recognize that this Agreement contains information which is commercially sensitive
and agree to keep the entire contents of this Agreement confidential and not to make any disclosures
to any third Parties (other than their professional and financial advisers who agree to be bound by
this provision) unless required by law to do so or unless prior written consent is obtained from the
other Party. 35.0 TRADE-MARKS

35.1 Each Party's trade-marks, distinctive colours and designs used in connection with the Services
shall remain at all times during the term of this Agreement and on the expiration or termination
thereof, the exclusive property of each Party and any benefit associated with such use shall accrue
solely to that Party. Each Party shall use the other Party's trade-mark, distinctive colours and
designs only with the prior written consent of the other Party and only in connection with the
services provided hereunder.

36.0 LAW OF THE AGREEMENT

36.1 This Agreement shall be governed and construed in accordance with the laws of the Province of
Ontario. All legal proceedings arising out of this Agreement shall be brought in a court of
competent jurisdiction in the Province of Ontario, and each of the Parties hereby attorn to the
jurisdiction of such court with respect to such proceedings. 18 - 18 -

37.0 REMEDIES

37.1 All remedies herein are cumulative and are in addition to, not in lieu of, any remedies
provided at law or in equity.

38.0 PUBLIC ANNOUNCEMENT

38.1 The content and timing of any public announcement, press release or publication of any kind
regarding this Agreement shall be mutually agreed to by the Parties, except disclosures required by
applicable law, in which case advance notice will be given to the other Party.

39.0 ARBITRATION

39.1 If at any time a dispute arises between the Parties hereto which cannot be resolved by
agreement among the Parties, or if the Parties are unable to agree on any matter that requires their
mutual agreement hereunder, the dispute or matter shall be submitted to arbitration as provided in
this Article by any Party hereto giving written notice to the other Party (the "Notice to
Arbitrate"). The Notice to Arbitrate shall contain a concise description of the matter submitted for
arbitration.

39.2 The Parties hereto shall within ten (10) business days of receipt of the Notice to Arbitrate
jointly appoint a single arbitrator. If the Parties fail to appoint an arbitrator who shall jointly
select a third arbitrator within ten (10) days, failing which same shall be designated by the
President of the Arbitrators' Institute of Canada Inc. upon the request of either Party.

39.3 The arbitration shall take place in the Municipality of Metropolitan Toronto and shall be
governed by the provisions of the Arbitration Act.

39.4 The determination of the arbitrator shall be in writing and shall be final and binding upon the
Parties hereto.

39.5 The cost of the arbitration shall be borne by the Parties hereto
<!-- page 11 -->
equally.

39.6 Submission to the arbitration under this Article shall be a condition precedent to the bringing
of any action with respect to this Agreement.

40.1 LANGUAGE

40.1 The Parties have expressly requested that this Agreement be written in the English language.

Les Parties ont specifiquement requis que la presente entente soit redigee en langue anglaise. 19 -
19 -

41.0 REPUTATION

41.1 In the event a Party has committed or shall commit any material act, or has or does become
involved in any material situation or occurrence bringing either Party into public disrepute,
contempt, scandal or ridicule, or shocking, insulting or offending potential customers of either
Party or any racial, religious or ethnic, age or gender group, or reflecting unfavourably on either
Party's reputation or their products or services, then the other Party may terminate this Agreement
upon giving such notice as it deems appropriate. The non-offending Party's decision on such matter
arising hereunder shall be based on its judgment as to whether or not the act or involvement of the
offending Party has materially harmed or may be materially harmful to the Parties, their products,
services or trademarks, in any respect, acting bona fidely.

42.0 NON-COMPETITION

32.1 In the event this Agreement is terminated pursuant to the provisions of paragraph 17, then the
Party in default shall not enter into an agreement with any other Party to provide services similar
to those provided herein or to provide its services similar to those provided for herein without an
agreement, for a period of six (6) months from the effective date of termination.

42.2 In the event this Agreement is terminated pursuant to the provisions of paragraph 19.2, then
the Party whose control has changed shall not enter into an agreement with any other Party to
provide services similar to those provided herein or to provide its services similar to those
provided for herein without an agreement, for a period of twelve (12) months from the effective date
of termination.

The Parties have executed this Agreement as of the day, month and year first above written by their
proper officers duly authorized on that behalf.

PARCELWAY COURIER SYSTEMS CANADA LTD.

Per: (ILLEGIBLE) 11/20/95 c/s -----------------------------

Per: c/s -----------------------------

PUROLATOR COURIER LTD.

Per: (ILLEGIBLE) c/s -----------------------------

Per: (ILLEGIBLE) --------------------------------
