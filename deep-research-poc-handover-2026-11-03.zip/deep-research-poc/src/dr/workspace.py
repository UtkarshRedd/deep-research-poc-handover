"""Per-query materialized working set.

Given DocRecords (already filtered upstream), write each document to
``<root>/docs/<doc_id>.md`` and a ``manifest.json``. Build a line->page map from the
``<!-- page N -->`` markers so every tool can cite pages. Nothing here calls a model.

Invariants enforced here:
  * all tool file access goes through ``path_of`` which rejects anything outside ``docs/``
  * line numbers are 1-based and stable for the life of the workspace
"""
from __future__ import annotations

import bisect
import json
import re
import time
from pathlib import Path

from .config import DEFAULT, Config
from .models import DocRecord, ManifestEntry

_HEADING_RE = re.compile(r"^(#{1,4})\s+(.+?)\s*#*\s*$")


class Workspace:
    def __init__(self, root: Path, config: Config = DEFAULT):
        self.root = Path(root).resolve()
        self.docs_dir = self.root / "docs"
        self.cfg = config
        self._page_re = re.compile(config.PAGE_MARKER_RE)
        self.manifest: dict[str, ManifestEntry] = {}
        # doc_id -> (sorted marker line numbers, page numbers at those lines)
        self._page_index: dict[str, tuple[list[int], list[int]]] = {}
        self._line_counts: dict[str, int] = {}
        self._lines_cache: dict[str, list[str]] = {}

    # ------------------------------------------------------------------ build

    @classmethod
    def materialize(cls, docs: list[DocRecord], root: Path, config: Config = DEFAULT) -> "Workspace":
        t0 = time.perf_counter()
        ws = cls(root, config)
        ws.docs_dir.mkdir(parents=True, exist_ok=True)
        (ws.root / "tool_out").mkdir(exist_ok=True)
        for d in docs:
            path = ws.docs_dir / f"{d.doc_id}.md"
            path.write_text(d.text, encoding="utf-8")
            lines = d.text.split("\n")
            ws._lines_cache[d.doc_id] = lines
            ws._line_counts[d.doc_id] = len(lines)
            ws._index_pages(d.doc_id, lines)
            ws.manifest[d.doc_id] = ws._manifest_entry(d, lines)
        (ws.root / "manifest.json").write_text(
            json.dumps({k: v.model_dump() for k, v in ws.manifest.items()}, indent=1),
            encoding="utf-8",
        )
        ws.stats = {"n_docs": len(docs), "materialize_ms": int((time.perf_counter() - t0) * 1000)}
        return ws

    @classmethod
    def load(cls, root: Path, config: Config = DEFAULT) -> "Workspace":
        ws = cls(root, config)
        raw = json.loads((ws.root / "manifest.json").read_text(encoding="utf-8"))
        ws.manifest = {k: ManifestEntry(**v) for k, v in raw.items()}
        for doc_id in ws.manifest:
            lines = ws.lines(doc_id)
            ws._line_counts[doc_id] = len(lines)
            ws._index_pages(doc_id, lines)
        return ws

    def _index_pages(self, doc_id: str, lines: list[str]) -> None:
        marker_lines: list[int] = []
        pages: list[int] = []
        for i, ln in enumerate(lines, start=1):
            m = self._page_re.match(ln)
            if m:
                marker_lines.append(i)
                pages.append(int(m.group(1)))
        self._page_index[doc_id] = (marker_lines, pages)

    def _manifest_entry(self, d: DocRecord, lines: list[str]) -> ManifestEntry:
        headings = []
        for ln in lines:
            m = _HEADING_RE.match(ln)
            if m and len(m.group(1)) <= 2:
                headings.append(m.group(2))
            if len(headings) >= 12:
                break
        _, pages = self._page_index[d.doc_id]
        md = d.metadata
        parties = [p.strip() for p in md.get("parties", "").split(";") if p.strip()]
        extra = {k: v for k, v in md.items() if k not in {"title", "doc_type", "date", "parties"}}
        return ManifestEntry(
            doc_id=d.doc_id,
            title=d.title or md.get("title", d.doc_id),
            doc_type=md.get("doc_type"),
            date=md.get("date"),
            parties=parties,
            n_pages=max(pages) if pages else 0,
            n_lines=len(lines),
            headings=headings,
            extra=extra,
        )

    # ------------------------------------------------------------------ access

    def doc_ids(self) -> list[str]:
        return list(self.manifest.keys())

    def path_of(self, doc_id: str) -> Path:
        """Resolve a doc path, rejecting anything outside docs/ (no '../', no absolute paths)."""
        if not doc_id or "/" in doc_id or "\\" in doc_id or doc_id.startswith("."):
            raise PermissionError(f"invalid doc_id: {doc_id!r}")
        p = (self.docs_dir / f"{doc_id}.md").resolve()
        if self.docs_dir not in p.parents:
            raise PermissionError(f"path escapes workspace: {doc_id!r}")
        if doc_id not in self.manifest:
            raise KeyError(f"unknown doc_id: {doc_id!r}")
        return p

    def lines(self, doc_id: str) -> list[str]:
        if doc_id not in self._lines_cache:
            self._lines_cache[doc_id] = self.path_of(doc_id).read_text(encoding="utf-8").split("\n")
        return self._lines_cache[doc_id]

    def line_count(self, doc_id: str) -> int:
        if doc_id not in self._line_counts:
            self._line_counts[doc_id] = len(self.lines(doc_id))
        return self._line_counts[doc_id]

    def page_of(self, doc_id: str, line: int) -> int | None:
        """Page containing `line` (1-based). None if the doc has no markers before that line."""
        marker_lines, pages = self._page_index.get(doc_id, ([], []))
        if not marker_lines:
            return None
        idx = bisect.bisect_right(marker_lines, line) - 1
        return pages[idx] if idx >= 0 else None

    def page_text(self, doc_id: str, page: int) -> str:
        """All lines belonging to `page` (used by tier-1 verification)."""
        marker_lines, pages = self._page_index[doc_id]
        lines = self.lines(doc_id)
        if page not in pages:
            return ""
        i = pages.index(page)
        start = marker_lines[i]  # marker line itself (1-based) -> content starts after it
        end = marker_lines[i + 1] - 1 if i + 1 < len(marker_lines) else len(lines)
        return "\n".join(lines[start:end])

    def offload_dir(self) -> Path:
        return self.root / "tool_out"
