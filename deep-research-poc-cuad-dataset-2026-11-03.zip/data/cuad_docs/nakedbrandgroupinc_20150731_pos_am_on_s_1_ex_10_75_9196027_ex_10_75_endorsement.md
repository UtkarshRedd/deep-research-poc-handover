<!-- page 1 -->
# COLLABORATION & ENDORSEMENT AGREEMENT
| Field | Value |
|---|---|
| Document Type | Endorsement Agreement |
| Agreement Date | 2015-06-15 |
| Parties | The Naked Brands Group, Inc ("Naked"); Wade Enterprises, LLC ("Wade Enterprises"); f/s/o Dwayne Wade ("Athlete" and together with Wade Enterprises (collectively, "Wade"); Wade Enterprises, Athlete and togetherwith Naked, (“Party” and collectively, the “Parties”) |
| Source | CUAD v1 / NakedBrandGroupInc_20150731_POS AM (on S-1)_EX-10.75_9196027_EX-10.75_Endorsement Agreement |

Confidential Information has been omitted in places marked "[***]" and has been filed separately
with the Securities and Exchange Commission. Confidential Treatment has been requested with respect
to this omitted information pursuant to an application for confidential treatment filed with the
Commission under Rule 406 under the Securities Act of 1934, as amended.

Exhibit 10.75

COLLABORATION & ENDORSEMENT AGREEMENT

THIS COLLABORATION & ENDORSEMENT AGREEMENT (the "Agreement") is dated as of this 15th day of June,
2015 ("Effective Date"), between The Naked Brands Group, Inc., a Delaware corporation ("Naked"), and
Wade Enterprises, LLC ("Wade Enterprises"), an Alaska limited liability company f/s/o Dwyane Wade
("Athlete" and together with Wade Enterprises, collectively "Wade"). Wade Enterprises, Athlete and
together with Naked, are each referred to herein as a "Party" and collectively, the "Parties".

AGREEMENT

1. Engagement. Naked hereby engages Wade for collaboration in business development for, and his
endorsement as set forth herein of, the following items, which shall be known herein as "Innerwear":
Briefs, trunks, boxer briefs and boxers, non-athletic undershirts (i.e., t-shirts intended to be
worn as innerwear and not intended specifically for athletic purposes), non-athletic lounge apparel
(bottoms and tops), sleepwear (including pajama bottoms and tops), and robes (as may be expanded to
include other mutually agreed upon innerwear and lounge apparel) which may now or hereafter during
the Term be manufactured, distributed, marketed and/or sold by Naked (collectively, the "Naked
Products"), and Wade hereby accepts such engagement. The Parties agree that the territory of such
engagement shall be worldwide (the "Territory").

2. Term of Agreement. The initial term of this Agreement shall be for a period of four (4) years,
commencing on the Effective Date, which term may be extended for up to three (3) years by written
agreement of both Parties prior to the expiration date of the initial term or any extension thereof
(collectively, the "Term"). Each twelve-month period beginning on the Effective Date shall be known
as a "Contract Year." In the event that either Wade or Naked wishes to extend the Term of the
Agreement as contemplated above, it shall provide the other Party with written notice at least
ninety (90) days prior to the expiration of the Term. The other Party will then have a period of
fourteen (14) days from the date of the notice to indicate whether it also desires to extend the
Term, on the terms and conditions set forth herein and if no such indication is made, the other
Party will be deemed to have declined the offer to extend. Notwithstanding the foregoing, Wade
agrees that for a period of ninety (90) days prior to the expiration of the Term (unless the
Agreement is terminated by Wade as permitted hereunder), Naked shall have the exclusive right to
negotiate for continued endorsement by Athlete of the Naked Products. For a period of six (6) months
at the end of the Term (the "Sell-off Period"); provided that the Agreement was not terminated by
Wade as permitted herein, Naked will have the right to continue to sell the Wade Products (defined
below) for which orders have already been placed at the end of the Term on the terms and conditions
herein.

3. Use of Wade Image.

During the Term and subject to the limitations set forth in this Agreement, Naked shall have an
exclusive right and license in the Territory to use Athlete's name, nickname, initials, autograph,
image, likeness, photographs, biographical details, facsimile signature, voice, videos, electronic
media depictions, any words, symbols or other depictions, as well as any other identifying
attributes that would identify Athlete to the public, including any trade mark(s), copyrights which
Wade has, as set forth on Schedule A attached hereto, and all multimedia assets that Wade owns or
has right to use (collectively, the "Wade Image") solely for the advertising, endorsement,
promotion, or sale of the Naked Products (including the Wade Products) in the Territory as follows:

Source: NAKED BRAND GROUP INC., POS AM (on S-1), 7/31/2015

Confidential Information has been omitted in places marked "[***]" and has been filed separately
with the Securities and Exchange Commission. Confidential Treatment has been requested with respect
to this omitted information pursuant to an application for confidential treatment filed with the
Commission under Rule 406 under the Securities Act of 1934, as amended.
<!-- page 2 -->
(1) On Naked's website(s) ("Website");

(2) In social media channels, including, but not limited to Facebook, Instagram, Twitter, YouTube,
Google+, Tumblr and other mutually agreeable channels, with reasonable frequency, to promote Naked
Products and Wade Products;

(3) In marketing and media opportunities in connection with the Wade Services (as defined below);
and

(4) For use on the packaging of the Naked Products and Wade Products and on Wade Products
themselves.

All uses of Wade Image in connection with this Agreement shall be subject to the prior written
approval of Wade, which Wade shall not unreasonably withhold. Naked agrees to submit to Wade or its
authorized agent a copy of all new promotional and/or advertising material using Wade Image at least
ten (10) days prior to the release to the general public. Wade and its authorized agent agree that
they shall not unreasonably withhold such approval. In the absence of disapproval within three (3)
business days of Wade's or authorized agent's receipt of a request for approval, said advertising or
promotional material shall be deemed approved. Any such usage featuring Athlete shall be and remain
the property of Naked except as otherwise set forth herein; however, Naked shall have the right to
such use only during the Term. Wade may use said materials in whole or in part for Wade's personal
portfolio, website or otherwise. Such usage may not be sold or transferred. For the avoidance of
doubt, that certain logo designed by Athlete prior to the date hereof (the "Logo") shall remain the
sole property of Wade and Naked shall have license during the Term to use the Logo for the
advertising, endorsement, promotion, or sale of the Naked Products (including the Wade Products) in
the Territory in accordance with the terms and conditions of the Agreement. During the Sell-off
Period, Naked shall have the license to use the Logo solely on packaging and presentation of Wade
Products already offered for sale at retail outlets or on-line in accordance with the terms and
conditions of the Agreement.

Wade will allow Naked to use any quotes that are attributed to Wade to promote the Naked Products
and Wade Products in any advertising campaign. Wade will allow Naked to use any such attributed
quotes that Naked requires to promote the Naked Products and Wade Products, subject to Wade's right
to approve such quotes in writing, which approval shall not be unreasonably withheld.

The Parties acknowledge and agree that Athlete's accomplishments and recognition as an outstanding
basketball player, individual and fashion icon, as well as his character, fame, likeness, image and
reputation are the essence of this Agreement.

Wade hereby warrants that he is not a party to any agreement, contract or understanding which would
prevent, limit or hider his performance of any of the obligations under this Agreement, provided
that Naked acknowledges that it is aware of Athlete's obligations under his existing endorsement
agreement with Li Ning for athletic shoes and athletic apparel and nothing herein shall obligate
Athlete to endorse any athletic apparel other than Li Ning's.

2

Source: NAKED BRAND GROUP INC., POS AM (on S-1), 7/31/2015

Confidential Information has been omitted in places marked "[***]" and has been filed separately
with the Securities and Exchange Commission. Confidential Treatment has been requested with respect
to this omitted information pursuant to an application for confidential treatment filed with the
Commission under Rule 406 under the Securities Act of 1934, as amended.
<!-- page 3 -->
4. Exclusivity. Wade agrees that during the Term of this Agreement, he will not represent or perform
as a representative, spokesperson or provide Wade Services for, nor furnish services or materials,
or allow the use of the Wade Image to be used for the advertising, endorsement, promotion, or sale
of Innerwear in the Territory. Furthermore, Wade will not engage in any business or other
transaction or have any financial or personal interest in any entity whose primary or core business
is selling or manufacturing Innerwear during the Term. Endorsement of any Innerwear other than the
Naked Products or Wade Products without the express written consent of Naked will constitute a
material breach of this Agreement.

5. Wade Services. During the Term and subject to the limitations set forth in this Agreement, Wade
agrees to provide Naked with the following services (collectively, the "Wade Services"):

A. During the first Contract Year, Wade will be available for (i) one production day for the purpose
of creating marketing assets for Naked Products for unlimited use in advertisements and the media
and (ii) one production day for creating marketing assets for Wade Products and Naked Products for
unlimited use in advertisements and the media, each as permitted herein. Wade shall be available to
render services at such production day for a maximum of three (3) consecutive hours, not including
scheduled breaks, during each such production day period; provided that, in the event an additional
production day is reasonably required for the creation of marketing assets related to the Wade
Product packaging, Athlete will be available to render services for up to an additional three (3)
hours in either the first Contract Year or the second Contract Year but not both. The scheduling and
content of said production days shall be mutually determined by Wade and Naked, subject to Wade's
professional availability;

B. Beginning in the second Contract Year, Wade will be available for a maximum of one (1) production
day for creating marketing assets for Wade Products and Naked Products for unlimited use in
advertisements and the media, for a maximum of three (3) consecutive hours, not including scheduled
breaks, during such production day period. The scheduling and content of said production days shall
be mutually determined by Wade and Naked, subject to Wade's professional availability;

C. During each Contract Year, Wade will be available for two (2) personal appearances (each, a
"Personal Appearance") on behalf of Naked and the Naked Products and Wade Products in the media,
including publicity shoots, interviews, print, television, radio and social media channels, each
appearance for a maximum of sixty (60) consecutive minutes to be scheduled at a time mutually
agreeable to Naked and Wade;

Wade has rights to websites or other social media channels promoting himself or any other
promotional activity that is independent of this Agreement ("Independent Promotions"), including
Wade's Facebook, Instagram, Twitter and Google+ channels and Wade's YouTube channel. Wade agrees, to
generously and positively promote Naked Products and Wade Products in any such Independent
Promotions on a mutually agreed upon basis with reasonable frequency and in a manner consistent with
drawing attention to the Wade/Naked relationship and promoting the Naked Products and Wade Products.
Naked, in its sole and absolute discretion, may preview all references and other such materials
referring to Naked in the Independent Promotions prior to the public dissemination of such
Independent Promotions. Wade agrees to immediately remove all such materials in his Independent
Promotions that Naked, in its sole and absolute discretion requests be removed. Naked has the right
to request such removals at any time, even if Naked previously approved the Independent Promotions,
and Naked agrees that all social media promotions it requests of Athlete shall comply with all
applicable rules and regulations. Naked may also provide material regarding the Naked Products and
Wade Products to Wade, and Wade agrees to include such materials in his Independent Promotions; and

3

Source: NAKED BRAND GROUP INC., POS AM (on S-1), 7/31/2015

Confidential Information has been omitted in places marked "[***]" and has been filed separately
with the Securities and Exchange Commission. Confidential Treatment has been requested with respect
to this omitted information pursuant to an application for confidential treatment filed with the
Commission under Rule 406 under the Securities Act of 1934, as amended.
<!-- page 4 -->
E. Wade is currently engaged in partnerships whereby its partners are selling and distributing other
Athlete endorsed products. Wade will use reasonable efforts to facilitate an introduction to Naked
to existing sales and distributions channels and accounts.

F. Naked may reasonably request an additional production session(s), or a media tour or personal
appearance(s), subject to mutual agreement by the Parties.

At all Personal Appearances, Wade will be available to sign a reasonable number of photographs,
autographs, and any other items requested by and provided by Naked at its sole cost and expense,
which Naked will have the right to distribute as giveaways but never for sale. If requested, Wade
will pass out a reasonable number of samples of the Wade Product. Wade will also permit himself to
be reasonably photographed at the Personal Appearances with customers and fans.

6. Commercial Materials. The results of the production days listed in subsections A and B in Section
5 may be used solely for the promotion of the Naked Products (including the Wade Products) and are
hereinafter referred to individually and collectively as the "Commercial Materials." Wade shall have
the right of prior written approval with respect to his photographs, likeness and statements. During
the Term, Naked shall have the right in the Territory to the unlimited broadcast use and re-use of
the Commercial Materials in the Territory. During the Term, Naked shall have the right in the
Territory to use the Wade Image in the Commercial Materials, for publication and display, as Naked
shall in its sole discretion determine, in print magazines, including but not limited to,
point-of-sale material, product packaging, Naked's Annual Report, other shareholder communications,
internal sales and marketing pieces, as well as the right to use the same at meetings held or
attended by Naked or for trade purposes. Naked shall have the right at any time during the term of
this Agreement to make any revision or versions of all or any part of the Commercial Materials to
conform to the requirements of individual markets as Naked may desire, subject to Wade's reasonable
approval as aforesaid. Naked may also propose to use the Commercial Materials as part of cooperative
advertising and retail tie in promotions subject to Wade's prior written approval which shall not be
unreasonably withheld, provided that withholding approval because a potential tie in conflicts with
one of Athlete's existing sponsors shall not be deemed unreasonable. Notwithstanding the foregoing,
in no case shall the Commercial Materials feature any commercial tie in or other use that could be
perceived as an endorsement by Athlete of any products or services other than the Naked Products.
Naked shall comply with all applicable rules and regulations (including the NBA's) in its use of the
Commercial Materials hereunder.

7. Design of Wade Products.

Naked and Wade (either Athlete or a team and/or agent and/or designer designated by Athlete,
referred to as the "Wade Team") agree to collaborate on the design and manufacture of a new line of
Innerwear under the brand "Wade By Naked" or such other brand name as the Parties agree
(collectively, the "Wade Products"). Athlete will have the title of "Creative Director" for the Wade
Products, which title shall be featured on the Commercial Materials. During the Term and subject to
the limitations set forth in this Agreement, the Wade Team and Naked agree that the process for
approving designs for Wade Products will be as follows:

4

Source: NAKED BRAND GROUP INC., POS AM (on S-1), 7/31/2015

Confidential Information has been omitted in places marked "[***]" and has been filed separately
with the Securities and Exchange Commission. Confidential Treatment has been requested with respect
to this omitted information pursuant to an application for confidential treatment filed with the
Commission under Rule 406 under the Securities Act of 1934, as amended.
<!-- page 5 -->
(1) Naked will develop detailed designs for each Wade Product, which shall include rough drawings,
to be provided to Wade for review and comment;

(2) The Wade Team will provide Naked with comments on such designs within ten (10) days after they
are provided to the Wade Team;

(3) Upon receipt of the Wade Team's comments, Naked will review such comments and work diligently to
incorporate them into the design within commercial reason and thereafter, develop and create a
prototype for such Wade Product for the Wade Team's approval;

(4) Within ten (10) days after the Wade Team's receipt of the prototype either in hand or via a
photograph by email, the Wade Team shall review the prototype and provide any additional comments;
and

(5) Upon the Wade Team's written approval of a prototype, such Wade Product will be considered
approved for production (the "Production Approval").

(6) In addition to the foregoing Wade Products, Naked shall have the right to produce and
distribute, on a non-exclusive basis, printed or branded tee-shirts subject to Wade's existing
endorsement agreements.

The Wade Team and Naked will collaborate to establish a mutually acceptable marketing campaign for
Wade Products, and will schedule regular phone calls, video conferences, and/or other meetings to
timely complete development of Wade Products.

8. Royalties. As consideration for Wade's services under this Agreement, Naked will pay Wade
royalties as follows:

A. Royalties. Naked will report, and Wade will be paid, royalty payments at [***]

5

Source: NAKED BRAND GROUP INC., POS AM (on S-1), 7/31/2015

Confidential Information has been omitted in places marked "[***]" and has been filed separately
with the Securities and Exchange Commission. Confidential Treatment has been requested with respect
to this omitted information pursuant to an application for confidential treatment filed with the
Commission under Rule 406 under the Securities Act of 1934, as amended.
<!-- page 6 -->
B. Payment Terms. Wade Product Royalties described above in Section 8A will be paid on a quarterly
basis on the first day of each of the months of July, October, January, and April and shall be
accompanied by backup documentation reasonably satisfactory to Wade.

C. [***]

D. Withholding Taxes. Wade will be solely responsible for withholding and paying any and all
federal, state and local taxes, including but not limited to payroll, unemployment, social security
and income taxes and any other payments which may be owed by Wade as a result of or in connection
with payments made by Naked for Wade Services rendered under this Agreement. Wade acknowledges that
he is not qualified for and will not receive any Naked employment benefits or other incidents of
employment as a result of the Agreement.

E. Equity Ownership. Wade is hereby granted a warrant (the "Grant Warrant") exercisable for a period
of seven (7) years from the date of issuance for the number of shares of Common Stock equal to [***]
shares of Common Stock (the "Wade Grant"), subject to the following terms:

(1) Exercise Price. The Grant Warrant will have an exercise price equal to the then-fair market
value per share of Common Stock as quoted on the OTCQB as of the Effective Date (the "FMV Exercise
Price"). The form of the Grant Warrant shall be agreed to by the Parties.

(2) Vesting Schedule. The Grant Warrant will become exercisable for: (a) fifty percent (50%) of the
Wade Grant on the one year anniversary of the Effective Date (the "First Installment"); (b)
twenty-five percent (25%) of the Wade Grant on the second anniversary of the Effective Date (the
"Second Installment"); and (c) the remaining twenty-five percent (25%) of the Wade Grant will vest
on the third anniversary of the Effective Date (the "Third Installment" and together with the First
Installment and the Second Installment, the "Installments" and each an "Installment"); provided
however, that in the event of a change of control of Naked, the entire unvested portion of the Grant
Warrant will immediately vest. For purposes hereof, a "change of control" shall mean the sale of at
least fifty percent (50%) of the assets of Naked, a merger or consolidation of Naked with, by or
into another entity, or a change in the ownership of more than fifty percent (50%) of the voting
capital stock of Naked in one or more related transactions.

6

Source: NAKED BRAND GROUP INC., POS AM (on S-1), 7/31/2015

Confidential Information has been omitted in places marked "[***]" and has been filed separately
with the Securities and Exchange Commission. Confidential Treatment has been requested with respect
to this omitted information pursuant to an application for confidential treatment filed with the
Commission under Rule 406 under the Securities Act of 1934, as amended.
<!-- page 7 -->
(3) Exercise Upon Termination of the Agreement. In the event that the Agreement is terminated in
accordance with Section 12A, than the [***] term of the Grant Warrant [***] shall expire ninety (90)
days thereafter. [***]

(6) Designee of Wade Grant. Pursuant to the request of Wade, Naked shall issue [***] to Wade's
exclusive representative, CAA Sports LLC. This grant shall be issued pursuant to the same terms and
conditions as the Wade Grant, with the exception of the terms of [***].

(7) [***]

7

Source: NAKED BRAND GROUP INC., POS AM (on S-1), 7/31/2015

Confidential Information has been omitted in places marked "[***]" and has been filed separately
with the Securities and Exchange Commission. Confidential Treatment has been requested with respect
to this omitted information pursuant to an application for confidential treatment filed with the
Commission under Rule 406 under the Securities Act of 1934, as amended.
<!-- page 8 -->
(8) Grant Documents. All warrants referenced herein shall be issued pursuant to separate, mutually
negotiated grant documents, which shall contain all the terms referenced herein and shall be
negotiated and executed promptly after the execution of the Agreement.

9. Board Membership.

A. Advisory Board. Upon entering into this Agreement, Athlete will join the Advisory Board of Naked
("Advisory Board"). As a member of the Advisory Board, Athlete agrees to the following:

(1) Athlete will participate in at least one (1) scheduled Advisory Board meeting by phone or
in-person, provided that such meeting is held in Miami on a date acceptable to Wade.

(2) Athlete will provide Naked with access to Wade's contacts and Wade's expertise and breadth of
experience as it pertains to the business of Naked;

(3) Wade will provide any reasonable additional assistance as may be mutually agreed upon by Naked
and Wade from time to time; and

(4) Wade grants Naked the right to publicly identify Wade as a member of the Advisory Board,
Creative Director, Stockholder, and Partner of Naked, and in the event that Wade joins the Board, as
Director, and may include his name and biography in materials published by Naked, including any
prospectus or offering materials or to publish any other information regarding Wade in any documents
required to be filed pursuant to applicable laws and regulations.

B. Board of Directors. Further, Athlete will have the option in his sole discretion of becoming a
member of the Board of Directors of Naked (the "Board") (for a period of eighteen (18) months
commencing on the Effective Date and provided that the Agreement has not been terminated). If
Athlete elects to become a member of the Board, he must satisfy the following requirements on an
annual basis:

(1) Wade will participate in at least four (4) scheduled board meetings, two (2) of which Wade must
attend in-person, provided that at least one meeting is held in Miami, FL or, if no such meeting is
held in Miami, FL then one (1) meeting if all meetings are held in New York, NY or another location.
Subject to legal compliance requirements, Wade may designate an individual acceptable to Naked serve
as his representative to the meetings of the Board;

(2) Wade will attend, subject to his availability in his sole discretion, fundraising events and
meetings with potential investors, placement agents and representatives of the same at the request
of Naked to be scheduled at the convenience of each of Naked and Wade;

If, while serving on the Board Wade does not satisfy any of the above-listed requirements on more
than one (1) occasion, the other members of the Board may remove Wade from the Board upon written
notice to Wade.

8

Source: NAKED BRAND GROUP INC., POS AM (on S-1), 7/31/2015

Confidential Information has been omitted in places marked "[***]" and has been filed separately
with the Securities and Exchange Commission. Confidential Treatment has been requested with respect
to this omitted information pursuant to an application for confidential treatment filed with the
Commission under Rule 406 under the Securities Act of 1934, as amended.
<!-- page 9 -->
10. Wade Obligations. During the Term of this Agreement, Athlete agrees to comply with the following
obligations:

A. Comply with all rules and regulations of the National Basketball Association and its governing
bodies rules and regulations;

B. Not do anything which damages Wade's name, reputation, or image in the eyes of a reasonable
observer;

C. Exercise reasonable constraints to avoid taking any actions which damages Naked, its name,
reputation, image, the Naked Products and Wade Products;

D. When promoting the Naked Products or Wade Products, mention when appropriate the name of Naked
and/or the Naked Products and Wade Products in interviews with the press, social media channels and
broadcast media;

E. Wear the Naked Products and/or Wade Products when appropriate and refrain from wearing any other
Innerwear products that would be visible to the public.

11. Non-compete; Confidentiality. Wade represents and warrants that during the Term and in the
Territory, neither Wade nor any of his agents, representatives or employees will solicit, initiate,
or encourage any proposal for an endorsement by Wade of any Innerwear to commence during the Term,
or participate in any discussions or negotiations for the same. Wade will execute a non-disclosure
and confidentiality agreement in a form mutually acceptable to each of Wade and Naked.

12. Termination.

A. Naked shall have the right to terminate this Agreement upon ten (10) days prior written notice to
Wade in the event Wade fails to perform the Wade Services or breaches any other covenant or
agreement set forth herein (including the essence of this Agreement), and fails to cure same (if
curable) within seven (7) days of receipt of written notice. Such termination shall relieve Naked of
its obligation to provide any further consideration pursuant to this Agreement provided that Wade
shall retain all warrants he has received hereunder that have vested as of the date of such
termination. In the event of such termination as a result of a material breach of this Agreement by
Wade (i) Wade's contractual liabilities and obligations until the date of termination still exist
notwithstanding such termination, (ii) Naked shall be under no obligation to sell any Wade Products
but shall nevertheless owe the Royalty on any Wade Products sold; and (iii) notwithstanding anything
to the contrary herein, Wade shall forfeit all warrants he has received hereunder. Naked shall not
have waived any of its rights at law or in equity by exercising any provision of this section.

B. Wade shall have the right to terminate this Agreement upon ten (10) days prior written notice to
Naked in the event of the occurrence of any of the following: (i) Naked is adjudicated as insolvent
or declares bankruptcy; or (ii) Naked fails to provide consideration due pursuant to this Agreement,
within ten (10) days following the date such consideration is due hereunder (or, if Wade elects to
receive stock in lieu of the cash consideration, if Naked fails to instruct its transfer agent to
issue the appropriate amount of Common Stock to Wade within ten (10) days following the date such
consideration is due in the event such consideration is payable in Common Stock); provided that
Naked is notified in writing of such non-payment by Wade and such payment by Naked is not made
within three (3) days following such notification; or (iii) Naked breaches any covenant or agreement
set forth herein and fails to cure same (if curable) within seven (7) days of receipt of written
notice. Furthermore, Naked agrees that such termination shall not relieve it of its obligation to
provide consideration as contemplated hereunder. Wade shall not have waived any of his rights at law
or in equity by exercising any provision of this section.

9

Source: NAKED BRAND GROUP INC., POS AM (on S-1), 7/31/2015

Confidential Information has been omitted in places marked "[***]" and has been filed separately
with the Securities and Exchange Commission. Confidential Treatment has been requested with respect
to this omitted information pursuant to an application for confidential treatment filed with the
Commission under Rule 406 under the Securities Act of 1934, as amended.
<!-- page 10 -->
C. The Agreement shall be deemed terminated if neither Naked nor Wade elect to extend the Agreement
as set forth in Section 2 hereof.

D. Naked's rights to the use of Wade Image shall end immediately should this Agreement be terminated
pursuant to Section 12(A) or Section 12(B) above.

13. Notices. All notices provided for herein shall be given in writing by hand delivery, courier
service, or by certified mail return receipt requested to the addresses of the Parties set forth as
follows (unless change of address by notice to the other Party is given as provided in this Section
13):

If to Wade: If to Naked: CAA Sports LLC Naked Brand Group, Inc. 405 Lexington Avenue, 19th Floor
10th Floor - 95 Madison Avenue New York, NY 10174 New York, NY 10016 Attn: Lloyd Frischer Attn: Joel
Primus With a copy to: With a copy to: Andrew B. Latack, Esq. Duane Morris LLP at the same address
1540 Broadway, 14th Floor New York, NY 10036 Attn: Nanette C. Heide, Esq.

14. Intellectual Property.

All rights to the use of the names, trademarks, service marks, symbols, logos, domain names, trade
secrets, confidential know-how, patents, copyrights, any pending applications with respect to any of
the foregoing, and any other intellectual property and related proprietary rights, interests and
protections ("Intellectual Property Rights") in connection with Wade Products will be jointly owned
by Wade and Naked. Wade will retain all ownership of the Intellectual Property Rights in connection
with Wade Image including, for the avoidance of doubt, the Logo. For the avoidance of doubt, no
rights are being granted hereunder to any intellectual property belonging to the NBA or its member
clubs (including but not limited to the Miami Heat).

Subject to Section 14A, Naked will retain all ownership of the Intellectual Property Rights in
connection with the Naked Products, the Naked brand and any and all related brands. All advertising
material produced hereunder will be and remain the absolute property of Naked. Wade acknowledges
that he does not now have and in the future will assert no right, title or interest of any kind or
nature whatsoever therein, or in or to any component part or tape, dub or copy or element or
character or characterization thereof.

10

Source: NAKED BRAND GROUP INC., POS AM (on S-1), 7/31/2015

Confidential Information has been omitted in places marked "[***]" and has been filed separately
with the Securities and Exchange Commission. Confidential Treatment has been requested with respect
to this omitted information pursuant to an application for confidential treatment filed with the
Commission under Rule 406 under the Securities Act of 1934, as amended.
<!-- page 11 -->
15. Representations and Warranties of Naked and Wade.

A. Wade relies upon Naked's skill and judgment and also upon the following representations of Naked
which shall be in effect throughout the term of this Agreement:

(1) Naked's products will be merchantable and fit for the purpose for which they are intended, and

(2) Naked's products will conform at all times to all applicable federal, state and local laws,
rules, regulations, ordinances, and other enactments and industry standards, including, but not
limited to, those relating to product safety.

B. Wade Enterprises and Athlete hereby jointly and severally represent to Naked the following:

(1) Authorization. Wade Enterprises is an entity duly organized and validly existing in good
standing under the laws of its jurisdiction of organization. Wade Enterprises and Athlete each have
the requisite power and authority to enter into, execute and deliver the Agreement to which it is a
party and to perform all of the obligations to be performed by each of them hereunder. The Agreement
and the obligations and transactions contemplated hereby have been, duly authorized, executed and
delivered by each of them, and the Agreement constitutes each of their valid and binding obligation,
enforceable against such Party in accordance with its terms.

(2) No Conflicts. Neither the execution and delivery of this Agreement nor the performance or
consummation of the transactions contemplated hereby or thereby by either Wade Enterprises or
Athlete will conflict with, result in the breach of, constitute a default under or accelerate the
performance required by the terms of: (i) any law, rule or regulation of any government or
governmental or regulatory agency; (ii) any judgment, order, writ, decree, permit or license of any
court or governmental or regulatory agency to which such Party may be subject; (iii) any contract,
agreement, commitment or instrument to which Wade Enterprises or Athlete is a party; or (iv) Wade
Enterprises' constituent documents or other governing instruments (or constitute an event which,
with the passage of time or action by a third party, would result in any of the foregoing). The
execution and delivery of this Agreement by Wade Enterprises and Athlete and the performance and
consummation of the transactions contemplated hereby do not require any registration, filing,
qualification, consent or approval under any material law, rule, regulation, judgment, order, writ,
decree, permit or license to which such Party is subject.

16. Indemnity.

Naked shall be solely responsible for all liability arising out of production, distribution and sale
of its product. Naked hereby agrees to indemnify, defend and hold harmless Wade Enterprises,
Athlete, his agents, representatives and employees (referred to collectively as "Wade Indemnities")
from and against any and all claims, actions, causes or action, damages, injuries, expenses,
liabilities (joint and several), penalties fines, attorneys' fees, court costs, and any other
expenses incurred by Wade Indemnities arising out of (1) breach by Naked of any of the terms,
representations or warranties made by Naked in this Agreement; or (2) Naked product liability or
trademark patent or other proprietary right infringement; or (3) errors, omissions, fraudulent or
negligent acts by Naked, its employees, agents or subcontractors in connection with (i) any
advertising featuring Athlete; (ii) the performance of Naked's duties and obligations under this
Agreement; (iii) the production, distribution, promotion, marketing and sales of products including
related product packaging; and/or (iv) the operation and management of its production and
distribution facilities, however caused. Naked shall not be obligated to indemnify Wade with respect
to damages which are the result of the gross negligence or willful misconduct of Wade.

11

Source: NAKED BRAND GROUP INC., POS AM (on S-1), 7/31/2015

Confidential Information has been omitted in places marked "[***]" and has been filed separately
with the Securities and Exchange Commission. Confidential Treatment has been requested with respect
to this omitted information pursuant to an application for confidential treatment filed with the
Commission under Rule 406 under the Securities Act of 1934, as amended.
<!-- page 12 -->
Athlete and Wade Enterprises, jointly and severally, hereby agree to indemnify, defend and hold
harmless Naked, its shareholders, directors, officers, employees, agents, and affiliates (referred
to collectively as "Naked Indemnities") from and against any and all claims, actions, causes or
action, damages, injuries, expenses, liabilities (joint and several), penalties fines, attorneys'
fees, court costs, and any other expenses incurred by Naked Indemnities arising out of or are in any
way connected directly or indirectly with any and all claims, suits, actions, costs, and other
expenses, fines, judgments, investigations, proceedings, demands, liabilities, and obligations of
any nature whatsoever, with respect to Wade Enterprises' or Athlete's breach of its respective
representations and warranties, uncured breach of this Agreement or Athlete's gross negligence or
willful misconduct.

17. Relationship of Parties. Nothing contained in this Agreement shall be deemed or construed to
place the Parties in the relationship of partners, joint venturers, principal-agents, or
employer-employee, it being understood that the Parties are and will remain independent contractors
in all respects and neither Party shall have any right to obligate or bind the other in any manner
whatsoever.

18. Assignment. Neither this Agreement nor any of the rights or obligations contained herein may be
assigned or transferred by either Party without the prior written consent of the other Party.

19. Expenses. Each Party will bear its own expenses with respect to the execution of this Agreement
and the transactions contemplated thereunder, including but not limited to legal fees.

20. Authority to Contract. Each of the Parties represents and warrants that it has full right and
power to enter into this Agreement, to perform all obligations to be performed by it hereunder, and
to grant all rights hereunder granted without violating the legal or equitable rights of any other
person or entity, and that the execution and performance of this Agreement will not conflict with or
result in a breach of or default under any of the terms or conditions of any agreement to which
either Party has agreed, or is a Party, or may be bound.

21. Construction of Agreement. Each Party acknowledges that it has participated in the negotiation
of this Agreement and that no provision of this Agreement shall be construed against or be
interpreted to the disadvantage of any Party by any court or other governmental or judicial
authority by reason of such Party having or deemed to have structured, dictated or drafted such
provision.

12

Source: NAKED BRAND GROUP INC., POS AM (on S-1), 7/31/2015

Confidential Information has been omitted in places marked "[***]" and has been filed separately
with the Securities and Exchange Commission. Confidential Treatment has been requested with respect
to this omitted information pursuant to an application for confidential treatment filed with the
Commission under Rule 406 under the Securities Act of 1934, as amended.
<!-- page 13 -->
22. Merger; Modification. This Agreement constitutes the entire agreement with respect to the
subject matter contained herein and supersedes all previous communications and agreements between
the Parties pertaining to the subject matter hereof, whether written or oral. The terms of this
Agreement may not be modified, waived, amended, discharged, terminated, or supplemented, or
otherwise changed, except by a written document executed by each Party.

23. No Waiver. A waiver by either Party of any of the terms or conditions of this Agreement in any
instance shall not be deemed or construed to be a waiver of such term or condition for the future,
or of any subsequent breach thereof, or any other term or condition of this Agreement. All remedies,
rights, undertakings, obligations, and agreements contained in this Agreement shall be cumulative
and none of them shall be in limitation of any other remedy, right, undertaking, obligation or
agreement of either Party.

24. Severability. If any provision of this Agreement, as applied to either Party or to any
circumstance, shall be adjudged by a court of competent jurisdiction to be void or unenforceable,
whether at law or in equity, then such determination shall in no way affect any other provision of
this Agreement, or the validity or enforceability of this Agreement.

25. Choice of Law. This Agreement, all amendments hereto, and any and all issues or controversies
arising here from or related hereto, shall be governed by and construed exclusively in accordance
with the laws of the State of New York.

26. Arbitration of Disputes. The parties agree to use commercially reasonable efforts to settle
amicably any controversy, or claim arising out of the Agreement or any breach thereof through a
dispute resolution process involving Wade and members from the senior management of Naked. If the
parties do not otherwise agree, either party may present any unresolved dispute for arbitration in
accordance with the Commercial Arbitration Rules of the American Arbitration Association (the
"Rules") then in effect. Such arbitration will be held in New York, NY. The arbitration will be by a
single arbitrator chosen by the parties, provided that if the parties fail to agree and to appoint a
single arbitrator within twenty (20) business days from the date that one of the parties has made a
demand for arbitration, then the arbitrator will be chosen in accordance with the Rules. The
decision of the arbitrator will be final and binding on the parties and any award of the arbitrator
may be entered in any court of competent jurisdiction.

27. Attorneys' Fees. If any action is necessary to enforce the provisions of this Agreement,
including any claims or demands, or to interpret this Agreement, the prevailing Party shall be
entitled to reasonable attorneys' fees, costs and necessary disbursements in addition to any other
relief to which it may otherwise be entitled.

28. Captions; Structure. Section headings used in this Agreement are for convenience of reference
only and shall not in any way affect the interpretation of any section of this Agreement or of the
Agreement itself.

29. Time is of the Essence. Time is of the essence with respect to the performance of the duties and
obligations hereunder.

30. Counterparts. This Agreement may be executed in one or more counterparts, each of which shall be
deemed an original and all of which when taken together shall be construed as a single instrument.
This Agreement may be executed by facsimile or other electronic transmissions, and signatures on any
facsimile or electronic transmission copy hereof shall be deemed authorized original signatures.

13

Source: NAKED BRAND GROUP INC., POS AM (on S-1), 7/31/2015

Confidential Information has been omitted in places marked "[***]" and has been filed separately
with the Securities and Exchange Commission. Confidential Treatment has been requested with respect
to this omitted information pursuant to an application for confidential treatment filed with the
Commission under Rule 406 under the Securities Act of 1934, as amended.
<!-- page 14 -->
31. No Third Party Beneficiaries. This Agreement is not for the benefit of any third party and shall
be deemed not to give any right or remedy to such third party, whether referred to herein or not.

32. Recitals. The recitals contained in this Agreement are true and correct and are incorporated
herein by reference.

[SIGNATURE PAGE TO FOLLOW]

14

Source: NAKED BRAND GROUP INC., POS AM (on S-1), 7/31/2015

Confidential Information has been omitted in places marked "[***]" and has been filed separately
with the Securities and Exchange Commission. Confidential Treatment has been requested with respect
to this omitted information pursuant to an application for confidential treatment filed with the
Commission under Rule 406 under the Securities Act of 1934, as amended.
<!-- page 15 -->
IN WITNESS WHEREOF, the Parties have executed this Agreement on the day and date first above
written.

WITNESS: Naked Brand Group, Inc. ("Naked") By: By: /s/ Carole Hochman Date: Title: WITNESS: Wade
Enterprises, LLC ("Wade") By: By: /s/ Dwyane Wade Date:

15

Source: NAKED BRAND GROUP INC., POS AM (on S-1), 7/31/2015

Confidential Information has been omitted in places marked "[***]" and has been filed separately
with the Securities and Exchange Commission. Confidential Treatment has been requested with respect
to this omitted information pursuant to an application for confidential treatment filed with the
Commission under Rule 406 under the Securities Act of 1934, as amended.
<!-- page 16 -->
Inducement Letter and Guarantee

In order to induce Naked to enter into this Agreement with Wade Enterprises, LLC, I agree to the
execution and delivery of this Agreement by Wade Enterprises, LLC, and agree to render all the
services herein provided to be rendered by me, to grant all the rights granted herein, and to be
bound by and duly perform and observe each and all of the terms and conditions of this Agreement
regarding performance or compliance on my part, and I hereby join in all warranties,
representations, agreements and indemnities made by Wade Enterprises, LLC, and further confirm the
rights granted to Naked under the Agreement. All notices to Wade Enterprises, LLC shall be deemed
notices to me with the same effect as if given to me. I certify that my services are rendered as an
employee of Wade Enterprises, LLC, and, unless substituted for Wade Enterprises, LLC by law, I agree
to look solely to Wade Enterprises, LLC for payment of compensation for my services and the
discharge all other obligations of an employer, subject to the terms of the Agreement.

By: /s/ Dwyane Wade Name: Dwyane Wade Date: NAKED BRAND GROUP, INC. By: /s/ Carole Hochman Name:
Date:

16

Source: NAKED BRAND GROUP INC., POS AM (on S-1), 7/31/2015

Confidential Information has been omitted in places marked "[***]" and has been filed separately
with the Securities and Exchange Commission. Confidential Treatment has been requested with respect
to this omitted information pursuant to an application for confidential treatment filed with the
Commission under Rule 406 under the Securities Act of 1934, as amended.
<!-- page 17 -->
SCHEDULE A

WADE TRADEMARKS AND COPYRIGHTS

Wade's Asterisk Logo

17

Source: NAKED BRAND GROUP INC., POS AM (on S-1), 7/31/2015
<!-- page 18 -->
Confidential Information has been omitted in places marked "[***]" and has been filed separately
with the Securities and Exchange Commission. Confidential Treatment has been requested with respect
to this omitted information pursuant to an application for confidential treatment filed with the
Commission under Rule 406 under the Securities Act of 1934, as amended.

18

Source: NAKED BRAND GROUP INC., POS AM (on S-1), 7/31/2015

Confidential Information has been omitted in places marked "[***]" and has been filed separately
with the Securities and Exchange Commission. Confidential Treatment has been requested with respect
to this omitted information pursuant to an application for confidential treatment filed with the
Commission under Rule 406 under the Securities Act of 1934, as amended.
<!-- page 19 -->
SCHEDULE B

[***]

19

Source: NAKED BRAND GROUP INC., POS AM (on S-1), 7/31/2015
