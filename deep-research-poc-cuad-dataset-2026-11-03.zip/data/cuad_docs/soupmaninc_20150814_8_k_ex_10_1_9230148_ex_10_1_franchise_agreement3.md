<!-- page 1 -->
# Attachment C to Master Franchise Agreement MULTI-STATE ADDENDUM CALIFORNIA APPENDIX
| Field | Value |
|---|---|
| Document Type | Franchise Agreement |
| SEC Filing Date | 2015-08-14 |
| Source | CUAD v1 / SoupmanInc_20150814_8-K_EX-10.1_9230148_EX-10.1_Franchise Agreement3 |

Attachment C to Master Franchise Agreement MULTI-STATE ADDENDUM CALIFORNIA APPENDIX 1. California
Business and Professions Code Sections 20000 through 20043 provide rights to you concerning
termination or non-renewal of a franchise. If the Master Franchise Agreement contains provisions
that are inconsistent with the law, the law will control.

2. The Master Franchise Agreement provides for termination upon bankruptcy. This provision may not
be enforceable under Federal Bankruptcy Law (11 U.S.C.A. Sec. 101 et seq. ).

3. The Master Franchise Agreement contains covenants not to compete which extend beyond the
termination of the agreement. These provisions may not be enforceable under California law.

4. Section 31125 of the California Corporation Code requires the franchisor to provide you with a
disclosure document before asking you to agree to a material modification of an existing franchise.

5. Neither the franchisor, any person or franchise broker in Item 2 of the Disclosure Document is
subject to any currently effective order of any national securities association or national
securities exchange, as defined in the Securities Exchange Act of 1934, 15 U.S.C.A. 79a et seq.,
suspending or expelling such persons from membership in such association or exchange.

6. The Master Franchise Agreement requires non-binding mediation. The mediation will occur in New
York with the costs being borne by equally by the parties. Prospective franchisees are encouraged to
consult private legal counsel to determine the applicability of California and federal laws (such as
Business and Professions Code Section 20040.5 and Code of Civil Procedure Section 1281) to any
provisions of a franchise agreement restricting venue to a forum outside the State of California.

7. The Master Franchise Agreement requires application of the laws of New York. This provision may
not be enforceable under California law.

8. You must sign a general release if you renew or transfer your franchise. California Corporation
Code 31512 voids a waiver of your rights under the Franchise Investment Law (California Corporations
Code 31000 through 31516). Business and Professions Code 20010 voids a waiver of your rights under
the Franchise Relations Act (Business and Professions Code 20000 through 20043).

9. THE CALIFORNIA FRANCHISE INVESTMENT LAW REQUIRES THAT A COPY OF ALL PROPOSED AGREEMENTS RELATING
TO THE SALE OF THE FRANCHISE BE DELIVERED TOGETHER WITH THE DISCLOSURE DOCUMENT.

10. The Master Franchise Agreement contains a liquidated damages clause. Under California Civil Code
Section 1671, certain liquidated damages clauses are unenforceable.

11. OUR WEBSITE, www.originalsoupman.com, HAS NOT BEEN REVIEWED OR APPROVED BY THE CALIFORNIA
DEPARTMENT OF BUSINESS OVERSIGHT. ANY COMPLAINTS CONCERNING THE CONTENT OF THIS WEBSITE MAY BE
DIRECTED TO THE CALIFORNIA DEPARTMENT OF BUSINESS OVERSIGHT at www.dbo.ca.gov.

Source: SOUPMAN, INC., 8-K, 8/14/2015
