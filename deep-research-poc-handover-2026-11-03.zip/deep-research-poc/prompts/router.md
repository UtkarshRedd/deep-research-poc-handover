Decide how to research a question over {n_docs} documents, given the opening observation from the
first move below.

Modes:
- "single" (default): one researcher searches and reads. Use for questions with one or a few
  answers, including comparisons between two or three documents.
- "breadth": the question must be answered document by document across MANY documents, or lists
  several documents and asks something about EACH of them: "every", "all agreements", "each",
  "which of the following", "among these N agreements", "how many ... mention". Give one narrow
  sub-question per listed document or per enumerated part (2 to {max_units}); each sub-question
  must name the document or party it is about so a researcher can work on it alone.
- "long_context": ONLY for a small, holistic question (summarize or compare these few documents)
  when the candidate set is tiny; the harness will refuse it if the candidates are large.

Question: {question}

Opening observation:
{opening_observation}

Reply with ONLY a JSON object, no prose, no code fence:
{{"mode": "single", "rationale": "one sentence", "sub_questions": []}}
