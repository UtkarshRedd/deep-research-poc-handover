<!-- page 1 -->
# JOINT VENTURE AGREEMENT
| Field | Value |
|---|---|
| Document Type | Joint Venture Agreement |
| Agreement Date | 2020-03-20 |
| Parties | BorrowMoney.com, inc.; JVLS, LLC; BorrowMoney.com, inc.; JVLS, LLC (individually the "Member" and collectively the "Members") |
| Source | CUAD v1 / BORROWMONEYCOM,INC_06_11_2020-EX-10.1-JOINT VENTURE AGREEMENT |

Exhibit 10.1

JOINT VENTURE AGREEMENT THIS JOINT VENTURE AGREEMENT (the "Agreement") made and entered into this
20th day of Friday, March 2020 (the "Execution Date"), BETWEEN: BorrowMoney.com, inc of 512 Bayshore
DR, suite 201 Fort Lauderdale FL 33304, and JVLS, LLC dba Vaccines 2Go of 4060 Johns Creek Parkway
Suite H Suwanee, GA 30024 (individually the "Member" and collectively the "Members"). BACKGROUND: A.
The Members wish to enter into an association of mutual benefit and agree to jointly invest and set
up a joint venture enterprise. B. This Agreement sets out the terms and conditions governing this
association. IN CONSIDERATION OF and as a condition of the Members entering into this Agreement and
other valuable consideration, the receipt and sufficiency of which consideration is acknowledged,
the Members agree as follows: Formation 1. By this Agreement the Members enter into a joint venture
(the "Venture") in accordance with the laws of the State of Florida. The rights and obligations of
the Members will be as stated in the applicable legislation of the State of Florida (the "Act")
except as otherwise provided here. Name 2. The business name of the Venture will be BM&V2GO. Page 1
of 13
<!-- page 2 -->
Purpose 3. The exclusive purpose of the Venture (the "Purpose") will be IT Development. internet
Back office Maintenance And Deployment of medical Service. Term 4. The duration of this Venture (the
"Term") will begin on March 1, 2020 and continue in full force and effect until February 28, 2025 or
as otherwise provided in this Agreement. 5. The Term may be extended with the unanimous consent of
all Members. Place of Business 6. The principal office of the business of the Venture will be
located at 512 Bayshore Drive Suite 201 Fort Lauderdale, FL 33304 or such other place as the Members
may from time to time designate. Business Management 7. The following managers (the "Managers") have
been appointed by the Members to manage the Venture: ● Aaldo PIscitello ● Jody Stewart 8. Except as
otherwise provided in this Agreement, the individual Managers may be appointed, replaced, or removed
upon unanimous consent of the Members. 9. The Managers will have a primary duty to the best interest
of the Venture and not directly to any individual Member. 10. Within the limits of the Purpose of
the Venture and the terms of this Agreement, the Managers, acting jointly, will have full authority
to bind the Members in all matters relating to the direction, control and management of the Venture.
Conduct and actions of the Managers will be dictated by policy and procedure established by the
Members. Authority to bind the Venture in contract or in any third party business relation lies
exclusively with the Managers, acting jointly. 11. The Managers will jointly decide major issues
concerning the Venture. Where Managers are unable to reach agreement in deciding major issues,
approval by a majority vote of the Members at a regular or special meeting will be required. Page 2
of 13
<!-- page 3 -->
Management Duties 12. Except as otherwise specified in this agreement, the duties and obligations of
the Managers in relation to the Venture will include the following: a. managing the day to day
business of the Venture; b. monitoring, controlling and directing the financial, business and
operational affairs of the Venture; c. proper maintenance of books of account and financial records
according to accepted accounting practices; d. monitoring, analyzing and acting on all issues over
which it would have express or implied authority according to this Agreement; and e. all
responsibilities attached to hiring of production and administration staff including any required
labor negotiations, and all responsibilities attached to hiring of third party contractors. Member
Duties 13. Each Member will be responsible for its respective duties as follows:

Page 3 of 13
<!-- page 4 -->
Member Duties Description

BorrowMoney.com, inc

*HTML code, build, deploy and maintain all technical aspect requirements including a database for
medical dispatch personal & product service as needed, including activity information, data storage
and backup. provided by three qualified assigned Borrowmoney.com, inc. employees/personal

JVLS, LLC dba Vaccines 2Go

$60,000.00 USD From Monthly Government , City And State, And Or Private Awarded Contracts. Plus
(10%) Of Any Generated Gross Revenue From Awarded Contract, In Addition to The Total Contributions.
14. Duties of Members may be amended, from time to time, by decision of the Members, provided that
the Members' interests are not affected except with the unanimous consent of the Members. Capital
Contributions 15. Each of the Members has contributed to the capital of the Venture, in cash or
property in agreed upon value, as follows (the "Capital Contribution"): Member Contribution
Description Agreed Value

BorrowMoney.com, inc 1, 500 square feet of Leased/rent office Space Includingspecified Description
of duty* $3,500,000.00 USD

JVLS, LLC dba Vaccines 2Go

$60,000.00 USD From Monthly Government , City And State, And Or Private Awarded Contracts. Plus
(10%) Of Any Generated Gross Revenue, In Add i t i on to The To ta l Contributions.

$3,500,000.00 USD

16. All Members will contribute their respective Capital Contributions fully and on time.

Page 4 of 13
<!-- page 5 -->
Withdrawal of Capital 17. No Member will have the right to demand or withdraw any portion of their
capital contribution without the express written consent of the remaining Members. 18. The Members
will not be personally liable for the return of all or part of the Capital Contributions of a
Member, except as otherwise provided in this Agreement. Additional Capital 19. Capital Contributions
may be amended from time to time, according to the requirements of the Venture, by decision of the
Members as recommended by the Managers. Where Members' interests are affected, additional capital
contributions (the "Additional Capital Contributions") must have the unanimous consent of the
Members. 20. Any advance of money to the Venture by any Member in excess of the amounts provided for
in this Agreement or subsequently agreed to as an Additional Capital Contribution will be deemed a
debt due from the Venture rather than an increase in Capital Contribution of the Member. This
liability will be repaid with interest at such rates and times to be determined by a majority of the
Members. This liability will not entitle the lending Member to a greater voting power. Such debts
may have preference or priority over any other payments to Members as may be determined by a
majority of the Members. Capital Accounts 21. An individual capital account will be maintained for
each Member and their initial Capital Contribution will be credited to this account. Any additional,
approved contributions to the Venture's capital made by a Member will be credited to that Member's
individual Capital Account. Interest on Capital 22. No borrowing charge or loan interest will be due
or payable to any Member on any Capital Contribution or on their Capital Account despite any
disproportion that may from time to time arise among the Capital Accounts of the Members. Page 5 of
13
<!-- page 6 -->
Books of Account 23. Accurate and complete books of account of the transactions of the Venture will
be kept in accordance with generally accepted accounting principles (GAAP) and at all reasonable
times will be available and open to inspection and examination by any Member. The books and records
of the Venture will reflect all the Venture's transactions and will be appropriate and adequate for
the business conducted by the Venture. Banking and Venture Funds 24. The funds of the Venture will
be placed in such investments and banking accounts as will be designated by the Members. Venture
funds will be held in the name of the Venture and will not be commingled with those of any other
person or entity. Member Meetings 25. Regular Member meetings will be held quarterly. Minutes of the
meetings will be maintained on file. 26. Any Member can call a special meeting to resolve urgent
issues that require a vote and that cannot wait for the next regularly scheduled meeting. When
calling a special meeting, all Members must be provided with reasonable notice. Where a special
meeting has been called, the meeting will be restricted to the specific purpose for which the
meeting was called. 27. All meetings will be held at a time and in a location that is reasonable,
convenient and practical considering the situation of all Members. 28. Any vote required by the
Members will be determined such that each Member receives one vote carrying equal weight. Amendments
29. This Agreement may be amended only with the unanimous consent of all Members. Admitting a new
Member 30. New Members may be admitted into the Venture only with the unanimous consent of the
existing Members. The new Member agrees to be bound by all the covenants, terms, and conditions of
this Agreement, inclusive of all current and future amendments. Further, a new Member will execute
such documents as are needed or required for this admission. Any new Member will receive a business
interest in the Venture as determined by all other Members. Page 6 of 13
<!-- page 7 -->
Dissociation of a Member 31. Where a Member is in breach of this Agreement and that Member has not
remedied the breach on notice from the Venture and after a reasonable period then the remaining
Members will have the right to terminate this Agreement with regard to that individual defaulting
Member (an "Involuntary Withdrawal") and take whatever action necessary to protect the interests of
the Venture. 32. If the Venture is harmed as the result of an individual Member's action or failure
to act, then that individual Member will be liable for that harm. If more than one Member is at
fault then they will be jointly and severally liable for that harm. 33. Each Member will indemnify
the remaining Members against all losses, costs and claims that may arise in the event of the
Venture being terminated as a result of breach of the Agreement by that Member. 34. If a Member is
placed in bankruptcy, or withdraws voluntarily from the Venture, or if there is an Operation of Law
against a Member, the other Members will be entitled to proceed as if the Member had breached this
Agreement. 35. Distribution of any amount owing to a dissociated Member will be made according to
the percentage of ownership as described in the Valuation of Interest or as otherwise may be agreed
in writing. Dissolution of the Joint Venture 36. The Venture will be dissolved and its assets
liquidated in the event of any of the following: a. the Term expires and is not extended; b. a
unanimous vote by the Members to dissolve the Venture; c. on satisfaction of the Purpose; d. loss or
incapacity through any means of substantially all of the Venture's assets; or e. where only one
Member remains. Page 7 of 13
<!-- page 8 -->
Liquidation 37. On dissolution, the Venture will be liquidated promptly and within a reasonable
time. 38. On the liquidation of the Venture assets, distribution of any amounts to Members will be
made in proportion to their respective capital accounts or as otherwise may be agreed in writing.
Valuation of Interest 39. In the absence of a written agreement setting a value, the value of the
Venture will be determined based on the fair market value appraisal of all Venture assets (less
liabilities) in accordance with generally accepted accounting principles (GAAP) by an independent
accounting firm agreed to by all Members. An appraiser will be appointed within a reasonable period
of the date of withdrawal or dissolution. The results of the appraisal will be binding on all
Members. A withdrawing Member's interest will be based on the proportion of their respective capital
account less any outstanding liabilities a Member may have to the Venture. The intent of this
section is to ensure the survival of the Venture despite the withdrawal of any individual Member.
40. No allowance will be made for goodwill, trade name, patents or other intangible assets, except
where those assets have been reflected on the Venture books immediately prior to valuation. Transfer
of Member Interest 41. A Member may assign their proprietary assets and their rights in distribution
interest in the Venture. Such assignment will only include that Member's economic rights and
interests and will not include any other rights of that Member nor will it include an automatic
admission as a Member of the Venture or the right to exercise any management or voting interests. A
Member who assigns any or all of their Venture interest to any third party will relinquish their
status as Member including all management and voting rights. Assignment of Member status, under this
clause, including any management and voting interests, will require the consent of all the remaining
Members. Page 8 of 13
<!-- page 9 -->
Management Voting 42. Any management vote required will be determined such that each Manager
receives one vote carrying equal weight. Force Majeure 43. A Member will be free of liability to the
Venture where the Member is prevented from executing their obligations under this Agreement in whole
or in part due to force majeure where the Member has communicated the circumstance of that event to
any and all other Members and taken any and all appropriate action to mitigate that event. Force
majeure will include, but not be limited to, earthquake, typhoon, flood, fire, and war or any other
unforeseen and uncontrollable event. Duty of Loyalty 44. Provided a Member has the consent of the
majority of the other Members, the Members to this Agreement and their respective affiliates may
have interests in businesses other than the Venture. Neither the Venture nor any other Member will
have any rights to the assets, income or profits of any such business, venture or transaction. Any
and all businesses, ventures or transactions with any appearance of conflict of interest must be
fully disclosed to all other Members. Failure to disclose any potential conflicts of interest will
be deemed an Involuntary Withdrawal by the offending Member and may be treated accordingly by the
remaining Members. Confidentiality 45. All matters relating to this Agreement and the Venture will
be treated by the Members as confidential and no Member will disclose or allow to be disclosed any
Venture matter or matters, directly or indirectly, to any third party without the prior written
approval of all Members except where the information properly comes into the public domain. 46. This
section will survive for one year after the expiration or termination of this Agreement or
dissolution of the Venture. Language 47. The Members expressly state that the English language is to
be the language of choice for this Agreement and all other notices and agreements required by the
Venture. Page 9 of 13
<!-- page 10 -->
Insurance 48. The Venture will insure all its assets against loss where reasonable and standard
practice in the industry. Indemnification 49. Each Member will be indemnified and held harmless by
the Venture from any and all harm or damages of any nature relating to the Member's participation in
Venture affairs except where such harm or damages results from gross negligence or willful
misconduct on the part of the Member. Liability 50. No Member will be liable to the Venture or to
any other Member for any error in judgment or any act or failure to act where made in good faith.
The Member will be liable for any and all acts or failures to act resulting from gross negligence or
willful misconduct. Liability Insurance 51. The Venture may acquire insurance on behalf of any
Member, employee, agent or other person engaged in the business interest of the Venture against any
liability asserted against them or incurred by them while acting in good faith on behalf of the
Venture. Covenant of Good Faith 52. Members will use their best efforts, fairly and in good faith to
facilitate the success of the Venture. Joint Venture Property 53. Where allowed by statute, title to
all Venture property, including intellectual property, will remain in the name of the Venture. Where
joint ventures are not recognized by statute as separate legal entities, Venture property, including
intellectual property, will be held in the name of one or more Members. In all cases Venture
property will be applied by the Members exclusively for the benefit and purposes of the Venture and
in accordance with this Agreement. Jurisdiction 54. The Members submit to the jurisdiction of the
courts of the State of Florida for the enforcement of this Agreement and for any arbitration award
or decision arising from this Agreement. Page 10 of 13
<!-- page 11 -->
Mediation and Arbitration 55. In the event a dispute arises out of, or in connection with, this
Agreement, the Members will attempt to resolve the dispute through friendly consultation. 56. If the
dispute is not resolved within a reasonable period then any or all outstanding issues may be
submitted to mediation in accordance with any statutory rules of mediation. If mediation is not
successful in resolving the entire dispute or is unavailable, any outstanding issues will be
submitted to final and binding arbitration in accordance with the laws of the State of Florida. The
arbitrator's award will be final, and judgment may be entered upon it by any court having
jurisdiction within the State of Florida. Warranties 57. All Members represent and warrant that they
have all authority, licenses and permits to execute and perform this Agreement and their obligations
under this Agreement and that the representative of each Member has been fully authorized to execute
this Agreement. 58. Each Member represents and warrants that this Agreement is not in violation of
any and all agreements and constitutional documents of the individual Member. Definitions 59. For
the purpose of this Agreement, the following terms are defined as follows: a. "Capital
Contributions" The capital contribution to the Venture actually made by the Members, including
property, cash and any additional capital contributions made. b. "Majority Vote" A Majority Vote is
any amount greater than one-half of the authorized votes. c. "Operation of Law" The Operation of Law
means rights or duties that are cast upon a party by the law, without any act or agreement on the
part of the individual including but not limited to an assignment for the benefit of creditors, a
divorce, or a bankruptcy. Page 11 of 13
<!-- page 12 -->
Miscellaneous 60. This Venture is termed a contractual joint venture and will not constitute a
partnership. Members will provide services to one another on an arms' length basis while remaining
independent business entities. There will be no pooling of profits and losses. Each Member is
responsible only for its own actions and no Member is an agent for any other Member. Members will
not be jointly or severally liable for the actions of the other Members. 61. Time is of the essence
in this Agreement. 62. This Agreement may be executed in counterparts. Facsimile signatures are
binding and are considered to be original signatures. 63. Headings are inserted for the convenience
of the Members only and are not to be considered when interpreting this Agreement. Words in the
singular mean and include the plural and vice versa. Words in the masculine gender include the
feminine gender and vice versa. Words in the neuter gender include the masculine gender and the
feminine gender and vice versa. 64. If any term, covenant, condition or provision of this Agreement
is held by a court of competent jurisdiction to be invalid, void or unenforceable, it is the
Members' intent that such provision be reduced in scope by the court only to the extent deemed
necessary by that court to render the provision reasonable and enforceable and the remainder of the
provisions of this Agreement will in no way be affected, impaired or invalidated as a result. 65.
This Agreement contains the entire agreement between the Members. All negotiations and
understandings have been included in this Agreement. Statements or representations which may have
been made by any Member in the negotiation stages of this Agreement may in some way be inconsistent
with this final written Agreement. All such statements are declared to be of no value in this
Agreement. Only the written terms of this Agreement will bind the Members. 66. This Agreement and
the terms and conditions contained in this Agreement apply to and are binding upon the Member's
successors, assigns, executors, administrators, beneficiaries, and representatives. 67. Any notices
or delivery required here will be deemed completed when hand-delivered, delivered by agent, or seven
(7) days after being placed in the post, postage prepaid, to the Members at the addresses contained
in this Agreement or as the Members may later designate in writing. Page 12 of 13
<!-- page 13 -->
68. All of the rights, remedies and benefits provided by this Agreement will be cumulative and will
not be exclusive of any other such rights, remedies and benefits allowed by law. IN WITNESS WHEREOF
the Members have duly affixed their signatures under hand and seal on this 20th day of March 2020.
BorrowMoney.com, inc (Member) Per: /s/ Aldo Piscitello (SEAL) Aldo Piscitello President JVLS, LLC
dba Vaccines 2Go (Member) Per: /s/ Jody Stewart Jody Stewart (Mar 20, 2020) (SEAL) Jody Stewart Page
13 of 13
