<!-- page 1 -->
# MOBILE VIRTUALNETWORK ENABLER HOSTING AGREEMENT
| Field | Value |
|---|---|
| Document Type | Hosting Agreement |
| Agreement Date | 2008-09-18 |
| Parties | Elephant Talk Communication Holding AG ("ELEPHANT TALK"); T-Mobile Netherlands B.V. ("T-Mobile")("Party" and together as "Parties") |
| Source | CUAD v1 / PareteumCorp_20081001_8-K_EX-99.1_2654808_EX-99.1_Hosting Agreement |

Exhibit 99.1 CONFIDENTIAL TREATMENT REQUESTED WITH RESPECT TO CERTAIN PORTIONS HEREOF DENOTED WITH
"***"

MOBILE VIRTUAL NETWORK ENABLER HOSTING AGREEMENT

BETWEEN

T-MOBILE NETHERLANDS B.V.

&

Elephant Talk Communication Holding AG

Source: PARETEUM CORP, 8-K, 10/1/2008

CONFIDENTIAL TREATMENT REQUESTED WITH RESPECT TO CERTAIN PORTIONS HEREOF DENOTED WITH "***" Hosting
Agreement between ELEPHANT TALK and T-Mobile, 18/9/2008
<!-- page 2 -->
TABLE OF CONTENT 1. Definitions 2. Purpose and Scope of the Agreement 3. Hosting Services 4.
Implementation 5. Forecast & Commitments 6. Service level 7. Data Protection & Privacy 8. The
co-operation relationship 9. Prices, Charging, Billing & Accounting 10. Customer Care Support 11.
Confidentiality 12. Limitation of Liability 13. Suspension and termination of Hosting Services 14.
Force Majeure 15. Intellectual Property Rights 16. SIM cards and Calling Credit 17. Duration of the
Agreement 18. Termination of the Agreement 19. Modifications 20. Miscellaneous 21. Governing Law 22.
Dispute resolution 23. Counterpart

Source: PARETEUM CORP, 8-K, 10/1/2008

CONFIDENTIAL TREATMENT REQUESTED WITH RESPECT TO CERTAIN PORTIONS HEREOF DENOTED WITH "***" Hosting
Agreement between ELEPHANT TALK and T-Mobile, 18/9/2008
<!-- page 3 -->
MOBILE VIRTUALNETWORK ENABLER HOSTING AGREEMENT by and between ELEPHANT TALK and T-Mobile

(T-Mobile hosting ELEPHANT TALK)

This Agreement is made between "Elephant Talk Communication Holding AG", a company incorporated
under the laws of Switzerland, having its registered office at Baarerstrasse 135, CH-6301 Zug,
Switzerland, legally and duly represented by its Chief Executive Officer Steven van der Velden and
its Chief Operations Officer and Chief Technology Officer Martin Zuurbier, hereinafter referred to
as: "ELEPHANT TALK"

and

T-Mobile Netherlands B.V., a company incorporated under the laws of the Netherlands, having its
registered office at the Waldorpstraat 60, 2521 CC Den Haag, the Netherlands, legally and duly
represented by its Managing Director Niek Jan van Damme and its Marketing Director, Bart Weijermars,
hereinafter referred to as: "T-Mobile"

each individually referred to as "Party" and together as "Parties". WHEREAS:

1. ELEPHANT TALK wishes to become a full Mobile Virtual Network Enabler (hereinafter: "MVNE")
providing mobile telecommunications services to legal entities partnering with ELEPHANT TALK to
offer mobile services in an (Enhanced) Service Provider model using the T- Mobile network and the by
T-Mobile provided wholesale mobile network services; 2. T-Mobile is a licensed Dutch mobile
telecommunications and services provider operating inter alia its own GSM and UMTS/HSDPA mobile
network in The Netherlands with related basic services and offering wholesale and retail mobile
network services and associated services on the Dutch market; 3. *** and ELEPHANT TALK have
conducted preliminary discussions and negotiations leading to an initial understanding on the basic
business principles of an envisaged co-operation between *** and ELEPHANT TALK, which has been laid
down in Heads of Agreement between *** and ELEPHANT TALK ***; 4. ***; 5. In answer to the proposal
of *** and the additions to this proposal by T-Mobile, ELEPHANT TALK has confirmed by letter dated
November 30, 2007 that it agrees to be directly implemented on the T-Mobile network in order to ***
the T-Mobile network; 6. ELEPHANT TALK therefore wishes to obtain from T-Mobile wholesale mobile
network services and associated services and T-Mobile is willing to offer ELEPHANT TALK such
services; 7. Following the signing of the aforementioned Heads of Agreement between *** and ELEPHANT
TALK, Parties have continued their discussions and negotiations with regard to their envisaged
co-operation and have reached agreement on the terms and conditions in that respect, which are laid
down in this Agreement; NOW, THEREFORE, the Parties have agreed as follows:

Source: PARETEUM CORP, 8-K, 10/1/2008

CONFIDENTIAL TREATMENT REQUESTED WITH RESPECT TO CERTAIN PORTIONS HEREOF DENOTED WITH "***" Hosting
Agreement between ELEPHANT TALK and T-Mobile, 18/9/2008
<!-- page 4 -->
1. DEFINITIONS For the purpose of this Agreement, the following words and phrases shall have the
meanings set forth in their respective definitions, unless a different meaning is called for in the
context of another provision in this Agreement:

1.1 "Affiliated Company" of a Party shall mean any other legal entity: · directly or indirectly
owning or controlling the Party (Mother company), or · under the direct or indirect ownership or
control of the same legal entity (Mother company) directly or indirectly owning or controlling the
Party, or · directly or indirectly owned or controlled by the Party, for as long as such ownership
or control lasts. "Ownership" or "control" shall exist through the direct or indirect ownership of
more than fifty (50) percent of the nominal value of the issued equity share capital or of more than
fifty (50) percent of the shares entitling the holders to vote for the election of directors or
persons performing similar functions.

1.2 "Agreement" shall mean the Mobile Virtual Network Enabler(MVNE) hosting agreement together with
the Appendices attached to this MVNE hosting agreement. 1.3 "Appendix" and "Appendices" shall mean
the appendix or appendices attached to this Agreement.

1.4 "Business Day" shall mean any day other than Saturdays, Sundays and Dutch generally recognized
public holidays.

1.5 "Calendar Day" shall mean any day including Saturdays, Sundays and Dutch generally recognized
public holidays.

1.6 "CDR" shall mean call detail record.

1.7 "Commercial Launch Date" shall mean the date on which ELEPHANT TALK commercially launches the
Hosting Services and starts providing the ELEPHANT TALK Services commercially to ELEPHANT TALK
Customers in the Dutch market (not being the Soft Launch). The Commercial Launch Date shall not be
later than six (6) weeks after the Ready for Service Date.

1.8 "Date of the Agreement" shall mean the date on which both Parties have signed the Agreement by
their duly authorized representatives or, if the Parties sign this Agreement on different dates, the
later date being the date the Agreement comes fully into effect.

1.9 "ELEPHANT TALK Customer" shall mean any company or legal entity partnering with ELEPHANT TALK,
which wishes to offer mobile services in a MVNO/ESP/SP model using the T-Mobile Network and the by
T-Mobile provided Hosting Services under the terms and conditions as mentioned in this Agreement.
ELEPHANT TALK Customers might include the mobile end-users of ELEPHANT TALK Customers, subject to
the interpretation of the specific provision.

Source: PARETEUM CORP, 8-K, 10/1/2008

CONFIDENTIAL TREATMENT REQUESTED WITH RESPECT TO CERTAIN PORTIONS HEREOF DENOTED WITH "***" Hosting
Agreement between ELEPHANT TALK and T-Mobile, 18/9/2008
<!-- page 5 -->
1.10 "ELEPHANT TALK Infrastructure" shall mean the entire (current and future) servers and systems
of ELEPHANT TALK, including the physical or logical link to the NAP, as described in Appendix 11.

1.11 "ELEPHANT TALK Wholesale Services" shall mean the mobile telecommunication services provided by
ELEPHANT TALK to the ELEPHANT TALK Customers, offering services in a MVNO/ESP/SP model, based on the
Hosting Services via the T-Mobile Network and the networks of the T-Mobile roaming partners.

1.12 "GSM Association Permanent Reference Documents" shall mean the documents that are established,
recognized and classified as binding by the GSM Association Plenary.

1.13 "GSM Association Plenary" shall mean the group of appointed representatives of the Signatories
of the GSM Association.

1.14 "GSM Specifications" shall mean ETSI GSM technical specifications, as defined by the GSM
Association.

1.15 "Hosting Service(s)" shall mean the network hosting (and related) services - as listed in
Appendix 1 - provided by T-Mobile to ELEPHANT TALK under the Agreement, enabling ELEPHANT TALK to
provide ELEPHANT TALK Wholesale Services to ELEPHANT TALK Customers in accordance with its terms and
conditions of the Agreement.

1.16 "Implementation Plan" shall have the meaning as described to it in Appendix 3.

1.17 "IMSI" means the International Mobile Subscriber Identity, ***

1.18 "Initial Term" means the initial duration of the Agreement as agreed upon between the Parties
and defined in article 17.1

1.19 "IN platform" (the intelligent network platform) shall mean the technical architecture and
telecommunications systems of ELEPHANT TALK for routing calls and charging real-time the outgoing
calls of ELEPHANT TALK Customers. 1.20 "Location Areas" (LAs) shall mean the individual geographic
areas into which the T-Mobile Network is divided at any time.

1.21 "MSISDN" shall mean Mobile Station Integrated Services Digital Network Number.

1.22 "NAP" shall mean Network Access Point, as described in Appendix 11.

Source: PARETEUM CORP, 8-K, 10/1/2008

CONFIDENTIAL TREATMENT REQUESTED WITH RESPECT TO CERTAIN PORTIONS HEREOF DENOTED WITH "***" Hosting
Agreement between ELEPHANT TALK and T-Mobile, 18/9/2008
<!-- page 6 -->
1.23 "Operational Manual" shall mean the working document in which Parties agree upon (dynamic)
activities and procedures as described in the Agreement in more detail for the duration of the
Agreement. The Operational Manual is a dynamic document. The latest valid and binding version shall
be the one agreed in writing between the Parties in accordance with article 19.3.

1.24 "***" means the company formerly known as ***. formed under the laws of the Netherlands, *** in
The Hague, The Netherlands.

1.25 "Protocol of Delivery" (also referred to as "PoD") shall mean the document, as attached in
Appendix 10, provided by T-Mobile to ELEPHANT TALK following the Soft Launch for the purpose of
accepting the Hosting Services by ELEPHANT TALK.

1.26 "Quarter" and "Quarterly" shall mean a quarter of a year, being three consecutive months
starting every January, April, July and/or October of every calendar year.

1.27 "Ready for Service Date" shall mean the date, following the Soft Launch, upon which the Hosting
Services agreed between the Parties - in accordance with article 3 - meet the agreed specification
as evidenced by the signing of the Protocol for Delivery.

1.28 "Ready for Test Date" shall mean the date on which the end-to-end test, to be performed
internally by T-Mobile solely, has been completed by T-Mobile and pursuant to which ELEPHANT TALK
can commence the Soft Launch.

1.29 "Regulatory Provisions" shall mean all applicable laws, directives, consents, specifications,
regulations and/or stipulations set forth by the relevant regulatory authority.

1.30 "SIM card" shall mean a subscriber identity module (chip) card for the identification of -the
mobile end-users of - an ELEPHANT TALK Customer on the T-Mobile Network and enables access to the
ELEPHANT TALK Wholesale Services.

1.31 "SLA" means the Service Level Agreement attached hereto in Appendix 6.

1.32 "Soft Launch" shall mean the test to be performed under article 4 and as described in Appendix
3 and the period in which ELEPHANT TALK can gain experience with the functionalities of the Hosting
Services prior to the Commercial Launch Date.

Source: PARETEUM CORP, 8-K, 10/1/2008
<!-- page 7 -->
CONFIDENTIAL TREATMENT REQUESTED WITH RESPECT TO CERTAIN PORTIONS HEREOF DENOTED WITH "***" Hosting
Agreement between ELEPHANT TALK and T-Mobile, 18/9/2008

Source: PARETEUM CORP, 8-K, 10/1/2008
<!-- page 8 -->
1.33 "TAP" shall mean Transferred Account Procedure as defined and described in GSM Association
Permanent Reference Documents.

1.34 "Technical Specification" shall mean the working document in which Parties agree upon the
technical specification of the Hosting Services as attached in Appendix 11. 1.35 "T-Mobile Network"
shall mean the T-Mobile DCS 1800 and UMTS/HSDPA mobile telecommunications network, including all
network elements, in the Netherlands, as described in Appendix 1. 2. PURPOSE AND SCOPE OF THE
AGREEMENT

2.1 The purpose of this Agreement is to lay down the general terms and conditions between the
Parties under which T-Mobile shall provide the Hosting Services and ELEPHANT TALK shall purchase the
Hosting Services from T-Mobile, whereby T-Mobile shall enable ELEPHANT TALK to market, sell and
provide mobile telecommunication services to the ELEPHANT TALK Customers via the T-Mobile Network.
For the avoidance of doubt, ELEPHANT TALK is not entitled to provide (retail) telecommunication
services based on the Hosting Service to others than ELEPHANT TALK Customers, such as but not
limited to mobile end-users or business companies with their own end-users.

In the event that *** Parties shall negotiate the terms and conditions under which T-Mobile shall
provide and ELEPHANT TALK shall purchase the services from T-Mobile. These terms and conditions
shall be laid down in a separate document and shall therefore not be part of this Agreement.

2.2 T-Mobile is entitled without limitations, to *** related services to any other party.

2.3 ELEPHANT TALK will not enter into any discussions or agreement on the provisioning of (similar)
Hosting Services as defined in Appendix 1 with any *** in the Netherlands for the duration of the
Initial Term of the Agreement. In case ELEPHANT TALK has provided to T-Mobile the twelve month
termination notice in accordance with article 17.2, ELEPHANT TALK ***.

2.4 The co-operation between Parties shall regard ***. The Hosting Services are intended for ***.
ELEPHANT TALK is allowed to provide SIM cards to ELEPHANT TALK Customers under the terms and
conditions as mentioned in this Agreement. 2.5 For the scope of this Agreement, ELEPHANT TALK
(including its Affiliated Companies) shall not provide the Hosting Services to ***. Excluded from
this provision is the situation wherein ELEPHANT TALK provides *** under the terms and conditions as
set out in this article.

Source: PARETEUM CORP, 8-K, 10/1/2008

CONFIDENTIAL TREATMENT REQUESTED WITH RESPECT TO CERTAIN PORTIONS HEREOF DENOTED WITH "***" Hosting
Agreement between ELEPHANT TALK and T-Mobile, 18/9/2008
<!-- page 9 -->
ELEPHANT TALK is not allowed, without the explicit written approval of T-Mobile, to provide the
ELEPHANT TALK Wholesale Services: I. to the below stated categories of companies, including
companies that represent a company in one of these categories, affiliated companies and/or companies
that can offer a brand from a company in one of the following categories: a) *** b) *** c) ***.

II. in the situation where T-Mobile for good reason refuses a ELEPHANT TALK Customer access to the
T-Mobile Network such as: a) association with - proven- bad taste (companies or brands with a direct
reference to subjects such as criminal or illegal behavior, violence or drugs); b) possible harm of
the good name of T-Mobile; c) breach of an intellectual property right of T-Mobile; and/or d)
conflict with key strategic issues for T-Mobile and Deutsche Telekom Affiliate Companies (such as
legal issues and court cases). The ELEPHANT TALK Customers will not directly or indirectly provide
the ELEPHANT TALK Wholesale Services to others, including an Affiliated Company, with the objective
to resell wholesale telecommunication services based on the by T-Mobile provided Hosting Services to
mobile telecommunication users.

2.6 Parties agree to implement an ELEPHANT TALK ***, and therefore would not result in additional
costs for ELEPHANT TALK. In order to execute this assessment Parties will discuss the detailed
business requirements - provided by ELEPHANT TALK for the implementation of the ELEPHANT TALK *** -
and will do the utmost to agree on this set of business requirements before or on *** Provided that
Parties have agreed upon the final set of business requirements before or on ***, Parties shall
subsequently execute an initial evaluation - based on the business requirements - of the impact of
the implementation on the T-Mobile infrastructure and network. Parties agree to finalize this
initial evaluation on ***. The outcome of the initial evaluation shall consist of an agreed high
level project plan for the implementation of at least the implementation of the *** solution.
Following the initial evaluation Parties will further discuss and negotiate in good faith the
elements of the project plan, including the alignment of *** and available resources in order to
implement the ***. Both Parties aim to implement the *** before ***. However, the actual
implementation date of the *** solution is subject to the chosen technical and operational solution
for the *** solution. In any case T-Mobile is obliged to implement the *** before or on ***.

2.7 ELEPHANT TALK shall purchase the Hosting Services from T-Mobile as an independent contractor.
ELEPHANT TALK shall sell and market the ELEPHANT TALK Wholesale Services to ELEPHANT TALK Customers
in its own name, for its own account and on its own risk (subject to the terms of this Agreement).
ELEPHANT TALK warrants T-Mobile that ELEPHANT TALK Customers shall sell and market their mobile
telecommunication services based on the ELEPHANT TALK Wholesale Services in its own name, for its
own account and on its own risk. ELEPHANT TALK and ELEPHANT TALK Customers shall not in any respect
represent T-Mobile or enter into any agreement or other commitment on T-Mobile's behalf.

Source: PARETEUM CORP, 8-K, 10/1/2008

CONFIDENTIAL TREATMENT REQUESTED WITH RESPECT TO CERTAIN PORTIONS HEREOF DENOTED WITH "***" Hosting
Agreement between ELEPHANT TALK and T-Mobile, 18/9/2008
<!-- page 10 -->
2.8 ELEPHANT TALK shall ensure that the ELEPHANT TALK Infrastructure complies with the Technical
Specifications, as set out in Appendix 11.

2.9 Parties acknowledge that the Dutch telecommunications market is regulated under both Dutch and
EU law, such as inter alia EU-directives, the Dutch Telecommunications Act, Dutch Competition Act
and the Dutch Data Protection Act. Parties shall at all times fully comply with all relevant
regulations, such as but not limited to, the obligation for ELEPHANT TALK - as providers of public
electronic communications services in the Netherlands- to notify OPTA according to article 2.1 of
the Dutch Telecommunication Act.

Furthermore, Parties acknowledge that their arrangements are subject to said regulations, and that
Parties' arrangements (including pricing arrangements) may, from time to time, require adjustment(s)
due to change of such regulations.

2.10 The Hosting Services shall be provided in accordance with relevant GSM Specifications and the
GSM Association Permanent Reference Documents, including all the commercial aspects, as defined in
the Agreement. This foregoing is however subject to the additional requirements and exceptions to
the GSM specifications and GSM Association Permanent Reference Documents as may be agreed in writing
between Parties.

2.11 The Parties recognize that it may be appropriate to modify this Agreement, in circumstances in
which they deem it important to do so, in the light of experience and development in the GSM
Association, the GSM Specifications, the GSM Association Permanent Reference Documents and mobile
telecommunications services available at the market not offered by T-Mobile under this Agreement In
such case Parties shall agree upon a workable solution and act accordingly.

2.12 The Appendices shall form an integral part of the Agreement and shall be fully binding on and
enforceable by and against the Parties as applicable in accordance with this Agreement. In case that
the Agreement contains contradictory provisions, the documents constituting the Agreement shall have
the following priority for the purpose of interpretation: a) the Agreement; b) the Appendices in
order of their number;

Source: PARETEUM CORP, 8-K, 10/1/2008
<!-- page 11 -->
CONFIDENTIAL TREATMENT REQUESTED WITH RESPECT TO CERTAIN PORTIONS HEREOF DENOTED WITH "***" Hosting
Agreement between ELEPHANT TALK and T-Mobile, 18/9/2008

Source: PARETEUM CORP, 8-K, 10/1/2008
<!-- page 12 -->
Appendix No. Appendix Name Appendix 1 Service Description Appendix 2 Financials Appendix 3
Implementation plan Appendix 4 Forecasting Appendix 5 Lawful Intercept Appendix 6 Service Level
Agreement Appendix 7 Accounting and Billing Appendix 8 Roaming Appendix 9 Bank guarantee Appendix10
Protocol of Delivery Appendix 11 Technical Specification Appendix 12 *** Appendix 13 *** 3. HOSTING
SERVICES

3.1 T-Mobile shall provide the Hosting Services, as described in Appendix 1, during the term of this
Agreement from the Ready for Service Date.

3.2 T-Mobile shall ensure that all *** from ELEPHANT TALK Customers and other telecommunication end
users in the Netherlands and in the relevant roaming countries, as further specified in the
Agreement.

3.3 ELEPHANT TALK is responsible and accountable for the installation, maintenance and availability
of the leased line between ELEPHANT TALK's POP and the T-Mobile Network, as described in Appendix 1.

3.4 T-Mobile is open and willing to discuss with ELEPHANT TALK the provision to ELEPHANT TALK of new
services, meaning services out of the scope of this Agreement, in the Dutch market.

3.5 Parties agree that ELEPHANT TALK, if applicable, makes a feature available in the SIM card to
display the brand name of ELEPHANT TALK Customers, when ELEPHANT TALK Customers are connected - via
the ELEPHANT TALK Infrastructure - to the T-Mobile Network. T-Mobile is aware of the fact that
out-dated devices might not support this feature available in the SIM cards.

3.6 Parties agree to implement the rules and procedures pursuant to Dutch legislation for number
portability prior to the Ready for Service Date, according to Appendix 1. A ELEPHANT TALK MSISDN
that is out-ported from ELEPHANT TALK's customer base will be barred from accessing the ELEPHANT
TALK Services in the T-Mobile Network.

3.7 Parties shall use their best efforts to ensure *** as set out in Appendix 1. ELEPHANT TALK is
responsible and liable for ***, as described in Appendix 11.

Source: PARETEUM CORP, 8-K, 10/1/2008

CONFIDENTIAL TREATMENT REQUESTED WITH RESPECT TO CERTAIN PORTIONS HEREOF DENOTED WITH "***" Hosting
Agreement between ELEPHANT TALK and T-Mobile, 18/9/2008
<!-- page 13 -->
3.8 T-Mobile shall support ELEPHANT TALK in fulfilling its legal obligations under Dutch law with
respect to lawful interception under the terms and conditions as set forth in detail in Appendix 5.
ELEPHANT TALK agrees to inform in writing, before the Ready for Service Date, the relevant Dutch
authority (which is at the time of closing of this Agreement the public prosecutor) that T-Mobile
will carry out the lawful intercept requests regarding ELEPHANT TALK Customers and that T-Mobile
will and is entitled to collect the financial compensation of the concerning authority for these
legal intercept activities on behalf of ELEPHANT TALK. ELEPHANT TALK shall provide T-Mobile with a
copy of the aforementioned letter to the relevant Dutch authority before the Ready for Service Date.
4. IMPLEMENTATION

4.1 The Parties shall implement the Hosting Services according to the Implementation Plan, as
described in Appendix 3.

4.2 The Parties shall provide each other with information on preparations made and other details
relevant to the implementation of the Hosting Services.

4.3 If it becomes known to a Party that either a delay shall occur or is likely to occur, such Party
shall immediately notify the other Party thereof in writing. In such case, the reason for the delay
shall be given as well as the moment when it is anticipated that the implementation can take place.

4.4 ***. T-Mobile shall resolve every critical part of the Hosting Service as soon as reasonable
possible and in any event before the date which is *** after the agreed ***. Once the Hosting
Service and every critical part, as *** the PoD, thereof has successfully passed the *** pursuant to
the procedures described in the PoD and Appendix 3 the Service shall be accepted by ELEPHANT TALK
and ELEPHANT TALK shall sign the Protocol of Delivery acknowledging such acceptance.

4.5 Subject to article 4.4., ELEPHANT TALK shall commence the Soft Launch on or after the ***. From
the *** ELEPHANT TALK shall be permitted to (technically) test the Hosting Services for the duration
of five (5) calendar weeks, with a limited number of users (***). The traffic generated during the
Soft Launch shall be free of charge for up to *** - based on the tariffs T-Mobile will charge
ELEPHANT TALK according to Appendix 2. For all other users and costs above the ***,- per user,
ELEPHANT TALK has to pay the fees for the Hosting Services as defined in Appendix 2. The Soft Launch
is not part of the forecasts pursuant to Appendix 4. ELEPHANT TALK will finalize the Soft Launch by
signing the Protocol of Delivery, according to Appendix 3 and 11.

Source: PARETEUM CORP, 8-K, 10/1/2008

CONFIDENTIAL TREATMENT REQUESTED WITH RESPECT TO CERTAIN PORTIONS HEREOF DENOTED WITH "***" Hosting
Agreement between ELEPHANT TALK and T-Mobile, 18/9/2008
<!-- page 14 -->
4.6 If it would become applicable, ELEPHANT TALK shall obtain any regulatory approvals, consents, or
decisions which allow ELEPHANT TALK to utilize the Hosting Services from T-Mobile to provide the
ELEPHANT TALK Services to ELEPHANT TALK Customers as contemplated by this Agreement. T-Mobile agrees
- but is not obliged - to reasonably assist ELEPHANT TALK in obtaining such regulatory approvals,
consents or decisions, especially by making available to ELEPHANT TALK necessary documents,
technical specifications and other information required and by cooperating through common
communication to any regulatory authorities. 5. FORECASTS & COMMITMENTS

5.1 A trial period, covering the *** calendar months from Commercial Launch Date shall apply for
ELEPHANT TALK in order to gain experiences and knowledge for ELEPHANT TALK on forecasting and call
behavior of its ELEPHANT TALK Customers. ***.

5.2 ELEPHANT TALK shall provide Quarterly forecasts in writing expressed in volume for the use of
the Hosting Services. Details as Parties have agreed upon regarding the forecasts are stipulated in
Appendix 4.

5.3 ***.

5.4 ELEPHANT TALK accepts that T-Mobile will not be bound to the service level agreed between
Parties pursuant to article 6 of this Agreement in relation to the relevant Quarter, if the ***.

5.5 In case of (promotional) actions and events that will or might temporarily exceed the forecasted
traffic volume, ELEPHANT TALK shall inform T-Mobile as soon as possible, after which T-Mobile shall
make reasonable efforts to take appropriate and business wise feasible measures to prevent network
interruptions. 6. SERVICE LEVEL

6.1 The Hosting Services shall be provided in accordance with the level of service and support as
the Parties have agreed upon in Appendix 6.

6.2 At no point in time shall one of the Parties carry out service or support on equipment,
excluding SIM cards ordered according to article 16, that belongs to the other Party or is provided
or maintained by the other Party, unless the other Party has agreed in writing to such measures in
advance.

Source: PARETEUM CORP, 8-K, 10/1/2008

CONFIDENTIAL TREATMENT REQUESTED WITH RESPECT TO CERTAIN PORTIONS HEREOF DENOTED WITH "***" Hosting
Agreement between ELEPHANT TALK and T-Mobile, 18/9/2008
<!-- page 15 -->
6.3 T-Mobile shall give prior notice to ELEPHANT TALK about planned outages and planned work as
agreed in Appendix 6. 7. DATA PROTECTION & PRIVACY

7.1 All rights to the personal and traffic data related to ELEPHANT TALK Customers which ELEPHANT
TALK places at the disposal of T- Mobile, as well as to the results of the T-Mobile registering and
processing of this data, shall rest in ELEPHANT TALK. T-Mobile shall have at its disposal data
covered by the Agreement only to the extent and as long as necessary for T-Mobile to fulfill its
obligations pursuant to this Agreement.

7.2 Both Parties confirm that they shall comply with the Data Privacy regulations and laws
applicable in the Netherlands and internationally, including the Dutch Data Protection Act ("Wet
Bescherming Persoonsgegevens"), as amended or varied from time to time. T-Mobile undertakes to
process personal data only for the purpose of this Agreement.

7.3 ***. T-Mobile will refrain from using any ELEPHANT TALK Customer related data for any other
purpose than providing the Hosting Services to ELEPHANT TALK, with the exception of: · legal tapping
requirements in accordance with a request from the relevant public body; and · necessary use for the
purposes of preventing, tracing and fighting fraud or irregularities; and · other activities
required by law.

8. THE CO-OPERATION RELATIONSHIP 8.1 The authorized members of each Party shall fully co-operate in
the performance of the Agreement. The account manager of each Party shall act as the first point of
contact in relation to any issues provided for in the Agreement. Each Party may change its contact
person at any time by informing the other Party in writing.

8.2 The Parties shall promptly inform each other of a breakdown in their respective systems or
mobile telecommunications Network that has or might have an effect on the Hosting Services and/or
the Agreement. 8.3 ***

Source: PARETEUM CORP, 8-K, 10/1/2008

CONFIDENTIAL TREATMENT REQUESTED WITH RESPECT TO CERTAIN PORTIONS HEREOF DENOTED WITH "***" Hosting
Agreement between ELEPHANT TALK and T-Mobile, 18/9/2008
<!-- page 16 -->
9. PRICES, CHARGING, BILLING AND ACCOUNTING 9.1 Development costs & prices for Hosting Services

9.1.1 Subject to the terms of this Agreement, ELEPHANT TALK shall pay T-Mobile the total amount of
*** -as specified in Appendix 2, as a contribution for upfront (network related) developments costs
of the Hosting Services, including *** services, as described in Appendix 1. Payments shall be made
in accordance with article 9.2.

9.1.2 The prices to be paid by ELEPHANT TALK to T-Mobile for the Hosting Services rendered are
stated in Appendix 2. Such prices may be amended in accordance with the terms of this Agreement and
Appendix 2 and shall be paid by ELEPHANT TALK to T-Mobile in accordance with article 9.2.

9.1.3 If the prices due to subsequent changes in Dutch laws and regulations become invalid or
unenforceable the prices shall be modified to the extent required in order to be in conformity with
such laws and regulations. In the event that such change of prices reasonably requires that Parties
revise the applicable price structure of the Hosting Services in its entirety, Parties shall enter
into good faith negotiations to agree upon new prices. 9.2 Charging 9.2.1 T-Mobile has charged the
first installment of *** to ELEPHANT TALK with regard to ELEPHANT TALK's contribution for upfront
(network related) developments costs, as mentioned in article 9.1.1, after signing of the Heads of
Agreement between the Parties dated ***. The second installment of *** shall be charged to ELEPHANT
TALK right after signing of the Agreement and shall be paid by ELEPHANT TALK within fifteen (15)
Calendar Days of the invoice date.

9.2.2 Whenever an ELEPHANT TALK Customer uses the ELEPHANT TALK Wholesale Services, ELEPHANT TALK
shall be fully responsible for timely payment of the appropriate price(s) established under article
9.1.2 for the Hosting Services used. ELEPHANT TALK shall pay to T-Mobile the charges for the Hosting
Services as from the Ready for Service Date, including the charges mentioned under article 4.5.

9.2.3 In addition to the invoice mentioned under article 9.2.1., T-Mobile shall on a monthly arrear
basis submit invoices to ELEPHANT TALK detailing the prices payable by ELEPHANT TALK under article
9.2.2. T-Mobile will send the following invoices for: a) network hosting services***; a) costs of
authorized lawful intercept (to the extent provided for under Appendix 5); b) costs for other
services agreed upon.

Source: PARETEUM CORP, 8-K, 10/1/2008

CONFIDENTIAL TREATMENT REQUESTED WITH RESPECT TO CERTAIN PORTIONS HEREOF DENOTED WITH "***" Hosting
Agreement between ELEPHANT TALK and T-Mobile, 18/9/2008
<!-- page 17 -->
9.2.4 ELEPHANT TALK shall pay all invoices no later than *** after the invoice date. ELEPHANT TALK
***, in the event that ELEPHANT TALK fails to meet ***

9.2.5 ***

9.2.6 Invoices submitted to ELEPHANT TALK by T-Mobile shall be itemized in accordance with Dutch
acknowledged principles of billing and accounting.

9.2.7 All charges under this Agreement are exclusive of value-added tax (VAT), duties or levies
imposed by any authority, government or governmental agency and any other applicable taxes payable
in relation to the Hosting Services supplied to ELEPHANT TALK. Any taxes shall be charged in
accordance with the relevant regulations in force at the time of making the taxable supply to
ELEPHANT TALK and shall be paid by ELEPHANT TALK. All amounts and any payment of charges under this
Agreement shall be made in EUROS and in full without any set-off, deductions or withholding
whatsoever.

9.2.8 Invoices not paid within the time limit set down in article 9.2.4 shall bear interest
("enkelvoudig") on a daily basis at the rate of the legal commercial interest rate ("wettelijke
handelsrente") plus 1 % until full payment is received by T-Mobile whether before or after judgment.
Interest shall continue to accrue notwithstanding termination or expiry of this Agreement for any
cause whatsoever.

9.2.9 ELEPHANT TALK may object to any invoice according to the procedure set out in article 4 of
Appendix 7, Accounting and Billing. In the event of invoicing irregularities, Parties shall use
their best efforts to establish the reason for and to eliminate such irregularities as quickly as
possible. 9.2.10 ELEPHANT TALK will be accountable for and shall pay all generated traffic by
ELEPHANT TALK Customers -including traffic generated via stolen or lost SIM cards - to T-Mobile .
9.2.11 ELEPHANT TALK bears the risk of and shall indemnify T-Mobile against high usage, fraud and
bed debts/non-payment of its ELEPHANT TALK Customers. 9.3 Billing and Accounting 9.3.1 Procedures
for billing and accounting information are provided in Appendix 7.

Source: PARETEUM CORP, 8-K, 10/1/2008

CONFIDENTIAL TREATMENT REQUESTED WITH RESPECT TO CERTAIN PORTIONS HEREOF DENOTED WITH "***" Hosting
Agreement between ELEPHANT TALK and T-Mobile, 18/9/2008
<!-- page 18 -->
9.3.2 In order to exchange invoice information, TAP files will be transferred by T-Mobile to
ELEPHANT TALK, as stated in Appendix 7.

9.3.3 For verification purposes T-Mobile will keep the CDRs in accordance with Dutch legislation.
9.4 Financial security

9.4.1. ***

***: a. ELEPHANT TALK has been declared bankrupt or has applied for bankruptcy according to 18.1 sub
g, or; b. ELEPHANT TALK *** ***.

9.4.2. T-Mobile shall not require financial security as set out in 9.4.1as long as the '***

T-Mobile customers using *** will ***. For *** ELEPHANT TALK will issue an invoice to T-Mobile.
Parties agree that as long as: · *** ; and · the invoice for these *** delivery of the Hosting
Services by T-Mobile according to this Agreement, article 9.4.1. shall not apply. In the event that
ELEPHANT TALK does not comply with the payment terms as set out in article 9.2.4., Parties agree
that T-Mobile is entitled *** ELEPHANT TALK following the '*** with the amounts which ELEPHANT TALK
( or any of its Affiliates) is due to T-Mobile according to this Agreement.

9.4.3. As soon as article 9.4.2. does no longer apply - ***. 10. CUSTOMER CARE SUPPORT

Source: PARETEUM CORP, 8-K, 10/1/2008

CONFIDENTIAL TREATMENT REQUESTED WITH RESPECT TO CERTAIN PORTIONS HEREOF DENOTED WITH "***" Hosting
Agreement between ELEPHANT TALK and T-Mobile, 18/9/2008
<!-- page 19 -->
10.1 ELEPHANT TALK shall for its own account and at its own cost maintain a customer support
organization for ELEPHANT TALK Customers. In addition, T-Mobile shall provide second line customer
care support to the back office of ELEPHANT TALK's customer support organization, according to
Appendix 1, 2 and 6. 10.2 For the avoidance of doubt, it is stated that Parties agree that T-Mobile
shall not provide customer support services to ELEPHANT TALK Customers (meaning end-users of
ELEPHANT TALK Customers) directly. 11. CONFIDENTIALITY

11.1 The Parties agree that all aspects of the content of this Agreement shall be treated as
confidential and that no information in respect of the content and/or existence of this Agreement
shall be disclosed without the prior written consent of both Parties. Neither Party shall make any
public announcements, including but not limited to press releases, articles, brochures,
advertisements and speeches, concerning this Agreement without the prior written consent of the
other Party. However, ELEPHANT TALK is entitled to communicate - as far as strictly necessary for
the proper conclusion of its agreements- to the ELEPHANT TALK Customer that its services are
provided by (the) T-Mobile (network). ELEPHANT TALK Customers shall be entitled to communicate that
the network coverage is provided by T-Mobile, only in case they are asked for it. Under no
circumstances, ELEPHANT TALK Customers shall make any public announcements, including but not
limited to press releases, commercial articles (not being technical or business articles),
brochures, advertisements, public speeches and other promotional material, that its services to
mobile end-users are provided by the T-Mobile network. Parties are aware of the fact that it might
be impossible for technical reasons to make a reference to the ELEPHANT TALK (Customer) brand name
on the display of devices and that the T-Mobile brand name may appear. ELEPHANT TALK shall do the
utmost to ensure that the communication to mobile telecommunication end-users- including the
communication of ELEPHANT TALK Customers - shall be in accordance with this article.

11.2 The Parties hereby agree to treat all information exchanged between them (hereinafter referred
to as "Confidential Information") whether for the purposes of this Agreement or not as confidential
and agree not to disclose such Confidential Information in any manner whatsoever in whole or in part
except as provided for in the article 11.4. The Parties may disclose Confidential Information only
to employees, attorneys at law and accountants or other professional advisers who need to know such
Confidential Information for the purposes of participation in the discussions connected with this
Agreement between the Parties and any transaction resulting there from and who are informed of and
bound to the confidential nature of such Confidential Information.

11.3 Notwithstanding the above, in the event that the receiving Party or (to the receiving Party's
knowledge) anyone to whom the Confidential Information has been supplied to by the receiving Party
receives a request to disclose under the terms of a subpoena, order, civil investigative demand or
similar process issued by a court of competent jurisdiction or by a governmental body all or any
part of the Confidential Information, such receiving Party agrees to:

Source: PARETEUM CORP, 8-K, 10/1/2008

CONFIDENTIAL TREATMENT REQUESTED WITH RESPECT TO CERTAIN PORTIONS HEREOF DENOTED WITH "***" Hosting
Agreement between ELEPHANT TALK and T-Mobile, 18/9/2008
<!-- page 20 -->
i. notify the disclosing Party promptly in writing of the existence, terms, and circumstances
surrounding such request; ii. consult with the disclosing Party on the advisability of taking
legally available steps to resist or narrow such request; iii. give the disclosing Party the
opportunity to defend, limit or protect against such disclosure; iv. if disclosure of such
information is lawfully required, furnish only that portion of the Confidential Information which is
legally necessary or appropriate in the light of all the circumstances and seek to obtain
confidential treatment for any information required to be disclosed.

11.4 For the purposes of this Agreement, Confidential Information shall not be considered to be
confidential if such Confidential Information is: a) in or passed into the public domain other than
by breach of this Agreement; or b) known to the receiving Party prior to the disclosure by the
disclosing Party without any obligation of confidentiality; or c) disclosed to a receiving Party
without restriction by a third party having the full right to disclose; or d) independently
developed by a receiving Party to whom no disclosure of Confidential Information relevant to the
development of such Confidential Information has been made.

11.5 This article 11 shall survive the termination of this Agreement as provided for in articles 17
and 18 for a period of two (2) years but shall not in any way limit or restrict either Party's use
of its own Confidential Information. 12. LIMITATION OF LIABILITY

12.1 Without prejudice to the provisions expressly stated elsewhere in this Agreement, a Party's
liability for damage suffered by the other Party, attributable to the first mentioned Party or a
person for whom it is liable by law, shall be limited to the following events, and the following
amounts: a) for direct damage to physical goods (property damage or "zaakschade") or directly
resulting from death or personal injury: up to a maximum of *** per event or series of connected
events and up to a further maximum of *** for all events (connected or not) in any period of 12
calendar months; b) for damage directly resulting from a material breach of this Agreement: up to a
maximum *** or *** as set out in Appendix 2), whatever amount is the highest, in any period of 12
calendar months.

Source: PARETEUM CORP, 8-K, 10/1/2008

CONFIDENTIAL TREATMENT REQUESTED WITH RESPECT TO CERTAIN PORTIONS HEREOF DENOTED WITH "***" Hosting
Agreement between ELEPHANT TALK and T-Mobile, 18/9/2008
<!-- page 21 -->
12.2 In no event shall either Party be liable for indirect or consequential loss or damage,
including but not limited to, loss of profit, loss of sales or turnover, loss of or damage to
reputation, loss of contract, loss of business, loss of anticipated savings and interest, increased
operation costs, increase maintenance costs even if such loss or damage was reasonably foreseeable
or if a Party had been advised by the other Party of the possibility of incurring such loss or
damage. 12.3 In no event shall any employee of either Party or of an Affiliated Company be liable to
the other Party for any act of negligence or intent under or in connection with this Agreement. Save
for the limitations in articles 12.1 and 12.2 nothing in the foregoing shall in any way restrict the
liability of either Party for the actions of its employees.

12.4 Limitation of liability as described in this article shall not apply: a) in case the damage or
loss is caused by a Party's willful misconduct (including fraud) or gross negligence, or b) in case
of a breach of a Parties obligation under article 11 (confidentiality) and article 15
(indemnification for breach of intellectual property rights). 12.5 Any claim for damages must be
notified to the other Party within six (6) months as from the date on which the damage was caused,
failing which such claim is deemed to be waived. 12.6 ELEPHANT TALK will be fully responsible for
the settlement of, and shall indemnify ("vrijwaren") T-Mobile against any claims made by ELEPHANT
TALK Customers or third parties with whom ELEPHANT TALK has a (contractual) relationship and which
claims are related to this (contractual) relationship 13. SUSPENSION AND TERMINATION OF HOSTING
SERVICES

13.1 Notwithstanding anything stipulated in the Agreement, T-Mobile may without liability suspend or
terminate whole or part of the Hosting Services in relation to one or more ELEPHANT TALK Customers,
in circumstances where T-Mobile would suspend or terminate those services to its own customers, in
the following circumstances - or circumstances of similar severity. a) ***; b) ***; or c) suspected
fraudulent or unauthorized use by the relevant ***; or d) necessary maintenance or enhancement of
the T-Mobile Network. In the event of planned suspension or termination of all or any of the Hosting
Services, T-Mobile shall inform ELEPHANT TALK accordingly by sending a written notification, as soon
as reasonably and business wise possible.

13.2 Furthermore, T-Mobile may without liability temporarily suspend all or any of its Hosting
Services to ELEPHANT TALK if a (partial or temporary) breakdown on the T-Mobile Network should
occur. Such temporarily suspension shall - to the extent possible - be limited to the Location Areas
where the temporarily breakdown occurs. Immediately after the T-Mobile Network has been restored,
T-Mobile shall take all appropriate measures in order to re-establish the Hosting Services with the
shortest possible delay, in accordance with the procedures as described in Appendix 6.

Source: PARETEUM CORP, 8-K, 10/1/2008

CONFIDENTIAL TREATMENT REQUESTED WITH RESPECT TO CERTAIN PORTIONS HEREOF DENOTED WITH "***" Hosting
Agreement between ELEPHANT TALK and T-Mobile, 18/9/2008
<!-- page 22 -->
13.3 T-Mobile may without liability limit at its own discretion the availability of all or any of
the Hosting Services above the level of the traffic forecasts of Hosting Services as defined in
article 5 and Appendix 4, provided that the provision of these Hosting Services -above the level of
the traffic forecasts - to ELEPHANT TALK have a noticeable negative impact on the quality of the
T-Mobile Network and on the provision of services to T-Mobile customers. 14. FORCE MAJEURE

14.1 Non-performance by either Party of its obligations pursuant to this Agreement or delay in
performing the same shall not constitute a breach of the Agreement if and for as long as it is due
to a force majeure event, including, but not limited to, government action or requirement of
regulatory authority, lock-outs, strikes, shortage of transportation, war, terrorist attacks,
rebellion or other military action, fire, floods, natural catastrophes, that a Party is not able to
overcome with reasonable and proportional efforts, or a non-performance of obligations by a
sub-contractor to a Party - in circumstances where it is reasonably impossible for that Party or an
other sub-contractor to perform such obligation instead -, pursuant to any of the aforementioned
reasons.

14.2 The Party prevented from fulfilling its obligations shall on becoming aware of such event
inform the other Party in writing of such force majeure event as soon as possible. If the affected
Party fails to inform the other Party of the occurrence of a force majeure event as set out in
article 14.1 above, then such Party thereafter shall not be entitled to refer such events to force
majeure as a reason for non-fulfillment. This obligation does not apply if the force majeure event
is known by both Parties or the affected Party is unable to inform the other Party due to the force
majeure event.

14.3 If the force majeure event continues for more than two (2) consecutive calendar weeks, then the
Parties shall promptly meet and discuss methods to resolve the difficulties arising from the event
of force majeure. If no agreement is reached by the Parties within a period of fifteen(15) Calendar
Days and the force majeure event continues to have a substantial effect on the performance of the
Agreement, either Party shall have the right to terminate this Agreement in whole or in part with
immediate effect by written notice without incurring any financial liability to the other Party as a
consequence of such termination.

Source: PARETEUM CORP, 8-K, 10/1/2008

CONFIDENTIAL TREATMENT REQUESTED WITH RESPECT TO CERTAIN PORTIONS HEREOF DENOTED WITH "***" Hosting
Agreement between ELEPHANT TALK and T-Mobile, 18/9/2008

15. INTELLECTUAL PROPERTY RIGHTS
<!-- page 23 -->
15.1 This Agreement does not imply any transfer of intellectual property right. Neither Party shall
use the other Party's name, trademarks, service marks or other intellectual property rights without
the other Party's prior written consent. ELEPHANT TALK shall guarantee that in any agreement it
concludes with ELEPHANT TALK Customers the following provision will be included: 'In no
circumstances, [X] shall use T-Mobile's name, trademarks, service marks or other intellectual
property rights in public announcements, including but not limited to press releases, commercial
articles (not being technical or business articles), brochures, advertisements public speeches and
other promotional material.'

15.2 ELEPHANT TALK is allowed to market and sell its services to ELEPHANT TALK Customers under a
brand name chosen by ELEPHANT TALK. However, ELEPHANT TALK shall not use any logos, names or other
material that bears, is similar or refers to any intellectual property right of T-Mobile or T-Mobile
competitors (meaning mobile network operators, mobile virtual network operators and enhanced service
providers in The Netherlands) without prior written approval of T-Mobile.

15.3 When marketing its ELEPHANT TALK Wholesale Services in The Netherlands, ELEPHANT TALK shall
refrain from using comparative advertising, in any form of media, in relation to T-Mobile's,
including its Affiliate's, products and/or services.

15.4 ELEPHANT TALK will defend, indemnify and will hold T-Mobile harmless from and against any claim
and costs assessed against T- Mobile by a third party alleging that the ELEPHANT TALK Wholesale
Services, constitute an infringement of any third party's intellectual property rights in
circumstances where the alleged infringement is attributable to ELEPHANT TALK and in no way the
fault of T-Mobile or its Affiliated Company. If such a claim is valid, ELEPHANT TALK shall make the
modifications needed to cease the infringement at its own expense as soon as possible. Such
modifications will not have any impact on the functionality and costs of the provided Hosting
Services. ELEPHANT TALK shall inform T-Mobile on any of such modifications as soon as possible. 15.5
T-Mobile shall retain all right, title and interest in and to the Hosting Services, including all
intellectual property rights therein and any modifications or enhancements thereof. 15.6 T-Mobile
hereby grants ELEPHANT TALK a fully paid-up, non-exclusive licence to use the Hosting Services for
the purpose of ELEPHANT TALK in providing the ELEPHANT TALK Wholesale Services during the term of
this Agreement without further consideration. This licence granted shall take effect on the date
that the relevant Hosting Services is first used by or on behalf of ELEPHANT TALK to provide the
ELEPHANT TALK Wholesale Services under this Agreement. 16. SIM CARDS & CALLING CREDIT

Source: PARETEUM CORP, 8-K, 10/1/2008

CONFIDENTIAL TREATMENT REQUESTED WITH RESPECT TO CERTAIN PORTIONS HEREOF DENOTED WITH "***" Hosting
Agreement between ELEPHANT TALK and T-Mobile, 18/9/2008
<!-- page 24 -->
16.1 ELEPHANT TALK shall order and purchase SIM cards.

16.2 In principle the *** will be of *** will remain the property of T-Mobile at all times.

16.3 T-Mobile shall retain at all times full ownership of its intellectual property rights vested in
the software (including T-Moible's and its supplier related software and codes, but excluding
typical ELEPHANT TALK's and/or other party's content) contained in the T-Mobile IMSI's. 16.4 Parties
agree that they will re-discuss the provisioning of a ***, the implementation and associated costs
of the *** shall be considered part of the Agreement and therefore shall not result in additional
costs for ELEPHANT TALK provided that no *** are involved. ELEPHANT TALK shall retain at all times
full ownership of its intellectual property rights vested in the software contained in the ***. .

16.5 T-Mobile has a strict policy with respect to the usage of *** (also known as "*** ") and any
other devices that ***"). These *** are under no circumstances allowed on the T-Mobile Network.
ELEPHANT TALK is aware of T-Mobile's position with respect to these *** and will refrain from using
*** or from doing business with any party (including ELEPHANT TALK's Customers), who uses these ***
to the T-Mobile Network. Furthermore, duplicating the *** or functionalities of the *** without the
explicit prior written approval of T- Mobile is forbidden. ELEPHANT TALK will (contractually) inform
the ELEPHANT TALK Customers that they will refrain from using *** or ***. T-Mobile herewith gives
ELEPHANT TALK approval to *** once, only for the purpose of supplying *** as commonly known in the
market at the moment of signing the Agreement, to ELEPHANT TALK Customers, only to be used by end
users of ELEPHANT TALK Customers for normal end user purposes. Parties shall use their reasonable
endeavors to co-operate in order to prevent and clarify any misuse of *** or use of ***. In the
event that T-Mobile discovers such improper use or forbidden acts of ELEPHANT TALK Customers,
Parties shall contact each other's fraud manager immediately, in order to stipulate details and take
appropriate measures. In addition, ELEPHANT TALK shall do its best to stop these actions immediately
on first request of T-Mobile. Should ELEPHANT TALK wilfully or negligently fail to comply with an
T-Mobile request, ELEPHANT TALK shall bear full responsibility and indemnify T- Mobile for all
damages and losses T-Mobile suffers resulting from actions as mentioned in this article by ELEPHANT
TALK's Customers. 17. DURATION OF THE AGREEMENT 17.1 This Agreement shall come into force on the
Date of the Agreement, and shall, subject to article 18, remain in full force and effect for an
initial period of *** from the Commercial Launch Date.

17.2 The Agreement may be terminated by both Parties with a notification period of *** before the
end of the Initial Term of the Agreement. If no termination notice is provided, the Agreement will
be automatically extended for consecutive *** periods until such time as *** termination notice is
provided. At the end of *** Parties will negotiate in good faith regarding a possible extension of
the Initial Term.

Parties can mutually agree in writing to deviate from an automatic extension of *** by extending
this Agreement for a longer period than ***.

Source: PARETEUM CORP, 8-K, 10/1/2008

CONFIDENTIAL TREATMENT REQUESTED WITH RESPECT TO CERTAIN PORTIONS HEREOF DENOTED WITH "***" Hosting
Agreement between ELEPHANT TALK and T-Mobile, 18/9/2008
<!-- page 25 -->
18. TERMINATION OF AGREEMENT

18.1 In addition to the conditions of Article 17, this Agreement may be terminated as follows:

a. by mutual agreement of the Parties; or

b. by either Party, with immediate effect, if the other Party is in material breach of any provision
of this Agreement and does not or is not capable of remedying such breach within a reasonable time
and in any event within sixty (60) Business Days of receipt of a written notice to such effect. A
material breach will, for the purpose of this Agreement, not include the event that ELEPHANT TALK
fails to comply with its payments obligations under article 9.2.; or

c. by T-Mobile, if ELEPHANT TALK fails to comply with its obligations under article 16.5 upon
written notification thereof by T-Mobile, within a reasonable period of time following the
respective notification date (but in no event later than forty-five (45) Business Days of receipt of
a written notice to such effect); or,

d. by T-Mobile, subject to *** . In the present situation ***; or

e. by T-Mobile or its successors, ***.; or,

f. by ELEPHANT TALK, subject to *** and this entity is at the time of signing of ***; or

g.. by either Party, with immediate effect, if the other Party becomes bankrupt or insolvent (or
bankruptcy or insolvency is appropriately requested for) or is liquidated or dissolved other than
for the purpose of a bona fide reconstruction or amalgamation, or if that other Party enters into
any composition or arrangements with its creditors; or,

Source: PARETEUM CORP, 8-K, 10/1/2008

CONFIDENTIAL TREATMENT REQUESTED WITH RESPECT TO CERTAIN PORTIONS HEREOF DENOTED WITH "***" Hosting
Agreement between ELEPHANT TALK and T-Mobile, 18/9/2008
<!-- page 26 -->
18.2 In case the number of frequencies or the use of the frequencies allocated to the T-Mobile
Network is reduced pursuant to Regulatory Provisions the Parties shall renegotiate in good faith the
commercial conditions of this Agreement in order to comply with Regulatory Provisions. 18.3 In the
event that T-Mobile is in material breach and ELEPHANT TALK terminates the Agreement according to
article 18.1.b, ***.

18.4 This Agreement will terminate immediately in the event that a final order made by the relevant
governmental authority not granting, revoking or denying renewal of T-Mobile DCS 1800 or UMTS/HSDPA
license or permission to operate the T-Mobile Network or any other license to operate the Hosting
Services, takes effect, if such order will be beyond the reasonable control of T-Mobile. 19.
MODIFICATIONS

19.1 Any modifications and/or additions to this Agreement and/or the Appendices shall be valid only
if made in writing and signed by duly authorized representatives of both Parties.

19.2 If a Party requests a modification of this Agreement because (a) a material change occurs in
the laws and regulations governing telecommunications in the Netherlands, or (b) a material change
(including enforcement action by any regulatory authority) occurs which affects or reasonably could
affect the commercial and technical basis of this Agreement, Parties shall enter into good faith
negotiations in order to determine if a modification of the Agreement is necessary and if so agree
upon the way to implement the required changes in or modifications to this Agreement.

19.3 Parties agree that the Operational Manual can only be modified by T-Mobile's account manager
upon consultation with ELEPHANT TALK's authorized account manager and with the subsequent written
agreement of ELEPHANT TALK and T-Mobile. 20. MISCELLANEOUS 20.1 Successors, Assigns This Agreement
and the rights and obligations specified herein shall be binding upon the Parties and their
respective legal successors and neither Party shall sell, transfer or assign this Agreement or any
part, interest, right or obligation hereunder except that a Party shall have the right to transfer
or assign this Agreement in whole (but not in part) to an Affiliated Company provided that:

Source: PARETEUM CORP, 8-K, 10/1/2008

CONFIDENTIAL TREATMENT REQUESTED WITH RESPECT TO CERTAIN PORTIONS HEREOF DENOTED WITH "***" Hosting
Agreement between ELEPHANT TALK and T-Mobile, 18/9/2008
<!-- page 27 -->
a) such Affiliated Company expressly assumes, by written instrument, all of the obligations of the
Party under this Agreement and thereby becomes a Party to this Agreement, and b) such Affiliated
Company has adequate financial strength, resources and experience in the reasonable opinion of the
other Party (such opinion to be obtained in writing in advance of any assignment), to comply with
its obligations under this Agreement. Such assignment shall not release the assigning Party of its
obligations under article 11 of this Agreement.

No person other than a Party to this Agreement shall acquire any rights hereunder as a third-Party
beneficiary or otherwise by virtue of this Agreement.

Both Parties will remain independent and competing companies, will develop their own market
strategy, and will address the market and the subscribers directly and independently. 20.2 No Waiver
Failure by any Party at any time to require performance of any provisions of this Agreement shall in
no manner affect its rights to enforce the same, and the waiver by any Party of any breach of any
provision of this Agreement shall not be construed to be a waiver by such Party of any succeeding
breach of such provision or waiver by such Party of any breach of any other provision hereof. 20.3
Severability If any part of this Agreement or any Appendices hereto is held to be invalid or
unenforceable according to Regulatory Provisions, this shall not invalidate any other provisions of
this Agreement or the Appendices hereto. The Parties shall attempt through negotiations in good
faith to replace any such provision of this Agreement or the Appendices so held to be invalid or
unenforceable with a valid provision which comes as close to the original economic understanding and
intention of the Parties as legally feasible. The same applies insofar as this Agreement and/or its
Appendices prove to have a gap. In this case, the Parties shall endeavor to close the gap through
negotiations conducted in good faith. 20.4 Entire Agreement 20.4.1 This Agreement and the documents
referred to in it contain the whole Agreement between the Parties relating to the subject matter of
this Agreement and supersede all previous agreements and understandings whether written or oral
between the Parties. 20.4.2 Each Party acknowledges that in entering into this Agreement it shall
not rely on any representation, warranty or other assurance except as set out in this Agreement.

Source: PARETEUM CORP, 8-K, 10/1/2008

CONFIDENTIAL TREATMENT REQUESTED WITH RESPECT TO CERTAIN PORTIONS HEREOF DENOTED WITH "***" Hosting
Agreement between ELEPHANT TALK and T-Mobile, 18/9/2008
<!-- page 28 -->
20.5 Non-solicitation Without the prior written consent of the other Party, a Party shall not at any
time while this Agreement is in force and for a one-year period after termination of this Agreement
either for itself or on behalf of any other company solicit, induce or cause any employee of the
other Party or any Affiliated Company of this other Party who has been a representative of or
employed by the other Party in connection with this Agreement to leave such employment. In case of
violation of this article, the Party shall pay to the other Party an equivalent of eighteen (18)
months gross salary of the respective employee.

20.6 Survival Any provision of this Agreement which by its nature or implication (including in
respect of any accrued rights and liabilities) is required to survive termination or expiry of this
Agreement shall survive termination or expiry as aforesaid. 20.7 Notices Any notice or other formal
communication to be given or made under or in connection with this Agreement, if not stated
otherwise explicitly in this Agreement and its Appendices, shall be in writing, signed by or on
behalf of the Party giving it and sent by registered mail. All notice or other formal communication
to be delivered under this Agreement shall be addressed to: for ELEPHANT TALK: the CTO; for
T-Mobile: the Director Wholesale & Interconnect.

20.8 Expenses Each Party shall bear its own costs and expenses including the fees of its
professional advisors in relation to the preparation, execution and carrying into effect of this
Agreement and all other documents related to it.

20.9 Representation Neither Party may in any respect represent the other Party or enter into any
agreement or other commitment on behalf of the other Party except as provided for in this Agreement
or agreed by the Parties in writing.

The Agreement and conditions contained herein are only related to the Dutch market and can not be
referred to in discussions or deals with other T-Mobile companies and/or Deutsche Telecom and their
respective Affiliated Companies. Due to amongst others market and country difference, T-Mobile
expressly states and ELEPHANT TALK agrees that this Agreement cannot and will not create any
precedent for any existing or future discussions between ELEPHANT TALK and T-Mobile/Deutsche Telecom
and their Affiliated Companies outside the Netherlands;

Source: PARETEUM CORP, 8-K, 10/1/2008

CONFIDENTIAL TREATMENT REQUESTED WITH RESPECT TO CERTAIN PORTIONS HEREOF DENOTED WITH "***" Hosting
Agreement between ELEPHANT TALK and T-Mobile, 18/9/2008
<!-- page 29 -->
21. GOVERNING LAW This Agreement shall be governed by and construed in all respects exclusively in
accordance with the laws of the Netherlands. 22. DISPUTE RESOLUTION Any dispute, excluding invoice
disputes as described in Appendix 7, controversy or claim arising out of or in connection with any
aspect of this Agreement, or the breach, termination or invalidity thereof, shall:

a. in first instance be referred to the authorized account manager of either Party. The account
managers shall try to solve the dispute within ten (10) Business Days. If the dispute is not
resolved within the latter period the appropriate managers of both account managers will seek for a
resolution within ten (10) Business Days; and

b. Thereafter, if the matter is not resolved, it shall be referred to the Chief Executive Officers
of the Managing Boards of the Parties for a further period of ten (10) Business Days for resolution;
and

Thereafter, if the matter remains unresolved, it shall exclusively be referred and finally settled
by the competent court in The Hague within the jurisdiction of the Netherlands.

Source: PARETEUM CORP, 8-K, 10/1/2008

CONFIDENTIAL TREATMENT REQUESTED WITH RESPECT TO CERTAIN PORTIONS HEREOF DENOTED WITH "***" Hosting
Agreement between ELEPHANT TALK and T-Mobile, 18/9/2008
<!-- page 30 -->
23. COUNTERPART

The Agreement is written in the English language in two (2) copies, each Party receiving one (1)
duly signed copy. Both copies are authentic.

Signed in September 17, 2008

For T-Mobile Netherlands B.V. /s/ Niek Jan van Damme Name: Mr. Niek Jan van Damme Title: Managing
Director

For Elephant Talk Communication Holding AG /s/ Steven van der Velden Name: Mr. Steven van der Velden
Title: CEO

For T-Mobile Netherlands B.V. /s/ Hans van Leeuwen Name: Hans van Leeuwen Title: Financieel
Directeur

For Elephant Talk Communication Holding AG /s/ Martin Zuurbier Name: Mr. Martin Zuurbier Title:
CTO/COO

____________________________

Source: PARETEUM CORP, 8-K, 10/1/2008
