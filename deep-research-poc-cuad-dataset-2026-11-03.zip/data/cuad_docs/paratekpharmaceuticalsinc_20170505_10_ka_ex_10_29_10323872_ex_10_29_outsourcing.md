<!-- page 1 -->
# Outsourcing Agreement
| Field | Value |
|---|---|
| Document Type | Outsourcing Agreement |
| Agreement Date | 2016-12-30 |
| Parties | Paratek Pharmaceuticals, Inc. ("Customer"); CARBOGEN AMCIS AG (“Supplier” and, collectively with Customer, the “Parties”, and each, a “Party) |
| Source | CUAD v1 / ParatekPharmaceuticalsInc_20170505_10-KA_EX-10.29_10323872_EX-10.29_Outsourcing Agreement |

Exhibit 10.29

THIS EXHIBIT HAS BEEN REDACTED AND IS THE SUBJECT OF A CONFIDENTIAL TREATMENT REQUEST. REDACTED
MATERIAL IS MARKED WITH [* * *] AND HAS BEEN FILED SEPARATELY WITH THE SECURITIES AND EXCHANGE
COMMISSION.

Execution Version

Outsourcing Agreement

Between

Paratek Pharmaceuticals, Inc.

and

CARBOGEN AMCIS AG

Date

30 December 2016

Source: PARATEK PHARMACEUTICALS, INC., 10-K/A, 5/5/2017
<!-- page 2 -->
THIS EXHIBIT HAS BEEN REDACTED AND IS THE SUBJECT OF A CONFIDENTIAL TREATMENT REQUEST. REDACTED
MATERIAL IS MARKED WITH [* * *] AND HAS BEEN FILED SEPARATELY WITH THE SECURITIES AND EXCHANGE
COMMISSION. Table of Contents Article 1 Interpretation 7

1.1 Definitions 7

1.2 Other Definitions 11

1.3 Currency 11

1.4 Headings 11

1.5 Exhibits 11

1.6 Applicable Law 12

Article 2 Term 12

2.1 Term 12

2.2 Effect of Expiration on Purchase Orders 12

Article 3 Supply of Product 12

3.1 Supply of Product 12

3.2 Manufacturing Services 13

3.3 Supply of Materials and Customer Material 13

3.4 Production Capacity 15

3.5 Processing Changes 15

3.6 Monitoring of Facilities 16

3.7 Subcontracting 16

3.8 [* * *] 16

3.9 [* * *] 17

3.10 Territory Expansion 17

3.11 Supply to Customer Licensees 17

3.12 Alternative Supply 17

Article 4 Forecasts 18

4.1 Short Term Rolling Forecasts 18

4.2 Long Term Forecasts 18 CONFIDENTIAL Page 2 of 49

Source: PARATEK PHARMACEUTICALS, INC., 10-K/A, 5/5/2017

THIS EXHIBIT HAS BEEN REDACTED AND IS THE SUBJECT OF A CONFIDENTIAL TREATMENT REQUEST. REDACTED
MATERIAL IS MARKED WITH [* * *] AND HAS BEEN FILED SEPARATELY WITH THE SECURITIES AND EXCHANGE
COMMISSION. Article 5 Testing and Samples 19
<!-- page 3 -->
5.1 Release Testing 19

5.2 Additional Release Testing 19

5.3 Retention Samples 19

5.4 Stability Testing 20

5.5 Reference Standards 20

5.6 Preparation of Process Qualification 20

Article 6 Purchase Orders 20

6.1 Placement of Purchase Orders 20

6.2 Acceptance of Orders 20

6.3 Delays 21

6.4 Cancellation of Purchase Orders 21

6.5 Material Failure of Supply 21

6.6 Services 21

Article 7 Shipment of Product 22

7.1 Storage of Product 22

7.2 Release and Shipment of Product 22

7.3 Documentation 23

7.4 Steering Committee 23

Article 8 Acceptance of Shipments 23

8.1 Acceptance of Shipments 23

8.2 Dispute of Rejected Product 24

8.3 Remedies 24

Article 9 Fees 25

9.1 Fees 25

9.2 Adjustments to Fees 25

9.3 Taxes 26 CONFIDENTIAL Page 3 of 49

Source: PARATEK PHARMACEUTICALS, INC., 10-K/A, 5/5/2017

THIS EXHIBIT HAS BEEN REDACTED AND IS THE SUBJECT OF A CONFIDENTIAL TREATMENT REQUEST. REDACTED
MATERIAL IS MARKED WITH [* * *] AND HAS BEEN FILED SEPARATELY WITH THE SECURITIES AND EXCHANGE
COMMISSION.
<!-- page 4 -->
Article 10 Invoicing and Payment 26

10.1 Issuance of Invoices 26

10.2 Invoice Contents 26

10.3 Delay of Shipment 27

10.4 Payment of Invoices 27

Article 11 Intellectual Property 27

11.1 Title 27

11.2 No Grant of Rights 27

11.3 Grant of License by Customer 28

11.4 Ownership of Inventions 28

11.5 Patents to Inventions 28

11.6 No Use of Trademarks 28

11.7 [* * *] 28

Article 12 Confidentiality & Publicity 29

12.1 Obligation of Confidentiality 29

12.2 Disclosure with Consent 29

12.3 Publicity 29

12.4 Disclosure Required by Law 30

12.5 Employee Confidentiality and Invention Assignment 30

12.6 Duration of Obligation 30

Article 13 Representations, Warranties and Covenants 31

13.1 Supplier's Representations, Warranties and Covenants 31

13.2 Customer's Representations, Warranties and Covenants 32

13.3 No Other Warranty 32

13.4 No Consequential Damages and Limitation of Liability 33

Article 14 Indemnification 33

14.1 Indemnification of Supplier 33 CONFIDENTIAL Page 4 of 49

Source: PARATEK PHARMACEUTICALS, INC., 10-K/A, 5/5/2017

THIS EXHIBIT HAS BEEN REDACTED AND IS THE SUBJECT OF A CONFIDENTIAL TREATMENT REQUEST. REDACTED
MATERIAL IS MARKED WITH [* * *] AND HAS BEEN FILED SEPARATELY WITH THE SECURITIES AND EXCHANGE
COMMISSION.

14.2 Indemnification of Customer 33

14.3 Intellectual Property Indemnity 34

14.4 Indemnification Procedure 34
<!-- page 5 -->
Article 15 Insurance 35

15.1 Insurance Coverage 35

15.2 Evidence of Insurance 35

Article 16 Legal and Regulatory 35

16.1 Compliance with Laws 35

16.2 Maintenance of Records 36

16.3 Notice of Reports 36

16.4 Drug Master Files 36

16.5 Compliance with Regulatory Standards 36

16.6 Inspection 36

Article 17 Recalls 37

17.1 Safety 37

17.2 Recalls 37

17.3 Supplier's Liability for Recall 37

17.4 Customer's Liability for Recall 37

17.5 Replacement Shipments 37

Article 18 Termination 38

18.1 Termination 38

18.2 Consequences of Termination 39

18.3 Return of Samples 40

18.4 Return of Confidential Information 40

18.5 Survival 40

Article 19 Miscellaneous 41

19.1 Assignment; Inurement 41 CONFIDENTIAL Page 5 of 49

Source: PARATEK PHARMACEUTICALS, INC., 10-K/A, 5/5/2017

THIS EXHIBIT HAS BEEN REDACTED AND IS THE SUBJECT OF A CONFIDENTIAL TREATMENT REQUEST. REDACTED
MATERIAL IS MARKED WITH [* * *] AND HAS BEEN FILED SEPARATELY WITH THE SECURITIES AND EXCHANGE
COMMISSION.
<!-- page 6 -->
19.2 Change of Control 41

19.3 Counterparts 41

19.4 Dispute Resolution 41

19.5 Force Majeure 42

19.6 Performance 42

19.7 Further Assurances 42

19.8 Independent Contractors 42

19.9 Injunctions 43

19.10 Notices 43

19.11 Entire Agreement 44

19.12 Severability 44

19.13 Waiver 44 CONFIDENTIAL Page 6 of 49

Source: PARATEK PHARMACEUTICALS, INC., 10-K/A, 5/5/2017
<!-- page 7 -->
THIS EXHIBIT HAS BEEN REDACTED AND IS THE SUBJECT OF A CONFIDENTIAL TREATMENT REQUEST. REDACTED
MATERIAL IS MARKED WITH [* * *] AND HAS BEEN FILED SEPARATELY WITH THE SECURITIES AND EXCHANGE
COMMISSION. THIS AGREEMENT (this "Agreement"), dated December 30, 2016 (the "Effective Date"), is

BETWEEN:

Paratek Pharmaceuticals, Inc., a company having a place of business at 75 Park Plaza, 4t h Floor,
Boston, MA 02116, USA ("Customer")

AND:

CARBOGEN AMCIS AG, a company having a place of business at Hauptstrasse 171, CH 4416 Bubendorf,
Switzerland ("Supplier" and, collectively with Customer, the "Parties", and each, a "Party).

WHEREAS:

A. Customer is the owner of certain technology and patent rights regarding the Product (as defined
herein) having the description set out in Exhibit A (Description of Product) and Exhibit B (Chemical
Synthesis);

B. Customer has filed / intends to file for approval with the United States Food and Drug
Administration and/or its foreign equivalents, an Investigational New Drug Application ("IND") and a
New Drug Application ("NDA"), and/or the foreign equivalents thereof, for certain formulations
containing the Product;

C. Supplier is engaged in the business of performing contracted process development, Manufacturing
and supply services of active pharmaceutical ingredients ("APIs") and intermediates; and

D. Customer desires that Supplier Manufacture the Product in bulk quantities, and Supplier desires
to perform such services, each on the terms and conditions set out in this Agreement.

NOW THEREFORE, in consideration of the premises and the mutual covenants and agreements contained
herein and other good and valuable consideration, the receipt and sufficiency of which are hereby
acknowledged, the Parties hereto agree as follows:

Article 1 Interpretation

1.1 Definitions

In this Agreement, in addition to words and phrases defined where they are used, the following words
and phrases shall have the following meanings:

a) "Affiliate" of a Party shall mean any entity, directly or indirectly, controlling, controlled by,
or under common control with a Party. For purposes of this definition, "controlling" (including,
"controlled by" and "under CONFIDENTIAL Page 7 of 49

Source: PARATEK PHARMACEUTICALS, INC., 10-K/A, 5/5/2017
<!-- page 8 -->
THIS EXHIBIT HAS BEEN REDACTED AND IS THE SUBJECT OF A CONFIDENTIAL TREATMENT REQUEST. REDACTED
MATERIAL IS MARKED WITH [* * *] AND HAS BEEN FILED SEPARATELY WITH THE SECURITIES AND EXCHANGE
COMMISSION. common control") shall mean: (a) ownership of at least fifty percent (50%) of the equity
capital or other ownership interest in or of an entity; (b) the power to control or otherwise direct
the affairs of an entity; (c) in the case of non-stock organizations, the power to control the
distribution of profits of an entity; or (d) such other relationship as, in fact, results in actual
control over the management, business, and affairs of an entity;

b) "Agreement" means this Supply Agreement for the Product, including all Exhibits attached hereto;

c) "Applicable Law" means any applicable law, statute, rule, regulation, order, judgment or
ordinance of any governmental or regulatory authority or agency;

d) "Applicable Regulatory Authority" means FDA, EMEA and/or other equivalent governmental or
regulatory authorities or agencies and any successors thereto;

e) "Business Day" means any day on which banking institutions in Boston, Massachusetts and
Bubendorf, Switzerland are open for business;

f) "Campaign" means a schedule of one or more discrete batches of Product Manufactured in sequence
by Supplier without pausing to change over to manufacture of any other product;

g) "cGMP Requirements" means the current Good Manufacturing Practices standards required under ICH
Q7A guideline and/or any similar standards of applicable governmental and/or regulatory authorities
as defined in the Quality Agreement;

h) "Change of Control" means any transaction or series of transactions wherein (a) the voting
securities of Supplier outstanding immediately prior thereto cease to represent at least fifty
percent (50%) of the combined voting power of the surviving entity immediately after such
transaction or transactions; (b) the stockholders or equity holders of Supplier approve a plan of
complete liquidation of Supplier, or an agreement for the sale or disposition by Supplier of all or
substantially all of Supplier's assets, other than to an Affiliate; (c) a Third Party becomes the
beneficial owner of fifty percent (50%) or more of the combined voting power of the outstanding
securities of Supplier; or (d) substantially all of Supplier's business or assets which relate to
this Agreement are sold or otherwise transferred to a Third Party;

i) "Chemical Synthesis" means established and reliable execution of chemical reactions in order to
produce the "Product" by applying chemical and physical manipulations usually involving one or more
reactions;

j) "Confidential Information" means all written information and data provided by the Parties to each
other hereunder and identified as being "Confidential" and provided to the recipient, except that
the term "Confidential Information" shall not apply to any information or any portion thereof which:

(i) was known to the recipient or any of its Affiliates, as evidenced by its written records, before
receipt thereof under this Agreement;

(ii) is disclosed to the recipient or any of its Affiliates, without obligations of confidentiality,
during the Term by a Third Party who has the right to make such disclosure; CONFIDENTIAL Page 8 of
49

Source: PARATEK PHARMACEUTICALS, INC., 10-K/A, 5/5/2017
<!-- page 9 -->
THIS EXHIBIT HAS BEEN REDACTED AND IS THE SUBJECT OF A CONFIDENTIAL TREATMENT REQUEST. REDACTED
MATERIAL IS MARKED WITH [* * *] AND HAS BEEN FILED SEPARATELY WITH THE SECURITIES AND EXCHANGE
COMMISSION. (iii) is or becomes part of the public domain through no breach of this Agreement by the
recipient; or

(iv) the recipient can demonstrate through competent written records is independently developed by
or for the recipient or any of its Affiliates by individuals or entities who have not had access to
the information disclosed under this Agreement.

The Confidential Information may include, without limitation, data, know-how, formulae, processes,
designs, sketches, photographs, plans, drawings, specifications, samples, reports, studies, data,
findings, inventions, ideas, production facilities, machines, production capacities, prices, market
share, research and development projects, and other market data. For the purposes of this Agreement,
Master Batch Record shall be deemed the Confidential Information of Customer and the Product
Specifications shall be deemed the Confidential Information of Customer;

k) "Customer Licensee" means any Third Party to whom Customer grants a license or a right to
research, develop, make, have made, use, sell, have sold, import, export or otherwise exploit a
Product or Customer Product;

l) "Customer Material" means the compound satisfying the Customer Material Specification;

m) "Customer Material Specifications" means the specifications for the Customer Material set forth
in the Quality Agreement, as such may be amended from time to time in accordance with its terms;

n) "Customer Product" means any pharmaceutical product owned, controlled or sold by Customer, its
Affiliates or Customer Licensees that incorporates or is derived from a Product;

o) "Customer Technology" means:

[* * *];

p) "Drug Master File" or "DMF" means a submission to the Applicable Regulatory Authority that
provides detailed information about facilities, processes or articles used in the Manufacture,
processing, packaging and storing of a drug or excipient, among others, in order to obtain
appropriate Applicable Regulatory Authority approval for the production for that drug;

q) "EMEA" means the European Medicines Agency and any successors thereto;

r) "FDA" means the United States Food and Drug Administration and any successors thereto;

s) "FD&C Act" means the Federal Food, Drug and Cosmetic Act, as the same may be amended or
supplemented from time to time;

t) "Fees" means the fees specified in Exhibit C, as may be amended by the Parties in accordance with
this Agreement; CONFIDENTIAL Page 9 of 49

Source: PARATEK PHARMACEUTICALS, INC., 10-K/A, 5/5/2017
<!-- page 10 -->
THIS EXHIBIT HAS BEEN REDACTED AND IS THE SUBJECT OF A CONFIDENTIAL TREATMENT REQUEST. REDACTED
MATERIAL IS MARKED WITH [* * *] AND HAS BEEN FILED SEPARATELY WITH THE SECURITIES AND EXCHANGE
COMMISSION. u) "Improvements" means, in relation to any Intellectual Property, any and all versions,
adaptations, modifications, improvements, enhancements, changes, revisions, translations and
derivative works (whether complete or incomplete), of, to, in or based upon such Intellectual
Property;

v) "Intellectual Property" means anything that is protected by any Rights in and to any and all
patents, trade-marks, copyrights, industrial designs, Confidential Information, know-how and
processes, and all other intellectual and industrial property Rights whatsoever and world-wide
(whether registered or unregistered and including Rights in any application for any of the
foregoing);

w) "Manufacture," "Manufactured" or "Manufacturing" means all activities involved in the production
of Products to be supplied to Customer or its Affiliates hereunder, including the preparation,
formulation, finishing, testing, storage and packaging for shipment of Products and the handling,
storage and disposal of any residues or wastes generated thereby;

x) "Manufacturing Process" means the activities set out in (a) this Agreement, (b) the Master Batch
Record and (c) Supplier's standard operating procedures for the Manufacturing, characterization and
testing, and bulk packaging and storage of the Product;

y) "Master Batch Record" means the complete detailed Manufacturing and control instructions and
specifications for the Manufacturing Process for the Product, as defined by the applicable
validation protocol and cGMP Requirements, as may be amended from time to time; in accordance with
cGMP Requirements, or by mutual agreement of both Customer and Supplier;

z) "Materials" means any and all materials, reagents, chemicals, compounds, physical samples,
models, specimens and any other similar physical substances that are used in the Manufacture of the
Product except for Customer Materials, including processes and activities leading up to and
peripheral to the Manufacture of the Product;

aa) "Product" means the compound product as described in Exhibit A satisfying the Product
Specifications;

bb) "Product Specifications" means the specifications for the Product set forth in the Quality
Agreement, as such may be amended from time to time in accordance with its terms;

cc) "Quality Agreement" shall mean that certain Quality Agreement Relating to Contract Manufacturing
Services by and between Customer and Supplier, dated [* * *];

dd) "Recall" means any action by Supplier, Customer or any of their respective Affiliates, to
recover possession of the Product or finished products containing the Product shipped to Third
Parties. "Recalled" and "Recalling" shall have comparable meanings;

ee) "Rights" shall mean any and all proprietary, possessory, use and ownership rights, titles and
interests (whether beneficial or legal) of all kinds whatsoever, howsoever arising, world-wide and
whether partial or whole in nature; CONFIDENTIAL Page 10 of 49

Source: PARATEK PHARMACEUTICALS, INC., 10-K/A, 5/5/2017
<!-- page 11 -->
THIS EXHIBIT HAS BEEN REDACTED AND IS THE SUBJECT OF A CONFIDENTIAL TREATMENT REQUEST. REDACTED
MATERIAL IS MARKED WITH [* * *] AND HAS BEEN FILED SEPARATELY WITH THE SECURITIES AND EXCHANGE
COMMISSION. ff) "Seizure" means any action by an Applicable Regulatory Authority in any
jurisdiction, to detain or destroy any Product or any intermediate or finished products containing
the Product or prevent release of the Product or finished products containing the Product. "Seized"
and "Seizing" shall have comparable meanings;

gg) "Services" refers to any activities undertaken by Supplier relating to the Product, as
referenced in Section 6.6 (Services);

hh) "Supplier Technology" means, to the extent such is not Customer Technology: [* * *];

ii) "Term" means the Initial Term and the Renewal Term, if applicable;

jj) "Territory" means the United States of America and its territories and possessions and any other
countries in the world added to the definition of "Territory" pursuant to Section 3.10;

kk) "Third Party" means any party other than a Party to this Agreement or an Affiliate of a Party to
this Agreement; and

ll) "Yield" means, with respect to any batch of Product manufactured by Supplier under this
Agreement, a percentage equal to the amount of Customer Material contained in such batch of Product
delivered and accepted by Customer under this Agreement divided by the amount of Customer Material
used in the Manufacturing Process of such batch of Product.

1.2 Other Definitions

Any words defined elsewhere in this Agreement shall have the particular meaning assigned to the
words.

1.3 Currency

In this Agreement, all references to money or payments means U.S. Dollars and all payments made
hereunder shall be made in that currency.

1.4 Headings

The headings in this Agreement are solely for convenience of reference and shall not be used for
purposes of interpreting or construing the provisions hereof.

1.5 Exhibits

The Exhibits attached hereto shall be deemed to form an integral part of this Agreement. In the
event of a conflict between the terms and conditions set out in this Agreement and the terms and
conditions set out in any Exhibit hereto, the terms and conditions set out in this Agreement shall
govern. CONFIDENTIAL Page 11 of 49

Source: PARATEK PHARMACEUTICALS, INC., 10-K/A, 5/5/2017
<!-- page 12 -->
THIS EXHIBIT HAS BEEN REDACTED AND IS THE SUBJECT OF A CONFIDENTIAL TREATMENT REQUEST. REDACTED
MATERIAL IS MARKED WITH [* * *] AND HAS BEEN FILED SEPARATELY WITH THE SECURITIES AND EXCHANGE
COMMISSION. 1.6 Applicable Law

This Agreement shall be governed by and construed in accordance with the substantive Laws of the [*
* *], excluding any rules of conflicts of laws that would apply the substantive laws of any other
jurisdiction.

Article 2 Term

2.1 Term

[* * *]

This Agreement shall commence on the Effective Date and shall be valid until the [* * *] (the
"Initial Term"). Both Parties shall use reasonably diligent efforts to come to a subsequent
long-term agreement, including good faith negotiations regarding minimum volume-based Product
commitments from Customer to Supplier, no later than [* * *] to replace this Agreement and serve as
a long-term supply agreement between the Parties. Should the Parties have not agreed to the
following agreement by [* * *], this Agreement shall automatically stay in force for a maximum of [*
* *] (unless otherwise mutually agreed by the Parties or as otherwise set forth in Section 18.1(a))
or until the Parties have signed the follow-on agreement (the "Renewal Term").

2.2 Effect of Expiration on Purchase Orders

For the avoidance of doubt, any signed Purchase Order which has not been completed at the date of
expiry shall continue in effect unless cancelled in accordance with Section 6.4 or Article 18. For
further avoidance of doubt, the terms and conditions of this Agreement shall remain applicable to
any such signed Purchase Order which continues in effect.

Article 3 Supply of Product

3.1 Supply of Product

a) During the Term, Supplier shall Manufacture the Product and perform all Services at its
facilities located at Bubendorf, Switzerland and at Neuland, Switzerland (such facilities, the
"Facilities" and each, a "Facility"). Supplier will supply to Customer or Customer's designee, the
Product, Manufactured in accordance with the accepted Purchase Order placed by Customer, Master
Batch Record, the Product Specifications, the Quality Agreement and cGMP Requirements and, subject
to Section 3.1(b), in such quantities as ordered by Customer in Purchase Orders submitted pursuant
to Section 6.1 and accepted pursuant to Section 6.2. CONFIDENTIAL Page 12 of 49

Source: PARATEK PHARMACEUTICALS, INC., 10-K/A, 5/5/2017
<!-- page 13 -->
THIS EXHIBIT HAS BEEN REDACTED AND IS THE SUBJECT OF A CONFIDENTIAL TREATMENT REQUEST. REDACTED
MATERIAL IS MARKED WITH [* * *] AND HAS BEEN FILED SEPARATELY WITH THE SECURITIES AND EXCHANGE
COMMISSION. b) [* * *]

c) [* * *]

d) In the event the Product manufactured and delivered to Customer under a Purchase Order is less
than [* * *] of the amount ordered by Customer under such Purchase Order or if Customer otherwise
reasonably requests, [* * *].

d) For clarity, nothing in this Section 3.1 limits Supplier's liability under this Agreement or
under law, including liability for negligence, willful misconduct and failure to comply with Product
Specifications; [* * *].

3.2 Manufacturing Services

Supplier will make available its labor, equipment and Facilities for the Manufacture and
characterization of the Product, including in-process and quality control analyses, release testing,
storage and bulk packaging of the Product, and shipping of the Product, in accordance with the terms
and conditions of this Agreement.

3.3 Supply of Materials and Customer Material

a) Materials

i. Supplier shall, at its cost, be responsible for the purchase, planning, supply, control, testing,
release and compliance of all Materials (other than Customer Materials unless expressly otherwise
set forth in this Agreement) required for the Manufacture of the Product and performance of Services
under accepted Purchase Orders.

ii. Supplier shall ensure that all Materials (other than Customer Material unless expressly
otherwise set forth in this Agreement) used in the Manufacture of the Product and performance of
Services shall comply with the specifications mutually agreed by the Parties in writing and
applicable requirements of the Quality Agreement.

iii. Supplier shall test and inspect all Materials as set forth in the Quality Agreement and
Supplier's standard incoming inspection andtesting procedures, which at a minimum will include
appearance and identity testing.

b) Customer Material

i. Customer or its designee (for which Customer is responsible) shall, at its cost, be responsible
for the planning, supply, control, testing, release and compliance of all Customer Materials
supplied to Supplier that are required for the Manufacture of the Product and performance of
Services under accepted Purchase Orders. Customer shall ensure that all Customer Materials meet the
Customer Material Specifications. CONFIDENTIAL Page 13 of 49

Source: PARATEK PHARMACEUTICALS, INC., 10-K/A, 5/5/2017

THIS EXHIBIT HAS BEEN REDACTED AND IS THE SUBJECT OF A CONFIDENTIAL TREATMENT REQUEST. REDACTED
MATERIAL IS MARKED WITH [* * *] AND HAS BEEN FILED SEPARATELY WITH THE SECURITIES AND EXCHANGE
COMMISSION.
<!-- page 14 -->
ii. Customer or its designee (for which Customer is responsible) shall, at its cost, be responsible
for the qualification of suppliers ofCustomer Materials.

iii. Customer or its designee (for which Customer is responsible) shall ensure that all Customer
Materials used in the Manufacture of theProduct and performance of Services shall meet applicable
requirements set forth in the Quality Agreement.

iv. Supplier shall test and inspect all Customer Materials in accordance with the Quality Agreement
and Supplier's standard incoming inspection and testing procedures. Supplier shall also
independently release Customer Materials (but Supplier shall not use any Customer Materials that
have not also been released by Customer).

v. Upon receipt of a Purchase Order from Customer, Supplier will inform Customer of the latest
delivery date required for Customer Materials [* * *]. Customer will use commercially reasonable
efforts to coordinate delivery of Customer Materials by that date according to [* * *].

vi. If Customer is unable to deliver Customer Materials by the date required by Supplier, this will
be promptly communicated to Supplier. Supplier will use commercially reasonable efforts to
reallocate capacity and accommodate the planned Campaign at a later date. [* * *] Supplier will be
released from its obligation under the relevant Purchase Order and any associated penalties
regarding delivery date for the corresponding Product. In the event of any such delay in the
delivery of Customer Materials to Supplier, the Parties shall negotiate in good faith and agree upon
a revised schedule for the supply of Products to Customer or its designee, which revised schedule
shall be binding on Supplier in accordance with this Agreement.

vii. In the event that Customer Materials delivered to Supplier are found by Supplier to be
non-conforming to the Customer Material Specifications at the time of delivery of such Customer
Materials to Supplier and Customer challenges this finding, the Parties shall conduct a joint
investigation. If Supplier and Customer are unable to resolve the issue of non-compliance then a
sample of the relevant Customer Material will be submitted to an independent laboratory reasonably
acceptable to both Parties for testing against the Customer Material Specifications, and
determination whether or not the Customer Material did not comply with the Customer Material
Specifications at the time of delivery to Supplier. The test results of the independent laboratory
testing shall be final and binding upon Customer and Supplier, and the fees and expense of such
laboratory testing and the out-of-pocket costs reasonably incurred by the Parties in the joint
investigation shall be [* * *] In such event, except as set forth in Section 3.3(b)(vi), Supplier
shall be released from its obligation with respect to the relevant Purchase Order and any associated
penalties regarding a delayed delivery date for the corresponding Product under such Purchase Order.
In the event that Customer delivers any such non-conforming Customer Materials, the Parties shall
negotiate in good faith and agree upon a revised schedule for the supply of Products to Customer or
its designee, which revised schedule shall be binding on Supplier in accordance with this Agreement.

viii. Customer will provide Supplier with a Certificate of Analysis, a BSE/TSE statement and a
Certificate of Compliance, data on the chemical and physical properties, toxicity, and handling,
storing, and shipping information for any Customer Materials (MSDS or equivalent) and any other
information that is necessary for the safe handling and transportation of Customer Materials.
Customer shall update all of such information provided to Supplier after such updated information
becomes available or known to Customer. CONFIDENTIAL Page 14 of 49

Source: PARATEK PHARMACEUTICALS, INC., 10-K/A, 5/5/2017
<!-- page 15 -->
THIS EXHIBIT HAS BEEN REDACTED AND IS THE SUBJECT OF A CONFIDENTIAL TREATMENT REQUEST. REDACTED
MATERIAL IS MARKED WITH [* * *] AND HAS BEEN FILED SEPARATELY WITH THE SECURITIES AND EXCHANGE
COMMISSION. Following receipt of Customer Materials from Customer and until the delivery of Product
containing such Customer Materials, Supplier shall bear the risk of any loss of or damage to such
Customer Materials resulting from [* * *]. Supplier shall retain exclusive control over Customer
Materials and shall not transfer any portion of them to any Third Party without the prior written
consent of Customer. Supplier shall identify Customer Materials at all times as Customer property
and shall segregate same from other substances except as needed for the Manufacture of the Product
and performance of the Services. Supplier shall not take any action inconsistent with Customer's
ownership interest in Customer Materials, including but not limited to, Supplier shall keep Customer
Materials free and clear of any liens, encumbrances, or security interests resulting from the
actions or omissions of Supplier or its Affiliates and, in the event of any such liens,
encumbrances, or security interests, Supplier shall promptly remove same at its sole expense.

3.4 Production Capacity

Supplier agrees to provide to Customer all such facility and Manufacturing capacity to perform the
Manufacturing Process as required to meet the Product requirements as described in the then-current
Short Term Rolling Forecast (as defined below). Supplier agrees that it shall provide to Customer at
least [* * *] prior written notice of any scheduled shutdown at any Facility that may impact
Supplier's ability to Manufacture and timely deliver the Product to Customer under this Agreement,
[* * *].

For the avoidance of doubt, Supplier confirms that it has the capacity to deliver [* * *], or such
adjusted amount as mutually agreed by the Parties. Batch size and annual capacity could be adjusted
in the future by mutual agreement of the Parties based on results of ongoing scale up work.

3.5 Processing Changes

a) Supplier shall not make any material changes to the Manufacturing Process, starting materials,
the Master Batch Record or Product Specifications for the Manufacture of the Product except in
accordance with the Quality Agreement. For clarity, formatting changes in the documentation related
to the Master Batch Record shall not be deemed a "material" change under this Section 3.5(a).

b) Customer (or Supplier, if changes are necessitated by Applicable Law) may request reasonable
changes to the Manufacturing Process, the Master Batch Record, the Product Specifications, storage,
testing or analytical methods or any starting materials for the Manufacture of the Product [* * *].
The notice of any CONFIDENTIAL Page 15 of 49

Source: PARATEK PHARMACEUTICALS, INC., 10-K/A, 5/5/2017
<!-- page 16 -->
THIS EXHIBIT HAS BEEN REDACTED AND IS THE SUBJECT OF A CONFIDENTIAL TREATMENT REQUEST. REDACTED
MATERIAL IS MARKED WITH [* * *] AND HAS BEEN FILED SEPARATELY WITH THE SECURITIES AND EXCHANGE
COMMISSION. such change by Customer shall comply with the cGMP documentation system and standard
operating procedures maintained by Supplier at the Facilities. No material modifications or
additions to the machinery, equipment and other fixed assets used by Supplier in the manufacture and
supply of the Product to Customer shall be required without the consent of Supplier, which consent
may be granted or withheld in Supplier's sole discretion.

c) In the event of a change to the Manufacturing Process, the Master Batch Record or the Product
Specifications, the relevant documents and related Exhibits to this Agreement will be revised
accordingly.

d) All operational Master Batch Records and standard operating procedures utilized by Supplier are
in the German language. Any requirement by Customer for translation of such records will be billed
at cost.

3.6 Monitoring of Facilities

Customer shall have the right to have a representative present at each Facility to observe the
performance of the Manufacturing Process by Supplier during normal business hours with at least [* *
*] advance notice. Supplier shall have the right to reasonably restrict such observation access to
prevent undue interference with Supplier's business operations or compromise Supplier's
confidentiality obligations to Third Parties; provided, however, Customer's observation access shall
be absolute with regard to the Manufacturing Process for the Product. As such it is Supplier's
obligation to segregate Third Party documents and materials from Customer's documents and materials
and Customer will not be restricted from observing any part of Customer's Manufacturing Process and
related documentation.

3.7 Subcontracting

Supplier shall obtain Customer's prior written approval, in accordance with the Quality Agreement,
to use a subcontractor to perform services under this Agreement, such approval not to be
unreasonably withheld, conditioned or delayed. Any and all such contractors shall perform such
services in accordance with the terms and conditions of this Agreement, and Supplier shall remain
liable for the performance of its obligations under this Agreement. Supplier may use the Third Party
suppliers set forth in Schedule 4 of the Quality Agreement for such specific activities set forth
opposite their respective name(s) in such Schedule. It is hereby agreed that Customer may authorize
the use of additional Third Party suppliers under this Agreement in accordance with the Quality
Agreement. Supplier agrees to use the Third Party suppliers identified, as applicable, in Schedule 4
of the Quality Agreement as the exclusive suppliers of starting materials for the Product
Manufacturing Process and any deviation from said supply sources requires the prior written approval
of Customer, in accordance with the Quality Agreement, such approval not to be unreasonably
withheld, conditioned or delayed.

3.8 [* * *] CONFIDENTIAL Page 16 of 49

Source: PARATEK PHARMACEUTICALS, INC., 10-K/A, 5/5/2017

THIS EXHIBIT HAS BEEN REDACTED AND IS THE SUBJECT OF A CONFIDENTIAL TREATMENT REQUEST. REDACTED
MATERIAL IS MARKED WITH [* * *] AND HAS BEEN FILED SEPARATELY WITH THE SECURITIES AND EXCHANGE
COMMISSION. 3.9 [* * *]

3.10 Territory Expansion
<!-- page 17 -->
At any time during the Term, Customer may provide written notice to Supplier of its intent to expand
the Territory under this Agreement to include one or more additional countries or territories.
Promptly following such notification, the Steering Committee (as defined below) shall meet to
discuss any expansion of Supplier's Manufacturing capabilities necessitated by such expansion in
accordance with clause (b) of Section 7.4 and the Parties shall execute an amendment that (a) amends
the definition of "Territory" under clause jj) of Section 1.1 to include such additional countries
or territories and (b) modifies the provisions of this Agreement as necessary in order to reflect
the regulatory requirements of such additional countries or territories. For clarity, neither Party
shall be obligated to amend the definition of Territory at any point during the Term.

3.11 Supply to Customer Licensees

In the event Customer delivers a written request to Supplier requesting that Supplier engage in
negotiations with a Customer Licensee on the terms of a definitive agreement pursuant to which
Supplier would Manufacture and supply Product to such Customer Licensee or a designee of a Customer
Licensee, Supplier shall use commercially reasonable good faith efforts to negotiate and execute
such agreement on substantially the same terms of this Agreement (including pricing, orders,
forecasting, delivery, non-conformance, failure to supply, term and termination).

3.12 Alternative Supply

At any time during the Term, Customer may elect to qualify one or more alternative Manufacturing
facilities (whether owned by a Third Party, Customer or by one of Customer's Affiliates) to
Manufacture the Products (each, a "Backup Supplier"). Customer shall be responsible for any costs
associated with qualifying Backup Suppliers. [* * *]. Supplier shall use commercially reasonable
efforts to cooperate with the qualification of any Backup Supplier, including (a) technology
transfer of all Supplier Technology necessary or useful for the Manufacture of the Products;
provided that, to the extent that such technology and know-how constitutes Confidential Information
of Supplier, it shall be subject to the provisions of Article 12 and Customer's designated
alternative supplier shall be required to enter into a confidentiality agreement with Supplier
containing substantially the same terms as Article 12 and (b) providing Customer and any Backup
Supplier with consulting services related to the Manufacture, quality control and quality assurance
of the Products. Any work related to technology transfer or qualification of a second supplier shall
be considered as Services under this Agreement as described in Section 6.6. For the avoidance of
doubt, Supplier will first prepare a customary Scope of Work describing the Services to be performed
and the costs to Customer for the CONFIDENTIAL Page 17 of 49

Source: PARATEK PHARMACEUTICALS, INC., 10-K/A, 5/5/2017
<!-- page 18 -->
THIS EXHIBIT HAS BEEN REDACTED AND IS THE SUBJECT OF A CONFIDENTIAL TREATMENT REQUEST. REDACTED
MATERIAL IS MARKED WITH [* * *] AND HAS BEEN FILED SEPARATELY WITH THE SECURITIES AND EXCHANGE
COMMISSION. approval of Customer. No Services shall be commenced by Supplier unless (a) a customary
Scope of Work relating to such Services has been agreed, executed and delivered by both Supplier and
Customer; and (b) a Purchase Order has been issued by Customer and accepted by Supplier relating to
such Services, which Purchase Order references the specific Scope of Work and this Agreement. In
case of disagreement on the Scope of Work, the Parties will enter into good faith negotiations to
reach a mutually satisfactory resolution.

Article 4 Forecasts

4.1 Short Term Rolling Forecasts

Commencing on the Effective Date, Customer shall provide to Supplier on a calendar quarterly basis
on or before the last Business Day of each calendar quarter during the Term, a short term rolling
forecast for the [* * *] period commencing on the first day of the following calendar month (each, a
"Short Term Rolling Forecast"). Each Short Term Rolling Forecast shall set out Customer's reasonable
and genuine estimate of the quantities of the Product to be ordered by Customer and to be delivered
by Supplier under this Agreement for the following [* * *].

(A): In case of an order volume equal or less than [* * *]: The first [* * *] of each short term
rolling forecast shall be binding firm purchase orders by Customer (each a "Purchase Order") and the
last [* * *] of each short term rolling forecast shall be non-binding, good faith estimates.
Customer shall provide Supplier with one or more Purchase Order(s) for Product consistent with the
first [* * *] binding portion of each Short Term Rolling Forecast, at least [* * *] in advance of
the scheduled delivery dates provided in such Purchase Order(s).

(B): In case of order volume larger than [* * *]: The first [* * *] of each short term rolling
forecast shall be binding firm purchase orders by Customer (each a "Purchase Order") and the last [*
* *] of each short term rolling forecast shall be non-binding, good faith estimates. Customer shall
provide Supplier with one or more Purchase Order(s) for Product consistent with the first [* * *]
binding portion of each Short Term Rolling Forecast, at least [* * *] in advance of the scheduled
delivery dates provided in such Purchase Order(s).

4.2 Long Term Forecasts

Within [* * *] after the Effective Date, Customer shall provide to Supplier a long term forecast of
the estimated quantities of the Product required by Customer from Supplier during the following [* *
*] (the "Long Term Forecast"). Customer shall during the Term provide to Supplier together with the
Short Term Rolling Forecast, on a calendar quarter basis, updates of such Long Term Forecasts for
the following [* * *] (or the balance of the Term, if shorter). For the avoidance of doubt, the
first [* * *] of each Long Term Forecast shall constitute the Short Term Rolling Forecast of which
the first [* * *], or the first [* * *], as the case may be due to the order volume, shall be
binding and the remainder of the Short Term Rolling Forecast and Long Term Forecast shall be
non-binding. CONFIDENTIAL Page 18 of 49

Source: PARATEK PHARMACEUTICALS, INC., 10-K/A, 5/5/2017

THIS EXHIBIT HAS BEEN REDACTED AND IS THE SUBJECT OF A CONFIDENTIAL TREATMENT REQUEST. REDACTED
MATERIAL IS MARKED WITH [* * *] AND HAS BEEN FILED SEPARATELY WITH THE SECURITIES AND EXCHANGE
COMMISSION. Article 5 Testing and Samples
<!-- page 19 -->
5.1 Release Testing

a) Supplier shall perform release testing of all batches of Product prior to delivery to Customer in
accordance with the Product Specifications and the Master Batch Record, to determine whether such
batches of Product meet the requirements set out in the Product Specifications. Customer shall be
responsible for the final release of Product prior to shipping and further processing.

b) Supplier shall ensure that:

(i) its quality assurance department approves each batch of Product for release promptly following
successful completion of release testing done by its quality control department (in this section
"promptly" means [* * *]); and

(ii) its quality assurance department does not release any batch of Product that does not meet the
requirements set out in the Product Specifications without prior written consent of Customer.

c) Supplier shall prepare a Certificate of Analysis and Certificate of Conformance, setting out the
results of the release testing and which shall be included with each batch of Product shipped to
Customer.

d) Customer shall have the right to oversee the activities set forth in this Section 5.1 in
accordance with the Quality Agreement.

5.2 Additional Release Testing

Customer reserves the right to conduct, in its sole discretion and at its expense, additional
analytical testing on the Product.

5.3 Retention Samples

Supplier shall retain and store in accordance with cGMP Requirements, Applicable Law and Supplier's
internal quality standard operating procedures, retention samples of each batch of Product
Manufactured under this Agreement. CONFIDENTIAL Page 19 of 49

Source: PARATEK PHARMACEUTICALS, INC., 10-K/A, 5/5/2017
<!-- page 20 -->
THIS EXHIBIT HAS BEEN REDACTED AND IS THE SUBJECT OF A CONFIDENTIAL TREATMENT REQUEST. REDACTED
MATERIAL IS MARKED WITH [* * *] AND HAS BEEN FILED SEPARATELY WITH THE SECURITIES AND EXCHANGE
COMMISSION. 5.4 Stability Testing

If requested by Customer, Supplier shall be responsible for performing annual stability testing of
the Product and shall ensure that all such testing is performed in compliance with the applicable
ICH regulations (e.g. follow-up stability studies of commercially used products). Costs associated
with annual stability testing will be quoted separately from commercial unit pricing under a
separate Scope of Work or Purchase Order.

5.5 Reference Standards

If requested by Customer, Supplier shall be responsible for qualification and requalification of
reference standards. Costs associated with qualification and requalification of reference standards
will be quoted separately from commercial unit pricing under a separate Scope of Work or Purchase
Order.

5.6 Preparation of Process Qualification

All costs associated with the preparation of process qualification (as but not limited to analytical
method validation, process optimization, PAR studies, preparation of quality risk assessments,
preparation of validation protocols and report per stage, preparation of validation master protocol
and report, preparation of process performance assessment) will be handled separately from the
commercial unit pricing under separate Scopes of Work or Purchase Orders. Until otherwise agreed,
all pricing for process qualification services to be similar to current framework between Supplier
and Customer.

Article 6 Purchase Orders

6.1 Placement of Purchase Orders

Consistent with the Short Term Rolling Forecast as set forth in Section 4.1, Customer shall place
with Supplier Purchase Orders, stating Customer's required delivery data, anticipated delivery
schedule and the anticipated Fees, in accordance with the Fee Schedule set out in Exhibit C, for
each delivery of Product to be made under this Agreement. Purchase Orders must have at least [* * *]
of lead time before anticipated delivery to allow sufficient time for Supplier's planning, raw
material purchases, production and release. Each Purchase Order shall constitute a firm, binding
order, upon Supplier's acceptance thereof in accordance with Section 6.2.

6.2 Acceptance of Orders

Supplier may reject any Purchase Order placed by Customer that is not placed in accordance with this
Agreement by giving written notice (e-mail shall constitute written notice) to Customer within a
reasonable time, not to exceed [* * *] after receipt of each Purchase Order, setting out the reason
for such rejection. In the event Supplier does not respond within [* * *], such Purchase Order shall
be considered accepted by CONFIDENTIAL Page 20 of 49

Source: PARATEK PHARMACEUTICALS, INC., 10-K/A, 5/5/2017
<!-- page 21 -->
THIS EXHIBIT HAS BEEN REDACTED AND IS THE SUBJECT OF A CONFIDENTIAL TREATMENT REQUEST. REDACTED
MATERIAL IS MARKED WITH [* * *] AND HAS BEEN FILED SEPARATELY WITH THE SECURITIES AND EXCHANGE
COMMISSION. Supplier. In the event the ordered amount of Product under the Purchase Order differs
more than [* * *] from the firm portion of the most recent Short Term Rolling Forecast or more than
[* * *] from the firm portion of the most recent Short Term Rolling Forecast, Supplier shall [* *
*].

In the event the terms and conditions of this Agreement conflict with the terms and conditions of
the Purchase Order, the terms and conditions of this Agreement shall take precedence unless
otherwise agreed upon by the Parties.

6.3 Delays

If, after acceptance of a Purchase Order, Supplier is unable for any reason to supply quantities of
the Product in accordance with the Purchase Orders placed by Customer under Section 6.1 on the
timelines set forth therein, Supplier shall inform Customer within [* * *] of becoming aware of its
inability to supply the Product of the expected duration of such inability and shall keep Customer
informed on a timely basis of developments during any such period of time. The Parties shall
cooperate to expedite the scheduling of the resumption of Manufacture of the Product by Supplier
when any such inability has been alleviated. In the event of any delay in delivery of Product from
the delivery date on the applicable Purchase Order for such Product, if such delay is: [* * *].

6.4 Cancellation of Purchase Orders

In the event that Customer cancels all or part of a Purchase Order already accepted by Supplier,
Supplier will use best efforts to reallocate capacity and mitigate any resultant costs of such
cancellation. Except as expressly set forth in Section 3.4, Section 6.2, Section 6.3 and Section
6.5, the following will be charged to Customer:

[* * *]

6.5 Material Failure of Supply

If Supplier, for any reason, fails to supply at least [* * *] of the units of Product ordered by
Customer pursuant to valid Purchase Orders during any period of [* * *] or longer beginning on the
requested delivery date, in addition to and without limiting any other remedies available to
Customer, [* * *].

6.6 Services

From time-to-time during the Term, Customer may request that Supplier perform Services for Customer
relating to the Product, for which Customer shall pay reasonable compensation to Supplier. In the
event that Supplier is willing to perform any such Services requested by Customer, Supplier will
first prepare a scope of work describing the Services to be performed and the costs to Customer for
the approval of Customer (each CONFIDENTIAL Page 21 of 49

Source: PARATEK PHARMACEUTICALS, INC., 10-K/A, 5/5/2017
<!-- page 22 -->
THIS EXHIBIT HAS BEEN REDACTED AND IS THE SUBJECT OF A CONFIDENTIAL TREATMENT REQUEST. REDACTED
MATERIAL IS MARKED WITH [* * *] AND HAS BEEN FILED SEPARATELY WITH THE SECURITIES AND EXCHANGE
COMMISSION. a "Scope of Work"). No Services shall be commenced by Supplier unless (a) a Scope of
Work relating to such Services has been agreed, executed and delivered by both Supplier and
Customer; and (b) a Purchase Order has been issued by Customer and accepted by Supplier relating to
such Services which Purchase Order references the specific Scope of Work and this Agreement.
Customer shall have the right to terminate any Scope of Work and corresponding Purchase Order for
Services at any time on reasonable advance written notice to Supplier (without terminating this
Agreement), in which case Customer shall be responsible for:

[* * *]

Article 7 Shipment of Product

7.1 Storage of Product

Supplier shall ensure that all Product held in storage is stored in accordance with the Product
Specifications until shipped to Customer under this Agreement and that all storage areas meet cGMP
Requirements. [* * *]

Should any Product, during storage, change chemical composition, then Supplier and Customer will
agree upon a plan for disposition of the Product, including possible disposal, reworking or using
the Product "as is." For clarity, Supplier shall not commence any action set forth in the preceding
sentence until such a plan has been agreed by Customer. The cost of reworking the Product shall be
borne by [* * *].

The cost of storage, monitoring (including any on-going analytical analysis), and insurance before
shipment shall be borne by [* * *].

7.2 Release and Shipment of Product

a) Supplier shall notify Customer by facsimile or electronic transmission of each batch of Product
Manufactured by it under this Agreement in accordance with this Article 7 as soon as reasonably
possible, and no later than [* * *], after Supplier's quality assurance department approves the
batch for release following successful completion of the release testing procedures.

b) Supplier shall pack and label shipping boxes and ship all orders of Product in a prompt and
timely manner and in accordance with international transport guidelines and regulations, the Product
Specifications, and Customer's reasonable written instructions including, as applicable, for such
shipment and the terms of this Agreement.

c) Supplier shall not sell or otherwise dispose of any Product except in accordance with the terms
and conditions of this Agreement.

d) The Products will be shipped [* * *]. All freight, applicable taxes (excluding any and all income
taxes, employment taxes and the like incurred by Supplier), duties, express and delivery charges
shall be for CONFIDENTIAL Page 22 of 49

Source: PARATEK PHARMACEUTICALS, INC., 10-K/A, 5/5/2017
<!-- page 23 -->
THIS EXHIBIT HAS BEEN REDACTED AND IS THE SUBJECT OF A CONFIDENTIAL TREATMENT REQUEST. REDACTED
MATERIAL IS MARKED WITH [* * *] AND HAS BEEN FILED SEPARATELY WITH THE SECURITIES AND EXCHANGE
COMMISSION. Customer's account and shall not be subject to discount. Delivery shall be deemed
completed and risk of loss or damage of the Products shall pass to Customer upon [* * *]. Title to
the Products shall pass to Customer upon [* * *].

7.3 Documentation

Supplier shall include with each shipment of Product shipped to Customer under Section 7.2:

a) commercially appropriate documentation;

b) a Certificate of Analysis and Certificate of Compliance in English for each batch of Product
included in the shipment, in the forms set out in Exhibit D; and

c) a copy of any deviation or investigation reports concerning each batch of Product shipped (to be
sent separately from shipment as part of the batch record documentation).

7.4 Steering Committee

The Parties agree to form a steering committee (the "Steering Committee") to oversee their
interactions under this Agreement as provided herein. Each Party shall name a mutually agreed upon
equal number of representatives to the Steering Committee, which shall meet either in person or
remotely (as mutually agreed) at least [* * *], or as otherwise mutually agreed by the Parties. The
primary function of the Steering Committee is to ensure the ongoing communication between the
Parties and discuss and resolve any issues arising under this Agreement. The Steering Committee
shall in particular have responsibility for the following: (a) reviewing key metrics for the
Product's production and quality, and reviewing and monitoring any required remediation with respect
to production and quality for the Product; (b) reviewing Supplier's capacity and short-term and
long-term planning for clinical and commercial supply of the Product, including anticipating any
capacity shortfalls and discussing the cost allocation of investments required to increase capacity
or improve efficiencies; (c) [* * *]; (d) reviewing and discussing draft Scopes of Work; (e)
discussing the cost allocation, if any, of extraordinary costs incurred by Supplier in connection
with the Manufacture of Products or provision of Services; and (f) establishing resource priorities
and resolving resource conflicts.

Article 8 Acceptance of Shipments

8.1 Acceptance of Shipments

Customer or its designees shall, within a period of [* * *] after the date of physical receipt of
any shipment of Product from Supplier, inspect the Product for any shortages or any defects or
deviations of the Product CONFIDENTIAL Page 23 of 49

Source: PARATEK PHARMACEUTICALS, INC., 10-K/A, 5/5/2017
<!-- page 24 -->
THIS EXHIBIT HAS BEEN REDACTED AND IS THE SUBJECT OF A CONFIDENTIAL TREATMENT REQUEST. REDACTED
MATERIAL IS MARKED WITH [* * *] AND HAS BEEN FILED SEPARATELY WITH THE SECURITIES AND EXCHANGE
COMMISSION. Specifications (hereinafter "Out Of Specification") that would be apparent from visual
inspections of the Product. In the event that Customer is of the opinion that the Product is Out Of
Specification at the time of delivery, Customer shall, within [* * *] after the date of physical
receipt of Product, provide Supplier with a written notice to reject the Product (a "Notice of
Rejection"), which shall include a description of the grounds for rejection and copies of test
reports and testing methodology conducted on the Product, if any. However, with respect to any Out
Of Specification Product which would not be apparent from a reasonable visual inspection on
delivery, including in the case of any hidden defects, such Notice of Rejection shall be provided to
Supplier not later than [* * *].

The failure of Customer or its designees to notify Supplier of any Out Of Specification Product in
the manner set forth herein above shall constitute confirmation of the acceptance thereof.

8.2 Dispute of Rejected Product

Supplier may, at its option, within [* * *] of receipt of any Notice of Rejection under Section 8.1,
challenge the Notice of Rejection by delivering written notice thereof to Customer. In the event
that Supplier challenges the Notice of Rejection, Customer and Supplier shall conduct a joint
investigation. If Supplier and Customer are unable to resolve the issue of non-compliance then a
sample of the Product will be submitted to an independent laboratory reasonably acceptable to both
Parties for testing against the Product Specifications, and determination whether or not the
non-compliance may be caused by a fault on the part of Supplier. The test results of the independent
laboratory testing shall be final and binding upon Customer and Supplier, and the fees and expense
of such laboratory testing shall be borne entirely by the Party against whom such laboratory's
findings are made.

8.3 Remedies

a) Except as set forth in this Agreement, in the event of a Product shortage[* * *].

b) In the event that Customer issues a timely Notice of Rejection in respect to any Out Of
Specification Product:

[* * *]

The Party in possession of any rejected Product which does not comply with the Product
Specifications or cGMP Requirements shall destroy, in accordance with all Applicable Law and in a
manner to which Customer has given its prior written approval, all rejected Product in its
possession, but only after the Parties have followed the procedures specified under Sections 8.2 and
8.3. No rejected Product shall be sold, reprocessed, salvaged, reclaimed or otherwise reused in any
manner by Supplier or Customer without the prior written agreement of the Parties with the exception
of use testing and analysis by Supplier and/or Customer in the investigating the cause of Product
rejection. Representatives of the Party not performing the destruction shall be permitted to witness
the destruction of the rejected Product under this section. CONFIDENTIAL Page 24 of 49

Source: PARATEK PHARMACEUTICALS, INC., 10-K/A, 5/5/2017
<!-- page 25 -->
THIS EXHIBIT HAS BEEN REDACTED AND IS THE SUBJECT OF A CONFIDENTIAL TREATMENT REQUEST. REDACTED
MATERIAL IS MARKED WITH [* * *] AND HAS BEEN FILED SEPARATELY WITH THE SECURITIES AND EXCHANGE
COMMISSION. Article 9 Fees

9.1 Fees

a) Customer shall pay to Supplier, in respect of each Purchase Order placed by Customer, the
applicable Fees for the supply of the Product in bulk quantities under this Agreement, in accordance
with the terms of this Agreement.

b) Except as otherwise expressly provided in this Agreement, the Fees specified in each Purchase
Order accepted by Supplier shall be full compensation for all Manufacturing and characterization
activities and Materials in respect thereof. Customer shall make all requests for processing changes
to be performed under this Agreement in writing under Section 3.5 and Supplier shall provide
Customer a cost estimate for such work.

9.2 Adjustments to Fees

During the Term of this Agreement, either Party may request an increase or decrease of the Fees
specified in Exhibit C no more than [* * *] and such change in Fees shall take effect on [* * *] for
which such Fee change is requested. Such change in Fees may be requested due to any of the following
events:

[* * *] or

(iii) any other cost adjustments mutually agreed to by the Parties via the Steering Committee.

Supplier will make available to Customer records that substantiate any adjustment to Fees for a
Product proposed by Supplier and Supplier will provide Customer with any Customer records that
provide evidence for a decrease in Fees pursuant to clause (i); such records to be considered
Supplier's Confidential Information hereunder.

The Party proposing an adjustment in the Fees will notify the other Party of the adjustment by
delivering to the other Party at least [* * *] prior to the effective date of the Fees adjustment,
written notice of the proposed adjustment. Said written notice shall specify the effective date as
[* * *] in which the Fee adjustment becomes effective and the amounts for the adjusted Fees. On
receipt of such request, the Parties shall seek in good faith to agree to an adjustment of the Fees,
based on such reasonable and objective evidence. Each Party shall use its commercially reasonable
efforts to mitigate any cost increase. The Fees for any Product ordered by Customer prior to the
effective date of the Fees adjustment shall be the Fees existing on the date Customer placed the
Purchase Order, as set out in the Purchase Order. CONFIDENTIAL Page 25 of 49

Source: PARATEK PHARMACEUTICALS, INC., 10-K/A, 5/5/2017
<!-- page 26 -->
THIS EXHIBIT HAS BEEN REDACTED AND IS THE SUBJECT OF A CONFIDENTIAL TREATMENT REQUEST. REDACTED
MATERIAL IS MARKED WITH [* * *] AND HAS BEEN FILED SEPARATELY WITH THE SECURITIES AND EXCHANGE
COMMISSION. 9.3 Taxes

The Fees shall be exclusive of any taxes, customs duties, levies and other charges applicable to the
supply of the Product under this Agreement ("Taxes"). Customer shall pay any Taxes and reimburse
Supplier for any Taxes for which Customer is responsible but which have been paid by Supplier.
Subject to compliance with laws, the Parties shall reasonably cooperate to eliminate or minimize the
amount of any such Taxes imposed on the transactions contemplated in this Agreement. For clarity,
Customer shall not be liable for any taxes incurred by the Supplier including, without limitation,
income taxes, employment taxes, use taxes, and the like incurred by Supplier, or for any penalties
or interest related to the failure of Supplier to collect sales, use, VAT or similar taxes.

Article 10 Invoicing and Payment

10.1 Issuance of Invoices

Supplier shall, in accordance with Section 10.2, invoice Customer for each Purchase Order accepted
under Section 6.2 as follows:

10.2 Invoice Contents

All invoices issued by Supplier under Section 10.1 shall show:

a) the actual quantity of Product shipped;

b) the lot number of each batch of Product shipped;

c) the Fees for the quantity of Product shipped, based on the Fees for the Product set out in the
applicable Purchase Order; and

d) the Purchase Order number placed by Customer for the Product shipped.

If Customer disputes for any reason with the amount of any invoice submitted by Supplier, Customer
shall notify Supplier of such dispute within [* * *] after the date of the invoice, and the Parties
shall promptly attempt to resolve the dispute. If Customer does not notify Supplier of any such
dispute within such [* * *] period, such invoice will be final and binding on Customer and Supplier,
subject to the correction of mathematical errors. CONFIDENTIAL Page 26 of 49

Source: PARATEK PHARMACEUTICALS, INC., 10-K/A, 5/5/2017
<!-- page 27 -->
THIS EXHIBIT HAS BEEN REDACTED AND IS THE SUBJECT OF A CONFIDENTIAL TREATMENT REQUEST. REDACTED
MATERIAL IS MARKED WITH [* * *] AND HAS BEEN FILED SEPARATELY WITH THE SECURITIES AND EXCHANGE
COMMISSION. 10.3 Delay of Shipment

If Customer delays shipment of Product released by Supplier in accordance with Section 7.2, Supplier
may issue its invoice under Section 10.1 on or after the release, with reference to the Product
released under Section 10.2.

10.4 Payment of Invoices

Each invoice provided by Supplier to Customer under Section 10.1, to the extent accurate, shall be
paid by Customer to Supplier within [* * *] after the date of the invoice to the extent that
Customer does not reasonably dispute that portion of the invoice in good faith.

All payments will be made in U.S. Dollars by SWIFT bank transfer directly to the Supplier account as
specified in the respective Purchase Orders.

Article 11 Intellectual Property

11.1 Title

a) The Parties agree that, as between Customer and Supplier, each Party owns its respective
Confidential Information, Customer owns all Rights in and to the Customer Technology, the Product(s)
and its Chemical Synthesis and Supplier owns all Rights in and to Supplier Technology.

b) Supplier shall not knowingly use in the Manufacturing Process any Intellectual Property protected
by any patent or patent application licensed to Supplier by any Third Party, except with the prior
written consent of Customer.

11.2 No Grant of Rights

Except as otherwise provided herein, neither Party hereto shall be deemed by this Agreement to have
been granted any Rights of the other Party. CONFIDENTIAL Page 27 of 49

Source: PARATEK PHARMACEUTICALS, INC., 10-K/A, 5/5/2017

THIS EXHIBIT HAS BEEN REDACTED AND IS THE SUBJECT OF A CONFIDENTIAL TREATMENT REQUEST. REDACTED
MATERIAL IS MARKED WITH [* * *] AND HAS BEEN FILED SEPARATELY WITH THE SECURITIES AND EXCHANGE
COMMISSION. WHERE TWO PAGES OF MATERIAL HAVE BEEN OMITTED, THE REDACTED MATERIAL IS MARKED WITH [†].
11.3 Grant of License by Customer
<!-- page 28 -->
During the Term, Customer hereby grants to Supplier a paid-up, royalty-free, non-exclusive license,
without the right to sublicense, to Customer's Confidential Information and the Customer Technology
reasonably necessary to Manufacture and supply to Customer the Product hereunder, but only for such
purposes. The Parties agree that the license grant contained in this Section 11.3 is personal to
Supplier only and shall be exercised by Supplier only, and Supplier agrees to make use of Customer's
Confidential Information and the Customer Technology only in accordance with this license and not to
disclose any such Confidential Information or Customer Technology to any Third Party, except that
nothing herein shall prevent Supplier from disclosing to its permitted subcontractors under
confidentiality obligations at least as strict as those that bind Supplier under this Agreement, as
necessary to perform Supplier's obligations hereunder.

11.4 Ownership of Inventions

With respect to any ideas, innovations, Improvements or inventions (whether patentable or
non-patentable) developed by Supplier during the Term of this Agreement and [* * *], the Parties
agree that, as between Customer and Supplier, Customer shall own all Rights to such Inventions and
may obtain patent, copyright, and other proprietary protection respecting such Inventions. Supplier
agrees to promptly disclose any Inventions to Customer. Supplier agrees to assign (and cause its
employees or permitted subcontractors to assign), and does hereby assign, any and all rights, title
and interests of Supplier in, to or under any Inventions to Customer. [* * *]

11.5 Patents to Inventions

With respect to all Intellectual Property created or developed under this Agreement, [* * *].

11.6 No Use of Trademarks

Nothing contained herein shall give either Party any right to use any trademark of the other Party.
All trademarks and service marks adopted by Customer to identify the Product or a Customer Product
are and shall remain the property of Customer.

11.7 [†] CONFIDENTIAL Page 28 of 49

Source: PARATEK PHARMACEUTICALS, INC., 10-K/A, 5/5/2017

THIS EXHIBIT HAS BEEN REDACTED AND IS THE SUBJECT OF A CONFIDENTIAL TREATMENT REQUEST. REDACTED
MATERIAL IS MARKED WITH [* * *] AND HAS BEEN FILED SEPARATELY WITH THE SECURITIES AND EXCHANGE
COMMISSION. Article 12 Confidentiality & Publicity

12.1 Obligation of Confidentiality
<!-- page 29 -->
It is contemplated that in the course of the performance of this Agreement each Party may, from time
to time, disclose Confidential Information to the other. Each Party agrees:

a) to keep and use in strict confidence all Confidential Information of the other Party that each
Party acquires, sees, or is informed of, as a direct or indirect consequence of this Agreement and
to not, without the prior written consent of the other Party, disclose any such Confidential
Information or recollections thereof to any person or entity other than its corporate counsel,
employees and contractors who are under an obligation of confidentiality on terms substantially
similar to those set out in this Agreement, who have been informed of the confidential nature of the
Confidential Information and who reasonably require such information in the performance of their
duties under this Agreement;

b) not to use, copy, duplicate, reproduce, translate or adapt, either directly or indirectly, any of
the Confidential Information of the other Party or any recollections thereof for any purpose other
than the performance of the Services and the Manufacture and characterization of the Product under
this Agreement, without the other Party's prior written approval;

c) that all copies, duplicates, reproductions, translations or adaptations of any Confidential
Information of the other Party permitted to be made hereunder shall be clearly labelled as
confidential; and

d) to take all reasonable steps to prevent material in its possession that contains or refers to
Confidential Information of the other Party from being discovered, used or copied by Third Parties
and to use reasonable steps to protect and safeguard all Confidential Information of the other Party
in its possession from all loss, theft or destruction.

Upon the termination of this Agreement, each Party shall promptly destroy or return all Confidential
Information to the disclosing Party in accordance with Section 18.4.

12.2 Disclosure with Consent

A Party receiving Confidential Information may, with the written consent of the disclosing Party,
disclose such Confidential Information to entities or persons other than its corporate counsel,
employees and contractors, on such terms and conditions as the disclosing Party may specify.

12.3 Publicity

During the Term, the Parties agree that no press release, public announcement or publication
regarding this Agreement or the relationship of the Parties (except to the extent that it may be
legally required), shall be made unless mutually agreed to in writing prior to the release or
dissemination of any such press release, public announcement or publication. CONFIDENTIAL Page 29 of
49

Source: PARATEK PHARMACEUTICALS, INC., 10-K/A, 5/5/2017

THIS EXHIBIT HAS BEEN REDACTED AND IS THE SUBJECT OF A CONFIDENTIAL TREATMENT REQUEST. REDACTED
MATERIAL IS MARKED WITH [* * *] AND HAS BEEN FILED SEPARATELY WITH THE SECURITIES AND EXCHANGE
COMMISSION. 12.4 Disclosure Required by Law
<!-- page 30 -->
No provision of this Agreement shall be construed so as to preclude such disclosure of Confidential
Information of the other Party as may be inherent in or reasonably necessary to the securing from
any governmental agency of any necessary regulatory approval or license. To the extent required by
legal process, subpoena, warrant, or court order, either Party may disclose Confidential Information
only to the extent required to comply with said legal proceeding, provided that the Party obligated
to make such disclosure shall, when lawfully permissible, provide reasonable prior notice the other
Party so as to allow the other Party to take steps to oppose or limit the required disclosure.

12.5 Employee Confidentiality and Invention Assignment.

(a) Supplier acknowledges and agrees that, with respect to any past or current employee, staff,
contractor, subcontractor or other agent of Supplier or its Affiliates who has conducted services or
activities related to the development, manufacture or supply of Products for or to Customer
(collectively, the "Supplier Employees"), Supplier or its Affiliate has entered into a binding
written arrangement(s) with each such Supplier Employee that requires: (i) that such Supplier
Employee will, at a minimum, keep the Confidential Information of Customer confidential and only use
such Confidential Information to conduct permitted activities for Customer under Supplier's
employment; and (ii) that such Supplier Employee assign to Supplier all of its right, title and
interest in and to any inventions (including, without limitation, know-how, improvements, ideas,
information, materials and processes) and all intellectual property rights therein that such
Supplier Employee, alone or jointly with others, conceives, develops or reduces to practice during
their period of employment or work with Supplier or its Affiliate.

(b) Supplier further covenants and agrees that, (i) with respect to any future Supplier Employee,
Supplier or its Affiliate shall enter into a binding written arrangement with such Supplier Employee
as set forth in Section 12.5(a) and (ii) with respect to any binding written arrangement referred to
in this Section 12.5(b) or Section 12.5(a), Supplier shall enforce, to the fullest extent permitted
under Applicable Law, the terms and provisions of such arrangement.

12.6 Duration of Obligation

Unless otherwise agreed by the Parties in writing, the obligations of the Parties relating to
Confidential Information set out in this Article 12 shall survive the termination of this Agreement
for a period of [* * *]. CONFIDENTIAL Page 30 of 49

Source: PARATEK PHARMACEUTICALS, INC., 10-K/A, 5/5/2017

THIS EXHIBIT HAS BEEN REDACTED AND IS THE SUBJECT OF A CONFIDENTIAL TREATMENT REQUEST. REDACTED
MATERIAL IS MARKED WITH [* * *] AND HAS BEEN FILED SEPARATELY WITH THE SECURITIES AND EXCHANGE
COMMISSION. Article 13 Representations, Warranties and Covenants

13.1 Supplier's Representations, Warranties and Covenants
<!-- page 31 -->
Supplier hereby represents, warrants and covenants to Customer as follows:

a) Supplier has been duly organized and is validly subsisting and in good standing in its
jurisdiction of organization and has the power to carry on the business as now being conducted by
it;

b) the execution, delivery and performance of this Agreement by Supplier have been duly authorized
by all requisite corporate action and do not require any shareholder action or approval;

c) Supplier has the right and authority to enter into this Agreement and perform its obligations
hereunder, and this Agreement is a legal and valid obligation binding upon Supplier and enforceable
in accordance with its terms;

d) Supplier has not made and will not make any commitments to Third Parties inconsistent with or in
derogation of Supplier's obligations under this Agreement and Supplier is to its knowledge not
subject to any obligations that would prevent it from entering into or carrying out its obligations
under this Agreement, and Supplier's compliance with the terms and provisions hereof does not and
will not conflict with or result in a breach of any of the terms and provisions of or constitute a
default under (i) a loan agreement, guaranty, financing agreement, agreement affecting a Product or
other agreement or instrument binding or affecting it or its property; (ii) the provisions of its
charter or operative documents or by-laws; or (iii) any order, writ, injunction or decree of any
court or governmental authority entered against it or by which any of its property is bound;

e) Supplier shall comply with all Applicable Law relating to its activities under this Agreement;

f) all Product delivered to Customer under this Agreement will have been Manufactured, stored and
shipped in a competent fashion in accordance with the Master Batch Record, the Product
Specifications, this Agreement, the Quality Agreement, Applicable Law and cGMP Requirements by
qualified personnel and, to Supplier's knowledge, will be free from defects;

g) the Facilities, including equipment, systems, utilities and services, complies with cGMP
Requirements for the Manufacture of the Product under this Agreement;

h) the Facilities and Supplier's procedures and processes in the Facilities are in compliance with
Applicable Law, including applicable environmental, health and safety requirements, for the
Manufacture of the Product under this Agreement;

i) Supplier does not, at any time from and after the Effective Date, retain or use the services of
(i) any person debarred under 21 U.S.C. § 335a or (ii) any person who has been convicted of a crime
as defined under the FD&C Act, in each case in any capacity associated with or related to the
Manufacture or supply of Products or any service rendered to Customer under this Agreement or the
Quality Agreement;

j) all Product supplied by Supplier under this Agreement shall be delivered by it free and clear of
any security interests, liens, claims, pledges or encumbrances of any kind or nature except for such
as are created by Customer; and

k) all records and reports required to be maintained by Supplier under cGMP Requirements shall be
accurate and complete in all material respects. CONFIDENTIAL Page 31 of 49

Source: PARATEK PHARMACEUTICALS, INC., 10-K/A, 5/5/2017
<!-- page 32 -->
THIS EXHIBIT HAS BEEN REDACTED AND IS THE SUBJECT OF A CONFIDENTIAL TREATMENT REQUEST. REDACTED
MATERIAL IS MARKED WITH [* * *] AND HAS BEEN FILED SEPARATELY WITH THE SECURITIES AND EXCHANGE
COMMISSION. In no event shall Customer seek to recover a refund for, or replacement to, an Out of
Specification Product due to Supplier's breach of Sections 13.1 (f), (g) or (h) except pursuant to
Article 8.

13.2 Customer's Representations, Warranties and Covenants

Customer hereby represents, warrants and covenants to Supplier as follows:

a) Customer has been duly organized and is validly subsisting and in good standing in its
jurisdiction of organization and has the power to carry on the business as now being conducted by
it;

b) the execution, delivery and performance of this Agreement by Customer have been duly authorized
by all requisite corporate action and do not require any shareholder action or approval;

c) Customer has the right and authority to enter into this Agreement and perform its obligations
hereunder, and this Agreement is a legal and valid obligation binding upon Customer and enforceable
in accordance with its terms;

d) Customer has not made and will not make any commitments to Third Parties inconsistent with or in
derogation of Customer's obligations under this Agreement and Customer is not subject to any
obligations that would prevent it from entering into or carrying out its obligations under this
Agreement, and Customer's compliance with the terms and provisions hereof does not and will not
conflict with or result in a breach of any of the terms and provisions of or constitute a default
under (i) a loan agreement, guaranty, financing agreement, agreement affecting a Product or other
agreement or instrument binding or affecting it or its property; (ii) the provisions of its charter
or operative documents or by-laws; or (iii) any order, writ, injunction or decree of any court or
governmental authority entered against it or by which any of its property is bound;

e) Customer shall comply with all Applicable Law relating to its activities under this Agreement;
and

f) to Customer's knowledge, [* * *].

13.3 No Other Warranty

THE WARRANTIES SET OUT IN SECTIONS 13.1 AND 13.2 ARE THE SOLE WARRANTIES MADE BY EITHER PARTY TO THE
OTHER AND TO THE EXTENT PERMITTED BY APPLICABLE LAW, THE PARTIES HEREBY DISCLAIM ANY AND ALL OTHER
WARRANTIES, REPRESENTATIONS OR GUARANTEES OF ANY KIND WHATSOEVER, EITHER EXPRESS OR IMPLIED,
REGARDING THE PRODUCT OR ANY OTHER MATERIALS OR SERVICES TO BE SUPPLIED UNDER THIS AGREEMENT,
INCLUDING, BUT NOT LIMITED TO ANY EXPRESS OR IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
PARTICULAR PURPOSE. CONFIDENTIAL Page 32 of 49

Source: PARATEK PHARMACEUTICALS, INC., 10-K/A, 5/5/2017

THIS EXHIBIT HAS BEEN REDACTED AND IS THE SUBJECT OF A CONFIDENTIAL TREATMENT REQUEST. REDACTED
MATERIAL IS MARKED WITH [* * *] AND HAS BEEN FILED SEPARATELY WITH THE SECURITIES AND EXCHANGE
COMMISSION. 13.4 No Consequential Damages and Limitation of Liability
<!-- page 33 -->
a) [* * *], IN NO EVENT SHALL EITHER PARTY BE LIABLE FOR ANY SPECIAL, CONSEQUENTIAL, PUNITIVE,
INCIDENTAL OR INDIRECT DAMAGES, OR LOST PROFITS, HOWEVER CAUSED, ON ANY THEORY OF LIABILITY. THIS
LIMITATION WILL APPLY EVEN IF THE OTHER PARTY HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

b) EXCEPT AS SET FORTH BELOW IN THIS SECTION 13.4(b), IN NO EVENT WILL SUPPLIER'S LIABILITY, [* *
*], BE GREATER THAN, PER CLAIM OR SERIES OF CLAIMS ARISING FROM THE SAME CAUSE OF ACTION, [* * *].

EXCEPT AS SET FORTH BELOW IN THIS SECTION 13.4(b), [* * *], AS APPLICABLE, IN NO EVENT SHALL A
PARTY'S LIABILITY, HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, BE GREATER THAN, PER CLAIM OR
SERIES OF CLAIMS ARISING FROM THE SAME CAUSE OF ACTION, [* * *].

EXCEPT AS SET FORTH BELOW IN THIS SECTION 13.4(b), WITH RESPECT [* * *], IN NO EVENT SHALL A PARTY'S
LIABILITY BE GREATER THAN, PER CLAIM OR SERIES OF CLAIMS ARISING FROM THE SAME CAUSE OF ACTION, [* *
*].

NOTWITHSTANDING ANYTHING TO THE CONTRARY IN THIS SECTION 13.4(b), WITH RESPECT TO [* * *] IN NO
EVENT SHALL SUPPLIER'S LIABILITY, HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, BE GREATER THAN,
PER CLAIM OR SERIES OF CLAIMS ARISING FROM THE SAME CAUSE OF ACTION, [* * *].

[* * *]

Article 14 Indemnification

14.1 Indemnification of Supplier

Customer shall indemnify, defend and hold harmless Supplier and its officers, directors, agents,
servants and employees against any and all actions, claims, demands, proceedings, suits, losses,
damages, costs and expenses (including reasonable legal fees) of Third Parties (in this Article 14,
"Claims") (including Claims for personal injury or death) to the extent such Claims result from or
arise out of (a) any product liability claim directly related to Customer's commercial use, sale or
distribution of Products or (b) Customer's [* * *] acts or omissions or [* * *], except, in each
case of clause (a) and (b), to the extent Supplier has an obligation to indemnify Customer pursuant
to Section 14.2 or 14.3.

14.2 Indemnification of Customer

Supplier shall indemnify, defend and hold harmless Customer and its Affiliates and Customer
Licensees, and their respective officers, directors, agents, servants, employees and consultants
against any and all Claims (including Claims for personal injury or death) to the extent such Claims
result from or arise out of (a) any [* * *] acts or omissions or [* * *] by Supplier or its
officers, directors, agents, servants, CONFIDENTIAL Page 33 of 49

Source: PARATEK PHARMACEUTICALS, INC., 10-K/A, 5/5/2017
<!-- page 34 -->
THIS EXHIBIT HAS BEEN REDACTED AND IS THE SUBJECT OF A CONFIDENTIAL TREATMENT REQUEST. REDACTED
MATERIAL IS MARKED WITH [* * *] AND HAS BEEN FILED SEPARATELY WITH THE SECURITIES AND EXCHANGE
COMMISSION. employees or contractors (collectively, the "Supplier Representatives") [* * *] or (b)
any [* * *] or omissions or [* * *] by Supplier or the Supplier Representatives, except, in each
case of clause (a) and (b), to the extent Customer has an obligation to indemnify Supplier pursuant
to Sections 14.1 or 14.3.

14.3 Intellectual Property Indemnity

Customer (an "Indemnifier") shall indemnify, defend and hold harmless Supplier and the Supplier
Representatives (each, an "Indemnified Party") from any and all Claims of any Third Party that any
Intellectual Property (including, without limitation, Customer Materials, Product Information,
Product Specifications, Customer Technology or Tufts Technology), provided by Customer to Supplier
hereunder, infringes a Third Party's Intellectual Property Rights or otherwise violates a Third
Party's rights. Supplier (an "Indemnifier") indemnifies Customer and its Affiliates and Customer
Licensees, and their respective officers, directors, agents, servants, employees and consultants
(each, an "Indemnified Party") from any and all Claims of any Third Party that the Intellectual
Property (other than the Intellectual Property Customer has provided to Supplier under this
Agreement) that Supplier elects to use in conducting the activities set out in this Agreement,
infringes such Third Party's Intellectual Property Rights or otherwise violates a Third Party's
rights.

The Indemnifier's obligation to indemnify the Indemnified Party shall apply only upon the following
terms and conditions:

a) the obligation shall only pertain to the Intellectual Property the Indemnifier, its Affiliates,
officers, directors, agents, servants, employees or consultants elect to use in conducting the
activities set out in this Agreement, and not to any Improvements or additions made by anyone other
than the Indemnifier, whether with or without permission; and

b) [* * *]

14.4 Indemnification Procedure

The indemnities contained in this Article 14 shall be conditional on compliance with the terms and
conditions set out in this Section 14.4. The indemnifying Party shall have the option to defend,
contest, or otherwise protect against any such Claims at its own cost and expense provided that the
party seeking indemnification (the "Indemnitee") regarding any such Claims gives written notice to
the indemnifying Party promptly after receiving notice of said Claims. If the indemnifying Party
chooses to defend Claims, the Indemnitee may, but will not be obligated to, participate at its own
expense in a defense thereof by counsel of its own choosing, but the indemnifying Party shall be
entitled to control the defense unless the Indemnitee has relieved the indemnifying Party from
liability with respect to the particular matter. If the indemnifying Party fails to timely defend,
contest, or otherwise protect against any such Claims, the Indemnitee may defend, contest, or
otherwise protect against the same, and make any reasonable compromise or settlement thereof and
recover the entire costs thereof from the indemnifying Party, including reasonable legal fees and
costs and disbursements, and all amounts paid as a result of such CONFIDENTIAL Page 34 of 49

Source: PARATEK PHARMACEUTICALS, INC., 10-K/A, 5/5/2017
<!-- page 35 -->
THIS EXHIBIT HAS BEEN REDACTED AND IS THE SUBJECT OF A CONFIDENTIAL TREATMENT REQUEST. REDACTED
MATERIAL IS MARKED WITH [* * *] AND HAS BEEN FILED SEPARATELY WITH THE SECURITIES AND EXCHANGE
COMMISSION. Claims or the compromise or settlement thereof; provided, however, that if the
indemnifying Party undertakes the timely defense of such matter, the Indemnitee shall not be
entitled to recover from the indemnifying Party for its costs incurred in the defense thereof. The
Indemnitee shall cooperate and provide such assistance as the indemnifying Party may reasonably
request in connection with the defense of the matter subject to indemnification.

Article 15 Insurance

15.1 Insurance Coverage

Customer and Supplier each represent that they are sufficiently insured against any liability
arising under this Agreement. Further, Supplier shall at a minimum retain [* * *].

15.2 Evidence of Insurance

Each of Customer and Supplier shall, upon request by the other, provide the other Party with a copy
of all insurance policies maintained under this Article 15 relating to the Manufacture of the
Product in bulk quantities and the facilities therefor and shall notify the other Party in writing
at least 30 days prior to the cancellation of or any material change to such insurance policies.
Each Party may request that the other Party procure and maintain such additional insurance coverage
relating to the Manufacture of the Product and the facilities therefore as may be reasonably
necessary in respect of the Parties' respective obligations under this Agreement.

Article 16 Legal and Regulatory

16.1 Compliance with Laws

a) Each Party shall, in connection with its obligations, rights and duties under this Agreement and
in Manufacturing, handling, storage, loading, shipping, using, commercializing, reselling and
distributing the Product:

(i) comply with all Applicable Law or other requirements applicable to such Party's business; and

(ii) subject to Subsection b) below, obtain and maintain in full force and effect all applicable
licenses, permits, certificates, authorizations or approvals from local governmental authorities
necessary to conduct its business and the activities contemplated under this Agreement. Such
licences or certificates are to be provided to the other Party on request.

b) Customer shall be responsible for obtaining all necessary import and/or export licenses or
permits and for the payment of all import and/or export fees, taxes or duties in connection with the
purchase and/or delivery of the Product under this Agreement. Supplier shall reasonably cooperate
with Customer in connection with obtaining necessary import and/or export licenses or permits.
CONFIDENTIAL Page 35 of 49

Source: PARATEK PHARMACEUTICALS, INC., 10-K/A, 5/5/2017

THIS EXHIBIT HAS BEEN REDACTED AND IS THE SUBJECT OF A CONFIDENTIAL TREATMENT REQUEST. REDACTED
MATERIAL IS MARKED WITH [* * *] AND HAS BEEN FILED SEPARATELY WITH THE SECURITIES AND EXCHANGE
COMMISSION. 16.2 Maintenance of Records
<!-- page 36 -->
Supplier shall maintain adequate books and records and retention samples consistent with cGMP
Requirements and any other Applicable Law and requirements of applicable governmental or regulatory
authorities, in respect of test records, samples and associated support data for all batches of
Product Manufactured by Supplier sufficient to substantiate and verify Supplier's duties and
obligations under this Agreement for [* * *] from the expiration date of the respective Product
batch.

16.3 Notice of Reports

Supplier shall provide to Customer within [* * *] of receipt by Supplier copies of all
Product-specific portions of any reports of any governmental or regulatory authority including,
without limitation, any Facility-specific reports solely to the extent applicable to the Product or
Manufacturing Process, FDA Form 483 observations, FDA warning letters or other correspondence from
the FDA or equivalent correspondence from another Applicable Regulatory Authority; provided that
Supplier may redact any information from such reports subject to confidentiality obligations and not
related to the Product.

16.4 Drug Master Files

Supplier will routinely update and keep current all information pertinent to maintain the Drug
Master Files relating to the Manufacture of the Product at the production site of Supplier. Supplier
will fully support and reasonably assist Customer with its filing of any application with respect to
the Product with any Applicable Regulatory Authority at Customer's expense.

16.5 Compliance with Regulatory Standards

Supplier shall be responsible for Manufacturing the Product in compliance with Applicable Law, cGMP
Requirements and the standards of any other applicable governmental or regulatory authority. Each
Party will provide reasonable assistance to the other, at no charge, if necessary to respond to
audits, inspections, inquiries, or requests of any Applicable Regulatory Authority. Supplier shall
advise Customer immediately if Supplier receives notice of an impending inspection related to a
Product or if an authorized agent of any Applicable Regulatory Authority or other governmental
agency provides advance notice of any investigation, inspection or visit to a Facility. In such
event, Supplier shall permit, to the extent permitted by Applicable Law, Customer or its
representatives to be present during such visit, at Customer's expense. Upon Customer's request,
Supplier shall provide Customer with a copy of any report issued by such Regulatory Authority
following such visit.

16.6 Inspection

Supplier shall allow monitoring of the Facilities as set forth in Section 3.6 and inspections or
audits as provided for in the Quality Agreement. Supplier shall make available to Customer all
relevant records and reports and Customer shall have the right to copy all Product related records
and reports. The frequency of such audits as well as the response time with respect to audit
findings shall be governed by the Quality Agreement. CONFIDENTIAL Page 36 of 49

Source: PARATEK PHARMACEUTICALS, INC., 10-K/A, 5/5/2017
<!-- page 37 -->
THIS EXHIBIT HAS BEEN REDACTED AND IS THE SUBJECT OF A CONFIDENTIAL TREATMENT REQUEST. REDACTED
MATERIAL IS MARKED WITH [* * *] AND HAS BEEN FILED SEPARATELY WITH THE SECURITIES AND EXCHANGE
COMMISSION. Article 17 Recalls

17.1 Safety

Supplier shall provide Customer with reasonable co-operation to help Customer investigate adverse
events or product complaints involving or related to the Product. The cost and expense of any
testing undertaken by Supplier at Customer's request shall be borne by [* * *].

17.2 Recalls

If either Party has grounds to recommend a Recall or otherwise receives a notification or
information which might result in a Recall, the Party recommending such Recall or receiving such
notification or information shall immediately notify the other Party in writing. Subject to
Applicable Law, Customer and its designees shall have the sole responsibility to implement any
Recall of the Product or any intermediate or finished product containing the Product and the sole
right to make all final decisions regarding any such Recall. Supplier shall reasonably cooperate
with Customer and its designees in implementing any such Recall, at Customer's expense.

17.3 Supplier's Liability for Recall

In the event of a Recall or Seizure arising from [* * *], Supplier shall be liable for the expenses
and out-of-pocket costs actually incurred by Customer as a result of such Recall or Seizure, and
Supplier shall, at the option of Customer:

[* * *].

Such liability shall not limit or otherwise be exclusive of any other provisions of this Agreement.

17.4 Customer's Liability for Recall

In the event of a Recall or Seizure arising from [* * *] Customer shall [* * *].

Such liability shall not be exclusive of any other provisions of this Agreement.

17.5 Replacement Shipments

In the event of any Recall or Seizure with respect to the Product during the Term of this agreement,
Supplier shall, upon the written request of Customer, as soon as reasonably possible, supply
replacement Product to Customer in an amount sufficient to replace the amount of Product Recalled or
Seized, at the applicable then current Fees for Product under this Agreement. If Customer makes such
written request, Customer shall issue a Purchase Order in this regard which Supplier is obliged to
accept. Supplier agrees to use commercially reasonable efforts to supply such replacement Product
pursuant to the new Purchase Order as soon as possible. CONFIDENTIAL Page 37 of 49

Source: PARATEK PHARMACEUTICALS, INC., 10-K/A, 5/5/2017

THIS EXHIBIT HAS BEEN REDACTED AND IS THE SUBJECT OF A CONFIDENTIAL TREATMENT REQUEST. REDACTED
MATERIAL IS MARKED WITH [* * *] AND HAS BEEN FILED SEPARATELY WITH THE SECURITIES AND EXCHANGE
COMMISSION. Article 18 Termination
<!-- page 38 -->
18.1 Termination

This Agreement is effective as of the Effective Date and will expire in accordance with Section 2.1,
unless, upon the occurrence of any of the following events, this Agreement is earlier terminated in
accordance with this Section 18.1:

a) Customer delivers written notice of termination to Supplier at least [* * *] prior to the
expiration date of the Initial Term, which termination shall be effective as of the expiration date
of the Initial Term;

b) either Party delivers written notice of termination to the other Party at least [* * *] prior to
the expiration date of the Renewal Term, which termination shall be effective as of the expiration
date of the Renewal Term;

c) a Party makes a general assignment for the benefit of creditors, a court of competent
jurisdiction declares a Party insolvent or bankrupt, or a petition in bankruptcy or under any
insolvency law is filed by or against a Party and such petition is not dismissed within [* * *]
after it has been filed, and the other Party delivers written notice of termination to such Party,
which termination shall be effective immediately upon delivery of such written notice;

d) a Party breaches a material provision of this Agreement, and the other Party delivers written
notice of termination to such breaching Party:

(i) if the breach is not cured within [* * *] after written notice thereof to the Party in default;
or

(ii) if the breach is of a type that cannot be cured within [* * *], if a cure is not promptly
commenced and diligently pursued until complete remediation but in any case after [* * *] unless
otherwise agreed in writing between the Parties;

e) any governmental law, regulation or order is adopted and made effective which would make
performance of a Party's obligations under this Agreement impossible or commercially impracticable,
and such Party delivers written notice of termination to the other Party, which termination shall be
effective immediately upon delivery of such written notice; or

f) a Party has the right to terminate under Section 14.3, which termination shall be effective [* *
*] after delivery of written notice to the non- terminating Party. CONFIDENTIAL Page 38 of 49

Source: PARATEK PHARMACEUTICALS, INC., 10-K/A, 5/5/2017

THIS EXHIBIT HAS BEEN REDACTED AND IS THE SUBJECT OF A CONFIDENTIAL TREATMENT REQUEST. REDACTED
MATERIAL IS MARKED WITH [* * *] AND HAS BEEN FILED SEPARATELY WITH THE SECURITIES AND EXCHANGE
COMMISSION. 18.2 Consequences of Termination
<!-- page 39 -->
On expiration or the effective date of termination of this Agreement, if earlier:

a) both Parties shall be released from all obligations and duties imposed or assumed hereunder,
except obligations and liabilities previously accrued and as expressly provided by this Agreement,
including, without limitation, those provisions which expressly survive termination or expiration of
this Agreement;

b) all Rights granted by Customer to Supplier under Section 11.3 shall immediately revert to
Customer, provided that Supplier may continue to use any such Rights in order to fulfil its
surviving obligations under Section 18.5, and only for such purpose;

c) Supplier shall provide to Customer, to the extent they exist, copies of:

(i) Supplier's Manufacturing batch records and analytical reports relating to the Product; and

(ii) any other documents required to be delivered pursuant to this Agreement or otherwise reasonably
requested by Customer;

d) Unless this Agreement is terminated by Customer pursuant to Section 18.1(d) above, all Purchase
Orders and Scopes of Work shall automatically be deemed terminated by Customer and Supplier shall be
compensated for final Product already produced or Services already rendered in accordance with this
Agreement and, for Products or Services not yet produced or rendered, as the case may be, Supplier
shall be entitled to its fees, expenses and costs as set forth in Sections 6.4 and 6.6.
Additionally, Customer shall be entitled to request that (i) all Products and/or works in process
for which Customer has compensated Supplier and (ii) all Customer Materials be shipped to Customer
in accordance with the provisions of Section 7.2(d). If this Agreement is terminated by Customer
pursuant to Section 18.1(d) as a result of Supplier's breach, then, Customer shall be able to elect
whether Purchase Orders or Scopes of Work not yet completed at the date of termination or expiration
should continue in force, subject to the terms and conditions herein; and

e) Supplier shall promptly cooperate with Customer to transfer and transition supply of the Products
to a Third Party supplier. Upon Customer's request, Supplier shall cooperate with Customer in the
transfer of technology and know-how necessary to Manufacture Products to such Third Party supplier,
including providing Customer and the Third Party supplier with reasonable access to the Facilities
and consulting services related to Manufacturing of the Product. Supplier shall conduct such
activities at Customer's expense paid in advance. CONFIDENTIAL Page 39 of 49

Source: PARATEK PHARMACEUTICALS, INC., 10-K/A, 5/5/2017
<!-- page 40 -->
THIS EXHIBIT HAS BEEN REDACTED AND IS THE SUBJECT OF A CONFIDENTIAL TREATMENT REQUEST. REDACTED
MATERIAL IS MARKED WITH [* * *] AND HAS BEEN FILED SEPARATELY WITH THE SECURITIES AND EXCHANGE
COMMISSION. 18.3 Return of Samples

On expiration or earlier termination of this Agreement, unless otherwise instructed by Customer,
Supplier shall, within [* * *], return to Customer all samples or other supplies of the Product (for
which Supplier has been paid) in its possession or control in any form, with the exception of any
samples such as retention samples that Supplier may be required to keep according to Applicable Law.
The cost of returning any such supplies shall: [* * *]

18.4 Return of Confidential Information

On expiration or earlier termination of this Agreement, unless otherwise agreed between the Parties,
each Party shall:

a) promptly cease all use of the Confidential Information of the other Party and ensure that its
corporate counsel, employees and contractors cease all use thereof; and

b) upon written request of the other Party,

(i) return to the other Party all original copies of the Confidential Information of the other Party
in its control or possession, subject to the retention of one (1) complete copy for archival
purposes and to satisfy any applicable legal requirements; and

(ii) except for back-up copies generated by the recipient Party's IT system, destroy any and all
copies or other reproductions or extracts of the Confidential Information of the other Party and all
other documents, computer files, memoranda, notes or other writings prepared based on such
Confidential Information subject to clause (i) above.

18.5 Survival

Except as otherwise provided herein or agreed in writing between the Parties, expiration or early
termination of this Agreement shall not relieve either Party of its obligations incurred prior to
such expiration or early termination, including the obligation to Manufacture and deliver the
Product under Purchase Orders placed by Customer and accepted by Supplier prior to the effective
date of expiration or earlier termination, and the obligation to pay Fees in respect thereof. In
addition, the following provisions shall survive any expiration or early termination of this
Agreement in accordance with the terms of such provision; provided that if there is no express
expiration or termination of an obligation or a right under a surviving provision, such provision or
right shall continue to survive, subject to Applicable Law[* * *]:

Article 1 (Interpretation); Section 2.2 (Effect of Expiration on Purchase Orders); Section 5.3
(Retention Samples); Article 9 (Fees) (solely with respect to amounts owed or paid following
termination); Article 11 (Intellectual Property) (other than Section 11.3 (Grant of License by
Customer)); Article 12 (Confidentiality & Publicity); Section 13.3 (No other Warranty); Section 13.4
(No Consequential Damages and Limitation of Liability); Article 14 (Indemnification); Article 15
(Insurance); Section 16.2 (Maintenance of Records); Section 16.4 (Drug Master Files); Section 16.6
(Inspection); Sections 17.2 CONFIDENTIAL Page 40 of 49

Source: PARATEK PHARMACEUTICALS, INC., 10-K/A, 5/5/2017
<!-- page 41 -->
THIS EXHIBIT HAS BEEN REDACTED AND IS THE SUBJECT OF A CONFIDENTIAL TREATMENT REQUEST. REDACTED
MATERIAL IS MARKED WITH [* * *] AND HAS BEEN FILED SEPARATELY WITH THE SECURITIES AND EXCHANGE
COMMISSION. (Recalls), 17.3 (Supplier's Liability for Recall) and 17.4 (Customer's Liability for
Recall); Sections 18.2 (Consequences of Termination), 18.3 (Return of Samples) and 18.4 (Return of
Confidential Information); this Section 18.5 (Survival); and Article 19 (Miscellaneous) (except 19.2
and 19.5).

Further, Article 8 (Acceptance of Shipments) shall survive any expiration or termination of this
Agreement solely with respect to shipments of Product shipped prior to the effective date of
expiration or termination.

Article 19 Miscellaneous

19.1 Assignment; Inurement

This Agreement shall be binding upon and shall inure to the benefit of the Parties hereto and their
successors and permitted assigns. Supplier shall not assign this Agreement, in whole or in part, to
any person without the prior written consent of Customer, except to a Third Party which acquires
all, or substantially all, of Supplier's business or assets, whether through merger or otherwise.

Customer shall be entitled to assign this Agreement, in whole or in part, to any person without the
consent of Supplier, provided that (i) such person acquires all, or substantially all, of Customer's
business or assets with respect to the Product, whether through merger or otherwise; (ii) such
person is an Affiliate of Customer or a Customer Licensee; or (iii) Customer remains liable for any
payments Supplier is or will be entitled to under this Agreement. Customer shall not assign this
Agreement, in whole or in part, to any other person without the prior written consent of Supplier,
not to be unreasonably withheld, conditioned or delayed.

19.2 Change of Control

During the Term, Supplier will promptly notify Customer in writing if at any time a Change of
Control shall occur as to Supplier, such notification to be given no later than fifteen (15) days
following such Change of Control. [* * *]

19.3 Counterparts

This Agreement may be executed in any number of counterparts each of which shall be deemed to be an
original and all of which taken together shall be deemed to constitute one and the same instrument.

19.4 Dispute Resolution

Any controversy or claim arising out of or relating to this Agreement, or the breach thereof, shall
be referred first to senior management of the Parties for amicable resolution. In the event that
amicable resolution has not been achieved within [* * *], then either Party may seek resolution
through CONFIDENTIAL Page 41 of 49

Source: PARATEK PHARMACEUTICALS, INC., 10-K/A, 5/5/2017
<!-- page 42 -->
THIS EXHIBIT HAS BEEN REDACTED AND IS THE SUBJECT OF A CONFIDENTIAL TREATMENT REQUEST. REDACTED
MATERIAL IS MARKED WITH [* * *] AND HAS BEEN FILED SEPARATELY WITH THE SECURITIES AND EXCHANGE
COMMISSION. confidential arbitration in accordance with the ICC Rules of Arbitration. The
arbitration hearing shall be held as soon as practicable following submission to arbitration. The
arbitration hearing shall be held in Delaware. The Parties shall request that the arbitration panel
render a formal, binding non-appealable resolution and award on each issue as expeditiously as
possible. In any arbitration, the prevailing Party shall be entitled to reimbursement of its
reasonable attorneys' fees and the Parties shall use all reasonable efforts to keep arbitration
costs to a minimum. Judgment upon the award may be entered by any court having jurisdiction thereof
or having jurisdiction over the relevant Party or its assets.

19.5 Force Majeure

Any delay or inability to perform any of the duties or obligations of either Party caused by an
event outside the affected Party's reasonable control shall not be considered a breach of this
Agreement, and unless provided to the contrary herein, the time required for performance shall be
extended for a period equal to the period of such delay. Such events shall include, without
limitation: acts of God; any governmental act or regulation; insurrections; riots or civil
disturbance; acts of war; embargoes; labor disputes at facilities of Material suppliers, including
strikes, lockouts, job actions, or boycotts; fires; explosions; terrorist attacks; floods; or other
unforeseeable causes beyond the reasonable control and without the fault or negligence of the Party
so affected. In order to take the benefit of this section, the Party so affected shall give prompt
notice [* * *] to the other Party of such cause, and shall take whatever reasonable steps are
necessary to relieve the effect of such cause as rapidly as reasonably possible. If performance is
affected for a cumulative period of more than [* * *], the non-affected Party may terminate this
Agreement immediately by notice in writing to the affected Party.

19.6 Performance

Each Party agrees to perform its obligations under this Agreement, including under any Scope of
Work, in a timely manner. Supplier shall allocate adequate resources to execute its obligations
under this Agreement, including under each Scope of Work. Supplier represents and warrants that all
Services shall be performed by qualified personnel in accordance with the highest industry
standards.

19.7 Further Assurances

The Parties shall both execute and deliver such further instruments and do such further acts as may
be required to implement the intent of this Agreement.

19.8 Independent Contractors

Supplier and Customer shall be independent contractors and shall not be deemed to be partners, joint
venturers or each other's agents under this Agreement, and neither Party shall have the right to act
on behalf of the other except as is expressly set forth in this Agreement. CONFIDENTIAL Page 42 of
49

Source: PARATEK PHARMACEUTICALS, INC., 10-K/A, 5/5/2017
<!-- page 43 -->
THIS EXHIBIT HAS BEEN REDACTED AND IS THE SUBJECT OF A CONFIDENTIAL TREATMENT REQUEST. REDACTED
MATERIAL IS MARKED WITH [* * *] AND HAS BEEN FILED SEPARATELY WITH THE SECURITIES AND EXCHANGE
COMMISSION. 19.9 Injunctions

Each Party agrees that the other Party may be irreparably damaged if any provision of this Agreement
is not performed in accordance with its terms. Accordingly, notwithstanding Section 19.3, each Party
will be entitled to apply for an injunction or injunctions to prevent breaches of any of the
provisions of this Agreement by the other Party, without showing or proving any actual or threatened
damage, notwithstanding any rule of law or equity to the contrary, and may specifically enforce such
provisions by an action instituted in a court having jurisdiction. These specific remedies are in
addition to any other remedy to which the Parties may be entitled at law or in equity.

19.10 Notices

Unless otherwise provided herein, any notice required or permitted to be given hereunder or any
proposal for any modification of this Agreement (hereinafter collectively referred to as the
"Correspondence") shall be faxed, mailed by overnight mail, certified mail postage prepaid, or
delivered by hand to the Party to whom such Correspondence is required or permitted to be given
hereunder at the addresses set out below. If delivered by hand, any such Correspondence shall be
deemed to have been given when received by the Party to whom such Correspondence is given and if
faxed, any such Correspondence shall be deemed to have been given on the first Business Day
following facsimile transmission, as evidenced by written and dated receipt of the receiving Party.

If to Supplier: CARBOGEN AMCIS AG Hauptstrasse 159-173 CH 4416 Bubendorf Switzerland Attention: CEO
Telephone: + 41 61 935 5353 Facsimile: + 41 61 935 5300

If to Customer: Paratek Pharmaceuticals, Inc. 75 Park Plaza, 4t h Floor Boston, MA 02116 USA
Attention: General Counsel Phone: +1 617 807 6600 Facsimile: +1 617 275 0039 CONFIDENTIAL Page 43 of
49

Source: PARATEK PHARMACEUTICALS, INC., 10-K/A, 5/5/2017
<!-- page 44 -->
THIS EXHIBIT HAS BEEN REDACTED AND IS THE SUBJECT OF A CONFIDENTIAL TREATMENT REQUEST. REDACTED
MATERIAL IS MARKED WITH [* * *] AND HAS BEEN FILED SEPARATELY WITH THE SECURITIES AND EXCHANGE
COMMISSION. Either Party may change the address to which any Correspondence to it is to be addressed
by notification to the other Party as provided herein.

19.11 Entire Agreement

This Agreement, the Quality Agreement and all Exhibits attached hereto (as the same may be amended
from time to time by the written agreement of the Parties) constitute the entire agreement between
the Parties with respect to the subject matter hereof and supersede all other documents, agreements,
verbal consents, arrangements and understandings between the Parties with respect to the subject
matter hereof. This Agreement shall not be amended orally, but only by an agreement in writing,
signed by both Parties that states that it is an amendment to this Agreement.

19.12 Severability

If any term or provision of this Agreement shall for any reason be held invalid, illegal or
unenforceable in any respect, such invalidity, illegality or unenforceability shall not affect any
other term or provision hereof, and this Agreement shall be interpreted and construed as if such
term or provision, to the extent the same shall have been held to be invalid, illegal or
unenforceable, had never been contained herein.

19.13 Waiver

No waiver or modification of any of the terms of this Agreement shall be valid unless in writing and
signed by an authorized representative of the Parties hereto. Failure by either Party to enforce any
rights under this Agreement shall not be construed as a waiver of such rights, nor shall a waiver by
either Party in one or more instances be construed as constituting a continuing waiver or as a
waiver in other instances.

[Signature page follows.] CONFIDENTIAL Page 44 of 49

Source: PARATEK PHARMACEUTICALS, INC., 10-K/A, 5/5/2017
<!-- page 45 -->
THIS EXHIBIT HAS BEEN REDACTED AND IS THE SUBJECT OF A CONFIDENTIAL TREATMENT REQUEST. REDACTED
MATERIAL IS MARKED WITH [* * *] AND HAS BEEN FILED SEPARATELY WITH THE SECURITIES AND EXCHANGE
COMMISSION. IN WITNESS WHEREOF, each of the Parties hereto has caused this Agreement to be executed
by its duly authorized officer as of the dates set forth below. CUSTOMER

by its authorized signatory:

/s/ William M. Haskel

Name: William M. Haskel

Title: Sr. Vice President

Date: January 9, 2017

CARBOGEN AMCIS AG by its authorized signatory:

/s/ Silke Erbeck

Name: Silke Erbeck

Title: Senior Head of Commercial Products

Date: 10.Jan.2017

/s/ Dr. Stephan Fritschi

Stephan Fritschi

VP Operations

CARBOGEN AMCIS AG

10.Jan.2017 [Signature page to Outsourcing Agreement]

Source: PARATEK PHARMACEUTICALS, INC., 10-K/A, 5/5/2017
<!-- page 46 -->
THIS EXHIBIT HAS BEEN REDACTED AND IS THE SUBJECT OF A CONFIDENTIAL TREATMENT REQUEST. REDACTED
MATERIAL IS MARKED WITH [* * *] AND HAS BEEN FILED SEPARATELY WITH THE SECURITIES AND EXCHANGE
COMMISSION. Exhibit A - Description of Product

[* * *]

Source: PARATEK PHARMACEUTICALS, INC., 10-K/A, 5/5/2017
<!-- page 47 -->
THIS EXHIBIT HAS BEEN REDACTED AND IS THE SUBJECT OF A CONFIDENTIAL TREATMENT REQUEST. REDACTED
MATERIAL IS MARKED WITH [* * *] AND HAS BEEN FILED SEPARATELY WITH THE SECURITIES AND EXCHANGE
COMMISSION. Exhibit B - Chemical Synthesis

[* * *]

Source: PARATEK PHARMACEUTICALS, INC., 10-K/A, 5/5/2017
<!-- page 48 -->
THIS EXHIBIT HAS BEEN REDACTED AND IS THE SUBJECT OF A CONFIDENTIAL TREATMENT REQUEST. REDACTED
MATERIAL IS MARKED WITH [* * *] AND HAS BEEN FILED SEPARATELY WITH THE SECURITIES AND EXCHANGE
COMMISSION. Exhibit C - Fee Schedule

[* * *]

Source: PARATEK PHARMACEUTICALS, INC., 10-K/A, 5/5/2017
<!-- page 49 -->
THIS EXHIBIT HAS BEEN REDACTED AND IS THE SUBJECT OF A CONFIDENTIAL TREATMENT REQUEST. REDACTED
MATERIAL IS MARKED WITH [* * *] AND HAS BEEN FILED SEPARATELY WITH THE SECURITIES AND EXCHANGE
COMMISSION. WHERE TWO PAGES OF MATERIAL HAVE BEEN OMITTED, THE REDACTED MATERIAL IS MARKED WITH [†].
Exhibit D - Certificate of Analysis and Certificate of Compliance

[†]

Source: PARATEK PHARMACEUTICALS, INC., 10-K/A, 5/5/2017
