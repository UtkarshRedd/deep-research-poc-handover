<!-- page 1 -->
# EXCLUSIVE DISTRIBUTOR AGREEMENT
| Field | Value |
|---|---|
| Document Type | Distributor Agreement |
| Agreement Date | 2017-05-17 |
| Parties | SMART RX SYSTEMS, INC. ("Company"); A3 DEVELOPMENT GROUP, LLC ("Distributor") |
| Source | CUAD v1 / SmartRxSystemsInc_20180914_1-A_EX1A-6 MAT CTRCT_11351705_EX1A-6 MAT CTRCT_Distributor Agreement |

Exhibit 6.7 EXCLUSIVE DISTRIBUTOR AGREEMENT This Distributor Agreement ("Agreement") is made and
entered into this 17t h day of May, 2017 by and between SMART RX SYSTEMS, INC., a Florida
corporation, with its principal place of business at Red Bug Lake Road, Suite 256, Winter Springs,
Florida 32708, U.S.A. ("Company") and A3 DEVELOPMENT GROUP, LLC, a Texas limited liability company,
with its principal place of business at 17521 Highway 69 South, Suite 120, Tyler, Texas 75703
("Distributor"). 1. DEFINITIONS: Background IP or "Background Technology" means existing
Intellectual Property not generated in the course of the Company's Business and owned by Smart RX
Systems, Inc. Business means the Business to be conducted by the parties as described in Section 2
of this Agreement. Code means the Internal Revenue Code of 1986, as amended. All references herein
to sections of the Code shall include any corresponding provision or provisions of succeeding law.
Company Marks shall mean those trademarks, service marks, logos and trade names specified in Exhibit
A used by Company in its commercial activities related to the Products. Confidential Information
means all proprietary information of Company or a third party disclosed on or after the date hereof
by Company to Distributor in any form (written, oral, photographic, electronic, magnetic, or
otherwise) which is designated as confidential or proprietary, including, without limitation:
technical data; methods; computer programs and related materials; product specifications;
documentation; processes; inventions; products under development; sales; marketing; business and
financial information; pro formas and projections; customer lists; internal memoranda; and
correspondence. Customers shall have the meaning as set forth in Section 2.5. Intellectual Property
means any Invention, Patent, trade secret, technical know-how, trademark, or work for which
copyright protection is available under Title 17 of the United States Code. Invention means an
invention patentable under Title 35 of the United States Code, or any patent on such an invention.
Kiosk Location means each Pharmacy where the Pharmacy Kiosk is installed and operational.
Medications means the inventory contained within each Kiosk Location.

EXCLUSIVE DISTRIBUTOR AGREEMENT Page 1 of 18

Source: SMART RX SYSTEMS INC, 1-A, 9/14/2018
<!-- page 2 -->
Operations Expense means all operating costs incurred in the operations of the Pharmacy (Wages,
Taxes, and benefits of Pharmacist and or Pharmacy Tech, Liability Insurance of $100/month,
miscellaneous expenses not exceeding $250/month, Fax, Phone, Internet, cost of supplies (Paper,
cartridges, vials, vial caps, envelopes, prescription labels). The supplies costs are a flat fee of
$0.75 per prescription filled). Operating costs exclude the cost of space and utilities. Patents
mean all patents and applications relating to the Kiosk or resulting from any Inventions relating to
the Smart Pharm Assist Kiosk™. Person means a natural person, corporation, limited liability company
(LLC), Series LLC, partnership, succession, trust, estate, association or other form of legal
entity. Physician(s) means any physician, physician group practice, or other health care provider
identified by Distributor in writing to the Company as a potential user of the Smart Pharm Assist
Kiosk™ in the Territory. Products shall mean the Company's Smart Pharm Assist Kiosk™ and associated
documentation, inventions, software, application and processes. Regulations means any regulations
adopted under the Code. Territory shall mean Exclusivity for the state of Texas, USA, and Exclusive
Distribution opportunities in all other states (with either the Company or Distributor), except the
state of Florida. 2. APPOINTMENT AND ACCEPTANCE: 2.1 Exclusive Appointment. Company hereby appoints
Distributor as Company's exclusive Distributor for the State of Texas, and Distributor accepts the
appointment and agrees to represent the Products within the Territory. Company agrees that no other
Distributor will be appointed in any other state as a Distributor unless it is either the Company or
Distributor, save and except for the state of Florida. 2.2 Marketing. Distributor agrees to use
commercially reasonable efforts to market Company's Products in the Territory. Distributor agrees to
include Company's trademarks, and the phrase "Authorized Company Distributor," on all literature,
marketing collateral, stationery and business correspondence in which the Products or related
services are mentioned. 2.3 Direct Marketing. Company reserves the right to directly market and
license Company products to customers within the state of Florida. 2.4 Promotion. Each party to this
contract shall act in good faith towards the other in order to promote the business and meet the
milestone targets and other goals of the Business Plan.

EXCLUSIVE DISTRIBUTOR AGREEMENT Page 2 of 18

Source: SMART RX SYSTEMS INC, 1-A, 9/14/2018
<!-- page 3 -->
2.5 Distributor Responsibilities. The primary responsibilities of the Distributor shall be as
follows: (i) Marketing the Smart Pharm Assist Kiosk™ to Physicians, Physician group practices,
Urgent Care Center, Freestanding Emergency Rooms, other retail convenience stores, other medical
facilities, retailers (such as grocery stores (Brookshires), variety stores, (i.e., Family Dollar),
medical office building owners, and other similar business in the Territory (collectively,
"Customers"); and Smart Rx Reserves the right to market directly to Retailers nationally. (ii)
Entering into pharmacy management services agreements ("PMAs") with Customers in the Territory
(similar in form as set forth on Exhibit B); (iii) Arranging to have Smart Pharm Assist Kiosk™
supplied to Customers in the Territory under various contractual arrangements with Customers,
including lease agreements, joint ventures, license agreements, jointly owned entities or other such
ventures, between Customers in the Territory (and may also include contractual relationships with
the manufacturer of Smart Pharm Assist Kiosk™ and the Distributor); (iv) Except as otherwise
provided by the applicable law, the debts, obligations and liabilities of both the Distributor and
the Company, whether arising in contract, tort or otherwise, shall be solely the debts, obligations
and liabilities of the party incurring such and neither Distributor, nor Company shall be obligated
for any such debt, obligation or liability of the other party; (v) devotion of such time, energy,
and skill on a regular and consistent basis as is necessary to distribute, promote the sale of, and
sell the Products through all channels of distribution in the Territory in conformity with the
Company's established marketing policies and programs; (vi) accurate representation and statement of
Company policies to all potential and present customers; (vii) disclosure of any problems concerning
Customers to the Company; (viii) Distributor has the sole right to bring in additional dealers under
this Agreement. All new dealers will be compensated by A3 Development Group, LLC. 3. SERVICES
PROVIDED BY COMPANY: 3.1 Purchasing of medications, vials, labels and other items for Customers in
the Territory needed to supply prescription and over the counter (OTC) medications to be dispensed
via the Smart Pharm Assist Kiosk™. 3.2 Management and training services to be rendered to all
employees of the Pharmacy.

EXCLUSIVE DISTRIBUTOR AGREEMENT Page 3 of 18

Source: SMART RX SYSTEMS INC, 1-A, 9/14/2018
<!-- page 4 -->
3.3 Coordinate installation, training, support, and maintenance of the Smart Pharm Assist Kiosk™.
3.4 Locating and hiring services of one or more pharmacists to support medication dispensing via the
Smart Pharm Assist Kiosk™ at locations of the Customers in the Territory who contract with Smart RX
Systems, Inc. 3.5 All related operating support. 3.6 All inventory and purchasing management, and
all accounting and financial activities including the preparation of Profit & Loss Statements for
each Kiosk Location on a monthly basis. 3.7 Profits from the operation of the Business shall be
calculated according to the methodology set forth in Section 4.1 or as otherwise mutually agreed
upon in writing by the parties. 3.8 INTENTIONALLY LEFT BLANK. 3.9 Sales and Marketing Plans. From
time-to-time, but in no event less frequently than annually, Company and Distributor will negotiate
in good faith mutually acceptable sales and marketing plans ("Plans") for Distributor for each
twelve-month period corresponding to the Distributor's fiscal quarter, which Plans may include
revenue targets and other specific performance obligations of Distributor. The initial Plan will be
established by the parties written ninety (90) days following the effective date of this Agreement
and incorporated by reference into this Agreement as a new Exhibit C to this Agreement. This Plan
shall be reviewed by the parties each year. 3.10 The Company agrees that it shall: (i) comply with
the laws and regulations that govern its business; (ii) carry reasonable amounts of insurance,
whether through self-insurance or otherwise, to cover its responsibilities with respect to
indemnification under Section 9 below. The Distributor shall have the right to examine the Company's
insurance policies on request; (iii) provide reasonable assistance in answering any questions the
Distributor may have about the Products; (iv) provide the Distributor with merchandising assistance
from time to time in the form of advertising programs, promotions, manuals, product and sales
training, and sales promotions;

EXCLUSIVE DISTRIBUTOR AGREEMENT Page 4 of 18

Source: SMART RX SYSTEMS INC, 1-A, 9/14/2018
<!-- page 5 -->
(v) cooperate with the Distributor and its dealers in providing advertising and promotion of the
Products through the Territory; 3.11 Product Recalls. If the Company (or any Pharmaceutical
Manufacturer) recalls any Products dispensed by the Kiosk, Smart RX Systems, Inc. will immediately
contact the Pharmacist at the location to remove the recalled products and contact the customers. 4.
PAYMENT: 4.1 Payment. Payment to the Distributor for the sale of the Products to Customers shall be
as follows: (i) Company will pay Distributor (or its Assignee) Ten Percent (10%) of the Master
Distributor Override generated by each Customer Kiosk Location. (Master Distributor Override ("MDO")
shall mean Total Revenue per Customer Kiosk Location collected by SRXS from third party payors and
patient cash payments). This 10% of the total revenue generated is payable only if the EBITDA is a
positive EBITDA and exceeds the 10% of the revenue. In cases of a positive EBITDA but shortage of
funds compared to the 10% of the revenue, Distributor will take less than 10%. If the EBITDA is
negative, no payments will be made to Distributor. Additionally, it will be the sole responsibility
of Distributor to make a full disclosure of the 10% MDO to all its clients. (ii) The MDO will be
payable within ninety (90) days from the date of the transaction (First Month payable by the end of
ninety (90) days from the end of the month). (iii) For each Customer Kiosk contracted and
implemented by Distributor, Company shall also pay a management fee of 40% of Net Income (Net Income
for this purpose is defined as EBITDA less percentage paid to the client. The balance is then split
40%/60% to A3 Development Group, LLC and Smart RX Systems, Inc. respectively). Net Income is defined
as total Customer revenue collections less all incurred expenses, and is the distributable cash
generated by each Customer location. These payments will also follow the payment policy outlined in
4.1 above. (iv) The Payment(s) to Distributor or its Assignee, as set forth herein, shall be further
set forth in each Class A Series Agreement, along with the respective ownership interest for both
the Company and the Distributor (or its Assignee) for each respective Kiosk Location which shall
have its own separate Series, as defined by the Texas Business Organizations Code for Series Limited
Liability Companies, and as set forth in the Company's Operating Agreement. (v) The Payments set
forth in Section 4.1(i) and 4.1(iii) above will reflect the following:

EXCLUSIVE DISTRIBUTOR AGREEMENT Page 5 of 18

Source: SMART RX SYSTEMS INC, 1-A, 9/14/2018
<!-- page 6 -->
The Parties further agree that to the extent a Pharmacy Kiosk is located in a medical facility that
is subject to the Stark Law (or similar State Stark Law), that such medical facility may not be able
to fulfill any Federal Healthcare Program ("FHP") (Medicare, Medicaid, Tricare) prescription, but
rather the Pharmacy Kiosk will bill such FHP prescriptions through a separate billing system. The
Parties cannot share such FHP revenues with the Healthcare Facility Investors who are subject to the
applicable Stark Laws, but Company and A3 Development Group, LLC shall share in the EBITDA on a
60/40 basis respectfully. 4.2 Method of Payment. Payments shall be made according to such methods as
may be designated or agreed to by the Parties from time to time. 4.3 Expenses. Each party shall be
responsible for their respective expenses incurred under this Agreement and shall be responsible for
all taxes based on its own net income. 4.4 U.S. Currency. All payments under this Agreement shall be
made in lawful United States currency. Due to the fact that no retail model has been developed to
date, the retail agreement will be a separate agreement. 4.5 Auditable Records. Each Party shall
keep true, accurate and consistent records containing regular entries relating to the disposition of
the Products, distributed reproduced or maintained in inventory by each respective Party. These
records shall be available for examination during normal business hours by accountants representing
the other Party, who shall be entitled to perform an audit and to make copies and extracts, and
receive any explanations that may reasonably be requested. Each Party is responsible for payment of
the accountant's fee, except that the other Party shall be responsible for such fees in the event
the examination disclose a discrepancy in a Party's favor of more than five percent (5%) of the
payments due under this Agreement. 4.6 Quarterly Reports, Distributor agrees to provide Company,
within thirty (30) days after the end of each calendar quarter, with a report depicting sales and
sales leads, including volume projections. Distributor shall commence providing Company such reports
within thirty (30) days following the end of the calendar quarter in which this Agreement is
executed. 5. INTELLECTUAL PROPERTY RIGHTS: 5.1 License. For the term of this Agreement, Company
grants Distributor a limited, revocable, non-transferable, non-exclusive license under Company's
copyrights to use the Company Products at Distributor's facilities in the Territory solely for
marketing and support purposes directly related to the performance of its duties under this
Agreement. Except as may be reasonably necessary for marketing and technical support purposes,
Distributor shall not duplicate or otherwise copy any Products without express written permission
from Company. All Products shall be reshipped by Distributor exactly as delivered by Company, and
may not be modified in any manner by Distributor.

EXCLUSIVE DISTRIBUTOR AGREEMENT Page 6 of 18

Source: SMART RX SYSTEMS INC, 1-A, 9/14/2018
<!-- page 7 -->
5.2 Ownership of Technology. Except for the limited license granted in subsection 5.1 above,
Distributor acknowledges and agrees that Company or its licensors own and will continue to own all
right, title, and interest in and to the Products, including all copyright rights (including rights
in audiovisual works), moral rights, patent rights (including patent applications and disclosures),
rights of priority and trade secret rights recognized in any country or jurisdiction of the world,
regardless of whether the Products are separate or combined with any other products, programs, or
data. Company may, at its option, provide Distributor with copies of the Products for demonstration
purposes, ill such cases, the demonstration products shall remain the property of Company and may
not be duplicated, resold, lent, leased, given away or otherwise distributed. Distributor agrees to
return aforesaid software at its expense upon written request from Company or at the termination of
this agreement. 5.3 Notices. Distributor agrees not to alter, erase, deface or overprint any
trademark, copyright and other notices of proprietary rights included by Company on or in Products.
5.4 Ownership of Marks. The Company Marks are the exclusive property of Company. Distributor has
paid no consideration for the use of Company's trademarks, logos, copyrights, trade names or
designations, and nothing contained in this Agreement shall give Distributor any interest in any of
them. Distributor may use the Company Marks in marketing the Products but such use does not confer
any right, title or interest in the Company Marks or in any of the Products. Distributor
acknowledges that Company owns and retains all copyrights and other proprietary rights in all the
Products, and agrees that it will not at any time during or after the term of this Agreement assert
or claim any interest in or do anything that may adversely affect the validity or enforceability of
any trademark, trade name, copyright or logo belonging to or licensed to Company (including without
limitation any act, or assistance to any act, which may infringe or lead to the infringement of any
copyright in the Products). Distributor agrees not to attach any additional trademarks, logos or
trade designations to any Product. Distributor further agrees not to affix any Company trademark,
logo, or trade name to any non-Company product. Distributor shall not register any Company Marks
with any government authority or agency. All rights to use such Company Marks shall cease upon
expiration or termination of this Agreement. 5.5 Infringement Enforcement. Distributor agrees to use
its best efforts to cooperate in Company's efforts to protect its proprietary rights. Distributor
agrees to immediately notify Company of any known or suspected breach of Company's proprietary
rights that comes to Distributor's attention. 5.6 Ownership of Intellectual Property, Company shall
retain ownership of its respective Background IP that each owned prior to this partnership and nay
other IP developed during this marketing relationship. 6. NON-DISCLOSURE OF CONFIDENTIAL
INFORMATION: 6.1 Generally. It may be necessary during the performance of this Agreement for Company
to disclose to Distributor Confidential Information. Distributor agrees to use the same degree of
care to protect the confidentiality of the Confidential Information and to prevent its unauthorized
use or dissemination as it uses to protect its own confidential information of a similar nature.
Distributor agrees to use the Confidential Information only for purposes directly related to the
performance of this Agreement. All Confidential Information remains the property of Company or the
relevant third party, and no license or other rights to Confidential Information is granted or
implied hereby. Company acknowledges Distributors value for identifying and contracting Customers
and will not circumvent Distributor in any manner relative to its relationships with existing
customers or leads.

EXCLUSIVE DISTRIBUTOR AGREEMENT Page 7 of 18

Source: SMART RX SYSTEMS INC, 1-A, 9/14/2018
<!-- page 8 -->
6.2 Internal Procedures. Distributor shall secure and protect and shall make and keep only the
minimum number of copies of any Confidential Information provided hereunder as may be required for
technical or archival reasons, and will ensure that each copy is marked with a clearly legible
confidentiality notice. Distributor shall restrict access to the Confidential Information to its
bona-fide full-time employees, or consultants who have signed a non-disclosure agreement no less
restrictive than terms of this Section, and who have a bona-fide need for such access. 6.3 No
Derivative Developments. Distributor may not develop, market, license, sell or otherwise distribute
any products derived in part or whole from the Confidential Information or Products or based on
techniques revealed by Distributor's inspection of the Confidential Information or Products, except
as expressly authorized by this Agreement. 6.4 Equitable Relief. Distributor consents to an
injunction without bond or other equitable relief if sought by Company from a court of competent
jurisdiction against the breach of the terms of this Section, in addition to any other legal or
equitable remedies which may be available to Company. 6.5 Survival. Distributor's obligations under
this Section shall survive any termination or expiration of this Agreement. 7. CONDUCT OF BUSINESS:
7.1 Reputational. Distributor will conduct all its business in its own name and in such manner as it
may see fit. However, conduct which Company, in its discretion, deems detrimental to Company's image
or reputation, shall be grounds for termination of this Agreement, upon reasonable notice and the
failure to cure such behavior by Distributor. 7.2 Public Access. Distributor shall maintain publicly
accessible facilities, including offices, a Website and toll-free telephone number within the
Territory, and shall use its best efforts and devote such time as may be reasonably necessary to
promote the sale of the Products within the Territory. 7.3 No Partnership or Agency. Nothing in this
Agreement shall be construed to constitute the Distributor as the partner, employee or agent of
Company, nor shall either party have any authority to bind the other in any respect, it being
intended that each shall remain an independent contractor responsible only for its own actions.
Distributor will pay all expenses of its office and activities and be responsible for the acts and
expenses of its employees.

EXCLUSIVE DISTRIBUTOR AGREEMENT Page 8 of 18

Source: SMART RX SYSTEMS INC, 1-A, 9/14/2018
<!-- page 9 -->
8. MARKETING MATERIALS: Company will provide Distributor with reasonable amounts of Company's
standard marketing literature for Distributor's use in marketing the Products. Distributor may
reproduce exact copies of such materials for such use. 9. REPRESENTATIONS AND WARRANTIES, LIMITATION
OF LIABILITY, INDEMNIFICATIONS: 9.1 Distributor Representations. Distributor represents and warrants
that it is a limited liability company organized and in good standing under the laws of the State of
Texas. 9.2 Company Representations. Company represents and warrants that it is a corporation
organized and in good standing under the laws of the State of Florida. 9.3 Disclaimer of Warranty.
COMPANY MAKES NO WARRANTIES OR REPRESENTATIONS AS TO PERFORMANCE OF COMPANY PRODUCTS OR AS TO
SERVICE TO DISTRIBUTOR OR TO ANY OTHER PERSON, EXCEPT AS SET FORTH IN ANY COMPANY OR END USER
LICENSE AGREEMENT FOR SUCH COMPANY PRODUCTS. 9.4 No Implied Warranties. TO THE EXTENT PERMITTED BY
APPLICABLE LAW, ALL IMPLIED WARRANTIES, INCLUDING BUT NOT LIMITED TO IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE, ARE HEREBY EXCLUDED. 9.5 Indemnification by
Company. Company represents that it has sufficient right, title and interest in the Products and
business processes to make this Agreement. Company agrees to defend at its expense any claim, suit
or action against Distributor or any Company Licensee based on a claim that Company does not have
sufficient right, title, and interest in the Products as furnished by Company, or that the Products
as furnished by Company infringe on any Berne Convention copyright, United States or European
patent, license, trade secret or other proprietary rights, and to pay the amount of any settlement,
award, or the costs and damages finally awarded after appeal, if any, in any such claim, suit or
action, provided (i) that Company is notified promptly in writing of any notice of claim or of
threatened or actual suit; (ii) at Company's request and expense Company is given assistance for the
defense of same; and (iii) the alleged infringement is not based upon the use of the Products in a
manner prohibited under this Agreement, in a manner for which the Products were not designed, or in
a manner not in accordance with the Products' specifications. 9.6 INTENTIONALLY LEFT BLANK. 9.7
Representations and Warranties. Each party (a "Representing Party" represents and warrants to the
other party that:

EXCLUSIVE DISTRIBUTOR AGREEMENT Page 9 of 18

Source: SMART RX SYSTEMS INC, 1-A, 9/14/2018
<!-- page 10 -->
(i) It (1) has the power and authority and the legal right to enter into this Agreement and perform
its obligations hereunder and (2) has taken all necessary action on its part required to authorize
the execution and delivery of this Agreement and the performance of its obligations hereunder. (ii)
This Agreement has been duly executed and delivered on its behalf and constitutes a legal, valid,
and binding obligation of such Party and is enforceable against it in accordance with its terms
subject to the effects of bankruptcy, insolvency, or other laws of general application affecting the
enforcement of creditor rights and judicial principles affecting the availability of specific
performance and general principles of equity, whether enforceability is considered a proceeding at
law or equity. (iii) It is not aware of any pending or threatened litigation (and has not received
any communication) that alleges that its activities related to this Agreement have violated, or that
by conducting the activities as contemplated herein it would violate, any person's intellectual
property rights. (iv) All necessary consents, approvals, and authorizations of all regulatory and
governmental authorities or other persons required to be obtained by it in connection with the
execution and delivery of this Agreement and the performance of its obligations hereunder have been
obtained. (v) The execution and delivery of this Agreement and the performance of its obligations
hereunder (1) do not conflict with or violate any requirement of applicable law or regulation or any
provision of its articles of incorporation, bylaws, limited partnership agreement, or any similar
instrument, as applicable, in any material way, and (2) do not conflict with, violate, or breach or
constitute a default or require any consent under, any contractual obligation or court or
administrative order by which it is bound. (vi) It is duly organized and in good standing under the
laws of its respective state of organization, and has full power and authority and the legal right
to own and operate its property and assets and to carry on its business as it is now being conducted
and as it is contemplated to be conducted by this Agreement. (vii) In the event of any dispute, any
deadlock among both parties, or any claim, question, or disagreement arising from or relating to
this Agreement or the interpretation, performance or breach thereof, the Parties shall use their
best efforts to settle the dispute, claim, question, or disagreement. To this effect, they shall
consult and negotiate with each other in good faith and, recognizing their mutual interests, attempt
to reach a just and equitable solution satisfactory to the parties. (viii) If any dispute, any
deadlock among the Parties, or any claim, question, or disagreement arises out of or relates to this
Agreement, or to the interpretation, performance, or breach thereof, and if the dispute or deadlock
is not resolved through negotiation, all such disputes, deadlocks, claims, questions, or differences
shall be finally resolved by arbitration in Orlando, Florida.

EXCLUSIVE DISTRIBUTOR AGREEMENT Page 10 of 18

Source: SMART RX SYSTEMS INC, 1-A, 9/14/2018
<!-- page 11 -->
10. ARBITRATION: Any dispute arising over the terms and conditions of this Agreement or in any
manner relating to this Agreement which the parties are unable to resolve informally between
themselves or by mediation shall be submitted, upon the motion of either party, to arbitration under
the appropriate rules of the American Arbitration Association ("AAA"). All such arbitration
proceedings shall be administered by the AAA and held in Dallas, Texas. The parties agree that the
decision of the arbitrator shall be final and binding as to each of them. The AAA administrative fee
shall be advanced by the party initiating the proceeding, but shall be subject to final
apportionment by the arbitrator. The arbitrator's fee shall be shared equally by the parties. The
arbitrator's award may be enforced in any court having jurisdiction thereof. Prior to invoking
arbitration, the parties will make a reasonable effort to settle any dispute in an informal and
expeditious manner. The parties separately and specially agree that if either shall contend that
this Agreement is invalid or that grounds exist for its rescission or cancellation, that any dispute
concerning such contention shall be submitted to arbitration in the manner provided in this section.
Each party shall bear such party's own attorneys' fees in any arbitration proceeding; however, if
either party commences an action in court to compel arbitration, enforce an arbitration award, or
otherwise seek by judicial means to secure compliance with the arbitration provisions of this
Agreement, then the prevailing party shall be entitled to recover from the losing party the
prevailing party's reasonable attorneys' fees and costs of suit incurred for such purpose. 11.
TRAINING: Company will schedule and provide training classes regarding Company products for Company
Pharmacists and Pharmacy Technicians. 12. TERM OF THE AGREEMENT: 12.1 Generally. This contract shall
remain in effect initially for the five (5) year term ("Initial Term") from the date signed and
shall be automatically extended for one (1) year periods after the Initial Term ("Renewal Term")
unless (i) either party provides written notice of its intention not to renew the Agreement within
180 days prior to any Renewal Term; or (ii) this Agreement is otherwise terminated pursuant to the
terms of this Section 12. 12.2 Termination for Cause. In addition to termination under Section 12.1,
either party may terminate this Agreement by giving written notice to the other party: (i) if the
other party fails to perform or comply with this Agreement or any provision thereof (subject to the
cure period described below); or (ii) if the other party becomes insolvent, admits in writing its
inability to pay its debts as they mature, makes an assignment for the benefit of creditors, or
becomes the subject of a petition under any bankruptcy act. Termination by Company under this
Section 12.2 shall be effective sixty (60) days following Company's giving of notice to Distributor
if the occurrence giving rise to the right of termination has not been cured, or immediately in the
event of a breach of Section 6 regarding Non-Disclosure of Confidential Information or Section 7.1
regarding conduct injurious to Company's reputation.

EXCLUSIVE DISTRIBUTOR AGREEMENT Page 11 of 18

Source: SMART RX SYSTEMS INC, 1-A, 9/14/2018
<!-- page 12 -->
12.3 The rights and remedies of Company provided in this Section shall not be exclusive and are in
addition to any other rights and remedies provided by law or this agreement. 13. OBLIGATIONS AFTER
TERMINATION: In the event that this Agreement is terminated for any reason, both Parties acknowledge
that there are certain obligations that they are required to fulfill, therefore the Parties agree
that, upon termination of this Agreement: 13.1 Distributor Obligations. Distributor shall: (i) pay
all valid outstanding and final invoices issued by Company within thirty (30) days after termination
is effective; (ii) immediately cease all distribution, duplication, and representation of the
Products and marketing literature; (iii) immediately cease all use of any Company trademarks, and
not there after use any mark which is confusingly similar to any trademark associated with any
Product; (iv) immediately cease all representation of an existing relationship with Company; and (v)
within thirty (30) days deliver to Company copies of all customer records (electronic, paper or
otherwise) related to the Products. 13.2 Company Obligations. (i) Immediately cease all
representation of an existing relationship with Distributor; (ii) All medication inventory is owned
by Smart RX Systems, Inc. only; and (iii) Distributor shall continue to receive Net Income per
Customer location for so long as Customer continues to utilize the Products. 13.3 No Use of
Products. From and after termination Distributor shall not use internally or employ any of the
Products or related materials as a part, portion, or basis of any product which Distributor shall
use, sell, sublicense, assign, lease, loan, license or transfer to any third party. 13.4 Survival.
The terms of Sections 5, 6, and 13-23 shall survive any termination or expiration of this Agreement.
14. NOTICES AND REQUESTS: Notices required under this Agreement shall be deemed given (i) when
delivered in writing personally, (ii) when sent by confirmed telex or facsimile, (iii) five (5) days
after having been sent by registered or certified mail, return receipt requested, postage prepaid;
or (iv) one (1) day after deposit with a commercial overnight carrier, with written verification of
receipt. All communications will be sent to the addresses set forth below (or such other address as
either party may subsequently designate):

EXCLUSIVE DISTRIBUTOR AGREEMENT Page 12 of 18

Source: SMART RX SYSTEMS INC, 1-A, 9/14/2018
<!-- page 13 -->
Company: Smart RX Systems, Inc. Red Bug Lake Road, Suite 256 Winter Springs, Florida 32708
Distributor: A3 Development Group, LLC 17521 Highway 69 South, Suite 120 Tyler, Texas 75703 15.
CONTROLLING LAW: 15.1 Generally. This Distributor Agreement shall be exclusively governed,
construed, enforced and controlled by the laws of the United States of America and of the State of
Texas. The parties agree that any controversy, claim, dispute, or disagreement arising under, out
of, or relating to this Distributor Agreement shall be exclusively submitted for resolution
exclusively to courts of competent jurisdiction located in the County of Orange, State of Florida,
USA. Distributor consents and submits to the exclusive jurisdiction and venue of such courts for the
resolution of such controversies, claims, disputes, or disagreements. 15.2 Service of Process. The
Parties further agree that service of process in any such controversy, claim, dispute, or
disagreement may be made by sending service by registered mail, return receipt requested, and the
Parties expressly waive any other rights to service. If either party employs attorneys to enforce
any rights arising out of or related to this Distributor Agreement, the party prevailing shall be
entitled to recover reasonable attorneys' fees from the other party. 16. MODIFICATION OF THE
AGREEMENT: This Distributor Agreement constitutes the entire agreement between the Parties with
respect to the subject matter hereof and merges all prior and contemporaneous communications. It
shall not be modified except by a written agreement dated even herewith or subsequent hereto signed
on behalf of Company and Distributor by their respective duly authorized representatives. 17.
SEVERABILITY; WAIVER; FORCE MAJEURE: 17.1 Severability. If any provision of this Agreement shall be
found to be invalid or unenforceable for any reason, the remaining provisions nevertheless shall
remain in full force and effect. 17.2 Waiver. Any waiver on the part of any parties hereto shall not
imply the waiver of any other right or interest of such party, or any subsequent waiver. 17.3 Force
Majeure. Except for failure to pay sums required under this Agreement, the parties hereto shall not
be responsible for any failure or delay in the performance of any obligations hereunder caused by
acts of God or the public enemy, flood, fire, natural disaster, war or preclusive acts of any
governmental authority.

EXCLUSIVE DISTRIBUTOR AGREEMENT Page 13 of 18

Source: SMART RX SYSTEMS INC, 1-A, 9/14/2018
<!-- page 14 -->
18. ATTORNEYS' FEES: If either party employs attorneys to enforce any rights arising out of or
related to this Distributor Agreement, the party prevailing shall be entitled to recover reasonable
attorneys' fees and costs from the other party. 19. BINDING EFFECT: Subject to the limitations
hereinbefore expressed, this Distributor Agreement will inure to the benefit of and shall be binding
upon the parties, their successors, administrators, heirs, and assigns. 20. NATURE OF RELATIONSHIP:
Nothing in this Agreement shall be construed as creating a joint venture, partnership, agency,
employer/employee, or similar relationship between the Parties, or as authorizing either Party to
act as the agent of the other. The Distributor's relationship to the Company is that of an
independent contractor. 21. NO IMPLIED WAIVER: The failure of either Party to insist on strict
performance of any covenant or obligation under this Agreement, regardless of the length of time for
which such failure continues, shall not be deemed a waiver of such Party's right to demand strict
compliance in the future. No consent or waiver, express or implied, to or of any breach or default
in the performance of any obligation under this Agreement shall constitute a consent or waiver to or
of any other breach or default in the performance of the same or any other obligation. 22.
COUNTERPARTS/ELECTRONIC SIGNATURES: This Agreement may be executed in one or more counterparts, each
of which shall be deemed an original but all of which shall constitute one and the same instrument.
For purposes of this Agreement, use of a facsimile, e-mail, or other electronic medium shall have
the same force and effect as an original signature. 23. SEVERABILITY: Whenever possible, each
provision of this Agreement, will be interpreted in such manner as to be effective and valid under
applicable law, but if any provision of this Agreement is held to be invalid, illegal, or
unenforceable in any respect under any applicable law or rule in any jurisdiction, such invalidity,
illegality, or unenforceability will not affect any other provision or any other jurisdiction, but
this Agreement will be reformed, construed, and enforced in such jurisdiction as if such invalid,
illegal, or unenforceable provisions had never been contained herein.

EXCLUSIVE DISTRIBUTOR AGREEMENT Page 14 of 18

Source: SMART RX SYSTEMS INC, 1-A, 9/14/2018
<!-- page 15 -->
24. HEADINGS: Headings used in this Agreement are provided for convenience only and shall not be
used to construe meaning or intent. IN WITNESS HEREOF, the parties have hereunto set their hands and
seals as of the date stated at the beginning of this Agreement. This Agreement may be executed in
two or more counterparts, each of which shall be deemed an original for all purposes, and together
shall constitute one and the same document. Telecopied signatures shall be relied on as original
signatures in all respects. COMPANY: DISTRIBUTOR: SMART RX SYSTEMS, INC., A3 DEVELOPMENT GROUP, LLC,
a Florida corporation a Texas limited liability company By: /s/ Sandeep Mathow By: /s/ Tracy W.
Gunter Name: Sandeep Mathow Name: Tracy W. Gunter Title: Founder & CEO Title: Partner

EXCLUSIVE DISTRIBUTOR AGREEMENT Page 15 of 18

Source: SMART RX SYSTEMS INC, 1-A, 9/14/2018
<!-- page 16 -->
Exhibit A Company Marks trademarks, service marks, logos and trade names

EXCLUSIVE DISTRIBUTOR AGREEMENT Page 16 of 18

Source: SMART RX SYSTEMS INC, 1-A, 9/14/2018
<!-- page 17 -->
Exhibit B Example Pharmacy Management Services Agreements

EXCLUSIVE DISTRIBUTOR AGREEMENT Page 17 of 18

Source: SMART RX SYSTEMS INC, 1-A, 9/14/2018
<!-- page 18 -->
Exhibit C Sales and Marketing Plans

EXCLUSIVE DISTRIBUTOR AGREEMENT Page 18 of 18

Source: SMART RX SYSTEMS INC, 1-A, 9/14/2018
