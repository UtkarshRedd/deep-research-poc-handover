Your previous reply did not match the required JSON format: {error}
Reply again with ONLY the JSON object, no prose, no code fence.
