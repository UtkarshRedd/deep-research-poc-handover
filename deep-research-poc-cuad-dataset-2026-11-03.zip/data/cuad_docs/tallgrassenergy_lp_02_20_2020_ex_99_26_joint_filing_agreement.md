<!-- page 1 -->
# JOINT FILING AGREEMENT
| Field | Value |
|---|---|
| Document Type | Joint Venture   Filing Agreement |
| Agreement Date | 2020-02-19 |
| Parties | PRAIRIE ECI ACQUIROR LP; PRAIRIE NON-ECI ACQUIROR LP; PRAIRIE VCOC ACQUIROR LP; PRAIRIE SECONDARY ACQUIROR LP; PRAIRIE SECONDARY ACQUIROR E LP; BIP HOLDINGS MANAGER L.L.C.; BLACKSTONE INFRASTRUCTURE ASSOCIATES L.P.; BIA GP L.P.; BIA GP L.L.C.; BLACKSTONE HOLDINGS III L.P. |
| Source | CUAD v1 / TALLGRASSENERGY,LP_02_20_2020-EX-99.26-JOINT FILING AGREEMENT |

Exhibit 26

JOINT FILING AGREEMENT

Pursuant to and in accordance with the Securities Exchange Act of 1934, as amended, and the rules
and regulations thereunder (the "Exchange Act") the undersigned hereby agree to the joint filing on
behalf of each of them of any filing required by such party under Section 13 of the Exchange Act or
any rule or regulation thereunder (including any amendment, restatement, supplement, and/or exhibit
thereto) with respect to securities of Tallgrass Energy, LP, a Delaware limited partnership, and
further agree to the filing, furnishing, and/or incorporation by reference of this Agreement as an
exhibit thereto. Each of them is responsible for the timely filing of such filings and any
amendments thereto, and for the completeness and accuracy of the information concerning such person
contained therein; but none of them is responsible for the completeness or accuracy of the
information concerning the other persons making the filing, unless such person knows or has reason
to believe that such information is inaccurate. This Agreement shall remain in full force and effect
until revoked by any party hereto in a signed writing provided to each other party hereto, and then
only with respect to such revoking party. This Agreement may be executed in any number of
counterparts all of which taken together shall constitute one and the same instrument.

IN WITNESS WHEREOF, the undersigned hereby execute this Joint Filing Agreement as of February 19,
2020. PRAIRIE ECI ACQUIROR LP By: BIP Holdings Manager L.L.C., its general partner

By: /s/ Sean Klimczak Name: Sean Klimczak Title: Senior Managing Director

PRAIRIE NON-ECI ACQUIROR LP By: BIP Holdings Manager L.L.C., its general partner

By: /s/ Sean Klimczak Name: Sean Klimczak Title: Senior Managing Director

PRAIRIE VCOC ACQUIROR LP By: BIP Holdings Manager L.L.C., its general partner

By: /s/ Sean Klimczak Name: Sean Klimczak Title: Senior Managing Director

PRAIRIE SECONDARY ACQUIROR LP By: BIP Holdings Manager L.L.C., its general partner

By: /s/ Sean Klimczak Name: Sean Klimczak Title: Senior Managing Director
<!-- page 2 -->
PRAIRIE SECONDARY ACQUIROR E LP By: BIP Holdings Manager L.L.C., its general partner

By: /s/ Sean Klimczak Name: Sean Klimczak Title: Senior Managing Director

BIP HOLDINGS MANAGER L.L.C.

By: /s/ Sean Klimczak Name: Sean Klimczak Title: Senior Managing Director

BLACKSTONE INFRASTRUCTURE ASSOCIATES L.P. By: BIA GP L.P., its general partner By: BIA GP L.L.C.,
its general partner

By: /s/ Sean Klimczak Name: Sean Klimczak Title: Senior Managing Director

BIA GP L.P. By: BIA GP L.L.C., its general partner

By: /s/ Sean Klimczak Name: Sean Klimczak Title: Senior Managing Director

BIA GP L.L.C.

By: /s/ Sean Klimczak Name: Sean Klimczak Title: Senior Managing Director

BLACKSTONE HOLDINGS III L.P. By: Blackstone Holdings III GP L.P., its general partner By: Blackstone
Holdings III GP Management L.L.C., its general partner

By: /s/ John G. Finley Name: John G. Finley Title: Chief Legal Officer

BLACKSTONE HOLDINGS III GP L.P. By: Blackstone Holdings III GP Management L.L.C., its general
partner

By: /s/ John G. Finley Name: John G. Finley Title: Chief Legal Officer

BLACKSTONE HOLDINGS III GP MANAGEMENT L.L.C.

By: /s/ John G. Finley Name: John G. Finley Title: Chief Legal Officer
<!-- page 3 -->
BLACKSTONE HOLDINGS II L.P. By: Blackstone Holdings I/II GP L.L.C., its general partner By: The
Blackstone Group Inc., its sole member

By: /s/ John G. Finley Name: John G. Finley Title: Chief Legal Officer

BLACKSTONE HOLDINGS I/II GP L.L.C. By: The Blackstone Group Inc., its sole member

By: /s/ John G. Finley Name: John G. Finley Title: Chief Legal Officer

THE BLACKSTONE GROUP INC.

By: /s/ John G. Finley Name: John G. Finley Title: Chief Legal Officer

BLACKSTONE GROUP MANAGEMENT L.L.C.

By: /s/ John G. Finley Name: John G. Finley Title: Chief Legal Officer

STEPHEN A. SCHWARZMAN

By: /s/ Stephen A. Schwarzman By: Stephen A. Schwarzman
