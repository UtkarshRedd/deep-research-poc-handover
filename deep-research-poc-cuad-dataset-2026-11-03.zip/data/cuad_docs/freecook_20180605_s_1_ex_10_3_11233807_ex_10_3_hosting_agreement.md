<!-- page 1 -->
# Website Design, Development and Hosting Agreement
| Field | Value |
|---|---|
| Document Type | Hosting Agreement |
| Agreement Date | 2018-01-11 |
| Parties | FreeCook ("Client"); Mitchell's Web Advance, PLC ("Company") |
| Source | CUAD v1 / Freecook_20180605_S-1_EX-10.3_11233807_EX-10.3_Hosting Agreement |

By Client: /s/ Natalija Tunevic

Website Design, Development and Hosting Agreement

This Website Design, Development and Hosting Agreement the ("Agreement") is entered into on January
11, 2018 by and between Natalija Tunevic, director of FreeCook (hereinafter referred to as "Client")
and Mitchell Vitalis, director of Mitchell's Web Advance, PLC (hereinafter referred to as
"Company").

1. Website Design and Development. Client agrees to pay to Company the sum of $5,000 (the "Contract
Price") to design and develop a website for Client (the "Client Website") in accordance with the
accompanying Scope of Work, attached to this Agreement as Exhibit A.

(a) Change Orders. Any changes to the Scope of Work following the execution of this Agreement
requiring Additional Work must be submitted to and accepted by Company in writing as a "Change
Order". The costs of any such changes shall be added to the Contract Price. Additional Work shall be
defined as the addition or revision of pages, graphics, or other features, any text, graphic or page
design or programming requiring more than two rounds of textual or graphical revisions, substantial
revisions to text and/or content provided by Client, changes to elements which have been finalized,
or significant changes in the Scope of Work.

(b) Due Dates and Delays. Company will use its best efforts to deliver the Client Website in the
time frame specified in the Scope of Work. Terms of the project: 12 weeks from February 8, 2018 to
May 3, 2018. Client acknowledges and agrees that any due dates set forth in the Scope of Work are
subject to delay if Company does not receive the required materials or documentation in a timely
manner or in the required format or if approvals are delayed by Client or if the Scope of Work is
changed by Client.

(c) Client Submitted Content. All written content submitted by Client for use in the Client Website
must be typewritten, proofread and delivered to Company in the body of an email message or as a
Microsoft Word electronic document or plaint text electronic document. Any content submitted by
Client in any other manner or format, including, but not limited to Adobe PDF format, will be
returned to Client for resubmission. Company will not make any attempt to proof read or correct any
contextual, grammatical or typographical errors in the written content submitted by Client. It is
Client's sole responsibility to check the accuracy of the written content and correct any errors
prior to submission for final publication. Company will assume that all the written content
submitted by Client has been proofread and is ready for publication. Client may elect to pay Company
the Hourly Rate set forth below to type and proofread any written content not submitted in the
electronic formats specified above.

(d) Company License and Credit. Client hereby grants to Company a non-exclusive and limited license
to use Client's trade names, logos and other trademarks in connection with Company advertising,
marketing and promotion of its products and services. Client agrees that any unsolicited positive
feedback Client provides to Company may be used in any Company marketing and/or advertising
materials (i.e., customer testimonials). Client further agrees that Company may use and display the
graphics and other web design elements of Client's website as examples of Company website design and
development work. To maintain Company's portfolio credentials, and the integrity of any applicable
copyrights, Company shall be entitled to place an unobtrusive credit in the footer on each page of
Client's website. 2. Payment Terms. Upon the signing of this Agreement, Client agrees to pay to
Company a total of $5,000. Client shall make a prepayment of $1,900 and pay the remaining $3,100 on
completion of the Scope of Work.

3. Business Hours; Rush Work. Company representatives are available during Company's normal business
hours which are 9 a.m. to 5 p.m. UTC +2, Monday through Friday. Any email or telephone
correspondence received after normal business hours will be processed the following business day.
Client shall pay an additional surcharge for any services requiring work to be performed outside of
normal business hours by reason of a rush deadline requested by Client or as a result of Client's
failure to meet scheduled times for delivery and/or review and approval of information, content and
materials. The surcharge for rush work shall be the standard hourly rate of $40 plus twenty-five
percent (25%).

4. Customer Service. Company, either directly or through its authorized service provider, shall
provide customer service (the "Customer Service") relating to Client Website consisting of replying
to customer questions or complaints regarding website hosting services during the normal business
hours set forth. Company is not obligated to provide any Customer Service except as specified in
this Section. Company at its sole discretion may at any time alter or cease providing the Customer
Service which it has agreed to provide to Client relating to Client Website pursuant to this
Agreement without any liability to Company.

AGREED AND ACCEPTED:

Date: Jan. 11, 2018

Source: FREECOOK, S-1, 6/5/2018
<!-- page 2 -->
By Company: /s/ Mitchell Vitalis Date: Jan. 11, 2018

Mitchell's Web Advance - Website Design, Development and Hosting Agreement Page 1 of 2 Client: /s/
Natalija Tunevic Company: /s/ Mitchell Vitalis

Source: FREECOOK, S-1, 6/5/2018

Mitchell's Web Advance Website Design, Development and Hosting Agreement
<!-- page 3 -->
Exhibit A

Scope of Work Development of design of Free Cook

Stage 1: 1. Search for competitors, collecting additional information on the subject. 2. Development
of unique style of the Client Website. 3. Development of a logo based on the unique corporate style.
4. Designing UI/UX-practical parts. 5. Development of the main and internal pages of the Client
Website.

Stage 2: 6. Emotional design (creation of web-assistants). 7. Adaptive design (mobile version of the
Client Website). 8. Design adaptation to other languages. 9. Development of a prototype and
interface testing.

Stage 3: 10. Search Engine Optimization.

Mitchell's Web Advance - Website Design, Development and Hosting Agreement Page 2 of 2 Client: /s/
Natalija Tunevic Company: /s/ Mitchell Vitalis

Source: FREECOOK, S-1, 6/5/2018
