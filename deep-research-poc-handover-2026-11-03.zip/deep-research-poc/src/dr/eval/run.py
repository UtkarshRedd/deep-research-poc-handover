"""Eval runner (PLAN Phase 6).

    python -m dr.eval.run --variant A1_deep_list --golden data/golden/cuad_questions.jsonl --docs data/cuad_docs
    python -m dr.eval.run --variant A2_fs_agent --golden data/golden/questions.jsonl --docs data/golden_docs --limit 10
    python -m dr.eval.run --dry --golden ... --docs ...      # list questions with resolved gold ids

Runs one variant over the golden set with a thread pool (keep `--concurrency` within the endpoint's
rate limit), scores every question with the deterministic metrics in `dr.eval.metrics` plus the
LLM judge (disable with `--no-judge`), and writes:

    eval/results/<variant>-<ts>.jsonl        one row per question
    eval/results/<variant>-<ts>.summary.md   per-slice table (also printed)
    eval/results/runs/<variant>-<ts>/<qid>/  the run folder (report.md, verify.json, trace, evidence)

A question that raises is recorded with `error` and never stops the batch.
"""
from __future__ import annotations

import argparse
import json
import time
import traceback
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from typing import Any

from ..config import DEFAULT, Config
from ..graph import IMPLEMENTED_VARIANTS, VARIANTS, Pipeline
from ..models import VerifyResult
from ..structured import ModelCaller
from .golden import GoldenQuestion, load_golden
from .metrics import (
    abstention,
    citation_support_rate,
    contains_answer,
    gap_rate,
    gold_page_cited,
    hallucination_gate,
    item_recall,
    judge_correctness,
    recall,
    render_summary,
    summarize,
)

ALL_VARIANTS = sorted(set(VARIANTS) | {"A3_fanout", "A3_grid_only", "LC_small"})


def _trace_totals(root: Path) -> dict[str, Any]:
    p = root / "trace.jsonl"
    n_model = n_tool = 0
    in_t = out_t = 0
    if p.exists():
        for ln in p.read_text(encoding="utf-8").splitlines():
            if not ln.strip():
                continue
            e = json.loads(ln)
            if e["kind"] == "model":
                n_model += 1
                in_t += e.get("in_tokens") or 0
                out_t += e.get("out_tokens") or 0
            elif e["kind"] == "tool":
                n_tool += 1
    return {"n_model_calls": n_model, "tool_calls": n_tool, "in_tokens": in_t, "out_tokens": out_t}


def evaluate_question(q: GoldenQuestion, docs, variant: str, config: Config, llms: dict | None,
                      run_root: Path, judge: bool) -> dict[str, Any]:
    row: dict[str, Any] = {"qid": q.qid, "type": q.type, "variant": variant, "question": q.question,
                           "gold_doc_ids": [d.doc_id for d in q.gold_docs], "run_root": str(run_root), "error": None}
    t0 = time.time()
    try:
        p = Pipeline(config, llms)
        state = p.run(q.question, docs, variant=variant, root=run_root)
        rid = state["run_id"]
        bank, tracker, fm = p.banks[rid], p.trackers.get(rid), p.first_moves.get(rid)
        results = [VerifyResult(**v) for v in state["verify"]]
        finding = state["findings"][0] if state["findings"] else None
        gold_ids = {d.doc_id for d in q.gold_docs}
        opened = (set(tracker.docs_read()) if tracker else set()) | bank.doc_ids()
        report = state["report_md"] or ""
        abst = abstention(q.type, bool(finding and finding.get("not_in_corpus")))
        row.update({
            "wall_s": round(time.time() - t0, 1), "stage_ms": state["stage_ms"], "research_done": state["research_done"],
            "partial": state["partial"], "route": (state.get("route") or {}).get("mode"), "errors": state["errors"],
            "candidate_recall": recall(gold_ids, set(fm.candidate_doc_ids)) if fm else None,
            "opened_or_cited_recall": recall(gold_ids, opened),
            "gold_page_cited": gold_page_cited([(d.doc_id, d.pages) for d in q.gold_docs], bank.all()),
            "n_claims": len(results), "support_rate": citation_support_rate(results),
            "gate_fail": hallucination_gate(results), "gap_rate": gap_rate(results),
            "contains_answer": None if q.type == "not_in_corpus" else contains_answer(q.gold_answer, report),
            "item_recall": item_recall(q.gold_items, report),
            "abstained": abst["abstained"], "abstention_correct": abst["correct"],
            "n_evidence": len(bank), "report_chars": len(report),
            **_trace_totals(run_root),
        })
        if judge:
            jl = (llms or {}).get("judge")
            if jl is None:
                from ..llm import get_llm

                jl = get_llm("judge")
            from ..trace import Trace

            jtrace = Trace(run_root / "trace.jsonl", rid)   # the pipeline closed its handle; append the judge call
            try:
                verdict = judge_correctness(q.question, q.gold_answer, q.rubric, report,
                                            ModelCaller(jl, jtrace, "judge", "judge"))
            finally:
                jtrace.close()
            row.update({"judge_verdict": verdict["verdict"], "judge_score": verdict["score"],
                        "rubric_hits": verdict["rubric_hits"], "rubric_rate": verdict["rubric_rate"],
                        "judge_reason": verdict["reason"]})
    except Exception as e:  # noqa: BLE001 - one bad question must not sink the batch
        row["error"] = f"{type(e).__name__}: {e}"[:500]
        row["traceback"] = traceback.format_exc()[-2000:]
        row["wall_s"] = round(time.time() - t0, 1)
    return row


def run_eval(questions: list[GoldenQuestion], docs, variant: str, config: Config = DEFAULT,
             llms: dict | None = None, out_dir: Path = Path("eval/results"), concurrency: int = 2,
             judge: bool = True, tag: str | None = None, stop_after_errors: int = 5,
             resume: Path | None = None) -> tuple[list[dict], dict, dict[str, Path]]:
    """`stop_after_errors`: abort the batch after that many CONSECUTIVE failed questions (a dead
    endpoint or an exhausted quota must not burn an hour producing error rows); 0 disables.
    `resume`: an earlier results file; its rows that completed (a submission and, with the judge on,
    a verdict) are copied into the new file and their questions are not run again."""
    if variant not in IMPLEMENTED_VARIANTS:
        raise NotImplementedError(f"variant {variant!r} is not implemented (have {sorted(IMPLEMENTED_VARIANTS)})")
    tag = tag or f"{variant}-{time.strftime('%Y%m%d-%H%M%S')}"
    out_dir = Path(out_dir)
    runs_dir = out_dir / "runs" / tag
    runs_dir.mkdir(parents=True, exist_ok=True)
    jsonl = out_dir / f"{tag}.jsonl"
    kept: dict[str, dict] = {}
    if resume and Path(resume).exists():
        for ln in Path(resume).read_text(encoding="utf-8").splitlines():
            if not ln.strip():
                continue
            r = json.loads(ln)
            # only clean completions are reused: a forced or deadline submission under throttling is not
            # the pipeline's real answer, so those questions run again
            complete = (not r.get("error") and r.get("research_done") == "submitted"
                        and (not judge or r.get("judge_verdict") not in (None, "unknown")))
            if complete and r.get("variant") == variant:
                kept[r["qid"]] = {**r, "resumed_from": str(resume)}
        print(f"resume: {len(kept)} completed rows reused from {resume}", flush=True)
    todo = [q for q in questions if q.qid not in kept]
    with ThreadPoolExecutor(max_workers=max(1, concurrency)) as ex, jsonl.open("w", encoding="utf-8") as f:
        rows = [kept[q.qid] for q in questions if q.qid in kept]
        for row in rows:
            f.write(json.dumps(row, default=str) + "\n")
        f.flush()
        futures = [ex.submit(evaluate_question, q, docs, variant, config, llms, runs_dir / q.qid, judge) for q in todo]
        streak = 0
        for fut in futures:
            row = fut.result()
            rows.append(row)
            f.write(json.dumps(row, default=str) + "\n")
            f.flush()
            status = row["error"] or f"{row.get('research_done')} judge={row.get('judge_verdict', '-')}"
            print(f"{row['qid']:<8} {row['type']:<14} {row.get('wall_s', 0):>6}s  {status}", flush=True)
            failed = bool(row["error"]) or row.get("research_done") == "model_error"   # a dead endpoint degrades gracefully
            streak = streak + 1 if failed else 0
            if stop_after_errors and streak >= stop_after_errors:
                print(f"stopping: {streak} consecutive failures (last: {(row['error'] or row.get('research_done'))[:120]})", flush=True)
                for other in futures:
                    other.cancel()
                break
    summary = summarize(rows)
    md = render_summary(summary, variant)
    (out_dir / f"{tag}.summary.md").write_text(md, encoding="utf-8")
    print("\n" + md)
    return rows, summary, {"jsonl": jsonl, "summary": out_dir / f"{tag}.summary.md", "runs": runs_dir}


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--golden", default="data/golden/questions.jsonl")
    ap.add_argument("--variant", default="A2_fs_agent", choices=ALL_VARIANTS)
    ap.add_argument("--docs", default="data/golden_docs", help="directory of parsed markdown (the upstream filter's output)")
    ap.add_argument("--dry", action="store_true", help="list the questions (with gold ids resolved) and exit")
    ap.add_argument("--concurrency", type=int, default=2)
    ap.add_argument("--limit", type=int, default=None, help="first N questions after filtering")
    ap.add_argument("--qids", default=None, help="comma-separated question ids")
    ap.add_argument("--types", default=None, help="comma-separated question types")
    ap.add_argument("--no-judge", action="store_true")
    ap.add_argument("--out", default="eval/results")
    ap.add_argument("--stop-after-errors", type=int, default=5, help="abort after N consecutive failed questions (0 = never)")
    ap.add_argument("--resume", default=None, help="earlier results .jsonl: reuse its completed rows, run only the rest")
    args = ap.parse_args()

    from ..ingest.load import load_dir

    docs = load_dir(Path(args.docs))
    qs = load_golden(Path(args.golden), docs=docs)
    if args.qids:
        want = {x.strip() for x in args.qids.split(",")}
        qs = [q for q in qs if q.qid in want]
    if args.types:
        want_t = {x.strip() for x in args.types.split(",")}
        qs = [q for q in qs if q.type in want_t]
    if args.limit:
        qs = qs[: args.limit]
    if args.dry:
        for q in qs:
            print(f"{q.qid:<6} {q.type:<14} gold={[d.doc_id for d in q.gold_docs]}  {q.question[:80]}")
        print(f"\n{len(qs)} questions over {len(docs)} docs; types: "
              f"{ {t: sum(1 for q in qs if q.type == t) for t in sorted({q.type for q in qs})} }")
        return
    print(f"{args.variant}: {len(qs)} questions over {len(docs)} docs, concurrency {args.concurrency}, "
          f"judge {'off' if args.no_judge else 'on'}\n")
    run_eval(qs, docs, args.variant, out_dir=Path(args.out), concurrency=args.concurrency, judge=not args.no_judge,
             stop_after_errors=args.stop_after_errors, resume=Path(args.resume) if args.resume else None)


if __name__ == "__main__":
    main()
