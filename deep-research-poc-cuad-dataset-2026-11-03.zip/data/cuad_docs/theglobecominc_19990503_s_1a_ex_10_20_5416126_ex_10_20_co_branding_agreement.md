<!-- page 1 -->
# CO-BRANDING Agreement
| Field | Value |
|---|---|
| Document Type | Co-Branding Agreement |
| SEC Filing Date | 1999-05-03 |
| Parties | theglobe.com, Inc. ("theglobe"); The Boxlot Company ("Boxlot") |
| Source | CUAD v1 / TheglobeComInc_19990503_S-1A_EX-10.20_5416126_EX-10.20_Co-Branding Agreement |

EXHIBIT 10.20

CO-BRANDING Agreement

This Co-Branding Agreement (the "Agreement") is entered into as of March ___, 1999 (the "Effective
Date") by and between theglobe.com, Inc., with its principal place of business at 31 West 21st
Street, New York, NY 10010 ("theglobe"), and The Boxlot Company, with its principal place of
business at 12626 High Bluff Drive, Suite 370, San Diego, CA 92130 ("Boxlot").

1. DEFINITIONS.

(a) "Boxlot Banners" means any banner, button, text or similar ads Boxlot provides to theglobe in
connection with this Agreement.

(b) "Boxlot Content" means any content or information (including without limitation any text, music,
sound, photographs, video, graphics, data or software), in any medium, provided by Boxlot to
theglobe (other than Boxlot Banners), as part of the Service or on the Co-Branded Pages, including
any content specified in Exhibit A.

(c) "Boxlot Marks" means all Boxlot domain names, trademarks, logos, and other graphics reasonably
necessary or desirable for theglobe to perform under this Agreement.

(d) "Boxlot Site" means the Boxlot-branded (i.e., non-co-branded) version of the Service and
associated pages.

(e) "Co-Branded Pages" means all pages of the Service (including, without limitation, any Java
screens associated with the Service or emails or other direct communications sent to Users by
operation of the Service).

(f) "Domain Name" means the domain name described in Exhibit A.

(g) "Launch Date" means the first date on which the Service is made publicly available.

(h) "Marks" means the Boxlot Marks or theglobe Marks, as applicable.

(i) "Net Revenues" means all monetary consideration theglobe actually receives for CPM- or CPC-based
advertisements and promotions (other than those for its commerce partners) delivered in connection
with the Co-Branded Pages, less a sales and administration fee of 15%.

(j) "Page Templates" means theglobe's standard page layout templates, as revised by theglobe from
time to time.

(k) "Service" means the services described in Exhibit A, as changed over time in accordance with
this Agreement, which are co-branded using the Page Templates. The Service

1

also includes any Boxlot-operated back-end administration tools or pages used by theglobe or Boxlot
to exchange data in accordance with this Agreement.

(l) "Shadow Site" means the password-protected site where the Co-Branded Pages are made available
for theglobe's review and approval prior to being made publicly available.

(m) "theglobe Marks" means all theglobe domain names, trademarks, logos, and other graphics
reasonably necessary or desirable for Boxlot to perform under this Agreement.

(n) "theglobe Site" means all pages under the theglobe.com domain.

(o) "User" means any person who accesses any Co-Branded Page.

2. DEVELOPMENT AND IMPLEMENTATION.

2.1 Pre-Launch Deliverables. On or around March 31, 1999, theglobe shall deliver to Boxlot the Page
Templates and the other materials specified in Exhibit A.

2.2 Initial Development. Boxlot shall develop the Co-Branded Pages using the Page Templates and take
all other steps required to co-brand the Service in accordance with Exhibit A. In addition, if
theglobe is passing any user data to Boxlot, theglobe's standard Automatic Partner Registration
procedure shall apply, and Boxlot shall perform the development necessary to use such procedure. The
current Automatic Partner Registration procedure is described in Exhibit D. Boxlot shall make the
Service implementation available to theglobe on the Shadow Site prior to making it publicly
available. Boxlot shall not make the initial Service implementation publicly available without
theglobe's prior written approval. Unless otherwise specified, each party shall be responsible for
all development, hosting and other costs associated with the pages living on their servers and all
emails they send.

2.3 Changes. theglobe shall have sole control over the Service's look and feel, and Boxlot shall not
make any change in the Service's look and feel without theglobe's prior consent. Further, Boxlot
shall notify theglobe if Boxlot changes or adds any functionality of the services described in
Exhibit A (as modified by Boxlot over time) as implemented on the Boxlot Site. Unless requested by
theglobe, Boxlot shall implement such changes or additions to the Service and make such
implementation available on the Shadow Site for theglobe's approval within 30 days of their
introduction on the Boxlot Site. However, under no circumstances shall Boxlot offer Users any
community features (such as email, chat, message boards, or the ability to create home pages) from
the Co- Branded Pages without theglobe's consent, and if Boxlot desires to do so, the parties will
work together to discuss appropriate implementations. Boxlot shall make available via the Shadow
Site all changes to the Service or the Co-Branded Pages completed in this Section 2, and Boxlot
shall not implement such changes on the publicly available Service or Co-Branded Pages until it has
received theglobe's approval.

2.4 Service Operation. Boxlot shall host and operate the Service under

Source: THEGLOBE COM INC, S-1/A, 5/3/1999
<!-- page 2 -->
the Domain Name in accordance with the terms of Exhibit B.

2

2.5 Rebranding. If requested by theglobe, Boxlot shall implement on the Co-Branded Pages new
versions of the Page Templates if theglobe changes the Page Templates across theglobe Site
generally. Further, if requested by theglobe, Boxlot shall create additional branded versions of the
Service and Co-Branded Pages branded with the branding of theglobe's distribution partners, which
branded versions shall be implemented within 30 days and subject to approval in accordance with this
Section 2.

2.6 Boxlot Content. Boxlot shall provide Boxlot Content to Users via the Co-Branded Pages, except
that Boxlot shall deliver to theglobe those elements of Boxlot Content residing on theglobe's
servers in accordance with the terms of Exhibit A. Unless otherwise directed by theglobe, the
Co-Branded Pages shall include all of the content displayed on the Boxlot Site, and the Boxlot
Content shall be updated to keep the Co-Branded Pages in parity with the Boxlot Site. Any
nonconformance with the terms of the frequency/quantity columns of Exhibit A shall permit theglobe
to terminate immediately if the breach is not cured within 12 hours.

2.7 Navigation. Boxlot shall not, in conjunction with the Service, use any interstitials, pop-up
windows, other intermediate steps or any other technology or content which acts as a barrier to the
transition of a User from theglobe Site to the Co-Branded Pages, nor shall Boxlot otherwise frame
the Co-Branded Pages or use any other technology which interferes with or affects the page layout of
such pages. All Co-Branded Pages shall link back to theglobe Site as specified by theglobe.

2.8 User Relations. Boxlot shall be responsible for providing all customer support regarding the
Service or the Co-Branded Pages, and theglobe may redirect to Boxlot any associated customer support
inquiries. Boxlot shall have sole control over the user agreement that governs the Service, and
Boxlot shall have the sole responsibility for dealing with breaches of such user agreement. However,
if theglobe has an issue with the user agreement or Boxlot's enforcement of it, the parties shall
discuss such issues in good faith. Furthermore, Boxlot's privacy policy shall make any disclosures,
or obtain any User consent, reasonably requested by theglobe that the parties believe are necessary
to make the disclosures about Users back to theglobe required by this Agreement. All Users shall be
treated at least as favorable in all respects (including without limitation with respect to pricing,
quality of service, and customer support responsiveness) as Boxlot treats users of the Boxlot Site.

2.9 Database Synchronization. If requested by theglobe and if Boxlot captures relevant information,
Boxlot shall use reasonable efforts to cooperate with theglobe to implement ways for theglobe to
capture User information to the extent that such information would change the relevant information
in theglobe's databases.

2.10 Promotions. Following the Launch Date, the parties shall conduct the promotions specified in
Exhibit A.

3. ADVERTISING.

3

3.1 Ad Sales. theglobe shall have sole control over all advertising and promotion inventory on the
Co-Branded Pages. Boxlot shall not introduce any advertising spots or third party branding in
conjunction with the Co-Branded Pages or the Service without theglobe's approval. If, after theglobe
(or its designee) uses commercially reasonable efforts to sell such inventory, there remains unsold
inventory, then theglobe may, in its sole discretion, place house or barter ads in such inventory.

3.2 Ad Serving. theglobe or its designee shall be solely responsible for serving all advertisements
and promotions in connection with the Co-Branded Pages. theglobe shall provide Boxlot with ad
serving code, which Boxlot shall implement at its own expense on all Co-Branded Pages. theglobe
hereby grants to Boxlot a nonexclusive license to use such code solely to permit theglobe or its
designee to serve ads in connection with the Co-Branded Pages. Boxlot shall notify theglobe at least
15 days prior to making any changes that would affect serving ads on the Co-Branded Pages.

3.3 Boxlot Banners. Boxlot shall deliver to theglobe any Boxlot Banners which are to be run in
accordance with this Agreement. Such banners shall comply with theglobe's then-current technical
standards. The terms of any insertion order or similar document regarding the Boxlot Banners are
expressly rejected, except to the extent that they specify the location, timing or duration of the
display of the Boxlot Banners and such terms are accepted by theglobe. Unless mutually agreed
otherwise, Boxlot Banners shall link to the Co-Branded Pages. theglobe may request that Boxlot
Banners be co-branded with theglobe Marks, in which case the parties shall work together to develop
a mutually acceptable implementation. theglobe may approve or reject any Boxlot Banner in its sole
discretion. theglobe shall use commercially reasonable efforts not to run banners on the Co-Branded
Pages for the companies enumerated on Exhibit C. Boxlot may update Exhibit C from time to time
during the term; however: (a) Boxlot may not add any site or company to Exhibit C which is not
reasonably considered to be in the online auctions business, and (b) if Boxlot adds any new sites or
companies to Exhibit C, theglobe shall be entitled to complete any contractual obligations pursuant
to contracts in place with such sites or companies at the time of addition.

4. LICENSES AND STANDARDS.

4.1 Content. Boxlot hereby grants to theglobe a non-exclusive, worldwide license to use, reproduce,
create derivative works of (only as necessary to build pages in a manner consistent with this
Agreement), publicly display, publicly perform and digitally perform Boxlot Banners, and those
elements of the Boxlot Content served from theglobe's servers (as denoted in Exhibit A), on theglobe
Site or otherwise as reasonably appropriate to advertise and promote the Service and the Co-Branded
Pages. Subject to the approval process in Section 2, theglobe hereby grants to Boxlot a
non-exclusive, worldwide license to use, reproduce, create derivative works of (only as necessary to
build Co- Branded Pages), publicly display, publicly perform and digitally perform the Page
Templates on Co-Branded Pages.

4.2 Trademarks. Boxlot hereby grants to theglobe a non-exclusive license to use the Boxlot Marks
(including the Domain Name if applicable) to advertise

Source: THEGLOBE COM INC, S-1/A, 5/3/1999

and promote the Service.

4
<!-- page 3 -->
theglobe hereby grants to Boxlot a non-exclusive license to use theglobe Marks (including the Domain
Name if applicable) on the Co-Branded Pages.

4.3 Trademark Restrictions. The Mark owner may terminate the foregoing trademark license if, in its
reasonable discretion, the licensee's use of the Marks tarnishes, blurs or dilutes the quality
associated with the Marks or the associated goodwill and such problem is not cured within 10 days of
notice of breach; alternatively, instead of terminating the license in total, the owner may specify
that certain licensee uses may not contain the Marks. Title to and ownership of the owner's Marks
shall remain with the owner. The licensee shall use the Marks exactly in the form provided and in
conformance with any trademark usage policies. The licensee shall not take any action inconsistent
with the owner's ownership of the Marks, and any benefits accruing from use of such Marks shall
automatically vest in the owner. The licensee shall not form any combination marks with the other
party's Marks other than the Domain Name (if applicable). If the Domain Name is deemed a combination
mark, neither party shall use the Domain Name for any purpose except as expressly provided herein or
attempt to register the Domain Name, and the parties will jointly cooperate on any enforcement
action of infringement of the Domain Name.

4.4 Ownership. As between theglobe and Boxlot: (a) theglobe and its suppliers retain all rights,
title and interest in and to all intellectual property rights embodied in or associated with the
Page Templates, and (b) Boxlot and its suppliers retain all rights, title and interest in and to all
intellectual property rights embodied in or associated with the Boxlot Content, Boxlot Banners and
Boxlot Marks. There are no implied licenses under this Agreement, and any rights not expressly
granted to a licensee hereunder are reserved by the licensor or its suppliers. Neither party shall
exceed the scope of the licenses granted hereunder.

4.5 Standards. Boxlot shall not provide Boxlot Banners or Boxlot Content, and theglobe shall not
provide to Boxlot any Page Templates, that: (a) infringe any third party's intellectual property
right or right of publicity or privacy; (b) violate any law or regulation; (c) are defamatory,
obscene, harmful to minors or child pornographic; (d) contain any viruses, trojan horses, worms,
time bombs, cancelbots or other computer programming routines that are intended to damage,
detrimentally interfere with, surreptitiously intercept or expropriate any system, data or personal
information; or (e) are materially false, inaccurate or misleading.

5. USER DATA.

5.1 Rights/Restrictions. Except as specified in this section, each party may freely use and disclose
any information (both individual and aggregated) about Users ("User Data"). Neither party shall
disclose any User Data in any manner that permits the User Data to be associated with the other
party or permits the targeting of Users on the basis of their status as Users (in theglobe's case)
or theglobe users (in Boxlot's case), nor shall a party use the User Data to target Users on the
basis of their status as Users (in theglobe's case) or theglobe users (in Boxlot's case). However,
either party may disclose User Data if it is aggregated (in a non-associatable way) with data from
multiple online properties. Each party shall use and disclose User Data only in accordance with the
privacy policy under which it was collected.

5

5.2 Delivery to theglobe. Boxlot shall deliver to theglobe all information about Users who register
with Boxlot on the Co-Branded Pages that Boxlot collects from its registration process. Such
information shall be delivered weekly in an electronic format specified by theglobe using a process
reasonably specified by theglobe.

6. PAYMENT TERMS.

6.1 Payments. The parties shall make the payments described in Exhibit A. Overdue payments shall
accrue interest, at the lesser of 1 1/2% per month or the maximum allowable interest under
applicable law, from due date until paid, and the owing party shall pay the owed party's costs of
collection (including reasonable attorneys' fees).

6.2 Taxes. All fees and payments stated herein exclude, and the party making payment shall pay, any
sales, use or other tax related to the parties' performance of their obligations or exercise of
their rights under this Agreement, exclusive of taxes based on the receiving party's net income.

6.3 Audit Rights. A party obligated to make payments hereunder shall keep for 3 years proper records
and books of account relating to the computation of such payments. Once every 12 months, the party
receiving payment or its designee may inspect such records to verify reports. Any such inspection
will be conducted in a manner that does not unreasonably interfere with the inspected party's
business activities. The inspected party shall immediately make any overdue payments disclosed by
the audit plus applicable interest. Such inspection shall be at the inspecting party's expense;
however, if the audit reveals overdue payments in excess of 5% of the payments owed to date, the
inspected party shall immediately pay the cost of such audit, and the inspecting party may conduct
another audit during the same 12 month period.

7. REPORTS.

7.1 By theglobe. Within 30 days following the end of each month, theglobe shall provide Boxlot with
its standard reports regarding theglobe's promotions hereunder and reports on the computation of Net
Revenues.

7.2 By Boxlot. In addition to any other reports specified herein, Boxlot shall provide to theglobe
the following reports: (a) daily usage reports regarding the Co-Branded Pages describing the number
of page impressions, number of Users and such other information as Boxlot generally provides to its
other similar partners, (b) weekly demographic reports regarding the Service containing summary
information regarding user demographic profiles, and (c) if applicable, within 30 days following the
end of each month, reports regarding the computation of the fees it owes under Section 6.

In addition to the foregoing, as soon as commercially reasonable (but in no event later than 6
months following the Launch Date), Boxlot (with assistance as

Source: THEGLOBE COM INC, S-1/A, 5/3/1999
<!-- page 4 -->
necessary from theglobe) shall deliver reports to theglobe about individual registered Users on the
Co-Branded Pages when the User bids on an item, purchases an item, lists an item for sale and
successfully sells an item. The report shall be broken down into at least the following categories:
the User's unique UserID

6

number assigned by theglobe, the action being logged (bid, purchase, list, sale), the date and time
of the event, and the topic/category in which the event occurred. Such reports shall be provided to
theglobe on at least a monthly basis in an electronic format that is easily decoded in an automated
manner for import into theglobe's statistics database, and the file shall be a delimited text file
with each line corresponding to an event and including the information outlined above.

8. TERM AND TERMINATION.

8.1 Term. This Agreement will become effective on the Effective Date and will continue in effect for
2 years following the Launch Date.

8.2 Termination for Failure to Perform. By providing written notice, a party may immediately
terminate this Agreement: (a) if the other party materially breaches this Agreement and fails to
cure that breach within 15 days after receiving written notice of the breach, or (b) as provided in
Sections 2.6 [Boxlot Content] or 12.7 [Force Majeure] or Exhibit B. In addition, by providing
written notice, theglobe may immediately terminate this Agreement, or at its option immediately
suspend its promotion and other efforts hereunder, in the case of Boxlot's breach of Section 12.1
[Compliance with Laws].

8.3 Termination for Change of Control. By providing written notice, theglobe may terminate this
Agreement in its sole discretion if one of the following companies (or their subsidiaries) does an
"Ownership Change Event": Lycos, Yahoo (including GeoCities, which shall be included even if their
proposed merger does not occur), Xoom, Fortune City, Excite, Go Network (including Disney and
Infoseek), Snap! (including NBC) and AOL. An "Ownership Change Event" means: (x) the acquisition of
50% or more of Boxlot's equity or voting interests; (y) a merger or consolidation of Boxlot; or (z)
the sale, exchange or transfer of all or substantially all of Boxlot's assets related to the
Service.

8.4 Termination for Changes. By providing written notice, theglobe may terminate this Agreement in
its sole discretion if: (a) Boxlot's business model changes such that the Service is no longer
Boxlot's primary line of business, or (b) at the one year anniversary of the Launch Date, the
Service is significantly inferior to the comparable services being offered by the market leaders in
the person to person auction space.

8.5 Termination for Failure to Grow. By providing written notice, Boxlot may immediately terminate
this Agreement if theglobe's registered user base has not increased by *** users by the 1 year
anniversary of the Effective Date.

8.6 Effects of Termination. Upon expiration or termination, all licenses granted hereunder shall
terminate unless such licenses are expressly stated as surviving. Boxlot shall promptly remove all
theglobe Marks and Page Templates from its servers, and theglobe shall promptly remove all Boxlot
Marks, Boxlot Banners and Boxlot Content from its servers. Sections 1, 4.4 [Ownership], 5.1
[Rights/Restrictions], 6.2 [Taxes], 6.3 [Audit Rights], 8.6 [Effects of Termination], 9, 10, 11 and
12.2 [Governing Law] to 12.9 [Entire Agreement; Waiver], and any obligation to pay any owed but
unpaid amounts, shall survive any expiration or termination.

7

In addition, Boxlot acknowledges that the placement fees set forth in Exhibit A were intended to be
*** in year 1 and *** in year 2, even though theglobe has agreed to extend credit terms to Boxlot by
allowing Boxlot to pay over time. Thus, in the event that this Agreement terminates under Section
8.2 [Termination for Failure to Perform] due to Boxlot's failure to perform (excluding the
cross-reference to Section 12.7 [Force Majeure]) prior to the end of the applicable year, Boxlot
shall immediately pay to theglobe the amount necessary to pay the total year's placement fee for
that year. Boxlot waives any right to assert that the foregoing fee is a liquidated damage or a
penalty.

9. NO WARRANTIES. EACH PARTY PROVIDES ALL MATERIALS AND SERVICES TO THE OTHER PARTY "AS IS." EACH
PARTY DISCLAIMS ALL WARRANTIES AND CONDITIONS, EXPRESS, IMPLIED OR STATUTORY, INCLUDING WITHOUT
LIMITATION THE IMPLIED WARRANTIES OF TITLE, NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A
PARTICULAR PURPOSE. Each party acknowledges that it has not entered into this Agreement in reliance
upon any warranty or representation except those specifically set forth herein. Unless an approval
process is specified herein, all deliverables provided by one party to the other shall be deemed
accepted (for purposes of the UCC) when delivered.

10. INDEMNITY. Each party (the "Indemnifying Party") shall indemnify the other party (the
"Indemnified Party") against any and all claims, losses, costs and expenses, including reasonable
attorneys' fees, which the Indemnified Party may incur as a result of claims in any form by third
parties arising from: (x) the Indemnifying Party's acts, omissions or misrepresentations to the
extent that the Indemnifying Party is deemed an agent of the Indemnified Party, or (y) the
Indemnifying Party's breach of its privacy policy. In addition, theglobe shall indemnify Boxlot
against any and all claims, losses, costs and expenses, including reasonable attorneys' fees, which
Boxlot may incur as a result of claims in any form by third parties arising from the Page Templates
or theglobe Marks. In addition, Boxlot shall indemnify theglobe against any and all claims, losses,
costs and expenses, including reasonable attorneys' fees, which theglobe may incur as a result of
claims in any form by third parties arising from Boxlot Banners, Boxlot Content, Boxlot Marks, the
Service (excluding the Page Templates or theglobe Marks) or Boxlot's breach of Section 12.1
[Compliance with Laws]. The foregoing obligations are conditioned on the Indemnified Party: (i)
giving the Indemnifying Party notice of the relevant claim, (ii) cooperating with the Indemnifying
Party, at the Indemnifying Party's expense, in the defense of such claim, and (iii) giving the
Indemnifying Party the right to control the defense and settlement of any such claim, except that
the Indemnifying Party shall not enter into any settlement that affects the Indemnified Party's
rights or interest without the Indemnified Party's prior written approval. The Indemnified Party
shall have the right to participate in the defense at its expense.

11. LIABILITY LIMITS. NEITHER PARTY SHALL BE LIABLE FOR LOST PROFITS OR SPECIAL, INCIDENTAL OR
CONSEQUENTIAL DAMAGES (HOWEVER ARISING, INCLUDING

Source: THEGLOBE COM INC, S-1/A, 5/3/1999
<!-- page 5 -->
NEGLIGENCE) ARISING OUT OF OR IN CONNECTION WITH THIS AGREEMENT, EVEN IF THE PARTIES ARE AWARE OF
THE POSSIBILITY OF SUCH DAMAGES.

EXCEPT IN THE EVENT OF A CLAIM UNDER SECTION 10 OR FAILURE TO PAY UNDER SECTION 6, IN NO EVENT SHALL
EITHER PARTY BE LIABLE TO THE

8

OTHER PARTY IN AN AMOUNT GREATER THAN THE AMOUNT BOXLOT ACTUALLY PAYS TO THEGLOBE HEREUNDER.

12. GENERAL.

12.1 Compliance with Laws. At its own expense, Boxlot shall comply with all applicable laws and
regulations regarding providing and operating the Service. Without limiting the foregoing, Boxlot
shall (a) obtain all governmental approval, permits and licenses, and make all governmental filings
and registrations, necessary for the marketing and performance of the Service in every United States
jurisdiction, (b) ensure that theglobe is not required to obtain any governmental approval, permits
or licenses as a result of this Agreement, theglobe's performance hereunder or any payments made to
theglobe hereunder, and (c) promptly resolve any assertions that the Service is illegal or violating
a protected third party interest.

12.2 Governing Law. This Agreement will be governed and construed in accordance with the laws of the
State of New York without giving effect to conflict of laws principles. Both parties submit to
personal jurisdiction in New York and further agree that any cause of action arising under this
Agreement shall be brought in a court in New York City, NY.

12.3 Publicity. Prior to the release of any press releases or other similar promotional materials
related to this Agreement, the releasing party shall submit a written request for approval to the
other party with a copy of the materials to be released, which request shall be made no less than 3
business days prior to the requested release date. A party shall not unreasonably withhold or delay
the granting of its approval of such materials. The parties shall issue the first press release
jointly.

12.4 Independent Contractors. The parties are independent contractors, and no agency, partnership,
franchise, joint venture or employment relationship is intended or created by this Agreement.
Neither party shall make any warranties or representations on behalf of the other party.

12.5 Assignment. Neither party may assign its rights or delegate its duties hereunder (except to an
affiliated company, or to a successor in interest in the event of a merger, sale of assets of the
business to which this Agreement is related, or consolidation) without the other party's prior
written consent, and any purported attempt to do so is null and void.

12.6 Severability; Headings. If any provision herein is held to be invalid or unenforceable for any
reason, the remaining provisions will continue in full force without being impaired or invalidated
in any way. The parties agree to replace any invalid provision with a valid provision that most
closely approximates the intent and economic effect of the invalid provision. Headings are for
reference purposes only and in no way define, limit, construe or describe the scope or extent of
such section.

12.7 Force Majeure. Except as otherwise provided, if performance hereunder (other than payment) is
interfered with by any condition beyond a party's reasonable control, the affected party, upon
giving prompt notice to the other party, shall be excused from such performance to

9

the extent of such condition. However, if a force majeure detrimentally affects a party's
performance of a material covenant hereunder for 14 days or more, the other party can terminate this
Agreement. Each party acknowledges that website operations may be affected by numerous factors
outside of a party's control. In the case of Boxlot's performance, a Boxlot force majeure includes
theglobe's failure to perform its obligations described in this Agreement or an outage that affects
the entire Internet in the United States; however, in no event shall a failure of any Boxlot
supplier or vendor be deemed a Boxlot force majeure.

12.8 Notice. Any notice under this Agreement will be in writing and delivered by personal delivery,
overnight courier, confirmed facsimile, confirmed email, or certified or registered mail, return
receipt requested, and will be deemed given upon personal delivery, 1 day after deposit with an
overnight courier, 5 days after deposit in the mail, or upon confirmation of receipt of facsimile or
email. Notices will be sent to a party at its address set forth above or such other address as that
party may specify in writing pursuant to this Section.

12.9 Entire Agreement; Waiver. This Agreement sets forth the entire understanding and agreement of
the parties, and supersedes any and all oral or written agreements or understandings between the
parties, as to the subject matter of the Agreement. This Agreement may be changed only by a writing
signed by both parties. The waiver of a breach of any provision of this Agreement will not operate
or be interpreted as a waiver of any other or subsequent breach.

12.10 Equity Stake. Boxlot shall grant to theglobe, pursuant to industry- standard terms negotiated
between the parties in good faith, immediately vested options to purchase shares of common stock
equal to up to 4% of Boxlot's fully diluted capital stock (in accordance with the chart below).
Theglobe shall be restricted from exercising such options until the first anniversary of the
Effective Date, and such options shall have a five-year term. Each such option shall have an
exercise price equal to the lesser of (1) the price at which Boxlot's common stock is sold to the
public in an initial public offering or (2) $6 per share; each of the foregoing as may be adjusted
for any stock splits, combinations or re-organizations affecting Boxlot's capital stock. Boxlot
shall grant to theglobe registration rights for such options and any shares of common stock issued
or issuable upon the exercise of such options (including without limitation, two demand registration
rights and unlimited piggyback registration rights) on Form S-1, Form S-3 or such other form as may
be applicable pursuant to the Securities Act of 1933 as amended.

-
------------------------------------------------------------------------------------------------------------------

Source: THEGLOBE COM INC, S-1/A, 5/3/1999
<!-- page 6 -->
Number of aggregate unique users, as measured by Aggregate percent of Boxlot's equity subject to the
unique IP addresses, in a month who visit a page options upon achieving such level once under the
Domain Name -
------------------------------------------------------------------------------------------------------------------
500,000 1% -
------------------------------------------------------------------------------------------------------------------
1,000,000 2% -
------------------------------------------------------------------------------------------------------------------
1,500,000 3% -
------------------------------------------------------------------------------------------------------------------
1,750,000 3.5% -
------------------------------------------------------------------------------------------------------------------
2,000,000 4% -
------------------------------------------------------------------------------------------------------------------

10

THEGLOBE.COM, INC.: THE BOXLOT COMPANY:

By: /s/ Dean Daniels By: /s/ Frederick Cary

Name: Dean Daniels Name: Frederick Cary

Title: COO Title: CEO

11

EXHIBIT A BUSINESS TERMS

Description of the Service: person-to-person auctions

Description of Boxlot Content:

***

Domain Name for the Co-Branded Pages: auctions.theglobe.com

theglobe's Promotions. In positions determined by theglobe in its sole discretion, theglobe shall:

. list "Classifieds/Auctions" in the tools category of the left hand nav bar . list auctions in
relevant theme areas . list auctions in myglobe [Note: this will be done when commercially
reasonable to do so some time after the Launch Date] . list auctions in shop.theglobe.com

theglobe may provide substitute placement if theglobe changes or reorganizes its site or
navigation/directory structure. theglobe shall provide a minimum of *** impressions per month of
promotion for auctions on the Co-Branded Pages (including without limitation any of the foregoing).
theglobe's sole and exclusive obligation for failing to deliver the minimum number of impressions
shall be to continue performing the promotion until it delivers the total number of required
impressions.

Boxlot's Promotions. theglobe may place up to 100 listings a month on the Boxlot Site (and all
co-branded versions thereof) promoting products being sold by theglobe or its affiliates without
having to pay any listing fee, closing value fee, transaction fee or other fee.

theglobe Pre-Launch Deliverables: In addition to developing the Page Templates, theglobe shall
provide to Boxlot a media and promotional plan and a plan for doing the production/design services
related to the Service's integration into theglobe Site.

PAYMENTS

. ***

. Placement Fee. The following schedule of payments apply:

-
------------------------------------------------------------------------------------------------------------------
Time of Payment Amount of Payment -
------------------------------------------------------------------------------------------------------------------
Execution *** -
------------------------------------------------------------------------------------------------------------------
Launch Date *** -
------------------------------------------------------------------------------------------------------------------
1st monthly anniversary of Launch Date *** -
------------------------------------------------------------------------------------------------------------------
2nd monthly anniversary of Launch Date *** -
------------------------------------------------------------------------------------------------------------------

12

3rd monthly anniversary of Launch Date *** -
------------------------------------------------------------------------------------------------------------------
4th monthly anniversary of Launch Date *** -
------------------------------------------------------------------------------------------------------------------
5th monthly anniversary of Launch Date *** -
------------------------------------------------------------------------------------------------------------------
6th monthly anniversary of Launch Date *** -
------------------------------------------------------------------------------------------------------------------
7th monthly anniversary of Launch Date *** -
------------------------------------------------------------------------------------------------------------------
8th monthly anniversary of Launch Date *** -
------------------------------------------------------------------------------------------------------------------
9th monthly anniversary of Launch Date ***

Source: THEGLOBE COM INC, S-1/A, 5/3/1999
<!-- page 7 -->
-
------------------------------------------------------------------------------------------------------------------
10th monthly anniversary of Launch Date *** -
------------------------------------------------------------------------------------------------------------------
11th monthly anniversary of Launch Date *** -
------------------------------------------------------------------------------------------------------------------
Each monthly anniversary thereafter (excluding the *** final monthly anniversary (e.g., the last day
of the contract)) -
------------------------------------------------------------------------------------------------------------------

. Ad Split. theglobe shall pay Boxlot *** of Net Revenues.

. Transactional Revenue. Boxlot shall retain *** of the transaction revenues it generates from
operation of the Service.

13

EXHIBIT B PERFORMANCE STANDARDS

A. Service Availability. The Service generally shall be publicly available to Users a minimum of 95%
of the time during any 7 day period and 98% of the time during any 30 day period, excluding
"Maintenance." Maintenance is defined as scheduled Service outages for Service maintenance or
upgrades of which theglobe is notified at least 48 hours in advance, so long as such outages are
scheduled for low-usage time periods and do not exceed a total of 20 hours in any 30 day period.

B. Response Time. The mean response time for server response to access the Service shall not exceed
more than 6 seconds during any 1 hour period.

C. Bandwidth. Throughout the term, Boxlot shall have an agreement in place with its Internet
connectivity provider which requires such provider to automatically increase bandwidth capacity if
such capacity exceeds 25% utilization.

D. Security. Boxlot shall prevent unauthorized access to restricted areas of its servers and any
databases or other sensitive material generated from or used in conjunction with the Service. In
addition, Boxlot shall immediately notify theglobe of any known security breaches or holes in the
Service or Co-Branded Pages.

E. Error Correction. Boxlot shall resolve any errors with the Service (including without limitation
any Javascripts or ActiveX controls used in connection with such pages) that cause such services not
to be able to perform one or more major functions within 24 hours of the earlier of its discovery of
the error or theglobe's notice of the error. Boxlot shall resolve all other errors with such
services within 7 days of the earlier of its discovery of the error or theglobe's notice of the
error.

F. Browser Compatibility. The Service shall initially be compatible with Netscape Navigator 3.X and
4.X and Microsoft Internet Explorer 3.X and 4.X. theglobe may unilaterally add additional browsers
or versions that the Service must be compatible with, effective after 30 days advance written
notice, if theglobe certifies that such additional browsers or versions are used by more than 5% of
its Users. Users shall not require any plug-ins in order to access any Service functionality.

G. Data Authentication. Boxlot shall use commercially reasonable efforts, no less than
industry-standard, to authenticate the origin of all information provided by theglobe as having come
from theglobe.

H. Customer Support. Boxlot shall auto-respond to all customer and technical support inquiries
within 10 minutes of the receipt of inquiry. Boxlot shall manually respond to all such inquiries
within 24 hours. Boxlot shall resolve all such inquiries within 72 hours or shall notify theglobe
that it cannot do so, in which case theglobe at its sole discretion may intervene to assist in
resolving the inquiry.

I. Remedies. In addition to other applicable remedies, theglobe may immediately terminate this
Agreement without a further cure period if: (a) any breach of this Exhibit lasts 2 consecutive
specified time periods, or if no time period for measurement is specified, 10 days, or (b) the same
provision is breached on two separate occasions (even if the first was cured).

14

EXHIBIT C BOXLOT COMPETITIVE SET

aciauction Auction 123 Auction Net Online Auction Network Auction Online Auction Sales Online
Auction Universe Auction USA Auction Warehouse Auction World AuctionAddict AuctionFloor AuctionGate
AuctionInc. AuctionLine AuctionPC AuctionPort-Interactive Online Auctions Auctionsamerica
Auctionware Technologies AuctionWorks AuctionX Autographs...and more! B2BAuction BargainsUSA Bid on
Collectibles

Source: THEGLOBE COM INC, S-1/A, 5/3/1999
<!-- page 8 -->
Bid Online Bid4it BidAway Web Auctions Biddernet Bidders Paradise BidderSuite bidnask.com Bidnow
Boekhout's Collectibles Mall Buck Auction Butterfield & Butterfield Central Missouri Internet
Auction Christie's CityAuction Classifieds Live CoinTrade Online CommPublic Online Consultants
Research Institute CSL Associates Online Auction for Pearls Dan's Online Auction DealDeal Deep
Discount Network Digitalauction eBay

15

Electronic Auction Encore E-Z Auction FairAuction FinalBid Internet Auction Service First Auction
FocalPoint Online Photo Auction Foryourneeds Fun Time Auction G.B. Tate & Sons Online Auction GEMS
AUCTION Gifts and More Online Auction Glenn Johnson Coins Going Going Sold Going Once Going,
Going...Sold! Golden Age Antiques and Collectibles Golf Auction GolfClubExchange GolfWeb GolfAuction
Haggle Online Hobby Markets Online Human Digital Auction Infinite Auction Insight Corp Auction
Interactive Auction Online interAUCTION Services Intermodal Equipment Exchange International
Electronic Auction Internet Auction House Internet Liquidators Int IWA Auction House John Morelli
Auctioneers Keybuy Auction House Klik-Klok Dutch Auction Labx Lightningauctions Magnolia Auction
Metric Equipment Sales ML Coins Motherlode Gold Auction Nab-it National Auction Properties, Inc.
Nationwide Dealer Exchange Netauction Netauctions NetMarket Nettworth NonProfitAuction Northerbys
Online Auctions Numisma Online Coin Auctions Numismatists Online Coin Auctions Old Auction Barn
OneWebPlace Online Auction Services

16

OnLine Exchange ONSALE Interactive Marketplace Paulus Swaen Internet Auction PC Buyer Philatelists
Online Prizefight ProAuctions RacerX Remington York Online Auction Rotman Collectibles Sandafayre
Sandy's Super Auction Save the Earth Foundation ArtRock Auction Scala-Mathis Auctions, Inc. SCC
Exchange Southeast Auction Company Sotheby's Sportsauctionsusa Steal-a-Record Auction Super Auction
Superior Coin & Stamp Auction Galleries SurplusAuction Teletrade The Auction Block The Auction Store

Source: THEGLOBE COM INC, S-1/A, 5/3/1999
<!-- page 9 -->
The Sell And Trade Internet Marketplace TIME MACHINE....Silent Watch Auction u-Auction-it uBid
Universe Auctions University of Michigan AuctionBot Up4Sale USAuctions USCents VintageUSA Direct
Auction WebAuction Wild Auction World Wide Auctions Yahoo Auction ZAuction 1st Sporting Equipment
Auction 3WAuction

17

EXHIBIT D AUTOMATIC PARTNER REGISTRATION To maintain a consistent user experience, any theglobe
member should not need to separately log in to the Service or the Co-Branded Pages. The only login
or registration that should be required to access the Service or the Co-Branded Pages is theglobe
Site's login or registration. Because Boxlot hosts the Service and the Co-Branded Pages, theglobe
will pass to Boxlot information about each User accessing the Service or the Co-Branded Pages as
described below:

. Accounts will be created for each User via a one-time "welcome" page (hosted by theglobe) when the
User tries to access the portion of the Service requiring such registration for the first time.

. The "welcome" page will include registration fields for any information about the User needed to
use the Service but not currently in theglobe's database.

. The "welcome" page will include a "Privacy Policy" informing the User that their data is being
passed to a third party (Boxlot) in order to use the Services.

. Any additional required User information is collected and entered into theglobe's database. Then,
the required User information is sent to Boxlot all at once to create the new account. theglobe will
include the User's "username" and "UserID#" in the data passed to Boxlot.

Additional notes on account creation:

. The User will only see the "Welcome" page until they consent to the privacy policy and enter any
required information. This page will not appear after the User completes the initial account
creation process.

. Account information stored on Boxlot's servers in connection to the Service will need to be kept
in parity with theglobe. To do so, the parties shall work together to implement a mechanism for
updating information on Boxlot's servers when User information changes on theglobe Site.

. The technology used to pass the data to Boxlot for account creation and ongoing account updates
will be determined jointly by Boxlot and theglobe.

. The UserID# theglobe passes to Boxlot during account creation will be stored by Boxlot in
association with each User. This UserID# is necessary to link individual user reporting and
individual account updates between Boxlot and theglobe on an ongoing basis.

18

Source: THEGLOBE COM INC, S-1/A, 5/3/1999
