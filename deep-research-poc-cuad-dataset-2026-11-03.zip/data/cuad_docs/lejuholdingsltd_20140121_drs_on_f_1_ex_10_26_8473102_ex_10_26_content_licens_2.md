<!-- page 1 -->
# MUTUAL TERMINATION AGREEMENT
| Field | Value |
|---|---|
| Document Type | License Agreement |
| SEC Filing Date | 2014-01-21 |
| Parties | Beijing SINA Internet Information Service Co. ("Beijing SINA"); Shanghai SINA Leju Information Technology Co. Ltd. ("SINA Leju") |
| Source | CUAD v1 / LejuHoldingsLtd_20140121_DRS (on F-1)_EX-10.26_8473102_EX-10.26_Content License Agreement2 |

EXHIBIT B MUTUAL TERMINATION AGREEMENT THIS MUTUAL TERMINATION AGREEMENT ("Termination Agreement")
is made and entered into this day of , 2009, by and between Beijing SINA Internet Information
Service Co. ("Beijing SINA") and Shanghai SINA Leju Information Technology Co. Ltd. ("SINA Leju").
WITNESSETH: WHEREAS, Beijing SINA and SINA Leju entered into that certain Domain Name License
Agreement dated May 8, 2008 (the "Original Agreement"); and WHEREAS, Beijing SINA and SINA Leju
desire to mutually terminate the Original Agreement effective as of the date of this Termination
Agreement. NOW, THEREFORE, in consideration of the mutual covenants and conditions contained herein,
and other good and valuable consideration, receipt of which is hereby acknowledged by each of the
parties hereto, the parties agree as follows: 1. Beijing SINA and SINA Leju agree that, upon the
date of execution of this Termination Agreement, the Agreement shall terminate and be of no further
force or effect, and, for the avoidance of doubt, no provisions of the Original Agreement survive
such termination. 2. This Termination Agreement represents the complete, integrated, and entire
agreement between the parties, and may not be modified except in writing signed by the parties. 3.
This Termination Agreement shall be governed by the laws of the PRC, without regard to conflicts of
law principles. 4. This Termination Agreement may be executed in one or more counterparts, each of
which shall be deemed an original but all of which together will constitute one and the same
instrument. 5. This Termination Agreement shall be binding upon and inure to the benefit of the
parties hereto and their respective successors and assigns. [SIGNATURES ON NEXT PAGE] 18

Source: LEJU HOLDINGS LTD, DRS (on F-1), 1/21/2014
<!-- page 2 -->
IN WITNESS WHEREOF, the undersigned have executed this Termination Agreement as of the date first
set forth above.

Beijing SINA Internet Information Service Co., Ltd.

By:

Name:

Title:

Shanghai SINA Leju Information Technology Co. Ltd.

By:

Name:

Title: 19

Source: LEJU HOLDINGS LTD, DRS (on F-1), 1/21/2014
