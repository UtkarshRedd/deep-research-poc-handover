<!-- page 1 -->
# Credit Agreement — Acme Industrial LLC (conformed copy)
| Field | Value |
|---|---|
| Document Type | Credit Agreement |
| Effective Date | 2024-03-15 |
| Parties | Acme Industrial LLC; First National Bank |

## 1. Definitions
"Applicable Margin" means 2.25% per annum for Term SOFR Loans.
<!-- page 2 -->
## 2. Commitments
The aggregate Revolving Commitment is $25,000,000 as of the Effective Date.
## 3. Financial Covenants
Borrower shall maintain a Leverage Ratio not exceeding 3.50 to 1.00.
