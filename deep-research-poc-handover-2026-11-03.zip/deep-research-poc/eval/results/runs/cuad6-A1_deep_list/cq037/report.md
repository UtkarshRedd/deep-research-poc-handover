# When does the Distributor Agreement between COMWARE TECHNICAL SERVICES and INTERNATIONA...

*Question:* When does the Distributor Agreement between COMWARE TECHNICAL SERVICES and INTERNATIONAL TEST SYSTEMS, INC. (filed 2000-07-26) expire, according to its term clause?

## Locate the Distributor Agreement

The document identified as a Distributor Agreement between COMWARE TECHNICAL SERVICES ("COMWARE") and INTERNATIONAL TEST SYSTEMS, INC. [uncited] ("ITS") was filed with the SEC on 2000-07-26. [ce581d56506a6a52 p.1]

[GAP] The term clause and expiration date of the Distributor Agreement are not provided in the evidence.

## Extract the term clause

The initial term of the Distributor Agreement runs from April 15, 2000 through October 15, 2000. [ce581d56506a6a52 p.1] The agreement specifies this as six months from the Effective Date. [ce581d56506a6a52 p.1] The agreement expires on October 15, 2000. [ce581d56506a6a52 p.1]

## Not established by the evidence

[GAP] No evidence was found for: State the exact expiration date according to the term clause

## Verification appendix

Claims: 7 · supported: 4 · partially: 0 · dropped: 0 · gaps: 3 · tier-1 support rate: 1.00

Notes: 1 empty section(s) collapsed into gaps: Determine expiration date

| claim | section | tier 1 | score | sources | note |
|---|---|---|---|---|---|
| s1.1 | s1 | gap |  |  | no evidence cited |
| s1.2 | s1 | keep | 1.00 | e1→[ce581d56506a6a52 p.1] |  |
| s1.3 | s1 | gap |  |  |  |
| s2.1 | s2 | keep | 1.00 | e2→[ce581d56506a6a52 p.1] |  |
| s2.2 | s2 | keep | 1.00 | e2→[ce581d56506a6a52 p.1] |  |
| s2.3 | s2 | keep | 1.00 | e2→[ce581d56506a6a52 p.1] |  |
| gaps.1 | gaps | gap |  |  |  |

### Evidence

- e1 [ce581d56506a6a52 p.1 L5-7] keep (1.0): "| Document Type | Distributor Agreement | | SEC Filing Date | 2000-07-26 | | Parties | COMWARE TECHNICAL SERVICES ("COMWARE"); INTERNATIONAL TEST SYSTEMS, INC. ("ITS") |"
- e2 [ce581d56506a6a52 p.1 L25-26] keep (1.0): "INITIAL DISTRIBUTION PERIOD: April 15, 2000 through October 15, 2000 (6 Months from the Effective Date)"
