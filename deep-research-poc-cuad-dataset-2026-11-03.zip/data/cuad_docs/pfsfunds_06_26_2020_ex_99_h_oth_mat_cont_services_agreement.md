<!-- page 1 -->
# SERVICES AGREEMENT
| Field | Value |
|---|---|
| Document Type | Service Agreement |
| Agreement Date | 2020-06-24 |
| Parties | PFS Funds ("Trust"); Potomac Fund Management, Inc. ("Adviser") |
| Source | CUAD v1 / PFSFUNDS_06_26_2020-EX-99.H OTH MAT CONT-SERVICES AGREEMENT |

SERVICES AGREEMENT CONQUER RISK MANAGED VOLATILITY FUND CONQUER RISK TACTICAL ROTATION FUND CONQUER
RISK TACTICAL OPPORTUNITIES FUND CONQUER RISK DEFENSIVE BULL FUND

AGREEMENT dated as of June 24, 2020, between PFS Funds (the "Trust"), a Massachusetts business
trust, and Potomac Fund Management, Inc. (the "Adviser"), a Florida Corporation.

WHEREAS, the Trust has been organized to operate as an open-end management investment company
registered under the Investment Company Act of 1940 (the "Act"); and WHEREAS, the Trust has engaged
the Adviser to act as investment adviser to the Conquer Risk Managed Volatility Fund, Conquer Risk
Tactical Rotation Fund, Conquer Risk Tactical Opportunities Fund, and Conquer Risk Defensive Bull
Fund (each a "Fund"), series of PFS Funds; and WHEREAS, the Trust wishes to retain the Adviser to
perform certain additional services as hereinafter described on behalf of the Fund; and WHEREAS, the
Adviser wishes to provide such services to the Fund under the conditions set forth below; NOW,
THEREFORE, in consideration of the promises and mutual covenants contained in this Agreement, the
Trust and the Adviser agree as follows:

1. Employment. The Trust, being duly authorized, hereby employs the Adviser to perform the services
described in this Agreement. The Adviser shall perform such services upon the terms and conditions
hereinafter set forth. Any services undertaken by the Adviser pursuant to this Agreement, as well as
any other activities undertaken by the Adviser on behalf of the Trust pursuant hereto, shall at all
times be subject to any directives of the Board of Trustees of the Trust.

2. Trust Administration. The Adviser shall give the Trust the benefit of its best judgment, efforts
and facilities in rendering its services. The Adviser shall at all times conform to: (i) all
applicable provisions of the Act and any rules and regulations adopted thereunder; (ii) the
provisions of the Registration Statement of the Trust under the Securities Act of 1933 and the Act
as amended from time to time; (iii) the provisions of the Agreement and Declaration of Trust and the
By-Laws of the Trust; and (iv) any other applicable provisions of state and federal law.

Subject to the direction and control of the Trust, the Adviser shall supervise the Fund's business
affairs. In addition, to the extent not otherwise provided by other parties under agreements with
the Trust, the Adviser shall supply: (i) non-investment related statistical and research data; (ii)
the services of a Chief Compliance Officer for the Trust with respect to the

1

Fund and (iii) executive and administrative services. The Adviser shall also assist with and/or
supervise the preparation by the Trust's administrator, transfer agent, and/or auditors of: (i) tax
returns; (ii) reports to shareholders of the Fund; (iii) reports to, and filings with, the
Securities and Exchange Commission, state securities commissions and Blue Sky authorities including
preliminary and definitive proxy materials and post-effective amendments to the Trust's registration
statement; and (iv) necessary materials for meetings of the Trust's Board of Trustees. The Adviser
shall provide personnel to serve as officers of the Trust if so elected by the Board of Trustees.
Executive and administrative services include, but are not limited to, the coordination of all third
parties furnishing services to the Fund, review of the books and records of the Fund maintained by
such third parties, and the review and submission to the officers of the Fund for their approval, of
invoices or other requests for payment of Fund expenses; and such other action with respect to the
Fund as may be necessary in the opinion of the Adviser to perform its duties hereunder.

3. Allocation of Charges and Expenses. Except as set forth below, the Adviser will pay all operating
expenses of each Fund specifically assumed by the Fund under the Management Agreement between the
Trust and the Adviser dated June 24, 2020 (the "Management Agreement"), including without limitation
the compensation and expenses of any employees of the Fund and of any other persons rendering any
services to the Fund; clerical and shareholder service staff salaries; office space and other office
expenses; fees and expenses incurred by the Fund in connection with membership in investment company
organizations; legal, auditing and accounting expenses; expenses of registering shares under federal
and state securities laws, including expenses incurred by the Fund in connection with the
organization and initial registration of shares of the Fund; insurance expenses; fees and expenses
of the custodian, transfer agent, dividend disbursing agent, shareholder service agent, plan agent,
administrator (excluding fees and expenses payable to the Adviser under this Agreement and the
Management Agreement), accounting and pricing services agent and underwriter of the Fund; expenses,
including clerical expenses, of issue, sale, redemption or repurchase of shares of the Fund; the
cost of preparing and distributing reports and notices to shareholders, the cost of printing or
preparing prospectuses and statements of additional information for delivery to shareholders; the
cost of printing or preparing stock certificates or any other documents, statements or reports to
shareholders; expenses of shareholders' meetings and proxy solicitations; and all other operating
expenses not specifically assumed by the Fund. For purposes of this Agreement, "operating expenses"
shall not include advertising, promotion and other expenses incurred directly or indirectly in
connection with the sale or distribution of the Fund's shares (including expenses that the Fund is
authorized to pay pursuant to Rule 12b-1 under the Act, if any).

The Fund will pay all brokerage fees and commissions, taxes, borrowing costs (such as (a) interest
and (b) dividend expenses on securities sold short), ADR fees, fees and expenses of acquired funds,
extraordinary or non-recurring expenses as may arise, including litigation to which the Fund may be
a party and indemnification of the Trust's Trustees and officers with respect thereto. The Fund also
will pay the fees paid pursuant to the Management Agreement between the Adviser and the Trust, and
all expenses which it is now or in the future may be authorized to pay pursuant to Rule 12b-1 under
the Act. The Adviser may obtain reimbursement from the Fund, at such time or times as the Adviser
may determine in its sole discretion, for any expenses advanced by the Adviser that the Fund is
obligated to pay, and such reimbursement shall not be considered to

2

be part of the Adviser's compensation pursuant to this Agreement.
<!-- page 2 -->
4. Record Keeping and Other Information. The Adviser shall create and maintain all necessary records
in accordance with all applicable laws, rules and regulations, including, but not limited to,
records required by Section 31(a) of the Act and the rules thereunder, as the same may be amended
from time to time, pertaining to the various functions performed by it and not otherwise created and
maintained by another party pursuant to contract with the Trust. Where applicable, such records
shall be maintained by the Adviser for the periods and in the places required by Rule 31a-2 under
the Act.

5. Audit, Inspection and Visitation. The Adviser shall make available to the Trust during regular
business hours all records and other data created and maintained pursuant to the foregoing
provisions of this Agreement for reasonable audit and inspection by the Trust or any regulatory
agency having authority over the Trust.

6. Compensation. For the performance of the Adviser's obligations under this Agreement, including
payment of certain expenses of each of the Funds pursuant to paragraph 3 hereof, each Fund shall pay
the Adviser, on the first business day following the end of each month, a fee at an annual rate of
0.65% of a Fund's average daily net assets up to $25 million, 0.35% of a Fund's average daily net
assets from $25 million to $100 million, and 0.25% of a Fund's average daily net assets for such
assets in excess of $100 million.

The average value of the daily net assets of a Fund shall be determined pursuant to the applicable
provisions of the Agreement and Declaration of Trust or a resolution of the Board of Trustees, if
required. If, pursuant to such provisions, the determination of net asset value of a Fund is
suspended for any particular business day, then for the purposes of this paragraph, the value of the
net assets of a Fund as last determined shall be deemed to be the value of the net assets as of the
close of the business day, or as of such other time as the value of the Fund's net assets may
lawfully be determined, on that day. If the determination of the net asset value of a Fund has been
suspended for a period including such month, the Adviser's compensation payable at the end of such
month shall be computed on the basis of the value of the net assets of the Fund as last determined
(whether during or prior to such month).

7. Limitation of Liability. The Adviser may rely on information reasonably believed by it to be
accurate and reliable. Except as may otherwise be required by the Act or the rules thereunder,
neither the Adviser nor its directors, officers, employees, shareholders, agents, control persons or
affiliates of any thereof (collectively, the "Adviser Employees") shall be subject to any liability
for, or any damages, expenses or losses incurred by the Trust in connection with any error of
judgment, mistake of law, any act or omission in connection with or arising out of any services
rendered under or payments made pursuant to this Agreement or any other matter to which this
Agreement relates, except by reason of willful misfeasance, bad faith or gross negligence on the
part of any such persons in the performance of the duties of the Adviser under this Agreement or by
reason of reckless disregard by any of such persons of the obligations and duties of the Adviser
under this Agreement. Any person, even though also a director, officer, employee, shareholder or
agent of the Adviser, who may be or become a trustee, officer, employee or agent of the Trust, shall
be deemed, when rendering services to the Trust or

3

acting on any business of the Trust (other than services or business in connection with the
Adviser's duties hereunder), to be rendering such services to or acting solely for the Trust and not
as a director, officer, employee, shareholder or agent, or one under the control or direction of the
Adviser, even though paid by it. The Adviser is responsible for any information that it provides to
the Trust for inclusion in the prospectus and/or statement of additional information of the Fund.
The Adviser agrees to defend and indemnify the Trust, and its trustees, officers and agent from and
against any and all liability, losses, claims and damages arising from any inaccurate or incomplete
statement provided by the Adviser (or its officers, employees, directors and agents) for inclusion
in the Fund's prospectus or statement of additional information. The Adviser agrees to defend and
indemnify the Trust, and its trustees, officers and agents from and against any and all liability,
losses, claims and damages arising from your willful misfeasance, bad faith or gross negligence on
the Adviser's part or the part of the Adviser's officers, employees, directors and agents in the
performance of the Adviser's duties under this Agreement, or by reason of reckless disregard by any
of such persons of the Adviser's obligations and duties under this Agreement.

8. Services for Others. Nothing in this Agreement shall prevent the Adviser or any affiliated person
of the Adviser from providing services for any other person, firm or corporation, including other
investment companies; provided, however, that the Adviser expressly represents that it will
undertake no activities which, in its judgment, will adversely affect the performance of its
obligations to the Trust under this Agreement.

9. Renewal and Termination. The term of this Services Agreement shall begin on the date of execution
and shall continue in effect for a period of two years. This Services Agreement shall continue in
effect from year to year thereafter, subject to termination as hereinafter provided, if such
continuance is approved at least annually by vote of a majority of the Trustees who are not
interested persons of the Trust or the Adviser. This Agreement may be terminated without the payment
of any penalty by either party upon sixty (60) days' written notice to the other party. Upon the
termination of this Agreement, the Trust shall pay the Adviser such compensation as may be payable
for the period prior to the effective date of such termination. This Agreement shall automatically
terminate in the event the Management Agreement is assigned or otherwise terminated.

10. The Trust. The term "PFS Funds" means and refers to the Trustees from time to time serving under
the Trust's Agreement and Declaration of Trust as the same may subsequently thereto have been, or
subsequently hereto may be, amended. It is expressly agreed that the obligations of the Trust
hereunder shall not be binding upon any of the Trustees, officers, employees, agents or nominees of
the Trust, or any shareholders of any series of the Trust, personally, but bind only the trust
property of the Trust (and only the property of the Fund). The execution and delivery of this
Agreement have been authorized by the Trustees of the Trust and signed by an officer of the Trust,
acting as such, and neither such authorization by such Trustees nor such execution and delivery by
such officer shall be deemed to have been made by any of them individually or to impose any
liability on any of them personally, but shall bind only the trust property of the Trust (and only
the property of the Fund) as provided in its Agreement and Declaration of Trust. A copy of the
Agreement and Declaration of Trust is on file with the Secretary of State of Massachusetts.

4

11. Miscellaneous. Each party agrees to perform such further acts and execute such further documents
as are necessary to effectuate
<!-- page 3 -->
the purposes hereof. This Agreement shall be construed and enforced in accordance with and governed
by the laws of the State of Massachusetts. This Agreement may be amended at any time by written
instrument executed by each of the parties hereto. The captions in this Agreement are included for
convenience of reference only and in no way define or delimit any of the provisions hereof or
otherwise affect their construction or effect.

IN WITNESS WHEREOF, the parties have duly executed this Agreement as of the day and year first above
written.

PFS Funds By: /s/ Jeffrey R. Provence Print Name: Jeffrey R. Provence Title: Trustee, Secretary and
Treasurer Potomac Fund Management, Inc. By: /s/ Manish Khatta Print Name: Manish Khatta Title:
President

5
