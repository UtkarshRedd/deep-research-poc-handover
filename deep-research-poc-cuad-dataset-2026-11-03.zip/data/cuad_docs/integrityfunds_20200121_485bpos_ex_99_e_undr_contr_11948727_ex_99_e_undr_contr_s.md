<!-- page 1 -->
# DISTRIBUTION AND SERVICES AGREEMENT
| Field | Value |
|---|---|
| Document Type | Service Agreement |
| Agreement Date | 2020-01-18 |
| Parties | Integrity Short Term Government Fund, ("fund"); The Integrity Funds, Integrity Funds Distributor, LLC, ("Integrity") |
| Source | CUAD v1 / IntegrityFunds_20200121_485BPOS_EX-99.E UNDR CONTR_11948727_EX-99.E UNDR CONTR_Service Agreement |

DISTRIBUTION AND SERVICES AGREEMENT January 18, 2020 This is to confirm that, in consideration of
the agreements hereinafter contained, the undersigned, the Integrity Short Term Government Fund,
(the "Fund"), an open-end, diversified, management investment company organized as a series of The
Integrity Funds, a Delaware statutory trust, has agreed that Integrity Funds Distributor, LLC,
("Integrity"), shall be, for the period of this distribution agreement (the "Agreement"), the
principal underwriter of shares issued by the Fund, including such classes of shares as may now or
hereafter be authorized (the "Shares"). SECTION 1. SERVICES AS UNDERWRITER Section 1.1 Integrity
will act as principal underwriter for the distribution of the Shares covered by the registration
statement, prospectus, and statement of additional information then in effect of the Fund (the
"Registration Statement") under the Securities Act of 1933, as amended (the "1933 Act"), and the
Investment Company Act of 1940, as amended (the "1940 Act"). Section 1.2 Integrity agrees to use its
best efforts to solicit orders for the sale of the Shares at the public offering price, as
determined in accordance with the Registration Statement, and will undertake such advertising and
promotion as it believes is reasonable in connection with such solicitation. Integrity shall order
Shares from the Fund only to the extent that it shall have received purchase orders therefore.
Section 1.3 All activities by Integrity as underwriter of the Shares shall comply with all
applicable laws, rules, and regulations, including, without limitation, all rules and regulations
made or adopted by the Securities and Exchange Commission (the "SEC") or by any securities
association registered under the Securities Exchange Act of 1934 and the Fund's Registration
Statement. Section 1.4 Integrity will provide one or more persons during normal business hours to
respond to telephone questions concerning the Fund. Section 1.5 Integrity acknowledges that,
whenever in the judgment of the Fund's officers such action is warranted for any reason, including,
without limitation, market, economic, or political conditions, those officers may decline to accept
any orders for, or make any sales of, the Shares until such time as those officers deem it advisable
to accept such orders and to make such sales. Section 1.6 Integrity shall be deemed to be an
independent contractor and, except as specifically provided or authorized herein, shall have no
authority to act for or represent the Fund. Integrity will act only on its own behalf as principal
should it choose to enter into selling agreements with selected dealers or others. Integrity may
allow commissions or concessions to dealers in such amounts as Integrity shall determine from time
to time, as set forth in the Fund's Registration Statement. Except as may otherwise be determined by
Integrity and the Fund from time to time, such commissions or concessions shall be uniform to all
dealers. Shares sold to dealers shall be for resale by such dealers only at the public offering
price(s) set forth in the Fund's then current Registration Statement. The price the Fund shall
receive for all Shares purchased from the Fund shall be the net asset value used in determining the
public offering price applicable to the sale of such Shares.

Source: INTEGRITY FUNDS, 485BPOS, 1/21/2020
<!-- page 2 -->
Section 1.7 In consideration of the services rendered pursuant to this Agreement, Integrity shall
receive the excess, if any, of the sales price, as set forth in the Fund's Registration Statement,
over the net asset value of Shares sold by Integrity, as underwriter. The Fund shall also pay
Integrity any distribution and/or service fees applicable to the Shares as authorized by the
Shareholder Services Plan (the "Plan") adopted by the Fund under Rule 12b-1 of the Investment
Company Act of 1940 and set forth in the Fund's Registration Statement. Such fees shall be payable
in the manner and terms set forth in the Plan. Section 1.8 Integrity will bear all expenses in
connection with the performance of its services and the incurring of distribution expenses under
this Agreement. For purposes of this Agreement, "distribution expenses" of Integrity shall mean all
expenses borne by Integrity or by any other person with which Integrity has an agreement approved by
the Fund, which expenses represent payment for activities primarily intended to result in the sale
of Shares, including, but not limited to, the following: (a) payments made to, and expenses of,
persons who provide support services in connection with the distribution of Shares, including, but
not limited to, office space and equipment, telephone facilities, answering routine inquiries
regarding the Fund, processing shareholder transactions, and providing any other shareholder
services; (b) costs relating to the formulation and implementation of marketing and promotional
activities, including, but not limited to, direct mail promotions and television, radio, newspaper,
magazine, and other mass media advertising; (c) costs of printing and distributing prospectuses and
reports of the Fund to prospective shareholders of the Fund; (d) costs involved in preparing,
printing, and distributing sales literature pertaining to the Fund; (e) costs involved in obtaining
whatever information, analyses, and reports with respect to marketing and promotional activities
that the Fund may, from time to time, deem advisable; and 2

Source: INTEGRITY FUNDS, 485BPOS, 1/21/2020
<!-- page 3 -->
(f) sales commissions and other fees paid, together with related financing costs to brokers, dealers
or other selling entities with a dealer agreement in effect for the sale of Fund Shares.
Distribution expenses, however, shall not include any expenditures in connection with services which
Integrity, any of its affiliates, or any other person has agreed to bear without reimbursement.
Section 1.9 Integrity shall prepare and deliver reports to the Treasurer of the Fund and to the
Investment Adviser on a regular, at least quarterly, basis, showing the distribution expenses
incurred pursuant to this Agreement and the Plan and the purposes therefore, as well as any
supplemental reports as the Trustees, from time to time, may reasonably request. SECTION 2. DUTIES
OF THE FUND Section 2.1 The Fund agrees at its own expense to execute any and all documents, to
furnish any and all information, and to take any other actions that may be reasonably necessary in
connection with the qualification of the Shares for sale in those states that Integrity may
designate. Section 2.2 The Fund shall furnish from time to time, for use in connection with the sale
of the Shares, such information reports with respect to the Fund and its Shares as Integrity may
reasonably request, all of which shall be signed by one or more of the Fund's duly authorized
officers; and the Fund warrants that the statements contained in any such reports, when so signed by
one or more of the Fund's officers, shall be true and correct. The Fund shall also furnish Integrity
upon request with: (a) annual audits of the Fund's books and accounts made by independent public
accountants regularly retained by the Fund, (b) semi-annual unaudited financial statements
pertaining to the Fund, (c) quarterly earnings statements prepared by the Fund, (d) a monthly
itemized list of the securities in the portfolio of the Fund, (e) monthly balance sheets as soon as
practicable after the end of each month, and (f) from time to time such additional information
regarding the Fund's financial condition as Integrity may reasonably request. Section 2.3 The Fund
shall pay to Integrity, as set forth in the Registration Statement, any distribution and service fee
authorized by the Plan. SECTION 3. REPRESENTATIONS AND WARRANTIES Section 3.1 The Fund represents to
Integrity that all registration statements, prospectuses, and statements of additional information
filed by the Fund with the SEC under the 1933 Act and the 1940 Act with respect to the Shares of the
Fund have been carefully prepared in conformity with the requirements of the 1933 Act, the 1940 Act,
and the rules and regulations of the SEC thereunder. As used in this Agreement, the terms
"registration statement," "prospectus," and "statement of additional information" shall mean any
registration statement, prospectus, and statement of additional information filed by the Fund with
the SEC and any amendments and supplements thereto which at any time shall have been filed with the
SEC. The Fund represents and warrants to Integrity that any registration statement, prospectus, and
statement of additional information, when such registration statement becomes effective, will
include all statements required to be contained therein in conformity with the 1933 Act, the 1940
Act, and the rules and regulations of the SEC; that all statements of fact contained in any
registration statement, prospectus, or statement of additional information will be true and correct
when such registration statement becomes effective; and that neither any registration statement nor
any prospectus or statement of additional information when such registration statement becomes
effective will include an untrue statement of material fact or omit to state a material fact
required to be stated therein or necessary to make the statements therein not misleading to a
purchaser of Shares. Integrity may, but shall not be obligated to, propose from time to time such
amendment or amendments to any registration statement and such supplement or supplements to any
prospectus or statement of additional information as, in the light of future developments, may, in
the opinion of Integrity's counsel, be necessary or advisable. If the Fund shall not propose such
amendment or amendments and/or supplement or supplements within fifteen days after receipt by the
Fund of a written request from Integrity to do so, Integrity may, at its option, terminate this
Agreement. The Fund shall not file any amendment to any registration statement or supplement to any
prospectus or statement of additional information without giving Integrity reasonable notice thereof
in advance; provided, however, that nothing contained in this Agreement shall in any way limit the
Fund's right to file at any time such amendments to any registration statement and/or supplements to
any prospectus or statement of additional information, of whatever character, as the Fund may deem
advisable, such right being in all respects absolute and unconditional. 3

Source: INTEGRITY FUNDS, 485BPOS, 1/21/2020
<!-- page 4 -->
SECTION 4. INDEMNIFICATION Section 4.1 The Fund authorizes Integrity and any dealers with whom
Integrity has entered into dealer agreements to use any prospectus or statement of additional
information furnished by the Fund from time to time in connection with the sale of Shares. The Fund
agrees to indemnify, defend, and hold Integrity, its several officers and governors, and any person
who controls Integrity within the meaning of Section 15 of the 1933 Act, free and harmless from and
against any and all claims, demands, liabilities, and expenses (including the cost of investigating
or defending such claims, demands, or liabilities and any counsel fees incurred in connection
therewith) which Integrity, its officers and governors, or any such controlling person may incur
under the 1933 Act, the 1940 Act, or common law or otherwise, arising out of or based upon any
untrue statement or alleged untrue statement of a material fact contained in any registration
statement, any prospectus, or any statement of additional information, or arising out of or based
upon any omission or alleged omission to state a material fact required to be stated in any
registration statement, any prospectus, or any statement of additional information, or necessary to
make the statements in any of them not misleading; provided, however, that the Fund's agreement to
indemnify Integrity, its officers or governors, and any such controlling person shall not be deemed
to cover any claims, demands, liabilities, or expenses arising out of or based upon any statements
or representations made by Integrity or its representatives or agents other than such statements and
representations as are contained in any registration statement, prospectus, or statement of
additional information and in such financial and other statements as are furnished to Integrity
pursuant to paragraph 2.2 hereof; and further provided that the Fund's agreement to indemnify
Integrity and the Fund's representations and warranties hereinbefore set forth in paragraph 3 shall
not be deemed to cover any liability to the Fund or its shareholders to which Integrity would
otherwise be subject by reason of willful misfeasance, bad faith, or gross negligence in the
performance of its duties, or by reason of Integrity's reckless disregard of its obligations and
duties under this Agreement. The Fund's agreement to indemnify Integrity, its officers and
governors, and any such controlling person, as aforesaid, is expressly conditioned upon the Fund's
being notified of any action brought against Integrity, its officers or governors, or any such
controlling person, such notification to be given by letter or by telegram addressed to the Fund at
its principal office in Minot, North Dakota, and sent to the Fund by the person against whom such
action is brought, within ten days after the summons or other first legal process shall have been
served. The failure so to notify the Fund of any such action shall not relieve the Fund from any
liability that the Fund may have to the person against whom such action is brought by reason of any
such untrue statement or omission or alleged omission otherwise than on account of the Fund's
indemnity agreement contained in this paragraph 4.1. The Fund's indemnification agreement contained
in this paragraph 4.1 and the Fund's representations and warranties in this Agreement shall remain
operative and in full force and effect regardless of any investigation made by or on behalf of
Integrity, its officers and governors, or any controlling person, and shall survive the delivery of
any Shares. This agreement of indemnity will inure exclusively to Integrity's benefit, to the
benefit of its several officers and governors, and their respective estates, and to the benefit of
the controlling persons and their successors. The Fund agrees to notify Integrity promptly of the
commencement of any litigation or proceedings against the Fund or any of its officers or trustees in
connection with the issuance and sale of any Shares. 4

Source: INTEGRITY FUNDS, 485BPOS, 1/21/2020
<!-- page 5 -->
Section 4.2 Integrity agrees to indemnify, defend, and hold the Fund, its several officers and
trustees, and any person who controls the Fund within the meaning of Section 15 of the 1933 Act,
free and harmless from and against any and all claims, demands, liabilities, and expenses (including
the costs of investigating or defending such claims, demands, or liabilities and any counsel fees
incurred in connection therewith) that the Fund, its officers or trustees, or any such controlling
person may incur under the 1933 Act, the 1940 Act, or common law or otherwise, but only to the
extent that such liability or expense incurred by the Fund, its officers or trustees, or such
controlling person resulting from such claims or demands shall arise out of or be based upon (a) any
unauthorized sales literature, advertisements, information, statements, or representations or (b)
any untrue or alleged untrue statement of a material fact contained in information furnished in
writing by Integrity to the Fund and used in the answers to any of the items of the registration
statement or in the corresponding statements made in the prospectus or statement of additional
information, or shall arise out of or be based upon any omission or alleged omission to state a
material fact in connection with such information furnished in writing by Integrity to the Fund and
required to be stated in such answers or necessary to make such information not misleading.
Integrity's agreement to indemnify the Fund, its officers and trustees, and any such controlling
person, as aforesaid, is expressly conditioned upon Integrity's being notified of any action brought
against the Fund, its officers or trustees, or any such controlling person, such notification to be
given by letter or telegram addressed to Integrity at its principal office in Minot, North Dakota,
and sent to Integrity by the person against whom such action is brought, within ten days after the
summons or other first legal process shall have been served. The failure so to notify Integrity of
any such action shall not relieve Integrity from any liability that Integrity may have to the Fund,
its officers or trustees, or to such controlling person by reason of any such untrue or alleged
untrue statement or omission or alleged omission otherwise than on account of Integrity's indemnity
agreement contained in this paragraph 4.2. Integrity agrees to notify the Fund promptly of the
commencement of any litigation or proceedings against Integrity or any of its officers or governors
in connection with the issuance and sale of any Shares. 5

Source: INTEGRITY FUNDS, 485BPOS, 1/21/2020
<!-- page 6 -->
Section 4.3 In case any action shall be brought against any indemnified party under paragraph 4.1 or
4.2, and it shall notify the indemnifying party of the commencement thereof, the indemnifying party
shall be entitled to participate in, and, to the extent that it shall wish to do so, to assume the
defense thereof with counsel satisfactory to such indemnified party. If the indemnifying party opts
to assume the defense of such action, the indemnifying party will not be liable to the indemnified
party for any legal or other expenses subsequently incurred by the indemnified party in connection
with the defense thereof other than (a) reasonable costs of investigation or the furnishing of
documents or witnesses and (b) all reasonable fees and expenses of separate counsel to such
indemnified party if (i) the indemnifying party and the indemnified party shall have agreed to the
retention of such counsel or (ii) the indemnified party shall have concluded reasonably that
representation of the indemnifying party and the indemnified party by the same counsel would be
inappropriate due to actual or potential differing interests between them in the conduct of the
defense of such action. SECTION 5. EFFECTIVENESS OF REGISTRATION Section 5.1 None of the Shares
shall be offered by either Integrity or the Fund under any of the provisions of this Agreement and
no orders for the purchase or sale of the Shares hereunder shall be accepted by the Fund if and so
long as the effectiveness of the registration statement then in effect or any necessary amendments
thereto shall be suspended under any of the provisions of the 1933 Act or if and so long as a
current prospectus as required by Section 5(b)(2) of the 1933 Act is not on file with the SEC;
provided, however, that nothing contained in this paragraph 5 shall in any way restrict or have an
application to or bearing upon the Fund's obligation to repurchase Shares from any shareholder in
accordance with the provisions of the Fund's prospectus, statement of additional information, or
declaration of trust. SECTION 6. NOTICE TO INTEGRITY Section 6.1 The Fund agrees to advise Integrity
immediately in writing: 6

Source: INTEGRITY FUNDS, 485BPOS, 1/21/2020
<!-- page 7 -->
(a) of any request by the SEC for amendments to the registration statement, prospectus, or statement
of additional information then in effect or for additional information; (b) in the event of the
issuance by the SEC of any stop order suspending the effectiveness of the registration statement,
prospectus, or statement of additional information then in effect or the initiation of any
proceeding for that purpose; (c) of the happening of any event that makes untrue any statement of a
material fact made in the registration statement, prospectus, or statement of additional information
then in effect or that requires the making of a change in such registration statement, prospectus,
or statement of additional information in order to make the statement therein not misleading; and
(d) of all actions of the SEC with respect to any amendment to any registration statement,
prospectus, or statement of additional information which may from time to time be filed with the
SEC. SECTION 7. TERM OF AGREEMENT Section 7.1 This Agreement shall continue until January 18, 2022,
and thereafter shall continue automatically for successive annual periods ending on January 18th of
each year, provided such continuance is specifically approved at least annually by (a) the Fund's
Board of Trustees and (b) a vote of a majority (as defined in the 1940 Act) of the Fund's Trustees
who are not interested persons (as defined in the 1940 Act) of the Fund and who have no direct or
indirect financial interest in the operation of the Plan, in this Agreement, or any agreement
related to the Plan (the "Qualified Trustees"), by vote cast in person at a meeting called for the
purpose of voting on such approval. This Agreement is terminable with respect to the Fund, without
penalty, (a) on 60 days' written notice, by vote of a majority of the Qualified Trustees or by vote
of a majority (as defined in the 1940 Act) of the outstanding voting securities of the Fund or (b)
on 90 days' written notice by Integrity. This Agreement will also terminate automatically in the
event of its assignment (as defined in the 1940 Act). SECTION 8. MISCELLANEOUS Section 8.1 The Fund
recognizes that governors, officers, and employees of Integrity may from time to time serve as
directors, officers, and employees of corporations and business trusts (including other investment
companies) and that Integrity or its affiliates may enter into distribution or other agreements with
such other corporations and trusts. Section 8.2 It is expressly agreed that the obligations of the
Fund hereunder shall not be binding upon any of the trustees, shareholders, nominees, officers,
agents, or employees of the Fund, personally, but bind only the property of the Fund. The execution
and delivery of this Agreement have been authorized by the Trustees and signed by an authorized
officer of the Fund, acting as such, and neither such authorization by such Trustees nor such
execution and delivery by such officer shall be deemed to have been made by any of them individually
or to impose any liability on any of them personally, but shall bind only the property of the Fund.
7

Source: INTEGRITY FUNDS, 485BPOS, 1/21/2020
<!-- page 8 -->
Section 8.3 This Agreement shall be construed in accordance with the laws of the State of Kansas.
Section 8.4 This Agreement may be executed in any number of counterparts, each of which shall be
deemed to be an original; but such counterparts shall, together, constitute only one instrument.
Section 8.5 This Agreement may not be amended or modified in any manner except by both parties with
the same formality as this Agreement and as may be permitted or required by the 1940 Act. Section
8.6 The captions of this Agreement are included for convenience of reference only and in no way
define or delimit any of the provisions hereof or otherwise affect their construction or effect. In
Witness Whereof, the parties hereto have caused this Agreement to be executed as of the date first
set forth herein. Integrity Short Term Government Fund By: /s/ Shannon D. Radke Shannon D. Radke -
President Accepted: Integrity Funds Distributor, LLC By: /s/ Shannon D. Radke Shannon D. Radke -
President Dated: January 18, 2020 8

Source: INTEGRITY FUNDS, 485BPOS, 1/21/2020
