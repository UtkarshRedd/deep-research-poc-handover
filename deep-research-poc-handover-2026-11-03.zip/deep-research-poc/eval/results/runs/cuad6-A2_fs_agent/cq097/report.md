# What non-compete clause does the Exclusive Distributor Agreement between WATER NOW, INC...

*Question:* What non-compete clause does the Exclusive Distributor Agreement between WATER NOW, INC. and Hydraspin USA, Inc. (dated 2019-11-12) contain? Quote the clause and cite its page.

## Locate the Exclusive Distributor Agreement

The document between WATER NOW, INC. and Hydraspin USA, Inc. dated 2019-11-12 is present in the fixed set. [c3ea62bed0707060 p.1]

[GAP] The non-compete clause contained in the Exclusive Distributor Agreement is not provided in the evidence.

## Identify the non-compete clause

The only occurrence of "compete" in the document is "competent jurisdiction," which is not a non-compete clause. [c3ea62bed0707060 p.13] Section 2.1 Exclusivity and Territory appoints the Distributor as Hydraspin's exclusive distributor of the Products in the Territory during the term of the Agreement. [c3ea62bed0707060 p.3] This exclusivity appointment is not a non-compete clause. [c3ea62bed0707060 p.3]

[GAP] A non-compete clause is not present in the evidence.

## Verification appendix

Claims: 6 · supported: 4 · partially: 0 · dropped: 0 · gaps: 2 · tier-1 support rate: 1.00

| claim | section | tier 1 | score | sources | note |
|---|---|---|---|---|---|
| s1.1 | s1 | keep | 1.00 | e1→[c3ea62bed0707060 p.1] |  |
| s1.2 | s1 | gap |  |  |  |
| s2.1 | s2 | keep | 1.00 | e2→[c3ea62bed0707060 p.13] |  |
| s2.2 | s2 | keep | 1.00 | e3→[c3ea62bed0707060 p.3] |  |
| s2.3 | s2 | keep | 1.00 | e3→[c3ea62bed0707060 p.3] |  |
| s2.4 | s2 | gap |  |  |  |

### Evidence

- e1 [c3ea62bed0707060 p.1 L6-14] keep (1.0): "| Agreement Date | 2019-11-12 |
| Parties | WATER NOW, INC.; ("Water Now"); Hydraspin USA, Inc. ("Subsidiary", collectively with Water Now, "Hydraspin"); BESTEV MANAGEMENT, LLC ("Distributor"); Hydraspin and Distributor (“Party” and collect…"
- e2 [c3ea62bed0707060 p.13 L506-509] keep (1.0): "limit the right of a Party to seek injunctive or other equitable relief from a court of competent jurisdiction pending resolution of a dispute by arbitration."
- e3 [c3ea62bed0707060 p.3 L107-120] keep (1.0): "ARTICLE II. APPOINTMENT 2.1 Exclusivity and Territory. Hydraspin hereby appoints Distributor, and Distributor hereby accepts appointment, as Hydraspin's exclusive distributor of the Products in the Territory during the term of this Agreemen…"
