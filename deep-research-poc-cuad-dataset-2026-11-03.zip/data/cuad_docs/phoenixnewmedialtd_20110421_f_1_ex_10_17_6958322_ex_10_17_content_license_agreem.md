<!-- page 1 -->
# Program Content License Agreement
| Field | Value |
|---|---|
| Document Type | License Agreement |
| Agreement Date | 2009-11-24 |
| Parties | Phoenix Satellite Television Company Limited ("Party A""Phoenix Satellite TV"); Beijing Tianying Jiuzhou Network Technology Co., Ltd ("Party B") |
| Source | CUAD v1 / PhoenixNewMediaLtd_20110421_F-1_EX-10.17_6958322_EX-10.17_Content License Agreement |

Exhibit 10.17 Program Content License Agreement between Phoenix Satellite Television Company Limited
and Beijing Tianying Jiuzhou Network Technology Co., Ltd. November 24, 2009

Source: PHOENIX NEW MEDIA LTD, F-1, 4/21/2011
<!-- page 2 -->
Program Content License Agreement This Program Content License Agreement ("Agreement") is entered
into between the following two parties on November 24, 2009 in Beijing: Phoenix Satellite Television
Company Limited ("Party A" or "Phoenix Satellite TV"), a foreign enterprise duly established and
validly existing under the laws of Hong Kong Registered Address: No. 2-6, Dai King Street, Taipo
Industrial Estate, Taipo, N. T., H.K. Authorized Representative: Cui Qiang and Beijing Tianying
Jiuzhou Network Technology Co., Ltd. ("Party B"), a limited liability company duly registered and
validly existing under PRC laws Address: Floor 5 Information Building, No. 12 Zhongguancun South
Street, Haidian District, Beijing 100081 China Legal Representative: Qiao Hai Yan Party A and Party
B are hereinafter referred to individually as a "Party" and collectively as "Parties". WHEREAS: 1.
Party A owns copyrights and other related rights to the programs listed in Exhibit 1 hereto, as
amended from time to time; 2. In accordance with the "Agreement Between Phoenix Satellite TV and
Phoenix New Media Regarding Cooperation in the Fields of Content, Branding, Promotion and
Technology" dated November 24, 2009 between Phoenix Satellite Television Holdings Limited and
Phoenix Online (Beijing) Information Technology Co., Ltd., Party B has the right to operate the
Phoenix Satellite TV Websites (defined below) and Other Websites (defined below), provide Internet
information services such as news, entertainment, and business information, as well as computer
information services through such websites and transfer information from Phoenix Satellite TV to
mobile network clients, and authorize the use of the Phoenix Satellite TV program content by other
information network service providers (collectively, "Party B Business"); and 3. Both Parties agree
that Party A will provide the program content of Phoenix Satellite TV to Party B, subject to the
terms and conditions hereof. 2

Source: PHOENIX NEW MEDIA LTD, F-1, 4/21/2011
<!-- page 3 -->
NOW, THEREFORE, upon amicable consultation based on principles of equality, mutual benefit and
complementary advantage, the Parties have reached this Agreement as follows: ARTICLE ONE DEFINITION
1.1 Unless otherwise referenced herein, each of the terms used herein shall have the meaning
ascribed to it below: (i) "Affiliate", with respect to any Party hereto, shall mean any legal
person, non-legal person economic organization, or natural person, which owns a controlling interest
in, or which is controlling, controlled by or under common control with, such Party, directly or
indirectly. As used in this Agreement, "control" means the power of any person to direct or cause
the direction of management and policies of another party on account of such person's ownership of
equity interest, voting right, the right to appoint directors, by contract or otherwise. (ii)
"Business Day" shall mean a date on which commercial banks open for business, other than Saturdays,
Sundays and public holidays in mainland China. (iii) "Intellectual Property Right" shall mean
authorship right, proprietary trademark right, patent right, business secret ownership right and
other intellectual property right under PRC Law. (iv) "Other Websites" shall mean Internet websites
whose domain name are licensed by Party A or its Affiliate to Party B and which are operated and
managed by Party B upon Party A's approval in writing, other than the Phoenix Satellite TV Websites.
(v) "Phoenix Satellite TV Websites" shall mean Internet websites which have the domain name of
www.ifeng.com, www.phoenixtv.com or www.phoenixtv.com.cn. (vi) "Program Content", with respect to
this Agreement, shall mean all program content set forth in Exhibit 1 to which Party A owns Internet
and media copyrights and which are required for Party B Business, including but not limited to
programs on news, policy trends, entertainment, business and economic trends. 3

Source: PHOENIX NEW MEDIA LTD, F-1, 4/21/2011
<!-- page 4 -->
(vii) "Program Content Collection" shall mean the collection of Program Content from Phoenix
Satellite TV's Chinese Channel, other professional news media, or other information sources. (viii)
"PRC Law" shall mean all laws, ordinances, rules, orders, notices, regulations and other regulatory
documents having legal binding force, as promulgated from time to time prior to and after the date
on which this Agreement becomes effective. (iv) "Taxes" shall mean taxes and fees of all kinds,
including all taxes collected in China (including by the central PRC government and various local
governments) and in any other jurisdiction, including but not limited to all kinds of ownership tax,
interest tax, value added tax, stamp tax, and land and property use tax collected or levied on
capital, profit, revenue, sales, or any other taxable item; all duties, fees, deductions,
withholding tax, withholding income tax, or penalties or other payment in connection with taxes; and
the term "Taxes" shall be interpreted accordingly. (v) "Third Party", with respect to this
Agreement, shall mean any company, enterprise, other economic organization or individual, other than
the Parties hereto. ARTICLE TWO BASIC PRINCIPLES OF THE LICENSE 2.1 Party B may use the Program
Content licensed by Party A only in Party B Business. Without Party A's consent in writing, Party B
may not in any way use the Program Content provided by Party A for any purposes other than in
connection with Party B Business, nor may Party B permit any third party to use in any way the
Program Content licensed by Party A to Party B prior to the publishing of the Program Content on the
Phoenix Satellite TV Websites or Other Websites. 2.2 The Parties shall provide the services
hereunder fairly and reasonably as if they were unaffiliated entities in an arm's-length
transaction. 2.3 Without Party A's consent, Party B may not enter into with any third party any
agreement or cooperation which is identical with or similar to this Agreement. 2.4 If other services
are required by Party B in Party B Business, Party B shall first provide Party A with the content
and requirements of such services in writing. If Party A indicates expressly in writing that it
refuses or is unable to provide such services, Party B may turn to third parties for such other
services; if, however, Party A agrees to provide such services, then the Parties shall 4

Source: PHOENIX NEW MEDIA LTD, F-1, 4/21/2011
<!-- page 5 -->
negotiate in good faith the content, method and fees of such services. 2.5 In the event of any
delay, non-performance or partial performance of any obligations hereunder by Party A, Party A shall
give Party B prompt notice in writing and make best effort to assist Party B in obtaining identical
or similar program content from other channels. 2.6 During the course of Party A's provision of the
services hereunder, Party B shall provide all assistance reasonably required by Party A. ARTICLE
THREE SERVICE SCOPE AND METHOD OF PROVISION 3.1 Both Parties agree that Party A shall license the
Program Content required in Party B Business to Party B, and Party B shall accept the services
provided by Party A, to the extent, at the time or times, and in the manner as agreed to by the
Parties herein. 3.2 The Program Content to be licensed by Party A to Party B shall be as set forth
in Exhibit 1 hereto, as updated from time to time. If the Program Content required by Party B is
beyond that listed on Exhibit 1, as updated from time to time, Party B shall send its written
request to Party A promptly and the latter shall license the Program Content described in the
preceding phrase to Party B to the extent it has power to do so in accordance with this Agreement.
3.3 In each May during the term of this Agreement, both Parties shall update and adjust the scope of
Program Content listed in Exhibit 1 and the Program Content so adjusted shall be the Program Content
to be licensed by Party A to Party B for the period of time from May of such year to the next
succeeding May. The then adjusted scope of Program Content shall constitute an exhibit hereto and
process equal validity as this Agreement. ARTICLE FOUR SERVICE FEE 4.1 The amount of the service fee
and its terms of payment shall be as set forth in Attachment 1 to the "Agreement Between Phoenix
Satellite TV and Phoenix New Media Regarding Cooperation in the Fields of Content, Branding,
Promotion and Technology" dated November 24, 2009 between Phoenix Satellite Television Holdings
Limited and Phoenix Online (Beijing) Information Technology Co., Ltd. ("Phoenix Online"). 4.2 The
Parties may enter into a separate agreement and establish specific fee rates in respect of services
beyond this Agreement in accordance with the principles set forth herein. 5

Source: PHOENIX NEW MEDIA LTD, F-1, 4/21/2011
<!-- page 6 -->
ARTICLE FIVE INTELLECTUAL PROPERTY RIGHTS TO THE PROGRAM CONTENT 5.1 Both Parties acknowledge and
agree that with respect to Program Content licensed to Party B hereunder, Party B shall not have any
copyright or any other Intellectual Property Right. If Party B obtains any Intellectual Property
Right in respect of the Program Content during its use of the same, Party B shall notify Party A
and, upon its request in writing, sign all documents and take all actions required to assign such
Intellectual Property Right to Party A, and ensure the Intellectual Property Right so obtained by
Party A is legitimate, complete, and free from any encumbrance. 5.2 In the event of any legal action
taken by Party A to protect any Intellectual Property Right of the Program Content, or any dispute
with any third party in connection with any Intellectual Property Right of the Program Content in
which Party A is involved (including but not limited to Party A's being the plaintiff/applicant or
defendant/respondent in any lawsuit or arbitration), Party B shall provide, at the cost of Part A;
all assistance reasonably requested by Party A, provided, however, that if the legal action taken by
Party A or the dispute in which Party A is involved is due to or related to Party B's negligence,
then the cost of providing such assistance requested by Party A shall be borne by Party B. 5.3 If
Party B becomes aware of any violation of any Intellectual Property Right to the Program Content
provided by Party A to Party B, it shall take all measures reasonably necessary to preserve the
evidence of such third party violation, notify Party A of the same as soon as reasonably possible,
and take actions reasonably requested by Party A to assist in legal actions taken or claims made by
Party A in order to protect its Intellectual Property Right. 5.4 If, for causes attributable to
Party B, Party A sustains any economic losses as a result of any dispute with any third party over
the Program Content provided by Party A, Party B agrees to indemnify Party A for all such losses,
which losses shall include only the direct losses and reasonable expenses incurred in resolving such
dispute (including reasonable attorney fees). ARTICLE SIX PARTY B'S OBLIGATIONS WITH RESPECT TO
CONFIDENTIAL INFORMATION 6.1 When providing the Program Content to Party B, Party A may specify the
special purpose for which such Program Content shall be used, the extent to which such Program
Content shall be transmitted, the time or times at which such Program Content shall be transmitted
(including the time at which such Program Content is published on the Phoenix Satellite TV Website
or Other 6

Source: PHOENIX NEW MEDIA LTD, F-1, 4/21/2011
<!-- page 7 -->
Websites, or the time at which such Program Content is licensed to any third party by Party B), and
the manner by which such Program Content shall be transmitted (including the manner by which such
Program Content is published on the Phoenix Satellite TV Websites or Other Websites, or the manner
in which such Program Content shall be used by the licensed third party). Party B's use of the
Program Content shall be in strict compliance with Party A's requirements. 6.2 Party B shall keep in
confidence Party A's business secrets of which Party B may be aware on account of Party B's receipt
from Party A of the license to use the Program Content. Upon the termination of this Agreement,
Party B shall return to Party A or destroy any document, material or software containing such
business secrets and delete the same from any memory devices. 6.3 Party B warrants that it will take
all technical methods and confidential measures reasonably available to Party B to ensure that only
Party A and certain of Party B personnel designated by Party A may have access to the Program
Content licensed by Party A to Party B. Without Party A's permission in writing, Party B may not
disclose or sublicense the Program Content to any third party, except for the Program Content
related to Party B Business. ARTICLE SEVEN REPRESENTATIONS AND WARRANTIES 7.1 Party A represents and
warrants that 7.1.1 it owns copyrights and other related rights to the Program Content set forth in
Exhibit 1 hereto, as updated from time to time; 7.1.2 it has taken all appropriate and necessary
corporate actions and other actions, authorized the execution and performance of this Agreement, and
obtained all appropriate consents, approvals and authorizations required for the execution and
performance of this Agreement; and 7.1.3 its signing and performance of this Agreement will not
violate or contradict any of its constitutional documents, laws and regulations applicable to it, or
any agreement or contract to which it is a party or by which it is bound. 7.2 Party B represents and
warrants that 7.2.1 it has taken all appropriate and necessary corporate action and other actions,
authorized the execution and performance of this Agreement, 7

Source: PHOENIX NEW MEDIA LTD, F-1, 4/21/2011
<!-- page 8 -->
and obtained all appropriate consents, approvals and authorizations required for the execution and
performance of this Agreement; and 7.2.2 its signing and performance of this Agreement will not
violate or contradict any of its constitutional documents, laws and regulations applicable to it, or
any agreements or contracts to which it is a party or by which it is bound. ARTICLE EIGHT
LIABILITIES FOR BREACH; TERMINATION 8.1 Both Parties agree that any breach of any of the warranties,
covenants, or provisions hereof by either Party shall constitute a breach of this Agreement, except
under circumstances described in Section 8.2 below. In the event of any breach of this Agreement by
any Party hereto, the breaching Party shall indemnify the other Party for all of such other Parties
losses arising therefrom, which losses shall include only direct losses, reasonable expenses and
reasonable attorney fees. 8.2 In the event that 8.2.1 one Party is in breach of its obligations
hereunder and fails to cure such breach within ten (10) Business Days following the other Party's
written notice thereof, then the non-breaching Party may terminate this Agreement; 8.2.2 one Party
enters into a bankruptcy process, Party B's shareholder or equity structure changes (not including
changes to Party B's shareholder or equity structure due to the Exclusive Call Option Agreement and
Equity Pledge Agreement dated between Party B, Phoenix Online and other relevant parties), or one
Party ceases its business operation, then the other Party may send a written notice of termination
to such Party and this Agreement shall terminate as of the date on which such written notice is
served to such Party; 8.2.3 one Party's performance of its obligations hereunder is held unlawful
under the PRC Law, such Party may send a written notice of termination to the other Party upon the
promulgation of the relevant PRC Law; 8.2.4 one Party's performance of its obligations hereunder
(including but not limited to such Party's ability to perform this Agreement) is, in the reasonable
judgment of the other Party, adversely affected by the occurrence of any event, then the unaffected
Party may terminate this Agreement upon notifying the other Party in writing; and 8

8.2.5 in exercising its right to terminate this Agreement pursuant to Subsections 8.2.1 to 8.2.4,
one Party shall give a written notice of termination to the other Party, without the necessity of
obtaining consent from the other Party, and this Agreement shall terminate as of the date on which
such written notice is served to the other Party. 8.3 No compensation or indemnification will be
required to be made by one Party to the other Party when one Party exercises its right to terminate
this Agreement unilaterally pursuant to this Article Eight and no rights or interests of the
terminating Party will be adversely affected by the termination of this Agreement. 8.4 Subsection
8.1 shall survive the termination of this Agreement. ARTICLE NINE EFFECTIVENESS 9.1 This Agreement
shall become effective on the date on which it is signed and affixed with the corporate seals by the
authorized representative of each Party and have a term of five (5) years commencing as of the
effective date hereof. 9.2 Upon confirmation by the licensor in writing prior to the expiration of
the term hereof, this Agreement may be extended for as long as may be agreed to by both the licensor
and licensee through negotiation, provided, however, that the licensee shall not have the right to
decide the extension of the term hereof. ARTICLE TEN FORCE MAJEURE In the event that a Party's
performance of this Agreement or any covenants of the Parties is directly affected by an earthquake,
typhoon, flood, fire, war, computer virus, design loophole in any software tool, hacker attack on
the Internet, amendment to law or policy or any other event of force majeure which is not
foreseeable or the result of which is not to be prevented or avoided, such Party shall immediately
give the other Party a notice by fax of such event and within thirty days (30) thereafter provide a
detailed report thereof as well as a certification document explaining the cause for the
non-performance or delayed performance of this Agreement, which certification document shall be
issued by the public notary of the region in which the event of force majeure occurred. The Parties
shall decide through consultation whether performance of this Agreement, in whole or in part, shall
be relieved or delayed to the extent affected by such event. With respect to economic losses
sustained by either Party as a result of such event, neither Party shall be liable therefor. 9

Source: PHOENIX NEW MEDIA LTD, F-1, 4/21/2011
<!-- page 9 -->
ARTICLE ELEVEN APPLICABLE LAW; DISPUTE RESOLUTION 11.1 The execution, validity, interpretation,
enforcement and dispute resolution of this Agreement shall be governed by the PRC Law. 11.2 Any
dispute, conflict or claim arising out of or in connection with this Agreement or the performance
hereof shall be resolved by the Parties through amicable negotiation, which negotiation shall
commence immediately upon notice by one Party to the other of the nature of such dispute, conflict
or claim. In the event that such dispute is not resolved within thirty (30) Business Days following
such notice, either Party may upon the expiration of the such 30-day notice period submit such
dispute to arbitration by the Hong Kong International Arbitration Centre in accordance with the
arbitration rules of such centre then in effect. The arbitration shall be conducted in Hong Kong in
English and the arbitral award shall be binding upon both Parties. During the resolution (including
the arbitration) of the dispute, the Parties shall continue to perform other portions of this
Agreement unaffected by such dispute. ARTICLE TWELVE TAXES Both Parties agree that any and all Taxes
payable on account of this Agreement or the performance hereof shall be paid by the Party incurring
such Taxes. ARTICLE THIRTEEN MISCELLANEOUS 13.1 Party B may not assign its rights and obligations
hereunder without Party A's consent in writing and the successors and permitted assigns of the
Parties shall be bound by this Agreement. 13.2 Failure to exercise or delay in exercising any right,
power, or privilege provided by this Agreement shall not be deemed a waiver of such right, power, or
privilege and any partial exercise of such right, power or privilege shall not hinder any future
exercise of such right, power or privilege. 13.3 The rights, power and remedies provided for Party A
and Party B herein are cumulative and not exclusive, and shall be in addition to any other rights,
power or remedies provided by law, regulation, contract or otherwise now or hereafter in effect.
13.4 Any and all notices, approvals, requests, authorizations, instructions or other communications
required hereunder (collectively, "Written Documents") shall be made in writing and with a reference
to this Agreement. A Written Document shall be deemed duly given by one Party to the other upon
personal delivery to the address of the other Party; or on a date which is four (4) business days
from the date on which the Written Document is posted through registered or certified mail (postage
prepaid and return receipt 10

Source: PHOENIX NEW MEDIA LTD, F-1, 4/21/2011
<!-- page 10 -->
requested), regardless of whether the Written Document is actually received; or on the first
business day following the date on which the Written Document is sent by express service (as
indicated by the written receipt confirmation); or as indicated on the confirmation report of the
fax machine confirming that the Written Document is delivered by fax successfully. 13.5 This
Agreement shall supersede all other agreements, written or oral, of the Parties regarding the
subject matter of this Agreement and constitutes the entire agreement of the Parties concerning such
subject matter. 13.6 This Agreement shall be signed in two (2) original copies in Chinese, with each
of Party A and Party B holding one (1) copy, and both copies shall be equally authentic. IN WITNESS
HEREOF, the Parties have signed this Agreement as of the date first written above. [Remainder of
this page intentionally left blank] 11

Source: PHOENIX NEW MEDIA LTD, F-1, 4/21/2011

[signature page] Party A: Phoenix Satellite Television Company Limited

Party B: Beijing Tianying Jiuzhou Network Technology Co., Ltd. Authorized Representative: 12
<!-- page 11 -->
Authorized Representative: /s/ Keung Chui

Source: PHOENIX NEW MEDIA LTD, F-1, 4/21/2011

[signature page] Party A: Phoenix Satellite Television Company Limited Authorized Representative:
Party B: Beijing Tianying Jiuzhou Network Technology Co., Ltd.

13
<!-- page 12 -->
Authorized Representative: /s/ Ming Chen

Source: PHOENIX NEW MEDIA LTD, F-1, 4/21/2011
<!-- page 13 -->
EXHIBIT 1 Program Content licensed by Party A to Party B: Phoenix infonews channel Stock Market
Snapshot Current Affairs Debate News Talk Financial Journal News Magnifier * Stock Market Express
Celebrated China Heritage Taiwan Weekly Focus Hong Kong Viewpoint Journalist On The Spot Finance
Point To Point Mainland Q&A Phoenix Chinese channel Studying Around Greater China with Yang Jinlin
My Patriotic Heart Belle Gourmet China Forum Phoenix Aerostation Mainland Q&A Wisdom From The East
Dialogue With World Leaders Tiger Talk Premium Spectacular China Impression Southern China Anecdote
National Centre For The Performing Arts * Inside Big Cases * Starface * 14

Source: PHOENIX NEW MEDIA LTD, F-1, 4/21/2011
<!-- page 14 -->
A Date With Luyu Eight-Minute Reading Entertainment Whirlwind * Lawrence Viewpoint Sisy's News Peter
Qiu's Talk Shi Ping Financial Insight Hacker Zhao Shao Kang Panoramic Eyeshot Of Phoenix * Emergent
China Trendy Guide: Cat Walk Art Of Taste Secret Documentary Observation Post Of Military Situation
Social Watch Head Start In Finance From Phoenix To The World * Newsline Behind The Headlines With
Wentao Celebrity Museum

* excluding the music contained in the Program Content, pieces and data authorized by third party to
Phoenix Satellite TV and pieces and materials which are not produced by Phoenix Satellite TV itself.
15

Source: PHOENIX NEW MEDIA LTD, F-1, 4/21/2011
