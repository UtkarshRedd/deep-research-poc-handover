<!-- page 1 -->
# PROMOTION AGREEMENT
| Field | Value |
|---|---|
| Document Type | Promotion Agreement |
| Agreement Date | 2009-06-29 |
| Parties | Charity Tunes Inc. ("Charity Tunes"); ConAgra Foods Canada Inc. ("Sponsor") |
| Source | CUAD v1 / ON4COMMUNICATIONSINC_07_02_2009-EX-10.1-PROMOTION AGREEMENT |

925 West Georgia Street Suite 1820 Vancouver, British Columbia Canada V6C 3L2 Facsimile:
604-632-1730 PROMOTION AGREEMENT (the "Agreement") This agreement (the "Agreement") is made between
Charity Tunes Inc., a British Columbia corporation with registered office located at Suite 1800, 925
West Georgia Street, Vancouver, British Columbia, Canada V6C 3L2 ("Charity Tunes") and ConAgra Foods
Canada Inc. ("Sponsor") a Canada corporation, 5935 Airport Rd, Suite 405, Mississauga, Ontario,
Canada L4V 1W5. WHEREAS as a new initiative, Charity Tunes and Sponsor will enter into a promotional
partnership, whereby Sponsor will offer Charity Tunes music downloads on Sponsor's Pogo products
consistent with the terms and conditions of this Agreement (the "Promotion"). NOW THEREFORE in
consideration of the mutual covenants made herein, and for other good and valuable consideration,
the receipt and sufficiency of which are hereby acknowledged by each Charity Tunes and Sponsor, the
parties agree as follows

A consumer who purchases a specially Designated Sponsor Product (as defined below) will receive
exactly one (1) unique pin code (a "Pin Code") in-pack. Such a consumer wil l be entitled to visit a
custom interactive landing page at the CharityTunes.com website to enter the unique code and
consumer's valid email address to receive downloads up to a maximum of either three (3), five (5),
or seven (7) free MP3 song downloads having a retail value of $1.29 per song or less. Charity Tunes
shall make its music catalogue available to the purchasers in MP3 file format to the fullest extent
that such format is available to Charity Tunes pursuant to any agreements in effect between Charity
Tunes and its wholesalers on the date of this Agreement. Accordingly, Charity Tunes shall use its
best efforts to update its music catalogue with available MP3 files by June 30, 2009. The custom
interactive landing page shall be designed, operated and maintained at the expense of Sponsor, and
shall be subject to the mutual approval by Charity Tunes and Sponsor, which approval shall not be
unreasonably withheld. The landing page shall feature the Charity Tunes logo in a size and
prominence substantially equal to that of Sponsor.

POGO 8 pack, POGO 10 pack, POGO 20 pack and POGO 30 pack products sold at participating retail
locations in Canada (individually and collectively the "Designated Sponsor Products") are the only
products for which a Pin Code will be distributed and each consumer who purchases a Designated
Sponsor Product will receive one and only one Pin Code while supplies last and subject to the
limitations detailed herein. A Pin Code for three (3) songs shall be distributed exclusively with
POGO 8 or 10 packs. A Pin Code for five (5) songs shall be distributed exclusively with POGO 20
packs. A Pin Code for seven (7) songs shall be distributed exclusively with POGO 30 packs.
Designated Sponsor Products sold by Sponsor with the Promotion offer may not be sold at a higher
list price than the same (or substantially similar) product(s) that do not contain the Promotion
offer. Pin Codes themselves may not be retailed in any way.

1.PROMOTION OFFER:

2.DESIGNATED SPONSOR PRODUCTS:

1
<!-- page 2 -->
Pin codes will only be distributed in the Designated Sponsor Products during the Promotion Period
(defined below). The total number of Pin Codes to be distributed as prizes in the Promotion shall
not exceed: (i) 277,760 Pin Codes containing three (3) music downloads per Pin Code ; (ii) 130,300
Pin Codes containing five (5) music downloads per Pin Code; and (iii) 27,900 Pin Codes containing
seven (7) music downloads per Pin Code. No Designated Sponsor Product shall contain more than 1 Pin
Code per pack. The distribution limits stated above are the maximum number of Pin Codes that may be
distributed in the Promotion. No 3- song, 5-song, or 7-song Pin Codes may be subdivided, duplicated
or distributed in combination with one another. Charity Tunes agrees to generate the unique Pin
Codes for the Promotion. The parties therefore understand and acknowledge the critical need to
maintain in absolute secrecy the Pin Codes generated for the Promotion such that they are only
disclosed to the appropriate recipient via the authorized distribution method described herein. If
the Pin Codes are made available to the public by Sponsor or by any of its employees, officers,
directors, consultants, agents, representatives or advisors, except in the manner provided for
herein, all parties agree that Pin Code security will be deemed compromised, and Charity Tunes may
terminate all subsequent Pin Code redemptions. Sponsor agrees that it will not increase the list
price to its customers of Designated Sponsor Products that form part of this promotion as compared
to its otherwise identical products that do not form part of the promotion.

The offer shall be communicated to potential consumers only via in-store on-pack advertising, and
retailer flyer advertising. Any communication of offer, including but not limited to Sponsor's rules
for the Promotion, must indicate that the offer is only available while supplies last.

A consumer who receives a Pin Code for a designated number of music downloads in accordance with
paragraph 3 above will be directed to visit the custom interactive landing page in order to redeem
his/her free music downloads. Consumer will have to enter the Pin Code in order to complete the
transaction. Consumer will be required to enter the Pin Code exactly as it appears in the email and
follow the instructions on the web site to download the selected music download. In no case may any
Pin Code be redeemed later than March 31, 2010. To assist as required with the redemption process,
consumers shall have access to Charity Tunes customer support by emailing at
support@charitytunes.com.

Sponsor shall received 435,960 unique Pin Codes for this Promotion and Sponsor is responsible for
maintaining a record of all Pin Codes distributed or withheld, such record being subject to the
confidentiality terms set forth above.

Designated Sponsor Products with Pin Codes may be distributed from approximately October 1, 2009 to
approximately December 31, 2009 (the "Promotion Period"). Eligible Pin Codes may be entered on the
www.charitytunes.com website and corresponding music downloaded from October 1, 2009 to March 31,
2010. Pin Codes entered for redemption after 11:59:59 pm PT on March 31, 2010 may be rejected as
ineligible. The contents of this section are to be reflected in the Sponsor's rules for the
Promotion.

The Charity Tunes system used for redemption of downloads will ensure that (i) downloads are
obtained under the Promotion only by way of redemption of eligible Pin Codes and only up to the
maximum number of music downloads per Pin Code set out at paragraph 3 above, (ii) otherwise eligible
Pin Codes are invalidated once they have been used to download their respective per Pin Code
maximum, and (iii) the total maximum download limits described herein are observed.

3.DISTRIBUTION:

4.COMMUNICATION OF OFFER:

5.PROMOTION MECHANIC:

6.GENERATION / PRINTING OF CODES:

7.PROMOTION PERIOD:

8.SECURITY & VERIFICATION:

2
<!-- page 3 -->
The Pin Codes that will be distributed to consumers of the Designated Sponsor Products under the
Promotion will be set with parental controls and will not allow any user download content that has
been designated by Charity Tunes music providers as containing explicit content.

Upon execution of this Agreement by both parties, Charity Tunes will invoice Sponsor for 435,960
unique codes consisting of a maximum of 277,760 Pin Codes containing three (3) music downloads per
Pin Code ; (ii) 130,300 Pin Codes containing five (5) music downloads per Pin Code; and (iii) 27,900
Pin Codes containing seven (7) music downloads per Pin Code, for a total cost of $117,605.60 CDN
(plus applicable taxes) (collectively the "Fee"), which Fee is calculated at the rate of $0.07 CND
(plus applicable taxes) per potential download. The Fee shall be payable to Charity Tunes in two
equal installments of $58,802.80 (plus applicable taxes) due to Charity Tunes on October 1, 2009 and
November 1, 2009, respectively payable upon receipt of invoice.

In consideration of the fees paid by Sponsor as set out herein, Charity Tunes agrees that during the
period beginning October 1, 2009 and ending March 31, 2010, Charity Tunes shall not enable another
program sponsorship for all competitive products/product categories distributed/sold within the
total Canadian consumer/retail/wholesale market place, inclusive of: - Total Frozen Handhelds -
Total Corporation General Mills Handhelds - Total Pizza Pops Handhelds / total Pillsbury Mini Pizzas
- Total Corporation McCain Foods Handhelds - Total Pizza Pockets / total McCain Mini Pizzas - Total
Corporation Heinz Handhelds - Total Heinz Hot bites (Bagel Bites and Taco Bites) / total Anchor
Poppers - Total Corporation Schneider Foods Handhelds - Total Hot Stuffs / total Lean Stuffs - Total
Resers Burritos - Total Corp les Plats du Chef Handhelds - Total Hinsdale Farms Corndogs

9.EXPLICIT CONTENT:

10.FEE:

11.WARRANTY AND INDEMNITY:

11.1Warranty. Charity Tunes warrants that, subject only to any limitation or condition specified in
this Agreement, it will provide immediately to any consumer entitled to a music download in
connection with a Pin Code the music download selected by that consumer.

11.2Obligations upon any breach. If for any reason Charity Tunes fails to provide a music download
to a consumer in accordance with clause 11.1, thereby breaching its warranty thereunder, it shall:
(i) forthwith remedy that failure by providing the requested download to that consumer as soon as
possible; (ii) forthwith provide notice to Sponsor of the failure to immediately provide the
download, including the date, time and other details of the failure, and of the steps being taken
forthwith to remedy the failure; and (iii) once the failure has been remedied by Charity Tunes,
forthwith provide Sponsor with notice of same.

11.3Indemnity. Furthermore, Charity Tunes will indemnify, save and hold harmless Sponsor, its
shareholders, officers, agents and affiliated companies from and against any and all claims,
investigations, lawsuits, losses, damages, costs, payments, charges, expenses and attorneys fees,
including any amount paid to settle an action or to satisfy a judgment by or for the benefit of any
person, that they, or any of them, may at any time incur as a result of any breach of this Agreement
by Charity Tunes.

12.EXCLUSIVITY:

3
<!-- page 4 -->
13.GENERAL:

13.1Relationship between the Parties. Nothing in this Agreement shall be construed as creating any
relationship (whether by way of employer/employee, agency, joint venture, association, or
partnership). It is expressly understood that the relationship between the parties shall be that of
independent contractors, whether for the purposes of the Income Tax Act (Canada), provincial
taxation legislation or otherwise.

13.2Time. Time is of the essence of this Agreement.

13.3Presumption. This Agreement or any section thereof shall not be construed against any party due
to the fact that said Agreement or any section thereof was drafted by said party.

13.4Titles and Captions. All article, section and paragraph titles or captions contained in this
Agreement are for convenience only and shall not be deemed part of the context nor affect the
interpretation of this Agreement.

13.5Further Action. The parties hereto shall execute and deliver all documents, provide all
information and take or forbear from all such action as may be necessary or appropriate to achieve
the purposes of this Agreement.

13.6Good Faith, Cooperation and Due Diligence. The parties hereto covenant, warrant and represent to
each other good faith, complete cooperation, due diligence and honesty in fact in the performance of
all obligations of the parties pursuant to this Agreement. All promises and covenants are mutual and
dependent.

13.7Savings Clause. If any provision of this Agreement, or the application of such provision to any
person or circumstance, shall be held invalid, the remainder of this Agreement, or the application
of such provision to persons or circumstances other than those as to which it is held invalid, shall
not be affected thereby.

13.8Assignment. This Agreement may not be assigned by either party hereto without the written
consent of the other but shall be binding upon the successors of the parties.

13.9Notices. All notices required or permitted to be given under this Agreement shall be given in
writing and shall be delivered, either personally or by express delivery service, to the party to be
notified. Notice to each party shall be deemed to have been duly given upon delivery, personally or
by courier, addressed to the attention of the officer at the address set forth heretofore, or to
such other officer or addresses as either party may designate, upon at least ten days written
notice, to the other party.

13.10Entire agreement. This Agreement contains the entire understanding and agreement among the
parties. There are no other agreements, conditions or representations, oral or written, express or
implied, with regard thereto. This Agreement may be amended only in writing signed by all parties.

13.11Waiver. A delay or failure by any party to exercise a right under this Agreement, or a partial
or single exercise of that right, shall not constitute a waiver of that or any other right.

4
<!-- page 5 -->
IN WITNESS WHEREOF, the parties have duly executed and delivered this Agreement:

5

13.12Counterparts. This Agreement may be executed in counterparts, each of which shall be deemed an
original, but all of which together shall constitute one and the same Agreement. In the event that
the document is signed by one party and faxed to another the parties agree that a faxed signature
shall be binding upon the parties to this Agreement as though the signature was an original.

13.13Successors. The provisions of this Agreement shall be binding upon all parties, their
successors and permitted assigns.

13.14Counsel. The parties expressly acknowledge that each has been advised to seek separate counsel
for advice in this matter and has been given a reasonable opportunity to do so.

13.15Law and Jurisdiction. This Agreement shall be governed by the laws of the Province of Ontario
and the federal laws of Canada applicable therein. The parties hereby attorn to the exclusive
jurisdiction of the provincial and federal courts located in the city of Toronto, Ontario for all
matters arising from this Agreement.

Signed in agreement: /s/ Marko Bukovec Marko Bukovec Title: Marketing Director ConAgra Foods Canada
Inc. Date:June 25, 2009

Signed in agreement: /s/ Robin Ram Robin Ram President Charity Tunes, Inc. Date: June 29, 2009
