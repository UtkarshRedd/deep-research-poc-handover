<!-- page 1 -->
# DOMAIN NAME AND CONTENT LICENSE AGREEMENT
| Field | Value |
|---|---|
| Document Type | License Agreement |
| SEC Filing Date | 2014-01-21 |
| Parties | Beijing SINA Internet Information Service Co., Ltd ("Licensor"); Beijing Yisheng Leju Information Services Co., Ltd ("Licensee" and together with Licensor, the "Parties" and each a "Party") |
| Source | CUAD v1 / LejuHoldingsLtd_20140121_DRS (on F-1)_EX-10.26_8473102_EX-10.26_Content License Agreement1 |

Exhibit 10.26 EXECUTION VERSION CONFIDENTIAL DOMAIN NAME AND CONTENT LICENSE AGREEMENT This Domain
Name and Content License Agreement (the "Agreement") is made and entered into, by and between
Beijing SINA Internet Information Service Co., Ltd. (北京新浪互联信息服务有限公司), a limited liability company
organized under the laws of the People's Republic of China (hereinafter "Licensor") and Beijing
Yisheng Leju Information Services Co., Ltd., a limited liability company organized under the laws of
the People's Republic of China ("Licensee" and together with Licensor, the "Parties" and each a
"Party") and is made effective as of the Effective Date (defined below). RECITALS WHEREAS, SINA
Corporation, a company organized under the laws of the Cayman Islands ("SINA"), and CRIC Holdings
Limited, a company organized under the laws of the Cayman Islands ("CRIC"), entered into that
certain Share Purchase Agreement dated July 23, 2009 (the "Share Purchase Agreement"), pursuant to
which SINA subscribes from CRIC the Subscription Shares (as defined in the Share Purchase
Agreement); WHEREAS, Licensor is the registrant of certain domain names as more particularly
described below that are related to the Business which it desires to license to Licensee and
Licensee desires to obtain a license from Licensor to such domain names to use in connection with
its operation of the Business on the terms and conditions set forth herein; and WHEREAS, Licensor
and Shanghai SINA Leju Information Technology Co. Ltd. ("SINA Leju") entered into that certain
Domain Name License Agreement dated May 8, 2008 (the "Original Agreement") and (i) Licensor and SINA
Leju desire to terminate the Original Agreement pursuant to the Mutual Termination Agreement
attached hereto as Exhibit B and (ii) Licensee and Licensor desire to enter into this Agreement, on
or prior to the consummation of the transactions contemplated by the Share Purchase Agreement. NOW,
THEREFORE, for and in consideration of the mutual covenants and agreement of the Parties and the
faithful performance thereof, and other good and valuable consideration, the receipt and sufficiency
of which are hereby acknowledged, the Parties hereto agree as follows: ARTICLE I DEFINITIONS As used
herein, the following terms shall have the meanings ascribed to them below. "Action" has the meaning
set forth in Section 8.1. "Affiliate" means, when used with respect to any specified Person, a
Person that directly or indirectly through one or more intermediaries, controls, is controlled by,
or is under common control with, such specified Person. For the purposes of this definition,
"control" (including the terms "controlled by" and "under common control with") with respect to the

Source: LEJU HOLDINGS LTD, DRS (on F-1), 1/21/2014
<!-- page 2 -->
relationship between or among two or more Persons, means the possession, directly or indirectly or
as trustee, personal representative or executor, of the power to direct or cause the direction of
the affairs or management of a Person, whether through the ownership of voting securities, as
trustee, personal representative or executor, by contract, credit arrangement or otherwise. "Agency
Agreement" means that certain Advertising Sale Agency Agreement by and between SINA Corporation and
China Online Housing Technology Corporation, dated as of the date hereof. "Business" means an online
real estate media platform in the PRC that (i) provides information and updates related to real
estate, home furnishing and construction in the PRC and provides real estate, home furnishing and
construction advertising services, and (ii) operates a business-to-business and business-to-consumer
Internet platform targeting participants in the PRC real estate industry, in each case, as currently
conducted or contemplated to be conducted on the websites owned or operated by Licensee or any of
Licensee's Affiliates in the PRC. "Business Day" means any day that is not a Saturday, a Sunday or
other day on which banks are required or authorized by Law to be closed in Beijing. "Change of
Control" means (i) the consummation of any acquisition or purchase, directly or indirectly, by any
Person or related group of Persons, that results in a Competitor owning more ordinary shares in CRIC
than E-House and SINA, and in each case, their respective controlled Affiliates, own in the
aggregate or (ii) an event pursuant to which a Competitor acquires the right to nominate a member to
the board of directors of CRIC. "Claimant" has the meaning set forth in Section 10.12. "Commission"
has the meaning set forth in Section 10.12. "Competitor" means any Person whose business includes an
online portal. "Confidential Information" has the meaning set forth in Section 9.1. "Content" means
text, graphics, information and data and other content, whether supplied by Licensee, Licensor, end
users or third party providers. "Dispute" has the meaning set forth in Section 10.12. "Effective
Date" means the Closing Date as set forth in the Share Purchase Agreement. "E-House Licensed Data
and Information" means the data and information licensed to CRIC Holdings Limited and its
subsidiaries, for the operation of the CRIC system pursuant to the Master Transaction Agreement. 2

Source: LEJU HOLDINGS LTD, DRS (on F-1), 1/21/2014
<!-- page 3 -->
"Governmental Authority" means any federal, national, supranational, state, provincial, local or
other government, governmental, regulatory or administrative authority, agency or commission or any
court, tribunal, or judicial or arbitral body. "Initial Term" has the meaning set forth in Section
6.1. "Law" means any federal, national, supranational, state, provincial, local or similar statute,
law or ordinance, regulation, rule, code, order, requirement or rule of law (including common law).
"Licensed Content" shall mean all Content (i) whose copyright is owned by Licensor; or (ii) owned by
a third party provider but is sublicensable by Licensor to Licensee without requiring the payment of
any additional fee to any third party and without violating the terms of any agreement with such
third party provider, together with all updates to and substitutions therefor as may be implemented
by Licensor or such third party provider. "Licensed Domain Names" means the domain names listed on
Exhibit A attached hereto. "Licensee Parties" has the meaning set forth in Section 8.1. "Licensor
Parties" has the meaning set forth in Section 8.2. "Master Transaction Agreement" means the Master
Transaction Agreement entered into by and between E-House (China) Holdings Limited and CRIC Holdings
Limited, dated as of July 27, 2009. "Operating Content" has the meaning set forth in Section 2.2.
"Person" means any individual, partnership, firm, corporation, limited liability company,
association, trust, unincorporated organization or other entity, as well as any syndicate or group
that would be deemed to be a person under Section 13(d)(3) of the Securities Exchange Act of 1934,
as amended. "PRC" means the People's Republic of China, excluding Hong Kong, Macau and Taiwan.
"Recipient" has the meaning set forth in Section 9.1. "Respondent" has the meaning set forth in
Section 10.12. "Rules" has the meaning set forth in Section 10.12. "Software License Agreement"
means that certain Software License and Support Services Agreement by and between Beijing SINA
Internet Information Service Co., Ltd. and SINA Leju dated as of [ ]. "Term" has the meaning set
forth in Section 6.1. 3

Source: LEJU HOLDINGS LTD, DRS (on F-1), 1/21/2014
<!-- page 4 -->
"Trademark License Agreement" means that certain Trademark License Agreement by and between Beijing
SINA Internet Information Service Co., Ltd. and Licensee dated as of [ ]. ARTICLE II GRANT OF
LICENSE 2.1. Grant of Licenses. (a) Subject to the terms and conditions of this Agreement, Licensor
hereby grants to Licensee, and Licensee hereby accepts from Licensor, an exclusive, non-transferable
(except as set forth in Section 10.7) and non-sublicensable (except as provided in Section 2.1(c))
license to use the Licensed Domain Names in connection with the Business during the Term. Except as
provided in Section 2.3, Licensee's use of the Licensed Domain Names under the terms of this
Agreement shall be free of any fees. (b) Subject to the terms and conditions of this Agreement,
Licensor hereby grants to Licensee, and Licensee hereby accepts from Licensor, an exclusive,
non-transferable (except as set forth in Section 10.7) and non-sublicensable (except as provided in
Section 2.1(c)) license to use the Licensed Content in connection with websites associated with the
Licensed Domain Names until the earlier of (i) termination or expiration of this Agreement, or (ii)
termination or expiration of the Agency Agreement, provided, however, that in the event the Agency
Agreement is amended or restated, such amendment or restatement shall not be deemed a termination or
expiration of the Agency Agreement. Except as provided in Section 2.3, Licensee's use of the
Licensed Content under the terms of this Agreement shall be free of any fees. (c) Notwithstanding
anything in this Agreement to the contrary, Licensee has no right to sublicense any rights granted
hereunder to any third party, or otherwise permit any third party to use any Licensed Domain Names
or Licensed Content; provided, however, that any rights granted to Licensee hereunder shall be
sublicensable, without the prior written consent of Licensor, to SINA Leju and Licensee's Affiliates
that are controlled by SINA Leju solely for the purpose of operating the Business during the Term.
All rights in and to the Licensed Domain Names and Licensed Content not expressly granted herein are
hereby reserved exclusively by Licensor. Licensee shall be responsible for the compliance of the
terms and conditions of this Agreement by all of its sublicensees. Without limiting the foregoing,
in the event any sublicensee undertakes any action (or inaction) that would be deemed a breach of
this Agreement had Licensee taken such action (or inaction), such action (or inaction) shall be
deemed a breach by Licensee under this Agreement. 2.2. Other Content. Licensee may desire to use
Content other than Licensed Content, from time to time, in connection with the websites associated
with the Licensed Domain Names ("Operating Content"). Licensee may independently enter into an
agreement with the owner of the Operating Content to secure Licensee's right to use such Operating
Content, and shall be solely responsible for the cost and expense associated with procuring such
Content. For the avoidance of doubt, Licensee shall be permitted to upload such Operating Content
directly onto Licensee's websites or through use of the Licensor's software pursuant to the Software
4

Source: LEJU HOLDINGS LTD, DRS (on F-1), 1/21/2014
<!-- page 5 -->
License Agreement. If Licensee requests Licensor to enter into such an agreement on behalf of
Licensee and to provide the Operating Content to Licensee, Licensor and Licensee shall discuss such
request in good faith; provided, however, if Licensor agrees to procure and provide such Operating
Content, Licensee shall reimburse Licensor for all reasonable, incremental costs that Licensor
incurs which are attributable to Licensee's request. For example, if Licensor, prior to the
Effective Date, employs ten (10) full time employees dedicated to obtaining Content and, as a result
of Licensee's request for Operating Content pursuant to this Section 2.2, must hire an additional
full time employee to handle Licensee's request, Licensee shall reimburse Licensor for the costs
related to such full time employee, provided that, if such full time employee also engages in work
on behalf of Licensor or its Affiliates, Licensee shall reimburse Licensor on a pro rata basis only
for the time spent by such full time employee in handling Licensee's requests. Licensee further
acknowledges that Licensor has no obligation to fulfill any request by Licensee to procure Operating
Content under this Section 2.2. Unless otherwise agreed to by the Parties, any Operating Content
obtained on Licensee's behalf by Licensor shall be for Licensee's use only and shall not be used by
Licensor or its Affiliates or provided or made available to any third parties by Licensor. 2.3.
Fees. In the event E-House Research and Training Institute becomes entitled to charge, invoice, or
otherwise receive from, Licensee any royalties, fees or other remuneration for use of the E-House
Licensed Data and Information pursuant to amendments to the Master Transaction Agreement or through
other means, Licensor and Licensee shall use good faith efforts to amend this Agreement such that
Licensor becomes entitled to charge, invoice, or otherwise receive fees from Licensee to use the
Licensed Domain Names and Licensed Content, such fees to be agreed upon by the Parties, provided
that (i) such fees shall be commercially reasonable and (ii) such fees shall not exceed the fees
charged by Licensor to unaffiliated third parties for use of the Licensed Content, taking into
account any other consideration received by Licensor (including, but not limited to, discounted
services offerings from the third party). ARTICLE III QUALITY CONTROL 3.1. Licensee Control. Subject
to the terms and conditions of this Agreement, Licensee shall be entitled to exercise exclusive
control over all aspects of the websites and the Business associated with the Licensed Domain Names
including, without limitation, the operation, the look-and-feel and the Content of such websites.
3.2. Content Distribution. Licensor shall make available to Licensee the Licensed Content in
substantially the same manner and with substantially the same speed and efficiency as such Licensed
Content was made available to SINA Leju prior to the Effective Date, namely through Licensor's
content database, but in no event with less speed, efficiency, or a lesser level of access than
Licensor provides with respect to its own operations. Licensee agrees to use the Licensed Domain
Names only in accordance with such content distribution policy that Licensor uses in connection with
its own business, and as may be established by Licensor and communicated in writing in advance to
Licensee from time to time or as may otherwise be agreed to by the Parties from time to time,
provided that Licensee shall be afforded the same period of time to implement any such content
distribution policy as is afforded to Licensor's Affiliates and other third parties. 5

Source: LEJU HOLDINGS LTD, DRS (on F-1), 1/21/2014
<!-- page 6 -->
3.3. Website Monitoring and Censoring. (a) Licensee Obligations. Licensee shall monitor and censor
all Content on the websites associated with the Licensed Domain Names, including without limitation
Content posted by end users. Licensor shall also have the right to monitor and censor Content of the
websites associated with Licensed Domain Names. Licensee shall remove any offending Content,
including, but not limited to, any illegal materials, pornographic, obscene or sexually explicit
materials, materials of a violent nature, or politically sensitive materials, from such websites as
soon as possible after it becomes aware of such offending Content but in no event later than the
timeframe prescribed by the Governmental Authority after receipt of oral or written notice from
Licensor or such Governmental Authority. Licensee's failure to comply with this Section 3.3(a) shall
be deemed a material breach of this Agreement. Without limiting the foregoing obligations, Licensee
acknowledges that Licensor shall have the right to remove such offending Content from the websites
associated with Licensed Domain Names. (b) New Restrictions Imposed by Governmental Authority. In
the event Licensor receives notice from any Governmental Authority that the websites associated with
the Licensed Domain Names contain offending Content where (i) the basis or nature of such offense
has not previously been identified by any Governmental Authority as offensive or inappropriate and
(ii) Licensee has not also received notice from such Governmental Authority, Licensor shall promptly
notify Licensee of Licensor's receipt thereof. Licensee shall then use best efforts to remove such
Content as soon as possible in accordance with the instructions of such Governmental Authority.
Notwithstanding the foregoing or anything in Section 8.2 to the contrary, in the event Licensor
fails to notify Licensee of Licensor's receipt of such notice from a Governmental Authority, such
that Licensee does not have sufficient time to remove such offending Content, Licensee shall not be
liable for any fines or penalties imposed by a Governmental Authority in connection with such
offending Content. 3.4. Compliance with Laws. Licensee shall ensure that the Business complies with
all applicable Laws in respect of operation, advertising and promotion of the Business and use of
the Licensed Domain Names and Licensed Content in connection therewith. 3.5. Restrictions. Except as
expressly permitted under the Trademark License Agreement, Licensee shall not knowingly (a) use the
Licensed Domain Names in any manner that tarnishes, degrades, disparages or reflects adversely on
Licensor or Licensor's business or reputation, (b) in any jurisdiction, register or attempt to
register any domain names that consist of, in whole or in part, or are confusingly similar to, the
term "SINA", (c) contest, challenge or otherwise make any claim or take any action adverse to
Licensor's interest in the Licensed Domain Names, (d) register any trademarks, trade names or
company names that consist of, in whole or in part, or are confusingly similar to the term "SINA" in
the name of Licensee or of any of its Affiliates, or (e) use the Licensed Content and other Content
for any unlawful purpose, including but not limited to displaying or distributing any pornographic,
obscene or sexually explicit material, materials of a violent nature, or politically sensitive
materials. In the event that Licensor reasonably determines that any violation of the foregoing by
Licensee poses an immediate harm to Licensor's business, reputation or goodwill, Licensee shall
promptly, following receipt of notice from Licensor, cease and desist all such non-conforming uses.
6

Source: LEJU HOLDINGS LTD, DRS (on F-1), 1/21/2014
<!-- page 7 -->
ARTICLE IV OWNERSHIP 4.1. Ownership. Licensee acknowledges that, as between the Parties, Licensor
(or its third party providers) is the owner of all right, title and interest in and to the Licensed
Domain Names and Licensed Content, and all such right, title and interest shall remain exclusively
with Licensor (or its third party providers). 4.2. Prosecution and Maintenance. As between Licensee
and Licensor, Licensor shall have the sole and exclusive right and obligation to maintain and renew
registrations for the Licensed Domain Names during the Term, and shall do so at its own cost and
expense during the Term. Licensee shall not engage in the foregoing affairs, in particular, Licensee
shall not change or apply for change of the domain name registration service agency for the Licensed
Domain Names during the Term of this Agreement. ARTICLE V ENFORCEMENT 5.1. Licensor Enforcement. (a)
Licensor shall have the right, but not the obligation, to take action against third parties in the
courts, administrative agencies or otherwise, at Licensor's cost and expense, to prevent or
terminate misuse, infringement, dilution, misappropriation, imitation or illegal use by third
parties of the Licensed Domain Names or Licensed Content. (b) Licensee shall reasonably cooperate
with Licensor in any action, suit or proceeding that the Licensor may undertake under this Section
5.1 (including, without limitation, executing, filing and delivering all documents and evidence
reasonably requested by the Licensor) and shall lend its name to such action, suit or proceeding if
reasonably requested by the Licensor or required by applicable Law. All reasonable out-of-pocket
expenses incurred by the Licensee in connection therewith shall be reimbursed by the Licensor. The
Licensee shall have the right to participate and be represented in any such action, suit or
proceeding by its own counsel at its own expense. (c) All damages or other compensation of any kind
recovered in any action, suit or proceeding undertaken under this Article V, or from any settlement
or compromise thereof, shall be for the benefit of the Licensor, provided, however, that any
compensation granted or awarded in light of any losses incurred by Licensee shall be for the benefit
of the Licensee after Licensor's reasonable expenses for taking such action, suit or proceeding have
been paid. ARTICLE VI TERM AND TERMINATION 6.1. Term. The initial term of this Agreement (the
"Initial Term") shall commence on the Effective Date and shall continue for a period of ten (10)
years thereafter. Beginning twelve (12) months prior to the expiration of the Initial Term, the
Parties shall use 7

Source: LEJU HOLDINGS LTD, DRS (on F-1), 1/21/2014
<!-- page 8 -->
good faith efforts to negotiate an extension of the term of this Agreement (the Initial Term
together with any applicable extension, the "Term"). 6.2. Termination for Bankruptcy. Either Party
may immediately terminate this Agreement in the event that the other Party (a) becomes insolvent or
unable to pay its debts as they mature; (b) makes an assignment for the benefit of its creditors;
(c) seeks relief, or if proceedings are commenced against such other Party or on its behalf, under
any bankruptcy, insolvency or debtors' relief law and such proceedings have not been vacated or set
aside within seven (7) days from the date of commencement thereof. 6.3. Termination for Breach. (a)
By Licensor. Licensor may terminate this Agreement at any time in the event that the Licensee is in
material default or breach of any provision of this Agreement, and, if such default or breach is
capable of cure, such default or breach continues uncured for a period of thirty (30) days after
receipt of written notice thereof; provided, however, that in the event that the Licensee has in
good faith commenced cure within such thirty (30) day period, but cannot practically complete such
cure within such thirty (30) day period, the Parties shall negotiate a reasonable additional time to
cure. (b) By Licensee. Licensee may terminate this Agreement at any time in the event that the
Licensor is in material default or breach of any provision of this Agreement, and, if such default
or breach is capable of cure, such default or breach continues uncured for a period of thirty (30)
days after receipt of written notice thereof; provided, however, that in the event that the Licensor
has in good faith commenced cure within such thirty (30) day period, but cannot practically complete
such cure within such thirty (30) day period, the Parties shall negotiate a reasonable additional
time to cure. 6.4. Termination for a Change of Control. Licensor may terminate this Agreement by
providing prior written notice to Licensee upon the occurrence of a Change of Control. 6.5.
Termination in the Event of Termination of Agency Agreement. In the event that the Agency Agreement
is terminated pursuant to Section 9.02(c)(iii) or 9.02(d)(i) thereof, this Agreement shall
automatically be terminated as of the effective date of the termination of the Agency Agreement and
shall thereafter be of no further force or effect except as set forth in Section 6.7. 6.6. Effect of
Termination. (a) Upon termination (but not expiration) of this Agreement for any reason, Licensee
shall be entitled to use the Licensed Domain Names and Licensed Content for a limited period of
time, not to exceed ninety (90) days, during which it shall diligently work to transition to another
solution. Upon expiration of this Agreement or such 90-day period, (i) all rights granted to
Licensee under this Agreement with respect to the Licensed Domain Names and Licensed Content shall
immediately cease, and (ii) Licensee shall immediately discontinue all use of the Licensed Domain
Names and Licensed Content. 8

Source: LEJU HOLDINGS LTD, DRS (on F-1), 1/21/2014
<!-- page 9 -->
(b) Upon termination or expiration of the Agency Agreement (other than as described in Section 6.5),
Licensee's rights under Section 2.1(b) are terminated and Licensee shall immediately discontinue all
use of the Licensed Content, provided, however that in the event the Agency Agreement is amended or
restated, such amendment or restatement shall not be deemed a termination or expiration of the
Agency Agreement. 6.7. Survival. The duties and obligations of the Parties under Articles IV, VI,
VIII, IX and X and Section 7.2 of this Agreement shall survive any termination or expiration of this
Agreement. ARTICLE VII REPRESENTATIONS AND WARRANTIES 7.1. Representations and Warranties. (a) By
Each Party. Each of Licensee and Licensor represents and warrants to each other Party that: (a) it
is a corporation duly incorporated, validly existing and in good standing under applicable Law; (b)
the execution, delivery and performance of this Agreement and the consummation of the transactions
contemplated hereby are within its corporate powers; (c) it has taken necessary steps to obtain
authority and all necessary consents and approvals of any other third party or Governmental
Authority to execute and perform this Agreement; (d) this Agreement has been duly executed and
delivered by it and constitutes its valid and binding obligation, enforceable against it in
accordance with its terms, except as such enforceability may be limited by bankruptcy, insolvency,
reorganization, or other laws affecting the rights of creditors' generally or by general principals
of equity; and (e) the execution, delivery and performance of this Agreement will not conflict with
or result in any breach of its charter or certificate of incorporation, bylaws, or other governing
document, or any instrument, obligation, or contract to which it or its properties is bound. (b) By
Licensor. Licensor represents and warrants that: i. It has the right to grant the licenses granted
to Licensee hereunder; and ii. The Licensed Content and the Licensed Domain Names are, and the
rights granted hereunder in connection with the Licensed Domain Names and Licensed Content are,
substantially similar to the Licensed Content and the Licensed Domain Names and the rights that were
granted to SINA Leju in connection therewith prior to the Effective Date. 7.2. Disclaimer. LICENSEE
HEREBY ACKNOWLEDGES AND AGREES THAT EXCEPT AS EXPRESSLY SET FORTH HEREIN OR IN THE SHARE PURCHASE
AGREEMENT, THE LICENSED DOMAIN NAMES AND THE LICENSED CONTENT ARE PROVIDED WITHOUT WARRANTY OF ANY
KIND, EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, WARRANTIES OF MERCHANTABILITY, VALIDITY,
NONINFRINGEMENT, FITNESS FOR A PARTICULAR PURPOSE OR OTHER WARRANTIES, WHETHER EXPRESS OR IMPLIED,
AND LICENSOR HEREBY DISCLAIMS ANY AND ALL SUCH WARRANTIES. 9

ARTICLE VIII INDEMNIFICATION 8.1. Indemnification by Licensor. Licensor shall defend, indemnify and
hold harmless Licensee and its Affiliates, and their respective officers, directors, employees,
agents, shareholders, successors and assigns, (collectively, the "Licensee Parties") from and
against any claim, suit, demand or action ("Action"), and any and all direct losses suffered or
incurred by Licensee in connection with any third party claims arising out of or resulting from any
breach by Licensor of any provision of this Agreement. Licensor's obligation to indemnify Licensee
shall be conditioned on (a) Licensee's provision to Licensor of prompt notice of such an Action
(except where any delay does not materially prejudice Licensor); (b) Licensee's reasonable
cooperation with Licensor in the defense and settlement of such an Action at Licensor's cost; and
(c) Licensor having exclusive control of the defense, settlement and/or compromise of such an Action
(provided that Licensor may not settle any Action in a manner that adversely affects Licensee
without Licensee's prior written consent, not to be unreasonably withheld or delayed). 8.2.
Indemnification by Licensee. Licensee shall defend, indemnify and hold harmless Licensor and its
Affiliates, and their respective officers, directors, employees, agents, shareholders, successors
and assigns, (collectively, the "Licensor Parties") from and against any Action, and any and all
direct losses suffered or incurred by Licensor in connection with any third party claims (a) arising
out of or resulting from any breach by Licensee of any provision of this Agreement, (b) regarding
the Content (other than Licensed Content) of the websites associated with Licensed Domain Names, or
(c) regarding any Content that was subject to a request for removal by a Governmental Authority,
even if Licensee removes such Content within the time period proscribed by the Governmental
Authority, provided that, in all cases, Licensee shall not be liable for any direct losses suffered
or incurred by Licensor as a result of Licensor's failure to provide Licensee with a reasonable
period of time to remove Content in cases where (i) the basis or nature of the offense has not
previously been identified by any Governmental Authority as offensive or inappropriate and (ii)
Licensee has not also received notice from the Governmental Authority. Licensee's obligation to
indemnify Licensor shall be conditioned on (x) Licensor's provision to Licensee of prompt notice of
such an Action (except where any delay does not materially prejudice Licensee); (y) Licensor's
reasonable cooperation with Licensee in the defense and settlement of such an Action at Licensee's
cost; and (z) Licensee having exclusive control of the defense, settlement and/or compromise of such
an Action (provided that Licensee may not settle any Action in a manner that adversely affects
Licensor without Licensor's prior written consent, not to be unreasonably withheld or delayed).
ARTICLE IX CONFIDENTIALITY 9.1. Confidential Information. In performing its obligations under this
Agreement, either Party (the "Recipient") may obtain certain Confidential Information of the other
Party. For purposes of this Agreement, "Confidential Information" shall mean information, documents
and other tangible things, provided by either Party to the other, in whatever form, relating to such
Party's business and marketing, including such

Source: LEJU HOLDINGS LTD, DRS (on F-1), 1/21/2014
<!-- page 10 -->
Party's financial information, personal information, customer lists, product plans and marketing
plans, whether alone or in its compiled form and whether marked as confidential or not. The
Recipient shall maintain in 10

Source: LEJU HOLDINGS LTD, DRS (on F-1), 1/21/2014
<!-- page 11 -->
confidence all Confidential Information and shall not disclose such Confidential Information to any
third party without the express written consent of the other Party except to those of its employees,
subcontractors, consultants, representatives and agents as are necessary in connection with
activities as contemplated by this Agreement. In maintaining the confidentiality of Confidential
Information, the Recipient shall exercise the same degree of care that it exercises with its own
confidential information, and in no event less than a reasonable degree of care. The Recipient shall
ensure that each of its employees, subcontractors, consultants, representatives and agents holds in
confidence and makes no use of the Confidential Information for any purpose other than those
permitted under this Agreement or otherwise required by Law. Upon request by the other Party, the
Recipient shall return, destroy or otherwise handle as instructed by the other Party, any documents
or software containing such Confidential Information, and shall not continue to use such
Confidential Information. 9.2. Exceptions. The obligation of confidentiality contained in Section
9.1 shall not apply to the extent that (a) the Recipient is required to disclose information by
order or regulation of a Governmental Authority or a court of competent jurisdiction; provided,
however, that, to the extent permitted by applicable Law, the Recipient shall not make any such
disclosure without first notifying the other Party and allowing the other Party a reasonable
opportunity to seek injunctive relief from (or a protective order with respect to) the obligation to
make such disclosure; or (b) the Recipient can demonstrate that (i) the disclosed information was at
the time of such disclosure to the Recipient already in (or thereafter enters) the public domain
other than as a result of actions of the Recipient, its directors, officers, employees or agents in
violation hereof, (ii) the disclosed information was rightfully known to the Recipient prior to the
date of disclosure (other than pursuant to disclosure by the other Party pursuant to other
agreements in effect between the Parties), or (iii) the disclosed information was received by the
Recipient on an unrestricted basis from a source unrelated to any Party and not under a duty of
confidentiality to the other Party. ARTICLE X GENERAL PROVISIONS 10.1. Taxes. Each Party shall be
responsible for taxes that should be borne by it in accordance with applicable Law. If any Party
pays any taxes that should have been borne by the other Party in accordance with Law, such other
Party shall reimburse such Party within seven (7) days after its receipt of documentation evidencing
such tax payment so incurred by such Party. 10.2. Expenses. Except as otherwise specified in this
Agreement, all costs and expenses, including, fees and disbursements of counsel, financial advisors
and accountants, incurred in connection with this Agreement and the transactions contemplated by
this Agreement shall be borne by the party incurring such costs and expenses, whether or not the
Closing shall have occurred. 10.3. Notices. All notices, requests, claims, demands and other
communications hereunder shall be in writing and shall be deemed duly given, made or received (i) on
the date of delivery if delivered in person or by messenger service, (ii) on the date of
confirmation of receipt of transmission by facsimile (or, the first (1 ) Business Day following such
receipt if (a) such 11

s t

Source: LEJU HOLDINGS LTD, DRS (on F-1), 1/21/2014
<!-- page 12 -->
date of confirmation is not a Business Day or (b) confirmation of receipt is given after 5:00 p.m.,
Beijing time) or (iii) on the date of confirmation of receipt if delivered by an internationally
recognized overnight courier service or registered or certified mail (or, the first (1 ) Business
Day following such receipt if (a) such date of confirmation is not a Business Day or (b)
confirmation of receipt is given after 5:00 p.m., Beijing time) to the respective parties hereto at
the following addresses (or at such other address for a party as shall be specified in a notice
given in accordance with this Section 10.3): if to Licensor: SINA Corporation 20/F Beijing Ideal
International Plaza No. 58 Northwest 4th Ring Road Haidian District, Beijing, 100090 People's
Republic of China Facsimile: +86 10 8260 7166 Attention: Head of Legal Department (Xie Guomin) with
a copy (which shall not constitute notice) to: Shearman & Sterling LLP 12 Floor East Tower, Twin
Towers B-12 Jianguomenwai Dajie Beijing 100022 People's Republic of China Facsimile: +86 10 6563
6001 Attention: Lee Edwards, Esq. if to Licensee: Beijing Yisheng Leju Information Services Co.,
Ltd. c/o CRIC Holdings Limited No. 383 Guangyan Road Shanghai 200072 People's Republic of China
Facsimile: + 86 (21) 6086 7111 Attention: President with a copy (which shall not constitute notice)
to: Skadden, Arps, Slate, Meagher & Flom 42/F, Edinburgh Tower, The Landmark 12 Queen's Road
Central, Hong Kong Facsimile: +852 3740 4727 Attention: Jonathan B. Stone, Esq. and Z. Julie Gao,
Esq. 10.4. Public Announcements. Other than (i) the filing with the SEC of the Form F-1, any
amendments thereto and any other documents filed in connection with the Form F-1, 12

s t

th

Source: LEJU HOLDINGS LTD, DRS (on F-1), 1/21/2014
<!-- page 13 -->
including the filing of this Agreement or (ii) any communications with the relevant stock exchange
or regulators in connection with the IPO, in each case, as deemed necessary or desirable in the sole
discretion of CRIC, neither party to this Agreement shall make, or cause to be made, any press
release or public announcement in respect of this Agreement or the transactions contemplated by this
Agreement or otherwise communicate with any news media without the prior written consent of the
other party unless otherwise required by Law or applicable stock exchange regulation, and the
parties to this Agreement shall cooperate as to the timing and contents of any such press release,
public announcement or communication. 10.5. Severability. If any term or other provision of this
Agreement is invalid, illegal or incapable of being enforced by any Law or public policy, all other
terms and provisions of this Agreement shall nevertheless remain in full force and effect for so
long as the economic or legal substance of the transactions contemplated by this Agreement is not
affected in any manner materially adverse to either party hereto. Upon such determination that any
term or other provision is invalid, illegal or incapable of being enforced, the parties hereto shall
negotiate in good faith to modify this Agreement so as to effect the original intent of the parties
as closely as possible in an acceptable manner in order that the transactions contemplated by this
Agreement are consummated as originally contemplated to the greatest extent possible. 10.6. Entire
Agreement. This Agreement constitutes the entire agreement of the Parties hereto with respect to the
subject matter hereof and supersedes all prior agreements and understandings, both written and oral,
with respect to the subject matter hereof and thereto (including the Original Agreement). 10.7.
Assignment. This Agreement and any rights or authority granted hereunder shall not be assigned or
transferred by either Party, including by operation of law, merger or otherwise, without the express
written consent of the other Party, provided that Licensor may assign this Agreement without consent
to any of its Affiliates and Licensee may assign this Agreement without consent to SINA Leju or an
Affiliate of Licensee that is controlled by SINA Leju. 10.8. Amendment. This Agreement may not be
amended or modified except (a) by an instrument in writing signed by, or on behalf of, both Parties
or (b) by a waiver in accordance with Section 10.9. 10.9. Waiver. Either Party may (a) extend the
time for the performance of any of the obligations or other acts of the other Party, (b) waive any
inaccuracies in the representations and warranties of the other Party contained herein or in any
document delivered by the other party pursuant hereto or (c) waive compliance with any of the
agreements of the other Party or conditions to such Party's obligations contained herein. Any such
extension or waiver shall be valid only if set forth in an instrument in writing signed by the Party
to be bound thereby. No waiver of any representation, warranty, agreement, condition or obligation
granted pursuant to this Section 10.9 or otherwise in accordance with this Agreement shall be
construed as a waiver of any prior or subsequent breach of such representation, warranty, agreement,
condition or obligation or any other representation, warranty, agreement, condition or obligation.
The failure of either party hereto to assert any of its rights hereunder shall not constitute a
waiver of any of such rights. 13

Source: LEJU HOLDINGS LTD, DRS (on F-1), 1/21/2014
<!-- page 14 -->
10.10. No Third Party Beneficiaries. Except for the provisions of Article VII relating to
indemnified parties, this Agreement shall be binding upon and inure solely to the benefit of the
Parties and their respective successors and permitted assigns and nothing herein, express or implied
(including the provisions of Article VII relating to indemnified parties), is intended to or shall
confer upon any other Person any legal or equitable right, benefit or remedy of any nature
whatsoever, including any rights of employment for any specified period, under or by reason of this
Agreement. 10.11. Governing Law. This Agreement and any dispute or claim arising out of or in
connection with it or its subject matter shall be governed by, and construed in accordance with, the
laws of the People's Republic of China (without regard to its conflicts of laws rules that would
mandate the application of the laws of another jurisdiction). 10.12. Dispute Resolution. (a) Any
dispute, controversy or claim arising out of or relating to this Agreement, or the breach,
termination or invalidity thereof (each, a "Dispute"), shall to the extent possible be settled
through friendly consultation among the Parties hereto. The claiming Party (the "Claimant") shall
promptly notify the other Party (the "Respondent") in a dated written notice that a Dispute has
arisen and describe the nature of the Dispute. Any Dispute which remains unresolved within sixty
(60) days after the date of such written notice shall be submitted to the China International
Economic and Trade Arbitration Commission (the "Commission") to be finally settled by arbitration in
Beijing, PRC in accordance with the Commission's then effective rules (the "Rules") and this Section
10.12. The language of the arbitration shall be Mandarin Chinese. (b) The arbitration tribunal shall
consist of three (3) arbitrators. The Claimant shall appoint one (1) arbitrator, the Respondent
shall appoint one (1) arbitrator, and the two (2) arbitrators so appointed shall appoint a third
arbitrator. If the Claimant and the Respondent fail to appoint one (1) arbitrator, or the two (2)
arbitrators appointed fail to appoint the third arbitrator within the time periods set by the then
effective Rules, the relevant appointment shall be made promptly by the Commission. (c) Any award of
the arbitration tribunal established pursuant to this Section 10.12 shall be final and binding upon
the Parties, and enforceable in any court of competent jurisdiction. The Parties shall use their
best efforts to effect the prompt execution of any such award and shall render whatever assistance
as may be necessary to this end. The prevailing Party (as determined by the arbitrators) shall be
entitled to reimbursement of its costs and expenses, including reasonable attorney's fees, incurred
in connection with the arbitration and any judicial enforcement, unless the arbitrators determine
that it would be manifestly unfair to honor this agreement of the Parties and determine a different
allocation of costs. (d) The foregoing provisions in this Section 10.12 shall not preclude any Party
from seeking interim or conservatory remedies, including injunctive relief, from any court having
jurisdiction to grant such relief. 10.13. No Presumption. The Parties acknowledge that each has been
represented by counsel in connection with this Agreement and the transactions contemplated by this
Agreement. Accordingly, any applicable Law that would require interpretation of any claimed 14

Source: LEJU HOLDINGS LTD, DRS (on F-1), 1/21/2014
<!-- page 15 -->
ambiguities in this Agreement against the Party that drafted it has no application and is expressly
waived. If any claim is made by a Party relating to any conflict, omission or ambiguity in the
provisions of this Agreement, no presumption or burden of proof or persuasion will be implied
because this Agreement was prepared by or at the request of any Party or its counsel. 10.14.
Specific Performance. The parties hereto acknowledge and agree that irreparable damage would occur
if any of the provisions of this Agreement are not performed in accordance with their specific terms
and that any breach of this Agreement could not be adequately compensated in all cases by monetary
damages alone. Accordingly, in addition to any other right or remedy to which a party hereto may be
entitled, at law or in equity, it shall be entitled to enforce any provision of this Agreement by a
decree of specific performance and to temporary, preliminary and permanent injunctive relief to
prevent breaches or threatened breaches of any of the provisions of this Agreement, without posting
any bond or other undertaking. 10.15. Force Majeure. Neither Party shall be liable for failure to
perform any of its obligations under this Agreement during any period in which such Party cannot
perform due to hacker attack, fire, flood or other natural disaster, war, embargo, riot or the
intervention of any Governmental Authority, provided, however, that the Party so delayed immediately
notifies the other Party of such delay. In no event shall such nonperformance by Licensee be excused
due to any such event for longer than ninety (90) days. 10.16. Counterparts. This Agreement may be
executed and delivered (including by facsimile transmission) in one or more counterparts, and by the
different parties hereto in separate counterparts, each of which when executed shall be deemed to be
an original, but all of which taken together shall constitute one and the same agreement. 10.17.
Termination of Original Agreement. Pursuant to the Mutual Termination Agreement set forth in Exhibit
B attached hereto, the Original Agreement shall be terminated as of the Effective Date.
Notwithstanding anything in this Agreement to the contrary, this Agreement shall not become
effective unless and until the Mutual Termination Agreement set forth in Exhibit B is executed.
[SIGNATURES ON NEXT PAGE] 15

Source: LEJU HOLDINGS LTD, DRS (on F-1), 1/21/2014
<!-- page 16 -->
IN WITNESS WHEREOF, each Party hereto has caused this Agreement to be executed by its duly
authorized representatives on the date first set forth above.

Beijing SINA Internet Information Service Co., Ltd.

By: /s/ Charles Chao

Name:

Title:

Beijing Yisheng Leju Information Services Co., Ltd.

By: /s/ Fei Cao

Name:

Title: 16

Source: LEJU HOLDINGS LTD, DRS (on F-1), 1/21/2014
<!-- page 17 -->
EXHIBIT A LICENSED DOMAIN NAMES house.sina.com.cn jiaju.sina.com.cn construction.sina.com.cn 17

Source: LEJU HOLDINGS LTD, DRS (on F-1), 1/21/2014
