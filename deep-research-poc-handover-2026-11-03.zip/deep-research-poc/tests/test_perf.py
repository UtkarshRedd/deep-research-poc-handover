"""Phase 1 acceptance: grep over a 1,000-doc workspace in < 1 s (pure Python path)."""
import random
import time

import pytest

from dr.models import DocRecord
from dr.tools import grep as grep_mod
from dr.workspace import Workspace

WORDS = "agreement borrower lender covenant leverage ratio margin commitment termination notice amendment facility".split()


def _synthetic(n_docs: int, lines_per_doc: int = 400) -> list[DocRecord]:
    rnd = random.Random(7)
    docs = []
    for i in range(n_docs):
        lines = []
        for p in range(1, 11):
            lines.append(f"<!-- page {p} -->")
            for _ in range(lines_per_doc // 10):
                lines.append(" ".join(rnd.choice(WORDS) for _ in range(12)))
        if i % 97 == 0:
            lines.insert(5, "Facility ID: FAC-2024-0117")
        text = "\n".join(lines)
        docs.append(DocRecord(doc_id=f"d{i:04d}", title=f"Doc {i}", text=text))
    return docs


@pytest.mark.timeout(60)
def test_grep_1000_docs_under_budget(tmp_path):
    ws = Workspace.materialize(_synthetic(1000), tmp_path / "ws")
    assert ws.stats["n_docs"] == 1000
    t0 = time.perf_counter()
    res = grep_mod.grep(ws, r"FAC-2024-0117")
    dt = time.perf_counter() - t0
    assert res.docs_with_matches == 11
    assert dt < 1.0, f"grep took {dt:.2f}s"
    # a common term: counts must be complete even though matches are capped
    t0 = time.perf_counter()
    res = grep_mod.grep(ws, r"\bleverage\b")
    dt = time.perf_counter() - t0
    assert res.matches_truncated and res.docs_with_matches > 900
    assert dt < 2.0, f"grep took {dt:.2f}s"
