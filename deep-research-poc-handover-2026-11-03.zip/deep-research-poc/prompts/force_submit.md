STOP RESEARCHING. {reason}. Call `submit` now, in this turn, with your best answer built only from
the evidence already saved. Cite only these saved evidence ids: {evidence_ids}. If the saved
evidence does not answer the question, say so and set not_in_corpus=true rather than guessing.
