"""Top-level LangGraph: materialize -> [research] -> write -> verify.

    START -> materialize -> (research | write)  -> write -> verify -> END
                              ^ skipped when the deadline leaves no room for research

The graph is shared by all variants; `variant` in state selects the research branch:

    variant        first_move   router    research
    A2_fs_agent    off          single    ResearchLoop (grep/read/outline/list_docs)
    A1_deep_list   on           on        ResearchLoop + search/page_results
    A3_fanout      on           on        router -> researcher | fanout (long_context falls back to single)
    (all implemented; see VARIANTS below for the ablations)

Deadline: `deadline_ts` = start + stages.TOTAL. Research gets the smaller of its own budget and
whatever is left after reserving WRITE + VERIFY + RESERVE; if nothing is left it is skipped and the
report is written from the (possibly empty) bank, marked partial. The writer skips its revision
pass when less than half of WRITE remains. Verification is deterministic and always runs.

Heavy objects (Workspace, EvidenceBank, Trace, Report) never enter the LangGraph state: a
`Pipeline` keeps them per run_id; the state holds paths, flags and serializable summaries.
"""
from __future__ import annotations

import time
import uuid
from pathlib import Path
from typing import Any, Literal, TypedDict

from langgraph.graph import END, START, StateGraph

from .agents.fanout import run_breadth
from .agents.first_move import run_first_move
from .agents.researcher import A1_TOOLS, A2_TOOLS, ResearchContext, ResearchLoop
from .agents.router import run_router
from .agents.writer import write_report
from .config import DEFAULT, Config
from .evidence import EvidenceBank
from .models import DocRecord, Finding, FirstMoveResult, Report
from .tools.bm25 import BM25Index
from .tools.read import ReadTracker
from .trace import Trace
from .verify.report import finalize_report
from .workspace import Workspace

Variant = Literal["A2_fs_agent", "A1_deep_list", "A3_fanout"]

# Eval variants (PLAN Phase 6). `first_move` toggles the first-move + router nodes; `tools` is the
# researcher's tool set (a BM25 index is built whenever `search` is exposed). A3_* and LC_small
# arrive with Phase 5 / the long-context router branch.
VARIANTS: dict[str, dict] = {
    "A2_fs_agent": {"first_move": False, "tools": A2_TOOLS, "note": "filesystem agent, the default loop"},
    "A2_grep_only": {"first_move": False, "tools": ["grep", "read", "add_evidence", "submit"],
                     "note": "ablation: no outline / list_docs"},
    "A1_deep_list": {"first_move": True, "tools": A1_TOOLS, "note": "first move + BM25 deep list + paging"},
    "A1_no_first_move": {"first_move": False, "tools": A1_TOOLS, "note": "ablation: BM25 tools, no first move"},
    "A1_bm25_only": {"first_move": True, "tools": ["search", "page_results", "read", "add_evidence", "submit"],
                     "note": "ablation: no grep"},
    "A3_fanout": {"first_move": True, "tools": A1_TOOLS, "breadth": True,
                  "note": "router-selected fan-out: sub-question researchers or extract grid + one gap round"},
    "A3_grid_only": {"first_move": True, "tools": A1_TOOLS, "breadth": True, "grid_only": True,
                     "note": "ablation: extract grid over the first-move candidates, no researchers"},
}
IMPLEMENTED_VARIANTS = set(VARIANTS)


class RunState(TypedDict, total=False):
    run_id: str
    variant: str
    question: str
    workspace_root: str
    deadline_ts: float
    # stage outputs (serializable summaries; heavy objects live in the Pipeline / workspace)
    first_move: dict | None
    route: dict | None
    findings: list[dict]
    report_md: str | None
    verify: list[dict]
    partial: bool
    errors: list[str]
    stage_ms: dict[str, int]
    research_done: str | None


def new_run_state(question: str, variant: str, root: Path, config: Config = DEFAULT) -> RunState:
    return RunState(
        run_id=uuid.uuid4().hex[:12], variant=variant, question=question, workspace_root=str(root),
        deadline_ts=time.time() + config.stages.TOTAL, first_move=None, route=None, findings=[],
        report_md=None, verify=[], partial=False, errors=[], stage_ms={}, research_done=None,
    )


class Pipeline:
    """Owns the compiled graph and the per-run heavy objects. `llms` injects chat models per
    role (tests); otherwise `dr.llm.get_llm(role)` is used."""

    def __init__(self, config: Config = DEFAULT, llms: dict[str, Any] | None = None):
        self.config = config
        self.llms = llms or {}
        self._docs: dict[str, list[DocRecord]] = {}
        self.workspaces: dict[str, Workspace] = {}
        self.banks: dict[str, EvidenceBank] = {}
        self.traces: dict[str, Trace] = {}
        self.reports: dict[str, Report] = {}
        self.indexes: dict[str, BM25Index] = {}
        self.first_moves: dict[str, FirstMoveResult] = {}
        self.trackers: dict[str, ReadTracker] = {}
        self.graph = self._build()

    # ------------------------------------------------------------------ entry point

    def run(self, question: str, docs: list[DocRecord], variant: str = "A2_fs_agent", root: Path | None = None) -> RunState:
        if variant not in IMPLEMENTED_VARIANTS:
            raise NotImplementedError(f"variant {variant!r} is not implemented yet (have {sorted(IMPLEMENTED_VARIANTS)})")
        root = Path(root) if root else Path(".runs") / uuid.uuid4().hex[:8]
        state = new_run_state(question, variant, root, self.config)
        self._docs[state["run_id"]] = docs
        try:
            final: RunState = self.graph.invoke(state, config={"recursion_limit": 50})
        finally:
            self._docs.pop(state["run_id"], None)
            tr = self.traces.get(state["run_id"])
            if tr:
                tr.close()
        return final

    # ------------------------------------------------------------------ graph

    def _build(self):
        g = StateGraph(RunState)
        g.add_node("materialize", self._materialize)
        g.add_node("first_move", self._first_move)
        g.add_node("route", self._route)
        g.add_node("research", self._research)
        g.add_node("breadth", self._breadth)
        g.add_node("write", self._write)
        g.add_node("verify", self._verify)
        g.add_edge(START, "materialize")
        g.add_conditional_edges("materialize", self._after_materialize,
                                {"first_move": "first_move", "research": "research", "write": "write"})
        g.add_edge("first_move", "route")
        g.add_conditional_edges("route", self._after_route, {"research": "research", "breadth": "breadth"})
        g.add_edge("research", "write")
        g.add_edge("breadth", "write")
        g.add_edge("write", "verify")
        g.add_edge("verify", END)
        return g.compile()

    def _reserve_after_research(self) -> float:
        s = self.config.stages
        return s.WRITE + s.VERIFY + s.RESERVE

    def _after_materialize(self, state: RunState) -> str:
        remaining = state["deadline_ts"] - time.time()
        if remaining <= self._reserve_after_research():
            return "write"
        return "first_move" if VARIANTS[state["variant"]]["first_move"] else "research"

    # ------------------------------------------------------------------ nodes

    def _materialize(self, state: RunState) -> dict:
        rid = state["run_id"]
        t0 = time.perf_counter()
        root = Path(state["workspace_root"])
        ws = Workspace.materialize(self._docs[rid], root, self.config)
        tr = Trace(root / "trace.jsonl", rid)
        self.workspaces[rid], self.banks[rid], self.traces[rid] = ws, EvidenceBank(ws), tr
        ms = int((time.perf_counter() - t0) * 1000)
        tr.stage("materialize", "end", n_docs=len(ws.manifest), ms=ms, variant=state["variant"])
        return {"stage_ms": {**state.get("stage_ms", {}), "materialize": ms}}

    def _first_move(self, state: RunState) -> dict:
        rid = state["run_id"]
        t0 = time.perf_counter()
        s = self.config.stages
        ws, tr = self.workspaces[rid], self.traces[rid]
        index = BM25Index(ws, self.config)
        self.indexes[rid] = index
        tr.event("bm25_index", stage="first_move", n_chunks=len(index.chunks), build_ms=index.build_ms)
        fm = run_first_move(ws, state["question"], index, self.config, llm=self.llms.get("planner"), trace=tr,
                            deadline_ts=min(time.time() + s.FIRST_MOVE, state["deadline_ts"] - self._reserve_after_research()))
        self.first_moves[rid] = fm
        ms = int((time.perf_counter() - t0) * 1000)
        summary = {"n_clues": len(fm.clues), "n_candidates": len(fm.candidate_doc_ids),
                   "top_candidates": fm.candidate_doc_ids[:10], "decomposed_by": fm.decomposed_by,
                   "estimated_candidate_tokens": fm.estimated_candidate_tokens, "bm25_build_ms": index.build_ms}
        return {"first_move": summary, "stage_ms": {**state.get("stage_ms", {}), "first_move": ms}}

    def _route(self, state: RunState) -> dict:
        rid = state["run_id"]
        t0 = time.perf_counter()
        decision = run_router(self.workspaces[rid], state["question"], self.first_moves.get(rid), self.config,
                              llm=self.llms.get("router"), trace=self.traces[rid],
                              deadline_ts=state["deadline_ts"] - self._reserve_after_research())
        errors = list(state.get("errors", []))
        spec = VARIANTS[state["variant"]]
        if decision.mode.value != "single" and not spec.get("breadth"):
            errors.append(f"router chose {decision.mode.value} but variant {state['variant']} runs the single researcher")
        ms = int((time.perf_counter() - t0) * 1000)
        return {"route": decision.model_dump(mode="json"), "errors": errors,
                "stage_ms": {**state.get("stage_ms", {}), "route": ms}}

    def _after_route(self, state: RunState) -> str:
        spec = VARIANTS[state["variant"]]
        if spec.get("grid_only"):
            return "breadth"
        if spec.get("breadth") and (state.get("route") or {}).get("mode") == "breadth":
            return "breadth"
        return "research"

    def _breadth(self, state: RunState) -> dict:
        rid = state["run_id"]
        t0 = time.perf_counter()
        s = self.config.stages
        from .models import RouteDecision

        decision = RouteDecision.model_validate(state["route"])
        deadline = min(time.time() + s.RESEARCH, state["deadline_ts"] - self._reserve_after_research())
        bank = self.banks[rid]
        res = run_breadth(state["question"], decision, self.first_moves.get(rid), self.workspaces[rid], bank,
                          self.config, llms=self.llms, bm25=self.indexes.get(rid), trace=self.traces[rid],
                          deadline_ts=deadline, grid_only=bool(VARIANTS[state["variant"]].get("grid_only")), run_id=rid)
        own = [it.id for it in bank.all() if it.created_by.startswith(("fanout:", "extract"))]
        merged = Finding(sub_question=state["question"], answer=res.merged_answer() or "No findings.", evidence_ids=own,
                         confidence="medium" if res.findings or (res.grid and res.grid.n_added) else "low",
                         not_in_corpus=bool(res.findings) and all(f.not_in_corpus for f in res.findings),
                         calls_used=sum(f.calls_used for f in res.findings))
        findings = [merged.model_dump()] + [f.model_dump() for f in res.findings]
        errors = list(state.get("errors", []))
        if res.failed_units:
            errors.append(f"{len(res.failed_units)} fan-out unit(s) failed the hand-off: " + "; ".join(res.failed_units))
        done = "submitted" if (res.findings or (res.grid and res.grid.n_added)) else "no_findings"
        ms = int((time.perf_counter() - t0) * 1000)
        return {"findings": findings, "research_done": done, "partial": state.get("partial", False) or bool(res.failed_units) or done != "submitted",
                "errors": errors, "stage_ms": {**state.get("stage_ms", {}), "breadth": ms}}

    def _research(self, state: RunState) -> dict:
        rid = state["run_id"]
        t0 = time.perf_counter()
        s = self.config.stages
        research_deadline = min(time.time() + s.RESEARCH, state["deadline_ts"] - self._reserve_after_research())
        fm = self.first_moves.get(rid)
        spec = VARIANTS[state["variant"]]
        if "search" in spec["tools"] and rid not in self.indexes:   # BM25 tools without a first move
            index = BM25Index(self.workspaces[rid], self.config)
            self.indexes[rid] = index
            self.traces[rid].event("bm25_index", stage="research", n_chunks=len(index.chunks), build_ms=index.build_ms)
        tracker = ReadTracker()
        self.trackers[rid] = tracker
        ctx = ResearchContext(ws=self.workspaces[rid], bank=self.banks[rid], tracker=tracker,
                              trace=self.traces[rid], config=self.config, deadline_ts=research_deadline,
                              llm=self.llms.get("researcher"), run_id=rid, tool_names=list(spec["tools"]),
                              opening_observation=fm.opening_observation if fm is not None else None,
                              bm25=self.indexes.get(rid))
        run = ResearchLoop(ctx).run(state["question"])
        ms = int((time.perf_counter() - t0) * 1000)
        errors = list(state.get("errors", []))
        if run.done != "submitted":
            errors.append(f"research ended without a normal submission: {run.done}")
        return {"findings": [run.finding.model_dump()], "research_done": run.done,
                "partial": state.get("partial", False) or run.done != "submitted",
                "errors": errors, "stage_ms": {**state.get("stage_ms", {}), "research": ms}}

    def _write(self, state: RunState) -> dict:
        rid = state["run_id"]
        t0 = time.perf_counter()
        s = self.config.stages
        errors = list(state.get("errors", []))
        partial = state.get("partial", False)
        if state.get("research_done") is None:
            errors.append("research skipped: deadline left no time for it")
            partial = True
        unit_findings = [Finding(**f) for f in state.get("findings", [])[1:]] if len(state.get("findings", [])) > 1 else None
        report = write_report(state["question"], self.banks[rid], self.config, llm=self.llms.get("writer"),
                              trace=self.traces[rid], deadline_ts=state["deadline_ts"] - s.VERIFY - s.RESERVE,
                              research_partial=partial, findings=unit_findings)
        self.reports[rid] = report
        ms = int((time.perf_counter() - t0) * 1000)
        return {"report_md": report.markdown, "partial": report.partial, "errors": errors,
                "stage_ms": {**state.get("stage_ms", {}), "write": ms}}

    def _verify(self, state: RunState) -> dict:
        rid = state["run_id"]
        t0 = time.perf_counter()
        s = self.config.stages
        # injected models define the roster: with an `llms` dict that has no verifier, tier 2 is skipped
        # (tests); with no injection every role comes from dr.llm
        report, results = finalize_report(self.workspaces[rid], self.banks[rid], self.reports[rid], self.config,
                                          llm=self.llms.get("verifier"), trace=self.traces[rid],
                                          deadline_ts=min(time.time() + s.VERIFY, state["deadline_ts"] - s.RESERVE),
                                          tier2=(not self.llms) or ("verifier" in self.llms))
        ms = int((time.perf_counter() - t0) * 1000)
        self.traces[rid].stage("verify", "end", n_claims=len(results),
                               dropped=sum(1 for r in results if r.tier1 == "drop"),
                               tier2_unsupported=sum(1 for r in results if r.tier2 == "unsupported"), ms=ms)
        return {"report_md": report.markdown, "verify": [r.model_dump() for r in results],
                "stage_ms": {**state.get("stage_ms", {}), "verify": ms}}


# --------------------------------------------------------------------------- module-level API


def build_graph(config: Config = DEFAULT, llms: dict[str, Any] | None = None):
    """Compiled graph (the Pipeline owns the runtime objects; prefer `Pipeline(...)` directly)."""
    return Pipeline(config, llms).graph


def run(question: str, docs: list[DocRecord], variant: str = "A2_fs_agent", root: Path | None = None,
        config: Config = DEFAULT, llms: dict[str, Any] | None = None) -> RunState:
    """Convenience entry point for notebooks and the eval runner."""
    return Pipeline(config, llms).run(question, docs, variant, root)
