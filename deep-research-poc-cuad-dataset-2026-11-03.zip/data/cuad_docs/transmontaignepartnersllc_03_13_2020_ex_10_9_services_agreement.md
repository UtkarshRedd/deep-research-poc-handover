<!-- page 1 -->
# SERVICES AGREEMENT
| Field | Value |
|---|---|
| Document Type | Service Agreement |
| SEC Filing Date | 2020-03-13 |
| Parties | TransMontaigne Management Company, LLC ("EmployeeCo"); TLP Management Services, LLC ("Operating Company"); (each "Party," collectively "Parties") |
| Source | CUAD v1 / TRANSMONTAIGNEPARTNERSLLC_03_13_2020-EX-10.9-SERVICES AGREEMENT |

Exhibits 10.9 SERVICES AGREEMENT

This SERVICES AGREEMENT is entered into on, and effective as of, August __, 2019 (the "Effective
Date") among TransMontaigne Management Company, LLC, a Delaware limited liability company
("EmployeeCo") and TLP Management Services, LLC, a Delaware limited liability company (the
"Operating Company"). The above-named entities are sometimes referred to in this Agreement (as
defined herein) each as a "Party" and collectively as the "Parties."

WHEREAS, EmployeeCo employs certain individuals (the "Services Employees") who provide management,
operational and administrative services as necessary to operate the business of the Operating
Company and its affiliates (the "Services").

NOW THEREFORE, in consideration of the premises and the covenants, conditions, and agreements
contained herein, and for other good and valuable consideration, the receipt and sufficiency of
which are hereby acknowledged, the Parties hereto hereby agree as follows:

ARTICLE I Services

1.1 Provision of Services. EmployeeCo agrees to provide to the Operating Company and its affiliates
the Services and such other services as may be determined by the Parties from time to time.

1.2 Reimbursement and Allocation. The Operating Company shall reimburse EmployeeCo for all direct or
indirect costs and expenses incurred by EmployeeCo in connection with performing its obligations
under this Agreement including, but not limited to:

(a) salaries of the Services Employees;

(b) the cost of employee benefits for the Services Employees, including 401(k), pension, bonuses and
health insurance benefits (whether through insurance policies provided by third-parties or
self-insurance);

(c) costs associated with workers' compensation claims and other disputes or liabilities associated
with the Services Employees;

(d) severance costs with respect to any terminated Services Employees; and

(e) all sales, use, employment, excise, value added or similar taxes, if any, that may be applicable
from time to time with respect to the Services.

Such reimbursements shall be made by the Operating Company to EmployeeCo in advance or immediately
upon such costs being incurred, or otherwise in accordance with historical practice, unless
otherwise agreed between the Operating Company and EmployeeCo.

1
<!-- page 2 -->
1.3 Additional Fee. As an additional fee, the Operating Company shall also pay to EmployeeCo an
amount equal to 1% of the amount of all reimbursements made under Section 1.2, payable at the same
time as such reimbursements, unless otherwise agreed between the Operating Company and EmployeeCo.

1.4 Settlement of Obligations. The Parties may settle their financial obligations under this
Agreement Pursuant to the Parties' normal inter-affiliate settlement processes.

ARTICLE II Miscellaneous

2.1 Choice of Law; Submission to Jurisdiction. This Agreement shall be subject to and governed by
the laws of the State of Colorado, excluding any conflicts-of-law rule or principle that might refer
the construction or interpretation of this Agreement to the laws of another state. Each Party hereby
submits to the jurisdiction of the state and federal courts in the State of Colorado and to venue in
Denver, Colorado.

2.2 Entire Agreement. This Agreement constitutes the entire agreement of the Parties relating to the
matters contained herein, superseding all prior contracts or agreements, whether oral or written,
relating to the matters contained herein.

2.3 Termination of Agreement. This Agreement shall remain in effect until terminated by the Parties.
This Agreement may be terminated by (a) the written agreement of the Parties or (b) by either Party
upon 5 days written notice to the other Party. All payment obligations hereunder shall survive the
termination of this Agreement in accordance with their respective terms.

2.4 Amendment or Modification. This Agreement may be amended or modified from time to time only by
the written agreement of all the Parties hereto. Each such instrument shall be reduced to writing
and shall be designated on its face an "Amendment" or an "Addendum" to this Agreement.

2.5 Assignment. No Party shall have the right to assign its rights or obligations under this
Agreement without the consent of the other Parties hereto; provided, however, that either party
hereto may make a collateral assignment of this Agreement solely to secure working capital financing
for such party.

2.6 Counterparts. This Agreement may be executed in any number of counterparts with the same effect
as if all signatory parties had signed the same document. All counterparts shall be construed
together and shall constitute one and the same instrument. Delivery of an executed signature page of
this Agreement by facsimile transmission or in portable document format (.pdf) shall be effective as
delivery of a manually executed counterpart hereof.

2.7 Severability. If any provision of this Agreement shall be held invalid or unenforceable by a
court or regulatory body of competent jurisdiction, the remainder of this Agreement shall remain in
full force and effect.

2
<!-- page 3 -->
2.8 Further Assurances. In connection with this Agreement and all transactions contemplated by this
Agreement, each signatory party hereto agrees to execute and deliver such additional documents and
instruments and to perform such additional acts as may be necessary or appropriate to effectuate,
carry out and perform all of the terms, provisions and conditions of this Agreement and all such
transactions.

[Signature Page Follows]

3
<!-- page 4 -->
IN WITNESS WHEREOF, the Parties have executed this Agreement on, and effective as of, the date first
written above.

TRANSMONTAIGNE MANAGEMENT COMPANY, LLC By: /s/ Daniel R. Revers Name: Daniel R. Revers Title:
President TLP MANAGEMENT SERVICES, LLC By: /s/ Michael A. Hammell Name: Michael A. Hammell Title:
EVP, General Counsel
