"""outline: headings with line numbers and pages — the agent's table of contents for one doc.
RISE found an offline TOC worth +1–4 points; this derives one from markdown headings for
free. (A model-written TOC per doc can be added later as a sidecar.)
"""
from __future__ import annotations

import re

from ..config import DEFAULT, Config
from ..models import OutlineItem, OutlineResult
from ..workspace import Workspace

_HEADING_RE = re.compile(r"^(#{1,6})\s+(.+?)\s*#*\s*$")


def outline(ws: Workspace, doc_id: str, max_level: int = 3, config: Config = DEFAULT) -> OutlineResult:
    me = ws.manifest[doc_id]
    items: list[OutlineItem] = []
    truncated = False
    for i, ln in enumerate(ws.lines(doc_id), start=1):
        m = _HEADING_RE.match(ln)
        if not m:
            continue
        level = len(m.group(1))
        if level > max_level:
            continue
        if len(items) >= config.tools.OUTLINE_MAX_HEADINGS:
            truncated = True
            break
        items.append(OutlineItem(level=level, heading=m.group(2)[:120], line=i, page=ws.page_of(doc_id, i)))
    return OutlineResult(
        doc_id=doc_id, title=me.title, n_pages=me.n_pages, n_lines=me.n_lines, items=items, truncated=truncated
    )


def render(res: OutlineResult) -> str:
    out = [f"outline {res.doc_id} — {res.title} ({res.n_pages} pages, {res.n_lines} lines)"]
    for it in res.items:
        pg = f" p.{it.page}" if it.page else ""
        out.append(f"{'  ' * (it.level - 1)}- L{it.line}{pg}: {it.heading}")
    if res.truncated:
        out.append("… (more headings; use grep to locate sections)")
    return "\n".join(out)
