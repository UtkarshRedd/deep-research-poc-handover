<!-- page 1 -->
# SPONSORSHIP AND DEVELOPMENT AGREEMENT
| Field | Value |
|---|---|
| Document Type | Sponsorship Agreement |
| Agreement Date | 2004-08-06 |
| Parties | TEKNIK DIGITAL ARTS INC. ("TDA"); RICK SMITH ENTERPRISES ("Smith") |
| Source | CUAD v1 / HALITRON,INC_03_01_2005-EX-10.15-SPONSORSHIP AND DEVELOPMENT AGREEMENT |

EXHIBIT 10.15

SPONSORSHIP AND DEVELOPMENT AGREEMENT

This Agreement is made as of August 6, 2004 (the "Effective Date") by and between TEKNIK DIGITAL
ARTS INC., a Nevada corporation with offices at 7377 E. Doubletree Ranch Road, Suite 270,
Scottsdale, Arizona 85258 ("TDA") and RICK SMITH ENTERPRISES ("Smith"), c/o GAYLORD SPORTS
MANAGEMENT, 14646 N. Kierland Blvd., Suite 230, Scottsdale, Arizona 85254 Attention: Steve Loy.

RECITALS

TDA is in the business of developing and publishing interactive entertainment software products. TDA
desires to have Smith assist in the development, endorsement and publicizing of TDA's golf
instruction related software products.

THEREFORE, TDA and Smith agree as follows:

1. DEVELOPMENT, PRODUCTION, COMMERCIAL AND PUBLICITY SERVICES

1.1 General. Smith agrees to cooperate, consult with and aid TDA in connection with the development
of TDA's "Golf Instruction Related Product" (hereinafter defined) and the advertising, marketing and
publicity thereof. As used herein, the term "Golf Instruction Related Product" shall mean any
interactive entertainment software product related to golf instruction which is produced and
released during the "Term" (hereinafter defined in Section 5.1) and which may be published in
multiple versions (e.g., versions for play on handheld mobile devices (including cell phones), for
sale in any and all territories.

2. GRANT OF RIGHTS; COOPERATIONS

2.1 Publicity Rights. Smith hereby grants to TDA the following rights (the "Rights"):

(a) the right to use and reuse Smith's name, voice, likeness, facsimile signature, personal
statistics, biographical information and any reproduction or simulation thereof ("Smith's Likeness")
in TDA's Golf Instruction Related Products and on packaging for TDA's Golf Instruction Related
Products in any fashion, said grant of rights being limited to the world (the "Contract
Territory")";

(b) the right to use and reuse Smith's Likeness in TDA's general internal, non-public corporate
promotional materials (such as TDA's Annual Report), corporate advertising and in other forms of
publicity;

(c) the right to use and reuse Smith's Likeness in and in connection with the marketing,
advertising, promoting and publicizing of TDA's Golf Instruction Related Products, by any and all
means now known or hereafter developed;

(d) the exclusive right to use and reuse the results and proceeds of the in connection with TDA's
Golf Instruction Related Products; and

(e) with Smith's prior reasonable approval, the right to license to third parties any of the
foregoing rights but only in connection with or directly related to the marketing and sale of TDA's
Golf Instruction Related Products.

Smith agrees to cooperate in good faith with TDA in connection with TDA's exercise of the Rights in
accordance with the terms of this Agreement.

2.2 Limitations of License

(a) The Rights granted in Section 2.1 above will only be used by TDA in connection with its Golf
Instruction Related Products. TDA does not have the right to use the Rights in any product
whatsoever released before or after the Term.

(b) TDA shall not utilize Smith's Likeness in a manner that would constitute an endorsement of any
product or service other than TDA's Golf Instruction Related Products.

1

2.3 Smith as Featured Swing Instructor. TDA agrees that Smith will be the featured Instructor on all
packaging of, and promotional materials related to, TDA's Golf Instruction Related Product.

2.4 No Obligation to Use. Except as set forth in Section 2.3 above, the payment to Smith of the sums
required under this Agreement shall fully discharge all obligations of TDA to use Smith's Likeness
under this Agreement.

2.5 Approvals. TDA agrees that no use of Smith's Likeness in connection with advertisements,
promotions and other related/similar materials (specifically excluding, however, TDA's Golf
Instruction Related Products) will be made hereunder unless and until the same has been approved by
Smith in writing. Smith agrees that any material, advertising or otherwise, submitted for approval
as provided herein may be deemed by TDA to have been approved hereunder if the same is not
disapproved in writing within fourteen (14) days after receipt thereof. Smith agrees that any
material submitted hereunder will not be unreasonably disapproved and, if it is disapproved, that
TDA will be advised of
<!-- page 2 -->
the specified grounds therefore. TDA agrees to protect, indemnify and save harmless Smith and
Smith's agents, or either of them, from and against any and all expenses, damages, claims, suits,
actions, judgments and costs whatsoever, arising out of, or in any way connected with, any
advertising material furnished by, or on behalf of, TDA.

3. EXCLUSIVITY

3.1 Exclusivity Period. During the Term (the "Exclusivity Period"), Smith hereby represents,
warrants and agrees that he will not: (i) render any services in commercials or advertisements on
behalf of any computer game or videogame sports software product or service, or (ii) authorize the
use of Smith's Likeness in connection with any computer game or videogame golf instruction related
sports software product or service. These exclusivity obligations will not limit Smith's right to
appear in any of the entertainment fields or in the entertainment portion of any television, film or
video program; provided, however, that Smith may not appear in, or provide services in connection
with, advertisements for any computer game or videogame sports products. Notwithstanding anything
herein to the contrary, this Section 3.1 is specifically subject to the provisions of Section 2.2
above. Smith's obligations set forth in this Section 3.1, and as limited by Section 2.2, will be
referred to elsewhere in this Agreement as the "Exclusivity Obligations". Notwithstanding anything
herein to the contrary, TDA explicitly agrees that nothing herein shall preclude Smith from
participating in, or in any way limit Smith's participation in, any current or future PGA PLAYERS
and/or PGA TOUR group licensing arrangements.

4. COMPENSATION

4.1 Products. TDA will provide to Smith, free of all costs whatsoever (including without limitation,
taxes, duties, shipping and/or handling fees) (a) fifty (50) copies each of TDA's "Phil Smith Golf
instruction related" game mobile, handheld devices promptly after TDA's release thereof and (b)
fifty (50) copies of any other TDA products selected by Smith.

4.2 Compensation for Rights and Services. TDA agrees to pay Smith, as a consideration for the Rights
and Services.

1) 25,000 Restricted common shares of TDA,

a. As of the date of this agreement, Company has sold stock at $2.50/share.

b. Par Value is $.0001 per share.

2) 25% royalty of net TDA net sales price.

3) Option to convert annual royalties to TDA common stock at a $10 of stock for every $1 of Royalty
converted.

a. TDA stock conversion price based on the previous six month average daily price

b. Option is limited to 50% of TDA outstanding stock and if the option is exercised, it must be
exercised when the agreement &sbsp; is in effect.

All payments due under this Agreement shall be made in the form of a check drawn to the order of
"Rick Smith" and delivered to Smith's agent at the following address: Gaylord Sports Management,
l4646 N. Kierland Blvd., Suite 230, Scottsdale, Arizona 85254, Attn: Steve Loy. Payments shall be
made 15 days from the end of each

2

quarter. Smith's net payment after any such charges or deductions shall equal the amount set forth
above. Past due payments hereunder shall bear interest at the rate of (i) one and one-half percent
(1-1/2%) per month, or (ii) the maximum interest rate permissible under law, whichever is less.

4.3 Expenses. First-class round-trip air transportation, hotel room meal expenses, local limousine
service and miscellaneous expenses (e.g., telephone and overnight courier charges) incurred by Smith
and a guest designated by Smith will be paid by TDA or reimbursed by TDA to Smith where necessary in
the performance of Smith's Services under this Agreement; provided, however, that such expenses are
required and reasonable for a celebrity of Smith's stature.

5. AUDIT

5.1 Licensee shall keep accurate books of account and records at its principal place of business
covering all transactions relating to the License granted herein. Smith shall have the right to
engage an independent accounting firm to examine the Licensee's sales information and all other
books and records necessary to establish the accuracy and timeliness of the royalty statements
required hereunder. Such examination shall be at the premises of Licensee on ten (10) working days
written notice and during normal business hours. The information provided to Smith by the accounting
firm will be the net sales and the application of the appropriate royalty rate to calculate
royalties due. The accounting firm shall be required to take reasonable steps to hold all Licensee
information confidential. Details of the review and all work papers and related supporting data
pertaining to the review will be held confidential by the accounting firm and will not be shown,
divulged, or delivered directly or indirectly to Smith or any third party. The accounting firm shall
be bound by a non-disclosure agreement in the form to be provided by Licensee to ensure compliance
with this paragraph. The examination may be conducted not more than
<!-- page 3 -->
once a year. If it is determined that Licensee has made any Royalty underpayment which is greater
than five percent (5%) for any Royalty Period, the Licensee shall reimburse Smith for the costs and
expenses of such audit.

5.2 Upon request by Smith, but not more than once each year, Licensee shall, at its own cost,
furnish to Smith within thirty (30) days after such request a detailed statement, prepared by
Licensee's Chief Financial Officer, setting forth the number of Products manufactured from the later
of the commencement of this Agreement or the date of any previous such statement up to and including
the date of Smith's request therefore and also setting forth the pricing information for all
Products (including the number and description of the Products) shipped, distributed and sold by
Licensee during the aforementioned time period.

5.3 All books of account and records of Licensee covering all transactions relating to the Licensee
shall be retained by the Licensee until at least two (2) years after the expiration or termination
of the Term for possible inspection by Smith.

6. TERM

6.1 Term. The term of this Agreement (the "Term") shall commence on the Effective Date and terminate
at the end of the Exclusivity Period (i.e., a three (3) year period commencing on the Effective
Date).

6.2 Post-Term Sales. Upon expiration of this Agreement, TDA shall cease all uses of the Rights
and/or Smith's Likeness with respect to advertising, endorsing and/or promoting TDA, but TDA shall
be free to continue to distribute and sell its Golf Instruction Related Products which incorporate
Smith's Likeness for up to 180 days after the expiration of the Term (although TDA may not use the
Rights or Smith's Likeness to promote or advertise TDA or any of TDA's non-Golf Instruction Related
Products when selling the Golf Instruction Related Products, nor can TDA highlight Smith's Likeness
in its packaging or sales efforts); provided, however, that TDA shall have no such right of
post-Term sales unless TDA is not in default of any of its obligations hereunder as of the date of
expiration or termination.

7. REPRESENTATIONS, WARRANTIES AND COVENANTS

7.1 Representations and Warranties.

(a) Smith represents and warrants that:

(i) Smith has full right to enter into this Agreement and to perform all of his obligations
hereunder without, to his knowledge, violating the legal or equitable rights of any person, firm or
entity and that TDA shall not be under any obligation for the payment of any

3

commissions or fees to any person, firm or entity on account of this Agreement, other than advances,
compensation, royalties and expenses expressly payable to Smith by TDA under this Agreement;

(ii) Smith will perform the Services in a professional and workmanlike manner, to the extent of
Smith's professional abilities.

(b) TDA represents and warrants that:

(i) TDA has full right to enter into this Agreement and to perform all of its obligations hereunder
without, to its knowledge, violating the legal or equitable rights of any person, firm or entity and
that Smith shall not be under any obligation for the payment of any commissions or fees to any
person, firm or entity related to or connected with TDA on account of this Agreement.

(c) Notwithstanding anything herein to the contrary, TDA agrees that nothing contained herein shall
be construed to convey to TDA any rights to use the trademarks, logos or uniform of the PGA TOUR
("PGA"), any other professional or amateur golf instruction related association (including any
member players of such association) in conjunction with the rights granted hereunder. All rights to
the use of such trademarks, logos or team identification must be acquired from the PGA or any other
appropriate rights holder.

7.2 Further Assurances and Execution of Documents. Smith will, if requested and reasonable, furnish
affidavits and other appropriate documentation that may be required, in TDA's reasonable judgment
and at TDA's expense, to comply with any applicable governmental or other regulations, broadcast
clearance procedures, or sports/entertainment industry guidelines relating to product endorsement.
Furthermore, Smith hereby agrees to execute any and all documents which are required by any guild or
union having jurisdiction over any of the services to be provided by Smith under this Agreement.

7.3 Confidential Information and Non-Disparagement. Neither party will disclose or use any
confidential or proprietary information that such party obtains from or about the other or its
products. Both parties agree that the existence and results of any arbitration held pursuant to this
Agreement will be treated confidentially. Smith will not authorize or release advertising matter or
publicity nor give interviews which make reference to the details of the material terms of this
Agreement, without TDA's prior written approval, although Smith may, during interviews, respond,
discuss and comment in a non-disparaging manner that Smith is associated with TDA and its Golf
Instruction Related Products.
<!-- page 4 -->
8. OWNERSHIP OF PROPRIETARY RIGHTS

8.1 All right, title and interest in and to TDA's Golf Instruction Related Products shall be and
remain the absolute property of TDA forever (it being understood that after the Term TDA may
continue to manufacture, promote, sell and/or distribute its other golf instruction related
interactive entertainment sports products which are separate and distinct from the Golf Instruction
Related Products incorporating Smith's Likeness on the packaging without being subject to any of the
limitations or restriction herein, provided that the Rights are not (directly or indirectly)
utilized by or incorporated in such other golf instruction related interactive sports products. All
right, title and interest in and to the Results and Proceeds and to the Advertising Materials (as
defined below) shall be and remain the absolute property of TDA forever (but which may only be used
during the Term and, subject to the limitations and conditions set forth in this Agreement,
thereafter). Without limiting the foregoing, TDA shall, during the Term (and, Subject to the
limitations and conditions on the Rights as set forth in this Agreement, thereafter) have the full
and complete right to revise, telecast, broadcast, use, distribute, reproduce, record, publish,
print, license, copyright and exhibit the contents of any Results and Proceeds, the Golf Instruction
Related Products and any Advertising Materials and any versions or revisions thereof and, in TDA's
sole discretion, the Results and Proceeds, the Golf Instruction Related Products and Advertising
Materials may be make by any process, instrumentation or device now known or hereafter developed and
may be made or adapted for use in any and all media now known or hereafter developed (although it is
acknowledged and agreed by TDA that multi-media usage (except, of course, as incorporated into TDA's
Golf Instruction Related Products) shall be strictly limited to advertising) provided that any and
all such uses are directly related to the marketing, development and sale of TDA's Golf Instruction
Related Products. Smith further acknowledges that TDA may adapt and use, and protect by

4

any means including registration with the appropriate authorities, a trademark or trade name
incorporating Smith's Likeness, and that Smith shall, until after the Term, have no right, title or
interest in or to any such trademark, trade name or related goodwill. As used in this Agreement,
"Advertising Material" means any commercials, print materials, copy, advertising, promotional and
publicity materials published under this Agreement which include or make reference to Smith's
Likeness and all elements thereof.

8.2 Notwithstanding anything herein to the contrary, TDA agrees not to remove, airbrush or otherwise
alter the trademarks and logos of Smith's equipment manufacturer (currently Mission) from the
packaging of TDA's Golf Instruction Related Products and/or the Advertising Materials, provided
that, upon TDA's written request, Smith secures for TDA, at no cost to TDA, all necessary written
permissions or grants of rights from any such equipment manufacturer or third party.

9. INDEMNITY

9.1 By TDA. TDA shall indemnify and hold harmless Smith, Smith's agent, and Smith's heirs, executors
and legal representatives from and against any and all damages, costs, judgments, penalties and
expenses of any kind (including reasonable legal fees and disbursements) which may be obtained
against, imposed upon or suffered by any of them as a result of (a) any claims or representations
made by Smith in any Advertising Materials produced or used by TDA hereunder, (b) TDA's default,
breach, negligence, errors and/or misconduct hereunder, and/or (c) any claim arising from any third
party's use or association with TDA;s products.

10. GENERAL

10.1 Taxes. Smith represents and warrants that, in performing its obligations under this Agreement,
Smith does so as an independent contractor and, without limiting the foregoing, Smith assumes
exclusive responsibility for the collection and payments of all employer and employee contributions
and taxes under all applicable laws now in effect or hereafter enacted and Smith further agrees to
file any returns or reports necessary in connection therewith. TDA shall have the right to deduct
from any amounts payable hereunder such portion thereof as are required to be deducted under
applicable statute, regulation, treaty or other law, and Smith shall promptly execute and deliver to
TDA such forms and other documents as may be required in connection therewith. Notwithstanding
anything herein to the contrary, it is agreed and acknowledged that TDA remains liable for the
payment of all pension and health welfare contributions required of any guild or labor organization
(i.e., SAG, AFTRA, etc.).

10.2 Notices. All notices and statements hereunder required to be given to TDA shall be sent to TDA
at its address stated at the beginning of this Agreement, to the attention of the General Counsel,
and all notices to Smith shall be sent to Smith at the address stated at the beginning of this
Agreement, unless either party notifies the other party in writing if a change of address in
accordance with the provisions of this Section. Notices are deemed to be received by the addressee
of the notice on the earlier or the date the notice is actually delivered to the addressee and: (i)
three (3) days after the notice is sent by certified mail, postage prepaid, return receipt
requested; (ii) the next business day after the notice is sent by confirmed fax transmission; or
(iii) on the date of guaranteed delivery if the notice is sent by recognized national or
international express courier.

10.3 Right of Offset. Notwithstanding any provision contained in this Agreement, neither party will
be prohibited from exercising any right of offset that may be available at law.
<!-- page 5 -->
10.4 Governing Law. This Agreement will be deemed entered into in Arizona and will be governed by
and interpreted in accordance with the internal substantive laws of the State of Arizona without
reference to conflicts of law provisions.

10.5 Entire Agreement. This Agreement constitutes the entire understanding between the parties
hereto with respect to the subject matter hereof, and all prior agreements and understandings,
whether oral or written, are hereby superseded in their entirety. No waiver, modification or
addition to this Agreement shall be valid unless in writing and signed by the party sought to be
charged therewith.

10.6 Assignment. This Agreement may be assigned by Smith and TDA with the other party's prior
written approval. Except with Smith's prior written approval, this Agreement may not be assigned by
TDA: (i) in connection with a merger, a sale of all or substantially all of the assets of TDA or
other similar corporate reorganization, or the sale of substantially all of TDA's rights to all of
its Golf Instruction Related Products; or (ii) to

5

an affiliated, parent, subsidiary, related company (or in the case of the production of Advertising
Materials to an advertising agency representing TDA) so as to effectuate the intent of this
Agreement and the subject matter hereof, although TDA will continue to be liable for all financial
obligations hereunder.

10.7 Severability. Should any provision of this Agreement be held to be void, invalid or
inoperative, such provision will be enforced to the extent permissible and the remaining provisions
of this Agreement will not be affected.

10.8 Attorney's Fees. In any suit, arbitration or other proceeding under this Agreement, the
prevailing party will be entitled to recover its reasonable fees and expenses of attorneys and other
professionals, including all fees and expenses of appeal and enforcement.

10.9 Liability. In no event (including, but not limited to, Smith's default hereunder) shall Smith
be liable to TDA (or any entity claiming through TDA) for any amount in excess of the amounts
actually received by Smith hereunder, excluding the reimbursement of expenses. Under no
circumstances will Smith be liable to TDA or any other entity for any special, consequential,
indirect, exemplary and/or punitive damages, or for loss of good will or business profits.

10.10 Applicable Law and Disputes. This Agreement shall be governed by the laws of the State of
Arizona applicable to agreements fully executed and performed therein. Any claims arising hereunder
or relating hereto shall be prosecuted only in the appropriate court or the State of Arizona or in
the applicable United States District Court and neither party shall make any claim or demand in any
other jurisdiction forum. Each party waives its right to a trial by jury and agrees to the
jurisdiction of the judge in the appropriate court as governed by the State of Arizona. The parties
consent to the personal jurisdiction of such courts and to the service of process by mail.

10.11 Force Majeure. If at any time during this Agreement, Smith or TDA is prevented from or
hampered or interrupted or interfered with in any manner whatever in fully performing their
respective duties hereunder by reason of any present or future statute, law, ordinance, regulation,
order, judgment or decree, whether legislative, executive or judicial (whether or not valid), act of
God, earthquake, flood, fire, epidemic, accident, explosion, casualty, lockout, boycott, strike,
labor controversy (including, but not limited to threat of lockout, boycott or strike), riot, civil
disturbance, war or armed conflict (whether or not there has been an official declaration of ___ or
official statement as to the existence of a state of war), invasion, occupation, intervention or
military forces, act of public enemy, embargo, delay of a common carrier, inability without fault of
such party to obtain sufficient material, labor, transportation, power or other essential commodity
required in the conduct of business; or by reason of any event beyond any of the foregoing parties'
reasonable control (e.g., illness, family emergency, etc.); or by reason of any other cause or
causes of any similar nature (all of the foregoing being herein referred to as an "event of force
majeure"), then the applicable party's obligations hereunder shall be suspended as often as any such
event of force majeure occurs and during such periods of time as such events of force majeure exist
and such non-performance shall not be deemed to be a breach of this Agreement.

10.12 Reservation of Rights. All rights not herein specifically granted to TDA shall remain the
property of Smith to be used in any manner Smith deems appropriate. TDA understands that Smith has
reserved the right to authorize others to use Smith's Likeness within the Contract Territory and
during the Term in connection with all tangible and intangible items and services other than TDA's
Golf Instruction Related Products as specifically set forth herein.

IN WITNESS WHEREOF, the parties hereby execute this Agreement as of the Effective Date by signing
below.

TEKNIK DIGITAL ARTS INC. RICK SMITH

By: /s/ John Ward By: /s/ Rick Smith -------------------------- ---------------------------------
Name: John Ward Title: Chairman Date: August 6, 2004 Date: August 6, 2004

6
<!-- page 6 -->
AMENDMENT

4. COMPENSATION

4.1 Products. TDA will provide to Smith, free of all costs whatsoever (including without limitation,
taxes, duties, shipping and/or handling fees) (a) fifty (50) copies each of TDA's "Phil Smith Golf
instruction related" game mobile, handheld devices promptly after TDA's release thereof and (b)
fifty (50) copies of any other TDA products selected by Smith.

4.2 Compensation for Rights and Services. TDA agrees to pay Smith, as a consideration for the Rights
and Services.

1) 25,000 Restricted common shares of TDA,

a. As of the date of this agreement, Company has sold stock at $2.50/share.

b. Par Value is $.0001 per share.

2) 33% royalty of net TDA net sales price.

a. Handheld products 33% or $1 per subscription whichever is greater

3) Option to convert annual royalties to TDA common stock at a $10 of stock for every $1 of Royalty
converted.

a. TDA stock conversion price based on the previous six month average daily price

b. Option is limited to 25,000 shares of TDA common stock and if the option is exercised, it must be
exercised when the agreement is in effect.

c. This one-time option would cease all future royalties.

All payments due under this Agreement shall be made in the form of a check drawn to the order of
"Rick Smith" and delivered to Smith's agent at the following address: Gaylord Sports Management,
l4646 N. Kierland Blvd., Suite 230, Scottsdale, Arizona 85254, Attn: Steve Loy. Payments shall be
made 15 days from the end of each quarter. Smith's net payment after any such charges or deductions
shall equal the amount set forth above. Past due payments hereunder shall bear interest at the rate
of (i) one and one-half percent (1-1/2%) per month, or (ii) the maximum interest rate permissible
under law, whichever is less.

4.3 Expenses. First-class round-trip air transportation, hotel room meal expenses, local limousine
service and miscellaneous expenses (e.g., telephone and overnight courier charges) incurred by Smith
and a guest designated by Smith will be paid by TDA or reimbursed by TDA to Smith where necessary in
the performance of Smith's Services under this Agreement; provided, however, that such expenses are
required and reasonable for a celebrity of Smith's stature.

This Section Amended: December 10, 2004 /s/ RS ------------------ /s/ JW ------------------

7
