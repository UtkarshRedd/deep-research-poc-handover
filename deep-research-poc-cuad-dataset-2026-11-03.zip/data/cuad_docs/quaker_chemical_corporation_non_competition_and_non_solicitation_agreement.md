<!-- page 1 -->
# NON-COMPETITION AND NON-SOLICITATION AGREEMENT
| Field | Value |
|---|---|
| Document Type | Non-Compete / Non-Solicit Agreement |
| Agreement Date | 2019-08-01 |
| Parties | Quaker Chemical Corporation (“Buyer”); Gulf Houghton Lubricants Ltd. (“Gulf Houghton”); Gulf Oil International Limited (“GulfInternational”); GOCL Corporation Limited (“Gulf Oil” and, together with Gulf Houghton andGulf International, the “Sellers” and each, a “Seller”); Gulf Oil Lubricants India, Ltd (“Gulf India”), solely for purposes of Section 1(c)[Confidentiality; Non-competition; Non-solicitation] |
| Source | CUAD v1 / Quaker Chemical Corporation - NON COMPETITION AND NON SOLICITATION AGREEMENT |

EXHIBIT 10.2 EXECUTION VERSION NON-COMPETITION AND NON-SOLICITATION AGREEMENT THIS NON-COMPETITION
AND NON-SOLICITATION AGREEMENT (this "Agreement"), dated as of August 1, 2019 (the "Effective
Date"), is entered into by Quaker Chemical Corporation ("Buyer"), a Pennsylvania corporation, Gulf
Houghton Lubricants Ltd., a company incorporated in the Cayman Islands ("Gulf Houghton"), Gulf Oil
International Limited, a company incorporated in the Cayman Islands ("Gulf International"), and GOCL
Corporation Limited, a public limited company incorporated in India ("Gulf Oil" and, together with
Gulf Houghton and Gulf International, the "Sellers" and each, a "Seller"). In addition, Gulf Oil
Lubricants India, Ltd, a public limited company incorporated in India ("Gulf India"), is executing
this Agreement solely for purposes of Section 1(c) [Confidentiality; Non-competition;
Non-solicitation]. BACKGROUND WHEREAS, Gulf Houghton owns 3,074,270.00 of the outstanding ordinary
shares (the "Shares") in Global Houghton Ltd., an exempted company incorporated under the Laws of
the Cayman Islands (the "Company"); Gulf International owns approximately 90% of Gulf Houghton; and
Gulf Oil is an indirect owner of approximately 10% of Gulf Houghton. WHEREAS, The Company and its
subsidiaries are engaged in the business of manufacturing, distributing and/or selling one or more
of the following formulated chemical specialty product lines: fire resistant hydraulic fluids,
semi-synthetic and specialty metalworking fluids, cleaning fluids, cold-rolling oils, hot-rolling
oils, and specialty industrial greases (such business, as conducted by the Company and its
Subsidiaries as of the Effective Date, the "Company Business"). WHEREAS, Buyer and its subsidiaries
are engaged in the business of manufacturing, distributing and/or selling the following formulated
chemical specialty product lines or chemical management services ("CMS"), (i) rolling lubricants
(used by manufacturers of steel in the hot and cold rolling of steel and by manufacturers of
aluminum in the hot rolling of aluminum); (ii) corrosion preventives (used by steel and metalworking
customers generally to protect metal during manufacture, storage, and shipment); (iii) metal
finishing compounds (used to prepare metal surfaces for special treatments such as, but not limited
to, galvanizing and tin plating and to prepare metal for further processing); (iv) machining and
grinding compounds (typically used by customers in cutting, shaping, and grinding metal parts which
require special treatment to enable them to tolerate the manufacturing process, achieve closer
tolerance, and improve tool life); (v) forming compounds (used generally to facilitate the drawing
and extrusion of metal products); (vi) bio-lubricants (typically used in machinery in the forestry
and construction industries); (vii) hydraulic fluids (used generally by steel, metalworking, mining,
and other customers to operate hydraulic equipment); (viii) chemical milling maskants for the
aerospace industry; (ix) temporary and permanent coatings for metal and concrete products, tubes and
pipes and other applications; (x) construction products, such as flexible sealants and protective
coatings, for various applications; (xi) various specialty greases used in automobile, industrial
and various other applications; (xii) various die casting lubricants and mold release agents; (xiii)
various dust suppressants, ground control agents and roofing products used in mining; and (xiv)
<!-- page 2 -->
programs to provide CMS (such business, as conducted by Buyer and its subsidiaries as of the
Effective Date, the "Existing Business" and, together with the Company Business, the "Combined
Business"). WHEREAS, Buyer, Gulf Houghton and other shareholders of the Company are parties to a
Share Purchase Agreement dated as of April 4, 2017, under which Buyer is acquiring the Shares (the
"Purchase Agreement"). Capitalized terms used herein but not otherwise defined herein shall have the
meanings given to such terms in the Purchase Agreement. WHEREAS, Sellers, together with the Company,
have been substantially involved in and with the Company's operations and management and possess
trade secrets and other confidential information relating to the Company Business and the Company's
clients, customers, vendors, suppliers and operations. WHEREAS, it is integral to Buyer's
acquisition of the Company Business and a condition precedent to the closing of the transactions
contemplated by the Purchase Agreement that the Sellers enter into this Agreement with Buyer to
provide for the protection of the Combined Business's customer and vendor relationships, trade
secrets, confidential information and other business operations. Pursuant to the Purchase Agreement,
Gulf Houghton shall receive cash consideration and shares of Buyer's capital stock in exchange for
the Shares owned by Gulf Houghton and as inducement for Gulf Houghton and the other Sellers to enter
into this Agreement. NOW THEREFORE, in consideration of the premises and the mutual representations,
warranties, covenants and agreements contained in this Agreement and in the Purchase Agreement, the
parties, intending to be legally bound, agree as follows: 1. Confidentiality; Non-competition;
Non-solicitation. (a) From and after the date hereof, each Seller shall, and shall cause its
Affiliates to, hold, and shall use its reasonable best efforts to cause its or their respective
Representatives to hold, in confidence any and all information, whether written or oral, concerning
Buyer, the Company and the Company Subsidiaries, except to the extent that such Seller can show that
such information: (i) is generally available to and known by the public through no fault of any
Seller or any of their respective Affiliates or Representatives or (ii) is lawfully acquired by such
Seller, any of its Affiliates or their respective Representatives from and after the date hereof
from sources that are not prohibited from disclosing such information by a legal, contractual or
fiduciary obligation. If any Seller or any of its Affiliates or their respective Representatives are
compelled to disclose any information by judicial or administrative process or by other requirements
of Law, such Seller shall promptly notify Buyer in writing and shall disclose only that portion of
such information that such Seller is advised by its counsel is legally required to be disclosed,
provided that such Seller shall use reasonable best efforts to obtain an appropriate protective
order or other reasonable assurance that confidential treatment will be accorded such information.

2
<!-- page 3 -->
(b) Each Seller agrees that for a period commencing on the Effective Date and ending two years after
the Closing Date (the "Non- Compete Period"), it shall not, other than solely through its direct or
indirect ownership of Buyer's capital stock or any other interests in Buyer, directly, or
indirectly, including through or on behalf of a subsidiary, anywhere in the world, excluding India:
(i) own, manage, operate or control any business which competes with any Combined Business or (ii)
be or become a shareholder, partner, member or owner of any Person who is engaged in any Combined
Business; provided, however that nothing in this Agreement shall: (i) prohibit or restrict any
Seller, directly or indirectly, from owning, as a passive investor, not more than five (5%) percent
collectively and in the aggregate of any class of outstanding publicly traded securities of any
Person so engaged; (ii) prohibit or restrict any Seller, directly or indirectly, from engaging in
such Seller's business as conducted on the Effective Date and reasonable extensions thereof, which
may include routine, day-to-day transactions with any entity, and (iii) apply to or restrict any
business of which a Seller acquires control after the Effective Date provided that the acquired
business did not receive more than $25,000,000 of its aggregate net sales (as measured during the 12
full calendar months prior to such acquisition) from product lines included within the definition of
Company Business. Each Seller agrees that this covenant is reasonable with respect to its duration,
geographical area and scope. For purposes of this Agreement, the term "control" (including the terms
"controlled by" and "under common control with") means the possession, directly or indirectly, of
the power to direct or cause the direction of the management and policies of a Person, whether
through the ownership of voting securities, by contract or otherwise. (c) Gulf Oil and Gulf India
each agree during the Non-Compete Period not to acquire, directly or indirectly, control of any
businesses involved in, or otherwise competing with, the business of the Combined Business from any
entity on Schedule 1 hereto. (d) Each Seller agrees that for a period commencing on the Effective
Date and ending three years after the Closing Date (the "Non-Solicit Period"), each Seller shall
not, directly or indirectly: (i) induce, solicit, recruit or attempt to persuade any employee of the
Combined Business to terminate his or her employment with the Buyer or any of its subsidiaries, or
(ii) solicit the employment of any of the employees of the Combined Business. Notwithstanding the
above, Sellers shall not be restricted from (1) soliciting for employment or hiring former employees
of Buyer or the Company (including their respective subsidiaries) whose employment was terminated by
Buyer or the Company (including their respective subsidiaries) at least six months prior to such
initial solicitation by such Seller or (2) soliciting employees of the Combined Business by means of
a general solicitation through a public medium or general or mass mailing that is not specifically
targeted at employees or former

3
<!-- page 4 -->
employees of the Combined Business; provided, however, that this clause (2) shall not permit any
Seller to hire any such employees during the Non-Solicit Period. (e) It is the intention of the
parties that the covenants contained in this Section 1 shall be enforced to the greatest extent (but
to no greater extent) in time, area and degree of participation as is permitted by the Law of that
jurisdiction whose Law is applicable to any acts allegedly in breach of such covenants. To this end,
the parties agree that the covenants contained in this Section 1 shall be construed to extend in
time and territory and with respect to degree of participation only so far as they may be enforced
in such jurisdiction, and that the covenants contained in this Section 1 are to that end hereby
declared divisible and severable. It being the purpose of this Section 1 to govern competition by
the Sellers and their respective subsidiaries, the non-competition covenants contained in this
Section 1 shall be governed by and construed according to the Law of all the jurisdictions in which
competition in breach of this Agreement is alleged to have occurred or to be threatened that best
gives them effect. 2. Notices. All notices, requests, consents, claims, demands, waivers and other
communications hereunder shall be in writing and shall be deemed to have been given: (a) when
delivered by hand (with written confirmation of receipt); (b) when received by the addressee if sent
by a nationally recognized overnight courier (receipt requested); (c) on the date sent by facsimile
or e-mail of a PDF document (with confirmation of transmission) if sent during normal business hours
of the recipient, and on the next Business Day if sent after normal business hours of the recipient
or (d) on the third day after the date mailed, by certified or registered mail, return receipt
requested, postage prepaid. Such communications must be sent to the respective parties at the
following addresses (or at such other address for a party as shall be specified in a notice given in
accordance with this Section 2): To the Buyer: Quaker Chemical Corporation One Quaker Park 901 E.
Hector Street Conshohocken, PA 19428-2380 Facsimile: (610) 832-4496 E-mail: traubr@quakerchem.com
Attention: Robert T. Traub with a copy (which shall not constitute notice) to: Drinker, Biddle &
Reath LLP One Logan Square Suite 2000 Philadelphia, Pennsylvania 19103 Facsimile: (215) 988-2757
E-mail: Douglas.Raymond@dbr.com Attention: F. Douglas Raymond, III

4
<!-- page 5 -->
If to any of the Sellers: Gulf Houghton Lubricants Ltd. Whitehall House, 238 North Church Street,
P.O. Box 1043, George Town Grand Cayman KY1-1102 Cayman Islands Facsimile: (305) 675-2619 Email:
Sandra@accla.im Attention: Sandra Georgeson with a copy (which shall not constitute notice) to:
Mayer Brown LLP 1221 Avenue of the Americas New York, New York 10020 Facsimile: (212) 849-5914
E-mail: rwheeler@mayerbrown.com Attention: Reb D. Wheeler 3. Successors and Assigns. This Agreement
shall be binding upon and inure to the benefit of the parties and their respective successors and
permitted assigns; provided that this Agreement shall not be assignable or otherwise transferable by
any party without the prior written consent of the other party (which consent shall not be
unreasonably withheld or delayed) and any purported assignment or transfer without such consent
shall be null and void. No assignment shall relieve the assigning party of any of its obligations
hereunder. 4. Governing Law. (a) THIS AGREEMENT SHALL BE GOVERNED BY AND CONSTRUED IN ACCORDANCE
WITH THE INTERNAL LAWS OF THE COMMONWEALTH OF PENNSYLVANIA WITHOUT GIVING EFFECT TO ANY CHOICE OR
CONFLICT OF LAW PROVISION OR RULE (WHETHER OF THE COMMONWEALTH OF PENNSYLVANIA OR ANY OTHER
JURISDICTION). (b) ANY LEGAL SUIT, ACTION OR PROCEEDING ARISING OUT OF OR BASED UPON THIS AGREEMENT,
THE OTHER TRANSACTION DOCUMENTS OR THE TRANSACTIONS CONTEMPLATED HEREBY OR THEREBY MAY BE INSTITUTED
IN THE FEDERAL COURTS OF THE UNITED STATES OF AMERICA OR THE COURTS OF THE COMMONWEALTH OF
PENNSYLVANIA IN EACH CASE LOCATED IN THE CITY OF PHILADELPHIA AND COUNTY OF PHILADELPHIA, AND EACH
PARTY IRREVOCABLY SUBMITS TO THE EXCLUSIVE JURISDICTION OF SUCH COURTS IN ANY SUCH SUIT, ACTION OR
PROCEEDING. SERVICE OF PROCESS, SUMMONS, NOTICE OR OTHER DOCUMENT BY MAIL TO SUCH PARTY'S ADDRESS
SET FORTH HEREIN SHALL BE EFFECTIVE SERVICE OF PROCESS FOR ANY SUIT, ACTION OR OTHER PROCEEDING
BROUGHT IN ANY SUCH COURT. THE

5
<!-- page 6 -->
PARTIES IRREVOCABLY AND UNCONDITIONALLY WAIVE ANY OBJECTION TO THE LAYING OF VENUE OF ANY SUIT,
ACTION OR ANY PROCEEDING IN SUCH COURTS AND IRREVOCABLY WAIVE AND AGREE NOT TO PLEAD OR CLAIM IN ANY
SUCH COURT THAT ANY SUCH SUIT, ACTION OR PROCEEDING BROUGHT IN ANY SUCH COURT HAS BEEN BROUGHT IN AN
INCONVENIENT FORUM. (c) EACH PARTY ACKNOWLEDGES AND AGREES THAT ANY CONTROVERSY WHICH MAY ARISE
UNDER THIS AGREEMENT OR THE OTHER TRANSACTION DOCUMENTS IS LIKELY TO INVOLVE COMPLICATED AND
DIFFICULT ISSUES AND, THEREFORE, EACH SUCH PARTY IRREVOCABLY AND UNCONDITIONALLY WAIVES ANY RIGHT IT
MAY HAVE TO A TRIAL BY JURY IN RESPECT OF ANY LEGAL ACTION ARISING OUT OF OR RELATING TO THIS
AGREEMENT, THE OTHER TRANSACTION DOCUMENTS OR THE TRANSACTIONS CONTEMPLATED HEREBY OR THEREBY. EACH
PARTY TO THIS AGREEMENT CERTIFIES AND ACKNOWLEDGES THAT (A) NO REPRESENTATIVE OF ANY OTHER PARTY HAS
REPRESENTED, EXPRESSLY OR OTHERWISE, THAT SUCH OTHER PARTY WOULD NOT SEEK TO ENFORCE THE FOREGOING
WAIVER IN THE EVENT OF A LEGAL ACTION, (B) SUCH PARTY HAS CONSIDERED THE IMPLICATIONS OF THIS
WAIVER, (C) SUCH PARTY MAKES THIS WAIVER VOLUNTARILY AND (D) SUCH PARTY HAS BEEN INDUCED TO ENTER
INTO THIS AGREEMENT BY, AMONG OTHER THINGS, THE MUTUAL WAIVERS AND CERTIFICATIONS IN THIS SECTION
4(C) [Governing Law]. 5. Injunctive Relief; Attorneys Fees. Each Seller agrees that in the event of
a breach of this Agreement, the damage to Buyer will be inestimable and that therefore any remedy at
Law or in monetary damages shall be inadequate. Accordingly, the parties agree that Buyer shall, in
addition to monetary damages incurred by reason of any such breach or potential breach, without the
necessity of posting any bond or similar instrument (and Sellers hereby irrevocably waive any right
it may have to require the obtaining, furnishing or posting of any such bond or similar instrument)
be entitled to seek injunctive relief (including specific performance) against the Sellers for
breach of this Agreement. If any action or proceeding shall be commenced to enforce this Agreement
or any right arising in connection with this Agreement, the prevailing party in such action or
proceeding shall be entitled to recover from the other party the reasonable attorneys' fees, costs
and expenses incurred by such prevailing party in connection with such action or proceeding. 6.
Entire Agreement. This Agreement and the other Transaction Documents to which the parties hereto are
parties constitute the sole and entire agreement of the parties to this Agreement with respect to
the subject matter contained herein and therein, and supersede all prior and contemporaneous
understandings and agreements, both written and oral, with respect to such subject matter. 7.
Amendment Waivers, etc. No amendment, modification or discharge of this Agreement, and no waiver
hereunder, shall be valid or binding unless set forth in writing and duly executed by the party
against whom enforcement of the amendment, modification, discharge or waiver is sought. Any such
waiver shall constitute a waiver only with respect to the

6
<!-- page 7 -->
specific matter described in such writing and shall in no way impair the rights of the party
granting such waiver in any other respect or at any other time. Neither the waiver by a party of a
breach of or a default under any of the provisions of this Agreement, nor the failure by any party,
on one or more occasions, to enforce any of the provisions of this Agreement or to exercise any
right or privilege hereunder, shall be construed as a waiver of any other breach or default of a
similar nature, or as a waiver of any of such provisions, rights or privileges hereunder. The rights
and remedies herein provided are cumulative and none is exclusive of any other, or of any rights or
remedies that any party may otherwise have at law or in equity. 8. Severability. If any term or
provision of this Agreement is invalid, illegal or unenforceable in any jurisdiction, such
invalidity, illegality or unenforceability shall not affect any other term or provision of this
Agreement or invalidate or render unenforceable such term or provision in any other jurisdiction.
Upon such determination that any term or other provision is invalid, illegal or unenforceable, the
parties hereto shall negotiate in good faith to modify this Agreement so as to effect the original
intent of the parties as closely as possible in a mutually acceptable manner in order that the
transactions contemplated hereby be consummated as originally contemplated to the greatest extent
possible. 9. Counterparts; Effectiveness; Third Party Beneficiaries. This Agreement may be executed
in counterparts, each of which shall be deemed an original and both of which shall together
constitute one and the same instrument. This Agreement shall become effective when each party shall
have received a counterpart hereof signed by the other party. Until and unless each party has
received a counterpart hereof signed by the other party, this Agreement shall have no effect and
none of the parties shall have any right or obligation hereunder (whether by virtue of any other
oral or written agreement or other communication). Facsimiles, e-mail transmission of .pdf
signatures or other electronic copies of signatures shall be deemed to be original counterparts. No
provision of this Agreement is intended to confer any rights, benefits, remedies, obligations or
liabilities hereunder upon any Person other than the parties and their respective successors and
permitted assigns. 10. Cooperation; Further Assurances. Each of the parties shall execute such
further instruments and take such other actions as the other party shall reasonably request in order
to effectuate the purposes of this Agreement. 11. Interpretation. The words "hereof", "herein" and
"hereunder" and words of like import used in this Agreement shall refer to this Agreement as a whole
and not to any particular provision of this Agreement. The captions herein are included for
convenience of reference only and shall be ignored in the construction or interpretation hereof.
References to Sections are to Sections of this Agreement unless otherwise specified. Any singular
term in this Agreement shall be deemed to include the plural, and any plural term the singular.
Whenever the words "include", "includes" or "including" are used in this Agreement, they shall be
deemed to be followed by the words "without limitation", whether or not they are in fact followed by
those words or words of like import. "Writing", "written" and comparable terms refer to printing,
typing and other means of reproducing words (including electronic media) in a visible form.
References to any Person include the successors and permitted assigns of that Person. References
from or through any date mean, unless otherwise specified, from and including or through and
including, respectively.

7
<!-- page 8 -->
Any reference to "days" means calendar days unless Business Days are expressly specified. If any
action under this Agreement is required to be done or taken on a day that is not a Business Day,
then such action shall be required to be done or taken not on such day but on the first succeeding
Business Day thereafter. The headings in this Agreement are for reference only and shall not affect
the interpretation of this Agreement. [Signature page follows]

8
<!-- page 9 -->
IN WITNESS WHEREOF, each of the parties has duly executed this Agreement as of the Effective Date.
QUAKER CHEMICAL CORPORATION By: /s/ Robert T. Traub Name: Robert T. Traub Title: Vice President,
General Counsel and Corporate Secretary [Signature Page to Non-Competition and Non-Solicitation
Agreement]
<!-- page 10 -->
GULF HOUGHTON LUBRICANTS LTD. By: /s/ Sandra Georgeson Name: Sandra Georgeson Title: Director
[Signature Page to Non-Competition and Non-Solicitation Agreement]
<!-- page 11 -->
GULF OIL INTERNATIONAL, LTD. By: /s/ Benjamin Booker Name: Benjamin Booker Title: Director
[Signature Page to Non-Competition and Non-Solicitation Agreement]
<!-- page 12 -->
GOCL CORPORATION LIMITED By: /s/ Subhas Pramanik Name: Subhas Pramanik Title: Managing Director
[Signature Page to Non-Competition and Non-Solicitation Agreement]
<!-- page 13 -->
GULF OIL LUBRICANTS INDIA, LTD. By: /s/ Ravi Chawla Name: Ravi Chawla Title: Managing Director
[Signature Page to Non-Competition and Non-Solicitation Agreement]
