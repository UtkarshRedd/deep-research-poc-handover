<!-- page 1 -->
# ENDORSEMENT AGREEMENT
| Field | Value |
|---|---|
| Document Type | Endorsement Agreement |
| Agreement Date | 2005-01-13 |
| Parties | TOM WATSON ("CONSULTANT"); ADAMS GOLF, LTD. ("ADAMS GOLF") |
| Source | CUAD v1 / ADAMSGOLFINC_03_21_2005-EX-10.17-ENDORSEMENT AGREEMENT |

REDACTED COPY

CONFIDENTIAL TREATMENT REQUESTED

CONFIDENTIAL PORTIONS OF THIS

DOCUMENT HAVE BEEN REDACTED

AND HAVE BEEN SEPARATELY

FILED WITH THE COMMISSION

1

ENDORSEMENT AGREEMENT
<!-- page 2 -->
This Agreement is entered into on January 13, 2005 between professional golfer, TOM WATSON,
(hereinafter referred to as "CONSULTANT") and ADAMS GOLF, LTD. (hereinafter referred to as "ADAMS
GOLF").

WITNESSETH

WHEREAS, ADAMS GOLF desires to obtain the right to use the name, likeness and ENDORSEMENT of
CONSULTANT in connection with the advertisement and promotion of ADAMS GOLF'S PRODUCT;

NOW THEREFORE, in consideration of the mutual covenants contained herein and other good and valuable
consideration, the receipt and sufficiency of which is hereby acknowledged, the parties agree as
follows:

CONTRACT PERIOD

1. TERM OF CONTRACT

The Term of this Agreement shall be for a period of [* ****] years and [*****] months commencing the
1st day of September 2004 and terminating the [*****] day of [*****].

2. DEFINITIONS

As used in this Agreement, the following terms shall be defined as set forth below:

A. CONSULTANT'S "ENDORSEMENT" means the right to use the CONSULTANT'S name, fame, nickname,
autograph, voice, facsimile, signature, photograph, likeness, and image in connection with the
marketing, advertising, promotion and sale of ADAMS GOLF'S PRODUCT.

B."PRODUCT" shall mean all golf clubs including, but not limited to, metal woods, drivers, fairway
woods, irons, iron- woods, utility clubs, wedges, and putters, bags, and headwear. C."MANDATORY
PRODUCTS" shall mean the following ADAMS GOLF PRODUCTS that CONSULTANT must exclusively play/use in
all Champions/Senior Professional Golf Association (SPGA) and Professional Golf Association (PGA)
events at all times:

[***** ] Confidential Material redacted and filed separately with the Commission. 2
<!-- page 3 -->
1.[*****] 2.Sufficient [*****] to maintain total minimum of [*****] ADAMS GOLF [*****] (includes
[*****])[*****] at all times 3.[*****] 4.[*****] (CONSULTANT may continue to place the [*****] logo
on the [*****] consistent with historical practice.)

D. "CONTRACT TERRITORY" shall mean the entire world.

CONSULTANT'S OBLIGATIONS

3. CONSULTANT'S ENDORSEMENT

CONSULTANT hereby gives and grants to ADAMS GOLF the exclusive right and license to use CONSULTANT'S
ENDORSEMENT in connection with the manufacture, sale, distribution, advertising and promotion of
PRODUCT in the CONTRACT TERRITORY. 4. EXCLUSIVITY OF ENDORSEMENT During the term of this Agreement,
unless otherwise authorized at the sole discretion of ADAMS GOLF in writing, CONSULTANT shall not:
A.give the right to use or permit the use of CONSULTANT'S name, facsimile signature, nickname, voice
or likeness to any other manufacturer or seller of PRODUCT;

B.sponsor or endorse PRODUCT made or sold by any other manufacturer or seller; or

C.serve as a CONSULTANT or advisor of any other manufacturer or seller of PRODUCT.

D.Notwithstanding paragraphs 4A, 4B and 4C above, CONSULTANT shall be entitled to endorse and play
the [*****]. The parties expressly agree that CONSULTANT may permit [*****] the use of CONSULTANT'S
name and/or likeness in [*****] print and/or television advertisement provided that this is executed
in a manner consistent with [*****] past [*****] advertising practice using similarly situated
professional golfers with competing golf club endorsement agreements that include [*****]. If
[*****] use of CONSULTANT varies from past practice of utilizing similarly situated professionals,
CONSULTANT will take action to remedy the situation [*****]. If CONSULTANT participates directly in
any [*****] sponsored photo shoots for advertising or PR, CONSULTANT shall wear his ADAMS GOLF
[*****]. The parties further expressly agree that CONSULTANT'S endorsement of the [*****] shall not
include the right to place a [*****] logo on his ADAMS GOLF [*****] or the ADAMS GOLF [*****]. If
CONSULTANT'S relationship with [*****] terminates during this Agreement, CONSULTANT shall be
permitted to replace the [*****] endorsement with another [*****] endorsement under the same terms
and conditions expressed herein.

[***** ] Confidential Material redacted and filed separately with the Commission. 3
<!-- page 4 -->
E.Notwithstanding paragraphs 4A, 4B and 4C above, CONSULTANT shall not be required to wear ADAMS
GOLF [*****] in [*****] ads.

5. EXCLUSIVE USE OF PRODUCT

During the term of this Agreement, CONSULTANT shall exclusively play/use the MANDATORY PRODUCT. (It
is expressly understood by the parties that CONSULTANT may play [* ****] clubs in the bag other than
ADAMS GOLF clubs including, but not limited to, a putter by a manufacturer other than ADAMS GOLF but
may not endorse those clubs and/or putter.)

6. CONSULTANT'S ENDORSEMENT OF NON-COMPETITIVE PRODUCT

If CONSULTANT endorses or promotes a non-competitive product and in that endorsement or promotion
CONSULTANT wears, plays, uses, holds or is in any way associated with a product that would
constitute PRODUCT as defined under this Agreement, CONSULTANT shall use objectively reasonable best
efforts to ensure that PRODUCT is an ADAMS GOLF PRODUCT and it shall not be altered or changed in
appearance in the endorsement in any manner whatsoever without the express written consent of ADAMS
GOLF. When endorsing a non-competitive product, under no circumstances shall CONSULTANT wear, play,
use, hold or in any way be associated with an ADAMS GOLF competitor's Product.

7. CONSULTANT'S SATISFACTION OF MANDATORY PRODUCT

It is particularly and expressly understood and agreed that if CONSULTANT shall find in his sincere
best reasonable judgment that the MANDATORY PRODUCT so supplied is not suitable for his use in
tournament competition, then he shall promptly notify ADAMS GOLF in writing of such fact and the
reasons therefor. Thereafter, ADAMS GOLF shall have a period of thirty (30) days to either, at ADAMS
GOLF'S sole discretion, supply CONSULTANT with MANDATORY PRODUCT that is acceptable to him or
terminate the agreement. It is agreed that if the contract is terminated pursuant to this paragraph,
the compensation due CONSULTANT shall be prorated from the date this Agreement is terminated.
Proration of compensation shall be determined on the same repayment schedule as provide in paragraph
8A below.

[***** ] Confidential Material redacted and filed separately with the Commission. 4
<!-- page 5 -->
8. MINIMUM NUMBER OF TOURNAMENTS AND POTENTIAL REPAYMENT OF BASE COMPENSATION

A. In each and every calendar year of this Agreement, CONSULTANT shall achieve a satisfactory record
of play in a minimum of [* ****] professional golf association events on the SPGA and/or PGA tour
(which shall include both the PGA and SPGA Tour Skins Games). If for any reason, CONSULTANT should
achieve a satisfactory record of play in less than [*****] SPGA and/or PGA tour events in a calendar
year, he shall repay ADAMS GOLF an amount per event for each event under [*****] achieved in the
given calendar year as follows:

The agreed upon repayment amount per event per calendar year:

1. Year 1. $[*****] 2. Year 2 $[*****] 3. Year 3 $[*****] 4. Year 4 $[*****] 5. Year 5 $[*****]

B.Payment shall be made to ADAMS GOLF within one month following the end of the calendar year. For
example, if in the calendar year 2005 CONSULTANT achieves a satisfactory record of play in [*****]
events, he shall repay ADAMS GOLF [*****] dollars no later than January 31, 2006.

C.In the event that CONSULTANT is prevented from competing for reasons outside his control, the
parties agree to a good faith attempt to resolve the issues. If a resolution can not be reached,
ADAMS GOLF may, at its sole discretion, demand prorated repayment pursuant to the repayment schedule
in paragraph 8A above.

9. PRODUCT DESIGN During the term of this Agreement, CONSULTANT shall use best efforts to cooperate
with ADAMS GOLF in giving advice, suggestions and recommendations concerning the acceptability and
playability of current ADAMS GOLF lines, the development of new ADAMS GOLF lines, and information
about significant golf PRODUCT and golf market trends, and meet as reasonably requested with ADAMS
GOLF'S Design/Testing Teams. 10. PROMOTION OF PRODUCT

During the term of this Agreement, CONSULTANT shall use best efforts to wear the headwear and
display ADAMS GOLF'S brand name and to demonstrate, discuss and emphasize the newest features of
ADAMS GOLF PRODUCT at every opportunity including but not limited to all Senior PGA tour events and
promotional and advertising events in which CONSULTANT takes part.

[***** ] Confidential Material redacted and filed separately with the Commission. 5

11. PROMOTIONAL APPEARANCES
<!-- page 6 -->
A.During the term of this Agreement, CONSULTANT shall use best efforts to be available for such
press interviews, radio or TV appearances arranged for CONSULTANT by ADAMS GOLF which are compatible
with CONSULTANT'S own practice, play and personal time requirements. CONSULTANT will be required to
be available after a tournament for selected interviews, either the Sunday afternoon or Monday
morning following the tournament. In all such interviews and appearances, CONSULTANT will use his
best efforts to make reference to the ADAMS GOLF PRODUCT and wear [*****] and display ADAMS GOLF'S
brand name.

B.During the term of this Agreement, CONSULTANT shall make himself available on not more than
[*****] days for television and radio commercials, photo shoots, modeling and promotional
appearances compatible with CONSULTANT'S own practice, play and personal time requirements. Said
activities shall be directly related to the promotion of ADAMS GOLF PRODUCT. ADAMS GOLF shall
reimburse CONSULTANT for reasonable travel expenses for CONSULTANT when making special appearances
for ADAMS GOLF pursuant to this paragraph but ADAMS GOLF shall not pay CONSULTANT session fees,
residual payments or the like for television appearances. Travel expenses shall include jet fuel or
first-class round-trip airfare and lodging, meals and local transportation.

12. BEHAVIOR

During the term of this Agreement, CONSULTANT will conduct himself at all times with due regard to
public morals and conventions. If the value of CONSULTANT'S ENDORSEMENT is materially reduced or
impaired because CONSULTANT:

A.committed or shall commit any public act that involves moral turpitude, B.commits or violates any
material foreign, U.S., federal, or other applicable state or local law, C.commits any act which
brings him into public disrepute, contempt, scandal or ridicule, or which insults or offends the
community, D.makes any statements in derogation, in any material respect, of ADAMS GOLF or any of
its affiliates or any of their respective PRODUCT or services and such statement is made to the
general public or becomes a matter of public knowledge,

then at any time after the occurrence of such act, thing or statement, ADAMS GOLF shall have the
right, in addition to its other legal and equitable remedies, to immediately terminate this
Agreement, by giving written notice to CONSULTANT. ADAMS GOLF must exercise its right of termination
within ninety (90) days of its senior management becoming aware of the conduct giving rise to the
right of termination.

[***** ] Confidential Material redacted and filed separately with the Commission. 6
<!-- page 7 -->
13. FREEDOM TO CONTRACT

CONSULTANT represents and warrants that CONSULTANT is free of all prior undertakings and obligations
which would prevent or tend to impair either the full performance of CONSULTANT'S obligations
hereunder or ADAMS GOLF'S full enjoyment of the rights and privileges granted to it by CONSULTANT.

14. INDEMNITY

CONSULTANT agrees to protect, indemnify and hold ADAMS GOLF harmless from any and all liability,
claims, causes of action, suits, damages and expenses (including reasonable attorneys' fees and
expenses) for which it becomes liable or is compelled to pay by reason of a breach of any covenant
or representation by CONSULTANT in this Agreement.

15. ABSENCE OF AGENCY

CONSULTANT shall not and will not have the right or authority to bind ADAMS GOLF by any
representation or in any other respect whatsoever or to incur any obligation or liability in the
name of or on behalf of ADAMS GOLF.

16. MEMBERSHIPS

CONSULTANT warrants and represents that during the term of this Agreement he is a member in good
standing of SAG, AFTRA or any other organization having jurisdiction over CONSULTANT'S services
hereunder. This Agreement is subject to all of the terms and conditions of the collective bargaining
agreements with SAG, AFTRA, or any other union agreements or codes having jurisdiction over
CONSULTANT'S services hereunder. Any and all payments required to be made to SAG or AFTRA or any
other organization having jurisdiction over CONSULTANT'S services hereunder, shall be the sole
responsibility of CONSULTANT.

ADAMS GOLF'S OBLIGATIONS

17. SUPPLY OF PRODUCT

A. During the term of this Agreement, ADAMS GOLF shall provide CONSULTANT with sufficient quantities
of such MANDATORY PRODUCTS for CONSULTANT'S use as CONSULTANT may reasonably need to fulfill his
obligations under this agreement. ADAMS GOLF shall pay all charges in connection with the delivery
of MANDATORY PRODUCTS to CONSULTANT.

B.In addition to paragraph 17A above, ADAMS GOLF shall provide CONSULTANT with [*****] sets of clubs
for CONSULTANT'S family and friends each calendar year of this Agreement.

[***** ] Confidential Material redacted and filed separately with the Commission. 7
<!-- page 8 -->
18. BASE COMPENSATION

For the entire term of this Agreement, from September 1, 2004 through [*****] ADAMS GOLF shall pay
CONSULTANT a base compensation of [*****] dollars. The base compensation shall be paid [*****].

19. PERFORMANCE BONUSES AND TOTAL COMPENSATION LIMITATION

A. In addition to his base compensation, CONSULTANT shall also be entitled to bonuses based on
performance in particular PGA and SPGA events and year-end standing as follows:

1. If CONSULTANT wins a PGA Tour Major (consisting of the Masters, US Open, PGA and British Open) or
the Champion's Tour (SPGA) US Open, CONSULTANT shall receive a bonus of $ [*****].

2. If CONSULTANT wins a Champions/Seniors Tour (SPGA) major other than the US Open (which shall for
the purposes of this agreement consist of the Senior PGA, Senior British, the Tradition and the Ford
Seniors) CONSULTANT shall receive a bonus of $ [*****].

3. If CONSULTANT finishes in the top [*****] on the official year end money list of the Champion's
Tour (SPGA), CONSULTANT shall also be entitled to a year end performance bonus according to the
following schedule:

a.2005 $ [*****] b.2006$ [*****] c.2007$ [*****] d.2008$ [*****] e.2009$ [*****]

B.Notwithstanding paragraph A and its subparts above, the maximum total annual bonuses shall in no
case exceed the following schedule:

1.2005 $ [*****] 2.2006$ [*****] 3.2007$ [*****] 4.2008$ [*****] 5.2009$ [*****]

(For example, if in the calendar year [*****]CONSULTANT wins every PGA tour major and finishes in
the top [*****] on the official year end money list of the Champion's Tour (SPGA), CONSULTANT'S
total bonuses shall be [*****] dollars.

[***** ] Confidential Material redacted and filed separately with the Commission. 8
<!-- page 9 -->
C. In the event of ADAMS GOLF'S insolvency or bankruptcy, it is expressly agreed to by the parties
that CONSULTANT shall not be obligated to repay any money so long as CONSULTANT continues to fully
perform his obligations under this Agreement. 20. APPROVAL OF ADVERTISING

Prior to publishing or placing any advertising or promotional material which uses CONSULTANT'S name,
facsimile signature, nickname, voice or likeness, ADAMS GOLF shall submit the same to CONSULTANT, or
CONSULTANT'S designee, for approval, which approval shall not be unreasonably withheld or delayed.
If CONSULTANT disapproves, the reasons therefore shall be given to ADAMS GOLF in writing within
three (3) business days or shall be deemed approved. ADAMS GOLF agrees to protect, indemnify and
hold CONSULTANT harmless from and against any and all expenses, damages, claims, suits, actions,
judgments and costs whatsoever, arising out of, or in any way connected with, any advertising
material furnished by, or on behalf of, the company.

21. INDEMNITY

ADAMS GOLF agrees to defend, indemnify and hold harmless CONSULTANT from any and all liability,
claims, causes of action, suits, damages and expenses (including reasonable attorneys' fees and
expenses) for which he becomes liable or is compelled to pay by reason of or arising out of any
claim or action for personal injury, death or otherwise involving alleged defects in ADAMS GOLF'S
PRODUCT, provided that ADAMS GOLF is promptly given notice in writing and is given complete
authority and information required for the defense, and ADAMS GOLF shall pay all damages or costs
awarded therein against CONSULTANT and any other cost incurred by CONSULTANT in defense of any suit,
but shall not be responsible for any cost, expense or compromise incurred or made by CONSULTANT
without ADAMS GOLF'S prior written consent.

TERMINATION

22. FAILURE TO PLAY

Notwithstanding any other paragraph of this Agreement, in the event that CONSULTANT dies or is
unable to play tour golf at all, ADAMS GOLF may terminate this Agreement on thirty (30) days'
written notice. Upon such termination, CONSULTANT and/or CONSULTANT'S estate shall be required to
repay ADAMS GOLF for that period of the Agreement not performed by CONSULTANT. The repayment amount
shall be calculated in the same way as repayment is calculated under paragraph 8A. 9
<!-- page 10 -->
23. TERMINATION FOR CAUSE

Notwithstanding any other paragraph of this Agreement, if either party commits any material breach
of this Agreement, the other party may terminate for cause upon giving fifteen (15) days written
notice of such cause and provided the breach is not rectified within such fifteen (15) day period.
Upon such termination, CONSULTANT shall be required to repay ADAMS GOLF for that period of the
Agreement not performed by CONSULTANT. The repayment amount shall be calculated in the same way as
repayment is calculated under paragraph 8A.

24. ADAMS GOLF'S RIGHTS UPON TERMINATION

A.In the event of termination of this Agreement, ADAMS GOLF shall cease using the name and/or
likeness of CONSULTANT in advertising within [*****] days.

B.In the event of termination of this Agreement, ADAMS GOLF shall cease using the name and/or
likeness of CONSULTANT on Product within [*****] months after termination of this Agreement.

MISCELLANEOUS PROVISIONS

24. SIGNIFICANCE OF HEADINGS

Section headings contained herein are solely for the purpose of aiding in speedy location of subject
matter and are not in any sense to be given weight in the construction of this Agreement.
Accordingly, in case of any question with respect to the construction of this Agreement, it is to be
construed as though such section headings had been omitted.

25. APPLICABLE LAW

This Agreement shall be governed and construed according to the laws of the State of Kansas.

26. ENTIRE AGREEMENT

The provisions of this Agreement are intended by the parties as a complete, conclusive and final
expression of their agreement concerning the subject matter hereof, which Agreement supersedes all
prior agreements concerning the subject matter, and no other statement, representation, agreement or
understanding, oral or written, made prior to or at the execution hereof, shall vary or modify the
written terms hereof. No amendments, modifications or releases from any provision hereof shall be
effective unless in writing and signed by both parties.

27. WAIVER

Unless otherwise mutually agreed in writing, no departure from, waiver of, or omission to require
compliance with any of the terms hereof by either party shall be deemed to authorize any prior or
subsequent departure or waiver, or obligate either party to continue any departure or waiver.

[***** ] Confidential Material redacted and filed separately with the Commission. 10
<!-- page 11 -->
28. EXECUTION AND DELIVERY REQUIRED

This instrument shall not be considered to be an agreement or contract nor shall it create any
obligation whatsoever on the part of CONSULTANT or ADAMS GOLF unless and until it has been signed by
CONSULTANT, or a duly authorized representative, and by duly authorized representatives of ADAMS
GOLF and delivery has been made of a fully signed original to both parties.

29. SEVERABILITY

Any provision or part of this Agreement prohibited by applicable law shall be ineffective to the
extent of such prohibition without invalidating the remaining provisions or parts hereof.

30. RELATIONSHIP

Both parties agree that this Agreement does not constitute and shall not be construed as a
constituting of a partnership or joint venture between ADAMS GOLF and CONSULTANT. Neither party
shall have any right to obligate or bind the other party in any manner whatsoever, and nothing
herein contained shall give or is intended to give any rights of any kind to any third person.

31. ASSIGNMENT AND CHANGE OF CONTROL

Neither ADAMS GOLF nor CONSULTANT shall have the right to grant sublicenses hereunder or to assign,
alienate or otherwise transfer any of its rights or obligations hereunder.

32. CONFIDENTIALITY

Both parties understand that the contents of this Agreement, including, but not limited to, all
amounts paid or to be paid and any additional consideration, are extremely confidential, and that
disclosure of same to any third party could be detrimental to the interests of one or both parties.
Therefore, both parties agree not to disclose the terms of this Agreement, without the permission of
the other party, to any third party other than to CONSULTANT'S business, legal and financial
advisors, and with respect to all such advisors, CONSULTANT shall take all reasonable steps to
ensure such confidentiality to ADAMS GOLF. Furthermore, CONSULTANT recognizes that during the course
of performing his duties hereunder he may become aware of proprietary, confidential information
concerning ADAMS GOLF, its PRODUCT, methods, processes, billing practices, financial condition,
etc., or information ADAMS GOLF designates as confidential (collectively "Confidential
Information"). CONSULTANT agrees that he will maintain in confidence and not disclose to any third
party at any time any such Confidential Information and shall not use any such information to the
detriment of ADAMS GOLF or for any purpose not contemplated by the Agreement. 11
<!-- page 12 -->
33. ARBITRATION

In the event a dispute arises under this Agreement which cannot be resolved, such dispute shall be
submitted to arbitration and resolved by a panel of three arbitrators (who shall be lawyers), in a
decision required by a majority of the arbitrators. If the parties cannot agree upon the panel of
three arbitrators, then each party may pick an arbitrator and the two chosen arbitrators shall
choose upon the three-arbitrator panel. The arbitration shall be conducted in accordance with the
Arbitration Rules of the American Arbitration Association. Venue shall be Kansas. The award or
decision rendered by the arbitration panel shall be final, binding and conclusive and judgment may
be entered upon such award by any court of competent jurisdiction.

34. NOTICE

Every written notice or written report which may be served upon CONSULTANT, according to the terms
of this Agreement, may be served by enclosing it in a postpaid envelope addressed to:

Mr. Tom Watson C/O Assured Management Company 1901 W. 47th Place, Suite 200 Westwood, Kansas 66205

or at such other address as is given in writing to ADAMS GOLF by CONSULTANT.

Every written notice which may be served upon ADAMS GOLF, according to the terms of this Agreement,
shall be served by enclosing it in a postpaid envelope addressed to:

Attention Legal Department ADAMS GOLF, LTD. 2801 East Plano Parkway Plano, Texas 75074

or at such other address as is given in writing by ADAMS GOLF to CONSULTANT.

12
<!-- page 13 -->
IN WITNESS WHEREOF, the parties hereto have caused this Agreement to be executed as of the date
first set forth above.

APPROVED FOR CONSULTANT By: /s/ Tom Watson Date: January 13, 2005

Tom Watson

APPROVED FOR ADAMS GOLF, LTD. By: /s/ Oliver G. "Chip" Brewer III Date: January 13, 2005

Oliver G. ("Chip") Brewer III

CEO, ADAMS GOLF

13
