<!-- page 1 -->
# WEB HOSTING AGREEMENT
| Field | Value |
|---|---|
| Document Type | Hosting Agreement |
| Agreement Date | 1997-09-09 |
| Parties | Galacticomm; Horst Entertainment Inc |
| Source | CUAD v1 / GALACTICOMMTECHNOLOGIESINC_11_07_1997-EX-10.46-WEB HOSTING AGREEMENT |

EXHIBIT 10.46

WEB HOSTING AGREEMENT

This agreement shall void and nullify any and all previous agreements to this date between
Galacticomm and Horst Entertainment Inc.

There shall be no additional fees of any kind paid to Galaticomm, other than those stated within
this agreement for software usage and/or bandwidth usage.

Horst Entertainment agrees to pay Galactcomm $0.01 (one cent) per access up to 400,000 accesses
thereafter payment shall be $0.005 (one-half cent) per access. Horst Entertainment shall send this
amount to Galacticomm by no later than Wednesday for accesses used from the previuos week (Monday
thru Sunday).

Galacticomm must provide a person(s) to correct any technical problems (Server being down or
inaccessible) 24 hours per day, 7 days per week. This person(s) must be available by beeper or
telephone. Horst Entertainment shall provide this same 24 hour service at the broadcast location.

In the event Galacticomm, Inc. chooses to terminate this agreement, Horst Entertainment Inc. will
have the right to purchase a license copy of the software in the amount of $15,000.00.

All parties have read and fully agree to all terms and conditions as set forth in this Web Hosting
Agreement. Any disputes arising herein shall be settled in a court in FLorida.

/s/ Yannick Tessier 9/9/97 - ----------------------- ------ Galacticomm Date

[ILLEGIBLE] HORST 9/9/97 - ------------------------- ------ Horst Entertainment Inc. Date
