"""Golden set v1 generator: synthetic financial-legal corpus + questions, correct by construction.

    .venv/Scripts/python.exe scripts/make_golden_corpus.py            # writes data/golden_docs, data/golden/questions.jsonl
    .venv/Scripts/python.exe scripts/make_golden_corpus.py --check    # regenerate into memory, compare with disk

Design
------
Every document is built page by page through `Doc`, which records on which page each tagged
line lands. Questions cite documents by file stem (`<stem>` placeholder, resolved to a real
doc_id by `dr.eval.golden.resolve_gold_docs`) and by the page numbers recorded for the tags
they depend on. Documents and questions are derived from the same `Facility` parameters, so a
gold answer is literally a span on the cited page; `_self_check` asserts this before anything
is written, and `tests/test_golden.py` re-asserts it through `dr.ingest.load.load_dir`.

The corpus is fully deterministic: the only randomness is `random.Random(SEED)` and it is used
for cosmetic filler (street numbers, boilerplate order), never for anything a question depends on.
See data/golden/README.md for the corpus design and the traps.
"""
from __future__ import annotations

import argparse
import json
import random
import sys
from dataclasses import dataclass, field
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DOCS_DIR = ROOT / "data" / "golden_docs"
QUESTIONS = ROOT / "data" / "golden" / "questions.jsonl"
SEED = 20251101

# --------------------------------------------------------------------------- page-tracking builder


class Doc:
    """Builds one markdown document page by page and remembers where tagged lines land."""

    def __init__(self, stem: str, title: str, meta: dict[str, str], meta_style: str = "table") -> None:
        self.stem = stem
        self.title = title
        self.pages: list[list[str]] = [[]]
        self.tags: dict[str, int] = {}
        self.line(f"# {title}")
        if meta_style == "table":
            self.line("| Field | Value |")
            self.line("|---|---|")
            for k, v in meta.items():
                self.line(f"| {k} | {v} |")
        else:
            for k, v in meta.items():
                self.line(f"{k}: {v}")
        self.line("")

    # -- building
    def page(self) -> None:
        if self.pages[-1]:
            self.pages.append([])

    def line(self, text: str = "", tag: str | None = None) -> None:
        self.pages[-1].append(text)
        if tag:
            if tag in self.tags:
                raise ValueError(f"{self.stem}: duplicate tag {tag}")
            self.tags[tag] = len(self.pages)

    def lines(self, *texts: str) -> None:
        for t in texts:
            self.line(t)

    def heading(self, text: str, tag: str | None = None) -> None:
        self.line(f"## {text}", tag)

    # -- lookup
    def page_of(self, tag: str) -> int:
        return self.tags[tag]

    def page_text(self, n: int) -> str:
        return "\n".join(self.pages[n - 1])

    @property
    def n_pages(self) -> int:
        return len(self.pages)

    def render(self) -> str:
        out: list[str] = []
        for i, lines in enumerate(self.pages, 1):
            out.append(f"<!-- page {i} -->")
            out.extend(lines)
        return "\n".join(out).rstrip() + "\n"


# --------------------------------------------------------------------------- parameters


@dataclass
class Amendment:
    number: int                   # 1 = First, 2 = Second
    date: str
    changes: dict[str, tuple[str, str]]  # field -> (old, new)
    recitals: str = ""


@dataclass
class Facility:
    key: str                      # file-stem prefix, e.g. "halvorsen"
    borrower: str
    short: str                    # short borrower name used in titles
    agent: str                    # administrative agent / lender
    jurisdiction: str             # borrower's organisation
    facility_id: str
    date: str                     # closing / effective date
    facility_type: str            # "Revolving Credit Facility" | "Term Loan Facility"
    commitment: str               # "$150,000,000"
    commitment_words: str
    margin: str                   # "2.75%"
    leverage: str                 # "4.00 to 1.00"
    coverage: str                 # interest coverage, "3.00 to 1.00"
    maturity: str
    governing_law: str
    address: str                  # borrower notice address
    agent_address: str
    guarantors: list[str] = field(default_factory=list)
    collateral_location: str = ""
    amendments: list[Amendment] = field(default_factory=list)
    docs: list[str] = field(default_factory=list)   # which ancillary docs to generate
    fee_upfront: str = ""
    fee_agency: str = ""
    fee_commitment: str = ""
    fee_ref: str = ""
    fee_account: str = ""
    extra: dict[str, str] = field(default_factory=dict)

    @property
    def ca_title(self) -> str:
        return f"Credit Agreement — {self.short}"

    def current(self, fld: str, as_of: str) -> str:
        """Value of a term as of a date, walking the amendments (ISO dates compare lexically)."""
        val = getattr(self, fld)
        for a in sorted(self.amendments, key=lambda a: a.date):
            if a.date <= as_of and fld in a.changes:
                val = a.changes[fld][1]
        return val


ORD = {1: "First", 2: "Second", 3: "Third"}
FIELD_LABEL = {
    "leverage": "Leverage Ratio", "margin": "Applicable Margin", "commitment": "Aggregate Commitment",
    "maturity": "Maturity Date", "coverage": "Interest Coverage Ratio",
}
FIELD_SECTION = {"leverage": "7.1", "coverage": "7.2", "margin": "1.1", "commitment": "2.1", "maturity": "1.1"}


def facilities() -> list[Facility]:
    return [
        Facility(
            key="halvorsen", borrower="Halvorsen Marine Holdings, Inc.", short="Halvorsen Marine Holdings",
            agent="Meridian Trust Bank, N.A.", jurisdiction="Delaware", facility_id="FAC-2025-0042",
            date="2025-02-14", facility_type="Revolving Credit Facility",
            commitment="$150,000,000", commitment_words="one hundred fifty million dollars",
            margin="2.75%", leverage="4.00 to 1.00", coverage="3.00 to 1.00", maturity="2030-02-14",
            governing_law="New York",
            address="1200 Harbor Way, Suite 400, Seattle, Washington 98101",
            agent_address="One Meridian Plaza, 18th Floor, New York, New York 10005",
            guarantors=["Halvorsen Shipyards LLC", "Cascade Vessel Services, Inc.", "Puget Marine Leasing LLC"],
            collateral_location="Tacoma, Washington",
            amendments=[
                Amendment(1, "2025-07-31", {"leverage": ("4.00 to 1.00", "4.50 to 1.00"), "margin": ("2.75%", "3.00%")},
                          recitals="the Borrower has requested, and the Lenders have agreed, to relax the maximum Leverage Ratio and to reprice the Loans"),
                Amendment(2, "2026-01-20", {"commitment": ("$150,000,000", "$175,000,000"), "maturity": ("2030-02-14", "2031-02-14")},
                          recitals="the Borrower has requested an increase in the Aggregate Commitment and an extension of the Maturity Date"),
            ],
            docs=["conformed", "guarantee", "security", "fee", "waiver", "side"],
            fee_upfront="0.75%", fee_agency="$75,000", fee_commitment="0.375%",
            fee_ref="MTB-2025-FEE-0042", fee_account="Account No. 4471-882901",
            extra={"waiver_quarter": "2025-09-30", "waiver_date": "2025-11-07", "waiver_ratio": "4.68 to 1.00",
                   "waiver_fee": "$125,000", "side_date": "2025-02-14",
                   "side_topic": "Permitted Vessel Dispositions", "side_amount": "$20,000,000"},
        ),
        Facility(
            key="corvallis", borrower="Corvallis Foods Group LLC", short="Corvallis Foods Group",
            agent="Pacific Commerce Bank", jurisdiction="Oregon", facility_id="FAC-2025-0108",
            date="2025-04-01", facility_type="Term Loan Facility",
            commitment="$80,000,000", commitment_words="eighty million dollars",
            margin="3.25%", leverage="3.25 to 1.00", coverage="2.75 to 1.00", maturity="2030-04-01",
            governing_law="California",
            address="455 Willamette Avenue, Corvallis, Oregon 97330",
            agent_address="600 Montgomery Street, 30th Floor, San Francisco, California 94111",
            guarantors=["Corvallis Cold Storage LLC", "Willamette Valley Produce, Inc."],
            collateral_location="Albany, Oregon",
            amendments=[
                Amendment(1, "2025-11-15", {"leverage": ("3.25 to 1.00", "3.75 to 1.00"), "margin": ("3.25%", "3.50%")},
                          recitals="the Borrower has requested covenant relief in connection with the acquisition of Willamette Valley Produce, Inc."),
            ],
            docs=["guarantee", "security", "fee", "consent"],
            fee_upfront="0.50%", fee_agency="$50,000", fee_commitment="",
            fee_ref="PCB-2025-FEE-0108", fee_account="Account No. 7730-114562",
            extra={"consent_date": "2025-09-03", "consent_asset": "the Eugene distribution center",
                   "consent_amount": "$12,500,000"},
        ),
        Facility(
            key="brightwater", borrower="Brightwater Renewables plc", short="Brightwater Renewables",
            agent="Meridian Trust Bank, N.A.", jurisdiction="England and Wales", facility_id="FAC-2024-0311",
            date="2024-09-30", facility_type="Revolving Credit Facility",
            commitment="$200,000,000", commitment_words="two hundred million dollars",
            margin="2.25%", leverage="3.50 to 1.00", coverage="2.50 to 1.00", maturity="2029-09-30",
            governing_law="New York",
            address="40 Cannon Street, London EC4N 6JJ, United Kingdom",
            agent_address="One Meridian Plaza, 18th Floor, New York, New York 10005",
            guarantors=["Brightwater Wind Holdings Limited", "Brightwater Solar Assets Limited"],
            amendments=[
                Amendment(1, "2025-05-12", {"coverage": ("2.50 to 1.00", "2.25 to 1.00")},
                          recitals="the Borrower has requested a reduction of the minimum Interest Coverage Ratio following the commissioning delay at the Firth Array"),
            ],
            docs=["conformed", "guarantee", "fee"],
            fee_upfront="0.60%", fee_agency="$90,000", fee_commitment="0.30%",
            fee_ref="MTB-2024-FEE-0311", fee_account="Account No. 4471-903377",
        ),
        Facility(
            key="tolland", borrower="Tolland Precision Components Corp.", short="Tolland Precision Components",
            agent="Northgate Capital Bank", jurisdiction="Connecticut", facility_id="FAC-2025-0193",
            date="2025-06-18", facility_type="Revolving Credit Facility",
            commitment="$45,000,000", commitment_words="forty-five million dollars",
            margin="4.00%", leverage="3.00 to 1.00", coverage="2.00 to 1.00", maturity="2028-06-18",
            governing_law="New York",
            address="2200 Industrial Parkway, Hartford, Connecticut 06103",
            agent_address="500 Boylston Street, Boston, Massachusetts 02116",
            collateral_location="Hartford, Connecticut",
            docs=["security", "waiver", "side"],
            extra={"waiver_quarter": "2025-12-31", "waiver_date": "2026-02-10", "waiver_ratio": "3.21 to 1.00",
                   "waiver_fee": "$40,000", "side_date": "2025-06-18",
                   "side_topic": "Reporting Accommodation", "side_amount": "$2,000,000"},
        ),
        Facility(
            key="keswick", borrower="Keswick Logistics Partners LP", short="Keswick Logistics Partners",
            agent="Pacific Commerce Bank", jurisdiction="Delaware", facility_id="FAC-2026-0007",
            date="2026-01-09", facility_type="Term Loan Facility",
            commitment="$120,000,000", commitment_words="one hundred twenty million dollars",
            margin="2.50%", leverage="3.75 to 1.00", coverage="2.50 to 1.00", maturity="2031-01-09",
            governing_law="Delaware",
            address="8800 Freight Circle, Memphis, Tennessee 38118",
            agent_address="600 Montgomery Street, 30th Floor, San Francisco, California 94111",
            guarantors=["Keswick Terminals LLC", "Keswick Fleet Holdings LLC", "Riverbend Intermodal LLC"],
            docs=["guarantee", "fee"],
            fee_upfront="0.40%", fee_agency="$60,000", fee_commitment="",
            fee_ref="PCB-2026-FEE-0007", fee_account="Account No. 7730-220815",
        ),
    ]


# --------------------------------------------------------------------------- document writers


def _ca_body(d: Doc, f: Facility, rng: random.Random, conformed: bool) -> None:
    """Pages 1-12 of a credit agreement. Tags are prefixed `ca.`; shared by the conformed copy."""
    note = "conformed" if conformed else ""
    d.line(f"THIS CREDIT AGREEMENT (this \"Agreement\") is entered into as of {f.date} (the \"Effective Date\"), "
           f"among {f.borrower}, a {f.jurisdiction} entity (the \"Borrower\"), the Lenders party hereto, and "
           f"{f.agent}, as administrative agent for the Lenders (in such capacity, the \"Administrative Agent\").", "ca.preamble")
    if conformed:
        d.line("")
        d.line("Conformed copy prepared by counsel to the Administrative Agent for convenience of reference only. "
               "This copy reproduces the executed Credit Agreement as of the Effective Date and does not reflect "
               "any subsequent amendment, waiver or consent. In the event of any conflict, the executed original controls.",
               "ca.conformed_note")
    d.line("")
    d.line("## Recitals")
    d.line(f"WHEREAS, the Borrower has requested that the Lenders make available a {f.facility_type.lower()} in an "
           f"aggregate principal amount of {f.commitment} ({f.commitment_words}) for working capital and general corporate purposes;")
    d.line("WHEREAS, the Lenders are willing to do so on the terms and subject to the conditions set forth herein;")
    d.line("NOW, THEREFORE, the parties agree as follows.")

    d.page()  # ---- p2 definitions
    d.heading("Article I — Definitions")
    d.line("Section 1.1 Defined Terms. As used in this Agreement, the following terms have the meanings set forth below.")
    d.line("\"Administrative Agent\" has the meaning assigned in the preamble.")
    d.line(f"\"Aggregate Commitment\" means the aggregate of the Commitments of all Lenders, which on the Effective Date is {f.commitment}.", "ca.def_commitment")
    d.line(f"\"Applicable Margin\" means, for any day, {f.margin} per annum for Term SOFR Loans and, for Base Rate Loans, "
           f"the Applicable Margin for Term SOFR Loans minus 1.00% per annum.", "ca.margin")
    d.line("\"Base Rate\" means, for any day, the greatest of (a) the Prime Rate, (b) the Federal Funds Effective Rate plus 0.50% and (c) Adjusted Term SOFR for a one-month tenor plus 1.00%.")
    d.line("\"Business Day\" means any day other than a Saturday, Sunday or other day on which commercial banks in New York City are authorized or required by law to close.")
    d.line("\"Change of Control\" means the acquisition by any person or group of beneficial ownership of more than 35% of the voting equity interests of the Borrower.")
    d.line("\"Consolidated EBITDA\" means, for any period, Consolidated Net Income for such period plus, without duplication, interest expense, taxes, depreciation and amortization, each to the extent deducted in determining Consolidated Net Income.")
    d.line("\"Consolidated Total Debt\" means, as of any date, the aggregate principal amount of Indebtedness of the Borrower and its Subsidiaries on a consolidated basis.")

    d.page()  # ---- p3 definitions continued
    d.line("Section 1.1 Defined Terms (continued).")
    d.line(f"\"Facility\" means the {f.facility_type.lower()} established hereunder, identified in the Administrative Agent's records as {f.facility_id}.", "ca.facility_id_def")
    d.line("\"Guarantors\" means each Subsidiary party to the Guarantee and each other person that becomes a Guarantor pursuant to Section 6.9.")
    d.line("\"Interest Coverage Ratio\" means, for any period of four consecutive fiscal quarters, the ratio of Consolidated EBITDA to Consolidated Interest Expense for such period.")
    d.line("\"Leverage Ratio\" means, as of the last day of any fiscal quarter, the ratio of Consolidated Total Debt as of such day to Consolidated EBITDA for the period of four consecutive fiscal quarters then ended.")
    d.line("\"Loan Documents\" means this Agreement, the Notes, the Guarantee, the Security Agreement, the Fee Letter and each other agreement designated as a Loan Document by the Borrower and the Administrative Agent.")
    d.line(f"\"Maturity Date\" means {f.maturity}, or, if such day is not a Business Day, the immediately preceding Business Day.", "ca.maturity")
    d.line("\"Material Adverse Effect\" means a material adverse effect on the business, assets, operations or financial condition of the Borrower and its Subsidiaries, taken as a whole.")
    d.line("\"Term SOFR\" means the forward-looking term rate based on SOFR published by the CME Term SOFR Administrator for the applicable interest period.")
    d.line("Section 1.2 Interpretation. Section and Article references are to this Agreement unless otherwise specified. The word \"including\" is not limiting.")

    d.page()  # ---- p4 commitments
    d.heading("Article II — The Commitments and Loans")
    kind = "Revolving Loans" if "Revolving" in f.facility_type else "Term Loans"
    d.line(f"Section 2.1 Commitments. Subject to the terms and conditions set forth herein, each Lender severally agrees to make {kind} to the Borrower "
           f"in an aggregate principal amount not exceeding its Commitment. The Aggregate Commitment on the Effective Date is {f.commitment}.", "ca.commitment")
    if "Revolving" in f.facility_type:
        d.line("Section 2.2 Borrowing Procedure. The Borrower shall deliver a Borrowing Request to the Administrative Agent not later than 11:00 a.m. New York City time three (3) Business Days before the date of a proposed Term SOFR borrowing and one (1) Business Day before a Base Rate borrowing.", "ca.borrowing_notice")
        d.line("Section 2.3 Revolving Nature. Within the limits of the Commitments, the Borrower may borrow, prepay and reborrow prior to the Maturity Date.")
    else:
        d.line("Section 2.2 Single Draw. The Term Loans shall be made in a single borrowing on the Effective Date. Amounts repaid or prepaid may not be reborrowed.", "ca.borrowing_notice")
        d.line("Section 2.3 Amortization. The Borrower shall repay the Term Loans in consecutive quarterly installments equal to 1.25% of the original principal amount, commencing on the last Business Day of the first full fiscal quarter after the Effective Date, with the balance due on the Maturity Date.", "ca.amortization")
    d.line("Section 2.4 Repayment. The Borrower unconditionally promises to pay the outstanding principal amount of the Loans on the Maturity Date.")
    d.line("Section 2.5 Evidence of Debt. Each Lender shall maintain accounts evidencing the Indebtedness of the Borrower to such Lender; such accounts are prima facie evidence absent manifest error.")

    d.page()  # ---- p5 interest & fees
    d.heading("Article III — Interest and Fees")
    d.line("Section 3.1 Interest. Each Term SOFR Loan shall bear interest at Adjusted Term SOFR for the applicable interest period plus the Applicable Margin. Each Base Rate Loan shall bear interest at the Base Rate plus the Applicable Margin.", "ca.interest")
    d.line("Section 3.2 Interest Payment Dates. Accrued interest on each Loan is payable in arrears on each Interest Payment Date and on the Maturity Date.")
    if f.fee_commitment:
        d.line(f"Section 3.3 Commitment Fee. The Borrower shall pay to the Administrative Agent for the account of each Lender a commitment fee at a rate per annum equal to {f.fee_commitment} on the daily unused amount of such Lender's Commitment, payable quarterly in arrears.", "ca.commitment_fee")
    else:
        d.line("Section 3.3 Other Fees. The Borrower shall pay the fees set forth in the Fee Letter at the times specified therein.", "ca.commitment_fee")
    d.line("Section 3.4 Computation. Interest and fees are computed on the basis of a year of 360 days and the actual number of days elapsed.")
    d.line("Section 3.5 Benchmark Replacement. If a Benchmark Transition Event occurs, the Administrative Agent and the Borrower may amend this Agreement to replace Term SOFR with a Benchmark Replacement in accordance with Section 10.2.")

    d.page()  # ---- p6 prepayments & conditions
    d.heading("Article IV — Prepayments and Conditions Precedent")
    d.line("Section 4.1 Voluntary Prepayments. The Borrower may prepay the Loans in whole or in part without premium or penalty upon not less than three (3) Business Days' prior written notice to the Administrative Agent, in minimum amounts of $1,000,000 and integral multiples of $500,000 in excess thereof.", "ca.prepayment_notice")
    d.line("Section 4.2 Conditions to Effectiveness. The obligations of the Lenders hereunder become effective on the date on which the Administrative Agent has received executed counterparts of this Agreement, the Guarantee, the Security Agreement and the Fee Letter, customary legal opinions, and evidence of payment of all fees then due.")
    d.line("Section 4.3 Conditions to Each Borrowing. The representations and warranties in Article V shall be true and correct in all material respects, and no Default shall have occurred and be continuing, on the date of each borrowing.")

    d.page()  # ---- p7 reps
    d.heading("Article V — Representations and Warranties")
    d.line(f"Section 5.1 Organization. The Borrower is duly organized, validly existing and in good standing under the laws of {f.jurisdiction}.")
    d.line("Section 5.2 Authorization; No Conflict. The execution and performance of the Loan Documents are within the Borrower's organizational powers and do not violate any law or material agreement binding on the Borrower.")
    d.line("Section 5.3 Financial Statements. The audited consolidated financial statements most recently delivered to the Administrative Agent fairly present the financial condition of the Borrower in accordance with GAAP.")
    d.line("Section 5.4 Litigation. There is no pending or, to the knowledge of the Borrower, threatened litigation that could reasonably be expected to result in a Material Adverse Effect.")
    d.line("Section 5.5 Sanctions; Anti-Corruption. Neither the Borrower nor any Subsidiary is a Sanctioned Person, and the Borrower has implemented policies reasonably designed to ensure compliance with Anti-Corruption Laws.")

    d.page()  # ---- p8 affirmative covenants
    d.heading("Article VI — Affirmative Covenants")
    d.line("Section 6.1 Financial Statements. The Borrower shall deliver to the Administrative Agent (a) within ninety (90) days after the end of each fiscal year, audited consolidated financial statements, and (b) within forty-five (45) days after the end of each of the first three fiscal quarters, unaudited consolidated financial statements.", "ca.reporting")
    d.line("Section 6.2 Compliance Certificate. Concurrently with each delivery under Section 6.1, the Borrower shall deliver a Compliance Certificate demonstrating compliance with Article VII.")
    d.line("Section 6.3 Notices of Material Events. The Borrower shall furnish prompt written notice, and in any event within five (5) Business Days, of the occurrence of any Default or any event that could reasonably be expected to result in a Material Adverse Effect.", "ca.default_notice")
    d.line("Section 6.4 Existence; Conduct of Business. The Borrower shall preserve its legal existence and the rights, licenses and permits material to its business.")
    d.line("Section 6.5 Insurance. The Borrower shall maintain insurance with financially sound insurers in such amounts as are customary for companies engaged in similar businesses.")
    d.line("Section 6.9 Additional Guarantors. Within thirty (30) days after any Subsidiary becomes a Material Subsidiary, the Borrower shall cause such Subsidiary to become a Guarantor.")

    d.page()  # ---- p9 negative covenants
    d.heading("Article VII — Financial and Negative Covenants")
    d.line(f"Section 7.1 Maximum Leverage Ratio. The Borrower shall not permit the Leverage Ratio as of the last day of any fiscal quarter to exceed {f.leverage}.", "ca.leverage")
    d.line(f"Section 7.2 Minimum Interest Coverage Ratio. The Borrower shall not permit the Interest Coverage Ratio for any period of four consecutive fiscal quarters to be less than {f.coverage}.", "ca.coverage")
    if f.key == "tolland":
        d.line("Section 7.3 Minimum Liquidity. The Borrower shall maintain Liquidity of not less than $5,000,000 at all times, tested on the last Business Day of each calendar month.", "ca.liquidity")
    else:
        d.line("Section 7.3 Indebtedness. The Borrower shall not, and shall not permit any Subsidiary to, incur Indebtedness other than Permitted Indebtedness, including purchase money Indebtedness not exceeding $10,000,000 in the aggregate at any time outstanding.")
    d.line("Section 7.4 Liens. The Borrower shall not create or permit any Lien on its property other than Permitted Liens.")
    d.line("Section 7.5 Fundamental Changes. The Borrower shall not merge, consolidate or dispose of all or substantially all of its assets, except as permitted under Section 7.6.")
    d.line("Section 7.6 Dispositions. The Borrower shall not dispose of assets outside the ordinary course of business with an aggregate fair market value exceeding $15,000,000 in any fiscal year without the consent of the Required Lenders.", "ca.dispositions")
    d.line("Section 7.7 Restricted Payments. The Borrower shall not declare or pay dividends if a Default exists or would result therefrom or if, on a pro forma basis, the Leverage Ratio would exceed the level set forth in Section 7.1 less 0.50 to 1.00.")

    d.page()  # ---- p10 events of default
    d.heading("Article VIII — Events of Default")
    d.line("Section 8.1 Events of Default. Each of the following constitutes an Event of Default:")
    d.line("(a) failure to pay principal when due, or failure to pay interest or fees within three (3) Business Days after the due date;", "ca.eod_payment")
    d.line("(b) any representation or warranty proves to have been incorrect in any material respect when made;")
    d.line("(c) failure to observe any covenant in Article VII, or failure to observe any other covenant that continues unremedied for thirty (30) days after notice from the Administrative Agent;", "ca.eod_covenant")
    d.line("(d) cross-default to other Indebtedness in an aggregate principal amount exceeding $5,000,000;", "ca.cross_default")
    d.line("(e) bankruptcy or insolvency of the Borrower or any Material Subsidiary; or")
    d.line("(f) a Change of Control.")
    d.line("Section 8.2 Remedies. Upon an Event of Default, the Administrative Agent may, at the request of the Required Lenders, terminate the Commitments and declare the Loans immediately due and payable.")

    d.page()  # ---- p11 agent & assignments
    d.heading("Article IX — The Administrative Agent; Assignments")
    d.line(f"Section 9.1 Appointment. Each Lender irrevocably appoints {f.agent} as Administrative Agent and authorizes it to take such actions on its behalf as are delegated by the Loan Documents.", "ca.agent")
    d.line("Section 9.2 Required Lenders. \"Required Lenders\" means Lenders holding more than 50% of the sum of the outstanding Loans and unused Commitments.")
    d.line("Section 9.3 Assignments. A Lender may assign all or a portion of its rights and obligations with the consent of the Borrower and the Administrative Agent (not to be unreasonably withheld), in minimum amounts of $5,000,000; the Borrower's consent is not required during an Event of Default.", "ca.assignment")
    d.line("Section 9.4 Resignation of Agent. The Administrative Agent may resign upon thirty (30) days' notice to the Lenders and the Borrower.")

    d.page()  # ---- p12 misc
    d.heading("Article X — Miscellaneous")
    d.line(f"Section 10.1 Notices. All notices shall be in writing and delivered by hand, overnight courier or electronic mail: if to the Borrower, to {f.address}, Attention: General Counsel; if to the Administrative Agent, to {f.agent_address}, Attention: Agency Services. "
           f"Notices are effective upon receipt, provided that notices received after 5:00 p.m. local time are deemed received on the next Business Day.", "ca.notices")
    d.line("Section 10.2 Amendments and Waivers. No amendment or waiver of any provision of this Agreement is effective unless in writing and signed by the Required Lenders and the Borrower; provided that no such amendment shall, without the consent of each Lender affected, increase any Commitment, reduce the principal of or rate of interest on any Loan, or extend the Maturity Date.", "ca.amendments_clause")
    d.line(f"Section 10.3 Governing Law. This Agreement shall be governed by, and construed in accordance with, the laws of the State of {f.governing_law}.", "ca.governing_law")
    d.line("Section 10.4 Counterparts. This Agreement may be executed in counterparts, each of which constitutes an original.")
    d.line("")
    d.line("IN WITNESS WHEREOF, the parties have caused this Agreement to be executed as of the Effective Date.")
    d.line(f"{f.borrower}, as Borrower — By: /s/ Authorized Signatory")
    d.line(f"{f.agent}, as Administrative Agent — By: /s/ Authorized Signatory")
    assert d.n_pages == 12, (d.stem, d.n_pages, note)


def credit_agreement(f: Facility, rng: random.Random) -> Doc:
    d = Doc(f"{f.key}_credit_agreement", f.ca_title, {
        "Document Type": "Credit Agreement", "Effective Date": f.date,
        "Parties": f"{f.borrower}; {f.agent}", "Facility ID": f.facility_id,
        "Version": "Original (Execution Version)",
    })
    _ca_body(d, f, rng, conformed=False)
    return d


def conformed_copy(f: Facility, rng: random.Random) -> Doc:
    # Same body as the executed agreement; different header + convenience note. Near-duplicate trap.
    d = Doc(f"{f.key}_credit_agreement_conformed", f"{f.ca_title} (Conformed Copy)", {
        "Document Type": "Credit Agreement", "Effective Date": f.date,
        "Parties": f"{f.borrower}; {f.agent}", "Facility ID": f.facility_id,
        "Version": "Conformed Copy",
    }, meta_style="kv")
    _ca_body(d, f, rng, conformed=True)
    return d


def amendment(f: Facility, a: Amendment) -> Doc:
    name = f"{ORD[a.number]} Amendment to Credit Agreement"
    prior = "" if a.number == 1 else f", as amended by the {ORD[a.number - 1]} Amendment dated as of {f.amendments[a.number - 2].date}"
    d = Doc(f"{f.key}_{ORD[a.number].lower()}_amendment", f"{name} — {f.short}", {
        "Document Type": "Amendment", "Effective Date": a.date,
        "Parties": f"{f.borrower}; {f.agent}", "Facility ID": f.facility_id,
        "Version": f"{ORD[a.number]} Amendment",
    })
    d.line(f"THIS {name.upper()} (this \"Amendment\") is entered into as of {a.date} (the \"{ORD[a.number]} Amendment Effective Date\") "
           f"among {f.borrower} (the \"Borrower\"), the Lenders party hereto and {f.agent}, as Administrative Agent.", "am.preamble")
    d.line("")
    d.line("## Recitals")
    d.line(f"WHEREAS, the Borrower, the Lenders and the Administrative Agent are parties to that certain Credit Agreement dated as of {f.date}{prior} "
           f"(the \"Credit Agreement\"; facility {f.facility_id});", "am.recital")
    d.line(f"WHEREAS, {a.recitals};")
    d.line("NOW, THEREFORE, the parties agree as follows.")
    d.page()
    d.heading("Section 1 — Amendments to the Credit Agreement")
    d.line(f"Effective as of the {ORD[a.number]} Amendment Effective Date, the Credit Agreement is amended as follows:")
    for i, (fld, (old, new)) in enumerate(a.changes.items(), 1):
        label = FIELD_LABEL[fld]
        sec = FIELD_SECTION[fld]
        if fld == "leverage":
            txt = f"1.{i} Section {sec} is amended by replacing \"{old}\" with \"{new}\", so that the Borrower shall not permit the Leverage Ratio as of the last day of any fiscal quarter to exceed {new}."
        elif fld == "coverage":
            txt = f"1.{i} Section {sec} is amended by replacing \"{old}\" with \"{new}\", so that the Borrower shall not permit the Interest Coverage Ratio to be less than {new}."
        elif fld == "margin":
            txt = f"1.{i} The definition of \"Applicable Margin\" in Section {sec} is amended by replacing \"{old}\" with \"{new}\", so that the Applicable Margin for Term SOFR Loans is {new} per annum."
        elif fld == "commitment":
            txt = f"1.{i} Section {sec} and the definition of \"Aggregate Commitment\" are amended by replacing \"{old}\" with \"{new}\", so that the Aggregate Commitment is {new}."
        else:  # maturity
            txt = f"1.{i} The definition of \"Maturity Date\" in Section {sec} is amended by replacing \"{old}\" with \"{new}\", so that the Maturity Date is {new}."
        d.line(txt, f"am.{fld}")
    d.line("")
    d.heading("Section 2 — Conditions to Effectiveness")
    d.line(f"This Amendment becomes effective on the date the Administrative Agent receives counterparts hereof executed by the Borrower and the Required Lenders"
           + (" and each Lender" if any(k in a.changes for k in ("commitment", "maturity")) else "")
           + f", together with an amendment fee for the account of each consenting Lender equal to {'0.125%' if a.number == 1 else '0.25%'} of such Lender's Commitment.", "am.fee")
    d.page()
    d.heading("Section 3 — Representations; Reaffirmation")
    d.line("The Borrower represents that no Default has occurred and is continuing and that the representations in Article V of the Credit Agreement are true and correct in all material respects on the date hereof.")
    d.line("Each Guarantor, by its acknowledgment below, reaffirms its obligations under the Guarantee and the Security Agreement after giving effect to this Amendment.", "am.reaffirm")
    d.heading("Section 4 — Effect; Governing Law")
    d.line("Except as expressly amended hereby, the Credit Agreement and the other Loan Documents remain in full force and effect and are hereby ratified and confirmed. This Amendment is a Loan Document.", "am.effect")
    d.line(f"This Amendment shall be governed by the laws of the State of {f.governing_law}. Notices hereunder shall be given in the manner set forth in Section 10.1 of the Credit Agreement.")
    d.line(f"{f.borrower}, as Borrower — By: /s/ Authorized Signatory")
    d.line(f"{f.agent}, as Administrative Agent — By: /s/ Authorized Signatory")
    return d


def guarantee(f: Facility) -> Doc:
    d = Doc(f"{f.key}_guarantee", f"Guarantee — {f.short}", {
        "Document Type": "Guarantee", "Effective Date": f.date,
        "Parties": "; ".join(f.guarantors) + f"; {f.agent}", "Facility ID": f.facility_id,
        "Version": "Original (Execution Version)",
    })
    d.line(f"THIS GUARANTEE (this \"Guarantee\") is made as of {f.date} by each of the undersigned subsidiaries of {f.borrower} (each a \"Guarantor\") in favor of {f.agent}, "
           f"as Administrative Agent for the Lenders under the Credit Agreement dated as of {f.date} among {f.borrower}, the Lenders and the Administrative Agent (facility {f.facility_id}).", "g.preamble")
    d.page()
    d.heading("Section 1 — Guarantors")
    d.line("The Guarantors on the date hereof are:")
    for i, g in enumerate(f.guarantors, 1):
        d.line(f"({chr(96 + i)}) {g};", f"g.guarantor{i}")
    d.line("together with each other person that becomes a party hereto by executing a Guarantor Joinder pursuant to Section 6.9 of the Credit Agreement.")
    d.page()
    d.heading("Section 2 — The Guarantee")
    d.line("Each Guarantor, jointly and severally, unconditionally and irrevocably guarantees the punctual payment when due of all Obligations of the Borrower under the Loan Documents.", "g.scope")
    d.line("This Guarantee is a guarantee of payment and not of collection. The Administrative Agent is not required to exhaust remedies against the Borrower before proceeding against any Guarantor.")
    d.heading("Section 3 — Limitation")
    d.line("The obligations of each Guarantor are limited to the maximum amount that can be guaranteed without rendering this Guarantee voidable under applicable fraudulent transfer law.", "g.limit")
    d.page()
    d.heading("Section 4 — Waivers; Reinstatement")
    d.line("Each Guarantor waives presentment, demand, protest and notice of any kind, and any defense arising from any amendment, waiver or release under the Loan Documents.")
    d.line("This Guarantee shall be reinstated if any payment is rescinded or must be returned upon the insolvency of the Borrower.")
    d.heading("Section 5 — Release")
    d.line("A Guarantor is released automatically upon the sale of all of its equity interests in a transaction permitted by Section 7.6 of the Credit Agreement.", "g.release")
    d.page()
    d.heading("Section 6 — Notices; Governing Law")
    d.line(f"Notices to any Guarantor shall be delivered care of the Borrower at {f.address}, Attention: General Counsel, and are effective in the manner provided in Section 10.1 of the Credit Agreement.", "g.notices")
    d.line(f"This Guarantee shall be governed by the laws of the State of {f.governing_law}.")
    for g in f.guarantors:
        d.line(f"{g}, as Guarantor — By: /s/ Authorized Signatory")
    return d


def security_agreement(f: Facility) -> Doc:
    d = Doc(f"{f.key}_security_agreement", f"Security Agreement — {f.short}", {
        "Document Type": "Security Agreement", "Effective Date": f.date,
        "Parties": f"{f.borrower}; " + ("; ".join(f.guarantors) + "; " if f.guarantors else "") + f"{f.agent}",
        "Facility ID": f.facility_id, "Version": "Original (Execution Version)",
    })
    d.line(f"THIS SECURITY AGREEMENT (this \"Security Agreement\") is made as of {f.date} among {f.borrower} (the \"Borrower\"), "
           f"the other Grantors party hereto and {f.agent}, as Administrative Agent (in such capacity, the \"Secured Party\"), "
           f"to secure the Obligations under the Credit Agreement dated as of {f.date} (facility {f.facility_id}).", "s.preamble")
    d.page()
    d.heading("Section 1 — Grant of Security Interest")
    d.line("Each Grantor hereby grants to the Secured Party, for the benefit of the Secured Parties, a continuing security interest in all of its right, title and interest in the following (the \"Collateral\"): all Accounts, Chattel Paper, Deposit Accounts, Documents, Equipment, General Intangibles, Instruments, Inventory, Investment Property and all Proceeds of the foregoing.", "s.grant")
    d.line(f"Without limiting the foregoing, the Collateral includes all Inventory and Equipment located at the Grantors' principal facility in {f.collateral_location}.", "s.location")
    d.heading("Section 2 — Excluded Assets")
    d.line("The Collateral does not include any lease, license or contract to the extent the grant of a security interest therein is prohibited by its terms, or any Deposit Account used exclusively for payroll or trust purposes.", "s.excluded")
    d.page()
    d.heading("Section 3 — Perfection")
    d.line(f"Each Grantor authorizes the Secured Party to file financing statements describing the Collateral in the jurisdiction of organization of such Grantor, including {f.jurisdiction}.", "s.perfection")
    d.line("Each Grantor shall deliver to the Secured Party all certificated Investment Property and Instruments with a value exceeding $250,000, together with undated instruments of transfer.", "s.delivery")
    d.heading("Section 4 — Covenants of the Grantors")
    d.line("Each Grantor shall give the Secured Party at least thirty (30) days' prior written notice of any change in its legal name, jurisdiction of organization or chief executive office.", "s.change_notice")
    d.line("Each Grantor shall keep the Collateral insured and shall not permit any Lien on the Collateral other than Permitted Liens.")
    d.page()
    d.heading("Section 5 — Remedies")
    d.line("Upon the occurrence and during the continuance of an Event of Default, the Secured Party may exercise all rights of a secured party under the Uniform Commercial Code, including the right to sell the Collateral at public or private sale upon ten (10) days' notice to the Grantors, which the Grantors agree is commercially reasonable.", "s.remedies_notice")
    d.line("Proceeds of Collateral are applied first to the costs of enforcement, second to interest and fees, third to principal, and last to the Grantors or as a court may direct.", "s.waterfall")
    d.page()
    d.heading("Section 6 — Termination")
    d.line("This Security Agreement terminates, and the security interest is released, when the Commitments have terminated and all Obligations (other than contingent indemnification obligations) have been paid in full.", "s.termination")
    d.heading("Section 7 — Notices; Governing Law")
    d.line(f"All notices hereunder shall be given in the manner set forth in Section 10.1 of the Credit Agreement, to the Grantors at {f.address}.", "s.notices")
    d.line(f"This Security Agreement shall be governed by the laws of the State of {f.governing_law}.")
    d.page()
    d.heading("Schedule 1 — Grantors and Filing Offices")
    d.line(f"{f.borrower} — {f.jurisdiction} — Secretary of State")
    for g in f.guarantors:
        d.line(f"{g} — {f.jurisdiction} — Secretary of State")
    d.heading("Schedule 2 — Collateral Locations")
    d.line(f"{f.collateral_location}")
    return d


def fee_letter(f: Facility) -> Doc:
    d = Doc(f"{f.key}_fee_letter", f"Fee Letter — {f.short}", {
        "Document Type": "Fee Letter", "Effective Date": f.date,
        "Parties": f"{f.borrower}; {f.agent}", "Facility ID": f.facility_id,
        "Version": "Original (Execution Version)",
    })
    d.line(f"Reference: {f.fee_ref}", "fee.ref")
    d.line(f"{f.agent}")
    d.line(f"{f.agent_address}")
    d.line("")
    d.line(f"{f.date}")
    d.line("")
    d.line(f"{f.borrower}")
    d.line(f"{f.address}")
    d.line("")
    d.line(f"Re: Credit Agreement dated as of {f.date} (facility {f.facility_id}) — Fees", "fee.re")
    d.line("")
    d.line("Ladies and Gentlemen:")
    d.line("This letter (this \"Fee Letter\") sets forth the fees payable by the Borrower in connection with the Credit Agreement. Capitalized terms used but not defined herein have the meanings given in the Credit Agreement. This Fee Letter is a Loan Document.")
    d.page()
    d.heading("1. Fees")
    d.line(f"(a) Upfront Fee. On the Effective Date, the Borrower shall pay to the Administrative Agent, for the account of each Lender, an upfront fee equal to {f.fee_upfront} of such Lender's Commitment on the Effective Date.", "fee.upfront")
    d.line(f"(b) Agency Fee. The Borrower shall pay to the Administrative Agent, for its own account, an annual agency fee of {f.fee_agency}, payable in advance on the Effective Date and on each anniversary thereof.", "fee.agency")
    if f.fee_commitment:
        d.line(f"(c) Commitment Fee. The commitment fee set forth in Section 3.3 of the Credit Agreement accrues at {f.fee_commitment} per annum on the unused Commitments.", "fee.commitment")
    else:
        d.line("(c) Arrangement Fee. The Borrower shall pay to the Administrative Agent, for its own account, an arrangement fee as separately agreed in writing.", "fee.commitment")
    d.heading("2. Payment")
    d.line(f"All fees are payable in immediately available funds, without setoff or counterclaim, to the Administrative Agent at {f.agent} , {f.fee_account}, reference {f.fee_ref}.", "fee.account")
    d.line("Fees paid are non-refundable under all circumstances.")
    d.page()
    d.heading("3. Confidentiality; Governing Law")
    d.line("The Borrower shall keep this Fee Letter confidential and shall not disclose it to any person other than its officers, directors, advisors and the Lenders, except as required by law.", "fee.confidential")
    d.line(f"This Fee Letter shall be governed by the laws of the State of {f.governing_law}.")
    d.line("Very truly yours,")
    d.line(f"{f.agent}, as Administrative Agent — By: /s/ Authorized Signatory")
    d.line(f"Accepted and agreed: {f.borrower} — By: /s/ Authorized Signatory")
    return d


def waiver(f: Facility) -> Doc:
    x = f.extra
    level_at_quarter = f.current("leverage", x["waiver_quarter"])
    d = Doc(f"{f.key}_waiver", f"Limited Waiver — {f.short}", {
        "Document Type": "Waiver", "Effective Date": x["waiver_date"],
        "Parties": f"{f.borrower}; {f.agent}", "Facility ID": f.facility_id,
        "Version": "Limited Waiver",
    })
    d.line(f"THIS LIMITED WAIVER (this \"Waiver\") is entered into as of {x['waiver_date']} among {f.borrower} (the \"Borrower\"), the Required Lenders and {f.agent}, as Administrative Agent, "
           f"under the Credit Agreement dated as of {f.date} (as amended, the \"Credit Agreement\"; facility {f.facility_id}).", "w.preamble")
    d.line("")
    d.line("## Recitals")
    d.line(f"WHEREAS, the Borrower has advised the Administrative Agent that the Leverage Ratio as of the fiscal quarter ended {x['waiver_quarter']} was {x['waiver_ratio']}, "
           f"exceeding the maximum of {level_at_quarter} permitted under Section 7.1 of the Credit Agreement (the \"Specified Default\");", "w.breach")
    d.line("WHEREAS, the Borrower has requested that the Required Lenders waive the Specified Default, and the Required Lenders are willing to do so on the terms set forth herein;")
    d.page()
    d.heading("Section 1 — Limited Waiver")
    d.line(f"Subject to Section 2, the Required Lenders hereby waive the Specified Default solely for the fiscal quarter ended {x['waiver_quarter']}. "
           f"This Waiver does not amend Section 7.1 of the Credit Agreement, which continues to require a Leverage Ratio not exceeding {level_at_quarter} for each subsequent fiscal quarter.", "w.scope")
    d.heading("Section 2 — Conditions")
    d.line(f"This Waiver is effective upon the Administrative Agent's receipt of (a) counterparts executed by the Borrower and the Required Lenders and (b) a waiver fee of {x['waiver_fee']} for the ratable account of the consenting Lenders.", "w.fee")
    d.line("The Borrower shall deliver to the Administrative Agent, within ten (10) Business Days after the date hereof, a thirteen-week cash flow forecast and shall deliver an updated forecast on the first Business Day of each month thereafter until the Leverage Ratio is in compliance for two consecutive fiscal quarters.", "w.reporting")
    d.page()
    d.heading("Section 3 — Reservation of Rights; Effect")
    d.line("Except as expressly set forth herein, the Lenders reserve all rights and remedies under the Loan Documents. Nothing herein constitutes a waiver of any other Default or a course of dealing.", "w.reservation")
    d.line("Except as expressly waived hereby, the Credit Agreement remains in full force and effect. This Waiver is a Loan Document.")
    d.line(f"This Waiver shall be governed by the laws of the State of {f.governing_law}. Notices shall be given in the manner set forth in Section 10.1 of the Credit Agreement.")
    d.line(f"{f.borrower}, as Borrower — By: /s/ Authorized Signatory")
    d.line(f"{f.agent}, as Administrative Agent — By: /s/ Authorized Signatory")
    return d


def consent(f: Facility) -> Doc:
    x = f.extra
    d = Doc(f"{f.key}_consent", f"Lender Consent — {f.short}", {
        "Document Type": "Consent", "Effective Date": x["consent_date"],
        "Parties": f"{f.borrower}; {f.agent}", "Facility ID": f.facility_id,
        "Version": "Consent",
    })
    d.line(f"THIS CONSENT (this \"Consent\") is entered into as of {x['consent_date']} among {f.borrower} (the \"Borrower\"), the Required Lenders and {f.agent}, as Administrative Agent, "
           f"under the Credit Agreement dated as of {f.date} (the \"Credit Agreement\"; facility {f.facility_id}).", "c.preamble")
    d.line("")
    d.line("## Recitals")
    d.line(f"WHEREAS, the Borrower proposes to sell {x['consent_asset']} for cash consideration of not less than {x['consent_amount']} (the \"Specified Disposition\"), "
           f"which would exceed the annual threshold under Section 7.6 of the Credit Agreement;", "c.asset")
    d.page()
    d.heading("Section 1 — Consent")
    d.line(f"The Required Lenders hereby consent to the Specified Disposition, provided that it is consummated on or before {x['consent_date'][:4]}-12-31 and that 100% of the Net Cash Proceeds are applied to prepay the Term Loans within five (5) Business Days of receipt.", "c.terms")
    d.heading("Section 2 — Limited Effect")
    d.line("This Consent is limited to the Specified Disposition and does not constitute a consent to any other transaction or a waiver of any other provision of the Credit Agreement.", "c.limited")
    d.page()
    d.heading("Section 3 — Miscellaneous")
    d.line("The Borrower represents that no Default has occurred and is continuing. The Credit Agreement remains in full force and effect. This Consent is a Loan Document.")
    d.line(f"This Consent shall be governed by the laws of the State of {f.governing_law}. Notices shall be given in the manner set forth in Section 10.1 of the Credit Agreement.")
    d.line(f"{f.borrower}, as Borrower — By: /s/ Authorized Signatory")
    d.line(f"{f.agent}, as Administrative Agent — By: /s/ Authorized Signatory")
    return d


def side_letter(f: Facility) -> Doc:
    x = f.extra
    d = Doc(f"{f.key}_side_letter", f"Side Letter — {f.short}", {
        "Document Type": "Side Letter", "Effective Date": x["side_date"],
        "Parties": f"{f.borrower}; {f.agent}", "Facility ID": f.facility_id,
        "Version": "Side Letter",
    })
    d.line(f"{x['side_date']}")
    d.line(f"To: {f.borrower}, {f.address}")
    d.line(f"From: {f.agent}, as Administrative Agent, on behalf of the Lenders")
    d.line(f"Re: Credit Agreement dated as of {f.date} (facility {f.facility_id}) — {x['side_topic']}", "sl.re")
    d.line("")
    d.line("This side letter forms part of the Loan Documents and records an accommodation agreed among the parties at closing.")
    d.page()
    d.heading(f"1. {x['side_topic']}")
    if f.key == "halvorsen":
        d.line(f"Notwithstanding Section 7.6 of the Credit Agreement, the Borrower may dispose of vessels in the ordinary course of fleet renewal for aggregate consideration of up to {x['side_amount']} per fiscal year without the consent of the Required Lenders, provided that the Net Cash Proceeds are reinvested in replacement vessels within 180 days.", "sl.terms")
    else:
        d.line(f"Notwithstanding Section 6.1(b) of the Credit Agreement, the Borrower may deliver quarterly financial statements within sixty (60) days after the end of each fiscal quarter during the first fiscal year after the Effective Date, and the Minimum Liquidity threshold in Section 7.3 is reduced to {x['side_amount']} for the same period.", "sl.terms")
    d.heading("2. Notices")
    d.line("Any notice under this side letter must be delivered by electronic mail to the Administrative Agent at agency.services@example.invalid, with a copy by overnight courier, and is effective one (1) Business Day after dispatch.", "sl.notices")
    d.page()
    d.heading("3. Confidentiality; Governing Law")
    d.line("This side letter is confidential and may not be disclosed except to the parties' advisors and as required by law.")
    d.line(f"This side letter shall be governed by the laws of the State of {f.governing_law}.")
    d.line(f"{f.agent}, as Administrative Agent — By: /s/ Authorized Signatory")
    d.line(f"Acknowledged and agreed: {f.borrower} — By: /s/ Authorized Signatory")
    return d


# --------------------------------------------------------------------------- distractors


def distractors(rng: random.Random) -> list[Doc]:
    out = []
    d = Doc("distractor_office_lease", "Office Lease — Halvorsen Marine Holdings, Inc. (Tenant)", {
        "Document Type": "Lease", "Effective Date": "2024-11-01",
        "Parties": "Harbor Way Properties LLC; Halvorsen Marine Holdings, Inc.",
    })
    d.line("THIS OFFICE LEASE (this \"Lease\") is made as of 2024-11-01 between Harbor Way Properties LLC (\"Landlord\") and Halvorsen Marine Holdings, Inc. (\"Tenant\") for Suite 400 at 1200 Harbor Way, Seattle, Washington.")
    d.page()
    d.heading("1. Premises and Term")
    d.line("Landlord leases to Tenant approximately 18,250 rentable square feet on the fourth floor (the \"Premises\") for a term of ten (10) years commencing 2025-01-01.")
    d.heading("2. Rent")
    d.line("Base Rent is $62,500 per month for the first lease year, increasing 3% annually.", "lease.rent")
    d.page()
    d.heading("3. Use; Assignment")
    d.line("Tenant shall use the Premises for general office purposes only. Tenant shall not assign this Lease without Landlord's prior written consent.")
    d.heading("4. Default")
    d.line("Failure to pay Rent within five (5) days after written notice constitutes an Event of Default under this Lease.")
    d.page()
    d.heading("5. Notices; Governing Law")
    d.line("Notices to Tenant: 1200 Harbor Way, Suite 400, Seattle, Washington 98101, Attention: Facilities. Notices to Landlord: 700 Fifth Avenue, Suite 5600, Seattle, Washington 98104.")
    d.line("This Lease is governed by the laws of the State of Washington.")
    out.append(d)

    d = Doc("distractor_nda", "Mutual Non-Disclosure Agreement — Corvallis Foods Group LLC and Willamette Valley Produce, Inc.", {
        "Document Type": "Non-Disclosure Agreement", "Effective Date": "2025-06-02",
        "Parties": "Corvallis Foods Group LLC; Willamette Valley Produce, Inc.",
    })
    d.line("This Mutual Non-Disclosure Agreement (this \"NDA\") is entered into as of 2025-06-02 between Corvallis Foods Group LLC and Willamette Valley Produce, Inc. in connection with a potential acquisition (the \"Transaction\").")
    d.page()
    d.heading("1. Confidential Information")
    d.line("\"Confidential Information\" means all non-public information disclosed by a party in connection with the Transaction, including financial projections, customer lists and the terms of any financing arrangements.")
    d.heading("2. Obligations")
    d.line("Each party shall hold the other party's Confidential Information in strict confidence for a period of three (3) years from the date of disclosure.", "nda.term")
    d.page()
    d.heading("3. Exclusions; Remedies")
    d.line("The obligations do not apply to information that is or becomes public through no fault of the receiving party. Each party acknowledges that breach may cause irreparable harm for which injunctive relief is appropriate.")
    d.heading("4. Governing Law")
    d.line("This NDA is governed by the laws of the State of Oregon.")
    out.append(d)

    d = Doc("distractor_employment_agreement", "Executive Employment Agreement — Keswick Logistics Partners LP", {
        "Document Type": "Employment Agreement", "Effective Date": "2025-10-01",
        "Parties": "Keswick Logistics Partners LP; Dana Whitfield",
    })
    d.line("THIS EXECUTIVE EMPLOYMENT AGREEMENT is entered into as of 2025-10-01 between Keswick Logistics Partners LP (the \"Company\") and Dana Whitfield (the \"Executive\").")
    d.page()
    d.heading("1. Position and Duties")
    d.line("The Executive shall serve as Chief Financial Officer of the Company, reporting to the Chief Executive Officer, and shall devote substantially all business time to the Company.")
    d.heading("2. Compensation")
    d.line("Base salary of $425,000 per year, subject to annual review; target annual bonus of 60% of base salary.", "emp.salary")
    d.page()
    d.heading("3. Term and Termination")
    d.line("The initial term is three (3) years. Either party may terminate upon ninety (90) days' written notice; termination by the Company without Cause entitles the Executive to twelve (12) months of base salary as severance.", "emp.notice")
    d.heading("4. Restrictive Covenants")
    d.line("During employment and for twelve (12) months thereafter, the Executive shall not solicit employees or customers of the Company.")
    d.page()
    d.heading("5. Governing Law")
    d.line("This Agreement is governed by the laws of the State of Tennessee.")
    d.line("Keswick Logistics Partners LP — By: /s/ Authorized Signatory")
    d.line("Dana Whitfield — /s/")
    out.append(d)

    d = Doc("distractor_equipment_lease", "Master Equipment Lease — Tolland Precision Components Corp. (Lessee)", {
        "Document Type": "Equipment Lease", "Effective Date": "2025-03-10",
        "Parties": "Northgate Equipment Finance LLC; Tolland Precision Components Corp.",
    })
    d.line("THIS MASTER EQUIPMENT LEASE is made as of 2025-03-10 between Northgate Equipment Finance LLC (\"Lessor\") and Tolland Precision Components Corp. (\"Lessee\").")
    d.line("Lessor is an affiliate of Northgate Capital Bank. This Lease is not a Loan Document under any credit agreement.")
    d.page()
    d.heading("1. Equipment; Schedules")
    d.line("Lessor leases to Lessee the CNC machining centers described in each Equipment Schedule executed hereunder, with an aggregate original equipment cost not to exceed $6,000,000.", "eq.cost")
    d.heading("2. Rent")
    d.line("Rent for each Schedule is payable monthly in advance as set forth in such Schedule. Late payments bear a late charge of 1.5% per month.")
    d.page()
    d.heading("3. Maintenance; Return")
    d.line("Lessee shall maintain the Equipment in good working order and return it at the end of the term to Lessor's facility in Hartford, Connecticut at Lessee's expense.")
    d.heading("4. Governing Law")
    d.line("This Lease is governed by the laws of the State of Connecticut.")
    out.append(d)
    return out


# --------------------------------------------------------------------------- corpus


def build_corpus() -> tuple[list[Doc], dict[str, Facility]]:
    rng = random.Random(SEED)
    docs: list[Doc] = []
    facs = {f.key: f for f in facilities()}
    for f in facs.values():
        docs.append(credit_agreement(f, rng))
        for a in f.amendments:
            docs.append(amendment(f, a))
        if "conformed" in f.docs:
            docs.append(conformed_copy(f, rng))
        if "guarantee" in f.docs:
            docs.append(guarantee(f))
        if "security" in f.docs:
            docs.append(security_agreement(f))
        if "fee" in f.docs:
            docs.append(fee_letter(f))
        if "waiver" in f.docs:
            docs.append(waiver(f))
        if "consent" in f.docs:
            docs.append(consent(f))
        if "side" in f.docs:
            docs.append(side_letter(f))
    docs.extend(distractors(rng))
    stems = [d.stem for d in docs]
    assert len(stems) == len(set(stems)), "duplicate stems"
    return docs, facs


# --------------------------------------------------------------------------- questions


class QBuilder:
    def __init__(self, docs: list[Doc]) -> None:
        self.by_stem = {d.stem: d for d in docs}
        self.out: list[dict] = []

    def add(self, qtype: str, question: str, gold: list[tuple[str, list[str | int]]],
            answer: str | None = None, items: list[str] | None = None, rubric: list[str] | None = None,
            notes: str = "", absent: list[str] | None = None) -> None:
        gold_docs = []
        for stem, refs in gold:
            d = self.by_stem[stem]
            pages = sorted({r if isinstance(r, int) else d.page_of(r) for r in refs})
            gold_docs.append({"doc_id": f"<{stem}>", "pages": pages})
        q = {"qid": f"q{len(self.out) + 1:03d}", "type": qtype, "question": question, "gold_docs": gold_docs,
             "gold_answer": answer, "gold_items": items or [], "rubric": rubric or [], "notes": notes}
        if absent:
            q["absent_terms"] = absent
        self.out.append(q)


def build_questions(docs: list[Doc], facs: dict[str, Facility]) -> list[dict]:
    qb = QBuilder(docs)
    H, C, B, T, K = (facs[k] for k in ("halvorsen", "corvallis", "brightwater", "tolland", "keswick"))
    ca = lambda f: f"{f.key}_credit_agreement"  # noqa: E731
    am1 = lambda f: f"{f.key}_first_amendment"  # noqa: E731

    # ---- single-document factoids
    qb.add("single", "What is the maximum Leverage Ratio permitted under Section 7.1 of the original Halvorsen Marine Holdings Credit Agreement?",
           [(ca(H), ["ca.leverage"])], answer=H.leverage,
           rubric=[f"states {H.leverage}", "cites the Credit Agreement (executed original), not the First Amendment or the conformed copy"],
           notes="single-doc factoid; near-duplicate conformed copy carries the same text")
    qb.add("single", "What is the Aggregate Commitment under the Tolland Precision Components Credit Agreement on the Effective Date?",
           [(ca(T), ["ca.def_commitment", "ca.commitment"])], answer=T.commitment,
           rubric=[f"states {T.commitment}", "cites Section 2.1 or the Aggregate Commitment definition"])
    qb.add("single", "Which bank is the Administrative Agent under the Keswick Logistics Partners Credit Agreement?",
           [(ca(K), ["ca.preamble", "ca.agent"])], answer=K.agent,
           rubric=[f"names {K.agent}", "does not confuse Keswick with Corvallis, which has the same agent"])
    qb.add("single", "What law governs the Corvallis Foods Group Credit Agreement?",
           [(ca(C), ["ca.governing_law"])], answer=C.governing_law,
           rubric=[f"states {C.governing_law} law", "cites Section 10.3"],
           notes="most other credit agreements in the corpus are New York law")
    qb.add("single", "How much is the annual agency fee under the Brightwater Renewables Fee Letter?",
           [("brightwater_fee_letter", ["fee.agency"])], answer=B.fee_agency,
           rubric=[f"states {B.fee_agency}", "identifies it as an annual fee payable in advance"])
    qb.add("single", "How many Business Days' prior notice must Halvorsen Marine Holdings give to make a voluntary prepayment?",
           [(ca(H), ["ca.prepayment_notice"])], answer="three (3) Business Days",
           rubric=["states three Business Days", "cites Section 4.1", "mentions the $1,000,000 minimum if asked about amounts"])
    qb.add("single", "What Leverage Ratio did Halvorsen Marine Holdings report for the fiscal quarter ended 2025-09-30 according to the Limited Waiver?",
           [("halvorsen_waiver", ["w.breach"])], answer=H.extra["waiver_ratio"],
           rubric=[f"states {H.extra['waiver_ratio']}", "distinguishes the reported ratio from the covenant maximum of 4.50 to 1.00"])
    qb.add("single", "What is the minimum Liquidity covenant under the Tolland Precision Components Credit Agreement?",
           [(ca(T), ["ca.liquidity"])], answer="$5,000,000",
           rubric=["states $5,000,000", "notes monthly testing on the last Business Day of each month"],
           notes="Tolland is the only facility with a liquidity covenant")
    qb.add("single", "Within how many days after fiscal year end must Brightwater Renewables deliver audited financial statements?",
           [(ca(B), ["ca.reporting"])], answer="ninety (90) days",
           rubric=["states 90 days", "cites Section 6.1(a)"])
    qb.add("single", "What waiver fee did Tolland Precision Components pay for the Limited Waiver dated 2026-02-10?",
           [("tolland_waiver", ["w.fee"])], answer=T.extra["waiver_fee"],
           rubric=[f"states {T.extra['waiver_fee']}", "does not confuse it with the Halvorsen waiver fee of $125,000"])

    # ---- temporal: which version governs on a date
    qb.add("temporal", "What maximum Leverage Ratio applies to Halvorsen Marine Holdings as of 2025-05-01?",
           [(ca(H), ["ca.leverage"])], answer=H.leverage,
           rubric=[f"states {H.leverage}", "identifies the original Credit Agreement as governing on that date", "notes the First Amendment (2025-07-31) had not yet taken effect"],
           notes="date precedes the First Amendment")
    qb.add("temporal", "What maximum Leverage Ratio applies to Halvorsen Marine Holdings as of 2025-10-15?",
           [(am1(H), ["am.leverage"])], answer=H.current("leverage", "2025-10-15"),
           rubric=["states 4.50 to 1.00", "identifies the First Amendment effective 2025-07-31 as governing", "mentions 4.00 to 1.00 was superseded"],
           notes="version trap: the conformed copy still shows 4.00")
    qb.add("temporal", "What is the Aggregate Commitment under the Halvorsen Marine Holdings facility as of 2026-03-31?",
           [("halvorsen_second_amendment", ["am.commitment"])], answer=H.current("commitment", "2026-03-31"),
           rubric=["states $175,000,000", "identifies the Second Amendment effective 2026-01-20 as governing", "notes the original $150,000,000"],
           notes="second amendment governs")
    qb.add("temporal", "What is the Maturity Date of the Halvorsen Marine Holdings facility as of 2025-12-01?",
           [(ca(H), ["ca.maturity"])], answer=H.maturity,
           rubric=[f"states {H.maturity}", "recognises the Second Amendment extension to 2031-02-14 took effect only on 2026-01-20"],
           notes="later amendment must NOT be applied retroactively")
    qb.add("temporal", "Which maximum Leverage Ratio covenant level applies to Halvorsen Marine Holdings as of 2026-06-30, and which document sets it?",
           [(am1(H), ["am.leverage"]), ("halvorsen_second_amendment", ["am.commitment"])], answer=H.current("leverage", "2026-06-30"),
           rubric=["states 4.50 to 1.00", "identifies the First Amendment as the document that set the level", "explains the Second Amendment did not change Section 7.1"],
           notes="latest document is not the governing one for this term")
    qb.add("temporal", "What Applicable Margin for Term SOFR Loans applies to Corvallis Foods Group as of 2025-12-01?",
           [(am1(C), ["am.margin"])], answer=C.current("margin", "2025-12-01"),
           rubric=["states 3.50%", "cites the First Amendment effective 2025-11-15", "mentions the original 3.25%"])
    qb.add("temporal", "What Applicable Margin for Term SOFR Loans applied to Corvallis Foods Group as of 2025-10-01?",
           [(ca(C), ["ca.margin"])], answer=C.margin,
           rubric=[f"states {C.margin}", "identifies the original Credit Agreement as governing before the 2025-11-15 amendment"])
    qb.add("temporal", "What minimum Interest Coverage Ratio applies to Brightwater Renewables as of 2025-06-30?",
           [(am1(B), ["am.coverage"])], answer=B.current("coverage", "2025-06-30"),
           rubric=["states 2.25 to 1.00", "cites the First Amendment effective 2025-05-12", "does not cite the conformed copy as current"],
           notes="conformed copy trap: shows 2.50 to 1.00")

    # ---- multihop
    qb.add("multihop", "What maximum Leverage Ratio applied, under the original Credit Agreement, to the borrower whose obligations are guaranteed by Halvorsen Shipyards LLC?",
           [("halvorsen_guarantee", ["g.guarantor1", "g.preamble"]), (ca(H), ["ca.leverage"])], answer=H.leverage,
           rubric=["identifies Halvorsen Marine Holdings via the Guarantee", f"states {H.leverage}", "cites both documents"],
           notes="guarantee -> borrower -> covenant")
    qb.add("multihop", "Which bank is Administrative Agent for the facility whose Fee Letter provides an upfront fee of 0.50%?",
           [("corvallis_fee_letter", ["fee.upfront"]), (ca(C), ["ca.agent"])], answer=C.agent,
           rubric=["identifies the Corvallis Fee Letter", f"names {C.agent}"],
           notes="fee letter -> facility -> agent")
    qb.add("multihop", "What is the Aggregate Commitment of the borrower whose Security Agreement covers Inventory and Equipment located in Hartford, Connecticut?",
           [("tolland_security_agreement", ["s.location"]), (ca(T), ["ca.commitment"])], answer=T.commitment,
           rubric=["identifies Tolland via the Security Agreement collateral location", f"states {T.commitment}", "ignores the Tolland equipment lease distractor"])
    qb.add("multihop", "The Halvorsen Marine Holdings Second Amendment extends the Maturity Date. What was the Maturity Date under the original Credit Agreement?",
           [("halvorsen_second_amendment", ["am.maturity"]), (ca(H), ["ca.maturity"])], answer=H.maturity,
           rubric=[f"states {H.maturity}", "states the new date 2031-02-14", "cites both documents"])
    qb.add("multihop", "At the time of the Specified Default described in the Halvorsen Marine Holdings Limited Waiver, which document had set the Leverage Ratio covenant level that was breached?",
           [("halvorsen_waiver", ["w.breach"]), (am1(H), [1, "am.leverage"])], answer="First Amendment to Credit Agreement",
           rubric=["identifies the First Amendment (effective 2025-07-31) as setting 4.50 to 1.00", "states the reported 4.68 to 1.00 exceeded it", "does not attribute the level to the original agreement"],
           notes="waiver -> amendment chain")
    qb.add("multihop", "What annual agency fee is payable under the Fee Letter for the facility identified as FAC-2026-0007?",
           [(ca(K), ["ca.facility_id_def"]), ("keswick_fee_letter", ["fee.re", "fee.agency"])], answer=K.fee_agency,
           rubric=["maps FAC-2026-0007 to Keswick Logistics Partners", f"states {K.fee_agency}"])
    qb.add("multihop", "The Corvallis Foods Group Lender Consent permits the sale of the Eugene distribution center. Which covenant section of the Credit Agreement would the sale otherwise have breached, and what is that section's annual threshold?",
           [("corvallis_consent", ["c.asset"]), (ca(C), ["ca.dispositions"])], answer="$15,000,000",
           rubric=["identifies Section 7.6 Dispositions", "states the $15,000,000 annual threshold", "states the consideration of not less than $12,500,000"])

    # ---- identifier
    qb.add("identifier", "Which executed instruments reference facility FAC-2025-0042?",
           [(ca(H), [1]), (am1(H), [1]), ("halvorsen_second_amendment", [1]), ("halvorsen_guarantee", [1]),
            ("halvorsen_security_agreement", [1]), ("halvorsen_fee_letter", [1]), ("halvorsen_waiver", [1]), ("halvorsen_side_letter", [1])],
           items=["Credit Agreement", "First Amendment to Credit Agreement", "Second Amendment to Credit Agreement", "Guarantee",
                  "Security Agreement", "Fee Letter", "Limited Waiver", "Side Letter"],
           rubric=["lists all eight executed instruments", "treats the conformed copy as a copy of the Credit Agreement, not a separate instrument"],
           notes="near-duplicate trap: the conformed copy also carries FAC-2025-0042")
    qb.add("identifier", "Which borrower's facility is identified as FAC-2024-0311?",
           [(ca(B), [1, "ca.facility_id_def"])], answer=B.borrower,
           rubric=[f"names {B.borrower}", "does not confuse it with Halvorsen, which shares the same agent"])
    qb.add("identifier", "What is the reference number of the Halvorsen Marine Holdings Fee Letter?",
           [("halvorsen_fee_letter", ["fee.ref"])], answer=H.fee_ref,
           rubric=[f"states {H.fee_ref}", "does not return the Brightwater reference MTB-2024-FEE-0311"])
    qb.add("identifier", "To which account number are fees under the Corvallis Foods Group Fee Letter payable?",
           [("corvallis_fee_letter", ["fee.account"])], answer=C.fee_account,
           rubric=[f"states {C.fee_account}", "does not return the Keswick account number, which shares the same agent"])
    qb.add("identifier", "Which documents reference facility FAC-2025-0193?",
           [(ca(T), [1]), ("tolland_security_agreement", [1]), ("tolland_waiver", [1]), ("tolland_side_letter", [1])],
           items=["Credit Agreement", "Security Agreement", "Limited Waiver", "Side Letter"],
           rubric=["lists all four documents", "excludes the Tolland equipment lease, which has no facility id"])

    # ---- coverage / enumeration
    qb.add("coverage", "List every Guarantor under the Halvorsen Marine Holdings Guarantee.",
           [("halvorsen_guarantee", ["g.guarantor1", "g.guarantor2", "g.guarantor3"])], items=list(H.guarantors),
           rubric=["lists all three guarantors", "does not list the Borrower itself as a guarantor"])
    qb.add("coverage", "List every fee payable under the Halvorsen Marine Holdings Fee Letter, with its amount or rate.",
           [("halvorsen_fee_letter", ["fee.upfront", "fee.agency", "fee.commitment"])],
           items=[f"upfront fee equal to {H.fee_upfront}", f"annual agency fee of {H.fee_agency}", f"accrues at {H.fee_commitment} per annum"],
           rubric=["lists upfront, agency and commitment fees", "gives 0.75%, $75,000 and 0.375%"])
    qb.add("coverage", "Which borrowers have Meridian Trust Bank, N.A. as Administrative Agent?",
           [(ca(H), ["ca.preamble"]), (ca(B), ["ca.preamble"])], items=[H.borrower, B.borrower],
           rubric=["lists Halvorsen Marine Holdings, Inc. and Brightwater Renewables plc", "does not list Corvallis, Tolland or Keswick"],
           notes="cross-document enumeration")
    qb.add("coverage", "List every notice provision across the Tolland Precision Components loan documents (Credit Agreement, Security Agreement, Limited Waiver, Side Letter).",
           [(ca(T), ["ca.notices", "ca.default_notice", "ca.prepayment_notice", "ca.borrowing_notice"]),
            ("tolland_security_agreement", ["s.change_notice", "s.remedies_notice", "s.notices"]),
            ("tolland_waiver", ["w.reporting"]), ("tolland_side_letter", ["sl.notices"])],
           items=["2200 Industrial Parkway, Hartford, Connecticut 06103", "within five (5) Business Days", "three (3) Business Days' prior written notice",
                  "thirty (30) days' prior written notice", "ten (10) days' notice", "effective one (1) Business Day after dispatch"],
           rubric=["covers the Credit Agreement Section 10.1 address and deemed-receipt rule", "covers the Security Agreement name/jurisdiction change notice and the sale notice",
                   "covers the Side Letter electronic-mail notice rule", "does not import notice terms from the Tolland equipment lease"],
           notes="breadth question; items are verbatim fragments")
    qb.add("coverage", "List every amendment to the Halvorsen Marine Holdings Credit Agreement and what each changed.",
           [(am1(H), ["am.leverage", "am.margin"]), ("halvorsen_second_amendment", ["am.commitment", "am.maturity"])],
           items=["Leverage Ratio", "Applicable Margin", "Aggregate Commitment", "Maturity Date"],
           rubric=["identifies the First Amendment (2025-07-31) and the Second Amendment (2026-01-20)", "lists the four changed terms with old and new values",
                   "does not treat the Limited Waiver or the conformed copy as an amendment"])
    qb.add("coverage", "List the financial covenants in the Tolland Precision Components Credit Agreement.",
           [(ca(T), ["ca.leverage", "ca.coverage", "ca.liquidity"])],
           items=["Maximum Leverage Ratio", "Minimum Interest Coverage Ratio", "Minimum Liquidity"],
           rubric=["lists all three covenants with their levels (3.00 to 1.00, 2.00 to 1.00, $5,000,000)", "cites Sections 7.1-7.3"])

    # ---- not in corpus (abstention)
    qb.add("not_in_corpus", "What Excess Cash Flow sweep percentage applies under the Corvallis Foods Group Term Loan Facility?",
           [], answer="Not in the documents.", absent=["Excess Cash Flow"],
           rubric=["states that no excess cash flow sweep is specified", "does not invent a percentage", "may note the Consent's 100% asset-sale prepayment is a different mechanism"])
    qb.add("not_in_corpus", "Which documents reference facility FAC-2025-0077?",
           [], answer="Not in the documents.", absent=["FAC-2025-0077"],
           rubric=["states that no document carries that facility id", "does not substitute a similar id such as FAC-2025-0042"])
    qb.add("not_in_corpus", "What LIBOR margin applied to the Brightwater Renewables loans before the SOFR transition?",
           [], answer="Not in the documents.", absent=["LIBOR"],
           rubric=["states the documents only reference Term SOFR", "does not present the 2.25% SOFR margin as a LIBOR margin"])
    qb.add("not_in_corpus", "What is the Default Rate of interest under the Halvorsen Marine Holdings Credit Agreement?",
           [], answer="Not in the documents.", absent=["Default Rate", "default interest"],
           rubric=["states that no default rate is specified", "does not invent a 2% uplift"])
    qb.add("not_in_corpus", "What is the swingline sublimit under the Tolland Precision Components Revolving Credit Facility?",
           [], answer="Not in the documents.", absent=["swingline", "Swingline", "sublimit"],
           rubric=["states no swingline facility or sublimit is provided for", "does not confuse the $45,000,000 Aggregate Commitment with a sublimit"])
    qb.add("not_in_corpus", "What sustainability-linked margin adjustment applies under the Brightwater Renewables Credit Agreement?",
           [], answer="Not in the documents.", absent=["sustainability", "Sustainability", "ESG"],
           rubric=["states that no sustainability-linked pricing exists in the documents despite the borrower's business", "does not invent KPI adjustments"])

    return qb.out


# --------------------------------------------------------------------------- self-check and I/O


def _self_check(docs: list[Doc], questions: list[dict]) -> None:
    by_stem = {d.stem: d for d in docs}
    assert 25 <= len(docs) <= 40, len(docs)
    for d in docs:
        assert 3 <= d.n_pages <= 12, (d.stem, d.n_pages)
    assert 30 <= len(questions) <= 50, len(questions)
    corpus = "\n".join(d.render() for d in docs)
    for q in questions:
        pages_text = []
        for gd in q["gold_docs"]:
            stem = gd["doc_id"].strip("<>")
            d = by_stem[stem]
            for p in gd["pages"]:
                assert 1 <= p <= d.n_pages, (q["qid"], stem, p)
                pages_text.append(d.page_text(p))
        if q["type"] == "not_in_corpus":
            assert not q["gold_docs"], q["qid"]
            for term in q.get("absent_terms", []):
                assert term not in corpus, (q["qid"], term)
            assert q["gold_answer"] not in corpus, q["qid"]
            continue
        assert q["gold_docs"], q["qid"]
        joined = "\n".join(pages_text)
        if q["gold_answer"]:
            assert q["gold_answer"] in joined, (q["qid"], q["gold_answer"])
        for item in q["gold_items"]:
            assert item in joined, (q["qid"], item)
    n = len(questions)
    counts = {t: sum(1 for q in questions if q["type"] == t) for t in sorted({q["type"] for q in questions})}
    assert counts.get("not_in_corpus", 0) >= max(3, -(-n // 10)), counts


def generate() -> tuple[dict[str, str], str, dict]:
    docs, facs = build_corpus()
    questions = build_questions(docs, facs)
    _self_check(docs, questions)
    files = {f"{d.stem}.md": d.render() for d in docs}
    jsonl = "".join(json.dumps(q, ensure_ascii=False) + "\n" for q in questions)
    summary = {
        "docs": len(docs),
        "docs_by_type": _count(d.pages[0] for d in docs),
        "questions": len(questions),
        "questions_by_type": {t: sum(1 for q in questions if q["type"] == t) for t in sorted({q["type"] for q in questions})},
    }
    return files, jsonl, summary


def _count(first_pages) -> dict[str, int]:
    out: dict[str, int] = {}
    for lines in first_pages:
        for ln in lines:
            if ln.startswith("| Document Type |") or ln.startswith("Document Type:"):
                t = ln.split("|")[2].strip() if ln.startswith("|") else ln.split(":", 1)[1].strip()
                out[t] = out.get(t, 0) + 1
                break
    return dict(sorted(out.items()))


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--check", action="store_true", help="do not write; exit 1 if disk differs from the generator")
    args = ap.parse_args(argv)
    files, jsonl, summary = generate()
    if args.check:
        bad = [n for n, body in files.items() if not (DOCS_DIR / n).exists() or (DOCS_DIR / n).read_text(encoding="utf-8") != body]
        extra = [p.name for p in DOCS_DIR.glob("*.md") if p.name not in files] if DOCS_DIR.exists() else []
        if not QUESTIONS.exists() or QUESTIONS.read_text(encoding="utf-8") != jsonl:
            bad.append(QUESTIONS.name)
        if bad or extra:
            print("stale:", bad, "extra:", extra)
            return 1
        print("up to date;", json.dumps(summary))
        return 0
    DOCS_DIR.mkdir(parents=True, exist_ok=True)
    for p in DOCS_DIR.glob("*.md"):
        if p.name not in files:
            p.unlink()
    for name, body in files.items():
        (DOCS_DIR / name).write_text(body, encoding="utf-8", newline="\n")
    QUESTIONS.parent.mkdir(parents=True, exist_ok=True)
    QUESTIONS.write_text(jsonl, encoding="utf-8", newline="\n")
    print(f"wrote {len(files)} docs to {DOCS_DIR.relative_to(ROOT)} and {summary['questions']} questions to {QUESTIONS.relative_to(ROOT)}")
    print(json.dumps(summary, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
