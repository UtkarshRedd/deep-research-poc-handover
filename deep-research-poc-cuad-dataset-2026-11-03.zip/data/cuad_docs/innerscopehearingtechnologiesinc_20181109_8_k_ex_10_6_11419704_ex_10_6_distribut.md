<!-- page 1 -->
# EXCLUSIVE DISTRIBUTOR AGREEMENT
| Field | Value |
|---|---|
| Document Type | Distributor Agreement |
| SEC Filing Date | 2018-11-09 |
| Parties | Erchonia Corporation ("Erchonia"); InnerScope Hearing Technologies Inc ("Distributor") |
| Source | CUAD v1 / InnerscopeHearingTechnologiesInc_20181109_8-K_EX-10.6_11419704_EX-10.6_Distributor Agreement |

Exhibit 10.6 ATTACHMENT A ERCHONIA CORPORATION EXCLUSIVE DISTRIBUTOR AGREEMENT

This agreement ("Agreement") is made by and between Erchonia Corporation. ("Erchonia") whose address
is 650 Atlantis Rd., Melbourne, Florida, USA, 32904 and InnerScope Hearing Technologies Inc,
("Distributor") whose address is 2151 Professional Drive, Second Floor, Roseville, California, USA,
95661 hereafter referred to collectively as the ("Parties").

Recitals

A. Erchonia is engaged in, among other things, the business of developing and promoting low level
lasers. Erchonia desires to retain Distributor to promote, distribute and sell such equipment listed
in Schedule A (the "Products"). B. Distributor is engaged in the business of, among other things,
selling medical products and services, specifically for the treatment of hearing disorders. C.
Distributor desires to obtain the exclusive right to distribute the Products pursuant to the terms
set for in this Agreement. D. The parties agree that these recitals shall be considered a term of
this Agreement. NOW, THEREFORE, the parties agree:

1. Grant of License.

a. Subject to the terms set forth in this agreement, Erchonia grants Distributor the exclusive, non-
transferable right and license to promote, distribute and sell the Products identified in Exhibit A
to those type of customer specified in Exhibit B and only within the Territory specified in Exhibit
B. Distributor shall only distribute or sell the Products to customers who are licensed health care
professionals and meet the other requirements set forth in Exhibit B.

b. Erchonia retains the right, in its sole discretion, to add, delete, upgrade, or modify the
Products from time to time. Upon receipt of notice of such change, Distributor shall cease to market
and distribute earlier versions of the Products and/or Products deleted from Schedule A. Distributor
will deliver, at Erchonia's expense, all recalled, discontinued or products otherwise rendered
unmarketable (under the terms of this paragraph) to Erchonia. Erchonia will fully reimburse
Distributor for all costs related to the cost of materials and products returned to Erchonia

2. Obligations of Distributor.

a. Distributor shall use its best efforts to market, promote and sell the Products to the authorized
customers in the Filed of Use and in the Territory during the term of this agreement.

b. Distributor agrees that during the term of this agreement it meet the minimum performance goals
set forth in Exhibit C to this agreement. Failure to meet these minimum performance goals for any
period, shall, at Erchonia's option (i) be considered a breach of this agreement for which Erchonia
shall have all the rights and remedies provided for herein upon a breach of this agreement,
including termination of this agreement, or (ii) shall give Erchonia to terminate or limit the
exclusivity provisions of this agreement

c. Upon Erchonia's reasonable request, Distributor shall consult with Erchonia regarding
Distributor's marketing and promotion efforts in the Territory and Field of Use and shall cooperate
with Erchonia's reasonable requests regarding Distributor's marketing and promotional efforts.

d. Distributor shall maintain appropriate records concerning the sales of the Products. Such records
shall include at a minimum the name, address and telephone number of each customer, the date of
sale, a listing of the Products sold to each customer. Upon Erchonia's request, Distributor shall
provide Erchonia with regular periodic reports including the information described in this
paragraph. All such information shall be available for inspection by Erchonia, upon reasonable
notice. Distributor shall also maintain such other records related to sales of the Products as
Erchonia may reasonably request.

e. Distributor shall pay for all products purchased in a timely manner. Source: INNERSCOPE HEARING
TECHNOLOGIES, INC., 8-K, 11/9/2018
<!-- page 2 -->
f. Distributor shall not, and may not permit any other person, including customers, to reproduce,
distribute, sell or dispose of the Products, in whole or in part, except as expressly permitted
under this Agreement.

g. Distributor will at all times be and represent itself to be an independent distributor, not an
agent or employee of Erchonia.

h. Distributor may not make any contracts or commitments on behalf of Erchonia nor make any
warranties or other representations regarding the Products other than those authorized herein.

i. Distributor must adhere to and comply with any use recommendations or restrictions for the
Products as indicated or recommended by Erchonia. Distributor shall not make any statements,
representations, or recommendations inconsistent with any use restriction or limitation.

j. Distributor shall not sell or export the Products outside the United States without prior written
consent of Erchonia. To the extent sales of the Products outside the United States are permitted,
Distributor will be solely responsible to comply with all applicable import and export laws and
regulations.

k. Distributor shall promptly notify Erchonia of any complaint about negative, unwanted,
deleterious, or other side effects due to the use of the Products, including the complainant's name,
contact information, and date of complaint.

l. During the term of this agreement Distributor shall at all time act in responsible and
professional manner. Distributor shall not do anything which is contrary to or which in Erchonia's
reasonable business judgment is harmful to its honor, goodwill or reputation.

m. Distributor shall at all times comply with all applicable laws and regulations.

3. Restriction on Promotion of Competing Products. During the term of this agreement, Distributor
shall not market, sell advertise or promote the sale or use of any product or device which is
competitive with or substantially similar to the Products, without the prior express written consent
of Erchonia, nor shall they assist any third party in doing so. Notwithstanding the foregoing, to
the extent Distributor or Distributor's customer is a licensed health care professional or licensed
health care practitioner, nothing in this paragraph shall prevent or limit Distributor or
Distributor's customer from exercising their independent medical judgment with regard to the
treatment of any patient.

4. Orders, Payment, and Shipment.

a. Erchonia agrees to provide Products to Distributor pursuant to orders placed by Distributor in
the form of individual purchase orders issued by Distributor to Erchonia. Such purchase orders shall
set forth the quantity of each product ordered, the required delivery date, and the point of
delivery. The price for the Products shall be as designated in Schedule A. Erchonia may revise its
prices from time to time and deliver a written 90 day notice of the reasonable price revision to
Distributor; provided that Erchonia agrees that the prices listed in Exhibit A shall not be
increased during the first 90 days of this agreement.

b. Erchonia shall submit invoices to Distributor after or concurrent with shipment of Products to
Distributor at the delivery address. Distributor shall pay half (1/2) of the purchase price prior to
shipment and the remaining balance 30 days after shipment of the Products. Payments received after
the 30 day calendar period will be subject to a late fee of 1.5% of the invoice amount. All payments
shall be made in U.S. Dollars.

c. Distributor is responsible for all shipping costs and applicable sales taxes. Distributor is also
responsible for all customs and duties applicable to any sales of the Products outside the United
States, to the extent such sales are authorized or permitted.

5. Expenses and Taxes.

a. Distributor is responsible for any out-of-pocket expenses incurred including but not limited to
Products for demonstration, Products for treatment, sales and promotional material, seminar costs
including room rental, and travel-related expenses.

b. Distributor is responsible for all federal, state and local taxes attributable to compensation
received

Source: INNERSCOPE HEARING TECHNOLOGIES, INC., 8-K, 11/9/2018
<!-- page 3 -->
pursuant to this Agreement, including sales, income, social security, and unemployment.

6. Term and Termination.

a. Unless terminated earlier as provided in this agreement, this Agreement shall have an initial
term of three (3) years. This agreement shall automatically renew for a period of three (3) years
and upon the parties mutual agreement on new minimum performance goals for the renewal period.

b. Either party may terminate this Agreement in the event of a material breach by the other party,
provided the breaching party is first given reasonably detailed, written notice of the breach. If
the breach is not cured within ten days of such notice, the Agreement will terminate immediately.

c. This Agreement may be terminated immediately by Erchonia under any of the following conditions:
(a) if the Distributor is declared insolvent or bankrupt; (b) if a petition is filed in any court to
declare Distributor bankrupt or for reorganization under the Bankruptcy Law or any similar statute
and such petition is not dismissed within 30 days.

d. Upon termination of this Agreement by either party, Distributor shall immediately cease using the
Trademarks (defined below) and discontinue all representations that it is an authorized distributor
of the Products or is in anyway affiliated with Erchonia.

e. Except upon termination due to Distributors breach of this agreement, Erchonia will complete
delivery of all purchase orders accepted by it prior to termination of this agreement; provided that
Distributor shall remain liable for full payment of all such orders.

f. The provisions of paragraphs 2 (c) (reporting), 7 (Confidentiality), 8 (Protection of
Intellectual Property, 10 (Warranty; Limitation of Liability), 11 (Indemnification), 12 (General
Provisions) shall survive termination of this agreement.

7. Confidentiality.

a. In connection with this Agreement, the Distributor will have disclosed to it or otherwise have
access to information that is confidential and proprietary to Erchonia. Such information includes
but is not limited to Product designs, methods and processes, know-how, business or marketing
strategies, Product plans, plans for research and development, development tools, financial
information, production costs and information, and supplier and customer lists and information and
medical research conducted in pursuit of intended medical applications of the product.

b. Distributor will not copy, reproduce, disclose, disseminate or provide any confidential
information to any third party, without the prior written consent of Erchonia. In addition,
Distributor agrees that it will use such confidential information only for the purpose of carrying
out its obligations under this agreement. Upon termination of this agreement for any reason,
Distributor will return all such confidential information and any copies of it to Erchonia and will
remove and delete any such confidential information for any computers, computer systems or other
electronic, magnetic or optical media in its possession or control.

c. Notwithstanding the above, the following materials will not be deemed confidential:

i. Information which was in the public domain at the time of disclosure

ii. Information which was published or otherwise became part of the public domain after disclosure
to the Distributor through no fault of the Distributor; and

iii. Information which was received from a third party who did not acquire it, directly or
indirectly, from Erchonia under an obligation of confidence except where required by law.

8. Protection of Intellectual Property.

a. Ownership of all applicable copyrights, trade secrets, patents and other intellectual property
rights in the Products are and shall at all times remain vested in Erchonia, its licensors or
assigns.

b. Distributor shall promptly inform Erchonia of any suggested modifications or improvements to the
Products and shall, upon Erchonia's request and at Erchonia's expense, execute any documents
necessary or appropriate to assign or confirm that all intellectual property rights in any
modification

Source: INNERSCOPE HEARING TECHNOLOGIES, INC., 8-K, 11/9/2018
<!-- page 4 -->
or improvement related to the Products are fully vested in Erchonia.

c. Distributor shall not modify nor create or attempt to create, by reverse engineering or
otherwise, the Products supplied hereunder, or adapt the Products in any way for other uses without
Erchonia's prior written consent

d. Several of the Products may be protected by one or more U.S. or international patents.
Distributor shall take reasonable steps to ensure that all patent markings and/or notices for or
related to the Products are properly placed on the Products, and on any advertising or marketing
materials for the Products, and it shall not remove any such markings, notices or labels from any of
the Products or related materials or related advertising or marketing materials.

9. Use of Erchonia Trademarks.

a. All trademarks, including service marks, trade names and trade address that Erchonia uses in
connection with the license granted hereunder (the "Trademarks") are and remain the exclusive
property of Erchonia. Nothing contained in this Agreement shall be deemed to give Distributor any
right, title or interest in any Trademark. The Trademarks include but are not limited to: the names
"Erchonia", "Erchonia Medical", the phrase "Erchonia, Designs Into the Future", the Erchonia logo,
packaging design, and Product design.

b. During the term of this Agreement, Erchonia grants Distributor a non-exclusive, non-transferable
license to use the Trademarks for advertising and promotion of Products. Distributor shall use the
Trademarks according to quality standards defined by Erchonia which shall be reasonable and shall be
no greater than the standards used by Erchonia for its own advertising and promotion.

c. Upon Erchonia's request, the Distributor shall at its expense deliver to Erchonia representative
samples of labels, advertisements, catalogs, spec sheets, and the like, containing the Trademarks,
and to inspect all of Distributors websites, social media accounts and any online information posted
by Distributor, to ensure that such Trademarks are used only in a manner complaint with the quality
standards. Should such material fail to meet the standards set by Erchonia, as determined by
Erchonia in its sole discretion, Distributor shall not use and shall withdraw and retract any
promotion or advertising that Erchonia finds unsuitable and will at its expense destroy such
materials or make them compliant.

d. All goodwill associated with such trademark use by Distributor inures to the benefit of Erchonia.

10. Warranty; Limitation of Liability.

a. Distributor Warranty. Distributor represents that it has requisite knowledge and experience to
provide the products and services contracted for herein.

b. Erchonia Warranty and Warranty Limitations: Other than the written warranty accompanying the
Products, Erchonia DISCLAIMS ALL OTHER REPRESENTATIONS AND WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT OF THIRD PARTY
INTELLECTUAL PROPERTY RIGHTS.

c. IN NO EVENT SHALL Erchonia BE LIABLE FOR ANY LOSS OF PROFIT OR ANY OTHER COMMERCIAL DAMAGE,
INCLUDING BUT NOT LIMITED TO SPECIAL, INCIDENTAL, CONSEQUENTIAL OR OTHER INDIRECT DAMAGES UNDER ANY
CAUSE OF ACTION ARISING OUT OF OR RELATING TO THIS AGREEMENT, INCLUDING, WITHOUT LIMITATION, CLAIMS
ARISING FROM MALFUNCTION OR DEFECTS IN THE PRODUCTS.

11. Indemnification.

a. Erchonia shall indemnify, defend and hold Distributor harmless from any claims, demands,
liabilities or expenses, including reasonable attorneys' fees, incurred by Distributor as a result
of any claim or proceeding against Distributor arising out of or based upon: (i) a claim that the
Products infringe upon any U.S. patent, trademark, copyright or other intellectual property rights
of any third party, (ii) the products fail to comply with applicable federal law or regulation.

b. Distributor shall promptly notify Erchonia of any suit or claim by a third party relating to the
Products or use of the Products and Distributor shall promptly furnished Erchonia with a copy of
each

Source: INNERSCOPE HEARING TECHNOLOGIES, INC., 8-K, 11/9/2018
<!-- page 5 -->
communication, notice or other action relating to said claim. Erchonia shall have the right to
assume sole authority to conduct the trial or settlement of such claim or any negotiations related
to any claim for which Erchonia is obligated to indemnify Distributor at Erchonia expense; and
Distributor shall provide reasonable information and assistance requested by Erchonia in connection
with such claim or suit.

c. Distributor shall indemnify, defend and hold Erchonia harmless from any claims, demands,
liabilities or expenses, including reasonable attorneys' fees, incurred by Erchonia as a result of
any claim or proceeding against Erchonia arising out of or based upon (i) the combination, operation
or use of the Products with any hardware, products, programs or data not supplied or approved in
writing by Erchonia, if such infringement would have been avoided but for such combination,
operation or use; (ii) the modification of the Products by Distributor or its Customers; (iii) any
breach of this agreement by Distributor; or (iv) any negligent, grossly negligent, or willful or
reckless acts by Distributor, or any of its officers, employees, agents or representatives.

12. General Provisions:

a. Assignment. Distributor may not assign to any person any duties or obligations arising under this
Agreement without Erchonia's prior written consent (which consent may be withheld in Erchonia's sole
discretion). Notwithstanding the foregoing, the Distributor may engage individuals, at the sole
expense and responsibility of the Distributor, to assist the Distributor in performing any of the
Distributor's duties or obligations arising under this Agreement. Erchonia may not assign any duties
or obligations arising under this Agreement, except to a successor who acquires substantially all of
the assets of Erchonia.

b. Arbitration. The parties intend to negotiate in good faith and resolve any dispute arising under
this Agreement. In the event the parties are unable to resolve any such dispute to binding
arbitration for settlement in accordance with the rules of the American Arbitration Association, the
arbitrator will determine the manner in which the parties are to pay the costs of such arbitration,
including reasonable attorneys' fees

c. Notices. All notices and communications required under this Agreement will be in writing and will
be delivered in person, faxed or mailed, postage prepaid, by overnight express carrier, to the
address of the parties listed at the beginning of this Agreement, or to any other address as such
party designates in a written notice to the other party. All notices sent pursuant to the terms of
this section will be deemed received on the date of delivery if personally delivered or faxed, or if
sent by overnight express carrier, on the next business day immediately following the day sent

d. Severability. The provisions of this Agreement will be deemed severable and the invalidity or
unenforceability of any provision will not affect the validity or enforceability of any other
provisions hereof.

e. Governing Law. This Agreement shall be governed in all respects by the laws of the United States
and the State of Florida, except for conflict of laws provisions. The parties agree that for any
dispute, controversy or claim arising out of or in connection with this Agreement, venue and
personal jurisdiction shall be in the federal or state court with competent jurisdiction located in
Brevard Country, Florida.

f. Entire Agreement. This Agreement constitutes and expresses the entire agreement and understanding
between the parties hereto with respect to the subject matter, all revisions discussions, promises,
representation, and understanding relative thereto, if any, being herein merged.

Dated: .

Erchonia Medical Corporation. By _____________________ Its _____________________

Distributor: ________________________ InnerScope Hearing Technologies, Inc. By
_______________________ Its _______________________ Exhibits Exhibit A - Products and Pricing
Exhibit B - Territory and Field of Use

Source: INNERSCOPE HEARING TECHNOLOGIES, INC., 8-K, 11/9/2018
<!-- page 6 -->
Exhibit C - Minimum Performance Goals Rev. IMS 8/29/2018 3:38 PM

Source: INNERSCOPE HEARING TECHNOLOGIES, INC., 8-K, 11/9/2018
<!-- page 7 -->
SCHEDULE A ERCHONIA CORPORATION Products and Pricing Erchonia 3LT Laser - Hearing Products Version
(product may be renamed) All prices are per unit sold excluding freight, duty, and taxes. Prices
will remain in effect for the period of the initial 5 year term. Wholesale Price Item To Be
determined when successful research project is complete. The parties agree to cooperate in
developing a private label version of the above products on the terms the parties may agree. The
private label products shall be versions of the above products labeled and packaged to bear the
Distributor's name or the Distributor's trade name. In addition, customized packaging for the
private label products may also be developed on the terms agreed to by the parties. Pricing for the
private labeled products may be modified due to any increased costs of production or packaging for
the private labeled products. In addition, Erchonia may require reasonable minimum purchasing
requirements for each run of private labeled products.

Source: INNERSCOPE HEARING TECHNOLOGIES, INC., 8-K, 11/9/2018
<!-- page 8 -->
EXHIBIT B

Licensed Territory

Worldwide

Field of Use

The products will be sold only for the use in the treatment of hearing disorders.

Source: INNERSCOPE HEARING TECHNOLOGIES, INC., 8-K, 11/9/2018

Exhibit C

Minimum Performance Goals
<!-- page 9 -->
Minimum Performance won't be determined until FDA 50k market clearance is obtained. At that time
parties will operate in good faith to set performance goals.

Note: Performance goals to begin 120 days after receipt of FDA market clearance.

Source: INNERSCOPE HEARING TECHNOLOGIES, INC., 8-K, 11/9/2018
