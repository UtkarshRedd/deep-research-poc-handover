<!-- page 1 -->
# Sponsorship Agreement
| Field | Value |
|---|---|
| Document Type | Sponsorship Agreement |
| Agreement Date | 1998-12-18 |
| Parties | J. Walter Thompson ("FMM"); iVillage, Inc. ("iVillage")(referred to generically as a "Party", orcollectively as "Parties") |
| Source | CUAD v1 / IVILLAGEINC_03_17_1999-EX-10.16-SPONSORSHIP AGREEMENT |

* Confidential treatment has been requested for certain portions of this exhibit. Omitted portions
have been filed separately with the Commission.

SPONSORSHIP AGREEMENT

This Sponsorship Agreement ("Agreement") is entered into as of December 18, 1998, by and between
Ford Motor Media, a division of J. Walter Thompson ("FMM") with offices at 300 Renaissance Center,
Detroit, Michigan 48243 and iVillage, Inc., ("iVillage") with offices at 170 Fifth Avenue, New York,
New York 10010. FMM and iVillage may be referred to generically as a "Party", or collectively as
"Parties".

WHEREAS, iVillage operates a site on the World Wide Web and America Online (the "Network"), which
contains channels including Parent Soup, ParentsPlace, Better Health and Armchair Millionaire as
well as career, fitness & beauty, relationships, work from home, travel, money and food channels.

WHEREAS, FMM seeks to promote the sale of its automotive products across the Network.

NOW, THEREFORE, for good and valuable consideration, the receipt and sufficiency of which are hereby
acknowledged, iVillage and FMM hereby agree as follows:

1. Term and Termination.

A. Term. The initial production period shall be for a period of two (2) months to commence on
November 4, 1998 (the "Production Period"), and the remaining term of this Agreement shall be for a
period of twenty four (24) months to commence on the tentative launch date of January 4, 1999,
unless terminated earlier as provided herein (the "Promotion Period"), (The Production Period and
the Promotion Period shall be collectively referred to as the "Initial Term"). The Parties agree
that prior to July 1, 2000, iVillage will provide FMM with the opportunity to renew this Agreement
(the "Renewal Term") on terms set forth in a proposal (the "Proposal) to be presented to FMM. FMM
shall indicate its acceptance or rejection of the Proposal no later than August 31, 2000. If
iVillage does not receive FMM's acceptance or rejection of the Proposal by August 31, 2000, iVillage
may interpret FMM's non response as a rejection of the Proposal. The Proposal shall include maximum
payment fees by FMM with respect to the Renewal Term.

B. Termination. In the event of a material breach by either Party of any term of this Agreement, the
non-breaching Party may terminate this Agreement by written notice to the breaching Party if the
breaching Party fails to cure such material breach within thirty (30) days of receipt of written
notice thereof. In addition, either Party may terminate this Agreement effective upon written notice
stating its intention to terminate in the event the other Party (i) ceases to function as a going
concern or to conduct operations in the normal course of business, or (ii) has a petition filed by
or against it under any state or federal bankruptcy or insolvency law which petition has not been
dismissed or set aside within sixty (60) days of its filing. In addition to the foregoing, if on or
after January 31, 2000, either Party determines, based upon reasonable and mutually agreed upon
measurable standards, that (x) the other Party has materially underperformed its obligations
pursuant to this Agreement or (y) the expectations of such Party have been materially unfulfilled,
such Party may terminate this Agreement upon ninety (90) days written notice to the other Party.
Additionally, in the event of a prolonged and/or substantial

strike which materially and adversely affects Ford's ability to produce and sell cars, the Parties
will work together in good faith to amend or terminate this Agreement.

2. Promotion.

A. During the Production Period, iVillage will design, develop, construct and host a Ford bridge
site (the "Bridge Site") which shall include approximately [*] pages of content and other
interactive material such as a travel planner or a car design feature. During the Promotion Period,
iVillage will continue to host, maintain and update the Bridge Site. Upon receipt from iVillage of
the proposed Bridge Site design and content, FMM shall have no more than five (5) business days in
which to provide iVillage with its acceptance or rejection of the design and content. If iVillage
does not receive FMM's acceptance or rejection of such within the allotted time, iVillage shall deem
FMM's silence as acceptance. The Parties shall work together to determine the content mix and
delivery deadlines in order to maximize the effectiveness of the sponsorship campaign.

B. During the Initial Term, iVillage will design, create and deliver [*] Ford-branded advertising
units. The advertising units shall be subject to FMM's final approval. iVillage will deliver
approximately [*] new advertising units each during the Promotion Period. For purposes of this
Agreement, an advertising unit can include but shall not be limited to banners in the form of rich
media, java-based, animated, daughter and/or pull-down banners, or a combination of appropriate
technologies, and which shall represent and be defined by industry standards.

C.

(i) During the Promotion Period, iVillage will deliver a
<!-- page 2 -->
minimum of [*] advertising impressions, in an equal proportion each month. Subject to reasonable
written notice to iVillage, FMM may request a reasonable reallocation of impressions as determined
by FMM. The advertising units of Ford Division and other Ford Motor Company entities shall be served
by a third party advertisement server, which shall be compliant with Net gravity, or Doubleclick or
other compatible technology.

(ii) During the Promotion Period, iVillage traffic shall be audited by a third party traffic auditor
listed on Exhibit A and iVillage shall provide FMM with relevant reports on a biweekly basis.
iVillage will provide ongoing marketing, creative, technical and editorial consultation to FMM.

(iii) In the event that iVillage fails to deliver the advertising impressions during the Promotion
Period, FMM shall have the option of either (a) extending the Initial Term of this Agreement for an
additional three (3) month period to "make good" the undelivered impressions or (b) requiring
iVillage to refund to FMM an amount equal to [*] for each [*] impressions which were not delivered.

(iv) However, if iVillage falls to deliver the advertising impressions during the Promotion Period
and FMM desires that iVillage "make good" the undelivered impressions and extend the Initial Term
pursuant to option (a) set forth in Section 2.C.(iii), if the Parties have decided not to renew the
Initial Term and iVillage desires to enter into an agreement with an entity whose business(es) would
pose a conflict to FMM 2

or Ford Motor Credit, then iVillage, at iVillage's option, may refund the remaining impression
deficiency to FMM, and immediately upon pavement of such, the "make good" obligation shall
terminate.

D. During the Initial Term, iVillage will design and administer, (i) a minimum of [*] online
conferences which shall include live chats and the archiving of conference transcripts (dates of
such conferences shall be determined by FMM and shall occur approximately once every two months, but
not earlier than March 1, 1999 and FMM shall provide iVillage with not less than forty five (45)
days advance notice of any conference); (ii) a minimum of [*] online polls; (iii) a minimum of [*]
sixty-second surveys; (iv) a minimum of [*] online focus groups; and (v) a minimum of [*] customized
turn-key Network sweepstakes (iVillage shall be responsible for all aspects of the sweepstakes other
than the prize(s) which shall be provided by Ford Motor Company ("FMC")). FMM and FMC's respective
advertising agencies shall be free to provide input with respect to the aforementioned promotional
efforts set forth in this section and shall have the opportunity to reasonably approve such efforts.

E. During the Initial Term, iVillage will develop and administer [*] message boards pertaining to
topics mutually determined by the Parties. The first message board shall be live on or about January
4, 1999, or in conjunction with the launch of the Bridge Site.

F. During the Promotional Period, iVillage will place special Ford-branded text links, newsletter
mentions, hotlinks and taglines throughout the Network. FMC shall have prior approval over all
iVillage uses of any, Ford Mark, as defined below. In the event that any of the Ford-branded links
and/or mentions set forth in this Section 2.F. are, in FMC's reasonable judgment, materially
injurious to FMC. FMC shall provide written notice of such offense to iVillage. iVillage shall then
have one (1) business day in which to cure said offense.

3. Reporting. During the Promotion Period, iVillage agrees to provide FMM with biweekly reports in
connection with the promotional obligations set forth in this Agreement in addition to semi-annual
executive reviews with iVillage management. All traffic reports shall be audited by the third party
traffic auditor selected pursuant to Section 2.C.(ii). iVillage shall also provide, on a timely
basis, impression tracking reports from a third party tracking system, confirming guaranteed
impression delivery.

4. Exclusivity. For the Initial Term of this Agreement, iVillage agrees that Ford shall be the
exclusive automobile manufacturer sponsor and advertiser throughout the Network, with respect to
entities whose primary business is that of an automotive manufacturer and/or retailer. For purposes
of this Agreement, the term "retailer" shall refer to an entity which sells new and/or used
vehicles. In addition, in the event that iVillage desires to form a sponsorship relationship with an
automobile rental company during the term of this Agreement, iVillage shall notify Hertz and provide
Hertz with an opportunity to enter into such a relationship with iVillage, on not less favorable
terms than those offered to any other automobile rental company. Once presented with an opportunity,
Hertz shall have five (5) business days in which to accept or reject such terms. If iVillage does
not receive Hertz's acceptance or rejection of such within the allotted time, iVillage shall deem
Hertz's silence as rejection. The terms of any such relationship shall be mutually determined by the
Parties. Notwithstanding the foregoing, FMC shall, on a non-exclusive basis,

3

be permitted to offer Ford Motor Credit car financing products related to the purchase of Ford
vehicles.

5. Fee.
<!-- page 3 -->
A. FMC agrees to pay iVillage, upon signing of this Agreement, an upfront, non-refundable,
non-recoupable production and set up fee in the amount of [*]. In addition, FMM shall pay iVillage
[*] in equal quarterly payments of [*] each, within ten (10) days after the end of each calendar
quarter during 1999.

B. In addition, FMM agrees to pay iVillage, [*] in equal quarterly payments of [*] each, within ten
(10) days after the end of each calendar quarter during the year 2000.

6. Representations and Warranties. Each Party hereby represents and warrants that: (a) it is a
corporation duly organized and validly existing and in good standing under the laws of the state of
incorporation; (b) it has full power and authority to enter into this Agreement and to perform its
obligations hereunder; (c) it has obtained all permits, licenses, and other governmental
authorizations and approvals required for its performance under this Agreement, and (d) the services
to be rendered and the materials provided by each Party under this Agreement neither infringe nor
violate any patent, copyright, trade secret, trademark, or other proprietary right of any third
party.

7. Proprietary Rights. Upon execution and delivery of this Agreement, iVillage assigns to FMC all
right, title and interest in and to the content, design and intellectual property, rights created
specifically for and unique to the Bridge Site, advertising units, and other promotional elements
set forth in this Agreement (collectively, the "Materials"). Notwithstanding the foregoing, iVillage
expressly retains all right, title and interest in and to the programs and software that are used in
connection with the creation and operation of, but are not created specifically, for and unique to
the Materials (the "iVillage Proprietary Materials"). FMC acknowledges and agrees that the iVillage
Proprietary Materials are used by iVillage in creating and developing Web sites for itself and other
parties. FMC further acknowledges and agrees that iVillage will be using certain licensed programs
and software owned by third parties for portions of the development and creation of the Materials
and that FMC will not acquire any right in or to those copyrighted materials. iVillage agrees to
execute any and all necessary further documents that FMC may reasonably request to fully vest the
intellectual property rights related to the Materials in FMC and, if requested, to reasonable assist
FMC in registering such rights in the name of FMC.

8. Publicity. iVillage, FMC and FMM agree to collaborate on a joint press release ("Press Release")
to include information regarding the subject matter of this Agreement and quotes from iVillage, FMC
and FMM sources. The distribution list shall be approved by both Parties no less than five (5)
business days prior to the release date. The Press Release and any quotes from either Party's
sources must be approved by the other Party's public relations department, which also must be made
aware of any pre-briefings with outside parties at least five (5) days in advance of any
pre-briefing. In addition, the iVillage and FMM public relations department, FMC and FMM must be
informed, no less than five (5) days before the release date, of any third party who expresses
interest in the Press Release.

4

9. Licenses. FMM grants to iVillage, during the Initial Term of this Agreement, a royalty-free,
non-exclusive, worldwide license to use, reproduce and display Ford's tradenames, trademarks,
service marks and logos (collectively, the "Marks") in connection with this Agreement. No right,
title, license, or interest in any Marks owned by Ford or any of its affiliates is intended to be
given to or acquired by iVillage by the execution of or the performance of this Agreement. iVillage
shall not use the Marks for any purpose or activity except as expressly authorized or contemplated
herein;

10. Confidentiality. Except as expressly set forth herein, iVillage and FMM shall maintain in
confidence the terms of this Agreement. It is expected that, pursuant to discussions to date and to
this Agreement, the Parties may disclose to one another certain information ("Confidential
Information"), as defined herein, which is considered by the disclosing Party to be proprietary or
confidential information. Confidential Information is defined as any, information, communication or
data, in any form, including, but not limited to oral, written, graphic or electromagnetic forms,
models or samples, which the disclosing Party desires to protect against unrestricted disclosure or
use, including without limitation, business information, financial data and marketing data. All
Confidential Information shall remain the sole property, of the disclosing Party and its
confidentiality shall be maintained and protected by the receiving Party with the same degree of
care as the receiving Party uses for its own confidential and proprietary information and the
receiving Party shall not disclose such Confidential Information to any third party. The
restrictions of the use or disclosure of any Confidential Information shall not apply to any
Confidential Information: (i) after it has become generally available to the public without breach
of this Agreement by the receiving Party; (ii) is rightfully in the receiving Party's possession
prior to disclosure to it by the disclosing Party; (iii) is independently developed by the receiving
Party; (iv) is rightfully received by the receiving Party from a third party, without a duty of
confidentiality; or (v) is required to be disclosed under operation of law.

11. LIMITATION OF LIABILITY. NEITHER PARTY SHALL HAVE ANY LIABILITY HEREUNDER FOR ANY INDIRECT,
SPECIAL, PUNITIVE OR CONSEQUENTIAL DAMAGES INCLUDING, WITHOUT LIMITATION, LOSS OF PROFIT OR BUSINESS
OPPORTUNITIES, WHETHER OR NOT THE PARTY WAS ADVISED OF THE POSSIBILITY OF SUCH.

EXCEPT AS EXPRESSLY SET FORTH HEREIN, NEITHER PARTY MAKES ANY, AND EACH PARTY HEREBY SPECIFICALLY
DISCLAIMS ANY REPRESENTATIONS OR WARRANTIES, EXPRESS OR IMPLIED, REGARDING THE SERVICES CONTEMPLATED
BY THIS AGREEMENT, INCLUDING ANY
<!-- page 4 -->
IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE AND IMPLIED WARRANTIES
AFJSING FROM COURSE OF DEALING OR COURSE OF PERFORMANCE.

12. Indemnification.

A. iVillage agrees to indemnify, defend and hold harmless FMM and its client Ford Motor Company and
their respective parents, subsidiaries, affiliates, successors and assigns from any and all third
party losses, liabilities, damages, actions, claims, expenses and costs (including reasonable
attorneys' fees) which result or arise out of or in connection with the breach of this

5

Agreement by iVillage or which result or arise out of or in connection with any material supplied by
iVillage pursuant to this Agreement.

B. FMM agrees to indemnify, defend and hold harmless iVillage and its parent, subsidiaries,
affiliates, successors and assigns from any and all third party, losses, liabilities, damages,
actions, claims, expenses and costs (including reasonable attorneys' fees) which result or arise out
of or in connection with the breach of this Agreement by FMM or which result or arise out of or in
connection with any material supplied by FMM or its client Ford Motor Company pursuant to this
Agreement.

13. General Provisions.

A. Relationship of the Parties. Nothing contained herein shall imply any partnership, joint venture
or agency relationship between the Parties and neither Party shall have the power to obligate or
bind the other in any manner whatsoever, except to the extent herein provided.

B. Severability. If any provision of this Agreement shall be declared by any court of competent
Jurisdiction to be illegal, void or unenforceable, all other provisions of this Agreement shall not
be affected and shall remain in full force and effect.

C. Counterparts. This Agreement may be executed in any number of counterparts, each of which shall
be deemed to be an original and all of which together shall be deemed to be one and the same
instrument.

D. Notices. All notices, requests, demands, payments and other communications which are required or
may be given under this Agreement shall be in writing and shall be deemed to have been duly given if
delivered personally, telecopied or sent by nationally recognized overnight carrier, or mailed by
certified mail, postage prepaid, return receipt requested, as follows:

If to FMM:

Ford Motor Media 500 Woodward Avenue Detroit, Michigan 48226-3428 Attention: Carol Wright Tel: (313)
964-2954 Fax: (313) 964-2315

If to iVillage:

iVillage, Inc. 170 Fifth Avenue New York, New York 10010 Attention: Vice President Business/Legal
Affairs Tel: (212) 206-3106 Fax: (212) 604-9133

6

E. Force Majeur. Except as otherwise expressly provided in this Agreement, neither Party shall be
liable for any breach of this Agreement for any delay or failure of performance resulting from any
cause beyond such Party's reasonable control, including but not limited to the weather, strikes or
labor disputes (other than as set forth in Section 1.B), war, terrorist acts, riots or civil
disturbances, government regulations, acts of civil or military authorities, or acts of God provided
the Party affected takes all reasonably necessary steps to resume full performance. In the event
that the Network or the Bridge Site are unavailable for a substantial period of time due an event of
force majeur or otherwise, iVillage agrees to use commercially reasonable efforts to "make good" any
impressions lost as a result of such circumstance.

F. Entire Agreement. This Agreement (i) constitutes the binding agreement between the Parties, (ii)
represents the entire agreement between the Parties and supersedes all prior agreements relating to
the subject matter contained herein and (iii) may not be modified or amended except in writing
signed by the Parties.

G. Survival. The following sections shall survive any termination or expiration of this Agreement:
6, 7, 10, 11, 12 and 13.

H. Governing Law. Agreement shall be governed by, and construed in accordance with the laws of the
State of New York without regard to the conflicts of laws principles thereof.
<!-- page 5 -->
I. Assignment. Neither Party shall sell, transfer or assign this Agreement or the rights or
obligations hereunder, without the prior written consent of the other Party, such consent not to be
unreasonably withheld or delayed. Notwithstanding the foregoing, upon prior written notice by Ford
Motor Company to iVillage, this Agreement may be assigned by FMM to another advertising agency, and
in such event, FMM will be released from all financial and other obligations under this Agreement.

J. Headings. The headings of the various sections of this Agreement have been inserted for
convenience of reference only.

IN WITNESS WHEREOF, the Parties hereto have executed and delivered this Agreement as of the date
first above written.

7

FOR FORD CENTRAL MEDIA FOR iVILLAGE, INC.

/s/ Mark A. Kaline /s/ Steven Elkes - --------------------------------------
--------------------------------------- (Name) (Name

Media Manager Vice President Business/]Legal Affairs - --------------------------------------
--------------------------------------- (Title) (Title)

1/12/99 12/18/98 - -------------------------------------- ---------------------------------------
(Date) (Date)

/s/ Mark A. Kaline /s/ Steven Elkes - --------------------------------------
--------------------------------------- (Signature) (Signature)

8

EXHIBIT A ---------

Third Party Traffic Auditors

ABC I/PRO PWC DoubleClick

9
