<!-- page 1 -->
# RECIPE DEVELOPMENT AGREEMENT
| Field | Value |
|---|---|
| Document Type | Development Agreement |
| Agreement Date | 2019-10-11 |
| Parties | Reed's, Inc. ("Reed's"); BC Marketing Concepts Inc., dba Full Sail Brewing Company ("Company") |
| Source | CUAD v1 / ReedsInc_20191113_10-Q_EX-10.4_11888303_EX-10.4_Development Agreement |

RECIPE DEVELOPMENT AGREEMENT This Recipe Development Agreement (this "Agreement") is made between
Reed's, Inc., a Delaware corporation ("Reed's") and B C Marketing Concepts Inc., dba Full Sail
Brewing Company, an Oregon corporation ("Company"), effective as of October 11, 2019 (the "Effective
Date"). RECITALS Company is engaged in the business of developing recipes for and manufacturing
alcohol beverage products. Reed's is engaged in the business of developing recipes for ginger-based
non- alcohol beverage products. Reed's desires to engage Company, and Company desires to be engaged,
to participate and assist in the development of formulas for ginger-based flavored alcohol beverage
products for Reed's (the "Products") as identified in Exhibit A. AGREEMENT The parties agree as
follows: 1. Definitions. Unless otherwise defined in this Agreement, words with initial capitalized
letters shall have the meanings assigned to such words in this Section 1: (a) "Applicable Laws and
Regulations" shall mean any law, statute, rule, regulation, ordinance or other binding
pronouncements of any duly authorized court, tribunal, arbitrator, agency, commission, official or
other instrumentality of any federal, state, province, county, city or other political subdivision
(domestic or foreign) having the effect of law in the United States, any foreign country or
territory or any domestic or foreign state, province, county, city or other political subdivision
applicable to the Company or its business. (b) "Company Intellectual Property" means all
Intellectual Property that: (i) was owned or developed by Company prior to the execution of this
Agreement; and (ii) is or was independently developed or acquired by Company without contribution or
assistance from Reed's, Reed's Confidential Information, or Reed's Intellectual Property. Company
Intellectual Property includes but is not limited to Company's know-how and independently developed
recipes and alcohol beverage production processes, including the Company's proprietary composition
of or recipe for the neutral alcohol beverage base that contributes alcohol to the Products
("Neutral Alcohol Beverage Base"). (c) "Deliverables" means (a) any Recipe, (b) documentation,
samples, prototypes and other tangible embodiments of or descriptions of Recipes, and (c) any other
Intellectual Property created with during the term of this Agreement and required to be disclosed to
the Development Committee as contemplated by Section 1(b) hereof. (d) "Intellectual Property" means
any and all domestic and international rights in and to: (i) trademarks, service marks, trade dress,
logos, trade names and Internet domain names, together with all goodwill associated therewith; (ii)
patents, patent disclosures, patentable subject matter, inventions, any improvements thereto and
know-how; (iii) copyrights, copyrightable works, derivative works thereof and moral rights; (iv)
trade secrets and confidential information; (v) other intellectual proprietary property (of every
kind and nature and however designated), whether arising by operation of law, contract, license or
otherwise; and (vi) all registrations, applications, renewals, extensions, continuations,
continuations-in-part, divisions or reissues of the foregoing now or hereafter in force or hereafter
acquired or adopted.

Source: REED'S, INC., 10-Q, 11/13/2019
<!-- page 2 -->
(e) "Recipe" means the ingredients and methods of combining and processing ingredients for the
Products, provided that a Recipe will not include the composition of or recipe for the Neutral
Alcohol Beverage Base (it being understood that the amount of Neutral Alcohol Beverage Base and the
process for combining and processing it with other ingredients shall be included in the Recipe). (f)
"Reed's Intellectual Property" means all Intellectual Property that: (i) was owned or developed by
Reed's prior to the execution of this Agreement; (ii) was or is independently developed by Reed's
without contribution or assistance from Company or Company's Intellectual Property; and (iii) the
Recipe. (g) "Specifications" means the specifications for the Products to be developed by the
Development Committee (as defined in Section 3). 2. Consideration. In exchange for Company's
contributions and obligations under this Agreement, Reed's grants Company the exclusive right to
manufacture, package, promote, sell and distribute the Products (if and to the extent approved by
the Development Committee), subject to the terms and conditions of a separate Manufacturing and
Distribution Agreement to be entered into by the parties concurrently with this Agreement, as it may
be amended, modified, supplemented or restated from time to time (the "Manufacturing and
Distribution Agreement"). Company shall be responsible for all costs relating to the development of
the Recipes and Deliverables, except for costs and expenses relating to the involvement of Reed's
personnel and contractors. 3. Development Committee. Representatives of Company and Reed's, as
identified in Exhibit B, shall meet regularly to discuss and approve development milestones for the
Products, the Recipes, Deliverables, Specifications and other topics as identified in Exhibit B (the
"Development Committee"). The final Recipes, Deliverables and Specifications for the Products must
be agreed to in writing by at least one member of the Development Committee from each of Reed's and
Company. 4. Rights and Obligations. (a) The parties will collaborate to develop commercial
production-ready Products according to the Specifications as may be developed by the Development
Committee. Reed's shall have the right to visit the facilities used by Company to develop the
Recipes and Deliverables, at such times as may be reasonably agreed to in advance by the parties.
Company shall perform the work in connection with this Agreement in a timely, professional and
workmanlike manner consistent with industry standards. Each party shall ensure that all persons
performing work under this Agreement on its behalf shall have the requisite experience, training,
skill and other qualifications needed to develop the Recipes, Deliverables and Specifications.
Company shall keep the Development Committee informed of the progress of the development of the
Recipes and Deliverables and such other matters as any member of the Development Committee may
reasonably request from time to time. 2

Source: REED'S, INC., 10-Q, 11/13/2019
<!-- page 3 -->
(b) Company shall promptly disclose to the Development Committee any prospective or actual new
Intellectual Property related to the Products or Product-specific production processes, whether
developed solely by Company or jointly by the Company and Reed's, except with regard to the Neutral
Alcohol Beverage Base, and except with regard to the Company's general know-how and independently
developed production processes not specifically related to the Products. 5. Representations and
Warranties. (a) By Company. Company represents and warrants that (i) Company has obtained all
authority, permits, licenses and approvals necessary to enter into and perform its obligations under
this Agreement; (ii) the execution and delivery by Company of this Agreement and the performance of
its obligations under this Agreement does not and will not violate the terms of any other contract,
agreement, obligation or understanding of Company or any Applicable Laws and Regulations; (iii) the
Deliverables will conform to the Specifications; and (iv) the Company's Intellectual Property does
not infringe or violate the Intellectual Property of any third parties. (b) By Reed's. Reed's
represents and warrants that (i) Reed's has obtained all authority and approvals necessary to enter
into and perform its obligations under this Agreement; (ii) the execution and delivery by Company of
this Agreement and the performance of its obligations under this Agreement does not and will not
violate the terms of any other contract, agreement, obligation or understanding of Reed's or any law
or regulation applicable to Reed's; and (iii) the Reed's Intellectual Property does not infringe or
violate the Intellectual Property of any third parties. 6. Intellectual Property. (a) Ownership of
Intellectual Property. (i) Company will create and provide to Reed's the Deliverables. Reed's will
exclusively own all Deliverables. Company will and hereby does, without further consideration,
irrevocably assign to Reed's any and all worldwide right, title or interest that Company may now or
hereafter possess in or to the Deliverables in perpetuity (or the maximum period permitted by
Applicable Laws and Regulations) and Reed's accepts such assignment. Company will execute and
deliver documents reasonably requested by Reed's to register its Intellectual Property in the
Deliverables. (ii) Company acknowledges that all rights of ownership of Reed's Intellectual
Property, Deliverables and the goodwill symbolized thereby shall belong exclusively to and inure to
the benefit of Reed's. Company shall not at any time acquire any rights, title or interest in Reed's
Intellectual Property or Deliverables. Company agrees that it will not at any time contest the
ownership or validity of any Reed's Intellectual Property or Deliverables, nor register or attempt
to register any rights with respect to Reed's Intellectual Property, nor do anything that would
jeopardize or diminish Reed's rights to or the value of Reed's Intellectual Property or
Deliverables. (iii) Reed's acknowledges that all rights of ownership of Company's Intellectual
Property and the goodwill symbolized thereby shall belong exclusively to and inure to the benefit of
Company. Reed's shall not at any time acquire any rights, title or interest in Company's
Intellectual Property. Reed's agrees that it will not at any time contest the ownership or validity
of any Company Intellectual Property, nor register or attempt to register any rights with respect to
Company Intellectual Property, nor do anything that would jeopardize or diminish Company's rights to
or the value of Company Intellectual Property. 3

Source: REED'S, INC., 10-Q, 11/13/2019
<!-- page 4 -->
(b) Work Product. Company acknowledges and agrees that all Intellectual Property created by Company,
its affiliates, representatives, or agents in connection with or resulting from any work or services
related to the Products, including the Deliverables ("Work Product"), but excluding the Neutral
Alcohol Beverage Base and excluding the Company's general know-how and independently developed
production processes not specifically related to the Products, have been specially ordered and
commissioned by Reed's, are works-made-for-hire from the moment of creation and that all such Work
Product is and will be the sole and exclusive property of Reed's. To the extent not a work-for-
hire, Company, its employees, subcontractors and agents hereby sell, assign and transfer to Reed's
all right, title and interest in and to the Work Product, including without limitation, all rights
to Intellectual Property therein. Company agrees on behalf of itself, its employees, subcontractors
and agents, not to file for or register any patents, trademarks, or copyrights in or to the Work
Product. No rights of any kind in the Work Product are reserved to or by Company or will revert to
Company. To the extent permitted by Applicable Laws and Regulations, Company forever waives and
agrees never to assert any "moral rights" in any Work Product or any derivative of any Work Product.
Company shall, without further compensation, execute and deliver such instruments and take such
action as may be requested by Reed's to perfect, protect, enforce or evidence Reed's rights in the
Work Product, Products and Deliverables and to carry out the assignments and waivers in this Section
6. (c) Use. Company shall not use the Work Product, Products or Deliverables during the term of this
Agreement or after, in perpetuity, for any purpose whatsoever other than performing Company's
obligations under this Agreement. The Deliverables shall be considered to be Confidential
Information (as defined below) of Reed's. This Section 6 shall survive termination or expiration of
this Agreement. 7. Confidentiality. Each of Reed's and Company (a "Receiving Party") shall hold in
confidence and not make any commercial or other use of any or all Confidential Information conveyed,
acquired or learned from the other party (the "Disclosing Party") at any time, except in association
with this Agreement. Except as otherwise expressly permitted herein, Receiving Party shall not
disclose such information to third persons without the prior written consent of the Disclosing
Party. Receiving Party shall limit access to the Confidential Information to those of its directors,
officers, employees, contractors, agents, attorneys and accountants (the "Representatives") with the
need to know the same and shall advise such Representatives of, and hold them to, Receiving Party's
obligations under the terms of this Section 7. Receiving Party and its Representatives shall be
permitted to disclose Confidential Information as required by law, including to any judicial,
regulatory, administrative or other governmental body (by interrogatories, investigative demands,
requests for information or documents, subpoena, or other similar process), but must (to the extent
legally permissible) promptly notify the disclosing party of the existence, terms and circumstances
surrounding such requirement and give the disclosing party a reasonable opportunity to obtain a
protective order or other appropriate remedy to resist or narrow such disclosure. "Confidential
Information" means all information of Disclosing Party that is disclosed orally or in writing by
Disclosing Party to Receiving Party that, at the time of disclosure, is designated as confidential
(or like designation), is disclosed in circumstances of confidence, would be understood by the
parties, exercising reasonable business judgment, to be confidential, or is not generally known to
the public, whether of a business, technical, or other nature, and including, without limitation,
designs, plans, drawings, know-how, recipes, and marketing and business plans. Upon the expiration
or earlier termination of this Agreement, Receiving Party shall return to Disclosing Party all of
Disclosing Party's Confidential Information or shall destroy the same at the option of Disclosing
Party. The provisions of this Section 7 shall survive termination or expiration of this Agreement.
The obligations in this Section 7 regarding trade secrets, in particular, will continue for so long
as the information constitutes a trade secret under applicable law. If an unauthorized use or
disclosure of a Disclosing Party's Confidential Information occurs, the Receiving Party shall
promptly notify the Disclosing Party, and the Disclosing Party may take, at the Receiving Party's
expense, all steps which are necessary to recover Confidential Information disclosed or used in
breach of this Agreement and to prevent its subsequent unauthorized use or dissemination, including
availing itself of actions for seizure and injunctive relief. 4

Source: REED'S, INC., 10-Q, 11/13/2019
<!-- page 5 -->
8. Term; Termination. (a) Term. The term of this Agreement shall commence on the Effective Date and
shall continue for the longer of the first anniversary of the Effective Date or the duration of the
Manufacturing and Distribution Agreement (the "Term"). The Term may be extended by written agreement
of the parties. (b) Early Termination. Either party may terminate this Agreement at any time if any
of the following occur: (i) the other party fails to comply with any requirements or obligations
under this Agreement, and such non-compliance is not cured within 30 days following written notice
from the other party identifying the non-compliance; (ii) the other party becomes insolvent,
reorganizes or liquidates; (iii) the other party makes any assignment for the benefit of Company's
creditors; or (iv) a receiver is appointed for Company's property. Either party may terminate this
Agreement upon written notice if the Manufacturing and Distribution Agreement terminates prior to
the first anniversary of the Effective Date. 9. Indemnification. Each party will indemnify, defend
and hold harmless the other party and its respective directors, officers, members, employees,
licensees, agents and independent contractors, from and against any claim or action, liability,
damages, and expense, including but not limited to attorney's fees, arising from or resulting from
(i) the negligent act or omission of the party, its employees, agents or contractors, (ii) the
party's breach of this Agreement, or (iii) the violation of any law by the party, its employees,
agents, or contractors. Reed's will indemnify, defend and hold harmless Company and its directors,
officers, members, employees, licensees, agents and independent contractors, from and against any
claims for the breach of the intellectual property rights of a third party based on the Reed's
Intellectual Property. Company will indemnify defend and hold harmless Reed's and its directors,
officers, members, employees, licensees, agents and independent contractors, from and against any
claims for the breach of the intellectual property rights of a third party based on the Company
Intellectual Property, Deliverables and Work Product, except as such claims are solely based on or
limited to the Reed's Intellectual Property. 10. Limitation of Liability. EXCEPT WITH RESPECT TO THE
INDEMNIFICATION OBLIGATIONS SET FORTH IN SECTION 9 WITH REGARD TO CLAIMS BY THIRD PARTIES, IN NO
EVENT SHALL EITHER PARTY BE LIABLE FOR CONSEQUENTIAL, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY,
PUNITIVE OR ENHANCED DAMAGES, LOST PROFITS OR REVENUES OR DIMINUTION IN VALUE ARISING OUT OF,
RELATING TO, OR IN CONNECTION WITH ANY BREACH OF THIS AGREEMENT OR CLAIM HEREUNDER, REGARDLESS OF
(A) WHETHER SUCH DAMAGES WERE FORESEEABLE, (B) WHETHER OR NOT IT WAS ADVISED OF THE POSSIBLITY OF
SUCH DAMAGES, AND (C) THE LEGAL OR EQUITABLE THEORY (CONTRACT, TORT OR OTHERWISE) UPON WHICH THE
CLAIM IS BASED. 5

Source: REED'S, INC., 10-Q, 11/13/2019
<!-- page 6 -->
11. Press Releases; Publicity. Reed's may issue or cause the publication of any press release or
other public announcement with respect to this Agreement or the relationship of the parties, subject
to Company's prior approval of any such press release or other public announcement which shall not
be unreasonably withheld, conditioned or delayed, it being understood that such consent shall not be
required in the case of any public announcement required by any law, regulation, regulatory body or
the rules of any exchange to which Reed's is or may become subject. Company shall not publicly
identify Reed's or use Reed's name in any manner in connection with this Agreement without Reed's
prior written approval. 12. Independent Contractors. Company and Reed's agree that neither party has
authority to bind the other party as its agent. Company and Reed's recognize and agree that Company
is not an employee of Reed's and is furnishing services as an independent contractor. This Agreement
does not constitute and shall not be construed as constituting a partnership or joint venture or
grant of a franchise between Reed's and Company. Neither party shall have the right to bind the
other party to any obligations to third parties. 13. Assignment. Company may not assign or transfer
its rights or obligations under this Agreement, whether by operation of law, contract or otherwise,
without the prior written consent of Reed's, which shall not be unreasonably withheld (it being
understood that a purported assignment to a Reed's competitor identified or referred to in Exhibit D
of the Manufacturing and Distribution Agreement shall be considered to be a reasonable basis for
withholding consent). This Agreement shall be binding on and inure to the benefit of the parties and
their heirs, personal representatives, successors, and assigns. 14. Governing Law; Venue. This
Agreement shall be governed by, and any dispute arising hereunder shall be determined in accordance
with, the laws of State of New York (without giving effect to conflict of laws principles) including
all matters of construction, validity and performance. The parties agree that any claim or dispute
arising under this Agreement shall be resolved by a court located in New York City, New York. 15.
Force Majeure. No party shall be liable or responsible to the other party, nor be deemed to have
defaulted under or breached this Agreement, for any failure or delay in fulfilling or performing any
term of this Agreement (except for any obligations to make payments to the other party hereunder),
when and to the extent such failure or delay is caused by or results from the following force
majeure events ("Force Majeure Events"): (a) acts of God; (b) flood, fire, earthquake or explosion;
(c) war, invasion, hostilities (whether war is declared or not), terrorist threats or acts, riot or
other civil unrest; (d) government order or law; (e) actions, embargoes or blockades in effect on or
after the date of this Agreement; (f) action by any governmental authority; (g) national or regional
emergency; (h) strikes, labor stoppages or slowdowns or other industrial disturbances; (i) shortage
of adequate power or transportation facilities; and (j) other similar events beyond the reasonable
control of the party impacted by the Force Majeure Event (the "Impacted Party"). The Impacted Party
shall give notice within seven (7) days of the Force Majeure Event to the other party, stating the
period of time the occurrence is expected to continue. The Impacted Party shall use diligent efforts
to end the failure or delay and ensure the effects of such Force Majeure Event are minimized. The
Impacted Party shall resume the performance of its obligations as soon as reasonably practicable and
to the greatest extent possible after the removal of the cause. In the event that the Impacted
Party's failure or delay remains uncured for a period of thirty (30) days following written notice
given by it under this Section 15, either party may thereafter terminate this Agreement upon thirty
(30) days' written notice. 6

Source: REED'S, INC., 10-Q, 11/13/2019
<!-- page 7 -->
16. Integration, Severability and Amendment. This Agreement (including the exhibits) sets forth the
entire understanding of the parties with respect to the subject matter of this Agreement and
supersedes any and all prior understandings and agreements, whether written or oral, between the
parties with respect to such subject matter. This Agreement will be deemed severable, and the
invalidity or unenforceability of any term or provision hereof will not affect the validity or
enforceability of this Agreement or any other term herein. This Agreement may not be amended or
otherwise modified except in a written agreement signed by each party. 17. Waiver. A provision of
this Agreement may be waived only by a written instrument executed by the party waiving compliance.
No waiver of any provision of this Agreement shall constitute a waiver of any other provision,
whether or not similar, nor shall any waiver constitute a continuing waiver. Failure of either party
to exercise promptly any right, power or privilege granted by this Agreement, or to require strict
performance of any obligation undertaken by the other party pursuant to this Agreement, will not be
deemed to be a waiver of such right, power or privilege or of the right to demand subsequent
performance of any and all such obligations undertaken by the other party. 18. Notice. Any notice,
request or demand to be made under this Agreement shall be in writing and shall be deemed to have
been duly made (a) upon delivery, if delivered personally (by courier service or otherwise), as
evidenced by written receipt or other written proof of delivery (which may be a printout of the
tracking information of a courier service that made such delivery), or (b) five (5) days after
deposit in the mail, if sent by certified or registered mail with return receipt requested, postage
prepaid, addressed to the party for whom intended at the address listed on the signature page. A
party may change its address for the purposes of this Section 18 by written notice hereunder given
to the other party. 19. Further Documentation. Each party agrees, at the reasonable request of the
other, to promptly execute and deliver all such further documents, and to promptly take or forbear
from all such action, as may be reasonably necessary or appropriate in order to more effectively
confirm or carry out the provisions of this Agreement. 20. Survival. Sections 6, 7, 9, 10 and 14-24
of this Agreement shall survive the termination or expiration of this Agreement. To the extent that
Company receives any trade secrets of Reed's, Company's obligation to protect such trade secrets and
abide by the terms of Section 7 shall survive for so long as such information is a bona fine trade
secret pursuant to the laws of the governing jurisdiction identified in Section 14. 21. Remedies.
All rights and remedies of either party hereto are cumulative of each other and of every other right
or remedy such party may otherwise have at law or in equity, and the exercise of one or more rights
or remedies shall not prejudice or impair the concurrent or subsequent exercise of other rights or
remedies. The parties acknowledge that any material breach, including without limitation the
disclosure of Confidential Information, will cause irreparable injury. In addition to any other
legal or equitable remedies that may be available, either party will be able to obtain immediate
injunctive relief in the form of a temporary restraining order, preliminary injunction or permanent
injunction against the other party to enforce the terms of this Agreement. 22. Fees and Expenses.
Each party shall be responsible for its own fees and expenses in connection with the preparation and
execution of this Agreement. 23. Headings. The headings contained in this Agreement are for the
purposes of convenience only and are not intended to define or limit the contents of this Agreement.
24. Counterparts. This Agreement may be executed in more than one counterpart, each of which shall
be deemed to be an original, but all of which together shall constitute one and the same instrument.
[Signature Page immediately follows] 7

Source: REED'S, INC., 10-Q, 11/13/2019
<!-- page 8 -->
The parties set forth below have executed this Agreement as of the Effective Date. REED'S: COMPANY:
Reed's, Inc. B C Marketing Concepts Inc., dba Full Sail Brewing Company By: /s/ John Bello By: /s/
Cory Comstock Name: John Bello Name: Cory Comstock Title: CEO Title: CEO Address: Address: Reed's,
Inc. B C Marketing Concepts Inc. dba Full Sail Attn: John Bello Brewing Company 201 Merritt 7 Attn:
Cory Comstock Norwalk, CT 06851 506 Columbia Street Hood River, OR 97031 Amended and Restated Recipe
Development Agreement - Signature Page 8

Source: REED'S, INC., 10-Q, 11/13/2019
<!-- page 9 -->
EXHIBIT A Products 1. Ready-to-drink Mule: Specifications to be determined by the Development
Committee 2. Ready-to-drink Hard Ginger Seltzer: Specifications to be determined by the Development
Committee Amended and Restated Recipe Development Agreement - Exhibit A

Source: REED'S, INC., 10-Q, 11/13/2019
<!-- page 10 -->
EXHIBIT B Development Committee Committee Members For Company: ● Brewmaster ● Director of Quality ●
Director of Marketing For Reed's: ● Vice President, Marketing ● Vice President, Sales ● Vice
President, Operations Committee Meetings Until the Products are initially launched on a commercial
basis, the Development Committee will confer (in person at the Company's brewery, or by telephone)
at least weekly, and thereafter will confer (in person at the Company's brewery, or by telephone) at
least monthly or as otherwise agreed by the Development Committee. Topics and Responsibilities
Topics and responsibilities for each meeting will be determined by Development Committee prior to a
meeting. Amended and Restated Recipe Development Agreement - Exhibit B

Source: REED'S, INC., 10-Q, 11/13/2019
<!-- page 11 -->
Source: REED'S, INC., 10-Q, 11/13/2019
