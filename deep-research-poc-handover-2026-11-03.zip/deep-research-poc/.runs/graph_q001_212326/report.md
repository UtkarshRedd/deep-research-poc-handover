# What is the maximum Leverage Ratio Acme Industrial must maintain under the original Cre...

*Question:* What is the maximum Leverage Ratio Acme Industrial must maintain under the original Credit Agreement?

## Identify the original Credit Agreement

The original Credit Agreement governs the borrower's financial covenants, and the Leverage Ratio covenant is confirmed by a conformed copy. [9ef8d980f49f4881 p.2] The conformed copy states that the Borrower shall maintain a Leverage Ratio not exceeding 3.50 to 1.00. [9ef8d980f49f4881 p.2] Therefore, the maximum Leverage Ratio under the original Credit Agreement is 3.50 to 1.00. [9ef8d980f49f4881 p.2]

[GAP] The evidence does not identify Acme Industrial as the Borrower.

## Determine the maximum Leverage Ratio

Under Section 3 (Financial Covenants) of the original Credit Agreement, the Borrower shall maintain a Leverage Ratio not exceeding 3.50 to 1.00. [3d26d475d8120e5c p.2] This establishes 3.50 to 1.00 as the maximum Leverage Ratio permitted. [3d26d475d8120e5c p.2]

## Verification appendix

Claims: 6 · supported: 5 · partially: 0 · dropped: 0 · gaps: 1 · tier-1 support rate: 1.00

| claim | section | tier 1 | score | sources | note |
|---|---|---|---|---|---|
| s1.1 | s1 | keep | 1.00 | e2→[9ef8d980f49f4881 p.2] |  |
| s1.2 | s1 | keep | 1.00 | e2→[9ef8d980f49f4881 p.2] |  |
| s1.3 | s1 | keep | 1.00 | e2→[9ef8d980f49f4881 p.2] |  |
| s1.4 | s1 | gap |  |  |  |
| s2.1 | s2 | keep | 1.00 | e1→[3d26d475d8120e5c p.2] |  |
| s2.2 | s2 | keep | 1.00 | e1→[3d26d475d8120e5c p.2] |  |

### Evidence

- e1 [3d26d475d8120e5c p.2 L16-17] keep (1.0): "## 3. Financial Covenants
Borrower shall maintain a Leverage Ratio not exceeding 3.50 to 1.00."
- e2 [9ef8d980f49f4881 p.2 L14-16] keep (1.0): "Borrower shall maintain a Leverage Ratio not exceeding 3.50 to 1.00."
