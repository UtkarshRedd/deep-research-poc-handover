"""Ephemeral per-query BM25 over paragraph chunks (Approach 1, PLAN Phase 4).

Built lazily from the workspace, lives in memory for ONE query and is never persisted
(CLAUDE.md: no persistent index; an in-memory BM25 built in seconds is a tool). Chunks are
~BM25_CHUNK_TOKENS, cut at headings and blank lines, prefixed with the document title and the
current heading (contextual prefix), and carry doc_id + line range + page so a hit is directly
readable with `read`. Rankings are cached to depth BM25_DEEP_K per query so the agent can page
the full list (Pi-Serini: surfaced recall 70 -> 96% from depth 5 to 1,000).
"""
from __future__ import annotations

import re
import time
from dataclasses import dataclass

from ..config import DEFAULT, Config
from ..models import SearchHit, SearchResult
from ..workspace import Workspace

_HEADING_RE = re.compile(r"^#{1,6}\s+(.+?)\s*#*\s*$")
# Our own tokenizer (not bm25s's): keeps identifiers such as FAC-2024-0117 and 3.50 as single
# tokens so exact ids and amounts rank precisely; lowercase; English stopwords removed.
_TOKEN_RE = re.compile(r"[a-z0-9]+(?:[.\-][a-z0-9]+)*")


def tokenize(text: str, stopwords: frozenset[str]) -> list[str]:
    return [w for w in _TOKEN_RE.findall(text.lower()) if w not in stopwords]


@dataclass(frozen=True)
class Chunk:
    idx: int
    doc_id: str
    start_line: int
    end_line: int
    page: int | None
    heading: str
    body: str


def chunk_document(ws: Workspace, doc_id: str, max_tokens: int, page_re: re.Pattern) -> list[Chunk]:
    """Cut one document into chunks at headings / blank lines once ~max_tokens accumulate."""
    lines = ws.lines(doc_id)
    chunks: list[Chunk] = []
    heading = ""
    buf: list[tuple[int, str]] = []
    size = 0

    def flush() -> None:
        nonlocal buf, size
        body_lines = [(i, ln) for i, ln in buf if ln.strip()]
        if body_lines:
            s, e = body_lines[0][0], body_lines[-1][0]
            chunks.append(Chunk(idx=len(chunks), doc_id=doc_id, start_line=s, end_line=e,
                                page=ws.page_of(doc_id, s), heading=heading,
                                body="\n".join(ln for _, ln in body_lines)))
        buf, size = [], 0

    for i, ln in enumerate(lines, start=1):
        if page_re.match(ln):
            continue
        m = _HEADING_RE.match(ln)
        if m:
            flush()
            heading = m.group(1)[:120]
            buf.append((i, ln))
            size += max(1, len(ln) // 4)
            continue
        if size >= max_tokens and not ln.strip():
            flush()
            continue
        buf.append((i, ln))
        size += max(1, len(ln) // 4)
        if size >= 2 * max_tokens:   # no blank line in sight: hard cut
            flush()
    flush()
    return chunks


class BM25Index:
    def __init__(self, ws: Workspace, config: Config = DEFAULT, doc_ids: list[str] | None = None):
        import bm25s

        self.ws, self.cfg = ws, config
        caps = config.tools
        t0 = time.perf_counter()
        page_re = re.compile(config.PAGE_MARKER_RE)
        self.chunks: list[Chunk] = []
        texts: list[str] = []
        for doc_id in doc_ids or ws.doc_ids():
            title = ws.manifest[doc_id].title
            for c in chunk_document(ws, doc_id, caps.BM25_CHUNK_TOKENS, page_re):
                c = Chunk(idx=len(self.chunks), doc_id=c.doc_id, start_line=c.start_line, end_line=c.end_line,
                          page=c.page, heading=c.heading, body=c.body)
                self.chunks.append(c)
                texts.append(f"{title} | {c.heading}\n{c.body}" if c.heading else f"{title}\n{c.body}")
        from bm25s.stopwords import STOPWORDS_EN

        self._stop = frozenset(STOPWORDS_EN)
        self._retriever = bm25s.BM25(k1=caps.BM25_K1, b=caps.BM25_B)
        if texts:
            self._retriever.index([tokenize(t, self._stop) for t in texts], show_progress=False)
        self._cache: dict[str, list[SearchHit]] = {}
        self.build_ms = int((time.perf_counter() - t0) * 1000)

    # ------------------------------------------------------------------ queries

    def ranking(self, query: str) -> list[SearchHit]:
        """Cached ranking to depth BM25_DEEP_K (hits with a positive score only)."""
        key = " ".join(query.split()).lower()
        if key in self._cache:
            return self._cache[key]
        hits: list[SearchHit] = []
        n = min(self.cfg.tools.BM25_DEEP_K, len(self.chunks))
        q = tokenize(key, self._stop)
        if n > 0 and q:
            idxs, scores = self._retriever.retrieve([q], k=n, show_progress=False)
            for rank, (i, s) in enumerate(zip(idxs[0].tolist(), scores[0].tolist()), start=1):
                if s <= 0:
                    break
                c = self.chunks[int(i)]
                hits.append(SearchHit(rank=rank, doc_id=c.doc_id, start_line=c.start_line, end_line=c.end_line,
                                      page=c.page, score=round(float(s), 3), snippet=self._snippet(c)))
        self._cache[key] = hits
        return hits

    def search(self, query: str, k: int | None = None) -> SearchResult:
        return self.page(query, 1, page_size=k)

    def page(self, query: str, page: int, page_size: int | None = None) -> SearchResult:
        size = self.cfg.tools.BM25_PAGE_SIZE if not page_size else max(1, min(page_size, self.cfg.tools.BM25_PAGE_SIZE * 3))
        ranked = self.ranking(query)
        page = max(1, page)
        start = (page - 1) * size
        hits = ranked[start : start + size]
        return SearchResult(query=query, total_ranked=len(ranked), page=page, page_size=size, hits=hits,
                            has_more=start + size < len(ranked))

    def _snippet(self, c: Chunk) -> str:
        n = self.cfg.tools.BM25_SNIPPET_CHARS
        body = " ".join(c.body.split())
        return body if len(body) <= n else body[:n] + "…"

    def doc_token_estimate(self, doc_id: str) -> int:
        return sum(max(1, len(c.body) // 4) for c in self.chunks if c.doc_id == doc_id)

    def expand_query(self, query: str, feedback_docs: int = 3, n_terms: int = 5) -> str:
        """Pseudo-relevance feedback (Question's Gambit): borrow the most frequent terms of the
        top `feedback_docs` chunks that are not already in the query, so a clue written in the
        question's words picks up the documents' own vocabulary. Returns the original query when
        there is nothing to add. Query-time only: nothing is fitted to a corpus."""
        if n_terms <= 0 or feedback_docs <= 0:
            return query
        hits = self.ranking(query)[:feedback_docs]
        if not hits:
            return query
        have = set(tokenize(query, self._stop))
        counts: dict[str, int] = {}
        docs_with: dict[str, int] = {}
        for h in hits:
            seen_here: set[str] = set()
            for t in tokenize(self.chunks[self._chunk_index(h)].body, self._stop):
                if t in have or len(t) < 3 or t.isdigit():
                    continue
                counts[t] = counts.get(t, 0) + 1
                if t not in seen_here:
                    seen_here.add(t)
                    docs_with[t] = docs_with.get(t, 0) + 1
        ranked = sorted(counts, key=lambda t: (docs_with[t], counts[t], -len(t)), reverse=True)
        extra = ranked[:n_terms]
        return (query + " " + " ".join(extra)).strip() if extra else query

    def _chunk_index(self, hit: SearchHit) -> int:
        for c in self.chunks:
            if c.doc_id == hit.doc_id and c.start_line == hit.start_line:
                return c.idx
        return 0


def render(res: SearchResult) -> str:
    """Compact text rendering for the model."""
    if not res.hits:
        return f"search /{res.query}/: no ranked chunks (page {res.page} of {res.total_ranked} ranked)"
    out = [f"search /{res.query}/: page {res.page}, hits {res.hits[0].rank}-{res.hits[-1].rank} of {res.total_ranked} ranked chunks"
           + (f"; page_results(query, page={res.page + 1}) for more" if res.has_more else "")]
    for h in res.hits:
        pg = f" p.{h.page}" if h.page else ""
        out.append(f"{h.rank}. [{h.doc_id}:{h.start_line}-{h.end_line}{pg}] ({h.score}) {h.snippet}")
    return "\n".join(out)
