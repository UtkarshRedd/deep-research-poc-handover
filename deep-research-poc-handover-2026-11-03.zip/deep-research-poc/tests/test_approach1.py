"""Approach 1 pieces, deterministic: BM25 index + paging, search tools, first move (fallback and
scripted clues), router guards, researcher with the A1 tool set, and the A1 graph end to end."""
import json
import time
import uuid
from dataclasses import replace
from pathlib import Path

import pytest
from langchain_core.messages import AIMessage, SystemMessage, ToolMessage
from test_perf import _synthetic

from dr.agents.first_move import decompose, fallback_clues, first_move, run_first_move
from dr.agents.researcher import A1_TOOLS, ResearchContext, ResearchLoop
from dr.agents.router import RouteJSON, apply_guards, route
from dr.config import DEFAULT
from dr.evidence import EvidenceBank
from dr.graph import Pipeline
from dr.ingest.load import load_dir
from dr.llm import get_scripted_llm
from dr.models import Clue, FirstMoveResult
from dr.structured import ModelCaller
from dr.tools.bm25 import BM25Index, render
from dr.tools.read import ReadTracker
from dr.trace import Trace
from dr.workspace import Workspace

SAMPLE = Path(__file__).resolve().parents[1] / "data" / "sample_docs"
QUOTE = "Borrower shall maintain a Leverage Ratio not exceeding 3.50 to 1.00."


@pytest.fixture()
def docs():
    return load_dir(SAMPLE)


@pytest.fixture()
def ws(tmp_path, docs):
    return Workspace.materialize(docs, tmp_path / "ws")


@pytest.fixture()
def ids(ws):
    by_title = {m.title: d for d, m in ws.manifest.items()}
    return {"a": by_title["Credit Agreement — Acme Industrial LLC"],
            "m": next(d for t, d in by_title.items() if t.startswith("First Amendment"))}


def tc(name, args):
    return {"name": name, "args": args, "id": f"call_{uuid.uuid4().hex[:8]}", "type": "tool_call"}


def ai(*calls, content=""):
    return AIMessage(content=content, tool_calls=list(calls))


# --------------------------------------------------------------------------- BM25

def test_bm25_chunks_search_and_paging(ws, ids):
    ix = BM25Index(ws)
    assert ix.chunks and all(c.start_line <= c.end_line and c.body for c in ix.chunks)
    assert all(c.page is not None for c in ix.chunks)                   # page markers are never chunk text
    res = ix.search("leverage ratio covenant")
    assert res.total_ranked == 3 and res.hits[0].doc_id == ids["a"] and res.hits[0].page == 2
    assert "3.50 to 1.00" in res.hits[0].snippet and res.hits[0].rank == 1
    txt = render(res)
    assert txt.startswith("search /leverage ratio covenant/") and f"[{ids['a']}:16-17 p.2]" in txt
    small = replace(DEFAULT, tools=replace(DEFAULT.tools, BM25_PAGE_SIZE=2))
    ix2 = BM25Index(ws, small)
    p1, p2, p3 = ix2.page("leverage ratio", 1), ix2.page("leverage ratio", 2), ix2.page("leverage ratio", 3)
    assert [h.rank for h in p1.hits] == [1, 2] and p1.has_more and [h.rank for h in p2.hits] == [3] and not p2.has_more
    assert p3.hits == [] and "no ranked chunks" in render(p3)
    assert ix.search("zzzz qqqq").total_ranked == 0
    assert ix.ranking("Leverage  Ratio") is ix.ranking("leverage ratio")  # cache is normalised


def test_query_expansion_borrows_document_vocabulary(ws, ids, tmp_path):
    ix = BM25Index(ws)
    q2 = ix.expand_query("leverage covenant")
    assert q2.startswith("leverage covenant ") and q2.count("leverage") == 1
    extra = q2.split()[2:]
    assert "borrower" in extra and "maintain" in extra and len(extra) <= 5      # the documents' own words
    assert ix.expand_query("leverage covenant", n_terms=0) == "leverage covenant"
    assert ix.expand_query("zzzz qqqq") == "zzzz qqqq"                          # nothing to borrow from
    clue = Clue(text="covenant", grep_patterns=[], bm25_query="leverage covenant")
    fm = first_move(ws, "q", [clue], ix, trace=Trace(tmp_path / "t.jsonl", "t"))
    assert "(+ expanded:" in fm.opening_observation and len(fm.candidate_doc_ids) == 3
    off = replace(DEFAULT, tools=replace(DEFAULT.tools, FIRST_MOVE_EXPANSION_TERMS=0))
    assert "(+ expanded:" not in first_move(ws, "q", [clue], BM25Index(ws, off), off).opening_observation


@pytest.mark.timeout(60)
def test_bm25_builds_1000_docs_under_budget(tmp_path):
    ws = Workspace.materialize(_synthetic(1000), tmp_path / "big")
    t0 = time.perf_counter()
    ix = BM25Index(ws)
    dt = time.perf_counter() - t0
    # PLAN target is < 3 s; measured ~2.7 s on a laptop for this worst-case dense corpus (17k chunks,
    # no blank lines), so the test allows 4 s to stay stable. The real-corpus number comes from CUAD.
    assert len(ix.chunks) >= 1000 and dt < 4.0, f"BM25 build took {dt:.2f}s"
    assert ix.search("FAC-2024-0117").total_ranked == 11           # identifier kept as one token
    res = ix.search("facility id", k=5)
    assert res.hits and len(ix.ranking("facility")) <= DEFAULT.tools.BM25_DEEP_K


# --------------------------------------------------------------------------- first move

def test_fallback_clues_from_question_text():
    q = 'Which documents reference facility "FAC-2024-0117" and the Applicable Margin of 2.25%?'
    clues = fallback_clues(q)
    texts = [c.text for c in clues]
    assert "FAC-2024-0117" in texts and "Applicable Margin" in texts and texts[-1] == "question keywords"
    assert all(c.grep_patterns or c.bm25_query for c in clues)
    assert clues[-1].bm25_query and "facility" in clues[-1].bm25_query.lower()


def test_first_move_without_model_ranks_candidates_and_pages(ws, ids, tmp_path):
    ix = BM25Index(ws)
    tr = Trace(tmp_path / "t.jsonl", "t")
    clues, how = decompose("Which documents reference facility FAC-2024-0117?", ws, None)
    assert how == "fallback"
    fm = first_move(ws, "Which documents reference facility FAC-2024-0117?", clues, ix, trace=tr, decomposed_by=how)
    assert fm.candidate_doc_ids[:2] and set(fm.candidate_doc_ids[:2]) == {ids["a"], ids["m"]}   # only these two carry the id
    assert fm.clues_hit[ids["a"]] >= 1 and fm.estimated_candidate_tokens > 0 and fm.decomposed_by == "fallback"
    obs = fm.opening_observation
    assert obs.startswith("## Opening observation") and "FAC-2024-0117" in obs and "Top candidate documents" in obs
    assert "page_results(" in obs and f"[{ids['a']}:" in obs
    ev = [json.loads(ln) for ln in (tmp_path / "t.jsonl").read_text().splitlines()]
    assert ev[-1]["stage"] == "first_move" and ev[-1]["n_candidates"] == len(fm.candidate_doc_ids)


def test_decompose_with_scripted_planner_sanitizes_patterns(ws):
    plan = {"clues": [
        {"text": "leverage covenant", "grep_patterns": ["Leverage Ratio", "3\\.50|3\\.5 ?to ?1", "unbalanced("], "bm25_query": "leverage ratio"},
        {"text": "empty", "grep_patterns": [], "bm25_query": ""},
    ]}
    caller = ModelCaller(get_scripted_llm([AIMessage(content=json.dumps(plan))]), None, "fm", "planner")
    clues, how = decompose("q", ws, caller)
    assert how == "model" and len(clues) == 1 and clues[0].grep_patterns[2] == "unbalanced\\("
    fm = run_first_move(ws, "What is the Leverage Ratio?", BM25Index(ws), llm=get_scripted_llm([AIMessage(content=json.dumps(plan))]))
    assert fm.decomposed_by == "model" and len(fm.candidate_doc_ids) == 3


# --------------------------------------------------------------------------- router

def test_router_guards(ws):
    fm = FirstMoveResult(clues=[Clue(text="x")], opening_observation="o", candidate_doc_ids=["d1", "d2", "d3"],
                         estimated_candidate_tokens=250_000)
    d = apply_guards(RouteJSON(mode="long_context", rationale="small"), fm)
    assert d.mode.value == "single" and "long_context refused" in d.rationale and d.estimated_evidence_tokens == 250_000
    d = apply_guards(RouteJSON(mode="long_context"), fm.model_copy(update={"estimated_candidate_tokens": 5_000}))
    assert d.mode.value == "long_context"
    d = apply_guards(RouteJSON(mode="breadth", sub_questions=["a", " b ", ""]), fm)
    assert d.mode.value == "breadth" and d.sub_questions == ["a", "b"] and d.doc_batches == []
    d = apply_guards(RouteJSON(mode="breadth"), fm)
    assert d.mode.value == "breadth" and d.doc_batches == [["d1", "d2", "d3"]]
    d = apply_guards(RouteJSON(mode="breadth"), None)
    assert d.mode.value == "single" and "defaulting to single" in d.rationale
    assert apply_guards(RouteJSON(mode="weird"), fm).mode.value == "single"
    scripted = ModelCaller(get_scripted_llm([AIMessage(content='{"mode": "single", "rationale": "one answer"}')]), None, "r", "router")
    assert route(ws, "q", fm, scripted).rationale == "one answer"
    assert route(ws, "q", fm, None).mode.value == "single"


# --------------------------------------------------------------------------- researcher with A1 tools

def test_researcher_a1_tool_set_uses_search(ws, ids, tmp_path):
    ix = BM25Index(ws)
    cfg = replace(DEFAULT, agents=replace(DEFAULT.agents, RESEARCH_MIN_CALLS=1, RESEARCH_MAX_CALLS=6))
    script = [
        ai(tc("search", {"query": "leverage ratio"}), tc("page_results", {"query": "leverage ratio", "page": 2}),
           tc("outline", {"doc_id": ids["a"]})),                                                     # outline is not exposed in A1
        ai(tc("add_evidence", {"doc_id": ids["a"], "start_line": 17, "end_line": 17, "quote": QUOTE, "note": "n"}),
           tc("submit", {"sub_question": "q", "answer": "[e1]", "evidence_ids": ["e1"]})),
    ]
    ctx = ResearchContext(ws=ws, bank=EvidenceBank(ws), tracker=ReadTracker(), trace=Trace(tmp_path / "t.jsonl", "t"),
                          config=cfg, llm=get_scripted_llm(script), tool_names=A1_TOOLS, bm25=ix,
                          opening_observation="## Opening observation\nhello")
    run = ResearchLoop(ctx).run("q")
    system = next(m for m in run.state["messages"] if isinstance(m, SystemMessage)).content
    assert "## Opening observation" in system and "`search(query, k?)`" in system and "`outline(doc_id)`" not in system
    tm = {m.name: m.content for m in run.state["messages"] if isinstance(m, ToolMessage)}
    assert tm["search"].startswith("search /leverage ratio/") and "no ranked chunks" in tm["page_results"]
    assert tm["outline"].startswith("UNKNOWN TOOL") and run.done == "submitted"
    # without an index the search tools refuse instead of failing
    ctx2 = ResearchContext(ws=ws, bank=EvidenceBank(ws), tracker=ReadTracker(), config=cfg, tool_names=A1_TOOLS,
                           llm=get_scripted_llm([ai(tc("search", {"query": "x"})), ai(tc("submit", {"sub_question": "q", "answer": "n", "evidence_ids": [], "not_in_corpus": True}))]))
    run2 = ResearchLoop(ctx2).run("q")
    assert any(m.content.startswith("REJECTED: search is not available") for m in run2.state["messages"] if isinstance(m, ToolMessage))


# --------------------------------------------------------------------------- A1 graph end to end

def test_pipeline_a1_deep_list_end_to_end(docs, ids, tmp_path):
    a = ids["a"]
    cfg = replace(DEFAULT, agents=replace(DEFAULT.agents, RESEARCH_MIN_CALLS=1, RESEARCH_MAX_CALLS=6))
    planner = get_scripted_llm([AIMessage(content=json.dumps({"clues": [
        {"text": "leverage covenant", "grep_patterns": ["Leverage Ratio"], "bm25_query": "leverage ratio"}]}))])
    router = get_scripted_llm([AIMessage(content='{"mode": "breadth", "rationale": "many docs", "sub_questions": ["x"]}')])
    researcher = get_scripted_llm([
        ai(tc("search", {"query": "leverage ratio"})),
        ai(tc("add_evidence", {"doc_id": a, "start_line": 17, "end_line": 17, "quote": QUOTE, "note": "covenant"}),
           tc("submit", {"sub_question": "q", "answer": "3.50 [e1]", "evidence_ids": ["e1"]})),
    ])
    writer = get_scripted_llm([
        AIMessage(content=json.dumps({"sections": [{"section_id": "s1", "title": "Covenant", "intent": "ratio"}]})),
        AIMessage(content=json.dumps({"sections": [{"section_id": "s1", "title": "Covenant", "intent": "ratio", "evidence_ids": ["e1"]}]})),
        AIMessage(content="The cap is 3.50 to 1.00 {{CITE:e1}}."),
    ])
    p = Pipeline(cfg, llms={"planner": planner, "router": router, "researcher": researcher, "writer": writer})
    state = p.run("What is the Leverage Ratio?", docs, variant="A1_deep_list", root=tmp_path / "run")
    assert state["first_move"]["decomposed_by"] == "model" and state["first_move"]["n_candidates"] == 3
    assert state["route"]["mode"] == "breadth" and any("runs the single researcher" in e for e in state["errors"])
    assert state["research_done"] == "submitted" and [v["tier1"] for v in state["verify"]] == ["keep"]
    assert set(state["stage_ms"]) == {"materialize", "first_move", "route", "research", "write", "verify"}
    assert f"[{a} p.2]" in state["report_md"]
    kinds = [json.loads(ln)["kind"] for ln in (tmp_path / "run" / "trace.jsonl").read_text().splitlines()]
    assert "bm25_index" in kinds and kinds.count("model") == 7      # planner, router, researcher x2, writer x3
