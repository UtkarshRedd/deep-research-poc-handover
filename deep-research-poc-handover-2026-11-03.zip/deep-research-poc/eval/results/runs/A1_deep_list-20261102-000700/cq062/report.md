# Which agreement in the corpus was entered into between Novo Integrated Sciences Inc. an...

*Question:* Which agreement in the corpus was entered into between Novo Integrated Sciences Inc. and Harvest Gold Farms Inc.? Give its title and date.

> **Partial report.** Research or writing ended before completion; see the gaps and the appendix.

## Identify Novo-Harvest agreement

[GAP] No evidence was found for: Find the agreement in the corpus between Novo Integrated Sciences Inc. and Harvest Gold Farms Inc.

## Extract title and date

[GAP] No evidence was found for: State the exact title and date of that agreement.

## Verification appendix

Claims: 2 · supported: 0 · partially: 0 · dropped: 0 · gaps: 2

Notes: no evidence in the bank; every section is a gap

| claim | section | tier 1 | score | tier 2 | clusters | sources | note |
|---|---|---|---|---|---|---|---|
| s1.1 | s1 | gap |  | skipped |  |  |  |
| s2.1 | s2 | gap |  | skipped |  |  |  |

### Evidence

