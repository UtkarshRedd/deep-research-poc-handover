<!-- page 1 -->
# SPONSORSHIP AGREEMENT
| Field | Value |
|---|---|
| Document Type | Sponsorship Agreement |
| Agreement Date | 2010-01-01 |
| Parties | Stallings Capital Group Consultants, Ltd. ("Racing"); GAINSCO, INC. ("Sponser") |
| Source | CUAD v1 / GAINSCOINC_01_21_2010-EX-10.41-SPONSORSHIP AGREEMENT |

Exhibit 10.41

SPONSORSHIP AGREEMENT

This Sponsorship Agreement (the "Agreement") is entered into effective January 1, 2010 by and
between Stallings Capital Group Consultants, Ltd., a Texas limited partnership dba Bob Stallings
Racing ("Racing"), and GAINSCO, INC., a Texas corporation (the "Sponsor").

Racing organized and operated a racing team engaging in Daytona Prototype Series auto racing (the
"Racing Team") in professional races in 2005 through 2008, and the Sponsor was the primary sponsor
of the Racing Team pursuant to Sponsorship Agreements dated February 7, 2005, February 1, 2006,
January 1, 2007, January 1, 2008 and January 1, 2009. Racing has invited the Sponsor to continue to
act as the primary sponsor of the Racing Team for 2010, and the Sponsor desires to act in that
capacity. In consideration of the sponsorship fee provided for herein, the parties desire to enter
into this Agreement to govern the terms of such sponsorship in 2010.

Now, therefore, Racing and the Sponsor hereby agree as follows:

1. Term. Subject to the provisions of Section 14 hereof, the term of this Agreement and the
sponsorship described herein shall commence on January 1, 2010 and extend through December 31, 2010.

2. Advertising and Other Benefits. Subject to payment by the Sponsor of the sponsorship fee provided
for herein, during the term of this Agreement Racing shall cause the Racing Team to provide for the
Sponsor's benefit all of the benefits customarily associated with the sponsorship of a Daytona
Prototype Series racing team and consistent with the benefits provided to the Sponsor in 2005 - 2009
(individually, a "Benefit," and collectively, the "Benefits"), including but not limited to the
following: (i) displaying prominent identification of the Sponsor's name and/or logo in signage on
the race car and racing suits and, where appropriate, on other team equipment (subject to approval
by the Sponsor); (ii) making available for the use of the Sponsor (x) the personalities associated
with the Racing Team, including without limitation the name, voice, picture, portrait, likeness,
persona and/or signature of each driver for endorsements, commercial advertising and promotions in
any and all media throughout the world during the term of this Agreement, (y) the Racing Team's home
base facilities in Texas, and (z) those facilities designated or assigned for the use of the Racing
Team at each race and race location at which the Racing Team actually participates in the race, all
for appropriate public relations and other promotional and marketing purposes. Racing agrees that it
will actively participate in the Rolex 24 at Daytona in January, 2010. As it concerns (y) and (z)
above, access shall be subject to appropriate security and safety restrictions designated by the
applicable racing location and the Racing Team;
<!-- page 2 -->
(iii) making available for the use of the Sponsor a non-racing look-alike (a "Show Car") of the
GAINSCO 99 race car (the "Car") used by the Racing Team. Subject to the Sponsor's first right to use
the Show Car, it will also be made available to Racing when such use does not interfere with the
Sponsor's use of the Show Car; (iv) allowing the Sponsor the use of the likeness of the Car,
including all paint and graphics, for promotion and advertising of or by the Sponsor, and Racing
shall be responsible for all necessary consents and permissions from any other sponsors to be sure
the Sponsor can use the likeness of the Car as specified herein; (v) prohibiting the endorsement by
Racing and any members of Racing, including the drivers, of any entities, products or services which
are in direct competition or otherwise inconsistent with the Sponsor or it products or services,
unless such endorsement activity is approved in writing by Racing and the Sponsor; and (vi) allowing
the Sponsor to use the conference room and other areas of the racing shop and garage for meetings
and similar events, provided that the Sponsor gives prior notice of the need for such use, and such
use does not interfere with operations of the racing shop and garage and is otherwise consistent
with reasonable requirements imposed by Racing to assure orderly operations and provide for adequate
safety measures at all times.

3. Sponsorship Fee. The Sponsor shall pay to Racing a sponsorship fee in the amount of $750,000.00
for the term of this Agreement, payable in an initial installment payable on or before February 1,
2010 in the amount of $350,000.00 and ten installments of $40,000.00 on or before the first day of
each month commencing March 1, 2010 and ending with the installment due on December 1, 2010 (unless
this Agreement is sooner terminated pursuant to Section 14 hereof, in which case Sponsor shall have
no obligation to make any payments after the date of termination).

4. Compliance with Applicable Rules and Regulations. Provision of the Benefits pursuant to this
Agreement is subject to rules and requirements of each organization and venue hosting a racing event
in which the Racing Team competes during the term hereof, and the Sponsor agrees to submit to Racing
all advertising and other promotional material relating to each such event in sufficient time to
enable Racing to assure compliance with such rules and requirements. If as a result of such rules
and requirements Racing is unable to provide a Benefit in the form requested by the Sponsor, Racing
shall be permitted to provide a substitute promotion or advertisement in compliance with such
requirements. 2
<!-- page 3 -->
5. Sponsor's Maximum Obligation; Indemnification. Racing represents to the Sponsor that the
Sponsor's aggregate obligation hereunder will not exceed the amount of the sponsorship fee set forth
in Section 3 hereof (or such lesser amount as is payable by the Sponsor in the event that this
Agreement is terminated pursuant to Section 14 hereof), plus, if applicable, collection costs that
may be reasonably incurred by Racing in a legal proceeding to collect all or any part thereof (the
"Maximum Obligation"). Racing agrees to indemnify the Sponsor and its officers, directors, agents
and employees and to hold them harmless from any loss, claim, cost, damage or liability in excess of
the Maximum Obligation which (i) the Sponsor shall incur as a result of this Agreement, or (ii)
arises from any failure by Racing to perform any of its obligations hereunder.

6. Retention of Rights. The only rights granted to the Sponsor hereunder are the right to receive
the Benefits, and Racing hereby retains all other rights with respect to the Racing Team, including
but not limited to logos, symbols, names and other marks and intellectual property of the Racing
Team, and any proceeds derived by the Racing Team. The Sponsor hereby retains and does not grant any
rights to Racing to use any of its logos, symbols, names or other marks or intellectual property,
except for use as described in Section 2 hereof. In the event that this Agreement is terminated or
if the sponsorship terminates at the end of the term provided for herein, each of the parties shall
retain the rights to use its logos, symbols, names or other marks or intellectual property
including, in the case of the Sponsor, the right to use the names and marks "GAINSCO 99", "the
GAINSCO 99 Car", or similar phrases or derivations thereof.

7. Relationship to Other Sponsors. The Sponsor acknowledges that Racing has arranged and may arrange
in the future for other sponsors for the Racing Team. Racing agrees that, during the term of this
Agreement, (i) Sponsor shall have the right to approve or disapprove any additional sponsor
identified by Racing, and (ii) unless another proposed sponsor has agreed to pay a sponsorship fee
that exceeds the amount paid by Sponsor, no other sponsor shall receive any benefit of greater value
(including either an equivalent or a more prominent use of another sponsor's name, logo or other
identifying information) than the Benefits provided to the Sponsor hereunder.

8. Insurance. (a) Racing shall obtain and maintain, at Racing's expense, comprehensive automobile
liability insurance covering all owned, non-owned and hired vehicles used by Racing in the Business
with limits of not less than $5,000,000 per occurrence combined single limit for personal injury and
property damage, including all statutory coverage for all states of operation. Racing shall also
provide comprehensive (fire and theft) and collision insurance on each vehicle used in the Business.
Racing shall provide the Sponsor a certificate of insurance evidencing "Gainsco Inc. and all related
entities" as additional insureds, stating that such insurance is primary in coverage to any other
insurance which may be available the Sponsor, and providing at least thirty (30) days' prior written
notice to the Sponsor of cancellation, modification or material change to the policy.

(b) Racing shall obtain and maintain pursuant to the terms of this Agreement, at its sole expense,
the following types of insurance coverage, with minimum limits as set forth below:

(i) Commercial General Liability covering liability arising from premises, operations, independent
contractors, personal and advertising injury and contractual liability—$5,000,000 each occurrence. 3
<!-- page 4 -->
(ii) Racing Owners' Sponsors (Spectators) Legal Liability including Participant Legal
Liability—$5,000,000 each occurrence.

(iii) Business Automobile Liability covering all owned, hired and non-owned vehicles—$5,000,000 each
occurrence, including statutory coverages for all states of operations.

(iv) Workers Compensation—statutory limits for all states of operation.

(v) Employers Liability—$5,000,000 each employee for bodily injury by accident and $500,000 each
employee for bodily injury by disease.

All policies of insurance procured by Racing herein shall be written as primary policies, not
contributing with or in excess of coverage that the Sponsor may carry. If Racing's liability
policies do not contain the standard separation of insureds provision, or a substantially similar
clause, they shall be endorsed to provide cross-liability coverage.

(c) Racing shall provide the Sponsor with a certificate of insurance evidence compliance with the
insurance requirements set forth above. Certificates shall provide that "Gainsco Inc. and all
related entities" shall be named as additional insureds on all liability policies, stating that such
insurance is primary in coverage to any other insurance which may be available to the Sponsor, and
providing at least thirty (30) days' prior written notice to the Sponsor of termination,
cancellation, modification or material change to the policy.

(d) Such certificates shall be in a form acceptable to, and underwritten by insurance company(ies)
reasonably satisfactory to the Sponsor. By requiring insurance herein, the Sponsor does not
represent that coverage limits will necessarily be adequate to protect Racing. The purchase of
appropriate insurance coverage by Racing or the furnishing of certificates of insurance shall not
release Racing from its obligations and liabilities under this Agreement.

9. Conduct. Racing and all Racing members, including but not limited to all drivers, agree to use
best efforts to conduct themselves in such a manner so as not to reflect unfavorably upon the
Sponsor or its products. The Sponsor shall have the right to terminate this Agreement on written
notice to Racing if any driver, the general manager or any other member of Racing (i) fails to
conduct himself/herself in accordance with generally accepted standards of morality, (ii) engages in
any activity which reflects adversely on the image, reputation or goodwill of the Sponsor or (iii)
disparages the products or services of the Sponsor; provided, however, the Sponsor shall not have
the right to terminate this Agreement if Racing, within fifteen (15) days after receipt of written
notice by the Sponsor terminates the employment of, or otherwise dismisses from the racing team, the
driver(s), general manager(s) or other member(s) of Racing engaging in the offensive conduct. Upon
termination, the Sponsor shall be entitled to a pro rata refund of monies paid for services not yet
performed by Racing based upon the number of races for the applicable racing season. The Sponsor's
decision with respect to all matters arising under this Section shall be conclusive. 4
<!-- page 5 -->
10. Remedies. If either party breaches any provision of this Agreement, the other party shall be
entitled to seek monetary damages and, if appropriate, equitable relief to require the performance
of the obligations hereunder.

11. Assignment. Neither party shall assign any of its rights or obligations hereunder without the
prior written consent of the other party.

12. Entire Agreement; Amendment and Waiver; Confidentiality. This Agreement constitutes the entire
agreement between Racing and the Sponsor with respect to the subject matter hereof and supercedes
all prior agreements and understandings. Any amendment of this Agreement must be by a written
instrument signed by both parties, and any waiver of any provision hereof must be in writing, signed
by the party agreeing to such waiver. Each of the parties hereto agrees to hold in confidence the
terms hereof and, unless otherwise required by law, neither party shall release, disclose or publish
any of the terms hereof without the prior written consent of the other party.

13. Notices. All notices and communications to be made with respect to this Agreement shall be in
writing and shall be effective only when delivered by (i) hand, (ii) prepaid certified United States
mail, return receipt requested, or (iii) overnight delivery service providing proof of delivery,
addressed as follows:

If to Racing: Stallings Capital Group Consultants, Ltd., dba Bob Stallings Racing Attention: Robert
W. Stallings, President 4 Windsor Ridge Frisco, Texas 75034

if to the Sponsor: GAINSCO, Inc. Attention: Glenn W. Anderson, President 3333 Lee Parkway, Suite
1200 Dallas, Texas 75219

Either party may change the name or address for notice by providing a written notice of such change
in accordance with this Section of the Agreement.

14. Termination by the Sponsor. Notwithstanding the provisions of Section 1 hereof, the Sponsor
shall have the right at any time prior to December 31, 2010 to terminate this Agreement by giving
written notice of such termination to Racing. In the event of such a termination, (i) the Sponsor
shall have no further obligation to make payments toward the sponsorship fee contemplated in Section
3 hereof, (ii) Racing shall have no further obligation to provide any Benefits hereunder, and (iii)
the remaining provisions of this Agreement shall remain in full force and effect.

15. Miscellaneous. (a) This Agreement may be executed in two counterparts, each of which shall be
deemed to be an original, but both of which shall constitute a single agreement. 5
<!-- page 6 -->
(b) The headings and sections of this Agreement are for convenience only and shall not affect the
interpretation of any provision hereof.

(c) This Agreement shall be governed and construed in accordance with the internal laws of the State
of Texas, without giving effect to principles of conflict of laws.

This Agreement is executed as of the date first above written.

6

STALLINGS CAPITAL GROUP CONSULTANTS, LTD., DBA BOB STALLINGS RACING GAINSCO, INC.

By: /s/ Robert W. Stallings By: /s/ Glenn W. Anderson Robert W. Stallings, President Glenn W.
Anderson, President
