# Prompts

Loaded by name with `dr.prompts.load(name, **fields)`; files with `## key` sections are read with
`dr.prompts.load_sections(name)` and formatted by the caller. Placeholders use `str.format` fields
(write literal braces as `{{` / `}}`); a missing field raises `KeyError` so prompt/code drift fails
loudly. Override the directory with `DR_PROMPTS_DIR`. Keep prompts short and concrete: the three
available models are small/open, so instructions must be explicit and tool descriptions crisp.
Tool *results* (REJECTED, INVALID ARGUMENTS, offload pointers, elided stubs) are rendered by the
tools and the loop, not here; only instructions addressed to the model live in this directory.

| File | Stage | Phase | Status |
|---|---|---|---|
| `researcher.md` | system prompt, Approach 2/1 single agent | 2 | used live (Phases 2-7, see docs/findings.md) |
| `research_task.md` | first user message (`task` / `sub_question` sections) | 2 | used live |
| `width_turn.md` | per-turn width nudge (user message) | 2 | used live |
| `width_phase_hints.md` | `early` / `mid` / `late` / `deadline` fills for `width_turn.md` | 2 | used live |
| `nudge_no_tools.md` | reply to a text-only turn | 2 | used live |
| `nudge_min_calls.md` | tool result for a submit below the minimum-calls floor | 2 | used live |
| `force_submit.md` + `force_reasons.md` | last call when budget / deadline is exhausted (submit only) | 2 | used live |
| `constrained_call.md` | `ask` / `repair`: one tool call as bare JSON after malformed turns | 2 | used live |
| `first_move.md` | clue decomposition (planner, JSON) | 4 | used live |
| `router.md` | single / breadth / long_context; breadth gives one sub-question per listed document | 4 | used live |
| `fanout_researcher.md` | per-unit contract (scope, budget, answer length) shown to each fan-out researcher | 5 | used live |
| `extract.md` | grid extractor: one question, one document, verbatim quote + line range (JSON) | 5 | used live |
| `gap_check.md` | planner lists what the fan-out findings still miss (JSON) | 5 | used live |
| `outline.md` | outline from the question alone (JSON) | 3 | used live |
| `outline_revise.md` | one revision pass + evidence assignment (JSON) | 3 | used live |
| `json_repair.md` | one-shot repair message for any structured JSON call | 3 | used live |
| `writer_section.md` | section drafting with `{{CITE:e<n>}}` before the period, `[GAP]` lines | 3 | used live |
| `verifier_tier2.md` | grouped claim review: claim + quote + context -> supported / partially / unsupported (JSON) | 7 | used live |
| `judge.md` | rubric judge; verdict correct / partially_correct / incorrect / unknown (JSON) | 6 | used live |
| `metadata_extract.md` | metadata from first 2 pages | 0 | todo |
