<!-- page 1 -->
# AGENCY AGREEMENT
| Field | Value |
|---|---|
| Document Type | Agency Agreement |
| Agreement Date | 2015-05-21 |
| Parties | Dundee Securities Ltd.("Lead Agent"); Kes 7 Capital Inc. and Bloom Burton & Co. Ltd. (collectively with the Lead Agent, "Agents" and each individually an "Agent"); Tribute Pharmaceuticals Canada Inc. ("Corporation") |
| Source | CUAD v1 / OLDAPIWIND-DOWNLTD_01_08_2016-EX-1.3-AGENCY AGREEMENT1 |

Exhibit 1.3 AGENCY AGREEMENT May 21, 2015 Tribute Pharmaceuticals Canada Inc. 151 Steeles Avenue
East Milton, Ontario L9T 1Y1 Attention: Rob Harris, President and Chief Executive Officer Dear Mr.
Harris: The undersigned, Dundee Securities Ltd. (the "Lead Agent"), Kes 7 Capital Inc., and Bloom
Burton & Co. Ltd. (collectively with the Lead Agent, the "Agents" and each individually an "Agent")
understand that Tribute Pharmaceuticals Canada Inc. (the "Corporation") proposes to issue and sell
up to 13,043,695 common shares of the Corporation (the "Offered Shares") at a price of $0.92 per
Offered Share (the "Offering Price") for aggregate gross proceeds of up to $12,000,199.40. The
offering of the Offered Shares by the Corporation is referred to in this Agreement as the
"Offering". In consideration of the Agents' services to be rendered in connection with the Offering,
the Corporation shall pay to the Agents a cash fee (the "Agents' Fee") equal to 7.0% of the gross
proceeds of the Offering. As additional consideration, the Corporation shall issue to the Agents
that number of compensation options (the "Compensation Options") equal to 3.5% of the number of
Offered Shares sold pursuant to the Offering. The Compensation Options will be exercisable for a
period of 24 months at the Offering Price. Unless otherwise stated herein, the Offered Shares shall
also refer to the Compensation Options. Notwithstanding anything to the contrary contained herein,
the entire Agents' Fee and Compensation Options payable in respect of Offered Shares sold pursuant
to Regulation D under the United States Securities Act of 1933, as amended, shall be payable to the
Lead Agent. Based on the foregoing, and subject to the terms and conditions contained in this
Agreement, the Agents severally and not jointly agree to act as, and the Corporation appoints the
Agents as, the exclusive agents of the Corporation to offer the Offered Shares for sale on the
Closing Date (as defined herein) in the Selling Jurisdictions (as defined herein) on a private
placement basis at the Offering Price. It is understood and agreed by the Corporation and the Agents
that the Agents shall act as agents only and are under no obligation to purchase any of the Offered
Shares. In connection with the offering and sale of the Offered Shares, the Agents shall be
entitled, with the written consent of the Corporation, not to be unreasonably withheld or delayed,
to retain as sub-agents other securities dealers or financial institutions to solicit subscriptions
for Offered Shares. Any fee payable to such sub-agents shall be for the account of the Agents and
not the Corporation. The Agents shall be entitled to the fee provided for in Section 1(1)(a). That
fee shall be payable at the Closing Time upon the closing of the sale of the Offered Shares, and may
be deducted by the Agents from the gross proceeds of the Offering.
<!-- page 2 -->
Schedules: Schedule "A" - United States Compliance with Securities Laws 1. Definitions In this
Agreement: (a) "Agent" and "Agents" have the respective meanings given to them above; (b) "Agents'
Counsel" means Dentons Canada LLP; (c) "Agents' Fee" has the meaning given in Section 1(1)(a); (d)
"Agreement" means the agreement resulting from the acceptance by the Corporation of the offer made
by the Agents by this letter; (e) "Applicable Securities Laws" means all applicable securities laws,
rules, regulations, notices and published policies of the Selling Jurisdictions in Canada and the
United States; (f) "Business Day" means any day other than a Saturday, Sunday or statutory or civic
holiday in Toronto, Ontario; (g) "Closing" means the completion of the Offering; (h) "Closing Date"
means May 21, 2015 or such other date as the Corporation and the Agents may agree upon in writing,
or as may be changed pursuant to this Agreement; (i) "Closing Time" means 8:00 a.m. (Toronto time)
on the Closing Date; (j) "Corporation" has the meaning given to it above; (k) "Corporation's
Auditors" means such firm of chartered accountants as the Corporation may have appointed or may from
time to time appoint as auditors of the Corporation, including prior auditors of the Corporation, as
applicable; (l) "Corporation's Counsel" means Fogler Rubinoff LLP; (m) "Compensation Options" has
the meaning ascribed thereto on the face page of this Agreement; (n) "Compensation Option
Certificates" shall mean the certificates representing the Compensation Options; (o) "Debt
Instrument" means any loan, bond, debenture, promissory note or other instrument evidencing
indebtedness (demand or otherwise) for borrowed money or other liability; 2
<!-- page 3 -->
(p) "Due Diligence Session" means the due diligence question and answer session held with management
of the Corporation on May 21, 2015 and July 14, 2014; (q) "Environmental Laws" means any federal,
state, provincial, territorial or local law, statute, ordinance, rule, regulation, order, decree,
judgment, injunction, permit, license, authorization or other binding requirement, or common law,
relating to health, safety or the regulation, protection, cleanup or restoration of the environment
or natural resources, including those relating to the distribution, processing, generation,
treatment, control, storage, disposal, transportation, other handling or release or threatened
release of Hazardous Materials or Conditions, and "Hazardous Materials or Conditions" means any
material, substance (including, without limitation, pollutants, contaminants, hazardous or toxic
substances or wastes) or condition that is regulated by or may give rise to liability under any
Environmental Laws; (r) "Financial Statements" means the audited consolidated financial statements
of the Corporation as at and for the years ended December 31, 2013 and 2014 and for the unaudited
interim financial statements for the period ended March 31, 2015 together with the notes thereto;
(s) "Governmental Authority (ies)" means governments, regulatory authorities, governmental
departments, agencies, commissions, bureaus, officials, ministers, Crown corporations, courts,
bodies, boards, tribunals or dispute settlement panels or other law, rule or regulation-making
organizations or entities: (i) having or purporting to have jurisdiction over the Corporation on
behalf of any nation, province, territory or state or any other geographic or political subdivision
of any of them; or (ii) exercising, or entitled or purporting to exercise any administrative,
executive, judicial, legislative, policy, regulatory or taxing authority or power over the
Corporation; (t) "Indemnified Party" has the meaning given to it in Section 11(b); (u) "Lead Agent"
has the meaning given to it above; (v) "Material Adverse Effect" or "Material Adverse Change" means
any effect, change, event or occurrence that is, or is reasonably likely to be, materially adverse
to the results of operations, condition (financial or otherwise), assets, properties, capital,
liabilities (contingent or otherwise), cash flow, income or business operations of the Corporation
and its subsidiaries taken as a whole; (w) "Material Agreement" means any note, indenture, mortgage
or other form of indebtedness and any contract, commitment, agreement (written or oral), joint
venture instrument, lease or other document to which the Corporation is a party and which is
material to the Corporation on a consolidated basis; (x) "notice" has the meaning given to it in
Section 21; 3
<!-- page 4 -->
(y) "Offered Shares" has the meaning given to it above; (z) "Offering" has the meaning given to it
above; (aa) "Offering Price" has the meaning given to it above; (bb) "Person" means any individual,
sole proprietorship, partnership, firm, entity, unincorporated association, unincorporated
syndicate, unincorporated organization, trust, body corporate, limited liability company and
unlimited liability company; (cc) "Public Record" means the public disclosure of the Corporation
filed on SEDAR; (dd) "SEC" means the United States Securities and Exchange Commission; (ee) "SEDAR"
means the System for Electronic Document Analysis and Retrieval; (ff) "Securities Commissions" means
the securities commissions or similar regulatory authorities in the Selling Jurisdictions; (gg)
"Selling Jurisdictions" means all of the provinces of Canada, the United States and such other
jurisdictions as the Agents and the Corporation may agree; (hh) "Subscriber" means, for the purposes
of this Agreement, the person who executes a Subscription Agreement or, if such person executes a
Subscription Agreement as a duly authorized agent of one or more principals, the principal or
principals of such person; (ii) "Subscription Agreements" means the agreements entered into by each
Subscriber and the Corporation in respect of the Subscriber's subscription for Offered Shares in the
form and on terms and conditions satisfactory to each of the Corporation and the Agents, each acting
reasonably; (jj) "TSX-V" means the TSX Venture Exchange; (kk) "United States" means the United
States of America, its territories and possessions, any state of the United States, and the District
of Columbia; and (ll) "U.S. Securities Act" means the United States Securities Act of 1933, as
amended, and the rules and regulations promulgated thereunder. In this Agreement, "affiliated",
"misrepresentation", "material change", "material fact" and "subsidiary" have the meanings ascribed
thereto under the Applicable Securities Laws of the Selling Jurisdictions in Canada, and
"distribution" means "distribution" or "distribution to the public", as the case may be, as defined
under the Applicable Securities Laws of the Selling Jurisdictions in Canada, and "distribute" has a
corresponding meaning. In this Agreement, unless there is something in the subject matter or context
inconsistent therewith: 4
<!-- page 5 -->
(a) words used herein importing the singular number include the plural and vice versa, words
importing the use of any gender include all genders, and words importing persons include
individuals, partnerships, associations, trusts, unincorporated organizations and corporations, and
the rest of the sentence is construed as if the necessary grammatical and terminological changes had
been made; (b) references herein to any agreement or instrument, including this Agreement, are
deemed to be references to the agreement or instrument as varied, amended, modified, supplemented or
replaced from time to time, and any specific references herein to any legislation or enactment are
deemed to be references to such legislation or enactment as the same may be amended or replaced from
time to time; and (c) all dollar amounts in this Agreement are expressed in Canadian dollars except
where expressly indicated otherwise. The division of this Agreement into sections, subsections,
paragraphs, subparagraphs and clauses and the insertion of headings are for convenience of reference
only and do not affect the construction or interpretation of this Agreement. The terms "this
Agreement", "hereof', "herein", "hereunder" and similar expressions refer to this Agreement and the
schedules hereto and not to any particular section, paragraph, subparagraph, clause or other portion
hereof and include any agreement or instrument supplementary or ancillary hereto. 2. Restrictions on
Sale Each of the Agents severally and not jointly covenants and agrees with the Corporation that it
will: (a) not solicit subscriptions for Offered Shares, trade in Offered Shares or otherwise do any
act in furtherance of a trade of Offered Shares outside of the Selling Jurisdictions; (b) in
connection with the offer and sale of the Offered Shares in Canada, the Agents will only offer and
sell the Offered Shares to persons resident in Canada who are: (i) "accredited investors" (as
defined in National Instrument 45-106 - Prospectus Exemptions or, in Ontario, Section 73.3 of the
Securities Act (Ontario)), and (ii) purchasing as principals; and (c) not advertise the proposed
sale of the Offered Shares in printed media of general and regular paid circulation, radio,
television or the internet nor provide or make available to prospective purchasers of Offered Shares
any document or material which would constitute an offering memorandum as defined in Applicable
Securities Laws in Canada. 5
<!-- page 6 -->
The parties hereto acknowledge that the Offered Shares have not been and will not be registered
under the U.S. Securities Act or any U.S. state securities laws and may not be offered or sold in
the United States except pursuant to transactions that are exempt from the registration requirements
of the U.S. Securities Act and the applicable securities laws of any U.S. state. Accordingly, the
Corporation and the Agents hereby agree that offers and sales of the Offered Shares in the United
States shall be made only to "accredited investors" within the meaning of Rule 501(a) of Regulation
D under the U.S. Securities Act in the manner specified in Schedule A hereto, which terms and
conditions are hereby incorporated by reference in and shall form a part of this Agreement. Any
agreement between an Agent and the members of any sub-agent group or selling group formed in
connection with the Offering shall contain the restrictions in Schedule A hereto. 3. Delivery of
Subscription Agreements The Agents agree to obtain from each Subscriber executed Subscription
Agreements (including the execution of applicable Schedules to such Subscription Agreements) and
deliver such Subscription Agreements (including applicable Schedules) to the Corporation at or prior
to the Closing Time. In addition, the Agents agree to obtain from each Subscriber such forms and
other documents as may be required by the Securities Commissions and by the Corporation's registrar
and provided by the Corporation to the Agents for delivery under this Agreement. The Corporation and
the Agents shall agree on the allocation of the Offered Shares amongst the Subscribers. 4.
Representations and Warranties of the Corporation The Corporation represents, warrants and covenants
to the Agents, and acknowledges that the Agents are relying upon such representations, warranties
and covenants, that: (a) the Corporation (i) is duly amalgamated under the Business Corporations Act
(Ontario) (the "Act") and is up-to-date in respect of all material corporate filings and is in good
standing under such Act; (ii) has all requisite corporate power, authority and capacity to carry on
its business as now conducted and to own, lease and operate its properties and assets (including as
described in the Public Disclosure); and (iii) has all requisite corporate power, authority and
capacity to create, issue and sell the Offered Shares, to enter into this Agency Agreement and the
Compensation Option Certificates, and to carry out the provisions contained in hereunder and
thereunder; (b) the Corporation does not have any material subsidiaries; (c) no proceedings have
been taken, instituted or, to the knowledge of the Corporation, are pending for the dissolution or
liquidation of the Corporation; (d) the Corporation has conducted its business in compliance, in all
material respects, with all applicable laws, rules and regulations (including all applicable
federal, national, provincial, municipal, and local environmental anti-pollution and licensing laws,
regulations and other lawful requirements of any governmental or regulatory body, of each
jurisdiction in which its business is carried on and is licensed, registered or qualified in all
jurisdictions in which it owns, leases or operates its property or carries on business to enable its
business to be carried on as now conducted and its property and assets to be owned, leased and
operated and all such licences, registrations and qualifications are valid, subsisting and in good
standing and it has not received a notice of non-compliance, nor knows of, nor has reasonable
grounds to know of, any facts that could give rise to a notice of non-compliance with any such laws,
regulations or permits which could reasonably be expected to have a Material Adverse Effect and all
such licences, registrations and qualifications are valid, subsisting and in good standing; 6
<!-- page 7 -->
(e) all necessary corporate action has been taken or will have been taken prior to the Closing Time
by the Corporation so as to validly issue and sell the Offered Shares and to issue the Compensation
Options; (f) except for the approval of the TSXV and any post-closing notice filings required under
applicable United States federal or state securities laws, all consents, approvals, authorizations
and corporate action have been taken and all necessary documents have been delivered and executed
with respect to the Offering; (g) the execution and delivery of this Agency Agreement and the
Compensation Option Certificates, and the performance of the transactions contemplated hereby and
thereby, including the issuance and sale of the Offered Shares, have been duly authorized by all
necessary corporate action of the Corporation and this Agency Agreement has been executed and
delivered by the Corporation and constitutes a valid and binding obligation of the Corporation,
enforceable against the Corporation in accordance with its terms, provided that enforcement thereof
may be limited by laws affecting creditors' rights generally, that specific performance and other
equitable remedies may only be granted in the discretion of a court of competent jurisdiction, that
the provisions thereof relating to indemnity, contribution and waiver of contribution may be
unenforceable under applicable law and that enforceability is subject to the provisions of the
Limitations Act, 2002 (Ontario); (h) except for any post-closing notice filings required under
applicable United States federal or state securities laws, the execution and delivery of this Agency
Agreement and the Compensation Option Certificates, and the fulfilment of the terms hereof and
thereof by the Corporation, including the issuance and sale of the Offered Shares, do not and will
not require the consent, approval, authorization, registration or qualification of or with any
Governmental Authority, stock exchange, Securities Commission or other third party, except such as
have been obtained or such as may be required (and shall be obtained prior to the Closing Time)
under Applicable Securities Laws or stock exchange regulations; (i) the Offered Shares have been, or
prior to the Closing Time will be, duly and validly authorized for issuance and, upon receipt by the
Corporation of the purchase price for the Offered Shares, will be validly issued as fully paid and
non-assessable Common Shares; 7
<!-- page 8 -->
(j) the Compensation Options have been, or prior to the Closing Time will be duly and validly
authorized and created; (k) the Compensation Option Shares to be issued upon exercise of the
Compensation Options, including payment in full of the applicable exercise price, will be validly
issued as fully paid and non-assessable Common Shares; (l) the authorized capital of the Corporation
consists of an unlimited number of Common Shares, of which, as of May 20, 2015, 100,675,988 Common
Shares were outstanding as fully paid and non-assessable Common Shares; (m) the Corporation is not
aware of any legislation, or proposed legislation published by a legislative body, which it
anticipates will materially and adversely affect the business, affairs, operations, assets,
liabilities (contingent or otherwise) or prospects of the Corporation on a consolidated basis; (n)
no order ceasing or suspending trading in any securities of the Corporation or prohibiting the sale
of the Offered Shares or the trading of any of the Corporation's issued securities has been issued
and no proceedings for such purpose are threatened or, to the best of the Corporation's knowledge,
pending; (o) except as disclosed to the Agents, no person now has any agreement or option or right
or privilege (whether at law, pre- emptive or contractual) capable of becoming an agreement for the
purchase, subscription or issuance of, or conversion into, any unissued shares, securities, warrants
or convertible obligations of any nature of the Corporation; (p) since December 31, 2013, except as
disclosed in the Public Record: (i) there has not been any material change in the assets,
liabilities, obligations (absolute, accrued, contingent or otherwise), business, condition
(financial or otherwise) or results of operations of the Corporation on a consolidated basis; (ii)
there has not been any material change in the capital stock or long-term debt of the Corporation on
a consolidated basis; and (iii) the Corporation has carried on its business in the ordinary course;
(q) the Financial Statements of the Corporation present fairly, in all material respects, the
financial condition of the Corporation on a consolidated basis for the periods then ended; (r) the
Corporation does not have any liabilities, direct or indirect, contingent or otherwise, not
disclosed in the Public Record which could reasonably be expected to have a Material Adverse Effect;
(s) except as disclosed in the Public Record (and certain other matters disclosed in writing to the
Agents that the Corporation believes are without merit and/or would not have a Material Adverse
Effect), there are no threats of actions, proceedings or investigations (whether or not purportedly
by or on behalf of the Corporation) that have been made to the Corporation or, to the knowledge of
the Corporation, that are pending or affecting the Corporation at law or in equity (whether in any
court, arbitration or similar tribunal) or before or by any federal, provincial, state, municipal or
other governmental department, commission, board or agency, domestic or foreign, which could
reasonably be expected to have a Material Adverse Effect; 8
<!-- page 9 -->
(t) the execution and delivery of this Agency Agreement and the Compensation Option Certificates,
and the fulfilment of the terms hereof and thereof by the Corporation, including the issuance and
sale of the Offered Shares, do not and will not (as the case may be) conflict with or result in a
breach or violation of any of the terms or provisions of, or constitute a default under, whether
after notice or lapse of time or both, (A) any statute, rule or regulation applicable to the
Corporation, including Applicable Securities Laws; (B) the constating documents, by-laws or
resolutions of the Corporation; (C) the terms of any Debt Instrument, Material Agreement, mortgage,
note, indenture, instrument, lease or any other material agreement to which the Corporation is a
party or by which they are bound; or (D) any judgment, decree or order binding the Corporation or
the respective property or assets of the Corporation; (u) to the knowledge of the Corporation, no
agreement is in force or effect which in any manner affects the voting or control of any of the
securities of the Corporation; (v) the Corporation is not included in a list of defaulting reporting
issuers maintained by the Securities Commissions in the Qualifying Jurisdictions and in particular,
without limiting the foregoing, the Corporation has at all relevant times complied with its
obligations to make timely disclosure of all material changes relating to it, no such disclosure has
been made on a confidential basis that is still maintained on a confidential basis, and there is no
material change relating to the Corporation which has occurred and with respect to which the
requisite material change report has not been filed with the Securities Commissions and the
Corporation is in all material respects in compliance with the rules and regulations of the TSXV;
(w) the Corporation has complied in all material respects with requirements to file all reports,
schedules, forms, statements and other documents that it is required to file under the U.S. Exchange
Act, including pursuant to Section 13(a) or 15(d) of the U.S. Exchange Act, including the exhibits
thereto and documents incorporated by reference therein, being collectively referred to herein as
the "SEC Reports") on a timely basis or has received a valid extension of such time of filing and
has filed any such SEC Reports prior to the expiration of any such extension. As of their respective
dates, the SEC Reports complied in all material respects with the respective requirements of the
U.S. Exchange Act and the rules and regulations of the SEC promulgated thereunder. The financial
statements of the Corporation included in the SEC Reports comply in all material respects with
applicable accounting requirements and the rules and regulations of the Commission with respect
thereto as in effect at the time of filing. Such financial statements have been prepared in
accordance with U.S. generally accepted accounting principles applied on a consistent basis during
the periods involved ("GAAP"), except as may be otherwise specified in such financial statements or
the notes thereto and except that unaudited financial statements may not contain all footnotes
required by GAAP, and fairly present in all material respects the financial position of the
Corporation as of and for the dates thereof and the results of operations and cash flows for the
periods then ended, subject, in the case of unaudited statements, to normal, immaterial, year-end
audit adjustments; 9
<!-- page 10 -->
(x) neither the Corporation nor, to the knowledge of the Corporation, any director, officer, agent,
employee, affiliate or other person acting on behalf of the Corporation is aware of or has taken any
action, directly or indirectly, that has resulted or would result in a violation of the Foreign
Corrupt Practices Act of 1977 (United States), as amended, and the rules and regulations thereunder
(the "FCPA"), and the Corruption of Foreign Public Officials Act (Canada) (the "CFPOA") including,
without limitation, making use of the mails or any means or instrumentality of interstate commerce
corruptly in furtherance of an offer, payment, promise to pay or authorization of the payment of any
money, or other property, gift, promise to give, or authorization of the giving of anything of value
to any "foreign official" (as such term is defined in the FCPA) or any "foreign public official" (as
such term is defined in the CFPOA) or any foreign political party or official thereof or any
candidate for foreign political office, in contravention of the FCPA and the CFPOA; and the
Corporation will monitor its respective businesses to ensure compliance with the FCPA and the CFPOA,
as applicable, and, if violations of the FCPA or the CFPOA are found, will take remedial action to
remedy such violations; (y) the operations of the Corporation are, and have been conducted at all
times, in compliance with all material applicable financial recordkeeping and reporting requirements
of the Currency and Foreign Transactions Reporting Act of 1970 (United States), as amended, the
Proceeds of Crime (Money Laundering) and Terrorist Financing Act (Canada), the money laundering
statutes of all applicable jurisdictions, the rules and regulations thereunder and any related or
similar applicable rules, regulations or guidelines, issued, administered or enforced by any
governmental agency (collectively, the "Money Laundering Laws") and no action, suit or proceeding by
or before any court or governmental agency, authority or body or any arbitrator involving the
Corporation with respect to the Money Laundering Laws is pending or, to the knowledge of the
Corporation, threatened; (z) neither the Corporation nor, to the knowledge of the Corporation, any
director, officer, agent, employee, affiliate or person acting on behalf of the Corporation is
currently subject to any United States sanctions administered by the Office of Foreign Assets
Control of the United States Treasury Department ("OFAC"); and the Corporation will not directly or
indirectly use the proceeds of this Offering, or lend, contribute or otherwise make available such
proceeds to any subsidiary, joint venture partner or other person or entity, for the purpose of
financing the activities of any person currently subject to any United States sanctions administered
by OFAC; 10

(aa) all filings and fees required to be made and paid by the Corporation pursuant to Applicable
Securities Laws have been paid or will be promptly paid by the Corporation following the Closing
Time; (bb) the Corporation's Auditors who audited the consolidated financial statements of the
Corporation for the year ended December 31, 2014 and delivered their auditors' report thereto are
independent public accountants as required by the Canadian Securities Laws; (cc) there has not been
any "reportable event" (within the meaning of National Instrument 51- 102 - Continuous Disclosure
Obligations with the Corporation's Auditors; (dd) all taxes (including income tax, capital tax,
payroll taxes, employer health tax, workers' compensation payments, property taxes, custom and land
transfer taxes), duties, royalties, levies, imposts, assessments, deductions, charges or
withholdings and all liabilities with respect thereto including any penalty and interest payable
with respect thereto (collectively, "Taxes") due and payable by the Corporation have been paid,
except for where the failure to pay such taxes would not constitute an adverse material fact of the
Corporation or result in a Material Adverse Effect. All tax returns, declarations, remittances and
filings required to be filed by the Corporation have been filed with all appropriate Governmental
Authorities and all such returns, declarations, remittances and filings are complete and materially
accurate and no material fact or facts have been omitted therefrom which would make any of them
misleading except where the inaccuracy or failure to file such documents would not constitute an
adverse material fact of the Corporation or result in a Material Adverse Effect. No examination of
any tax return of the Corporation is currently in progress and there are no issues or disputes
outstanding with any Governmental Authority respecting any taxes that have been paid, or may be
payable, by the Corporation, in any case, except where such examinations, issues or disputes would
not constitute an adverse material fact of the Corporation or result in a Material Adverse Effect;
(ee) neither the Corporation or to the knowledge of the Corporation any other person, is in default
in the observance or performance of any term, covenant or obligation to be performed by the
Corporation or such other person under any Debt Instrument, Material Agreement, agreement, or
arrangement to which the Corporation is a party or otherwise bound which could reasonably be
expected to have a Material Adverse Effect, and all such contracts, agreements or arrangements are
in good standing, and to the knowledge of the Corporation no event has occurred which with notice or
lapse of time or both would constitute such a default by the Corporation or any other party; (ff)
Equity Financial Trust Company at its principal transfer office in the City of Toronto, Ontario has
been duly appointed as the registrar and transfer agent for the Common Shares; (gg) except as
disclosed in the Public Record, none of the directors or officers of the Corporation, any known
holder of more than 10% of any class of shares of the Corporation, or any known associate or
affiliate of any of the foregoing persons, has had any material interest, direct or indirect, in any
transaction during the three most recently completed financial years or during the current financial
year, or any proposed material transaction which, as the case may be, materially affected, is
material to or will materially affect the Corporation on a consolidated basis; 11
<!-- page 11 -->
(hh) each Debt Instrument to which the Corporation is a party is in good standing and the
Corporation is not in default of any obligation or covenant under such Debt Instruments and, except
for intercompany debt, the Corporation is not party to any material Debt Instrument or has any
material loans or other indebtedness outstanding which has been made to any of its shareholders,
officers, directors or employees, past or present, or any person not dealing at arm's length with
them; (ii) the Corporation is in compliance, in all material respects, with all applicable federal,
provincial, state, municipal and local laws, statutes, ordinances, by laws and regulations and
orders, directives and decisions rendered by any ministry, department or administrative or
regulatory agency, domestic or foreign (the "Environmental Laws") relating to the protection of the
environment, occupational health and safety or the processing, use, treatment, storage, disposal,
discharge, transport or handling of any pollutants, contaminants, chemicals or industrial, toxic or
hazardous wastes or substance ("Hazardous Substances"); (jj) the Corporation has collectively,
obtained all material licences, permits, approvals, consents, certificates, registrations and other
authorizations under all applicable Environmental Laws (the "Environmental Permits") necessary as at
the date hereof for the operation of the business carried by the Corporation; (kk) the Corporation
has not used, except in compliance in all material respects with all Environmental Laws and
Environmental Permits, any property or facility which it owns or leases or previously owned or
leased, to generate, manufacture, process, distribute, use, treat, store, dispose of, transport or
handle any Hazardous Substance; (ll) the Corporation has not received any notice of, or been
prosecuted for an offence alleging, non-compliance with any Environmental Law. There are no orders
or directions relating to environmental matters requiring any material work, repairs, construction
or capital expenditures to be made with respect to any of the assets of the Corporation which are
material to the Corporation, nor has the Corporation received notice of any of the same; (mm) the
Corporation has not received any notice wherein it is alleged or stated that it is potentially
responsible for a federal, provincial, state, municipal or local clean-up site or corrective action
under any Environmental Laws and the Corporation has not received any request for information in
connection with any federal, state, provincial, municipal or local inquiries as to disposal sites;
12
<!-- page 12 -->
(nn) except as disclosed in the Public Record, the Corporation is the sole and exclusive owner of
all right, title and interest in and to, or has a valid and enforceable right to use pursuant to a
written license, all trademarks, trade names, service marks, patents, patent applications, other
patent rights, copyrights, domain names, software, inventions, processes, databases, know-how
(including trade secrets and other unpatented and/or unpatentable proprietary or confidential
information, systems or procedures) and other similar intellectual property rights, whether
registered or unregistered and in any jurisdiction (collectively, "Intellectual Property Rights")
reasonably necessary to conduct its business as now conducted or proposed to be conducted. To the
knowledge of the Corporation, the Corporation's business as now conducted or proposed to be
conducted as described in the Public Record, does not infringe, conflict with or otherwise violate
any Intellectual Property Rights of others, and the Corporation has not received, and has no reason
to believe that it will receive, any notice of infringement or conflict with asserted Intellectual
Property Rights of others, or any facts or circumstances which would render any Intellectual
Property Rights invalid or inadequate to protect the interest of the Corporation therein. Except as
disclosed to the Agent, to the knowledge of the Corporation, there is no infringement by third
parties of any Intellectual Property Rights owned by the Corporation. Except as disclosed in the
Public Record, there is no pending or, to the knowledge of the Corporation, threatened action, suit,
proceeding or claim relating to Intellectual Property Rights owned by the Corporation. Except as
disclosed in the Public Record, the Corporation is not a party to or bound by any options, licenses
or agreements with respect to the Intellectual Property Rights of any other person or entity. All
licenses for Intellectual Property Rights owned or used by the Corporation are valid, binding upon
and enforceable by or against the Corporation and, to the Corporation's knowledge, against the
parties thereto in accordance with their terms. To the knowledge of the Corporation, none of the
technology employed by the Corporation has been obtained or is being used by the Corporation in
violation of any contractual obligation binding on the Corporation or, to the Corporation's
knowledge, any of its officers, directors or employees or otherwise in violation of the rights of
any third party. All assignments from inventors to the Corporation have been obtained and filed with
the appropriate patent offices for all of the Corporation's patent applications. Except as disclosed
in the Public Record the Corporation does not have knowledge of any claims of third parties to any
ownership interest or lien with respect to the Corporation's or its licensors' patents and patent
applications. The Corporation does not know of any facts which would form a basis for a finding of
unenforceability or invalidity of any of the patents, trademarks or service marks of the
Corporation. The Corporation does not know of any material defects of form in the preparation or
filing of the patent applications of the Corporation. To the knowledge of the Corporation, the
Corporation has complied with the U.S. Patents and Trademark Office duties and Canadian equivalent
duties of candor and disclosure for each patent and patent application of the Corporation. The
Corporation does not know of any fact with respect to the patent applications of the Corporation
presently on file that (i) would preclude the issuance of patents with respect to such applications,
(ii) would lead the Corporation to conclude that such patents, when issued, would not be valid and
enforceable in accordance with applicable regulations or (iii) would result in a third party having
any rights in any patents issuing from such patent applications. The Corporation has taken all
commercially reasonable steps to protect, maintain and safeguard its rights in all material
Intellectual Property Rights, including the execution of appropriate nondisclosure and
confidentiality agreements; 13
<!-- page 13 -->
(oo) except as disclosed to the Agents, the Corporation (or parties under contractual obligation to
the Corporation) holds all licenses, certificates, approvals and permits from all provincial,
federal, state, United States, foreign and other regulatory authorities, including but not limited
to the United States Food and Drug Administration (the "FDA"), Health Canada ("HC"), the European
Medicines Agency (the "EMA") and any foreign regulatory authorities performing functions similar to
those performed by the FDA, HC and the EMA, that are material to the conduct of the business of the
Corporation as such business is now conducted or proposed to be conducted as described in the Public
Record, all of which are valid and in full force and effect and there is no proceeding pending or,
to the knowledge of the Corporation, threatened which may cause any such license, certificate,
approval or permit to be withdrawn, cancelled, suspended or not renewed. Nothing has come to the
attention of the Corporation that has caused the Corporation to believe that the completed studies,
tests, preclinical studies and clinical trials conducted by or on behalf of the Corporation that are
described in the Public Record were not conducted, in all material respects, in accordance with
experimental protocols, procedures and controls pursuant to, where applicable, accepted professional
and scientific standards for products or product candidates comparable to those being developed by
the Corporation; or that the drug substances used in the clinical trials have not been manufactured,
under "current good manufacturing practices", when required, in the United States, Canada and other
jurisdictions in which such clinical trials have been and are being conducted. No filing or
submission to the FDA, HC, the EMA or any other regulatory body, that was or is intended to be the
basis for any approval of the Corporation's products or product candidates, to the knowledge of the
Corporation, contains any material omission or material false information. The Corporation is not in
violation of any material law, order, rule, regulation, writ, injunction or decree of any court or
governmental agency or body, applicable to the investigation of new drugs in humans and animals,
including, but not limited to, those promulgated by the FDA, HC or the EMA; (pp) the descriptions in
the Public Record of the results of the clinical trials referred to therein are consistent in all
material respects with such results and no other studies or other clinical trials whose results are
known to the Corporation are materially inconsistent with or otherwise materially call into question
the results described or referred to in the Public Record. To the Corporation's knowledge, the
studies, tests and preclinical and clinical trials conducted by or on behalf of the Corporation were
and, if still pending, are, in all material respects, being conducted in accordance with
experimental protocols, procedures and controls pursuant to accepted professional scientific
standards and all applicable laws and authorizations; (qq) the Corporation possesses such valid and
current certificates, authorizations or permits issued by the appropriate federal, provincial,
state, local or foreign regulatory agencies or bodies necessary to conduct its business, except
where the failure to possess such certificates, authorizations or permits would not, individually or
in the aggregate, result in a Material Adverse Change, and the Corporation has not received, nor has
any reason to believe that it will receive, any notice of proceedings relating to the revocation or
modification of, or non-compliance with, any such certificate, authorization or permit which, singly
or in the aggregate, if the subject of an unfavourable decision, ruling or finding, could result in
a Material Adverse Change; 14
<!-- page 14 -->
(rr) neither the Corporation or, to the best of its knowledge, any employee or agent thereof, has
made any unlawful contribution or other payment to any official of, or candidate for, any federal,
state, provincial or foreign office, or failed to disclose fully any contribution, in violation of
any law, or made any payment to any foreign, Canadian, governmental officer or official, or other
Person charged with similar public or quasi-public duties, other than payments required or permitted
by applicable laws; (ss) there are no environmental audits, evaluations, assessments, studies or
tests relating to the Corporation except for ongoing assessments conducted by or on behalf of the
Corporation in the ordinary course; (tt) each material plan for retirement, bonus, stock purchase,
profit sharing, stock option, deferred compensation, severance or termination pay, insurance,
medical, hospital, dental, vision care, drug, sick leave, disability, salary continuation, legal
benefits, unemployment benefits, vacation, incentive or otherwise contributed to or required to be
contributed to, by the Corporation for the benefit of any current or former director, officer,
employee or consultant of the Corporation (the "Employee Plans") has been maintained in compliance
with its terms and with the requirements prescribed by any and all statutes, orders, rules and
regulations that are applicable to such Employee Plans, in each case in all material respects and
has been publicly disclosed to the extent required by Applicable Securities Laws; (uu) all material
accruals for unpaid vacation pay, premiums for employment insurance, health premiums, federal or
state pension plan premiums, accrued wages, salaries and commissions and employee benefit plan
payments have been reflected in the books and records of the Corporation; (vv) there has never been,
there is not currently and the Corporation does not anticipate any labour disruption with respect to
the employees or consultants of the Corporation which is adversely affecting or could adversely
affect the carrying on of the business of the Corporation; (ww) the minute books of the Corporation
made available to the Agents contain copies of all constating documents and all proceedings of
security holders and directors (and committees thereof) and are complete in all material respects;
(xx) the Corporation is not aware of any circumstances presently existing under which liability is
or could reasonably be expected to be incurred under Part XXIII.1 - Civil Liability for Secondary
Market Disclosure of the Securities Act (Ontario) or analogous securities laws in the other
Qualifying Jurisdictions; 15
<!-- page 15 -->
(yy) other than the Agents, there is no person acting or purporting to act at the request or on
behalf of the Corporation that is entitled to any brokerage or finder's fee in connection with the
transactions contemplated by this Agency Agreement; (zz) the Corporation will use the proceeds from
the Offering for acquisitions and working capital; and (aaa) the Corporation has complied and will
comply with the representation, warranties and covenants applicable to it in Schedule "A" and
Schedule "A" is true and correct in all material respects. 5. Agents' Fee In consideration for the
Agents' services hereunder, the Corporation will pay to the Agents the Agents' Fee and the
Corporation shall issue to the Agents that number of Compensation Options equal to 3.5% of the
number of Offered Shares sold pursuant to the Offering. Unless otherwise stated herein, the Offered
Shares shall also refer to the Compensation Options. The Agents' Fee shall be apportioned among the
Agents as follows: Dundee Securities Ltd. 40% Kes 7 Capital Inc. 30% Bloom Burton & Co. Ltd. 30%
100% 6. Closing The sale of the Offered Shares shall be completed at the Closing Time at the offices
of Corporation's Counsel in Toronto, Ontario or at such other place as the Corporation and the
Agents may agree. At the Closing Time, the Corporation shall deliver to the Agents: (a) the
opinions, certificates and agreements referred to in Section 9 and all other documents required to
be provided by the Corporation to the Agents pursuant to this Agreement and the Subscription
Agreements; (b) except for any Offered Shares offered or sold in the United States which shall be
represented by individual definitive share certificates, one or more definitive share
certificate(s)/and or book-entry only securities, duly registered as the Lead Agent may direct the
Corporation; (c) the Corporation's receipt for payment by the Agents of an amount equal to the
aggregate purchase price for the Offered Shares sold pursuant to the Offering; and (d) such further
documentation as may be contemplated by this Agreement or as Agents' Counsel or the applicable
regulatory authorities may reasonably require; against delivery by the Agents of: 16
<!-- page 16 -->
(e) all duly completed Subscription Agreements tendered by the Subscribers for the Offered Shares
being issued and sold and, where applicable, all completed forms, schedules and certificates
contemplated by such Subscription Agreements; (f) a wire transfer of immediately available funds in
an amount equal to the aggregate purchase price for the Offered Shares sold pursuant to the
Offering, less an amount equal to the Agents' Fee and the costs and expenses of the Agent provided
for in Section 14; and (g) the Agents' receipt for the Agents' Fee and the definitive certificates
delivered to the Agents in accordance with Section 6(b). 7. Delivery of Offered Shares The
Corporation shall, prior to the Closing Date, make all necessary arrangements for the preparation
and delivery (and, in the case of definitive certificates, execution of such definitive
certificate(s) representing the Offered Shares) of the Offered Shares on the Closing Date in the
City of Toronto. The Corporation shall pay all fees and expenses payable to its transfer agent in
connection with the preparation and delivery (and, in the case of definitive certificates, execution
of such definitive certificate(s) representing the Offered Shares) of the Offered Shares
contemplated by this Section 7 and the fees and expenses payable to its transfer agent as may be
required in the course of the distribution of the Offered Shares. 8. Agency Basis The Corporation
agrees that the Agents are acting as agents of the Corporation in seeking purchasers of Offered
Shares without underwriter liability, and nothing in this Agreement or any other agreement shall
require the Agents to purchase any of the Offered Shares in connection with the Offering. 9.
Conditions to Closing The sale of the Offered Shares shall be subject to the representations,
warranties and covenants of the Corporation contained in this Agreement being accurate as of the
date of this Agreement and as of the Closing Date, to the Corporation having performed all of its
obligations under this Agreement and to the following additional conditions, and the Agents shall
have the right on the Closing Date on behalf of Subscribers for Offered Shares to withdraw, all
Subscription Agreements delivered and not previously withdrawn by Subscribers unless such conditions
have been satisfied: (a) Delivery of Opinions (i) The Agents shall have received at the Closing Time
a legal opinion dated the Closing Date, in form and substance satisfactory to the Agents, acting
reasonably, addressed to the Agents (and, if required for opinion purposes, counsel to the Agents)
from Corporation's Counsel as to the laws of Canada and the Selling Jurisdictions in Canada, which
counsel in turn may rely upon the opinions of local counsel where it deems such reliance proper as
to the laws other than those of Canada and such provinces in Canada where Corporation's Counsel is
licensed to practice law (or alternatively make arrangements to have such opinions directly
addressed to the Agents) and as to matters of fact, on certificates of Governmental Authorities and
officers of the Corporation and letters from stock exchange representatives and transfer agents,
with respect to customary corporate, securities law and other matters requested by the Agents. (ii)
The Agents shall have received at the Closing Time an opinion of U.S. counsel to the Corporation,
Troutman Sanders LLP, in form and substance satisfactory to the Agents, acting reasonably, to the
effect that the offer and sale of the Offered Shares in the United States do not require
registration under the U.S. Securities Act. 17
<!-- page 17 -->
(iii) The Agents having received at the Closing Time such further opinions, certificates and other
documentation from the Corporation as may be contemplated herein or as the Agents may reasonably
require, provided, however, that the Agents shall request any such opinion, certificate or document
within a reasonable period prior to the Closing Time that is sufficient for the Corporation to
obtain and deliver such certificate or document. (b) Delivery of Certificates (i) The Agents shall
have received at the Closing Time a certificate dated the Closing Date, addressed to the Agents
(and, if necessary for opinion purposes, counsel to the Agents) and signed by officers of the
Corporation acceptable to the Agents, acting reasonably, with respect to the constating documents of
the Corporation, no proceedings to voluntarily wind-up or dissolve, all resolutions of the board of
directors of the Corporation relating to this Agreement and the transactions contemplated by this
Agreement and the incumbency and specimen signatures of signing officers of the Corporation and such
other matters as the Agents may reasonably request. (ii) The Agents shall have received at the
Closing Time a certificate of good standing of the Corporation. (iii) The Agents shall have received
at the Closing Time a certificate dated the Closing Date, addressed to the Agents and counsel to the
Agents and signed on behalf of the Corporation by the Chief Executive Officer and the Chief
Financial Officer or other officers of the Corporation acceptable to the Agents, certifying for and
on behalf of the Corporation and without personal liability, after having made due enquiry: (A) the
Corporation has complied with and satisfied all terms and conditions of this Agreement and the
Subscription Agreements on its part to be complied with or satisfied at or prior to the Closing
Time; 18
<!-- page 18 -->
(B) the representations and warranties of the Corporation contained in this Agreement and the
Subscription Agreements are true and correct at the Closing Time with the same force and effect as
if made at and as of the Closing Time after giving effect to the transactions contemplated by this
Agreement; (C) the responses provided by the Corporation at the Due Diligence Session are true and
correct and would not be different in any material respect if the Due Diligence Session were held
immediately prior to the Closing Time; (D) the Corporation has made and/or obtained, on or prior to
the Closing Time, all necessary filings, approvals, consents and acceptances of applicable
regulatory authorities and under any applicable agreement or document to which the Corporation is a
party or by which it is bound, required for the execution and delivery of this Agreement, the
offering and sale of the Offered Shares in the Selling Jurisdictions in Canada and the consummation
of the other transactions contemplated hereby (subject to completion of filings with certain
regulatory authorities following the Closing Date); (E) no order, ruling or determination having the
effect of suspending the sale of or cease trading the Offered Shares or any other securities of the
Corporation has been issued by any regulatory authority and is continuing in effect and no
proceedings for that purpose have been instituted or are pending or, to the knowledge of such
officer of the Corporation, contemplated or threatened under any Applicable Securities Laws or by
any other regulatory authority; and (F) such other matters as may be reasonably requested by the
Agents or the Agents' Counsel. (c) Exchange Approval The Corporation shall have obtained the
conditional approval of the TSX-V and any other applicable exchange in respect of the issuance and
sale of the Offered Shares and all other necessary regulatory approvals prior to the Closing. (d)
Consents All required third party consents and waivers necessary for the Corporation to enter into
this Agreement and to consummate the transactions contemplated by this Agreement shall have been
received at or prior to the Closing Time. 19
<!-- page 19 -->
The foregoing conditions contained in this Section 9 are for the sole benefit of the Agents and may
be waived in whole or in part by the Agents at any time and without limitation. If any of the
foregoing conditions have not been met at the Closing Time, the Agents may terminate their
obligations under this Agreement without prejudice to any other remedies they may have and the
Agents shall have the right on behalf of the Subscribers to withdraw all Subscription Agreements
delivered and not previously withdrawn by Subscribers. 10. Rights of Termination (a) Regulatory
Proceedings Out If, after the date hereof and prior to the Closing Time, any enquiry, action, suit,
investigation or other proceeding, whether formal or informal, is instituted or announced or any
order is made by any federal, provincial or other Governmental Authority in relation to the
Corporation which, in the opinion of any of the Agents, operates to prevent or restrict the
distribution or trading of the Offered Shares, then such Agent shall be entitled, at its option and
in accordance with Section 10(e), to terminate its obligations under this Agreement by notice to
that effect given to the Corporation any time at or prior to the Closing Time. (b) Disaster Out If
prior to the Closing Time there should develop, occur or come into effect or existence any event,
action, state, condition or major financial occurrence of national or international consequence or
any law or regulation which, in the opinion of any of the Agents, seriously adversely affects, or
involves, or will seriously adversely affect, or involve, the financial markets or the business,
operations or affairs of the Corporation and its subsidiaries taken as a whole, then such Agent
shall be entitled, at its option and in accordance with Section 10(e), to terminate its obligations
under this Agreement by written notice to that effect given to the Corporation at any time at or
prior to the Closing Time. (c) Material Change or Change in Material Fact Out If, after the date
hereof and prior to the Closing Time, there shall occur any material change or change in a material
fact which, in the reasonable opinion of any of the Agents, would be expected to have a significant
adverse effect on the business, affairs, prospects or financial condition of the Corporation and its
subsidiaries taken as a whole or the market price or value of the securities of the Corporation,
then such Agent shall be entitled, at its option, in accordance with Section 10(e), to terminate its
obligations under this Agreement by written notice to that effect given to the Corporation any time
at or prior to the Closing Time. (d) Non-Compliance with Conditions The Corporation agrees that all
terms and conditions in Section 9 shall be construed as conditions and complied with so far as they
relate to acts to be performed or caused to be performed by it, that it will use its best efforts to
cause such conditions to be complied with, and that any breach or failure by the Corporation to
comply with any such conditions shall entitle any of the Agents, in accordance with Section 10(e),
to terminate its obligations under this Agreement by written notice to that effect given to the
Corporation at any time at or prior to the Closing Time, unless otherwise expressly provided in this
Agreement. Each Agent may waive, in whole or in part, or extend the time for compliance with, any
terms and conditions without prejudice to its rights in respect of any other terms and conditions or
any other or subsequent breach or non- compliance, provided that any such waiver or extension shall
be binding upon an Agent only if such waiver or extension is in writing and signed by the Agent. 20

(e) Exercise of Termination Rights The rights of termination contained in Sections 10(a), (b), (c)
and (d) may be exercised by any of the Agents and are in addition to any other rights or remedies
any of the Agents may have in respect of any default, act or failure to act or non- compliance by
the Corporation in respect of any of the matters contemplated by this Agreement or otherwise. In the
event of any such termination, there shall be no further liability on the part of the Agents to the
Corporation or on the part of the Corporation to the Agents except in respect of any liability which
may have arisen prior to or arise after such termination under Sections 11, 12 and 14. A notice of
termination given by an Agent under Section 10(a), (b), (c) or (d) shall not be binding upon any
other Agent who has not also executed such notice. 11. Indemnity (a) Rights of Indemnity (1) The
Corporation covenants and agrees to protect, indemnify, and save harmless, each of the Agents and
their respective affiliates, and each and every one of the directors, officers, employees, partners
and agents of the Agents (individually, an "Indemnified Party" and collectively, the "Indemnified
Parties") harmless from and against any and all expenses, losses (excluding loss of profits),
claims, actions, damages (other than consequential or punitive damages) or liabilities, joint or
several (including the aggregate amount paid in settlement of any actions, suits, proceedings or
claims and the reasonable fees and expenses of their counsel that may be incurred in advising with
respect to and/or defending any claim that may be made against the Indemnified Parties) to which any
Indemnified Party may become subject or otherwise involved in any capacity under any statute or
common law or otherwise insofar as such expenses, losses, claims, damages, liabilities or actions
arise out of or are based, directly or indirectly, upon the performance of professional services
rendered to the Corporation by the Indemnified Parties (or any of them), whether directly or
indirectly, including by reason of: (a) any information or statement contained in this Agreement,
the Corporation's publicly available disclosed documents filed on SEDAR or elsewhere, or in any
other material prepared by the Corporation used for marketing the Offering or any certificate of the
Corporation delivered hereunder or pursuant hereto, which at the time and in the light of the
circumstances under which it was made contains or is alleged to contain a misrepresentation or any
misstatement of a material fact; 21
<!-- page 20 -->
(b) the omission or alleged omission to state in in this Agreement, the Corporation's publicly
available disclosed documents filed on SEDAR or elsewhere, or in any other material prepared by the
Corporation used for marketing the Offering or any certificate of the Corporation delivered
hereunder or pursuant hereto, any material fact required to be stated therein or necessary to make
any statement therein not misleading in light of the circumstances in which it was made; (c) any
order made, or inquiry, investigation or proceeding commenced by any securities regulatory authority
or other competent authority based upon any misrepresentation, untrue statement or omission or
alleged untrue statement or omission in this Agreement, the Corporation's publicly available
disclosed documents filed on SEDAR or elsewhere, or in any other material prepared by the
Corporation used for marketing the Offering or any certificate of the Corporation delivered
hereunder or pursuant hereto that prevents or restricts the trading in any of the Corporation's
securities or the distribution or distribution to the public, as the case may be, of any of the
Offered Shares in any of the Qualifying Jurisdictions; (d) the Corporation not complying with any
requirement of Applicable Securities Laws or stock exchange requirements in connection with the
transactions contemplated herein, including the Corporation's non-compliance with any statutory
requirement to make any document available for inspection; or (e) any breach of a representation or
warranty of the Corporation contained in this Agreement or the failure of the Corporation to comply
with any of its obligations hereunder. (2) Notwithstanding Subsection 11(a) (1), the indemnification
in Subsection 11(a)(1) does not and shall not apply to the extent that a court of competent
jurisdiction in a final judgment that has become non- appealable shall determine that (a) the Agents
and their respective affiliates have been negligent or have committed any fraudulent or illegal act
in the course of the professional services rendered to the Corporation, and (b) such expenses,
losses, claims, damages, liabilities or actions were caused or incurred by the gross negligence,
fraud or wilful misconduct of the Agents. (3) If any matter or thing contemplated by this Section 11
shall be asserted against any Indemnified Party in respect of which indemnification is or might
reasonably be considered to be provided, such Indemnified Party will notify the Corporation in
writing as soon as possible of the nature of such claim (provided that omission to so notify the
Corporation will not relieve the Corporation of any liability that it may otherwise have to the
Indemnified Party hereunder, except to the extent the Corporation is materially prejudiced by such
omission) and the Corporation shall be entitled (but not required) to assume the defence of any suit
brought to enforce such claim; provided, however, that the defence shall be through legal counsel
reasonably acceptable to such Indemnified Party and that no settlement may be made by the
Corporation or such Indemnified Party without the prior written consent of the other, such consent
not to be unreasonably withheld. 22
<!-- page 21 -->
(4) In any such claim, such Indemnified Party shall have the right to retain other legal counsel to
act on such Indemnified Party's behalf, provided that the fees and disbursements of such other legal
counsel shall be paid by such Indemnified Party, unless: (a) the employment of such counsel has been
authorized by the Corporation; or (b) the Corporation has not assumed the defence and employed
counsel thereof promptly after receiving notice of such claim; or (c) the named parties to any such
claim include both the Indemnified Party and the Corporation, and the Indemnified Party has been
advised by legal counsel thereto that representation of both the Corporation and the Indemnified
Party by the same legal counsel would be inappropriate due to actual or potential differing
interests between them; or (d) there are one or more defences available to the Indemnified Party
which are different from and in addition to those available to the Corporation, provided that the
Corporation shall not be responsible for the fees or expenses of more than one legal firm in any
single jurisdiction for all of the Indemnified Parties. (5) To the extent that any Indemnified Party
is not a party to this Underwriting Agreement, the Agents shall obtain and hold the right and
benefit of this Section 11 in trust for and on behalf of such Indemnified Party. (6) The Corporation
hereby consents to personal jurisdiction in any court in which any claim that is subject to
indemnification hereunder is brought against the Agents or any Indemnified Party and to the
assignment of the benefit of this Section 11 to any Indemnified Party for the purpose of enforcement
provided that nothing herein shall limit the Corporation's right or ability to contest the
appropriate jurisdiction or forum for the determination of any such claims. (7) The rights of the
Corporation contained in this Section 11 shall not enure to the benefit of any Indemnified Party if
the Agents were provided with a copy of any amendment or supplement to this Agreement which corrects
any untrue statement or omission or alleged omission that is the basis of a claim by a party against
such Indemnified Party and that is required, under the Applicable Securities Laws, to be delivered
to such party by the Agents. (8) The Corporation shall not be liable under this Section 11 for any
settlement of any claim or action effected without its prior written consent. 23
<!-- page 22 -->
(b) Notification of Claims If any matter or thing contemplated by Section 11(a) (any such matter or
thing being referred to as a "Claim") is asserted against any person or company in respect of which
indemnification is or might reasonably be considered to be provided, such person or company (the
"Indemnified Party") will notify the Corporation as soon as possible of the nature of such Claim
(but the omission so to notify the Corporation of any potential Claim shall not relieve the
Corporation from any liability which they may have to any Indemnified Party and any omission so to
notify the Corporation of any actual Claim shall affect the Corporation's liability only to the
extent that the Corporation is materially prejudiced by that failure). The Corporation shall assume
the defence of any suit brought to enforce such Claim, provided, however, that (i) the defence shall
be conducted through legal counsel acceptable to the Indemnified Party, acting reasonably, and (ii)
no settlement of any such Claim or admission of liability may be made by the Corporation without the
prior written consent of the Indemnified Party, acting reasonably, unless such settlement includes
an unconditional release of the Indemnified Party from all liability arising out of such action or
claim and does not include a statement as to or an admission of fault, culpability or failure to
act, by or on behalf of any Indemnified Party. (c) Right of Indemnity in Favour of Others With
respect to any Indemnified Party who is not a party to this Agreement, the Agents shall obtain and
hold the rights and benefits of this Section 11 in trust for and on behalf of such Indemnified
Party. (d) Retaining Counsel In any such Claim, the Indemnified Party shall have the right to retain
one separate counsel to act on his or its behalf, provided that the fees and disbursements of such
counsel shall be paid by the Indemnified Party unless: (i) the Corporation and the Indemnified Party
shall have mutually agreed in writing to the retention of the other counsel; (ii) the named parties
to any such Claim (including any added third or impleaded party) include both the Indemnified Party
and the Corporation and the Indemnified Party shall have been advised in writing by counsel to the
Indemnified Party that the representation of both parties by the same counsel would be inappropriate
due to an actual or potential conflict of interest between the Corporation and the Indemnified
Party; or (iii) the Corporation shall not have retained counsel within seven Business Days following
receipt by the Corporation of notice of any such Claim from the Indemnified Party; provided that the
Corporation shall not be responsible for the fees or expenses of more than one legal firm in any
single jurisdiction for all of the Indemnified Parties. 24
<!-- page 23 -->
12. Contribution (a) Rights of Contribution In order to provide for a just and equitable
contribution in circumstances in which the indemnity provided in Section 11 would otherwise be
available in accordance with its terms but is, for any reason, held to be unavailable to or
unenforceable by the Agents or enforceable otherwise than in accordance with its terms, the
Corporation and the Agents shall contribute to the aggregate of all claims, expenses, costs and
liabilities and all losses (other than loss of profits) of a nature contemplated by Section 11 in
such proportions so that the Agents shall be responsible for the portion represented by the
percentage that the aggregate Agents' Fee hereunder bears to the aggregate offering price of the
Offered Shares being sold by the Corporation and the Corporation shall be responsible for the
balance, whether or not they have been sued together or sued separately, provided, however, that (i)
the Agents shall not in any event be liable to contribute, in the aggregate, any amounts in excess
of the aggregate Agents' Fee actually received by the Agents from the Corporation under this
Agreement; (ii) each Agent shall not in any event be liable to contribute, individually, any amount
in excess of such Agents' portion of the aggregate Agents' Fee actually received from the
Corporation under this Agreement; and (iii) no party who has engaged in any fraud, fraudulent
misrepresentation, wilful misconduct or negligence shall be entitled to claim contribution from any
person who has not engaged in such fraud, fraudulent misrepresentation, wilful misconduct or
negligence. (b) Rights of Contribution in Addition to Other Rights The rights to contribution
provided in this Section 12 shall be in addition to and not in derogation of any other right to
contribution which the Agents may have by statute or otherwise at law. (c) Right of Contribution in
Favour of Others With respect to this Section 12, the Corporation acknowledges and agrees that the
Agents are contracting on their own behalf and as agents for their affiliates, directors, officers,
employees and agents. For purposes of this Section 12, each person, if any, who controls an Agent
within the meaning of Section 15 of the U.S. Securities Act or Section 20 of the U.S. Exchange Act
and each Agents' affiliates and selling agents shall have the same rights to contribution as such
Agent and each person, if any, who controls the Corporation within the meaning of Section 15 of the
U.S. Securities Act or Section 20 of the U.S. Exchange Act shall have the same rights to
contribution as the Corporation. The Agents' respective obligations to contribute pursuant to this
Section 12 are several in proportion to the percentages of Agents' Fee set forth opposite their
respective names in Section 5(a) hereof and not joint. 25
<!-- page 24 -->
(d) Remedy Not Exclusive The remedies provided for in this Section 12 are not exclusive and shall
not limit any rights or remedies which may otherwise be available to any party at law or in equity.
13. Severability If any provision of this Agreement is determined to be void or unenforceable in
whole or in part, it shall be deemed not to affect or impair the validity of any other provision of
this Agreement and such void or unenforceable provision shall be severable from this Agreement. 14.
Expenses (a) Whether or not the transactions contemplated by this Agreement shall be completed, all
expenses of or incidental to the issue, sale and delivery of the Offered Shares and all expenses of
or incidental to all other matters in connection with the offering of the Offered Shares shall be
borne by the Corporation including, without limitation, all fees and disbursements of all legal
counsel to the Corporation (including U.S., foreign and local counsel), all fees and disbursements
of the Corporation's accountants and auditors, all expenses related to road shows and marketing
activities, all printing costs incurred in connection with the offering of the Offered Shares,
including certificates, if any, representing the Offered Shares, all filing fees, all fees and
expenses relating to listing the Offered Shares on any exchanges, all transfer agent fees and
expenses, and all reasonable out-of-pocket expenses of the Agents incurred in connection with the
offering of the Offered Shares, including without limitation the fees of Canadian counsel to the
Agents which shall not exceed $50,000 (not including applicable taxes and disbursements and $10,000
USD plus tax and disbursements for U.S. Counsel), and any advertising, printing, courier,
telecommunications, data search, presentation, travel and other expenses incurred by the Agents
together with all related taxes (including, without limitation, provincial sales taxes and HST). (b)
All expenses payable by the Corporation to the Agent in accordance with this Agreement shall be
payable whether or not the Offering is completed. 15. Survival of Representations and Warranties The
representations, warranties, obligations and agreements of the Corporation contained in this
Agreement and in any certificate delivered pursuant to this Agreement or in connection with the
purchase and sale of the Offered Shares shall survive the payment by the Agents for the Offered
Shares, if any, and the distribution of the Offered Shares, and shall continue in full force and
effect unaffected by the termination of the Agents' obligations and shall not be limited or
prejudiced by any investigation made by or on behalf of the Agents in connection with the
distribution of the Offered Shares. 26
<!-- page 25 -->
16. Entire Agreement This Agreement, including any schedules hereto, represents the entire agreement
of the parties hereto relating to the subject matter hereof and there are no representations,
warranties, covenants or other agreements relating to the subject matter hereof except as stated or
referred to herein. This Agreement shall not be amended or varied in its terms by oral agreement or
by representations or otherwise except by instrument in writing executed by the duly authorized
representatives of the parties hereto or their respective successors or assigns. It is understood
that the terms and conditions of this Agreement supersede any previous verbal or written agreement
between the Agents and the Corporation relating to the subject matter hereof. 17. Amendment No
modification or amendment to this Agreement may be made unless agreed upon by the Corporation and
the Agents in writing. 18. Assignment and Enurement No party may transfer or assign its rights or
obligations under this Agreement without the prior written consent of the other parties and any
transfer or assignment or purported transfer or assignment in contravention of this Section 18 shall
be void and without force or effect. This Agreement shall be binding upon and shall enure to the
benefit of the parties hereto and their respective successors and permitted assigns. 19. Time Time
is of the essence in the performance of the parties' respective obligations under this Agreement.
20. Governing Law This Agreement shall be governed by and construed in accordance with the laws of
the Province of Ontario and the federal laws of Canada applicable in the Province of Ontario. 21.
Notice Unless otherwise expressly provided in this Agreement, any notice or other communication to
be given under this Agreement (a "notice") shall be in writing addressed as follows: If to the
Corporation, addressed and sent to: Tribute Pharmaceuticals Canada Inc. 151 Steeles Avenue East
Milton, Ontario L9T 1Y1 Attention: Rob Harris Facsimile No.: 519.434.4382 e-mail:
rob.harris@tributepharma.com 27
<!-- page 26 -->
with a copy to (which copy shall not constitute notice): Fogler, Rubinoff LLP 77 King Street West
Suite 3000, P.O. Box 95 TD Centre North Tower Toronto, Ontario M5K 1G8 Attention: Eric Roblin
Facsimile No.: 416.941.8852 e-mail: eroblin@foglers.com to the Agents at: Dundee Securities Ltd. 1
Adelaide Street East, Suite 2000 Toronto, Ontario M5C 2V9 Attention: Aaron Unger Facsimile No.:
416.849.1380 e-mail: aunger@dundeecapitalmarkets.com Kes 7 Capital Inc. 2 Bloor Street East, Suite
2102 Toronto, Ontario M4W 1A8 Attention: Marc Lustig e-mail: marcl@kes7capital.com Bloom Burton &
Co. Ltd. 65 Front Street West Suite 300 Toronto, Ontario M5E 1B5 Attention: Jolyon Burton Facsimile
No.: 416.640.7573 e-mail: jburton@bloomburton.com with a copy to (which copy shall not constitute
notice): Dentons Canada LLP 77 King Street West, Suite 400, TD Centre Toronto, Ontario M5K 0A1 28
<!-- page 27 -->
Attention: Andrew Elbaz Facsimile No.: 416.863.4592 email: andrew.elbaz@dentons.com or to such other
address as any of the parties may designate by giving notice to the others in accordance with this
Section 21. Each notice shall be personally delivered to the addressee or sent by fax or e-mail to
the addressee. A notice which is personally delivered or delivered by fax or e-mail shall, if
delivered prior to 5:00 p.m. (Toronto time) on a Business Day, be deemed to be given and received on
that day and, in any other case, be deemed to be given and received on the first Business Day
following the day on which it is delivered. 22. Authority of the Lead Agent The Lead Agent is hereby
authorized by each of the other Agents to act on its behalf, except in respect of any consent to a
settlement pursuant to Section 11(b) which consent shall be given by the Indemnified Party, a notice
of termination pursuant to Section 10 which notice may be given by any of the Agents, or any waiver
pursuant to Section 10(d), which waiver must be signed by all of the Agents. 23. Agents as Trustee
The Corporation acknowledges and agrees that it is the intention of the parties to this Agreement
and the Corporation hereby constitutes the Agents as trustees for each of the Subscribers in respect
of each of the representations and warranties of the Corporation contained in this Agreement and the
Agents shall be entitled, as trustees, in addition to any rights of the Subscribers, to enforce such
representations and warranties on behalf of the Subscribers. 24. Counterparts This Agreement may be
executed by the parties to this Agreement in counterpart and may be executed and delivered by
facsimile and all such counterparts and facsimiles shall together constitute one and the same
agreement. [The remainder of this page has been left blank intentionally.] 29
<!-- page 28 -->
If the foregoing is in accordance with your understanding and is agreed to by you, please signify
your acceptance by executing the enclosed copies of this letter where indicated below and returning
the same to the Lead Agent upon which this letter as so accepted shall constitute an Agreement among
us. Yours very truly, DUNDEE SECURITIES LTD. By: /s/ Aaron Unger Name: Aaron Unger Title: Managing
Director KES 7 CAPITAL INC. By: /s/ Mark Christensen Name: Mark Christensen Title: President and CEO
BLOOM BURTON & CO. LTD. By: /s/ Jolyon Burton Name: Jolyon Burton Title: CEO 30
<!-- page 29 -->
The foregoing offer is accepted and agreed to as of the date first above written. TRIBUTE
PHARMACEUTICALS INC. By: /s/ Rob Harris Name: Rob Harris Title: President and CEO 31

SCHEDULE A COMPLIANCE WITH UNITED STATES SECURITIES LAWS As used in this Schedule and related
exhibits, the following terms shall have the meanings indicated: (a) "Accredited Investors" means
institutions that are "accredited investors" meeting the criteria set forth in Rule 501(a) of
Regulation D; (b) "Directed Selling Efforts" means "directed selling efforts" as that term is
defined in Rule 902(c) of Regulation S, which, without limiting the foregoing, but for greater
clarity in this Schedule, includes, subject to the exclusions from the definition of directed
selling efforts contained in Regulation S, any activity undertaken for the purpose of, or that could
reasonably be expected to have the effect of, conditioning the market in the United States for any
of the Offered Shares and includes the placement of any advertisement in a publication with a
general circulation in the United States that refers to the offering of the Offered Shares; (c)
"Foreign Issuer" means "foreign issuer" as that term is defined in Rule 902(e) of Regulation S; (d)
"General Solicitation" and "General Advertising" means "general solicitation" and "general
advertising", respectively, as used in Rule 502(c) of Regulation D, including advertisements,
articles, notices or other communications published in any newspaper, magazine or similar media or
the internet or broadcast over radio or television or the internet, or any seminar or meeting whose
attendees had been invited by general solicitation or general advertising; (e) "Offshore
Transaction" means an "offshore transaction" as that term is defined in Rule 902(h) of Regulation S;
(f) "Regulation D" means Regulation D adopted by the SEC under the U.S. Securities Act; (g)
"Regulation S" means Regulation S adopted by the SEC under the U.S. Securities Act; (h) "SEC" means
the United States Securities and Exchange Commission; (i) "Substantial U.S. Market Interest" means
"substantial U.S. market interest" as that term is defined in Rule 902(j) of Regulation S; (j) "U.S.
Affiliate" of any Lead Agent means the U.S. registered broker-dealer affiliate of the Lead Agent;
(k) "U.S. Exchange Act" means the United States Securities Exchange Act of 1934, as amended, and the
rules and regulations promulgated thereunder; and (l) "U.S. Subscriber" means a Subscriber located
in the United States, who was offered Offered Shares in the United States, who originated their
purchase at or from the United States or who executes a Subscription Agreement while in the United
States.
<!-- page 30 -->
All other capitalized terms used but not otherwise defined in this Schedule shall have the meanings
assigned to them in the Agency Agreement to which this Schedule is attached. Representations,
Warranties and Covenants of the Corporation The Corporation represents, warrants, covenants and
acknowledges to and with the Agents and the U.S. Affiliates that: 1. The Corporation is a Foreign
Issuer and reasonably believes that there is no Substantial U.S. Market Interest with respect to the
common shares of the Corporation. 2. The Corporation is not, and after giving effect to the Offering
and the application of the proceeds as contemplated hereby, will not be, required to register as an
"investment company" as such term is defined under the United States Investment Corporation Act of
1940, as amended. 3. Except with respect to offers and sales to Accredited Investors identified by
the Agents in reliance upon Regulation D, none of the Corporation, its affiliates, or any person
acting on any of their behalf (other than the Agents, the U.S. Affiliates, any members of the
banking and selling group formed by them, or any person acting on any of their behalf, as to whom
the Corporation makes no representation, warranty, covenant or acknowledgment), has made or will
make: (A) any offer to sell, or any solicitation of an offer to buy, any Offered Shares to a person
in the United States; or (B) any sale of Offered Shares unless, at the time the buy order was or
will have been originated, the Subscriber is (i) outside the United States, or (ii) the Corporation,
its affiliates, and any person acting on any of their behalf reasonably believe that the Subscriber
is outside the United States. 4. None of the Corporation, its affiliates, or any person acting on
any of their behalf (other than the Agents, the U.S. Affiliates, any members of the banking and
selling group formed by them, or any person acting on any of their behalf, as to whom the
Corporation makes no representation, warranty, covenant or acknowledgment), has engaged or will
engage in any Directed Selling Efforts, or has taken or will take any action that would cause the
registration exemption and exclusion afforded by Rule 506(b) of Regulation D or Rule 903 of
Regulation S, respectively, to be unavailable for offers and sales of the Offered Shares pursuant to
this Agreement. 5. None of the Corporation, any of its affiliates or any person acting on any of
their behalf (other than the Agents, the U.S. Affiliates, or any members of the banking and selling
group formed by them, or any person acting on any of their behalf, as to whom the Corporation makes
no representation, warranty, covenant or acknowledgment) has offered or will offer to sell, or has
solicited or will solicit offers to buy, any of the Offered Shares in the United States by means of
any form of General Solicitation or General Advertising or in any manner involving a public offering
within the meaning of Section 4(a)(2) of the U.S. Securities Act. 2
<!-- page 31 -->
6. For the period commencing six months prior to the date hereof and ending six months following the
completion of the Offering, none of the Corporation, its affiliates, or any person acting on any of
their behalf (other than the Agents, the U.S. Affiliates, or any members of the banking and selling
group formed by them, or any person acting on any of their behalf, as to whom the Corporation makes
no representation, warranty, covenant or acknowledgment) has sold, offered for sale or solicited any
offer to buy or will sell, offer to sell or solicit any offer to buy any of the Corporation's
securities in a manner that would be integrated with the offer and sale of the Offered Shares and
would cause the exemption from registration afforded by Rule 506(b) of Regulation D to become
unavailable with respect to the offer and sale of the Offered Shares. 7. Neither the Corporation nor
any of its predecessors or affiliates has been subject to any order, judgment, or decree of any
court of competent jurisdiction temporarily, preliminarily or permanently enjoining such person for
failure to comply with Rule 503 of Regulation D. 8. None of the Corporation, its affiliates or any
person on any of their behalf (other than the Agents, the U.S. Affiliates, or any members of the
banking and selling group formed by them, or any person acting on any of their behalf, as to whom
the Corporation makes no representation, warranty, covenant or acknowledgment) has taken or will
take any action that would constitute a violation of Regulation M under the U.S. Exchange Act in
connection with the Offering. 9. The Corporation will cause a Form D to be filed with the SEC within
15 days of the first sale of the Offered Shares to a U.S. Subscriber, and will, within the
prescribed time periods, prepare and file any other forms or notices required under any state
securities laws in connection with the offer and sale of Offered Shares. 10. With respect to Offered
Shares to be offered and sold in reliance on Rule 506(b) of Regulation D, none of the Corporation,
any of its predecessors, any affiliated issuer, any director, executive officer, other officer of
the Corporation participating in the Offering, any beneficial owner of 20% or more of the
Corporation's outstanding voting equity securities, calculated on the basis of voting power, or any
promoter (as that term is defined in Rule 405 under the U.S. Securities Act) connected with the
Corporation in any capacity at the time of sale (each, an "Issuer Covered Person" and, together,
"Issuer Covered Persons") is subject to any of the "Bad Actor" disqualifications described in Rule
506(d)(1)(i) to (viii) of Regulation D (a "Disqualification Event"), except for a Disqualification
Event covered by Rule 506(d)(2) or (d)(3) of Regulation D. The Corporation has exercised reasonable
care to determine whether any Issuer Covered Person is subject to a Disqualification Event. The
Corporation has complied, to the extent applicable, with its disclosure obligations under Rule
506(e) of Regulation D, and has furnished to the Agents a copy of any disclosures provided
thereunder. 11. The Corporation is not aware of any person (other than any Dealer Covered Person)
that has been or will be paid (directly or indirectly) remuneration for solicitation of Subscribers
in connection with the sale of any Offered Shares pursuant to Rule 506(b) of Regulation D. 3
<!-- page 32 -->
12. The Corporation will notify the Agents, in writing, prior to the Closing Date of (i) any
Disqualification Event relating to any Issuer Covered Person and (ii) any event that would, with the
passage of time, become a Disqualification Event relating to any Issuer Covered Person.
Representations, Warranties and Covenants of the Agents Each of the Agents represents, warrants,
covenants and acknowledges to and with the Corporation that: 1. The Offered Shares have not been and
will not be registered under the U.S. Securities Act or any state securities laws and may be offered
and sold only in transactions exempt from or not subject to the registration requirements of the
U.S. Securities Act and applicable state securities laws. It has not offered and sold, and will not
offer and sell, any Offered Shares except: (a), in case of all Agents, offers and sales in Offshore
Transactions in accordance with Rule 903 of Regulation S; or (b), in the case of the Lead Agent,
offers in the United States to Accredited Investors as permitted by this Agreement. Accordingly,
none of the Agent, its affiliates or any persons acting on any of their behalf, has made or will
make (except as permitted in this Agreement): (i) any offer to sell, or any solicitation of an offer
to buy, any Offered Shares to any person in the United States; (ii) any sale of Offered Shares to
any Subscriber unless, at the time the buy order was or will have been originated, the Subscriber
was outside the United States, or such Agent, affiliate or person acting on any of their behalf
reasonably believed that such Subscriber was outside the United States. 2. It has not entered and
will not enter into any contractual arrangement with respect to the offer and sale of the Offered
Shares, except with its U.S. Affiliate, any selling group members or with the prior written consent
of the Corporation. It shall require its U.S. Affiliate and each selling group member to agree, for
the benefit of the Corporation, to comply with, and shall use its reasonable best efforts to ensure
that its U.S. Affiliate and each selling group member complies with, the provisions of this Schedule
applicable to the Agent as if such provisions applied to such U.S. Affiliate and such selling group
members. 3. All offers of Offered Shares in the United States shall be made only by the Lead Agent
through its U.S. Affiliate, which on the dates of such offers and subsequent sales by the
Corporation was and will be duly registered as a broker-dealer under the U.S. Exchange Act and under
all applicable state securities laws (unless exempt from the registration requirements thereof) and
a member of, and in good standing with, the Financial Industry Regulatory Authority, Inc. The U.S.
Affiliate will make all offers and arrange for all sales by the Corporation of Offered Shares in
compliance with all applicable United States federal and state broker-dealer requirements and this
Schedule. 4
<!-- page 33 -->
4. None of the Agent, its affiliates, or any person acting on behalf of any of them, have engaged in
any Directed Selling Efforts or have solicited or will solicit offers to buy, or have offered to
sell or will offer to sell, any of the Offered Shares in the United States by any form of General
Solicitation or General Advertising or in any manner involving a public offering within the meaning
of Section 4(a)(2) of the U.S. Securities Act. 5. Any offer to sell or solicitation of an offer to
buy Offered Shares that has been made or will be made in the United States by the Lead Agent through
the U.S. Affiliate was or will be made only to Accredited Investors in transaction that in
compliance with Rule 506(b) of Regulation D and to be exempt from registration under and in
compliance with applicable state securities laws. 6. Immediately prior to soliciting any U.S.
Subscriber, the Lead Agent, its U.S. Affiliate, their respective affiliates, and any person acting
on behalf of any of them, had reasonable grounds to believe and did believe that each such U.S.
Subscriber was an Accredited Investor, based upon a pre-existing relationship, and at the time of
completion of each sale by the Corporation to such U.S. Subscriber, the Lead Agent, its U.S.
Affiliate, their respective affiliates, and any person acting on behalf of any of them will have
reasonable grounds to believe and will believe, that each U.S. Subscriber designated by the Lead
Agent or its U.S. Affiliate to purchase Offered Shares from the Corporation is an Accredited
Investor. 7. Prior to arranging for any sale by the Corporation of Offered Shares to U.S.
Subscribers, the Lead Agent shall cause each such U.S. Subscriber to duly complete and execute a
Subscription Agreement to be used for U.S. Subscribers. 8. At least one business day prior to the
Closing Date, the transfer agent for the Corporation will be provided with a list of all U.S.
Subscribers. 9. At the Closing Time, the Lead Agent, together with its U.S. Affiliate, will provide
a certificate, substantially in the form of Exhibit I to this Schedule A relating to the manner of
the offer of the Offered Shares in the United States or will be deemed to have represented and
warranted to the Corporation that neither it nor its U.S. Affiliate has offered or sold Offered
Shares in the United States. 10. Prior to arranging any sale by the Corporation of Offered Shares to
a U.S. Subscriber, each such person will be informed that the Offered Shares have not been and will
not be registered under the U.S. Securities Act or any state securities laws and are being offered
and sold to such U.S. Subscriber in reliance on an exemption from the registration requirements of
the U.S. Securities Act provided by Rule 506(b) of Regulation D and similar exemptions under
applicable state securities laws. 11. None of the Agent, the U.S. Affiliate, or any person acting on
its or their behalf has taken or will take any action in violation of Regulation M under the U.S.
Exchange Act in connection with the Offering. 12. Other than Lead Agent and the U.S. Affiliate, it
has not made and will not make any offers or sales of Offered Shares in the United States in
connection with the Offering. 5
<!-- page 34 -->
13. The Lead Agent represents and warrants that with respect to Offered Shares to be sold in
reliance on Rule 506(b) of Regulation D, none of it, or the U.S. Affiliate, or any of its or the
U.S. Affiliate's directors, executive officers, general partners, managing members or other officers
participating in the Offering, or any other person associated with the Lead Agent who will receive,
directly or indirectly, remuneration for solicitation of Subscribers of Offered Shares pursuant to
Rule 506(b) of Regulation D (each, a "Dealer Covered Person" and, together, "Dealer Covered
Persons"), is subject to any Disqualification Event (as defined below) except for a Disqualification
Event (i) covered by Rule 506(d)(2)(i) of Regulation D and (ii) a description of which has been
furnished in writing to the Corporation prior to the date hereof or, in the case of a
Disqualification Event occurring after the date hereof, prior to the Closing Date. 14. The Lead
Agent represents that it is not aware of any person (other than any Dealer Covered Person) that has
been or will be paid (directly or indirectly) remuneration for solicitation of Subscribers in
connection with the sale of any Offered Shares pursuant to Rule 506(b) of Regulation D. It will
notify the Corporation, prior to the Closing Date of any agreement entered into between it and any
such person in connection with such sale. 15. The Lead Agent will notify the Corporation, in
writing, prior to the Closing Date, of (i) any Disqualification Event relating to any Dealer Covered
Person not previously disclosed to the Corporation in accordance herewith, and (ii) any event that
would, with the passage of time, become a Disqualification Event relating to any Dealer Covered
Person. 6
