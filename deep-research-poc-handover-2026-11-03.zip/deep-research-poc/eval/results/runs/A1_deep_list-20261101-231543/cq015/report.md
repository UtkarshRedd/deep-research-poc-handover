# What cap on liability does the Amended and Restated Strategic Licensing, Distribution a...

*Question:* What cap on liability does the Amended and Restated Strategic Licensing, Distribution and Marketing Agreement between PACIRA PHARMACEUTICALS, INC. and EKR THERAPEUTICS, INC. (dated 2009-10-15) provide?

> **Partial report.** Research or writing ended before completion; see the gaps and the appendix.

## Identify the liability cap provision

Section 10.9 of the agreement specifies EKR's liability limitation. [07f7a8f9538a471a p.49] The provision states: "10.9 EKR Liability Limitation. [uncited] Any and all liability of EKR to PPI howsoever arising in respect of this Agreement, the Transition Services and Inventory Agreement or the Supply Agreement and their performance in contract tort or otherwise shall be limited (except for death or personal injury caused by the negligence of EKR or its employees while acting in the course of their employment, and except in relation to any specified payment, lump sum, milestone or royalty payment unpaid) to [**] US Dollars ($[**]); provided however that such limitation shall not apply to the extent that PPI or any PPI Indemnified Party is required to pay in excess of such amount to a third party in respect of a final judgment or order obtained by the third party." [07f7a8f9538a471a p.49]

## Not established by the evidence

[GAP] No evidence was found for: Establish the exact monetary cap, parties covered, types of claims or damages covered or excluded, and any exceptions

## Verification appendix

Claims: 4 · supported: 2 · partially: 0 · dropped: 0 · gaps: 2 · tier-1 support rate: 1.00

Notes: 1 empty section(s) collapsed into gaps: State the cap amount and scope

| claim | section | tier 1 | score | sources | note |
|---|---|---|---|---|---|
| s1.1 | s1 | keep | 1.00 | e1→[07f7a8f9538a471a p.49] |  |
| s1.2 | s1 | gap |  |  | no evidence cited |
| s1.3 | s1 | keep | 1.00 | e1→[07f7a8f9538a471a p.49] |  |
| gaps.1 | gaps | gap |  |  |  |

### Evidence

- e1 [07f7a8f9538a471a p.49 L1240-1247] keep (1.0): "10.9 EKR Liability Limitation. Any and all liability of EKR to PPI howsoever arising in respect of this Agreement, the Transition Services and Inventory Agreement or the Supply Agreement and their performance in contract tort or otherwise s…"
