<!-- page 1 -->
# COOPERATION AGREEMENT
| Field | Value |
|---|---|
| Document Type | Collaboration Agreement |
| Agreement Date | 2017-06-27 |
| Parties | Meet Group, Inc. ("Company"); HARVEST SMALL CAP PARTNERS MASTER, LTD ("Investor", collectively, the “Investors” or, with their respective affiliates and associates, the “Investor Group”); HARVEST SMALL CAP PARTNERS, L.P. (“Investor” and collectively, the “Investors” or, with their respective affiliates and associates, the “Investor Group”); HARVEST CAPITAL STRATEGIES LLC ("Investor” and collectively, the “Investors” or, with their respective affiliates and associates, the “Investor Group”) |
| Source | CUAD v1 / MEETGROUP,INC_06_29_2017-EX-10.1-COOPERATION AGREEMENT |

CERTAIN PORTIONS OF THIS DOCUMENT HAVE BEEN OMITTED PURSUANT TO A CONFIDENTIAL TREATMENT REQUEST.
SUCH OMITTED PORTIONS, WHICH ARE MARKED WITH BRACKETS [ ] AND AN ASTERISK*, HAVE BEEN SEPARATELY
FILED WITH THE SECURITIES AND EXCHANGE COMMISSION. Exhibit 10.1 EXECUTION COPY COOPERATION AGREEMENT
This AGREEMENT, dated as of June 27, 2017 (this "Agreement"), is made and entered into by The Meet
Group, Inc., a Delaware corporation (the "Company"), and each of the persons set forth on the
signature page hereto (each, an "Investor" and collectively, the "Investors" or, with their
respective affiliates and associates, the "Investor Group"), which presently are or may be deemed to
be members of a "group" with respect to the common stock of the Company, $0.001 par value per share
(the "Common Stock"), pursuant to Rule 13d-5 promulgated by the U.S. Securities and Exchange
Commission (the "SEC") under the Securities Exchange Act of 1934, as amended (the "Exchange Act");
WHEREAS, the Investor Group is deemed to beneficially own shares of the Common Stock totaling, in
the aggregate, 4,425,000 shares of the Common Stock outstanding as of the date hereof; and WHEREAS,
the Company has agreed, at the request of the Investor Group, to cause Jim Parmelee ("New Director
A") and a person to be selected from the Director Candidate Pool (as defined herein) ("New Director
B") (collectively, the "New Directors") to be appointed to the Company's Board of Directors (the
"Board"), and to come to an agreement with respect to certain other matters as provided in this
Agreement. NOW, THEREFORE, in consideration of the foregoing premises and the mutual covenants and
agreements contained herein, and for other good and valuable consideration, the receipt and
sufficiency of which are hereby acknowledged, the parties hereto, intending to be legally bound
hereby, agree as follows: 1. Board Composition Matters. (a) Appointment of New Director A. The
Company agrees that it shall take all action as is necessary (including, without limitation, calling
a special meeting of the Board to approve all actions contemplated hereby), effective immediately
following the execution of this Agreement, to (i) cause the Board to increase the size of its
membership from six (6) to seven (7) members; (ii) accept the resignation of one existing member of
the Board to become effective immediately prior to the appointment of New Director A; and (iii)
appoint New Director A to the Board with a term on the Board expiring at the Company's 2018 Annual
Meeting of Stockholders (the "2018 Annual Meeting") and until his successor is duly elected and
qualified. The Company further agrees that without the unanimous approval of the Board, during the
period from the execution of this Agreement until the expiration of the Standstill Period (as
defined below), the size of the Board shall not be increased beyond seven (7) members.
<!-- page 2 -->
(i) Identification and Appointment of New Director B. No later than ninety (90) calendar days from
the date of execution of this Agreement (the "New Director B Appointment Deadline"), the Company
shall take the necessary steps to cause the Board to appoint one of the candidates set forth on
Exhibit A (as the same may be supplemented or otherwise amended from time to time by the mutual
constent of the Company and the Investor Group, the "Director Candidate Pool") as New Director B
with a term on the Board expiring at the 2018 Annual Meeting and until his or her successor is duly
elected and qualified. The Company agrees that, if New Director B is not appointed to the Board
prior to the New Director B Appointment Deadline and none of the candidates included in the Director
Candidate Pool are willing to serve on the Board by the New Director B Appointment Deadline, (1) the
Company and Investor Group will discuss in good faith the identification and selection of a mutually
agreed upon substitute person to be added to the Director Candidate Pool following the same process
that they would follow pursuant to Section 1(f) hereof if either of the New Directors, following
their appointment to the Board, is unable to serve as a director for any reason, resigns as a
director, or is removed as a director prior to the end of the term of office; and (2) the New
Director B Appointment Deadline shall no longer apply and, in lieu thereof, shall be replaced by the
time periods set forth in Section 1(f) hereof. (b) Board's Review of Qualifications and
Determination of Independence. Prior to the execution of this Agreement (i) the Nominating and
Governance Committee of the Board (the "Nominating Committee") has reviewed the qualifications of
New Director A and each of the individuals included within the Director Candidate Pool to serve as
members of the Board and has determined that they are so qualified, and (ii) the Board has
determined that each of the New Directors and each of the individuals included within the Director
Candidate Pool are "independent" as defined by the listing standards of NASDAQ. (c) Committees. The
Company agrees that, concurrent with the appointment of the New Directors to the Board, the Board
shall take such action as is necessary such that each of the New Directors is appointed to at least
one (1) of the three (3) standing committees of the Board that the Company is required to maintain
in accordance with the NASDAQ listing standards; provided that, with respect to each such committee
appointment, the New Director is and continues to remain eligible to serve as a member of such
committee pursuant to applicable law and the rules of NASDAQ that are applicable to the composition
of such committee. (d) Board Policies and Procedures. The Investor Group acknowledges that each of
the New Directors shall be required to comply with all policies, processes, procedures, codes,
rules, standards, and guidelines applicable to members of the Board, as in effect from time to time,
including, but not limited to, the Company's Code of Conduct, and policies on confidentiality,
ethics, hedging and pledging of Company securities, public disclosures, stock trading, and stock
ownership, and that each of the New Directors shall be required to strictly preserve the
confidentiality of Company business and information, including the discussion of any matters
considered in meetings of the Board whether or not the matters relate to material non-public
information, unless previously publicly disclosed by the Company. Further, the Investor Group
acknowledges that the New Directors will be requested to provide the Company with such information
as is reasonably requested by the Company concerning the New Directors as is required to be
disclosed under applicable law or stock exchange regulations, including the completion of the
Company's standard director and officer questionnaire, in each case as promptly as necessary to
enable the timely filing of the Company's proxy statement and other periodic reports with the SEC. 2
<!-- page 3 -->
(e) Rights and Benefits of the New Directors. The Company agrees that each of the New Directors
shall receive (i) the same benefits of director and officer insurance, and any indemnity and
exculpation arrangements available generally to the directors on the Board, (ii) the same
compensation for his service as a director as the compensation received by other non-management
directors on the Board, and (iii) such other benefits on the same basis as all other non-management
directors on the Board. (f) Replacements. The Company agrees that, during the Standstill Period (as
defined below), if any of the New Directors is unable to serve as a director for any reason, resigns
as a director, or is removed as a director prior to the end of the term of office, and at such time
the Investor Group beneficially owns in the aggregate at least three percent (3.0%) of the Company's
then outstanding Common Stock (subject to adjustment for share issuances, stock splits,
reclassifications, combinations and similar actions by the Company that increase the number of
outstanding shares of Common Stock), then the Company and the Investor Group shall work together in
good faith to identify and select a replacement director candidate to be appointed to the Board
which shall only be appointed to the Board after having been mutually agreed upon by both the
Company and the Investor Group. Any such mutually agreed upon replacement director candidate shall
qualify as "independent" pursuant to NASDAQ's listing standards and have the relevant financial and
business experience to fill the resulting vacancy. Each of the Investor Group and the Company shall
determine, and inform the other party of its determination, whether any proposed replacement
director candidate is acceptable and meets the foregoing criteria, within ten (10) business days
after such party has conducted interview(s) of such proposed replacement director candidate. Each of
the Company and the Investor Group shall use their respective reasonable best efforts to cause any
interview(s) contemplated by this Section 1(f) to be conducted as promptly as practicable, but in
any case, assuming reasonable availability of the proposed replacement director candidate, within
ten (10) business days after the receipt of such director candidate's credentials, including, but
not limited to, a completed copy of the Company's standard director and officer questionnaire. Upon
acceptance of a replacement director candidate by both the Company and the Investor Group, the Board
shall take such actions as to appoint such replacement director candidate to the Board no later than
ten (10) business days after both parties have confirmed in writing that they have mutually agreed
upon such candidate. Following the appointment of any director to replace a New Director in
accordance with this Section 1(f), any reference to New Directors herein shall be deemed to include
such replacement director. 3
<!-- page 4 -->
2. Actions by the Investor Group. (a) Voting Agreement. (i) Stockholders Meetings. At each annual
and special meeting of stockholders held prior to the expiration of the Standstill Period (as
defined below), each of the Investors agrees to (A) appear at such stockholders' meeting or
otherwise cause all shares of Common Stock beneficially owned by each Investor and their respective
Affiliates and Associates (as defined below) to be counted as present thereat for purposes of
establishing a quorum; (B) vote, or cause to be voted, all shares of Common Stock beneficially owned
by each Investor and their respective Affiliates and Associates on the Company's proxy card or
voting instruction form in favor of each of the nominees for election as directors nominated by the
Board and recommended by the Board (and not in favor of any other nominees to serve on the Board);
and, except in connection with any Opposition Matter (as defined below) or Other Voting
Recommendation (as defined below), each of the proposals listed on the Company's proxy card or
voting instruction form as identified in the Company's definitive proxy statement or supplement
thereto in accordance with the Board's recommendations, including in favor of all matters
recommended by the Board for stockholder approval and against all matters which the Board recommends
against stockholder approval; provided, however, in the event that Institutional Shareholder
Services Inc. ("ISS") issues a recommendation with respect to any matter (other than with respect to
the election of nominees as directors to the Board or the removal of directors from the Board) that
is different from the recommendation of the Board, each of the Investors shall have the right to
vote on the Company's proxy card or voting instruction form in accordance with the ISS
recommendation (the "Other Voting Recommendation"); and (C) not execute any proxy card or voting
instruction form in respect of such stockholders' meeting other than the proxy card and related
voting instruction form being solicited by or on behalf of the Company or the Board. No later than
five (5) business days prior to each annual or special meeting of stockholders held prior to the
expiration of the Standstill Period, each Investor shall, and shall cause each of its Associates and
Affiliates to, vote any shares of Common Stock beneficially owned by such Investors in accordance
with this Section 2. No Investor nor any of its Affiliates or Associates nor any person under its
direction or control shall take any position, make any statement or take any action inconsistent
with this Section 2(a)(i). For purposes of this Agreement, "Opposition Matter" shall mean any of the
following transactions but only to the extent submitted by the Board to the Company's stockholders
for approval: (A) the sale or transfer of all or substantially all of the Company's assets in one or
a series of transactions; (B) the sale or transfer of a majority of the outstanding shares of the
Company's Common Stock (through a merger, stock purchase, or otherwise); (C) any merger,
consolidation, acquisition of control or other business combination that results in a Change of
Control (as defined below) of the Company; (D) any tender or exchange offer; (E) any dissolution,
liquidation, or reorganization; (F) any changes in the Company's capital structure (but excluding
any proposal regarding the adoption or amendment of equity plans, all of which shall not be deemed
an Opposition Matter for purposes of this Agreement); or (G) any other transactions that would
result in a Change of Control of the Company. (ii) Actions By Written Consent. In connection with
any action by written consent that is sought to be taken by any party, other than the Company or the
Board, prior to the expiration of the Standstill Period (as defined below), each of the Investors
agrees not to vote and to take all necessary action, including, without limitation, the execution
and completion of any consent revocation card solicited by the Company or the Board, in accordance
with the recommendation of the Board, to cause not to be voted, any of their shares of Common Stock
beneficially owned by each Investor and/or their respective Affiliates and Associates on any consent
card related to or affecting the removal, replacement or election of Board members and solicited by
any party, other than the Company or the Board. No Investor nor any of its Affiliates or Associates
nor any person under its direction or control shall take any position, make any statement or take
any action inconsistent with this Section 2(a)(ii). (iii) Special Meeting Demands. In connection
with any demand by a stockholder of the Company that the Company call a special meeting of
stockholders, made prior to the expiration of the Standstill Period (as defined below), each of the
Investors agrees not to vote and shall take all necessary action, including, but not limited to, the
execution and completion of any consent revocation card solicited by the Company or the Board in
accordance with the recommendation of the Board, to cause not to be voted, any of their shares of
Common Stock beneficially owned by each Investor and/or their respective Affiliates and Associates
for any special meeting demand proposed or sought to be made by any party. No Investor nor any of
its Affiliates or Associates nor any person under its direction or control shall take any position,
make any statement or take any action inconsistent with this Section 2(a)(iii). 4
<!-- page 5 -->
3. Standstill. (a) Each Investor agrees that, from the date of this Agreement until the expiration
of the Standstill Period (as defined below), without the prior written consent of a majority of the
Board specifically expressed in a written resolution, neither it nor any of its Related Persons (as
defined herein) will, and it will cause each of its Related Persons not to, directly or indirectly,
alone or with others, in any manner: (i) propose or publicly announce or otherwise publicly disclose
an intent to propose or enter into or agree to enter into, singly or with any other person, directly
or indirectly, (x) any form of business combination or acquisition or other transaction relating to
a material amount of assets or securities of the Company or any of its subsidiaries, (y) any form of
restructuring, recapitalization or similar transaction with respect to the Company or any of its
subsidiaries or (z) any form of tender or exchange offer for the Common Stock, whether or not such
transaction involves a change of control of the Company; (ii) engage in any solicitation of proxies
or written consents to vote any voting securities of the Company, or conduct any non-binding
referendum with respect to any voting securities of the Company, or assist or participate in any
other way, directly or indirectly, in any solicitation of proxies or written consents with respect
to any voting securities of the Company, or otherwise become a "participant" in a "solicitation," as
such terms are defined in Instruction 3 of Item 4 of Schedule 14A and Rule 14a-1 of Regulation 14A,
respectively, under the Exchange Act, to vote any securities of the Company in opposition to any
recommendation or proposal of the Board; (iii) acquire, offer or propose to acquire, or agree to
acquire, directly or indirectly, whether by purchase, tender or exchange offer, through the
acquisition of control of another person, by joining a partnership, limited partnership, syndicate
or other group (including any group of persons that would be treated as a single "person" under
Section 13(d) of the Exchange Act), through swap or hedging transactions or otherwise, any
additional securities (including common and preferred equity interests and debt that is convertible
into any equity interests) of the Company or any rights decoupled from the underlying securities of
the Company, that would result, or could result, in the Investor Group owning, in the aggregate
(amongst all of the Investors and any Affiliate or Associate thereof), in excess of 10% of the
shares of Common Stock outstanding; (iv) seek to advise, encourage or influence any person with
respect to the voting of (or execution of a written consent in respect of) or disposition of any
securities of the Company, other than in a manner in accordance with Section 2; (v) sell, offer or
agree to sell directly or indirectly, through swap or hedging transactions or otherwise, any
securities (including common and preferred equity interests and debt that is convertible into any
equity interests) of the Company or any rights decoupled from the underlying securities held by the
Investors to any person or entity that would knowingly result in any third party, together with its
Affiliates and Associates, owning, controlling or otherwise having any, beneficial, economic or
other ownership interest representing in the aggregate 5% or more of the shares of Common Stock
outstanding at such time; 5
<!-- page 6 -->
(vi) sell, offer or agree to sell directly or indirectly, through swap or hedging transactions or
otherwise, any securities (including common and preferred equity interests and debt that is
convertible into any equity interests) of the Company or any rights decoupled from the underlying
securities held by the Investors to any Affiliate or Associate of the Investors not a party to this
Agreement; (vii) except as otherwise set forth in this Agreement, take any action in support of or
make any proposal or request that constitutes: (A) advising, controlling, changing or influencing
the Board or management of the Company, including any plans or proposals to change the number or
term of directors or to fill any vacancies on the Board, (B) any material change in the
capitalization, stock repurchase programs and practices or dividend policy of the Company, (C) any
other material change in the Company's management, governance, policies, strategic direction,
business or corporate structure, (D) seeking to have the Company waive or make amendments or
modifications to the Company's Amended and Restated Certificate of Incorporation or Bylaws, or other
actions that may impede or facilitate the acquisition of control of the Company by any person, (E)
causing a class of securities of the Company to be delisted from, or to cease to be authorized to be
quoted on, any securities exchange, or (F) causing a class of securities of the Company to become
eligible for termination of registration pursuant to Section 12(g)(4) of the Exchange Act; (viii)
call or seek to call, or request the call of, alone or in concert with others, any meeting of
stockholders, whether or not such a meeting is permitted by the Company's Amended and Restated
Certificate of Incorporation or Bylaws, including, but not limited to, a "town hall meeting;" (ix)
seek, alone or in concert with others, representation on the Board, except as expressly permitted by
this Agreement; (x) initiate, encourage or participate in any "vote no," "withhold" or similar
campaign; (xi) deposit any Common Stock in any voting trust or subject any Common Stock to any
arrangement or agreement with respect to the voting of any Common Stock (other than any such voting
trust, arrangement or agreement solely among the members of the Investor Group that is otherwise in
accordance with this Agreement); (xii) seek, or encourage any person, to submit nominations in
furtherance of a "contested solicitation" for the election or removal of directors with respect to
the Company or seek, encourage or take any other action with respect to the election or removal of
any directors of the Company or with respect to the submission of any stockholder proposals
(including any submission of stockholder proposals pursuant to Rule 14a-8 under the Exchange Act); 6
<!-- page 7 -->
(xiii) form, join or in any other way participate in any "group" (within the meaning of Section
13(d)(3) of the Exchange Act) with respect to the Common Stock (other than the Investor Group);
(xiv) demand a copy of the Company's list of stockholders or its other books and records, whether
pursuant to Section 220 of the Delaware General Corporation Law (the "DGCL") or pursuant to any
other statutory right; (xv) commence, encourage, or support any derivative action in the name of the
Company, or any class action against the Company or any of its officers or directors in order to,
directly or indirectly, effect any of the actions expressly prohibited by this Agreement or cause
the Company to amend or waive any of the provisions of this Agreement; provided, however, that for
the avoidance of doubt, the foregoing shall not prevent any Investor from (A) bringing litigation to
enforce the provisions of this Agreement, (B) making counterclaims with respect to any proceeding
initiated by, or on behalf of, the Company against an Investor, or (C) exercising statutory
dissenters, appraisal or similar rights under the DGCL; provided, further, that the foregoing shall
also not prevent the Investors from responding to or complying with a validly issued legal process
in connection with litigation that it did not initiate, invite, facilitate or encourage, except as
otherwise permitted in this Section (3)(a) (xv); (xvi) disclose publicly or privately, in a manner
that could reasonably be expected to become public any intent, purpose, plan or proposal with
respect to the Board, the Company, its management, policies or affairs, any of its securities or
assets or this Agreement that is inconsistent with the provisions of this Agreement; provided,
however, that nothing herein shall prohibit the Investor Group from engaging in private discussions
with the Company concerning the Investor Group's views or suggestions concerning the Company; (xvii)
enter into any negotiations, agreements or understandings with any person or entity with respect to
any of the foregoing, or advise, assist, knowingly encourage or seek to persuade any person or
entity to take any action or make any statement with respect to any of the foregoing, or otherwise
take or cause any action or make any statement inconsistent with any of the foregoing; (xviii) make
any request or submit any proposal to amend the terms of this Agreement other than through
non-public communications with the Company that would not be reasonably determined to trigger public
disclosure obligations for any party; (xix) take any action challenging the validity or
enforceability of any of the provisions of this Section 3 or publicly disclose, or cause or
facilitate the public disclosure (including, without limitation, the filing of any document with the
SEC or any other governmental agency or any disclosure to any journalist, member of the media or
securities analyst) of, any intent, purpose, plan or proposal to either (A) obtain any waiver or
consent under, or any amendment of, any provision of this Agreement, or (B) take any action
challenging the validity or enforceability of any provisions of this Section 3; or (xx) otherwise
take, or solicit, cause or encourage others to take, any action inconsistent with the foregoing. 7
<!-- page 8 -->
(b) Notwithstanding the foregoing, the provisions of this Section 3 shall not limit in any respect
the actions of any director of the Company (including, but not limited to, the New Directors) in
their capacity as such, recognizing that such actions are subject to such director's fiduciary
duties to the Company and its stockholders (it being understood and agreed that neither the
Investors nor any of their Affiliates or Associates shall seek to do indirectly through the New
Directors anything that would be prohibited if done by any of the Investors or their Affiliates and
Associates directly). For the avoidance of doubt, no provision in this Section 3 or elsewhere in
this Agreement shall prohibit privately-negotiated transactions in the Common Stock solely between
or among the Investors. (c) As of the date of this Agreement, none of the Investors are engaged in
any discussions or negotiations with any person, and do not have any agreements, arrangements, or
understandings, written or oral, formal or informal, and whether or not legally enforceable with any
person concerning the acquisition of economic ownership of any securities of the Company, and have
no actual and non-public knowledge that any other stockholders of the Company have any present or
future intention of taking any actions that if taken by the Investors would violate any of the terms
of this Agreement. The Investors agree to refrain from taking any actions during the Standstill
Period to intentionally encourage other stockholders of the Company, or any other persons to engage
in any of the actions referred to in the previous sentence. (d) As used in this Agreement, the terms
"Affiliate" and "Associate" shall have the respective meanings set forth in Rule 12b-2 promulgated
by the SEC under the Exchange Act; the terms "beneficial owner" and "beneficial ownership" shall
have the same meanings as set forth in Rule 13d-3 promulgated by the SEC under the Exchange Act; the
terms "economic owner" and "economically own" shall have the same meanings as "beneficial owner" and
"beneficially own," except that a person will also be deemed to economically own and to be the
economic owner of (i) all shares of Common Stock which such person has the right to acquire pursuant
to the exercise of any rights in connection with any securities or any agreement, regardless of when
such rights may be exercised and whether they are conditional, and (ii) all shares of Common Stock
in which such person has any economic interest, including, without limitation, pursuant to a cash
settled call option or other derivative security, contract or instrument in any way related to the
price of shares of Common Stock; the terms "person" or "persons" shall mean any individual,
corporation (including not-for-profit), general or limited partnership, limited liability company,
joint venture, estate, trust, association, organization or other entity of any kind or nature; and
the term "Related Person" shall mean, as to any person, any Affiliates or Associates of such person.
(e) Notwithstanding anything contained in this Agreement to the contrary: (i) The provisions of
Sections 1, 2, and 3 of this Agreement shall automatically terminate upon the occurrence of a Change
of Control transaction (as defined below) involving the Company if the acquiring or counter-party to
the Change of Control transaction has conditioned the closing of the transaction on the termination
of such sections; provided, however, that the Company shall not directly or indirectly, propose,
seek, encourage or otherwise influence such acquiring or counter-party to the Change of Control
transaction to condition the closing of such transaction on the termination of Sections 1, 2, and 3
of this Agreement; and 8
<!-- page 9 -->
(ii) For purposes of this Agreement, a "Change of Control" transaction shall be deemed to have taken
place if (1) any person is or becomes a beneficial owner, directly or indirectly, of securities of
the Company representing more than 50% of the equity interests and voting power of the Company's
then outstanding equity securities or (2) the Company enters into a stock-for-stock transaction
whereby immediately after the consummation of the transaction the Company's stockholders retain less
than 50% of the equity interests and voting power of the surviving entity's then outstanding equity
securities. (f) For purposes of this Agreement, "Standstill Period" shall mean the period commencing
on the date of this Agreement and ending at 11:59 p.m. Eastern Time on the date of the certification
of the vote of stockholders at the 2018 Annual Meeting. 4. Expenses. Each of the Company and the
Investors shall be responsible for its own fees and expenses incurred in connection with the
negotiation, execution, and effectuation of this Agreement and the transactions contemplated hereby,
including, but not limited to attorneys' fees incurred in connection with the negotiation and
execution of this Agreement and all other activities related to the foregoing. 5. Representations
and Warranties of the Company. The Company represents and warrants to the Investors that (a) the
Company has the corporate power and authority to execute this Agreement and to bind it thereto, (b)
this Agreement has been duly and validly authorized, executed and delivered by the Company,
constitutes a valid and binding obligation and agreement of the Company, and is enforceable against
the Company in accordance with its terms, except as enforcement thereof may be limited by applicable
bankruptcy, insolvency, reorganization, moratorium, fraudulent conveyance or similar laws generally
affecting the rights of creditors and subject to general equity principles and (c) the execution,
delivery and performance of this Agreement by the Company does not and will not violate or conflict
with (i) any law, rule, regulation, order, judgment or decree applicable to it, or (ii) result in
any breach or violation of or constitute a default (or an event which with notice or lapse of time
or both could become a default) under or pursuant to, or result in the loss of a material benefit
under, or give any right of termination, amendment, acceleration or cancellation of, any
organizational document, or any material agreement, contract, commitment, understanding or
arrangement to which the Company is a party or by which it is bound. 6. Representations and
Warranties of the Investors. Each Investor, on behalf of itself, severally represents and warrants
to the Company that (a) as of the date hereof, such Investor beneficially owns, directly or
indirectly, only the number of shares of Common Stock as described opposite its name on Exhibit B
and Exhibit B includes all Affiliates and Associates of any Investors that own any securities of the
Company beneficially or of record and reflects all shares of Common Stock in which the Investors
have any interest or right to acquire, whether through derivative securities, voting agreements or
otherwise, (b) this Agreement has been duly and validly authorized, executed and delivered by such
Investor, and constitutes a valid and binding obligation and agreement of such Investor, enforceable
against such Investor in accordance with its terms, except as enforcement thereof may be limited by
applicable bankruptcy, insolvency, reorganization, moratorium, fraudulent conveyance or similar laws
generally affecting the rights of creditors and subject to general equity principles, (c) such
Investor has the authority to execute this Agreement on behalf of itself and the applicable Investor
associated with that signatory's name, and to bind such Investor to the terms hereof, (d) each of
the Investors shall use its commercially reasonable efforts to cause its respective Affiliates and
Associates to comply with the terms of this Agreement and (e) the execution, delivery and
performance of this Agreement by such Investor does not and will not violate or conflict with (i)
any law, rule, regulation, order, judgment or decree applicable to it, or (ii) result in any breach
or violation of or constitute a default (or an event which with notice or lapse of time or both
could become a default) under or pursuant to, or result in the loss of a material benefit under, or
give any right of termination, amendment, acceleration or cancellation of, any organizational
document, agreement, contract, commitment, understanding or arrangement to which such member is a
party or by which it is bound. 9
<!-- page 10 -->
7. Mutual Non-Disparagement. (a) Each Investor agrees that, until the earlier of (i) the expiration
of the Standstill Period or (ii) any material breach of this Agreement by the Company (provided that
the Company shall have three (3) business days following written notice from such Investor of any
material breach to remedy such material breach if capable of remedy), neither it nor any of its
Affiliates or Associates will, and it will cause each of its Affiliates and Associates not to,
directly or indirectly, publicly make, express, transmit, speak, write, verbalize or otherwise
publicly communicate in any way (or cause, further, assist, solicit, encourage, support or
participate in any of the foregoing), any remark, comment, message, information, declaration,
communication or other statement of any kind, whether verbal or in writing, that might reasonably be
construed to be derogatory or critical of, or negative toward, the Company or any of its directors,
officers, Affiliates, Associates, subsidiaries, employees, agents or representatives (collectively,
the "Company Representatives"), or that reveals, discloses, incorporates, is based upon, discusses,
includes or otherwise involves any confidential or proprietary information of the Company or its
subsidiaries or Affiliates or Associates, or to malign, harm, disparage, defame or damage the
reputation or good name of the Company, its business or any of the Company Representatives. (b) The
Company hereby agrees that, until the earlier of (i) the expiration of the Standstill Period or (ii)
any material breach of this Agreement by an Investor (provided that such Investor shall have three
(3) business days following written notice from the Company of any material breach to remedy such
material breach if capable of remedy), neither it nor any of its Affiliates will, and it will cause
each of its Affiliates not to, directly or indirectly, publicly make, express, transmit, speak,
write, verbalize or otherwise publicly communicate in any way (or cause, further, assist, solicit,
encourage, support or participate in any of the foregoing), any remark, comment, message,
information, declaration, communication or other statement of any kind, whether verbal or in
writing, that might reasonably be construed to be derogatory or critical of, or negative toward, the
Investors or their Affiliates or Associates or any of their agents or representatives (collectively,
the "Investor Agents"), or that reveals, discloses, incorporates, is based upon, discusses, includes
or otherwise involves any confidential or proprietary information of any Investor or its Affiliates
or Associates, or to malign, harm, disparage, defame or damage the reputation or good name of any
Investor, its business or any of the Investor Agents. (c) Notwithstanding the foregoing, nothing in
this Section 7 or elsewhere in this Agreement shall prohibit any party from making any statement or
disclosure required under the federal securities laws or other applicable laws. (d) The limitations
set forth in Section 7(a) and 7(b) shall not prevent any party from responding to any public
statement made by the other party of the nature described in Section 7(a) and 7(b) if such statement
by the other party was made in breach of this Agreement. 10
<!-- page 11 -->
8. Public Announcements. Promptly following the execution of this Agreement, the Company and the
Investor Group shall issue a mutually agreeable press release (the "Mutual Press Release"),
announcing certain terms of this Agreement, substantially in the form attached hereto as Exhibit C.
Prior to the issuance of the Mutual Press Release, neither the Company nor any of the Investors
shall issue any press release or make any public announcement regarding this Agreement or take any
action that would require public disclosure thereof without the prior written consent of the other
party. During the Standstill Period, neither the Company nor the Investor Group or any of its
Affiliates or Associates shall make any public announcement or statement that is inconsistent with
or contrary to the statements made in the Mutual Press Release, except as required by law or the
rules of any stock exchange (and, in any event, each party will provide the other party, prior to
making any such public announcement or statement, a reasonable opportunity to review and comment on
such disclosure, to the extent reasonably practicable under the circumstances, and each party will
consider any comments from the other in good faith) or with the prior written consent of the other
party, and otherwise in accordance with this Agreement. 9. SEC Filings. (a) No later than two (2)
business days following the execution of this Agreement, the Company shall file a Current Report on
Form 8-K with the SEC reporting the entry into this Agreement and appending or incorporating by
reference this Agreement as an exhibit thereto. The Company shall provide the Investor Group and its
counsel a reasonable opportunity to review and comment on the Form 8-K prior to such filing, which
comments shall be considered in good faith. (b) No later than two (2) business days following the
execution of this Agreement, the Investor Group shall file an amendment to its Schedule 13D with
respect to the Company that has been filed with the SEC, reporting the entry into this Agreement,
amending applicable items to conform to their obligations hereunder and appending or incorporating
by reference this Agreement as an exhibit thereto. The Investor Group shall provide the Company and
its counsel a reasonable opportunity to review and comment on the Schedule 13D prior to such filing,
which comments shall be considered in good faith. 10. Specific Performance. Each of the Investors,
on the one hand, and the Company, on the other hand, acknowledges and agrees that irreparable injury
to the other party hereto may occur in the event any of the provisions of this Agreement are not
performed in accordance with their specific terms or are otherwise breached and that such injury
would not be adequately compensable in monetary damages. It is accordingly agreed that the Investors
or any Investor, on the one hand, and the Company, on the other hand (the "Moving Party"), shall
each be entitled to seek specific enforcement of, and injunctive or other equitable relief to
prevent any violation of, the terms hereof, and the other party hereto will not take action,
directly or indirectly, in opposition to the Moving Party seeking such relief on the grounds that
any other remedy or relief is available at law or in equity. 11
<!-- page 12 -->
11. Notice. Any notices, consents, determinations, waivers or other communications required or
permitted to be given under the terms of this Agreement must be in writing and will be deemed to
have been delivered: (i) upon receipt, when delivered personally; (ii) upon receipt, when sent by
facsimile (provided confirmation of transmission is mechanically or electronically generated and
kept on file by the sending party); (iii) upon confirmation of receipt, when sent by email (provided
such confirmation is not automatically generated) or (iv) one (1) business day after deposit with a
nationally recognized overnight delivery service, in each case properly addressed to the party to
receive the same. The addresses and facsimile numbers for such communications shall be: If to the
Company: The Meet Group, Inc. 100 Union Square Drive New Hope, PA 18938 Fax No.: (215) 862.7825
Email: fred@themeetgroup.com Attention: Frederic A. Beckley, Esq., General Counsel and Executive
Vice President, Business Affairs With copies (which shall not constitute notice) to: Morgan, Lewis &
Bockius LLP 1111 Pennsylvania Avenue, N.W. Washington, DC 20004 Fax No.: (202) 739-3001 Email:
keith.gottfried@morganlewis.com Attention: Keith E. Gottfried, Esq. If to any Investor: Harvest
Capital Strategies LLC 600 Montgomery Street, Suite 1700 San Francisco, CA 94111 Fax No.: (415)
869-4433 Email: investments@harvestcaps.com Attention: Jeffrey B. Osher, Managing Director With
copies (which shall not constitute notice) to: Olshan Frome Wolosky LLP 1325 Avenue of the Americas
New York, NY 10019 Fax No.: (212) 451-2222 E-mail: swolosky@olshanlaw.com afreedman@olshanlaw.com
Attention: Steve Wolosky, Esq. Andrew Freedman, Esq. 12
<!-- page 13 -->
12. Governing Law. This Agreement shall be governed in all respects, including validity,
interpretation, and effect, by, and construed in accordance with, the laws of the State of Delaware
executed and to be performed wholly within the State of Delaware, without giving effect to the
choice of law or conflict of law principles thereof or of any other jurisdiction to the extent that
such principles would require or permit the application of the laws of another jurisdiction. 13.
Jurisdiction. Each of the parties hereto (a) consents to submit itself to the personal jurisdiction
of federal or state courts of the State of Delaware in the event any dispute arises out of this
Agreement or the transactions contemplated by this Agreement, (b) agrees that it shall not bring any
action relating to this Agreement or the transactions contemplated by this Agreement in any court
other than the federal or state courts of the State of Delaware, and each of the parties irrevocably
waives the right to trial by jury, (c) agrees to waive any bonding requirement under any applicable
law, in the case any other party seeks to enforce the terms by way of equitable relief, and (d)
irrevocably consents to service of process by first class certified mail, return receipt requested,
postage prepaid, to the address of such party's principal place of business or as otherwise provided
by applicable law. Each of the parties hereto irrevocably waives, and agrees not to assert, by way
of motion, as a defense, counterclaim or otherwise, in any action, suit or other legal proceeding
with respect to this Agreement, (a) any claim that it is not personally subject to the jurisdiction
of the above-named courts for any reason, (b) that it or its property is exempt or immune from
jurisdiction of any such court or from any legal process commenced in such courts (whether through
service of notice, attachment before judgment, attachment in aid of execution of judgment, execution
of judgment or otherwise), and (c) to the fullest extent permitted by applicable law, that (i) such
action, suit or other legal proceeding in any such court is brought in an inconvenient forum, (ii)
the venue of such action, suit or other legal proceeding is improper or (iii) this agreement, or the
subject matter hereof, may not be enforced in or by such court. 14. Waiver of Jury Trial. EACH PARTY
ACKNOWLEDGES AND AGREES THAT ANY CONTROVERSY WHICH MAY ARISE UNDER THIS AGREEMENT IS LIKELY TO
INVOLVE COMPLICATED AND DIFFICULT ISSUES AND, THEREFORE, EACH SUCH PARTY IRREVOCABLY AND
UNCONDITIONALLY WAIVES ANY RIGHT IT MAY HAVE TO A TRIAL BY JURY IN RESPECT OF ANY LEGAL ACTION
ARISING OUT OF OR RELATING TO THIS AGREEMENT OR THE TRANSACTIONS CONTEMPLATED BY THIS AGREEMENT.
EACH PARTY TO THIS AGREEMENT CERTIFIES AND ACKNOWLEDGES THAT (A) NO REPRESENTATIVE OF ANY OTHER
PARTY HAS REPRESENTED, EXPRESSLY OR OTHERWISE, THAT SUCH OTHER PARTY WOULD NOT SEEK TO ENFORCE THE
FOREGOING WAIVER IN THE EVENT OF A LEGAL ACTION, (B) SUCH PARTY HAS CONSIDERED THE IMPLICATIONS OF
THIS WAIVER, (C) SUCH PARTY MAKES THIS WAIVER VOLUNTARILY, AND (D) SUCH PARTY HAS BEEN INDUCED TO
ENTER INTO THIS AGREEMENT BY, AMONG OTHER THINGS, THE MUTUAL WAIVERS AND CERTIFICATIONS IN THIS
SECTION 14. 15. Representative. Each Investor hereby irrevocably appoints Jeffrey B. Osher as its
attorney-in-fact and representative (the "Investor Group Representative"), in such Investor's place
and stead, to do any and all things and to execute any and all documents and give and receive any
and all notices or instructions in connection with this Agreement and the transactions contemplated
hereby. The Company shall be entitled to rely, as being binding on each Investor, upon any action
taken by the Investor Group Representative or upon any document, notice, instruction or other
writing given or executed by the Investor Group Representative. 13
<!-- page 14 -->
16. Entire Agreement. This Agreement constitutes the full and entire understanding and agreement
among the parties with regard to the subject matter hereof, and supersedes all prior and
contemporaneous agreements, understandings and representations, whether oral or written, of the
parties with respect to the subject matter hereof. There are no restrictions, agreements, promises,
representations, warranties, covenants or undertakings, oral or written, between the parties other
than those expressly set forth herein. 17. Headings. The section headings contained in this
Agreement are for reference purposes only and shall not effect in any way the meaning or
interpretation of this Agreement. 18. Waiver. No failure on the part of any party to exercise, and
no delay in exercising, any right, power or remedy hereunder shall operate as a waiver thereof, nor
shall any single or partial exercise of such right, power or remedy by such party preclude any other
or further exercise thereof or the exercise of any other right, power or remedy. 19. Remedies. All
remedies hereunder are cumulative and are not exclusive of any other remedies provided by law or
equity. 20. Receipt of Adequate Information; No Reliance; Representation by Counsel. Each party
acknowledges that it has received adequate information to enter into this Agreement, that it has had
adequate opportunity to make whatever investigation or inquiry it may deem necessary or desirable in
connection with the subject matter of this Agreement prior to the execution hereof, and that it has
not relied on any promise, representation or warranty, express or implied not contained in this
Agreement. Each of the parties hereto acknowledges that it has been represented by counsel of its
choice throughout all negotiations that have preceded the execution of this Agreement, and that it
has executed the same with the advice of said independent counsel. Each party cooperated and
participated in the drafting and preparation of this Agreement and the documents referred to herein,
and any and all drafts relating thereto exchanged among the parties shall be deemed the work product
of all of the parties and may not be construed against any party by reason of its drafting or
preparation. Accordingly, any rule of law or any legal decision that would require interpretation of
any ambiguities in this Agreement against any party that drafted or prepared it is of no application
and is hereby expressly waived by each of the parties hereto, and any controversy over
interpretations of this Agreement shall be decided without regards to events of drafting or
preparation. Further, any rule of law or any legal decision that would provide any party with a
defense to the enforcement of the terms of this Agreement against such party shall have no
application and is expressly waived. The provisions of this Agreement shall be interpreted in a
reasonable manner to effect the intent of the parties. 21. Construction. When a reference is made in
this Agreement to a Section, such reference shall be to a Section of this Agreement, unless
otherwise indicated. The headings contained in this Agreement are for reference purposes only and
shall not affect in any way the meaning or interpretation of this Agreement. Whenever the words
"include," "includes" and "including" are used in this Agreement, they shall be deemed to be
followed by the words "without limitation." The words "hereof, "herein" and "hereunder" and words of
similar import when used in this Agreement shall refer to this Agreement as a whole and not to any
particular provision of this Agreement. The word "will" shall be construed to have the same meaning
as the word "shall." The words "dates hereof" will refer to the date of this Agreement. The word
"or" is not exclusive. The definitions contained in this Agreement are applicable to the singular as
well as the plural forms of such terms. Any agreement, instrument, law, rule or statute defined or
referred to herein means, unless otherwise indicated, such agreement, instrument, law, rule or
statute as from time to time amended, modified or supplemented. 14
<!-- page 15 -->
22. Severability. If any provision of this Agreement is held invalid or unenforceable by any court
of competent jurisdiction, the other provisions of this Agreement shall remain in full force and
effect. Any provision of this Agreement held invalid or unenforceable only in part or degree shall
remain in full force and effect to the extent not held invalid or unenforceable. The parties further
agree to replace such invalid or unenforceable provision of this Agreement with a valid and
enforceable provision that will achieve, to the extent possible, the purposes of such invalid or
unenforceable provision. 23. Amendment. This Agreement may be modified, amended or otherwise changed
only in a writing signed by all of the parties hereto, or in the case of the Investors, the Investor
Group Representative, or their respective successors or assigns. 24. Successors and Assigns. The
terms and conditions of this Agreement shall be binding upon and be enforceable by the parties
hereto and the respective successors, heirs, executors, legal representatives and permitted assigns
of the parties, and inure to the benefit of any successor, heir, executor, legal representative or
permitted assign of any of the parties; provided, however, that no party may assign this Agreement
or any rights or obligations hereunder without, with respect to any Investor, the express prior
written consent of the Company (with such consent specifically authorized in a written resolution
adopted and approved by the unanimous vote of the entire membership of the Board), and with respect
to the Company, the prior written consent of the Investor Group Representative. 25. No Third-Party
Beneficiaries. The representations, warranties and agreements of the parties contained herein are
intended solely for the benefit of the party to whom such representations, warranties or agreements
are made, and shall confer no rights, benefits, remedies, obligations, or liabilities hereunder,
whether legal or equitable, in any other person or entity, and no other person or entity shall be
entitled to rely thereon. 26. Counterparts; Facsimile / PDF Signatures. This Agreement and any
amendments hereto may be signed in any number of counterparts, each of which shall be an original,
with the same effect as if the signatures thereto and hereto were upon the same instrument. This
Agreement shall become effective when each party hereto shall have received a counterpart hereof
signed by the other parties hereto. In the event that any signature to this Agreement or any
amendment hereto is delivered by facsimile transmission or by e-mail delivery of a portable document
format (.pdf or similar format) data file, such signature shall create a valid and binding
obligation of the party executing (or on whose behalf such signature is executed) with the same
force and effect as if such facsimile or ".pdf" signature page were an original thereof. [REMAINDER
OF PAGE INTENTIONALLY LEFT BLANK] [SIGNATURE PAGE FOLLOWS] 15
<!-- page 16 -->
[SIGNATURE PAGE TO COOPERATION AGREEMENT] IN WITNESS WHEREOF the parties have duly executed and
delivered this Agreement as of the date first above written. THE MEET GROUP, INC. By: /s/ Frederic
Beckley Name: Frederic Beckley Title: General Counsel & EVP Business Affairs HARVEST SMALL CAP
PARTNERS MASTER, LTD. By: Harvest Capital Strategies LLC Investment Manager By: /s/ Jeffrey B. Osher
Name: Jeffrey B. Osher Title: Managing Director HARVEST SMALL CAP PARTNERS, L.P. By: Harvest Capital
Strategies LLC Investment Manager By: /s/ Jeffrey B. Osher Name: Jeffrey B. Osher Title: Managing
Director HARVEST SMALL CAP PARTNERS GP, LLC By: Harvest Capital Strategies LLC Investment Manager of
the Limited Partner By: /s/ Jeffrey B. Osher Name: Jeffrey B. Osher Title: Managing Director HARVEST
CAPITAL STRATEGIES LLC By: /s/ Jeffrey B. Osher Name: Jeffrey B. Osher Title: Managing Director /s/
Jeffrey B. Osher JEFFREY B. OSHER 16
<!-- page 17 -->
CERTAIN PORTIONS OF THIS DOCUMENT HAVE BEEN OMITTED PURSUANT TO A CONFIDENTIAL TREATMENT REQUEST.
SUCH OMITTED PORTIONS, WHICH ARE MARKED WITH BRACKETS [ ] AND AN ASTERISK*, HAVE BEEN SEPARATELY
FILED WITH THE SECURITIES AND EXCHANGE COMMISSION. EXHIBIT A DIRECTOR CANDIDATE POOL [***] 17
<!-- page 18 -->
EXHIBIT B STOCKHOLDERS, AFFILIATES, AND OWNERSHIP

Investor Shares of Common Stock Beneficially Owned Harvest Small Cap Partners Master, Ltd. 2,763,182

Harvest Small Cap Partners, L.P. 1,661,818

Aggregate total beneficially owned by the Investor Group: 4,425,000

18
<!-- page 19 -->
EXHIBIT C FORM OF PRESS RELEASE THE MEET GROUP REACHES AGREEMENT WITH HARVEST CAPITAL Agrees to
Appoint Two New Independent Directors to The Meet Group's Board NEW HOPE, PA, June 27, 2017 - The
Meet Group, Inc. (NASDAQ: MEET), a public market leader in the mobile meeting space, today announced
that it has entered into a cooperation agreement with Harvest Capital Strategies LLC and its
affiliates, which, in the aggregate, beneficially owns approximately 6.3% of The Meet Group's
outstanding shares, regarding the composition of The Meet Group's Board of Directors. Under the
terms of the agreement, The Meet Group has agreed to appoint to its Board two new independent
directors: Jim Parmelee, who has agreed to join the Meet Group Board effective immediately, and a
second director mutually acceptable to The Meet Group and Harvest Capital to be identified within
the next ninety days. Spencer G. Rhodes, The Meet Group's Chairman of the Board, stated, "We are
pleased to have reached this cooperation agreement with Harvest Capital, as we believe this outcome
serves the best interests of The Meet Group and its stockholders. We are also pleased to welcome Jim
Parmelee to our Board and look forward to the insights and experience he will bring." Jeffrey B.
Osher, the Managing Director of Harvest Capital, stated, "We have spent considerable time with The
Meet Group's senior management team and strongly support their strategy of creating a compelling
portfolio of mobile meeting apps. Under Geoff Cook's leadership, The Meet Group has methodically
grown its global platform while delivering consistent profitability and cash flow. We look forward
to continuing our collaboration with The Meet Group's Board and senior management team as they
execute on their long-term growth initiatives and focus on shareholder value creation." Pursuant to
the cooperation agreement, Harvest Capital has agreed that, until the certification of the
shareholder vote at The Meet Group's 2018 Annual Meeting of Stockholders, it will abide by certain
customary standstill provisions. The cooperation agreement between The Meet Group and Harvest
Capital will be included as an exhibit to a Current Report on Form 8-K that The Meet Group will file
with the Securities and Exchange Commission. Morgan, Lewis & Bockius LLP served as legal counsel to
The Meet Group. Olshan Frome Wolosky LLP served as legal advisor to Harvest Capital. The Meet Group
also announced today that it has appointed The Blueshirt Group to lead its investor relations
communications and strategy. The Blueshirt Group is a leading tech-focused investor relations firm
that specializes in investor relations, IPO advisory, financial communications, financial media
relations and crisis management. About Jim Parmelee Mr. Parmelee brings over 25 years of technology
industry experience. He is currently an advisor to Hamilton Robinson Capital Partners, a middle
market focused private equity firm. Jim was previously a Managing Director in Peak Ten Management
LLC, where he was responsible for the firm's investments in the software, Internet and technology
infrastructure verticals. Before Peak Ten, Jim was a Partner in Union Square Advisors, an M&A
advisory firm focused on the technology sector, where he led the firm's global Information
Technology infrastructure practice. Jim was previously a leading data networking and telecom
equipment equity research analyst at Credit Suisse First Boston (now Credit Suisse). Jim was highly
ranked by external polls throughout his research career including being named six times to
Institutional Investor Magazine's All America Research Team. 19
<!-- page 20 -->
About The Meet Group The Meet Group (NASDAQ: MEET) is a fast-growing portfolio of mobile apps
designed to meet the universal need for human connection. Using innovative products and
sophisticated data science, The Meet Group keeps its approximately 2.8 million mobile daily active
users engaged and originates untold numbers of casual chats, friendships, dates, and marriages. The
Meet Group offers advertisers the opportunity to reach customers on a global scale with hundreds of
millions of daily mobile ad impressions. The Meet Group utilizes high user density, economies of
scale, and leading monetization strategies with the goal of maximizing adjusted EBITDA. Our apps -
currently MeetMe , Skout , Tagged , and Hi5 - let users in more than 100 countries chat, share
photos, stream live video, and discuss topics of interest, and are available on iPhone, iPad, and
Android in multiple languages. For more information, please visit themeetgroup.com. MEET Investor
Contact: The Blueshirt Group Allise Furlani allise@blueshirtgroup.com 20

® ® ® ®
