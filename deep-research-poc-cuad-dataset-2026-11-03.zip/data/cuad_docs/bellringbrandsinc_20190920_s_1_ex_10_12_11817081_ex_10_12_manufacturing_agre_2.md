<!-- page 1 -->
# MANUFACTURING AGREEMENT
| Field | Value |
|---|---|
| Document Type | Manufacturing Agreement |
| Agreement Date | 2018-06-11 |
| Parties | Stremick's Heritage Foods, LLC ("Heritage"); Premier Nutrition Corporation ("Premier") |
| Source | CUAD v1 / BellringBrandsInc_20190920_S-1_EX-10.12_11817081_EX-10.12_Manufacturing Agreement2 |

AMENDMENT NO. 1 TO STREMICK'S HERITAGE FOODS, LLC and PREMIER NUTRITION CORPORATION MANUFACTURING
AGREEMENT

This Amendment No. 1 (the "Amendment"), entered into by and between Stremick's Heritage Foods, LLC
("Heritage") Premier Nutrition Corporation ("Premier") is effective as of June 11, 2018 ("Amendment
Effective Date") and amends that certain Manufacturing Agreement between Heritage and Premier dated
July 1, 2017 ("Agreement"). Heritage and Premier are each referred to herein as a "Party" and
collectively as the "Parties."

WHEREAS, Heritage and Premier entered into the Agreement;

WHEREAS, the Parties wish to amend the Agreement in accordance with the terms and conditions set
forth herein.

NOW, THEREFORE, in consideration of the promises and of the mutual covenants, representations and
warranties contained in the Agreement and set forth herein, the Parties hereby agree that the
following changes shall be made to the Agreement:

1. The Parties hereby agree to remove Section 2(c) in its entirety and replace it with the
following:

During the Term of this Agreement, Premier shall be required to purchase a Minimum Annual Order
Volume ("MAOV") of [***] ("Units") for the twelve-month period commencing July 1, 2018 and ending
June 30, 2019. The MAOV [***] Units for each twelve-month period commencing July 1, 2019 through the
end of the Term, contingent upon commercial aseptic production at Heritage's [***] facility and
approval of that facility by Premier by January 1, 2019. For the avoidance of doubt, the six-month
period commencing July 1, 2022 and ending December 31, 2022, Premier will be required to purchase
[***] (the twelve-month periods and the six-month period are each a "Contract Period").

2. Except as otherwise specified above in this Amendment, all other terms, conditions and covenants
of the Agreement shall remain in full force and effect.

IN WITNESS WHEREOF, the Parties have caused this Amendment to be signed by their respective duly
authorized representatives as of the Amendment Effective Date. Premier Nutrition Corporation
Stremick's Heritage Foods, LLC.

By: /s/ Darcy Davenport By: /s/ Sam Stremick Name: Darcy Davenport Name: Sam Stremick Title:
President Title: President

Source: BELLRING BRANDS, INC., S-1, 9/20/2019
