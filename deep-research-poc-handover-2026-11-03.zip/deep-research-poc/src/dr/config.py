"""Explicit budgets and caps. Every limit in the system lives here and is passed down.

Values are defaults for a 5-minute (300 s) wall-clock budget with small/open models.
Re-tune after the Phase 0 endpoint probe (`scripts/probe_endpoints.py`).
"""
from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(frozen=True)
class ToolCaps:
    # grep
    GREP_MAX_MATCHES: int = 40          # matches returned (counts are always complete)
    GREP_CONTEXT_LINES: int = 1         # lines of context either side of a hit
    GREP_MAX_LINE_CHARS: int = 300      # truncate very long lines in output
    GREP_MAX_DOCS_IN_COUNTS: int = 50   # per-doc count rows returned (rest summarized)
    # read
    READ_MAX_LINES: int = 120           # hard cap on a single read window
    READ_DEFAULT_LINES: int = 60
    # outline
    OUTLINE_MAX_HEADINGS: int = 80
    # manifest
    MANIFEST_MAX_ROWS: int = 60
    # bm25 (Approach 1)
    BM25_CHUNK_TOKENS: int = 300
    BM25_DEEP_K: int = 1000             # cached ranking depth the agent can page through
    BM25_PAGE_SIZE: int = 10
    BM25_SNIPPET_CHARS: int = 240
    BM25_K1: float = 1.5                # Pi-Serini tuned k1=25/b=1 for its corpus; re-tune on the golden set
    BM25_B: float = 0.75
    # first move (Approach 1)
    FIRST_MOVE_CLUES_MAX: int = 10
    FIRST_MOVE_K_PER_CLUE: int = 200    # BM25 depth per clue for the candidate union
    FIRST_MOVE_TOP_HITS: int = 10       # line-cited hits shown in the opening observation
    FIRST_MOVE_TOP_DOCS: int = 15       # candidate documents listed in the opening observation
    FIRST_MOVE_FEEDBACK_DOCS: int = 3   # pseudo-relevance feedback: top chunks a clue's query is expanded from
    FIRST_MOVE_EXPANSION_TERMS: int = 5 # terms borrowed from those chunks (0 disables expansion)
    # offload
    OFFLOAD_TOKENS: int = 8000          # tool results above this go to a file + pointer
    OFFLOAD_PREVIEW_LINES: int = 40     # lines of an offloaded result shown inline next to the pointer


@dataclass(frozen=True)
class AgentBudgets:
    RESEARCH_MIN_CALLS: int = 6         # under-search floor
    RESEARCH_MAX_CALLS: int = 25
    WIDTH_SCHEDULE: tuple[int, int, int] = (3, 2, 1)  # parallel calls per turn: early / mid / late (W&D)
    RESEARCH_MAX_CONTEXT_TOKENS: int = 60_000  # compaction safety net: oldest tool results elided above this
    MALFORMED_TURNS_MAX: int = 2        # consecutive all-malformed turns -> constrained one-tool JSON step
    NO_TOOL_TURNS_MAX: int = 2          # consecutive text-only turns -> forced submit
    FORCE_SUBMIT_GRACE_S: float = 15.0  # past the deadline by more than this -> no final model call
    MODEL_ERRORS_MAX: int = 2           # failed model calls (after client retries) before the loop gives up
    FANOUT_WIDTH: int = 4               # researchers running at once in the breadth branch (free tier: ~40 req/min)
    FANOUT_UNITS_MAX: int = 8           # sub-questions or doc batches per run
    FANOUT_MAX_CALLS: int = 12          # per researcher
    FANOUT_MIN_CALLS: int = 2
    FANOUT_FINDING_MAX_TOKENS: int = 1500
    FANOUT_BATCH_SIZE: int = 40         # doc ids per batch when the router gives no sub-questions
    GAP_ROUNDS_MAX: int = 1
    GAP_UNITS_MAX: int = 3              # targeted researchers in the gap round
    OUTLINE_ITERATIONS_MAX: int = 2
    OUTLINE_MAX_SECTIONS: int = 6
    WRITE_SECTION_CONCURRENCY: int = 4  # section drafts run in parallel (respect the endpoint probe)
    LONG_CONTEXT_MAX_TOKENS: int = 100_000  # router: long_context only below this
    EXTRACT_CONCURRENCY: int = 4        # grid tool; set from endpoint probe (free tier: ~40 req/min)
    EXTRACT_DOC_MAX_TOKENS: int = 12_000  # document text shown to the extractor per call (header + best chunks)
    EXTRACT_CHUNKS_PER_DOC: int = 6     # BM25 chunks of the document used to fill that budget


@dataclass(frozen=True)
class StageBudgetsS:
    """Wall-clock budgets per stage, in seconds.

    The sequential stages (materialize, first move, research, write, verify) plus RESERVE must
    fit inside TOTAL; this is checked at construction so a misconfiguration fails loudly
    (invariant 10: budgets are explicit). The optional gap round on the breadth path runs
    INSIDE the research budget, not in addition to it: GAP caps how much of RESEARCH the
    gap round may consume. Defaults: 10 + 30 + 150 + 45 + 30 = 265 s, plus 30 s reserve.
    """

    TOTAL: float = 300.0
    MATERIALIZE: float = 10.0
    FIRST_MOVE: float = 30.0
    RESEARCH: float = 150.0             # includes the optional gap round on the breadth path
    GAP: float = 45.0                   # max share of RESEARCH the gap round may consume
    WRITE: float = 45.0
    VERIFY: float = 30.0
    RESERVE: float = 30.0               # never scheduled; the deadline forces a write from the bank

    def sequential_total(self) -> float:
        """Sum of the stages that run one after another on every path (GAP is inside RESEARCH)."""
        return self.MATERIALIZE + self.FIRST_MOVE + self.RESEARCH + self.WRITE + self.VERIFY

    def __post_init__(self) -> None:
        if self.GAP > self.RESEARCH:
            raise ValueError(f"GAP ({self.GAP:g} s) must fit inside RESEARCH ({self.RESEARCH:g} s)")
        used = self.sequential_total() + self.RESERVE
        if used > self.TOTAL:
            raise ValueError(
                f"stage budgets + reserve = {used:g} s exceed TOTAL = {self.TOTAL:g} s; "
                "shrink a stage or the reserve"
            )


@dataclass(frozen=True)
class VerifyParams:
    NGRAM: int = 5
    ALIGN_THRESHOLD: float = 0.70       # fraction of quote n-grams found in cited page
    TRUNCATE_THRESHOLD: float = 0.40    # between this and ALIGN -> keep only aligned span
    TIER2_GROUP_SIZE: int = 8
    TIER2_SAMPLE_RATE_CLEAN: float = 0.2    # share of clean (tier-1 keep) claims re-checked; flagged ones always
    TIER2_ENABLED: bool = True
    TIER2_CONTEXT_LINES: int = 12           # lines of source context around each cited span shown to the verifier
    # provenance gate (near-duplicate sources count once)
    SHINGLE_N: int = 5                      # word n-gram shingles
    MINHASH_PERMS: int = 64
    # Calibrated on the synthetic golden corpus: conformed copies score >= 0.97, template-generated
    # agreements for DIFFERENT borrowers score up to 0.94 (boilerplate), amendments < 0.2.
    NEAR_DUP_THRESHOLD: float = 0.95        # estimated Jaccard at or above this -> same cluster, any parties
    NEAR_DUP_SAME_PARTIES_THRESHOLD: float = 0.8   # ... or at least this when both documents list the same parties


@dataclass(frozen=True)
class Config:
    tools: ToolCaps = field(default_factory=ToolCaps)
    agents: AgentBudgets = field(default_factory=AgentBudgets)
    stages: StageBudgetsS = field(default_factory=StageBudgetsS)
    verify: VerifyParams = field(default_factory=VerifyParams)
    ENABLE_BASH_TOOL: bool = False      # team decision (PLAN open decision 2)
    ENABLE_BM25_TOOL: bool = True       # ephemeral per-query index (PLAN open decision 3)
    ENABLE_LOCAL_RERANK: bool = False   # local cross-encoder in the first move (PLAN open decision 4)
    RATE_LIMIT_RETRIES: int = 5         # harness-level retries on HTTP 429 (after the client's own retries)
    RATE_LIMIT_BACKOFF_S: float = 2.0   # first wait; then doubles: 2, 4, 8, 16, 30 s (load shedding clears in seconds)
    RATE_LIMIT_BACKOFF_MAX_S: float = 30.0  # cap per wait; every wait is also capped by the stage deadline
    PAGE_MARKER_RE: str = r"^<!--\s*page\s+(\d+)\s*-->\s*$"


DEFAULT = Config()
