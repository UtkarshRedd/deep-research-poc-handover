"""Golden questions over the CUAD corpus, derived from the expert clause annotations.

    .venv/Scripts/python.exe -I scripts/make_cuad_golden.py            # -> data/golden/cuad_questions.jsonl
    .venv/Scripts/python.exe -I scripts/make_cuad_golden.py --check    # regenerate in memory, compare with disk

Requires data/cuad_docs (scripts/make_cuad_corpus.py) and data/raw/cuad (scripts/fetch_cuad.py).
Schema: PLAN.md "Golden set spec"; gold docs are `<stem>` placeholders (dr.eval.golden resolves them).

How gold is built
-----------------
* Every gold answer / gold item is a CUAD annotated span, whitespace-collapsed; the gold pages are
  the PDF pages the span's character offsets land on (data/cuad_docs/_alignment.json). Before
  anything is written, `self_check` re-reads the markdown on disk and asserts each answer is on a
  cited page (whitespace-insensitive, because the corpus reflows lines; see data/golden/README.md).
* Long clause spans are cut to MAX_ANSWER_CHARS at a word boundary (a prefix is still verbatim);
  the CUAD normalized answer (e.g. "Nevada", "60 days") goes into the rubric for the judge.
* Only contracts whose page alignment is exact (no approximate pages, no suspect pages among the
  cited ones) are used for questions that cite pages.
* not_in_corpus questions ask for a clause category that CUAD marks absent in that contract; they
  cite no documents (eval convention) and record the contract and category in `notes`.
* Deterministic: a fixed-seed RNG only chooses which contracts/subsets to use.
"""
from __future__ import annotations

import argparse
import bisect
import csv
import json
import random
import re
import sys
from dataclasses import dataclass, field
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from dr.ingest.pages import _norm_key  # noqa: E402

RAW = ROOT / "data" / "raw" / "cuad" / "CUAD_v1"
DOCS = ROOT / "data" / "cuad_docs"
ALIGNMENT = DOCS / "_alignment.json"
OUT = ROOT / "data" / "golden" / "cuad_questions.jsonl"
SEED = 20251101
MAX_ANSWER_CHARS = 300
MIN_SPAN_CHARS = 8
MAX_USES_PER_DOC = 2

PAGE_RE = re.compile(r"^<!--\s*page\s+(\d+)\s*-->\s*$", re.MULTILINE)

LABEL = {  # category -> how a user names the clause
    "Governing Law": "governing-law", "Cap On Liability": "cap on liability", "Exclusivity": "exclusivity",
    "Non-Compete": "non-compete", "Termination For Convenience": "termination for convenience",
    "Anti-Assignment": "anti-assignment", "Minimum Commitment": "minimum commitment", "Audit Rights": "audit rights",
    "Expiration Date": "expiration", "Renewal Term": "renewal term",
    "Notice Period To Terminate Renewal": "notice period to terminate renewal", "Effective Date": "effective date",
    "Most Favored Nation": "most-favored-nation", "Change Of Control": "change-of-control",
    "Liquidated Damages": "liquidated damages", "Source Code Escrow": "source code escrow",
    "Non-Disparagement": "non-disparagement", "No-Solicit Of Employees": "no-solicit of employees",
    "Insurance": "insurance", "Ip Ownership Assignment": "IP ownership assignment",
    "Uncapped Liability": "uncapped liability", "Joint Ip Ownership": "joint IP ownership",
    "Revenue/Profit Sharing": "revenue or profit sharing", "Volume Restriction": "volume restriction",
    "Price Restrictions": "price restriction", "Warranty Duration": "warranty duration",
    "Post-Termination Services": "post-termination services", "Covenant Not To Sue": "covenant not to sue",
    "Third Party Beneficiary": "third-party beneficiary",
}

SINGLE_TEMPLATES = {
    "Governing Law": "Which jurisdiction's law governs {h}?",
    "Cap On Liability": "What cap on liability does {h} provide?",
    "Exclusivity": "What exclusivity obligation does {h} impose?",
    "Non-Compete": "What non-compete restriction does {h} contain?",
    "Termination For Convenience": "Can a party terminate {h} for convenience, and on what terms?",
    "Anti-Assignment": "What does {h} say about assignment of the agreement?",
    "Minimum Commitment": "What minimum purchase or volume commitment does {h} contain?",
    "Audit Rights": "What audit rights does {h} grant?",
}
TEMPORAL_TEMPLATES = {
    "Expiration Date": "When does {h} expire, according to its term clause?",
    "Renewal Term": "What renewal term does {h} provide for after the initial term?",
    "Notice Period To Terminate Renewal": "How much notice is required to prevent the automatic renewal of {h}?",
    "Effective Date": "When does {h} become effective?",
}
PLAN = {  # family -> (category, count)
    "single": [("Governing Law", 12), ("Cap On Liability", 6), ("Exclusivity", 6), ("Non-Compete", 6),
               ("Termination For Convenience", 3), ("Anti-Assignment", 3)],
    "temporal": [("Expiration Date", 10), ("Renewal Term", 7), ("Notice Period To Terminate Renewal", 7)],
    "identifier_parties": 8,
    "identifier_date": 8,
    "coverage": [("Non-Compete", 2), ("Exclusivity", 2), ("Cap On Liability", 2), ("Most Favored Nation", 2),
                 ("Change Of Control", 2), ("Termination For Convenience", 2)],
    "multihop": 8,
    "not_in_corpus": [("Non-Compete", 4), ("Cap On Liability", 3), ("Renewal Term", 3), ("Most Favored Nation", 2),
                      ("Liquidated Damages", 2), ("Change Of Control", 2)],
}
COVERAGE_SUBSET = (8, 12)    # contracts listed per coverage question
COVERAGE_POSITIVES = (3, 6)


# --------------------------------------------------------------------------- data


def ws(s: str) -> str:
    return " ".join(s.split())


@dataclass
class Doc:
    stem: str
    cuad_title: str
    context: str
    page_starts: list[int]
    approximate: bool
    suspect: set[int]
    spans: dict[str, list[tuple[str, int]]]      # category -> [(text, start)] in the ORIGINAL text
    csv_row: dict
    md_pages: dict[int, str]
    uses: int = 0
    title: str = ""
    doc_type: str = ""
    date: str = ""
    parties: list[str] = field(default_factory=list)
    date_source: str = ""

    def pages_of(self, start: int, text: str) -> list[int]:
        last = max(start, start + len(text) - 1)
        a = bisect.bisect_right(self.page_starts, start)
        b = bisect.bisect_right(self.page_starts, last)
        return list(range(a, b + 1))

    def csv_answer(self, cat: str) -> str:
        for k in (f"{cat}-Answer", f"{cat}- Answer"):
            v = self.csv_row.get(k)
            if v is not None:
                return ws(v)
        return ""

    def has(self, cat: str) -> bool:
        return bool(self.spans.get(cat))

    def best_span(self, cat: str) -> tuple[str, list[int], bool] | None:
        """Shortest usable span: (whitespace-collapsed text, pages, truncated)."""
        cands = sorted(((ws(t), s) for t, s in self.spans.get(cat, [])), key=lambda x: len(x[0]))
        for text, start in cands:
            if len(text) < MIN_SPAN_CHARS:
                continue
            raw = next(t for t, s in self.spans[cat] if s == start and ws(t) == text)
            pages = self.pages_of(start, raw)
            truncated = False
            if len(text) > MAX_ANSWER_CHARS:
                cut = text.rfind(" ", 0, MAX_ANSWER_CHARS)
                text = text[: cut if cut > MAX_ANSWER_CHARS // 2 else MAX_ANSWER_CHARS].rstrip(" ,;:")
                truncated = True
                pages = self.pages_of(start, raw[: len(text) + 1])
            if any(p in self.suspect for p in pages):
                continue
            return text, pages, truncated
        return None

    def page_text(self, pages: list[int]) -> str:
        return "\n".join(self.md_pages[p] for p in pages)


def _split_pages(text: str) -> dict[int, str]:
    out: dict[int, str] = {}
    cur: int | None = None
    buf: list[str] = []
    for ln in text.split("\n"):
        m = PAGE_RE.match(ln)
        if m:
            if cur is not None:
                out[cur] = "\n".join(buf)
            cur, buf = int(m.group(1)), []
        else:
            buf.append(ln)
    if cur is not None:
        out[cur] = "\n".join(buf)
    return out


def _clean_party(p: str) -> str:
    return ws(re.sub(r"\s*\([^)]*\)", "", p)).strip(" ;,")


_GENERIC_WORDS = re.compile(r"\b(each|collectively|hereinafter|referred|party|parties|between|and/or)\b", re.I)


def looks_like_name(t: str) -> bool:
    """A Parties span that reads as a company/person name, not a definitional fragment."""
    return (6 <= len(t) <= 80 and t[0].isalnum() and len(t.split()) <= 8
            and any(c.isupper() for c in t) and not _GENERIC_WORDS.search(t))


def load_docs() -> list[Doc]:
    data = {t["title"]: t for t in json.loads((RAW / "CUAD_v1.json").read_text(encoding="utf-8"))["data"]}
    with (RAW / "master_clauses.csv").open(encoding="utf-8", newline="") as f:
        rows = {_norm_key(r["Filename"].rsplit(".", 1)[0]): r for r in csv.DictReader(f)}
    docs: list[Doc] = []
    for rec in json.loads(ALIGNMENT.read_text(encoding="utf-8")):
        entry = data[rec["cuad_title"]]
        context = entry["paragraphs"][0]["context"].replace("\r", " ")
        spans: dict[str, list[tuple[str, int]]] = {}
        for q in entry["paragraphs"][0]["qas"]:
            cat = q["id"].rsplit("__", 1)[-1]
            spans[cat] = [(a["text"], a["answer_start"]) for a in q["answers"] if ws(a["text"])]
        meta = json.loads((DOCS / f"{rec['stem']}.meta.json").read_text(encoding="utf-8"))
        md = (DOCS / f"{rec['stem']}.md").read_text(encoding="utf-8")
        d = Doc(stem=rec["stem"], cuad_title=rec["cuad_title"], context=context, page_starts=rec["page_starts"],
                approximate=rec["approximate"], suspect=set(rec["suspect_pages"]), spans=spans,
                csv_row=rows.get(_norm_key(rec["cuad_title"]), {}), md_pages=_split_pages(md),
                title=meta["title"], doc_type=meta["doc_type"], date=meta.get("date", ""),
                date_source=meta.get("date_source", ""),
                parties=[_clean_party(p) for p in meta.get("parties", "").split(";") if _clean_party(p)])
        docs.append(d)
    return docs


# --------------------------------------------------------------------------- corpus-wide helpers


class Corpus:
    def __init__(self, docs: list[Doc]) -> None:
        self.docs = docs
        self.by_stem = {d.stem: d for d in docs}
        self._lower = {d.stem: ws(d.context).lower() for d in docs}
        self._handle: dict[str, str | None] = {}

    def n_docs_with(self, term: str) -> int:
        t = ws(term).lower()
        return sum(1 for s in self._lower.values() if t in s)

    def unique_party_spans(self, d: Doc) -> list[tuple[str, list[int]]]:
        """Parties spans that occur in no other contract (so they identify the document)."""
        out: list[tuple[str, list[int]]] = []
        seen: set[str] = set()
        for raw, start in d.spans.get("Parties", []):
            t = ws(raw).strip(" ,;")
            if not looks_like_name(t) or t in seen or t.lower() in {p.lower() for p, _ in out}:
                continue
            if not (t[0].isupper() or t[0].isdigit()) or t.lower().startswith(("d/b/a", "dba ", "f/k/a")):
                continue
            seen.add(t)
            if self.n_docs_with(t) == 1:
                out.append((t, d.pages_of(start, raw)))
        out.sort(key=lambda x: -len(x[0]))
        return out

    def two_distinct_parties(self, d: Doc) -> list[tuple[str, list[int]]]:
        """Two unique party spans naming different entities (not 'X, LLC' and 'X, L.L.C.')."""
        spans = self.unique_party_spans(d)
        for i, (a, pa) in enumerate(spans):
            ka = _norm_key(a)
            for b, pb in spans[i + 1:]:
                kb = _norm_key(b)
                if ka[:10] != kb[:10] and ka not in kb and kb not in ka:
                    return [(a, pa), (b, pb)]
        return []

    def handle(self, d: Doc) -> str | None:
        """A party-name span unique to this contract (used as a gold item / in question text)."""
        if d.stem not in self._handle:
            u = self.unique_party_spans(d)
            self._handle[d.stem] = u[0][0] if u else None
        return self._handle[d.stem]


def describe(d: Doc) -> str:
    """How a question refers to a contract: title + parties (+ date), all from the metadata table."""
    name = d.title.title() if d.title.isupper() else d.title
    name = re.sub(r"\bAnd\b", "and", name)
    name = name if name.lower().startswith("the ") else f"the {name}"
    if len(d.parties) >= 2:
        s = f"{name} between {d.parties[0]} and {d.parties[1]}"
    elif d.parties:
        s = f"{name} of {d.parties[0]}"
    else:
        s = name
    if d.date:
        s += f" (filed {d.date})" if d.date_source.startswith("filename") else f" (dated {d.date})"
    return s


# --------------------------------------------------------------------------- generation


def generate() -> tuple[str, list[dict]]:
    rng = random.Random(SEED)
    docs = load_docs()
    corpus = Corpus(docs)
    exact = [d for d in docs if not d.approximate]
    questions: list[dict] = []

    def qid() -> str:
        return f"cq{len(questions) + 1:03d}"

    def pick(cands: list[Doc], pred, n: int) -> list[Doc]:
        pool = [d for d in cands if d.uses < MAX_USES_PER_DOC]
        rng.shuffle(pool)
        pool.sort(key=lambda d: d.uses)  # stable: least-used first, random within
        out: list[Doc] = []
        for d in pool:
            if pred(d):
                out.append(d)
                d.uses += 1
                if len(out) == n:
                    break
        return out

    def cite_rubric(d: Doc, pages: list[int]) -> str:
        return f"cites page {', '.join(map(str, pages))} of {describe(d)}"

    def clause_question(family: str, cat: str, template: str, n: int) -> None:
        for d in pick(exact, lambda x: x.best_span(cat) is not None and len(x.parties) >= 1, n):
            text, pages, truncated = d.best_span(cat)  # type: ignore[misc]
            ans = d.csv_answer(cat)
            rubric = [f"quotes or faithfully paraphrases the {LABEL[cat]} clause", cite_rubric(d, pages)]
            if ans and ans.lower() not in {"yes", "no"}:
                rubric.insert(0, f"states {ans}")
            questions.append({
                "qid": qid(), "type": family, "question": template.format(h=describe(d)),
                "gold_docs": [{"doc_id": f"<{d.stem}>", "pages": pages}],
                "gold_answer": text, "gold_items": [], "rubric": rubric,
                "notes": f"CUAD category {cat}" + ("; gold_answer is the opening of the annotated span" if truncated else ""),
            })

    for cat, n in PLAN["single"]:
        clause_question("single", cat, SINGLE_TEMPLATES[cat], n)
    for cat, n in PLAN["temporal"]:
        clause_question("temporal", cat, TEMPORAL_TEMPLATES[cat], n)

    # identifier: by parties ------------------------------------------------------------------
    def two_unique_parties(d: Doc) -> bool:
        return bool(corpus.two_distinct_parties(d)) and bool(d.spans.get("Document Name"))

    for d in pick(exact, two_unique_parties, PLAN["identifier_parties"]):
        (a, pa), (b, pb) = corpus.two_distinct_parties(d)
        name_raw, name_start = min(d.spans["Document Name"], key=lambda x: x[1])
        pages = sorted(set(pa) | set(pb) | set(d.pages_of(name_start, name_raw)))
        if any(p in d.suspect for p in pages):
            d.uses -= 1
            continue
        questions.append({
            "qid": qid(), "type": "identifier",
            "question": f"Which agreement in the corpus was entered into between {a} and {b}? Give its title and date.",
            "gold_docs": [{"doc_id": f"<{d.stem}>", "pages": pages}],
            "gold_answer": ws(name_raw), "gold_items": [],
            "rubric": [f"identifies {describe(d)}", f"gives the title {ws(name_raw)}",
                       f"states the date {d.date}" if d.date else "states the agreement date", cite_rubric(d, pages)],
            "notes": "exact identifier: both party names occur in no other contract",
        })

    # identifier: by agreement-date span -------------------------------------------------------
    def unique_date_span(d: Doc) -> bool:
        if not d.spans.get("Agreement Date") or not d.spans.get("Document Name") or not corpus.handle(d):
            return False
        t, s = min(d.spans["Agreement Date"], key=lambda x: len(x[0]))
        return len(ws(t)) >= 10 and corpus.n_docs_with(t) == 1

    for d in pick(exact, unique_date_span, PLAN["identifier_date"]):
        t, s = min(d.spans["Agreement Date"], key=lambda x: len(x[0]))
        name_raw, name_start = min(d.spans["Document Name"], key=lambda x: x[1])
        pages = sorted(set(d.pages_of(s, t)) | set(d.pages_of(name_start, name_raw)))
        if any(p in d.suspect for p in pages):
            d.uses -= 1
            continue
        questions.append({
            "qid": qid(), "type": "identifier",
            "question": f'Which agreement in the corpus is dated "{ws(t).strip(".")}"? Name it and its parties.',
            "gold_docs": [{"doc_id": f"<{d.stem}>", "pages": pages}],
            "gold_answer": ws(name_raw), "gold_items": [corpus.handle(d)],  # type: ignore[list-item]
            "rubric": [f"identifies {describe(d)}", "names the parties", cite_rubric(d, pages)],
            "notes": "exact identifier: the quoted date phrase occurs in exactly one contract",
        })

    # coverage over a named subset --------------------------------------------------------------
    for cat, n in PLAN["coverage"]:
        for _ in range(n):
            pos_pool = [d for d in exact if d.has(cat) and corpus.handle(d) and d.best_span(cat) and d.uses < MAX_USES_PER_DOC]
            neg_pool = [d for d in docs if not d.has(cat) and d.csv_answer(cat).lower() in {"no", ""} and d.uses < MAX_USES_PER_DOC]
            rng.shuffle(pos_pool)
            rng.shuffle(neg_pool)
            n_pos = rng.randint(*COVERAGE_POSITIVES)
            size = rng.randint(*COVERAGE_SUBSET)
            positives, negatives = pos_pool[:n_pos], neg_pool[: size - n_pos]
            if len(positives) < COVERAGE_POSITIVES[0] or len(negatives) < size - n_pos:
                continue
            subset = positives + negatives
            rng.shuffle(subset)
            for d in subset:
                d.uses += 1
            gold_docs, items = [], []
            for d in positives:
                handle = corpus.handle(d)
                hp = next(p for h, p in corpus.unique_party_spans(d) if h == handle)
                _, cp, _ = d.best_span(cat)  # type: ignore[misc]
                gold_docs.append({"doc_id": f"<{d.stem}>", "pages": sorted(set(hp) | set(cp))})
                items.append(handle)
            listing = "; ".join(describe(d) for d in subset)
            questions.append({
                "qid": qid(), "type": "coverage",
                "question": f"Among the following {len(subset)} agreements, which contain a {LABEL[cat]} clause? "
                            f"For each, quote the clause. Agreements: {listing}.",
                "gold_docs": gold_docs, "gold_answer": None, "gold_items": items,
                "rubric": [f"lists exactly these {len(items)} agreements: " + "; ".join(describe(d) for d in positives),
                           f"does not list the other {len(negatives)} agreements",
                           "cites the clause page for each listed agreement"],
                "notes": f"CUAD category {cat}; negatives are contracts CUAD annotates as having no such clause",
            })

    # multihop: parties -> governing law -------------------------------------------------------
    def mh_ok(d: Doc) -> bool:
        return bool(corpus.two_distinct_parties(d)) and d.best_span("Governing Law") is not None

    for d in pick(exact, mh_ok, PLAN["multihop"]):
        (a, pa), (b, pb) = corpus.two_distinct_parties(d)
        text, gp, truncated = d.best_span("Governing Law")  # type: ignore[misc]
        pages = sorted(set(pa) | set(pb) | set(gp))
        ans = d.csv_answer("Governing Law")
        questions.append({
            "qid": qid(), "type": "multihop",
            "question": f"Under which jurisdiction's law is the agreement between {a} and {b} governed?",
            "gold_docs": [{"doc_id": f"<{d.stem}>", "pages": pages}],
            "gold_answer": text, "gold_items": [],
            "rubric": [f"states {ans}" if ans else "states the governing law",
                       f"first identifies {describe(d)} from its parties", cite_rubric(d, gp)],
            "notes": "two hops inside one contract: parties page -> governing-law clause"
                     + ("; gold_answer is the opening of the annotated span" if truncated else ""),
        })

    # not_in_corpus: a category CUAD marks absent -----------------------------------------------
    for cat, n in PLAN["not_in_corpus"]:
        def absent(d: Doc, cat=cat) -> bool:
            return not d.has(cat) and d.csv_answer(cat).lower() in {"no", ""} and len(d.parties) >= 1
        for d in pick(docs, absent, n):
            questions.append({
                "qid": qid(), "type": "not_in_corpus",
                "question": f"What {LABEL[cat]} clause does {describe(d)} contain? Quote the clause and cite its page.",
                "gold_docs": [], "gold_answer": f"No {LABEL[cat]} clause: CUAD annotates none in this agreement",
                "gold_items": [],
                "rubric": ["states that the agreement contains no such clause (or that none could be found)",
                           "does not quote a clause of a different category or a different agreement as the answer"],
                "notes": f"contract=<{d.stem}>; category={cat}; cuad_answer={d.csv_answer(cat) or 'none'}",
            })

    jsonl = "".join(json.dumps(q, ensure_ascii=False) + "\n" for q in questions)
    self_check(questions, corpus)
    return jsonl, questions


# --------------------------------------------------------------------------- self check


def self_check(questions: list[dict], corpus: Corpus) -> None:
    assert 80 <= len(questions) <= 150, len(questions)
    assert len({q["qid"] for q in questions}) == len(questions)
    n_nic = sum(1 for q in questions if q["type"] == "not_in_corpus")
    assert n_nic >= 0.10 * len(questions), n_nic
    for q in questions:
        if q["type"] == "not_in_corpus":
            m = re.search(r"contract=<([^>]+)>; category=([^;]+)", q["notes"])
            assert m and not corpus.by_stem[m.group(1)].has(m.group(2)), q["qid"]
            assert not q["gold_docs"]
            continue
        assert q["gold_docs"], q["qid"]
        cited = []
        for gd in q["gold_docs"]:
            d = corpus.by_stem[gd["doc_id"].strip("<>")]
            assert gd["pages"] and all(p in d.md_pages for p in gd["pages"]), (q["qid"], gd)
            cited.append(ws(d.page_text(gd["pages"])))
        joined = " \n ".join(cited)
        if q["gold_answer"]:
            assert q["gold_answer"] in joined, (q["qid"], q["gold_answer"][:80])
        for item in q["gold_items"]:
            assert item in joined, (q["qid"], item)
        assert q["rubric"], q["qid"]


def summary(questions: list[dict]) -> str:
    counts: dict[str, int] = {}
    for q in questions:
        counts[q["type"]] = counts.get(q["type"], 0) + 1
    docs_cited = {gd["doc_id"] for q in questions for gd in q["gold_docs"]}
    return f"{len(questions)} questions; by type: {dict(sorted(counts.items()))}; {len(docs_cited)} distinct gold documents"


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--check", action="store_true", help="regenerate in memory and exit 1 if the file on disk differs")
    args = ap.parse_args()
    if not ALIGNMENT.exists():
        print(f"{ALIGNMENT} missing: run scripts/make_cuad_corpus.py first", file=sys.stderr)
        return 2
    jsonl, questions = generate()
    if args.check:
        same = OUT.exists() and OUT.read_text(encoding="utf-8") == jsonl
        print("up to date" if same else f"{OUT} differs from the generator")
        return 0 if same else 1
    OUT.write_text(jsonl, encoding="utf-8", newline="\n")
    print(f"wrote {OUT}")
    print(summary(questions))
    return 0


if __name__ == "__main__":
    sys.exit(main())
