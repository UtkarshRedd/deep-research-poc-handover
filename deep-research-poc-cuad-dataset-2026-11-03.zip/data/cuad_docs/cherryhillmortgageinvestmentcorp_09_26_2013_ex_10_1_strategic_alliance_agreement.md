<!-- page 1 -->
# Strategic Alliance Agreement
| Field | Value |
|---|---|
| Document Type | Strategic Alliance Agreement |
| SEC Filing Date | 2013-09-26 |
| Parties | Freedom Mortgage Corporation ("Freedom Mortgage"); Cherry Hill Mortgage Investment Corp. ("Cherry Hill") |
| Source | CUAD v1 / CHERRYHILLMORTGAGEINVESTMENTCORP_09_26_2013-EX-10.1-Strategic Alliance Agreement |

Exhibit 10.1

Strategic Alliance Agreement

AGREEMENT made as of , 2013, between Freedom Mortgage Corporation, a New Jersey corporation
("Freedom Mortgage"), and Cherry Hill Mortgage Investment Corp., a Maryland corporation ("Cherry
Hill").

WITNESSETH:

WHEREAS, Freedom Mortgage is a privately held, national mortgage bank that originates and services
mortgage loans secured by liens on one- to four-family properties; and

WHEREAS, Cherry Hill is a newly formed affiliate of Freedom Mortgage that intends to elect and
qualify as a Real Estate Investment Trust under the Internal Revenue Code of 1986, as amended; and

WHEREAS, Cherry Hill will have access to capital, including capital raised through one or more
offerings of its securities; and

WHEREAS, Cherry Hill will seek to benefit from having a consistent and predictable source of real
estate assets from Freedom Mortgage, and Freedom Mortgage will seek to benefit from the liquidity
available to Cherry Hill; and

WHEREAS, the parties desire to set forth the terms of a strategic alliance that is expected to
benefit them both;

NOW, THEREFORE, in consideration of the foregoing, and of other good and valuable consideration, the
receipt and sufficiency of which is hereby acknowledged, the parties here to agree as follows.

Section 1. Definitions.

(a) The following terms shall have the meanings specified wherever used in this Agreement.

Acknowledgement Agreement: The Acknowledgement Agreement to be entered into by Freedom Mortgage, as
Issuer, Cherry Hill, as Secured Party, and the Government National Mortgage Association.

Action: Any civil, criminal, investigative or administrative claim, demand, action, suit, charge,
citation, complaint, notice of violation, proceeding (public or private), litigation, prosecution,
arbitration or inquiry by or before any Governmental Entity whether at law, in equity or otherwise.

Agreement: This Strategic Alliance Agreement as the same may be amended in accordance with the terms
hereof.

1
<!-- page 2 -->
Ancillary Agreements: The Acknowledgement Agreement, the Purchase Agreement and the Flow Agreement.

Base Servicing Fee: As to any Mortgage Loan and any Collection Period, an amount equal to the
product of the Base Servicing Fee Rate, the UPB of that Mortgage Loan as of the related Measurement
Date and 1/12 or, for the first Collection Period, the number of days in such Collection Period
divided by 360; provided, however, that payment of the Base Servicing Fee for any delinquent
Mortgage Loan shall be suspended unless and until Freedom Mortgage recovers the amount thereof from
payments in respect thereof from the related mortgagor or the amount thereof is otherwise recovered
from liquidation of the related property.

Base Servicing Fee Rate: As to any Mortgage Loan, the per annum rate specified to be payable to
Freedom Mortgage to cover the actual costs of servicing. For example, the Base Servicing Fee Rate
for the Mortgage Loans in the initial pool will be eight (8) basis points.

Business Day: Any day other than a Saturday or Sunday or a day on which banks in New Jersey and New
York are authorized or obligated by law to close.

Closing: The closing of the initial public offering of the common stock of Cherry Hill.

Closing Date: The date of the Closing.

Collection Period: The period beginning on the Closing Date and ending on the last day of the
calendar month in which the Closing Date occurs and each calendar month thereafter.

Excess MSR: As to any Mortgage Loan, the portion of the servicing fee for that Mortgage Loan that
exceeds the Base Servicing Fee.

Flow Agreement : The Flow and Bulk Purchase Agreement to be entered into between Cherry Hill, as
purchaser, and Freedom Mortgage, as seller, substantially in the form of Exhibit B attached hereto.

GAAP: Generally accepted accounting principles in the United States as in effect from time to time
as set forth in the statements, pronouncements and opinions of the Accounting Principles Board and
the American Institute of Certified Public Accountants.

Ginnie Mae: The Government National Mortgage Association, a corporation within the United States
Department of Housing and Urban Development.

Governmental Entity: Any federal, state or local governmental authority, agency, commission or court
or self-regulatory authority or commission.

Guide: The Ginnie Mae Mortgage Backed Securities Guide.

Law: Any law, statute, ordinance, rule, regulation, code, Permit, Order, or decree of any
Governmental Entity.

2
<!-- page 3 -->
Lien: Any lien, pledge, security interest, mortgage, deed of trust, claim, encumbrance, easement,
servitude, encroachment, covenant, charge or similar right of any other Person of any kind or nature
whatsoever.

Material Adverse Effect: Any effect, event, circumstance, development or change that, individually
or in the aggregate, has or is reasonably likely to have a material adverse effect on the ability of
the named Party to consummate the Transactions or perform its material obligations hereunder.

Measurement Date: As to any Collection Period, the first day of such Collection Period.

Mortgage Loan: A loan originated and serviced by Freedom Mortgage and secured by a first lien on a
one- to four- family residential property.

MSR: The compensation owing to a servicer of a Mortgage Loan for servicing such loan.

Order: Any applicable order, judgment, ruling, injunction, assessment, award, decree, writ,
temporary restraining order, or any other order of any nature enacted, issued, promulgated, enforced
or entered by a Governmental Entity.

Party: Either Freedom Mortgage or Cherry Hill, as the context may require.

Permit: Any license, permit, authorization, approval or consent issued by a Governmental Entity.

Person: Any individual, corporation (including any non-profit corporation), general or limited
partnership, limited liability company, limited liability partnership, joint venture, estate, trust,
unincorporated organization, association, organization or other entity or form of business
enterprise or Governmental Entity.

Purchase Agreement: The Excess MSR Acquisition and Recapture Agreement to be entered into by Cherry
Hill, as purchaser, and Freedom Mortgage, as seller, substantially in the form of Exhibit A attached
hereto.

Standby Trigger Event: The existence of any of the following: (i) Freedom Mortgage's Tangible Net
Worth is less than the sum of $40,000,000 plus the required net worth determined in accordance with
HUD's regulations; (ii) the percentage of the loans serviced for Ginnie Mae that are more than 90
days delinquent, determined as provided in the Ginnie Mae guide, exceeds 4.25% as of any date such
delinquency percentage is reported to Ginnie Mae in accordance with that guide; (iii) the existence
of a default, an event of default or an event which with the giving of notice or the passage of time
or both, will become a default or an event of default under any warehouse agreement of Freedom
Mortgage; or (iv) Freedom Mortgage's cash and cash equivalents are less than $50,000,000.

3
<!-- page 4 -->
Tangible Net Worth: The net worth of Seller determined in accordance with GAAP, minus all
intangibles determined in accordance with GAAP (including goodwill, capitalized financing costs and
capitalized administration costs but excluding originated and purchased mortgage servicing rights or
retained residual securities) and any and all advances to, investments in and receivables held from
affiliates; provided, however, that the non­cash effect (gain or loss) of any mark­to­market
adjustments made directly to stockholders' equity for fluctuation of the value of financial
instruments as mandated under the Statement of Financial Accounting Standards No. 133 (or any
successor statement) shall be excluded from the calculation of Tangible Net Worth.

Transactions: The execution, delivery and performance of this Agreement and the Ancillary Agreements
and the performance of the other obligations set forth herein and therein.

UPB: As to any Mortgage Loan and any date of determination, the unpaid principal balance of such
Mortgage Loan as of such date.

(b) When a reference is made in this Agreement to Sections or Exhibits, such reference shall be to a
Section of or Exhibit to this Agreement unless otherwise indicated. Whenever the words "herein" or
"hereunder" are used in this Agreement, they will be deemed to refer to this Agreement as a whole
and not to any specific Section. References to Sections include subsections which are part of the
related Section. Any Law defined herein will mean such Law as amended and will include any successor
Law. The table of contents, index and headings contained in this Agreement are for reference
purposes only and shall not affect in any way the meaning or interpretation of this Agreement.
Whenever the words "include", "includes" or "including" are used in this Agreement, they shall be
deemed to be followed by the words "without limitation". Any singular term in this Agreement will be
deemed to include the plural, and any plural term the singular. All pronouns and variations of
pronouns will be deemed to refer to the feminine, masculine or neuter, singular or plural, as the
identity of the person referred to may require. The phrases "the date of this Agreement", "the date
hereof' and terms of similar import, unless the context otherwise requires, shall be deemed to refer
to the date set forth in the preamble to this Agreement. Whenever a dollar figure ($) is used in
this Agreement, it will mean United States dollars unless otherwise specified.

Section 2. The Acknowledgement Agreement

(a) Prior to the purchase and sale of Excess MSRs as contemplated by the Purchase Agreement, Freedom
Mortgage and Cherry Hill shall execute the Acknowledgement Agreement with Ginnie Mae.

(b) Freedom Mortgage agrees that if a Standby Issuer (as defined in the Acknowledgement Agreement)
has not yet been appointed, upon the occurrence of a Standby Trigger Event, it shall designate a
Standby Issuer reasonably satisfactory to Cherry Hill and shall use its commercially reasonable
efforts to cause such Standby Issuer to agree to act as such and to be accepted by Ginnie Mae as the
Standby Issuer referred to in the Acknowledgement Agreement. Any costs or expenses incurred in
connection with such designation, agreement and/or approval shall be paid by Freedom Mortgage.

(c) Cherry Hill agrees that upon the request of Freedom Mortgage, Cherry Hill shall cooperate with
Freedom Mortgage's efforts to cause the Acknowledgement Agreement to be revised or replaced with an
alternative arrangement proposed by Freedom Mortgage that is acceptable to Ginnie Mae and that will
provide Cherry Hill with benefits, rights and remedies that are, in the reasonable judgment of
Cherry Hill, not materially less favorable than those provided under the Acknowledgement Agreement.

4
<!-- page 5 -->
(d) The Purchase Agreement will provide that Freedom Mortgage will indemnify Cherry Hill against,
and hold it harmless from, any loss, cost or expense incurred by Cherry Hill as a result of Ginnie
Mae's termination for cause of Freedom Mortgage as an issuer.

Section 3. Ancillary Agreements.

On or prior to the Closing Date, Cherry Hill and Freedom Mortgage shall enter into the Purchase
Agreement and the Flow Agreement.

Section 4. Representations and Warranties.

(a) Freedom Mortgage represents and warrants to Cherry Hill that the statements contained in this
Section 4(a) are true and correct in all material respects as of the date of this Agreement (or, if
made as of a different specified date, as of such date) and will be true and correct in all material
respects as of the Closing Date (as though made then and as though the Closing Date were substituted
for the date of this Agreement throughout this Section 4(a)).

(i) Freedom Mortgage is duly organized and validly existing and in good standing under the laws of
the jurisdiction of its organization. Freedom Mortgage has all requisite corporate power and
authority to own, lease and operate its assets and carry on its business as now conducted. Freedom
Mortgage is duly licensed or qualified to do business in each jurisdiction where its ownership or
leasing of assets or the conduct of its business requires such qualification, except where the
failure to obtain such license or qualification would not reasonably be expected to have a Material
Adverse Effect.

(ii) Freedom Mortgage has full corporate power and authority to execute and deliver this Agreement
and the Ancillary Agreements and to consummate the Transactions. The execution and delivery of this
Agreement by Freedom Mortgage and the completion by Freedom Mortgage of the Transactions have been
duly and validly authorized by all necessary corporate action of Freedom Mortgage. This Agreement
has been duly and validly executed and delivered by Freedom Mortgage and constitutes the valid and
binding obligation of Freedom Mortgage, enforceable against Freedom Mortgage in accordance with its
terms, subject to applicable bankruptcy, insolvency and similar Laws affecting creditors' rights
generally, and subject, as to enforceability, to general principles of equity, whether applied in a
court of law or a court of equity.

(iii) The execution and delivery of this Agreement and the consummation of the Transactions and
compliance by Freedom Mortgage with any of the terms or provisions hereof will not: (i) conflict
with or result in a breach or violation of or a default under any provision of the organizational
documents of Freedom Mortgage; (ii) violate any Law applicable to Freedom Mortgage or any of its
material properties or assets or enable any Person to enjoin the Transactions; or (iii) violate,
conflict with, result

5
<!-- page 6 -->
in a breach of any provisions of, constitute a default (or an event which, with notice or lapse of
time, or both, would constitute a default) under, result in the termination of, accelerate the
performance required by, or result in a right of termination or acceleration or the creation of any
Lien upon any of the properties or assets of Freedom Mortgage under any of the terms, conditions or
provisions of any material contract to which Freedom Mortgage is a party, or by which it or any of
its properties or assets may be bound or affected.

(iv) No consents, waivers or approvals of, or filings or registrations with, any Governmental Entity
are necessary, and no consents, waivers or approvals of, or filings or registrations by Freedom
Mortgage with, any other third parties are necessary, in connection with the execution and delivery
of this Agreement by Freedom Mortgage, and the completion by Freedom Mortgage of the Transactions.

(v) Freedom Mortgage has all Permits of, and has made all filings, applications and registrations
with, all Governmental Entities that are required in order for it to consummate the Transactions;
all such Permits are in full force and effect and, to the knowledge of Freedom Mortgage, no
suspension or cancellation of any such Permit is threatened or will result from the consummation of
the Transactions.

(vi) Freedom Mortgage is not a party to any, nor are there pending, or to Freedom Mortgage's
knowledge, threatened Actions (i) challenging the validity or propriety of any of the Transactions
or (ii) which could materially and adversely affect the ability of Freedom Mortgage to perform under
this Agreement or any Ancillary Agreement.

(b) Cherry Hill represents and warrants to Freedom Mortgage that the statements contained in this
Section 4(b) are true and correct in all material respects as of the date of this Agreement (or, if
made as of a different specified date, as of such date) and will be true and correct in all material
respects as of the Closing Date (as though made then and as though the Closing Date were substituted
for the date of this Agreement throughout this Section 4(b)) and as of the date of any purchase and
sale of Excess MSRs as contemplated hereby.

(i) Cherry Hill is duly organized and validly existing and in good standing under the laws of the
jurisdiction of its organization. Cherry Hill has all requisite corporate power and authority to
own, lease and operate its assets and carry on its business as now conducted. Cherry Hill is duly
licensed or qualified to do business in each jurisdiction where its ownership or leasing of assets
or the conduct of its business requires such qualification, except where the failure to obtain such
license or qualification would not reasonably be expected to have a Material Adverse Effect.

(ii) Cherry Hill has full corporate power and authority to execute and deliver this Agreement and
the Ancillary Agreements and to consummate the Transactions. The execution and delivery of this
Agreement by Cherry Hill and the completion by Cherry Hill of the Transactions have been duly and
validly authorized by all necessary corporate action of Cherry Hill. This Agreement has been duly
and validly executed and delivered by Cherry Hill and constitutes the valid and binding obligation
of Cherry Hill, enforceable against Cherry Hill in accordance with its terms, subject to applicable
bankruptcy, insolvency and similar Laws affecting creditors' rights generally, and subject, as to
enforceability, to general principles of equity, whether applied in a court of law or a court of
equity.

6
<!-- page 7 -->
(iii) The execution and delivery of this Agreement and the consummation of the Transactions and
compliance by Cherry Hill with any of the terms or provisions hereof will not: (i) conflict with or
result in a breach or violation of or a default under any provision of the organizational documents
of Cherry Hill; (ii) violate any Law applicable to Cherry Hill or any of its material properties or
assets or enable any Person to enjoin the Transactions; or (iii) violate, conflict with, result in a
breach of any provisions of, constitute a default (or an event which, with notice or lapse of time,
or both, would constitute a default) under, result in the termination of, accelerate the performance
required by, or result in a right of termination or acceleration or the creation of any Lien upon
any of the properties or assets of Cherry Hill under any of the terms, conditions or provisions of
any material contract to which Cherry Hill is a party, or by which it or any of its properties or
assets may be bound or affected.

(iv) No consents, waivers or approvals of, or filings or registrations with, any Governmental Entity
are necessary, and no consents, waivers or approvals of, or filings or registrations by Cherry Hill
with, any other third parties are necessary, in connection with the execution and delivery of this
Agreement by Cherry Hill, and the completion by Cherry Hill of the Transactions.

(v) Cherry Hill has all Permits of, and has made all filings, applications and registrations with,
all Governmental Entities that are required in order for it to consummate the Transactions; all such
Permits are in full force and effect and, to the knowledge of Cherry Hill, no suspension or
cancellation of any such Permit is threatened or will result from the consummation of the
Transactions.

(vi) Cherry Hill is not a party to any, nor are there pending, or to Cherry Hill's knowledge,
threatened Actions (i) challenging the validity or propriety of any of the Transactions or (ii)
which could materially and adversely affect the ability of Cherry Hill to perform under this
Agreement.

Section 5. Term and Termination.

(a) Unless earlier terminated as provided below, this Agreement shall remain in effect until the
later to occur of the date that is (x) three (3) years from the date hereof and (y) the date on
which an affiliate of Freedom Mortgage is not acting as the external manager of Cherry Hill.

(b) In the event that a party materially breaches any representation or covenant herein, the other
party may give written notice of the breach requiring the same to be remedied within 30 days of
receipt of such notice. If the breaching party fails to remedy the material breach in such time
period, the non-breaching party may terminate this Agreement by delivery of a written termination
notice to the breaching party. Any such termination shall not relieve the breaching party from any
obligation or liability arising prior to such termination.

7
<!-- page 8 -->
Section 6. Miscellaneous.

(a) All notices or other communications hereunder shall be in writing and shall be deemed given if
delivered by receipted hand delivery or mailed by prepaid registered or certified mail (return
receipt requested) or by recognized overnight courier addressed as follows:

If to Freedom Mortgage to:

Freedom Mortgage Company 907 Pleasant Valley Ave., Suite 3 Mount Laurel, New Jersey 08054 Attention:
Chief Corporate Counsel

If to Cherry Hill to:

Cherry Hill Mortgage Investment Corp. 301 Harper Drive Moorestown, New Jersey 08057 Attention: Chief
Financial Officer

or such other address as shall be furnished in writing by any Party. Any such notice or
communication shall be deemed to have been given: (i) as of the date delivered by hand; (ii) three
(3) Business Days after being delivered to the U.S. mail, postage prepaid; or (iii) one (1) Business
Day after being delivered to the overnight courier.

(b) This Agreement shall be binding upon and shall inure to the benefit of the Parties and their
respective successors and permitted assigns; provided, however, that neither this Agreement nor any
of the rights, interests or obligations hereunder shall be assigned by any Party without the prior
written consent of the other Party. Nothing in this Agreement is intended to confer upon any other
Person any rights or remedies under or by reason of this Agreement.

(c) This Agreement, including the Exhibits and Schedules hereto and the documents and other writings
referred to herein or therein or delivered pursuant hereto, contains the entire agreement and
understanding of the Parties with respect to its subject matter. There are no restrictions,
agreements, promises, warranties, covenants or undertakings between the Parties other than those
expressly set forth herein or therein. This Agreement supersedes all prior agreements and
understandings between the Parties, both written and oral, with respect to its subject matter.

(d) This Agreement may be executed in two or more counterparts, including by facsimile or electronic
transmission, each of which shall be deemed an original but all of such counterparts together shall
be deemed to be one and the same agreement.

(e) In the event that any one or more provisions of this Agreement shall for any reason be held
invalid, illegal or unenforceable in any respect, by any court of competent jurisdiction, such
invalidity, illegality or unenforceability shall not affect any other provisions of this Agreement
and the Parties shall use their reasonable efforts to substitute a valid, legal and enforceable
provision which, insofar as practical, implements the purposes and intents of this Agreement.

8
<!-- page 9 -->
(f) The Parties may (i) amend this Agreement, (ii) extend the time for the performance of any of the
obligations or other acts of any other Party, (iii) waive any inaccuracies in the representations
and warranties contained herein or in any document delivered pursuant hereto, or (iv) waive
compliance with any of the agreements or conditions contained herein. This Agreement may not be
amended except by an instrument in writing signed on behalf of each of the Parties. Any agreement on
the part of a Party to any extension or waiver shall be valid only if set forth in an instrument in
writing signed on behalf of such Party, but such waiver or failure to insist on strict compliance
with such obligation, covenant, agreement or condition shall not operate as a waiver of, or estoppel
with respect to, any subsequent or other failure.

(g) This Agreement shall be governed by the laws of the State of New York, without giving effect to
its principles of conflicts of laws, other than Section 5-1401 of the New York General Obligations
Law.

(h) Each Party irrevocably submits to the jurisdiction, including the personal jurisdiction, of (i)
any New York State court sitting in New York County, and (ii) any Federal court of the United States
sitting in New York County in the State of New York, solely for the purposes of any suit, action or
other proceeding between any of the Parties arising out of this Agreement or the Transactions. Each
Party agrees to commence any suit, action or proceeding relating hereto only in any Federal court of
the United States sitting in New York County in the State of New York or, if such suit, action or
other proceeding may not be brought in such court for reasons of subject matter jurisdiction, in any
New York State court sitting in New York County. Each Party irrevocably and unconditionally waives
any objection to the laying of venue of any suit, action or proceeding between any of the Parties
arising out of this Agreement or the Transactions in (i) any New York State court sitting in New
York County, and (ii) any Federal court of the United States sitting in New York County in the State
of New York, and hereby further irrevocably and unconditionally waives and agrees not to plead or
claim in any such court that any such suit, action or proceeding brought in any such court has been
brought in an inconvenient forum. Each Party irrevocably agrees to request that the applicable court
adjudicate any covered claim on an expedited basis and to cooperate with each other to assure that
an expedited resolution of any such dispute is achieved. Each Party irrevocably agrees to abide by
the rules or procedure applied by the Federal courts or New York State courts (as the case may be)
(including but not limited to procedures for expedited pre-trial discovery) and waive any objection
to any such procedure on the ground that such procedure would not be permitted in the courts of some
other jurisdiction or would be contrary to the laws of some other jurisdiction. Each Party further
irrevocably consents to the service of process out of any of the aforementioned courts in any such
suit, action or other proceeding by the mailing of copies thereof by registered mail to such Party
at its address set forth in this Agreement, such service of process to be effective upon
acknowledgment of receipt of such registered mail; provided, that nothing in this Section 6(h) shall
affect the right of any Party to serve legal process in any other manner permitted by Law.

(i) The Parties agree that irreparable damage would occur in the event that the provisions contained
in this Agreement were not performed in accordance with its specific terms or were otherwise
breached. It is accordingly agreed that the Parties shall be entitled to an injunction or
injunctions to prevent breaches of this Agreement and to enforce specifically the terms and
provisions hereof in any court of the United States or any state having jurisdiction, this being in
addition to any other remedy to which they are entitled at law or in equity.

9
<!-- page 10 -->
(j) FREEDOM MORTGAGE AND CHERRY HILL HEREBY IRREVOCABLY WAIVE, TO THE FULLEST EXTENT PERMITTED BY
APPLICABLE LAW, ANY AND ALL RIGHT TO TRIAL BY JURY IN ANY LEGAL PROCEEDING ARISING OUT OF OR
RELATING TO THIS AGREEMENT, ANY OTHER TRANSACTION DOCUMENT OR THE TRANSACTIONS CONTEMPLATED HEREBY
OR THEREBY.

[The remainder of this page left blank intentionally]

10
<!-- page 11 -->
IN WITNESS WHEREOF, the parties hereto have executed this Agreement as of the date first
above-written.

FREEDOM MORTGAGE CORPORATION

By:

Name: Title:

CHERRY HILL MORTGAGE INVESTMENT CORP.

By:

Name: Title:
