"""Load parsed markdown documents (+ metadata) into DocRecords.

Expected layout (adapt `glob` to yours):
    data/parsed/<name>.md            markdown with '<!-- page N -->' markers
    data/parsed/<name>.meta.json     optional sidecar {title, doc_type, date, parties, ...}

If no sidecar exists, metadata is parsed from the first ~2 pages via dr.ingest.metadata.
"""
from __future__ import annotations

import json
import re
from pathlib import Path

from ..config import DEFAULT, Config
from ..models import DocRecord
from .metadata import parse_metadata_block


def load_dir(root: Path, glob: str = "*.md", config: Config = DEFAULT, require_page_markers: bool = True) -> list[DocRecord]:
    page_re = re.compile(config.PAGE_MARKER_RE, re.MULTILINE)
    docs: list[DocRecord] = []
    missing_markers: list[str] = []
    for p in sorted(Path(root).glob(glob)):
        text = p.read_text(encoding="utf-8", errors="replace")
        if not page_re.search(text):
            missing_markers.append(p.name)
        side = p.with_suffix(".meta.json")
        meta: dict[str, str] = {}
        if side.exists():
            meta = {k: str(v) for k, v in json.loads(side.read_text(encoding="utf-8")).items()}
        else:
            meta = parse_metadata_block(text, max_pages=2)
        title = meta.get("title") or p.stem
        docs.append(DocRecord(doc_id=DocRecord.make_id(str(p), text), title=title, text=text,
                              source_path=str(p), metadata=meta))
    if missing_markers and require_page_markers:
        raise ValueError(
            f"{len(missing_markers)} documents lack '<!-- page N -->' markers (e.g. {missing_markers[:3]}). "
            "Run dr.ingest.pages to derive them from the PDFs, or pass require_page_markers=False "
            "(citations will then be line-based only)."
        )
    return dedupe(docs)


def dedupe(docs: list[DocRecord]) -> list[DocRecord]:
    """Content-hash dedupe (exact). Near-duplicate clustering is Phase 7 (provenance)."""
    seen: set[str] = set()
    out = []
    for d in docs:
        h = DocRecord.make_id("", d.text)
        if h in seen:
            continue
        seen.add(h)
        out.append(d)
    return out
