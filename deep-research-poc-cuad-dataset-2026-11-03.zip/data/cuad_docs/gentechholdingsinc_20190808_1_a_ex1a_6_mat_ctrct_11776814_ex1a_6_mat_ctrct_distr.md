<!-- page 1 -->
# DISTRIBUTOR AGREEMENT
| Field | Value |
|---|---|
| Document Type | Distributor Agreement |
| Agreement Date | 2019-08-01 |
| Parties | B & C General Warehouse Corporation LLC ("Company"); XXXXXXXXXXXXXXXXXXXXX ("Distributor") |
| Source | CUAD v1 / GentechHoldingsInc_20190808_1-A_EX1A-6 MAT CTRCT_11776814_EX1A-6 MAT CTRCT_Distributor Agreement |

Exhibit 6.1 DISTRIBUTOR AGREEMENT THIS DISTRIBUTOR AGREEMENT (this "Agreement") is made and
effective as of1 August 2019, by and between, B & C General Warehouse Corporation LLC , a USA
Limited Liability Company (LLC), with an address located at 7405 SW 11th CT, North Lauderdale, FL,
33068, USA, ("Company"), and XXXXXXXXXXXXXXXXXXXXX ("Distributor"). Company Import the products from
Brazil Farm origin (Arte Café - Prescafe Torrefação e Comercio de Cafe, a Brazil company, with an
address located at 1 Fazenda Sao Gabriel, Guaxupé, Cep 37800-000, Minas Gerais, Brazil), and sells
the products listed in Section 1.c below (the "Products"). Distributor desires to purchase the
Products from Company for resale in the territories or geographic areas as defined in Section 1.b
(the "Territory"). Company desires to appoint Distributor as its exclusive distributor of the
Products to all Clients that Distributor introduce, and upon confirmed the first order, this client
come to be exclusive of Distributor, every new customer introduced by Distributor, must be approved
by the company prior to any sale. After official approval from the Company, the customer introduced
by Distributor, will appear on an official list in this contract, and will only be met by the
Distributor and will follow the rules of this agreement. Distributor desires such appointment
subject to the terms and conditions set forth in this Agreement, including any exhibits or schedules
attached hereto. Now, Therefore, in consideration of the foregoing, and of the mutual benefit
contained herein, the Parties, intending to be legally bound, agree as follows: AGREEMENT OF THE
PARTIES 1. APPOINTMENT, ACCEPTANCE & SCOPE. (a) Exclusive Appointment. Subject to the terms and
conditions of this Distributor Agreement, Company hereby appoints and grants Distributor the
exclusive right to sell and distribute the Products to customers that Distributor introduce and
confirmed by Company, (in all territory of United State of America (USA) and to render other
services as a distributor for Company as set forth herein. Distributor shall limit its activities
with respect to the Products to Customers located within the Territory and refrain from selling or
otherwise transferring, directly or indirectly, the Products to any person outside the Territory,
without the express written consent of Company. Company shall not sell or otherwise supply, directly
or indirectly, the Products to any Distributor's Customer's, except by sale through the Distributor.
The Company shall not contact any of Distributor's Customer's for any reason, without the prior
written approval of Distributor.

Source: GENTECH HOLDINGS, INC., 1-A, 8/8/2019
<!-- page 2 -->
(b) Territory. The rights granted Distributor hereunder are granted for the following geographical
areas and markets. USA. (c) Products. The Products manufactured and sold by Company to Distributor
for distribution hereunder are as follows: ● Arte Café Especial ● Arte Café Gourmet ● Arte Café
Laurina ● Arte Café Organico ● And all another new brand and or kind of coffee. (d) Subagents.
Distributor may appoint, with prior approval of the Company, sub-agents, sub-distributors,
sub-representatives or other persons to act on Distributor's behalf or to otherwise perform any of
Distributor's obligations under this Agreement within the Territory; provided that (i) any
compensation to such sub-agent, sub-distributor, sub-representative or other person to act on
Distributor's behalf or to otherwise perform any of Distributor's obligations shall be solely
Distributor's responsibility, and (ii) such appointment does not deprive Company of the essential
rights to which it is entitled under this Agreement. Any agreement with such sub-agent,
sub-distributor, sub-representative or other person shall not extend beyond the term of this
Agreement.

2

Source: GENTECH HOLDINGS, INC., 1-A, 8/8/2019
<!-- page 3 -->
(e) Relationship of Parties. Distributor is an independent contractor and is not and shall not be
deemed to be an employee, legal representative, dealer, general agent, joint venture or partner of
Company for any purpose. Distributor acknowledges that Company has not granted it any authority to
make changes to Company's terms and conditions of sale, grant any warranties in excess of those
extended by Company or limit its liabilities or remedies less than Company limits its liabilities
and remedies, sign quotations, incur obligations (expressed or implied), or in general enter into
contracts on behalf of Company or bind Company in any transaction with customers, governmental
agencies or third parties. 2. ORDERS, PRICE, TERMS OF SALE & PAYMENT. (a) Communications Pursuant to
this Distributor Agreement and Orders. Orders shall be made with Company. Company understands that
its timely acceptance of orders from Distributor hereunder is an important element of this
Agreement. Company shall have Seven (7) business days after its receipt to accept (or reject for a
legitimate business reason) any order submitted by Distributor. All the negotiations between Company
and Distributor will be by INCOTERMS Ex-works, in origin farm, in Brazil. So will must be respected
the Transite Time to destiny delivery. Should Company fail to timely accept or reject an order from
Distributor in accordance with this Section, such order shall be deemed accepted and shall become
binding on Company. All orders shall be fulfilled by Company within Seven (7) business days of order
acceptance. (b) Prices and Shipment. Company agrees to sell, and Distributor agrees to purchase, the
Products in accordance with the Prices and Volume Discount Prices set forth in Schedule A. Such
Prices and Volume Discount Prices shall only be subject to increase once per year on each
anniversary date of this Agreement, provided (i) Company provides Distributor with at least Ninety
(90) days prior written notice of any such increase, and (ii) such increase does not exceed 5% of
the preceding year's Prices, except for reasons of force majeure, (Chapter 10), and Volume Discount
Prices nor the lowest price charged to others for the same Product. Any such change shall not apply
for any order(s) accepted prior to the effective date of the increase.

3

Source: GENTECH HOLDINGS, INC., 1-A, 8/8/2019
<!-- page 4 -->
(c) Company shall package the Products for shipment in accordance with Distributor's instructions.
All shipments of Products for Customers in the Territory, and any freight and shipping costs related
thereto, will be Distributor's responsibility. All shipments will be prepared and shipped from
Company's facility. Distributor will promptly inspect the Products upon receipt at Distributor's
facility to determine whether any Products included in the shipment are in short supply, defective,
or otherwise not in conformance with this Agreement. Within Seven (7) days of receipt of such
Products, Distributor will notify Company of any shortages, defects, non-conformance, and Company
will promptly replace such Products free of charge. Title to the Products shall pass to Distributor
upon delivery. (d) Terms of Sale. All sales by Company shall be in accordance with the terms and
conditions of this Agreement. (e) Payment. Upon Customer's acceptance of any order, Distributor
shall submit to Customer via wire transfer at least Twenty-Five Percent (25%) of the total order
price. Distributor shall submit to Customer via wire transfer the remaining balance upon receipt
Packing List and Bill of landing documents, from origin in Brazil Farm. (f) Resale of the Products.
Distributor shall be free to resell the Products for such prices and upon such terms and conditions
as Distributor may see fit in its sole discretion. Company shall have no control over or any
liability in connection with the price at which Distributor resells the Products, and Distributor
shall hold Company harmless and indemnify and defend Company from and against any liability
resulting therefrom. 3. REPRESENTATIONS. The Distributor and Company, as applicable, make the
following representations, warranties and covenants: (a) Distributor is a company duly organized,
validly existing and in good standing in the United States of America (USA) , is qualified to do
business and in good standing in each jurisdiction located within the Territory and is and will
remain in compliance with all applicable laws and regulations in the conduct of its business and,
specifically, in its sale of the Products and provision of any services hereunder.

4

Source: GENTECH HOLDINGS, INC., 1-A, 8/8/2019
<!-- page 5 -->
(b) Company is a corporation, duly organized, validly existing and in good standing in the State of
Florida, and is and will remain in compliance with all applicable laws and regulations in the
conduct of its business and, specifically, in its sale of the Products. (c) Company warrants and
represents that the Products will be free from defects in design, materials and workmanship and
conform with any specifications provided. (d) Company has all rights, power, and authority to enter
into this Agreement. (e) Company's execution of this Distributor Agreement, and Company's
performance of its obligations and duties hereunder, do not and will not violate any agreement to
which Company is a party or by which it is otherwise bound, and (f) Neither Party is subject to any
pending or threatened litigation or governmental action that could interfere with its performance of
this Agreement. (g) This Agreement is the binding legal obligation of each Party and is enforceable
in accordance with its terms. 4. RESPONSIBILITIES OF DISTRIBUTOR. Distributor agrees that it will
diligently perform the services and obligations detailed in this Agreement. The operations of
Distributor are under its sole and exclusive control, including without limitation supervision of,
and liability for expenses incurred with respect to, employees. The Distributor will use best
reasonable efforts to distribute the Products in the Territory. 5. RESPONSIBILITIES OF COMPANY. In
addition to any other responsibilities stated in this Agreement, Company will: (a) Provide, at
Distributor's reasonable request and without charge, up to 10 hours of training with regard to any
characteristics of the Products that Distributor deems reasonably necessary for Distributor and its
employees and agents to fulfill the purposes of Distributor's appointment,

5

Source: GENTECH HOLDINGS, INC., 1-A, 8/8/2019
<!-- page 6 -->
(b) provide to Distributor, without charge, reasonable quantities of promotional literature,
brochures and commercial and technical information regarding the Products; (c) provide sales support
and technical training to Distributor and its personnel as deemed reasonably appropriate by Company.
6. CONFIDENTIAL & PROPRIETARY INFORMATION. (a) As used herein, the term "Proprietary Information"
means any information, technical data, or know-how (including, but not limited to, information
relating to products, software, services, development, inventions, processes, techniques, customers,
pricing, internal procedures, business and marketing plans or strategies, finances, employees and
business opportunities) disclosed by one Party (the "Disclosing Party") to the other (the "Recipient
Party") either directly or indirectly in any form whatsoever, including, but not limited to, in
writing, in machine readable or other tangible form, orally or visually. (b) Unless otherwise
expressly authorized by the Disclosing Party, the Recipient Party agrees that it and any of its
personnel receiving Proprietary Information under this Agreement shall treat such Proprietary
Information in strict confidence with the same degree of care applied to its own Proprietary
Information of like importance, which it does not wish to disclose, publish, or disseminate to third
parties. (c) In no event will the Recipient Party divulge, in whole or in part, such information to
any third party without the prior written consent of the Disclosing Party; provided, further, that
any third party must also agree in writing to restrictions comparable to those provided in this
Section 6. The Recipient Party may disclose the Proprietary Information to the extent required by a
valid order by a court or other governmental body or by applicable law; provided, however, that the
Recipient Party will use all reasonable efforts to notify Disclosing Party of the obligation to make
such disclosure in advance of the disclosure so that Disclosing Party will have a reasonable
opportunity to object to such disclosure.

6

Source: GENTECH HOLDINGS, INC., 1-A, 8/8/2019
<!-- page 7 -->
(d) Notwithstanding any other provisions of this Agreement, each party acknowledges that Proprietary
Information shall not include any information that: (i) is already known to the Recipient Party at
the time of disclosure, or becomes publicly known through no wrongful act of the Recipient Party's
part; (ii) is rightfully received by the Recipient Party from a third party without breach of this
Agreement; (iii) is independently developed by the Recipient Party without benefit of information
received under this Agreement; (iv) is furnished to a third party by the Disclosing Party without a
restriction on the third party's right to disclose it; or (v) is explicitly approved for release by
written authorization by the Disclosing Party. (e) It is understood that all Proprietary Information
disclosed under this Agreement, is, and shall remain, the property of the Disclosing Party. Upon
completion of this Agreement, or upon written notice from the Disclosing Party, the Recipient Party
agrees to return all Proprietary Information in its possession. (f) The Recipient Party acknowledges
that the Disclosing Party, because of the unique nature of the Proprietary Information, would suffer
irreparable harm in the event that the Recipient Party breaches its obligation under this Agreement
and that monetary damages would be inadequate to compensate the Disclosing Party for such a breach.
The Parties agree that, in such a circumstance, the Disclosing Party shall be entitled, in addition
to such monetary relief as may be applicable, to injunctive relief as may be necessary to restrain
any continuing or further breach by the Recipient Party, without showing or proving any actual
damages sustained by the Disclosing Party. (g) The obligations of the Recipient Party under this
Section 6 shall survive termination or nonrenewal of this Agreement for a period of thee (3) years.
For the avoidance of doubt, the customer and sub-distributor lists of Distributor shall be deemed to
constitute Proprietary Information under this agreement.

7

Source: GENTECH HOLDINGS, INC., 1-A, 8/8/2019
<!-- page 8 -->
7. DURATION & TERMINATION. (a) Effective Date and Duration. This Agreement shall become effective on
the date first written above and shall continue in effect for a period of Three (3) years. (b)
Distributor Option to Renew. Distributor shall have the option to renew this Agreement for an
additional Three (3) year period by providing prior written notice to Company within Ninety (90)
days of the end of the initial period of this Agreement. (c) Termination. Either Party may terminate
this Agreement prior to its expiration upon the occurrence of either of the following: (i) the other
Party becomes insolvent, or institutes (or there is instituted against it) proceedings in
bankruptcy, insolvency, reorganization or dissolution, makes an assignment for the benefit of
creditors or becomes nationalized or has any of its material assets confiscated or expropriated; or
(ii) the other Party (in this case, the "breaching Party") fails to perform any of its obligations
hereunder and fails to correct such failure within Ninety (90) calendar days after receiving written
demand therefore from the non-breaching Party, specifying the failure in sufficient detail for the
breaching Party to correct such failure; provided, however, that upon a second breach of the same
obligation by such Party, the other Party may forthwith terminate this Agreement upon notice to the
breaching Party. 8. RIGHTS OF PARTIES AT TERMINATION. (a) Obligations After Termination. In the
event that this Agreement is terminated or expires on its own terms, Company shall have no further
responsibilities to Distributor except that in the event the Agreement terminates for any reason
other than a breach hereof by Distributor, Company shall be obligated to process orders accepted by
Company prior to the effective date of such termination or expiration or within Ninety (90) days
thereafter. (b) Survival. Notwithstanding anything to the contrary set forth herein, no termination
of this Agreement shall relieve any Party from any obligations hereunder which are outstanding on,
or relate to matters or claims occurring or arising prior to, the date of such termination or which
survive such termination by their own terms or nature.

8

Source: GENTECH HOLDINGS, INC., 1-A, 8/8/2019
<!-- page 9 -->
9. INDEMNIFICATION & LIMITATION OF LIABILITY. (a) Indemnification. Each Party ("Indemnifying Party")
shall indemnify, hold harmless and defend the other Party ("Indemnified Party") and its officers,
directors, agents, employees, and affiliates, from and against any and all claims, demands, actions,
costs, expenses, liabilities, judgments, causes of action, proceedings, suits, losses and damages of
any nature, which are threatened or brought against, or are suffered or incurred by, the Indemnified
Party or any such person to the extent caused directly by acts or omissions of the Indemnifying
Party relating to this Agreement, including without limitation (i) any negligent or tortious
conduct, (ii) any breach of any of the representations, warranties, covenants or conditions of the
Indemnifying Party contained in this Agreement, (iii) any violation of applicable laws or
regulations, (iv) infringement or violation of any patent, copyright, trade secret, or other
proprietary interest of any third party, and (v) any breach of any express or implied warranties
relating to the Products, including implied warranties of merchantability and fitness for a
particular purpose. (b) Limitation of Liability.IN NO EVENT SHALL EITHER PARTY BE LIABLE TO THE
OTHER FOR ANY SPECIAL, INDIRECT, EXEMPLARY OR CONSEQUENTIAL DAMAGES ARISING OUT OF THIS AGREEMENT OR
PURCHASE OR USE OF THE PRODUCTS. 10. FORCE MAJEURE. Neither Party shall be held liable for any
failure to perform that is due to any cause or circumstance beyond the reasonable control of such
Party, including without limitation a demand for such Products and other products manufactured by
Company which exceeds Company's ability to supply them, earthquakes, fire, accidents, floods,
storms, other Acts of God, riots, wars, rebellions, strikes, lockouts or other labor disturbances,
national or international emergencies, failure to secure materials or equipment from usual sources
of supply, failure of carriers to furnish transportation, government rules, regulations, acts,
orders, world financial crisis, restrictions or requirements or any other cause or circumstance
beyond the reasonable control of such Party. No such inability to deliver or delay in delivery shall
invalidate the remainder of this Agreement.

9

Source: GENTECH HOLDINGS, INC., 1-A, 8/8/2019
<!-- page 10 -->
11. TRADEMARKS. Distributor shall not dispute or contest for any reason whatsoever, directly or
indirectly, during the term of this Agreement and thereafter, the validity, ownership or
enforceability of any of the trademarks of Company, nor directly or indirectly attempt to acquire or
damage the value of the goodwill associated with any of the trademarks of Company, nor counsel,
procure or assist any third Party to do any of the foregoing. Distributor will not institute any
proceedings with respect to the trademarks of Company either in Distributor's own name or on behalf
of Company without express written permission of Company. Distributor shall assign to Company,
without charge, any rights in the trademarks of Company that may inure to the benefit of Distributor
pursuant to this Agreement or otherwise. Distributor shall execute any documents or do any acts that
may be required to accomplish the intent of this Section. 12. GENERAL PROVISIONS. (a) Amendments.
This Agreement may be amended only by a writing signed by each of the Parties, and any such
amendment shall be effective only to the extent specifically set forth in such writing. (b)
Governing Law. This Agreement is a contract under the laws of the State of Florida and for all
purposes shall be governed by and construed in accordance with the substantive laws of the State of
Florida, without regard to its principles of conflicts of laws provisions. (c) Disputes. The Parties
shall seek to resolve any dispute, controversy or claim arising out of or in connection with this
Agreement, including without limitation, any dispute regarding the enforceability of any provision,
through good faith negotiations between them within Thirty (30) days of any notice of dispute being
served or such longer period of time as may be mutually agreed between the Parties. If the Parties
are unable to resolve the dispute within this timeframe, and one or both parties one or both parties
desire to pursue the dispute, the complaining party must submit the dispute to binding arbitration
in accordance with the rules and regulations of the American Arbitration Association. The Parties
will share equally the cost of arbitrating such dispute. The arbitrator(s) shall not be empowered to
award punitive or other damages in excess of compensatory damages, and both parties irrevocably
waive the right to any such damages. Judgment on the award rendered by the arbitrator(s) may be
entered by any court having jurisdiction over the dispute. In the event that the parties cannot
agree upon an arbitrator within a Thirty (30) day period, each party shall designate an arbitrator
and those two arbitrators shall choose a third arbitrator, with that third arbitrator serving as the
sole arbitrator of the dispute.

10

Source: GENTECH HOLDINGS, INC., 1-A, 8/8/2019
<!-- page 11 -->
(d) Assignment. Neither Party shall assign, pledge or otherwise transfer any of its rights, interest
or obligations hereunder, whether by operation of law or otherwise, without the prior express
written consent of the other Party. (e) Counterparts; Email Execution. This Agreement may be
executed in any number of counterparts, and by each of the Parties on separate counterparts, each of
which, when so executed, shall be deemed an original, but all of which shall constitute but one and
the same instrument. Delivery of an executed counterpart of this Agreement by email shall be equally
as effective as delivery of a manually executed counterpart of this Agreement. Any Party delivering
an executed counterpart of this Agreement by email shall also deliver a manually executed
counterpart of this Agreement, but the failure to deliver a manually executed counterpart shall not
affect the validity, enforceability or binding effect of this Agreement. (f) Cumulative Remedies.
The rights and remedies of the Parties hereunder are cumulative and not exclusive of any rights or
remedies which the Parties would otherwise have. No single or partial exercise of any such right or
remedy by a Party, and no discontinuance of steps to enforce any such right or remedy, shall
preclude any further exercise thereof or of any other right or remedy of such Party. (g) Entire
Agreement. This Agreement contains the entire agreement of the Parties with respect to the
transactions contemplated hereby and supersedes all prior written and oral agreements, and all
contemporaneous oral agreements, relating to such transactions. (h) Exhibits and Schedules.The
exhibits or schedules attached hereto are an integral part hereof and all references herein to this
Agreement shall include such exhibits and schedules.

11

Source: GENTECH HOLDINGS, INC., 1-A, 8/8/2019
<!-- page 12 -->
(i) Notices. Unless otherwise specifically provided herein, all notices, consents, requests, demands
and other communications required or permitted hereunder: (i) shall be in writing; (ii)) shall be
sent by email, certified or registered U.S. mail, or reliable express delivery service (with a copy
sent by one of the foregoing means), charges prepaid as applicable, to the appropriate address(es)
or number(s) set forth below; and (iii) shall be deemed to have been given on the date of receipt by
the addressee, as evidenced by (A) a receipt executed by the addressee (or a responsible person in
his or her office), the records of the Person delivering such communication or a notice to the
effect that such addressee refused to claim or accept such communication, if sent by messenger, U.S.
mail or express delivery service, or (B) a receipt generated by the sender's email showing that such
communication was sent to the appropriate number on a specified date, if sent by email. All such
communications shall be sent to the addresses for each Party as first set forth above, or to such
other addresses or numbers as any Party may inform the others by giving Seven (7) days prior notice.
(j) Severability. Any provision of this Agreement which is prohibited or unenforceable in any
jurisdiction shall, as to such jurisdiction, be ineffective to the extent of such prohibition or
unenforceability without invalidating the remaining portions hereof or affecting the validity or
enforceability of such provision in any other jurisdiction. (k) Successors and Assigns. This
Agreement shall be binding upon and shall inure to the benefit of each of the Parties and their
respective successors and permitted assigns.

12

Source: GENTECH HOLDINGS, INC., 1-A, 8/8/2019
<!-- page 13 -->
IN WITNESS WHEREOF, this Agreement was signed by the Parties under the hands of their duly
authorised officers and made effective as of the date first written above. Luiz Augusto Matavelli
Bacetti B & C General Warehouse Corporation LLC Date: 04th, August, 2019. xxxxxxxx xxxxxxxx Date:

Source: GENTECH HOLDINGS, INC., 1-A, 8/8/2019
<!-- page 14 -->
SCHEDULE A PRICES AND DISCOUNT VOLUME PRICES Subject to Company's right to increase the price only
once per year per the terms and restrictions contained in the Agreement, and Company's right to
decrease the price at any time upon notice, the Products shall be sold by Company to Distributor at
the following Prices and Volume Discount Prices. Prices are in US Dollars. ● $9 (US) per kilogram
Ex-work Incoterms. (Brazil Farm). Distributor will be appropriately credited should Distributor make
payment related to an order and later determine that it had achieved a greater discount per the
above.

Source: GENTECH HOLDINGS, INC., 1-A, 8/8/2019
