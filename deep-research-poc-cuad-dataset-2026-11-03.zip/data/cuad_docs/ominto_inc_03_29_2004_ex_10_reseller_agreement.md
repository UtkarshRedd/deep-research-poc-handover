<!-- page 1 -->
# RESELLER AGREEMENT
| Field | Value |
|---|---|
| Document Type | Reseller Agreement |
| Agreement Date | 2004-03-19 |
| Parties | MediaNet Group Technologies, Inc. ("MEDIANET GROUP TECHNOLOGIES"); International Direct Response, Inc. ("RESELLER") |
| Source | CUAD v1 / OMINTO,INC_03_29_2004-EX-10-RESELLER AGREEMENT |

EXHIBIT 10.25 RESELLER AGREEMENT

THIS AGREEMENT (the "AGREEMENT") entered into as of the 19 day of March, 2004 (the "EFFECTIVE DATE")
provides the terms and conditions under which MediaNet Group Technologies, Inc., a Nevada
corporation having an address at 5100 W. Copans Road Suite 710 Margate, FL 33063 USA ("MEDIANET
GROUP TECHNOLOGIES"), authorizes International Direct Response, Inc., a Pennsylvania Corporation,
having an address at 1125 Lancaster Avenue, Berwyn, PA 19312("RESELLER") to be its true and lawful
representative and agent for the purpose of reselling licenses of the MediaNet Group Technologies
Portals ("PORTALS") and other MediaNet Group Technologies products and services in accordance with
the terms and conditions contained in this Agreement. This Agreement, together with the other
agreements and schedules referenced in it, contains the complete terms and conditions between the
parties.

MEDIANET GROUP TECHNOLOGIES AND RESELLER AGREE AS FOLLOWS:

1. LICENSE

Reseller is hereunder licensed to market MediaNet Group Technologies' Brand-A-Port portals
("PORTALS") and to resell MediaNet Group Technologies products and services for compensation in
accordance with the annexed "RESELLING SCHEDULE." Under the terms and conditions as outlined in this
Agreement.

2. RESELLING

The Reseller intends to market the Portals to companies and various businesses and individuals
("BUYERS") who may include corporations, small businesses, religious organizations, network
marketing, franchise, business opportunities, chains, charities, organizations and other companies
that would have a use for individual and multiple portals. The purpose of this Agreement is to
define the scope of compensation for the marketing of Portals to these potential customers. During
the Term of this Agreement, Reseller shall have the right to market Brand-A-Port Portals, both
through the existing Brand-A-Port Portal under the License and independently to Buyers for resale,
subject to approval by MediaNet Group Technologies.

3. COMPENSATION

MediaNet Group Technologies shall pay Reseller a fee in accordance with the annexed Fee Schedule.
MediaNet Group Technologies will remit payment as directed by Reseller in the time frames noted on
the Compensation Schedule attached hereto.

4. PUBLICITY AND ADVERTISING

Subject to Section 7, Reseller and MediaNet Group Technologies agree that broad publicity with
respect to the relationship developed by this Agreement, and the advantages of such relationship,
will be permitted and actively encouraged and supported by both parties. This publicity initiative
will include, but is not limited to, a press releases issued by Reseller and MediaNet Group
Technologies, publicizing the strategic alliance between the parties, on site promotion and email
campaigns. In this regard, Reseller and MediaNet Group Technologies shall agree on the form, content
of the press release prior to its release. MediaNet Group Technologies must approve any advertising
prior to issuance and placement.

5. PROPRIETARY RIGHTS

5.1 OWNERSHIP. RESELLER understands and agrees that MediaNet Group Technologies is the exclusive
holder of and shall retain, all right, title and interest in and to the Portal, Content and Engine
and the All Pages, including without limitation all intellectual Property therein site (EXCLUDING
PROPRIETARY PAGES PROVIDED BY RESELLER OR BUYERS).

Reseller Agreement Initials ______ _______ 1

5.2 INTELLECTUAL PROPERTY. Nothing herein shall grant a party any right, title or interest in the
other party's Intellectual Property, except as explicitly set forth herein. At no time during or
after the Term of this Agreement shall a party challenge or assist others to challenge the other
party's Intellectual Property or the registration thereof or attempt to register any trademarks,
marks or trade names confusingly similar to those or the other party.

5.3 INTELLECTUAL PROPERTY WARRANTY. The MediaNet Group Technologies BrandAPort Service and the
operation of the site(s) and co-branded site(s) as currently operated by MediaNet Group
Technologies, Inc. is designed to provide a link taking the end-user to it's originating website.
Other than claims arising out of the use of the BrandAPort services, MediaNet Group Technologies
shall not be responsible for unauthorized use of the Co-branded sites by Reseller, users of
Reseller's or Buyers' Sites.

6. CONFIDENTIALITY

6.1 CONFIDENTIALITY INFORMATION. Each party (the "RECEIVING PARTY") acknowledges that by reason of
its relationship to the other party (the "DISCLOSING PARTY") hereunder, the Receiving Party will
have access to certain information and materials, including the terms of this Agreement, concerning
the Disclosing Party's business, plans, technology, products and services that are confidential and
of substantial value to the Disclosing Party, which value would be impaired if such information were
disclosed to third parties ("CONFIDENTIAL INFORMATION"). The Receiving Party agrees that
<!-- page 2 -->
it shall not use in any way for its own account or the account of any third party, nor disclose to
any third party, any such Confidential Information revealed to it by the Disclosing Party. The
Receiving Party shall take every reasonable precaution to protect the confidentiality of
Confidential Information. Upon request by the Receiving Party, the Disclosing Party shall advise
whether or not it considers any particular information to be Confidential Information. The Receiving
Party shall not publish any technical description of the Disclosing Party's Confidential Information
beyond any descriptions published by the Disclosing party. In the event of expiration or termination
of this Agreement, there shall be no use or disclosure by the Receiving Party of any Confidential
Information of the Disclosing Party, and the Receiving Party shall not develop any software,
devices, components or assemblies utilizing the Disclosing Party's Intellectual Property. Both
parties agree that the terms and conditions of this Agreement are confidential and shall not be
disclosed to any third party, unless disclosure is compelled by final, non-appealable order of a
court of competent jurisdiction.

6.2 EXCLUSIONS. Confidential Information does not include information permitted to be disclosed
under section 5 and any information that the Receiving Party can demonstrate by written records: (a)
was known to the Receiving Party prior to its disclosure hereunder by the disclosing party; (b) is
independently developed by the Receiving Party; (c) is or becomes publicly known through no wrongful
act of the Receiving Party; (d) has been rightfully received from a third party whom the Receiving
party has reasonable grounds to believe is authorized to make such disclosure without restriction;
(e) has been approved for public release by the Disclosing Party's prior written authorization, or
(f) must be produced or disclosed pursuant to applicable law, regulation or court order, provided
that the receiving party provides prompt advance notice thereof to enable the disclosing party to
seek a protective order or otherwise prevent such disclosure. In addition, Reseller and MediaNet
Group Technologies may disclose the existence and terms of this Agreement in connection with a
potential acquisition of substantially the entire business of the other party, or a private or
public offering of securities of either party.

Reseller Agreement Initials ______ _______ &sbsp; 2

7. LIMITATION OF LIABILITY

NEITHER RESELLER NOR MEDIANET GROUP TECHNOLOGIES MAKES ANY WARRANTY WHATSOEVER WITH REGARD TO THE
FEATURES, FUNCTIONS, PERFORMANCE, QUALITY OR OTHER CHARACTERISTICS OF THE SERVICE EACH COMPANY
PROVIDES. IN NO EVENT SHALL EITHER PARTY BE LIABLE TO EACH OTHER OR ANY OTHER ENTITY FOR ANY
SPECIAL, CONSEQUENTIAL, INCIDENTAL OR INDIRECT DAMAGES, HOWEVER CAUSED, ON ANY THEORY OF LIABILITY,
AND NOTWITHSTANDING ANY FAILURE OF ESSENTIAL PURPOSE OF ANY LIMITED REMEDY. RESELLER SHALL NOT BE
LIABLE TO MEDIANET GROUP TECHNOLOGIES OR ANY OTHER PARTY FOR ANY DAMAGES ARISING FROM THIRD PARTY
UNAUTHORIZED ACCESS OR USE OF THE MEDIANET GROUP TECHNOLOGIES SERVICE OR ANY IMAGES OBTAINED BY
USING THE MEDIANET GROUP TECHNOLOGIES SERVICE. MEDIANET GROUP TECHNOLOGIES SHALL NOT BE LIABLE TO
RESELLER OR ANY OTHER PARTY FOR ANY DAMAGES ARISING FROM THIRD PARTY UNAUTHORIZED ACCESS OR USE OF
THE MEDIANET GROUP TECHNOLOGIES SERVICE OR ANY IMAGES OBTAINED BY USING THE MEDIANET GROUP
TECHNOLOGIES SERVICES.

8. DISCLAIMERS

MEDIANET GROUP TECHNOLOGIES DISCLAIMERS. MEDIANET GROUP TECHNOLOGIES MAKES NO OTHER WARRANTIES OF
ANY KIND, EITHER EXPRESS OR IMPLIED, STATUTORY OR OTHERWISE, REGARDING THE MEDIANET GROUP
TECHNOLOGIES, PICTUREJUDGE OR BRANDAPORT SERVICE, AND MEDIANET GROUP TECHNOLOGIES SPECIFICALLY
DISCLAIMS ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR
PURPOSE. MEDIANET GROUP TECHNOLOGIES DOES NOT WARRANT THAT THE OPERATION OF THE MEDIANET GROUP
TECHNOLOGIES SERVICE WILL BE UNINTERRUPTED OR ERROR-FREE. FURTHERMORE, MEDIANET GROUP TECHNOLOGIES
DOES NOT MAKE ANY REPRESENTATIONS REGARDING THE USE OF THE RESULTS OF THE USE OF THE MEDIANET GROUP
TECHNOLOGIES SITE IN TERMS OF THEIR CORRECTNESS, ACCURACY, RELIABILITY OR OTHERWISE.

9. TERMS AND TERMINATION

9.1 TERM. The term of this Agreement shall commence on the Effective Date and continue for a period
of 1 year after the Effective Date, unless earlier terminated as set forth herein (the "TERM"). This
Agreement shall renew for successive 1-year periods, after the initial 1 Year Term, if agreed by
both parties in writing within 30 days of license expiration. Either party may terminate the
Agreement on 60-days written notice during a renewed term. However, in no event shall termination of
this Agreement by MediaNet Group Technologies relieve it of the obligation to remit payment to
Reseller for sales or Portals, Hosting Services or other products and services to or through Buyers
contracted by Reseller prior to such termination. The obligation to remit payment cease 30 days
after termination of this Agreement.

9.2 TERMINATION FOR BREACH OR INSOLVENCY. A party shall have the right to terminate this Agreement
on written notice if (a) the other party ceases to do business in the ordinary course or is
insolvent (i.e., unable to pay its debts in the ordinary course as they come due), or is declared
bankrupt, or is the subject of any liquidation or insolvency proceeding which is not dismissed
within 90 days, or makes any assignment for the benefit of creditors, or (b) the other party
breaches any material term of this Agreement, including timely payments, and fails to cure such
breach within 30 days after written notice thereof (collectively referred to here in as "TERMINATING
EVENTS"). In the event of a Terminating Event, involving Reseller, other than for an event involving
fraud or dishonesty by Reseller, MediaNet Group Technologies shall be entitled to offset payments
<!-- page 3 -->
due under this Agreement against its costs incurred as a result of the Terminating Event, but shall
remain obligated to remit all payments due under this agreement as a direct result of the activities
of Reseller prior to the effective date of termination.

Reseller Agreement Initials ______ _______ &sbsp; 3

10. EFFECT OF TERMINATION

Upon the expiration or termination of this Agreement:

10.1 Each party shall, within 30 days of such expiration or termination return to other party or
destroy all Confidential Information and all other material received from such other party.

10.2 All rights granted by Reseller hereunder to MediaNet Group Technologies shall terminate. All
rights granted by MediaNet Group Technologies hereunder to Reseller shall terminate, subject to the
continuing obligation of MediaNet Group Technologies to remit payment pursuant to the provisions of
Section 8.

10.3 Sections 5, 6, 7, 9.2 10, 11, 12 and 13 shall survive the expiration or termination of this
Agreement for any reason.

11. REMEDIES

11.1 INDEMNIFICATION. Reseller and MediaNet Group Technologies shall indemnify and hold harmless
each other, and their respective directors, officers, employees, and agents, from and against all
claims, losses, damages and expenses (including reasonable attorney's fees) resulting from the
breach of any agreement, representation or warranty set forth herein; provided the indemnified party
provides the indemnifying party with (i) prompt written notice of such claim or action, (ii) sole
control and authority over the defense or settlement of such claim or action and (iii) proper and
full information and reasonable assistance to defend and/or settle any such claim or action.

11.2 INJUNCTIVE RELIEF. The parties acknowledge that the breach or threatened breach of this
Agreement by Reseller would cause irreparable harm to MediaNet Group Technologies, the extent of
which would be difficult to ascertain. Accordingly, each party agrees that, in addition to any other
remedies to which MediaNet Group Technologies may be legally entitled, MediaNet Group Technologies
may seek immediate injunctive relief in the event of a breach or threatened breach of such sections
by the Reseller or any of Resellers employees or subcontractors.

12. RESELLER PORTAL

If applicable, MediaNet Group Technologies shall produce a Branded Portal for Licensee under terms
as outlined in a Portal Agreement attached hereto.

13. MISCELLANEOUS

13.1 ASSIGNMENT. This Agreement will be binding upon and inure to the benefits of the parties hereto
and their permitted successors and assigns. Reseller may nat assign or otherwise transfer this
Agreement without MediaNet Group Technologies's prior written consent except to a successor.

13.2 WAIVER AND AMENDMENT. No modifications, amendment or waiver of any provision of this Agreement
shall be effective unless in writing and signed by the party to be charged. No failure or delay by
either party in exercising any right, power, or remedy under this Agreement shall operate as a
waiver of any such right, power or remedy.

13.3 GOVERNING LAW. The laws of the State of Florida shall govern this Agreement, without reference
to conflicts of law provisions.

13.4 NOTICES, ETC. Any notice required or permitted by this Agreement shall be deemed given if
delivered by registered mail, postage prepaid, addressed to the other party at the address shown at
the beginning of this Agreement or at such other address for which such party gives notice
hereunder. Delivery shall be deemed effective 3 days after deposit with postal

Reseller Agreement Initials ______ _______ 4

authorities. Email, facsimile or other form of transmission pursuant to which MediaNet Group
Technologies receives actual notice of the accounts into which the funds are to be wired may give
notices of the accounts into which payment is to be wired shall be effective and MediaNet Group
Technologies shall be entitled to rely upon them as if they were sent in accordance with the notice
provisions of this paragraph.

13.5 INDEPENDENT CONTRACTORS. The parties are independent contractors with respect to each other.
Each party is not and shall not be deemed to be an employees, agent, joint venture Reseller or legal
representative of the other for any purpose and shall not have any right, power, or authority to
create any obligation or responsibility on behalf of the other.

13.6 SEVERABILITY. If any provision of this Agreement shall be held by a court of competent
jurisdiction to be contrary to law, such provision shall be changed and interpreted so as to best
accomplish the objectives of the original provision to the fullest extent allowed by law and the
remaining
<!-- page 4 -->
provisions of this Agreement shall remain in full force and effect.

13.7 COMPLETE UNDERSTANDING. This Agreement constitutes the final, complete and exclusive agreement
between the parties with respect to the subject matter hereof, and supersedes any prior or
contemporaneous agreement, either written or oral.

13.8 FORCE MAJEUR. Except with respect to obligations to make payments hereunder, neither party
shall be deemed in default hereunder, nor shall it hold the other party responsible for, any
cessation, interruption or delay in the performance of its obligations hereunder due to causes
beyond its reasonable control including, but not limited to: earthquake, flood, fire, storm or other
natural disaster, act of God, labor controversy or threat thereof, civil disturbance or commotion,
disruption of the public markets, war or armed conflict or the inability to obtain sufficient
material, supplies, labor, transportation, power or other essential commodity or service required in
the conduct of its business, including internet access, or any change in or the adoption of any law,
ordinance, rule, regulation, order, judgment or decree.

13.9 CONTENT. It is agreed that MediaNet Group Technologies shall have complete control of content
on the Portals with the exception of the customized pages and links on contracted portals, and these
pages and links are subject to MediaNet Group Technologies's approval.

13.10 NO DISPARAGEMENT. Each party agrees that, during the Term of this Agreement and for a period
of five (5) years thereafter, neither will make written or oral comments regarding the other that
are negative, disparaging, tend to bring the other into disrepute or call into question the business
acumen, character, honesty or integrity of the other.

IN WITNESS WHEREOF, the parties have caused this Agreement to be executed effective as of the day
and year last set forth below.

MEDIANET GROUP TECHNOLOGIES, INC. LEGAL NAME: Michael Guyer

/s/ Martin A.Berns /s/ Michael Guyer ---------------------------------
------------------------------------ Signature Signature

By: Martin A. Berns By: Michael Guyer

Title: Chief Executive Officer Title: VP & Director of Marketing

Name of Master Reseller (if applicable):____________ Approved by:_______________

Reseller Agreement Initials ______ _______ 5

LICENSE RESELLING SCHEDULE

Resellers are licensed to market the Brand-A-Port applications and receive commission on all product
sales plus residual income on hosting/maintenance fees as outlined on the Compensation Schedule
attached hereto.

THE PLAN

The MediaNet Group Technologies Reseller Plan is free to join. Under the plan, resellers market and
promote MediaNet Group Technologies's software product range to their existing customer base and the
general Internet community. By referring a customer to the MediaNet Group Technologies web site, the
reseller receives a commission for customer's purchase of the MediaNet Group Technologies
Brand-A-Port software.

MARKETING AND PROMOTION

Resellers are expected to actively market and promote MediaNet Group Technologies Software to their
existing customer base and visitors to their web site. Promotion by newsletters and e-mail to
customers is encouraged, but we do not encourage spam e-mail and hence specifically ask resellers
not to promote MediaNet Group Technologies Software or Applications via unsolicited e-mail.

RESELLER LINK

Customers are identified as coming from a particular reseller by placing a link(s) on their web
site, which contains a cookie (i.e.. small packet of code) which identifies the reseller. On
acceptance into the program, MediaNet Group Technologies issues the reseller with the cookie and
instructions on how to insert the cookie into their web site.

WHAT PRODUCTS ARE AVAILABLE FOR RESALE?

Products which can be resold, include: Brand-A-Port Gold (Generic Portal), Brand-A-Port Platinum
Portal and Branded PictureJudge applications. MediaNet Group Technologies may offer additional
products from time to time.

COMMISSION

MediaNet Group Technologies tracks the customer sales coming from the reseller and at the end of
every calendar month issues a check for 20% commission to the reseller on product sales and 10% the
total amount of hosting/maintenance sales made. Commissions are only paid each month if the amount
owing exceeds $100 US. MediaNet Group Technologies reserves the right to change the level of
commission
<!-- page 5 -->
with out notice. Commission is not paid on MediaNet Group Technologies's free-ware programs.
(pricing and products subject to change without notice).

CUSTOMER CONTACT

Once a customer has come from the reseller to the MediaNet Group Technologies web site, MediaNet
Group Technologies deals with the customer directly, issuing the software from the MediaNet Group
Technologies server and billing the customer. MediaNet Group Technologies handles all technical
support and refund issues.

REFUNDS

If a refund is issued to a customer who came from a reseller, the reseller's account is adjusted
accordingly.

TERMINATION

The Reseller Agreement can be terminated at any time at the discretion of either party.

Reseller Agreement Initials ______ _______ 6

COMPENSATION SCHEDULE

This Compensation Schedule is attached hereto and made a part thereof that certain Reseller
Agreement of even date:

Reseller shall be entitled to receive compensation in the following manner:

COMPENSATION:

BSP REWARDS PROGRAM: MediaNet shall, upon collection, remit to Member Provider _1_% of the net
Rewards earned by Members through and provided directly by it, and _1_% of the net Member Rewards
received and collected that is earned through Merchants, Companies, Organizations, Groups and
individuals that have been contracted through Member Provider.

BRAND-A-PORT OR BSP PORTAL SALES: MediaNet shall remit to Member Provider 20% of the price of each
Portal sold directly by it.

BSP MONTHLY HOSTING FEES: In addition, MediaNet shall remit to Member Provider an amount equal to
10% of the hosting fees paid by Buyers who purchase portals or host websites with MediaNet as a
direct result of the activities of Member Provider, whether those activities are sold through the
portal or independent of it.

PAYMENT OF COMPENSATION (SUBJECT TO RECEIPT OF GOOD, VALID FUNDS)

PORTAL SALES: MediaNet shall remit all sums due to Member Provider within 30 days of receipt of
cleared funds.

MONTHLY HOSTING FEES: In addition, MediaNet shall remit hosting fees to Member Provider in monthly
installments on or before the 15th business day of each month. All sums received by MediaNet through
the last business day of the preceding month shall be included in the calculation of the amount to
be remitted.

BSP REWARDS MEMBER PURCHASES VOLUME: Amounts due for purchases of products or services shall be
calculated as of funds received by the last day of each month and remitted on or before the 15th day
of the following month.

RECORDS

MediaNet shall maintain books and records and shall provide for online confirmation of sales and
payments. MediaNet shall permit Member Provider or its designees reasonable access during normal
business hours and, upon request, to verify funds and payments due pursuant to this Agreement.

IN WITNESS WHEREOF, the parties have caused this Agreement to be executed effective as of the day
and year last set forth below.

Reseller Agreement Initials ______ _______ 7

RESELLER DISTRIBUTOR PRICING STRUCTURE & DETAILS

GOLD PORTAL

Includes the following available options:

o Complete Basic Portal

o Web-based Admin Panel to turn on and turn off individual applications and features

o Branded Header

o Branded Frames

o Reseller Program

o Email

o MediaNet Group Technologies Photo Sharing
<!-- page 6 -->
o MediaNet Group Technologies Travel Agency

Retail $495 License Wholesale $395 Monthly Hosting/Maintenance/Updates Retail $39 Wholesale $35
(quarterly maintenance fee due in advance)

PLATINUM PORTAL

Includes at your option:

o Full Featured Customizable Portal with web based administration panel

o Branded Header

o Branded Photo Sharing

o Branded Travel Agency

o Branded Frames

o Email

o Branded Picture Judge

o Reseller program

Retail $1295 License Wholesale $1035 Monthly Hosting/Maintenance/Updates Retail $99 Wholesale $89
(quarterly maintenance fee due in advance)

BRANDED PICTUREJUDGE(SM) INTERACTIVE PHOTO RATING GAME

Includes at your option: o Branded PictureJudge photo rating game o Customized phot catagories o
Reseller Program

Retail $795 License Wholesale $635 Monthly Hosting/Maintenance/Updates Retail $69 Wholesale $63
(quarterly maintenance fee due in advance)

Reseller Agreement Initials ______ _______ 8

PROCEDURE FOR REGISTERING PROSPECTIVE CLIENTS, MEMBER PROVIDERS/ MERCHANTS/MERCHANT MEMBER PROVIDERS

This Addendum is attached hereto and made a part hereof that certain Reseller or Master Reseller
Agreement between the parties:

MEDIANET GROUP (MNG) HAS DEVELOPED A SET OF CRITERIA DESIGNED TO AVOID ANY POTENTIAL PROSPECT
REGISTRATION DISPUTES AND TO ASSURE OUR RESELLERS FULL COMMISSION ON SALES MADE BY THEM. TO INSURE
THIS GOAL, WE HAVE CREATED CRITERIA THAT MUST BE FOLLOWED FOR REGISTRATION OF THE COMPANIES
(PROSPECTS) INTRODUCED TO THE BSP REWARDS PROGRAM.

1. Resellers must send us an E-mail with the company name, contact and title that you wish to
register with the Company. Said contact must have the authority to make the decision relative to the
Brand-A-Port and/or BSP programs.

2. MNG will send an e-mail to the Reseller approving or disapproving the registration of the
prospective client dependent upon whether or not there has been prior contact by the company,
registration of the prospect by another Reseller or other factors as determined by the MNG.

3. Upon approval by MNG, the Reseller will have 30 days to initiate and complete a proposal to said
prospect. The proposal must be approved by MNG and receipt confirmed by the prospect.

4. The Reseller will then have 5 months to bring the registered prospect to contract. If a contract
is not consummated in the allotted time-frame, the prospect shall then revert back to MNG. Reseller
may then re-register the prospect subject to the above criteria and/or other criteria in effect at
the time.

The above criteria points are firm unless a special situation is approved by MNG in writing.

WE BELIEVE THAT EACH REPRESENTATIVE AND RESELLER WILL SEE THE BENEFITS OF THIS PROGRAM AND THE
PROTECTION IT AFFORDS THEM.

APPROVED AND ACCEPTED BY THE SIGNATORY PARTIES BELOW THIS __ OF ________, 200__.

MediaNet Group Technologies, Inc. ________________________

Accepted by: __________________________ Accepted by:__________________ Chief Executive Officer
Title:
<!-- page 7 -->
Reseller Agreement Initials ______ _______ 9
