<!-- page 1 -->
# OUTSOURCING AGREEMENT
| Field | Value |
|---|---|
| Document Type | Outsourcing Agreement |
| Agreement Date | 1998-01-19 |
| Parties | (Dragon Systems, Inc. ("Dragon Systems"); Modus Media International ("MMI") |
| Source | CUAD v1 / DRAGONSYSTEMSINC_01_08_1999-EX-10.17-OUTSOURCING AGREEMENT |

1 Exhibit 10.17

Confidential Materials omitted and filed separately with the Securities and Exchange Commission.
Asterisks denote omissions.

OUTSOURCING AGREEMENT

BETWEEN:

MODUS MEDIA INTERNATIONAL LANDDROSTLAAN 51 7327 GM APELDOORN THE NETHERLANDS (HEREINAFTER "MMI")

AND

DRAGON SYSTEMS, INC. 320 NEVADA STREET NEWTON, MA 02160 U.S.A. (HEREAFTER "DRAGON SYSTEMS")

EFFECTIVE AS OF (EFFECTIVE DATE)

1. PURPOSE OF AGREEMENT Formalize the agreements made regarding services and products between Dragon
Systems and MMI.

2. SERVICES MMI will produce products for Dragon Systems on a Turnkey basis. Initially, services
will cover 3 products, as per the attached price sheets. However, this may be extended.

Specific services will be:

- - Receipt and Management of master materials

- - Supply base management

- - Production (both components & finished goods)

- - Delivery

- - Inventory Management

- - Financial Services

Quality and Services Level Agreements will be based on mutual agreement.

3. DELIVERY

MMI shall deliver the Services in line with the agreed service levels to Dragon Systems.

2 Confidential Materials omitted and filed separately with the Securities and Exchange Commission.
Asterisks denote omissions.

4. ACCEPTANCE OF SERVICES

Dragon Systems may reject the Services if they do not comply with the specification set out by
Dragon \s\ JB. The Services are deemed to be accepted if MMI does not receive a notification within
60 days after delivery to Dragon Systems or its customers.

5. PAYMENT AND PRICING

Dragon Systems will compensate MMI for all Services rendered in accordance with the rates specified
in the Annex "Prices." Unless otherwise agreed, prices shall exclude transport, insurance, VAT and
Import duties (outside EC countries) to Dragon Systems' designated delivery address.

For all materials in stock, older than 90 days, MMI will charge Dragon Systems with an Inventory
Carriage Charge of [**] of its value per month.

MMI will invoice Dragon Systems based on actual shipments that have been performed.

Payments will be due in US dollars within 30 days after delivery, or when agreed after delivery of
installments or the receipt of invoice by Dragon Systems, which ever is later. MMI shall invoice
Dragon Systems indicating the performed services in US$ with reference to this Agreement.

Dragon Systems shall be entitled to deduct from or set off against any sums which Dragon Systems may
be liable to pay to MMI any amounts owed by MMI, its affiliated entities, subsidiaries or successors
in interest.

6. WARRANTY

MMI warrants providing the Services with due diligence and care in accordance
<!-- page 2 -->
with the specifications set by Dragon Systems. Should MMI not supply the Services as agreed or
should the Services become defective within 6 months from their delivery to Dragon Systems, Dragon
Systems may at its option require MMI to complete or re-perform the Services within a reasonable
period of time, rescind the contract or refuse payment of the compensation in part or in total,
notwithstanding any damage claims.

7. INDEMNITY

MMI shall reimburse Dragon Systems and hold Dragon Systems harmless from any liabilities or
obligations imposed upon Dragon Systems resulting directly or indirectly from MMI's or its employees
or agents activities under this Agreement.

-2- 3 8. LIABILITY

Either party shall be liable for failure or delay in performance of its duties under this Agreement
except for reasons beyond such party's reasonable control. MMI shall not be liable for indirect or
consequential damages unless caused by intention or gross negligence.

9. CONFIDENTIALITY

Both parties shall take reasonable precautions to preserve in strict confidence any confidential or
proprietary information obtained by them, their agents or employees concerning the business,
products, equipment or services of the other party, including without limitation, trade secrets.
Such reasonable precautions shall include exercising precautionary measures designed to preserve the
secrecy of such information and to prevent its disclosure to third parties, except following prior
consent of the other party, with such precautions being at least equivalent to those taken by each
party with respect to its own confidential information.

10. PATENTS AND COPYRIGHT

MMI warrants that the Services supplied to Dragon Systems will not infringe any third parties'
intellectual property rights. MMI will defend and indemnity Dragon Systems against a claim that the
Services supplied hereunder infringe a patent or copyright and will pay resulting costs and damages
provided that Dragon Systems (i) promptly informs MMI in writing of the claim and (ii) gives MMI
sole control of the defense and all related settlement negotiations. MMI will either procure the
right for Dragon Systems to continue using the Services or replace or modify them so that they
become non-infringing or accept return of the Services for a credit equal to the price paid by
Dragon Systems.

11. COPYRIGHT AND COPYRIGHT LICENSE

Dragon Systems hereby grants MMI the rights to copy in printed or electronic form the master
materials according to the forecasted numbers given to MMI by Dragon Systems.

12. TERM AND TERMINATION

This Agreement shall be valid for an indefinite period.

Both parties may terminate the Agreement with immediate effect

- - of either party breaches a material term of the Agreement

- - in case of a merger or change of key management or control

- - in case of bankruptcy or similar.

Dragon may terminate this agreement without cause by giving sixty (60) days written notice to MMI.

-3- 4 13. GOVERNING LAW

Any lawsuit relating to any matter arising under this Agreement may be initiated in a State or
Federal Court located in the Commonwealth of Massachusetts or in any court in the Netherlands having
jurisdiction over the matter.

14. INSURANCE

MMI shall at its own expense obtain and maintain with an insurer adequate insurance coverage in
respect of any Dragon Systems property under the care, custody or control of MMI. MMI shall
immediately notify Dragon Systems in writing of any theft, loss or damage to any Dragon Systems
property and shall indemnify Dragon Systems in respect of the same.

MMI

\s\ John Dick General Manager - ------------------------------------------------------- 19 Jan. 1998

DRAGON SYSTEMS, INC.
<!-- page 3 -->
\s\ Janet M. Baker, President - ----------------------------------------------------- 12 Jan. 1998

-4- 5 NaturallySpeaking

Part Number Description 1,000 units 2,500 units 5,000 units 10,000 units 25,000 units 50,000 units -
---------------------- ------------------- ------------- ------------ ------------ -------------
------------ -------------

[**]

-5- 6 Dictate Power

Part Number Description 1,000 units 2,500 units 5,000 units 10,000 units 25,000 units 50,000 units -
---------------------- ------------------- ------------- ------------ ------------ -------------
------------ -------------

[**]

-6- 7 Dictate Classic

Part Number Description 1,000 units 2,500 units 5,000 units 10,000 units 25,000 units 50,000 units -
---------------------- ------------------- ------------- ------------ ------------ -------------
------------ -------------

[**]

-7-
