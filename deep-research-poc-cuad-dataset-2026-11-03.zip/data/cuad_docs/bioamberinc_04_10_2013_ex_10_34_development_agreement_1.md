<!-- page 1 -->
# DEVELOPMENT AGREEMENT
| Field | Value |
|---|---|
| Document Type | Development Agreement |
| Agreement Date | 2010-04-15 |
| Parties | Cargill, Incorporated ("Cargill"); Bioamber S.A.S ("Bioamber"); (individually as "Party", collectively as "Parties") |
| Source | CUAD v1 / BIOAMBERINC_04_10_2013-EX-10.34-DEVELOPMENT AGREEMENT (1) |

Exhibit 10.34

*** Text Omitted and Filed Separately Confidential Treatment Requested Under 17 C.F.R. §§
200.80(b)(4) and 203.406

DEVELOPMENT AGREEMENT

This Development Agreement ("Development Agreement") is entered into on April 15 , 2010
("EffectiveDate") by and between Cargill, Incorporated through its Bio Technology Development
Center, having its principal place of business at 15407 McGinty Road West, Wayzata, Minnesota 55391
USA ("Cargill") and Bioamber S.A.S., having a place of business at Route de Bazancourt, F-51110,
Pomacle France ("Bioamber"). Bioamber and Cargill shall be referred to individually as "Party" and
collectively as "Parties", as required by text.

Background

Cargill and Bioamber mutually agree as follows:

Cargill Confidential - 1 - * Confidential treatment requested

A. Cargill has developed a yeast strain designated CB1 ("CB1") for fermenting dextrose and/or mixed
sugar streams and related research tools for modifying CB1,which are protected by Licensed Patents
(as defined in Section 2.5 below).

B. Bioamber desires to engage Cargill to further develop or modify CB1 with the goal of fermenting
dextrose and/or mixed sugar streams to produce succinic acid and salts thereof.

C. The Parties desire to grant each other certain rights to use the further developed or modified
CB1 as well as other technology that is developed in the course of the work as provided in this
Development Agreement for research purposes only.

1. Scope of Work Plan 1.1 Cargill agrees to perform the services to develop or modify CB1 to produce
succinic acid and salts thereof using dextrose (defined as glucose) and/or sucrose as the
fermentation feedstock ("Work Plan"). The Work Plan is more fully described in Exhibit A, which is
hereby incorporated by reference into this Development Agreement. CB1 that has been further
developed or modified (or the like) under the Work Plan shall be referred to as "Modified CB1". Any
changes to the Work Plan must be in writing and signed by both Cargill and Bioamber and may be
subject to incremental fees depending on resource requirements.

1.2 In agreeing to perform the Work Plan, Cargill represents and warrants that:

1.2.1 Cargill has the capability, experience, and means necessary to perform the Work Plan, and the
Work Plan will be performed using personnel, equipment, and material qualified and suitable to
perform the Work Plan requested;

th
<!-- page 2 -->
Cargill Confidential - 2 - * Confidential treatment requested

1.2.2 Cargill will provide properly trained and informed personnel, and Cargill will be solely
responsible for the negligent acts, errors and omissions of its employees, subcontractors, and
agents and for any other person performing services under this Development Agreement at the direct
request of Cargill;

1.2.3 Cargill will perform the Work Plan in a workmanlike manner with reasonable skill and care
ordinarily exercised by members of the profession practicing under similar conditions and in
accordance with accepted industry practices and professional guidelines;

1.2.4 Subject to Section 13.1, Cargill has in effect and will maintain in effect all permits,
licenses and other authorizations necessary to perform the Work Plan; and

1.2.5 No other party has rights to its services as described in the Work Plan, and that a work
assignment from any third party shall not be accepted, or work by Cargill aloneshall not be
conducted, to develop CB1 or other microorganisms that will be used to (a) directly produce succinic
acid and salts thereof, or (b) indirectly produce succinic acid and salts thereof (for example,
Cargill may develop microorganisms to produce precursors of succinic acid, such as fumaric acid and
malic acid, so long as such precursors are not converted to succinic acid, such as by chemical
modification), for the Term (as defined in Section 10.1) of this Development Agreement. For purposes
of clarity, and as examples, Cargill may sell dextrose as fermentation feedstock to third parties,
who may use such dextrose to produce succinic acid; also, Cargill may modify starches to make
succinic acid starch derivatives.

2. Fees and Milestones 2.1 Bioamber shall pay Cargill Two Hundred Fifty Thousand U.S. Dollars
($250,000.00) within thirty (30) days of the execution of this Development Agreement.

2.2 In addition to the payment in Section 2.1, Bioamber shall pay Cargill a total of [***] U.S.
Dollars ($[***] per year per full-time equivalent (FTE) person to perform the Work Plan, and Cargill
will make available up to [***] FTE persons per year to perform the work as outlined in the Work
Plan. Such total is subject to change based on an annual review of the needs and requirements of the
Work Plan. The actual number of FTEs assigned at any given time will be a function of the Work Plan
and will be subject to agreement amongst the Parties. In addition, Bioamber will pay for reasonable
expenses incurred by Cargill, including travel. Cargill shall cover ordinary and customary [***].
Cargill shall submit to Bioamber a monthly invoice for costs owed by Bioamber, accompanied by a
report summarizing Cargill's activities in relation to actual hours worked and expenses incurred.
Bioamber will pay Cargill's costs within thirty (30) days of receipt of invoice and supporting
documentation. Bioamber shall have the right to audit Cargill time sheets from time to time. Such
audit shall occur once per year during reasonable business hours by an independent third party
agreed to by both parties, who shall be under obligations of confidentiality.
<!-- page 3 -->
Cargill Confidential - 3 - * Confidential treatment requested

2.3 Bioamber shall also pay Cargill within thirty (30) days of achieving each of the milestones
summarized below and more fully described in the Work Plan found in Exhibit A. For purposes of
clarity, payment is triggered [***]. Further, each of the Milestones and Target Dates may be changed
according to the needs of the Work Plan and upon written agreement by the parties.

Milestone Target Date Payment Milestone 1: Proof of Concept 12 months after Effective Date US
$250,000.00 Milestone 2: CB1 Strain Development 30 months after Effective Date US $300,000.00
Milestone 3: CB1 Strain Optimization 42 months after Effective Date US $500,000.00

2.4 Missed Milestones.

2.4.1 In the event Cargill does not achieve a given Milestone provided in Section 2.3 by the Target
Date listed in Section 2.3 or modified Milestone and modified Target Date as agreed to by the
Parties, and subsequently achieves such milestone as per the criteria described in Exhibit A, the
payment for such missed milestone shall be due [***] and the amount due shall be [***] for every
[***] beyond the Target Date. The Target Date for subsequent Milestones will be adjusted to reflect
the date on which the Milestone was actually achieved. If a subsequent Milestone is achieved by the
original Target Date listed in Section 2.3, Bioamber will pay Cargill the amount [***]. For purposes
of clarity and as examples, if Milestones 1 and 2 were not delivered by the Target Dates, but
Milestone 3 is delivered by or before the Target Date, then the total payments due to Cargill at
that time would be [***] (a total payment of $[***]). Another example is if [***], the payment due
at that time would be a total of $[***].

2.4.2 In the event Cargill does not achieve a given Milestone provided in Section 2.3 by the Target
Date listed in Section 2.3 or modified Milestone and modified Target Date as agreed to by the
Parties, and Bioamber decides to commercialize Modified CB1, any outstanding milestone payments
shall immediately become due such that the total payment due Cargill under this Development
Agreement equals One Million Fifty Thousand U.S. Dollars (US $1,050,000.00).
<!-- page 4 -->
Cargill Confidential - 4 - * Confidential treatment requested

2.4.3 Provided that Cargill has respected its undertakings set out in Section 1.2 of this
Development Agreement, no other damages shall accrue to Cargill for not achieving a given Milestone
other than provided in Sections 2.4.1, 2.4.2, and 2.5.

2.5 Option to Research License. In the event Cargill (i) is unable to achieve a given milestone
described in Section 2.3 by the Target Date, or (ii) terminates this Agreement pursuant to Section
10.2, Bioamber shall have the option to obtain a license during the term of this Development
Agreement to the patent applications and patents listed in Exhibit B (including any continuations,
continued prosecutions, continuations- in-part, reissues, reexaminations, divisions or substitutions
thereof) (collectively "Licensed Patents"), the tool kit listed in Exhibit C ("Licensed Tool Kit"),
and Cargill Improvements if any (as defined in Section 5.2 below), for research use only and for
additional monetary consideration ("Research License"). Except for financial terms paid by third
parties for [***], the Research License shall be offered to Bioamber at [***]. Such research use
shall be for the development and optimization of CB1 for the production of succinic acid and salts
thereof using dextrose or sucrose as the fermentation feedstock. The Research License shall be
provided to Bioamber only, with no rights to sublicense and with no "have made" rights.
Notwithstanding the preceding, Bioamber will be permitted to outsource development work as outlined
in the Work Plan and according to the Research License to third parties that have been approved by
Cargill, and such approval shall not be unreasonably withheld. In considering whether or not to
outsource such development work to third parties, the Parties recognize that it is in their mutual
interest to protect CB1, Modified CB1, Cargill Confidential Information (as defined in Section 4.1),
and Know-How and Licensed Patents (as those terms are defined under the Commercial License
Agreement) and, therefore, the Parties shall undertake joint evaluations of third parties who have
been identified by Bioamber to perform such development work, including, for example and not by
limitation, a risk assessment of the geography in which such development work will occur, and
whether or not such third parties have similar guiding principles as Cargill (a copy of Cargill's
Guiding Principles and Compliance Policy on Intellectual Property is attached as Exhibit F). Such
development work shall not be conducted by such third parties in circumstances where Cargill's
intellectual property is at an unacceptable risk as determined by Cargill based on the joint
evaluations of such third parties. The terms and conditions of such Research License shall be
negotiated between the Parties and shall include the terms described in this Section 2.5 and terms
addressing ownership and rights to use of any intellectual property developed. Further, this
Development Agreement shall serve as the framework for the Research License.

2.6 Technology Transfer. In the event Milestone 3 is achieved, Cargill will provide up to [***] to
assist in a successful transfer of the Modified CB1 technology to Bioamber in order to allow
subsequent scale-up at the same FTE rate set forth in Section 2.2. For clarity, [***] per FTE per
year equals US$[***] for this technology transfer).
<!-- page 5 -->
Cargill Confidential - 5 - * Confidential treatment requested

2.7 Scale-Up. Following the successful technology transfer, upon request by Bioamber and subject to
Cargill's availability of appropriate resources, Cargill will enter at its sole discretion into a
services agreement with Bioamber to assist in the fermentation scale-up of using Modified CB1
obtained under Milestones 2 and 3 for producing succinic acid and salts thereof at a single Bioamber
facility or a facility designated by Bioamber. Cargill shall invoice Bioamber [***] U.S. Dollars
(US$[***]) per man-day provided, not inclusive of taxes or other governmental fees, and further
adjusted for inflation at the time it goes into effect. Cargill shall have no obligation to perform
scale-up work at Cargill facilities.

3. Alternative Feedstock. Bioamber also desires the right to further develop CB1 to utilize
cellulosic biomass as the fermentation feedstock. Cargill hereby grants Bioamber the option to
modify or convert the Work Plan to include the development or modification of CB1 capable of
fermenting such cellulosic feedstock ("Modified Work Plan"). If such option is exercised, (a) the
terms and conditions of this Development Agreement shall apply to the Modified Work Plan except (i)
new, additional up-front and milestone payments shall apply as provided below, and (ii) any
development work performed under the Modified Work Plan will be at a FTE rate which will be
equivalent to the FTE rate provided in Section 2.2 above and further adjusted for inflation at the
time it goes into effect; and (b) the commercial license attached as Exhibit D shall be expanded to
include the resulting strain developed out of the Modified Work Plan with no additional change in
the financial terms. Additionally, the additional up-front fee [***].

Milestone using Alternative Feedstock Target Date Payment Up-front Payment TBD US $[***] Milestone
1: Proof of Concept TBD US $[***] Milestone 2: CB1 Strain Development TBD US $[***] Milestone 3: CB1
Strain Optimization TBD US $[***]

4. Confidentiality. To carry out the Work Plan, Cargill may receive from, and provide to, Bioamber
certain Confidential Information, as defined below. Such Confidential Information will be disclosed
by one Party (the "Disclosing Party") to the other Party (the "Receiving Party") on the following
terms and conditions:

4.1 "Confidential Information" means all business, technical, and financial information related to
the Work Plan, the terms and discussions relating to the Term Sheet executed by the parties on
December 3, 2009 and December 4, 2009, and to any aspect of the business of each Party that is
material to the Work Plan, including, without limitation, Licensed Tool Kit, products, product
compositions, raw materials, specifications, formulae, equipment, business plans and strategies,
customer lists, supplier lists, know-how, samples, drawings, pricing informationand other financial
information, inventions, ideas, research information, packaging, manufacturing processes, and other
information, or its potential use, that is owned by or in possession of either Party. For purposes
of clarity, the parties shall not disclose to each other any Confidential Information that is not
material to the Work Plan, such as, by way of example and without limitation, processes and other
information relating to post-fermentation activities. Confidential Information shall not include
information that: (a) is in the public domain prior to disclosure by Disclosing Party; (b) becomes
part of the public domain, by publication or otherwise, through no unauthorized act or omission by
the Receiving Party; (c) is lawfully in the Receiving Party's possession prior to disclosure by the
Disclosing Party; or (d) is independently developed by an employee(s) of the Receiving Party with no
access to the disclosed Confidential Information.
<!-- page 6 -->
Cargill Confidential - 6 - * Confidential treatment requested

4.2 The Receiving Party agrees to take and maintain proper and appropriate steps to protect
Confidential Information of the Disclosing Party. The Receiving Party agrees to disclose the
Confidential Information of the Disclosing Party only to employees or agents of the Receiving Party
who are directly involved with the Work Plan contemplated by this Development Agreement, and even
then only to such extent as is necessary and essential to perform the Work Plan. The Receiving Party
agrees to inform such employees and agents of the confidential nature of the information disclosed
hereunder and to cause all such employees and agents to abide by the terms of this Development
Agreement.

4.3 The Receiving Party shall not disclose the Disclosing Party's Confidential Information to any
unauthorized party without the Disclosing Party's prior express written consent or unless required
by court order or order of a similar governmental entity. If a Party is required by court order or
order of a similar governmental entity to disclose the other's Confidential Information, they shall
give the other Party prompt notice of such requirement so that an appropriate protective order or
other relief may be sought.

4.4 The Receiving Party will use Confidential Information only in connection with the Work Plan.
Both Parties have reserved all rights to their respective Confidential Information not expressly
granted herein. All documents and/or tangible materials containing or comprising Confidential
Information of the Disclosing Party will remain the property of the Disclosing Party. Upon the
request of the Disclosing Party, the Receiving Party will destroy all Confidential Information of
the Disclosing Party and any documents prepared by the Receiving Party using Confidential
Information of the Disclosing Party and the Receiving Party agrees to provide confirmation of such
destruction in writing. The Receiving Party may, however, keep one copy of any such document in the
files of its legal department or outside counsel for record purposes only.

4.5 Notwithstanding any other provision of this Development Agreement, each Receiving Party
acknowledges that a breach of confidentiality and use as provided in this Section may result in
irreparable harm and damages to the Disclosing Party in an amount difficult to ascertain and that
cannot be adequately compensated by a monetary award. Accordingly, in addition to any other relief
to which the Disclosing Party may be entitled at law or in equity, the Disclosing Party shall be
entitled to seek a temporary and/or permanent injunctive relief from any breach or threatened breach
by the Receiving Party.
<!-- page 7 -->
Cargill Confidential - 7 - * Confidential treatment requested

4.6 The obligations imposed by this section, including but not limited to non-disclosure and
non-use, however, will endure so long as the Confidential Information of the Disclosing Party does
not become part of the public domain.

4.7 The existence of and the terms of this Development Agreement, including its Exhibits, are
confidential and are not to be disclosed without the prior written approval of Cargill.

4.8 Neither Party may make any public announcement concerning this Development Agreement, its
subject matter, and the activities and actions it contemplates without the other Party's express
written consent. 4.9 This Section 4 supercedes and replaces the Mutual Confidentiality Agreement
between the Parties, which was effective July 17, 2009. All Confidential Information that was
subject to that Mutual Confidentiality Agreement is hereby made subject to the terms and conditions
of this Section 4.

5. Intellectual Property 5.1 Each party shall retain ownership of all intellectual property that it
owned prior to the Effective Date.

5.2 Improvements. Any invention or discovery relating to the Work Plan, in whole or in part, that is
conceived during the term of this Development Agreement shall be an "Improvement". The scope for
Improvements will be limited to the CB1 strain itself and the [***] (the "Field"), but shall exclude
[***]. Bioamber will own any Improvement in the field of succinic acid and salts thereof and such
Improvement shall be designated "Bioamber Improvements". Cargill will own any Improvement in all
fields other than the field of succinic acid and salts thereof, subject to the rights provided in
Section 5.2.1 below, and such Improvement shall be designated "Cargill Improvements". In the event
it is not clear as to ownership of any Improvement as described in this Section 5.2, in other words,
if it is not clear whether an invention or discovery is either a Bioamber Improvement or a Cargill
Improvement, such Improvement shall be [***] and such Improvement shall be designated "Joint
Improvements". For purposes of clarity, as examples, Cargill Improvements are those inventions
relating to fumaric acid and malic acid. Additionally, where an Improvement has applications both in
the Field and outside the Field, then such Improvement, as it applies to the Field, shall be a
Bioamber Improvement and, as it applies outside the Field, such Improvement shall be a Cargill
Improvement.

5.2.1 Cargill hereby grants Bioamber, and Bioamber hereby accepts, an exclusive, royalty-free
license to Cargill Improvements and Joint Improvements for use in the Field during the term of this
Development Agreement with a reservation of right for Cargill to practice such Cargill Improvements
and Joint Improvements for use in the field of succinic acid and salts thereof during the term of
this Development Agreement. Such use shall be for research purposes only with no rights to
sublicense and with no "have made" rights. Cargill shall also grant a commercial license to Bioamber
for Cargill Improvements and Joint Improvements under the terms and conditions of Exhibit D.
<!-- page 8 -->
Cargill Confidential - 8 - * Confidential treatment requested

5.2.2 Bioamber hereby grants Cargill, and Cargill hereby accepts, an exclusive, worldwide,
royalty-free license with an unlimited right to sublicense under and to Bioamber Improvements for
use outside the Field during the term of this Development Agreement. Such use shall be for research
purposes only.

5.2.3 Cargill shall have the first option to prepare, file, prosecute, and maintain patent
applications and issued/granted patents on Bioamber Improvements and Joint Improvements, which
option may be waived in whole or in part. Cargill shall bear all costs incurred in connection with
such preparation, filing, prosecution, and maintenance of U.S. and foreign application(s) and
issued/granted patents directed to Bioamber Improvements and Joint Improvements. Cargill shall
provide Bioamber a copy of any proposed patent application covering Bioamber Improvements and Joint
Improvements in advance of the submission of the proposed patent application to any patent office.
However, Cargill shall be entitled to file provisional patent applications without seeking
Bioamber's approval. If Cargill waives its option, Bioamber shall have the option to prepare, file,
prosecute, and maintain patent applications and issued patents on Bioamber Improvements and Joint
Improvements. Cargill shall provide, when requested by Bioamber, all information in its possession,
or true copies thereof, pertaining to Bioamber Improvements and Joint Improvements which may be
necessary or useful in the preparation, filing, and prosecution of patent applications covering the
Bioamber Improvements and Joint Improvements. Such information shall be treated as Confidential
Information.

5.2.4 If Cargill waives its option to prepare and prosecute a patent application in accordance with
Section 5.2.3 and elects not to file such a patent application or elects to allow any such patent
application or issued/granted patent to become abandoned or lapse, Cargill shall give Bioamber
notice of such election promptly and at least two (2) months prior to the first date that action
must be taken to avoid such abandonment or lapse. Bioamber shall have the right to take over at its
sole expense the filing, prosecution or maintenance of any such patent application and Bioamber
shall keep Cargill informed of Bioamber's filing, prosecution, and maintenance activities. All
out-of-pocket expenses of Cargill shall be reimbursed by Bioamber. Bioamber shall have no liability
to Cargill for Bioamber's acts or failure to act with respect to such patent application or
issued/granted patent.

5.2.5 Cargill shall have the sole power to bring and/or settle suits for infringement of any and all
patent applications and/or patents on Improvements, regardless of ownership; provided, however, if
required by law, Cargill shall join Bioamber, and Bioamber shall be joined, in such suits. Cargill
shall control any such suits and shall bear all expenses related to any such suits. Bioamber shall
provide any assistance reasonably requested in prosecuting and enforcing any and all patent
applications and/or patents on Improvements. In the event Cargill elects not to initiate and
prosecute suits for infringement of any patent application/and or patent onImprovement within the
Field, then with sixty (60) days prior written notice to Cargill, Bioamber shall be entitled to
initiate and prosecute such suits. For purposes of clarity, within such sixty (60) day period,
Cargill shall be entitled to initiate and prosecute such suits.
<!-- page 9 -->
Cargill Confidential - 9 - * Confidential treatment requested

5.2.6 Cargill shall have the sole power to settle suits for infringement of the Licensed Patents.
Cargill will in good faith consider enforcement requests from Bioamber.

5.2.7 Improvements are to be considered Confidential Information of the owning Party subject to the
terms and conditions of Section 4, provided that the Party authorized hereunder to file and
prosecute patent applications for an Improvement may make disclosure of that Improvement to outside
patent counsel and to relevant patent offices as reasonably necessary for filing and prosecution of
a patent application.

5.3 In consideration of the ownership rights granted to Bioamber under this Section 5, and the
licenses granted to Bioamber under this Section 5 and the Commercial License attached as Exhibit D,
Bioamber agrees to the payment terms and its other obligations contained in the attached Commercial
License.

6. WRF Patents. Washington Research Foundation (WRF) is the owner of several patents relating to the
expression of polypeptides in yeast ("WRF Patents"). Prior to transferring CB1 or any other yeast
strain to Bioamber, Bioamber shall provide to Cargill a letter from WRF stating that Bioamber has a
license to the WRF Patents ("Bioamber-WRF License"). Upon receipt of such letter, Cargill will
transfer CB1 to Bioamber for Bioamber's use of the strain commensurate with and in accordance with
the Bioamber-WRF License. Cargill shall have no liability to Bioamber for Bioamber's acts or failure
to act with respect to the WRF Patents. 7. Warranties. Except as provided in Section 1.2 of this
Development Agreement, Cargill makes no representations or warranties, express or implied, with
respect to the services provided under this Development Agreement and with respect to the subject
matter of this Development Agreement. The services are provided "as is" and Bioamber acknowledges
that it bears all responsibility and accountability for evaluating, approving, and implementing any
of results resulting from this Development Agreement.

8. Indemnification. Bioamber and Cargill agree to waive any and all claims against each other for
consequential, punitive, incidental, special, or other forms of "exemplary" losses whether arising
in contract, warranty, tort (including negligence), strict liability, or otherwise, including any
losses relating to lost use, lost profits, lost business, damage to reputation, or lost or
diminished financing unless such claims are based on a Party's gross negligence or willful
misconduct. 9. Notices. All notices or other communication must be in writing and delivered by (a)
personal delivery, (b) reputable overnight delivery service, or (c) facsimile or e-mail, confirmed
under clause (a) or clause (b), and addressed in each case as set forth below:
<!-- page 10 -->
Cargill Confidential - 10 - * Confidential treatment requested

If to Cargill: If to Bioamber:

Cargill, Incorporated Bioamber S.A.S. Bio Technology Development Center 1250 Rene-Levesque West
15285 Minnetonka Blvd. Suite 4110 Minnetonka, Minnesota 55345 USA Montreal, Quebec Canada H3B 4W8
Fax: 952-742-0540 Fax: 514-844-1414 Attention: Pirkko Suominen Attention: Laurent Bernier

With copy to: Cargill, Incorporated Law Department / Mailstop 24 15407 McGinty Road West Wayzata,
Minnesota 55391 USA Fax: 952-742-6349 Attention: Bio TDC IP Lawyer

With copy to: Boivin Desbiens Senécal, g.p. 2000-2000 McGill College Suite 2000 Montreal, QC, Canada
H3A 3H3 Fax: 514-844-5836 Attention: Thomas Desbiens

10. Term and Termination.

10.1 This Development Agreement will begin on the Effective Date and continue for four (4) years
unless earlier terminated pursuant to Section 10.2, or unless the parties extend the term by mutual
written Development Agreement ("Term"). 10.2 Either Party may terminate this Development Agreement
by giving written notice to the other Party, (a)in the event the other Party's bankruptcy,
insolvency, or the filing of a petition therefore; and (b) the other Party materially defaults in
the performance of its obligations hereunder. This Development Agreement shall also terminate upon
mutual written agreement by the Parties. Further, in the event there is a dispute as to whether or
not Cargill has missed a certain Milestone, then the Target Date for that Milestone shall be tolled
until the Parties, acting in good faith, have settled such dispute in writing between themselves or
through an independent expert.

11. Independent Contractor. Nothing in this Development Agreement is to be construed to deem the
relationship between the parties to be one of master/servant, principal/agent, or employer/employee.
To the contrary, the relationship of Cargill to Bioamber is that of independent contractor, and
Cargill will have no authority to (i) make any binding decision for, or on behalf of, Bioamber or
(ii) commit Bioamber to any contract, obligation, debt, or other liability. None of Cargill's
employees will be deemed to be employees of Bioamber. 12. Publicity. Any public statements related
to work performed under this Development Agreement, including public statements related to the
existence of this Development Agreement itself, will only be made after the prior written consent of
both Parties concerning timing, content, and audience.
<!-- page 11 -->
Cargill Confidential - 11 - * Confidential treatment requested

13. Miscellaneous.

13.1 Third Party Patents. In addition to the WRF Patents as described more fully in Section 6, the
CB1 Team of the Bio Technology Development Center of Cargill represents that, to the best of its
knowledge as of the Effective Date, the patents and patent applications of third parties that could
impact the Work Plan and the commercialization thereof are provided in Exhibit E ("Third Party
Patents"). Cargill shall have no liability to Bioamber for Bioamber's acts or failure to act with
respect to such Third Party Patents. The Parties shall meet regularly throughout the Term of this
Development Agreement to determine whether or not licenses to Third Party Patents are needed to
perform or continue to perform the Work Plan and the next steps if such licenses are needed.

13.2 Governing Law. This Development Agreement shall be governed by and construed in accordance with
the laws of the State of Minnesota, United States of America, disregarding its conflicts of law
rules.

13.3 Assignment. Neither Party shall assign this Development Agreement or the obligations contained
herein without the express written consent of the other Party.

13.4 Waiver. The failure of either Party to insist in any one or more instances upon performance of
any terms or conditions of this Development Agreement, is not to be construed as a waiver of future
performance of any such term, covenant, or condition, but the obligations of either Party with
respect thereto will continue in full force and effect. No waiver will be effective unless in
writing and signed by the waiving Party.

13.5 Amendment. No amendment, modification, or waiver of the terms of this Development Agreement
shall be binding unless placed in writing and duly executed by the Parties' authorized
representatives. 13.6 Severability. All provisions contained herein are severable, and in the event
any of them is held to be invalid by any competent court or arbitrator, this Development Agreement
is to be interpreted as if such invalid provision were not contained herein.

13.7 Survivability. Sections 4 (Confidentiality), 5 (Intellectual Property), 6 (WRF Patents), 7
(Warranties), 8 (Indemnification), 13.2 (Governing Law), and 13.7 (Survivability) will survive the
expiration or earlier termination of this Development Agreement.

13.8 Entire Agreement. This Development Agreement supersedes all previous understandings between
Cargill and Bioamber concerning the subject matter of this Development Agreement, including but not
limited to the Term Sheet executed by the Parties on December 3, 2009 and December 4, 2009, and the
Mutual Confidentiality Agreement between the Parties which was effective July 17, 2009, and,
together with its attachments, including the Commercial License Agreement attached hereto as Exhibit
D executed concurrently with this Development Agreement, contains the entire agreement between the
parties with respect to the subject matter hereof, and may not be amended, modified, or supplemented
except in writing and signed by both Parties specifically referring to this Development Agreement
and the Commercial License Agreement.

13.9 Bioamber Non-Compete Commitment. Bioamber will not itself or with or through third parties
engage in the development of biocatalysts other than E. coli for the production of succinic acid or
salts thereof, except for the development activities under the terms and conditions of this
Development Agreement. This obligation endures for the Term of this Development Agreement.
Notwithstanding the above, Bioamber shall be permitted to evaluate other biocatalysts, but shall not
undertake development of such biocatalysts. The purpose of such evaluations shall be to identify and
eventually secure alternative technologies, in the event that the CB1 development program is not
successful. As such, Bioamber shall cease within 30 days any further funding and development of a
biocatalyst, including but not limited to the genetic modification or the optimization of
fermentation conditions, when such biocatalyst has demonstrated the ability to produce succinic acid
at a concentration above [***] grams per liter. This restriction shall apply to any succinic acid
biocatalyst other than E. coli, be it a biocatalyst developed in-house, licensed-in, or under
development at a third party lab that is funded by Bioamber or to which Bioamber has secured a
future right or right of first refusal through direct payment, in kind contribution, grant, gift,
differed payment or commitment to a future payment.
<!-- page 12 -->
The Parties, through their authorized representatives, hereby agree to the terms and conditions of
this Development Agreement.

Cargill Confidential - 12 - * Confidential treatment requested

CARGILL, INCORPORATED Bio Technology Development Center BIOAMBER S.A.S.

/s/ Jack Staboch /s/ Jean-François Huc Signature Signature

VP BioTDC Director General Title Title

4/16/10 April 15, 2010 Date Date
<!-- page 13 -->
Exhibit A Work Plan Milestones

[***]

MILESTONE 1

[***] Time to achieve: Month 12

MILESTONE 2

[***] Time to achieve: Month 30

MILESTONE 3

[***] Time to achieve: Month 42 Cargill Confidential - 13 - * Confidential treatment requested
<!-- page 14 -->
Exhibit B Cargill Patents and Patent Applications

Cargill Confidential - 14 - * Confidential treatment requested

Publication # Title Filing Date Expiration Date

[***]

Publication # Title Filing Date Expiration Date

[***]

Publication # Title Filing Date Expiration Date

[***]

Publication # Title Filing Date Expiration Date

[***]

Publication # Title Filing Date Expiration Date

[***]

Publication # Title Filing Date Expiration Date

[***]
<!-- page 15 -->
Exhibit C Licensed Tool Kit

Basic Package Content:

Additional Fee Option Content:

Cargill Confidential - 15 - * Confidential treatment requested

• [***] • [***] • [***] • [***] • [***]

• The price will be negotiated, but as of the Effective Date of this Agreement, the fair market
value is base package price of US $[***]

• Genome sequence of CB1, including assembly and annotations as is Cargill's state of the art at the
time of the request.

• The price will be negotiated, but as of the Effective Date of this Development Agreement, the fair
market value is price of US $[***]
<!-- page 16 -->
EXHIBIT D

COMMERCIAL LICENSE AGREEMENT Cargill Confidential - 16 - * Confidential treatment requested
<!-- page 17 -->
EXHIBIT E Third Party Patents relating to the Work Plan

Third Party Patents relating to Modified Work Plan

Cargill Confidential - 17 - * Confidential treatment requested

Publication number and title Assignee [***]

Publication number and title Assignee [***]
<!-- page 18 -->
EXHIBIT F Cargill's Guiding Principles

Cargill's Compliance Policy on Intellectual Property

[*** 2 pages omitted.] Cargill Confidential - 18 - * Confidential treatment requested

• Cargill will comply with the laws of all countries to which it is subject. • Cargill will not
knowingly assist any third party to violate any law of any country, by creating false documents or
by any other means. • Cargill will not pay or receive bribes or participate in any other unethical,
fraudulent, or corrupt practice. • Cargill will always honor all business obligations that it
undertakes with absolute integrity. • Cargill will keep its business records in a manner that
accurately reflects the true nature of its business transactions.

• Cargill managers and supervisors will be responsible that employees, consultants and contract
workers under their supervision are familiar with applicable laws and company policies and comply
with them. Further, they will be responsible for preventing, detecting, and reporting any violations
of law of Cargill policies. • Cargill employees will not become involved in situations that create a
conflict of interest between the company and the employee. • Every year, all Cargill employees sign
an agreement to live these principles.
