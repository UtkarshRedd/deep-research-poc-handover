<!-- page 1 -->
# AGENCY AGREEMENT
| Field | Value |
|---|---|
| Document Type | Agency Agreement |
| Agreement Date | 1999-05-25 |
| Parties | Mutual Insurance Corporation of America (MICOA); Stratton, Cheeseman & Walsh-Nevada, Inc. ("Agency"); (sometimes commonly referred to as the Parties) |
| Source | CUAD v1 / AMERICANPHYSICIANSCAPITALINC_03_31_2003-EX-10.26-AGENCY AGREEMENT |

EXHIBIT 10.26 MICOA AGENCY AGREEMENT

Mutual Insurance Corporation of America, a Michigan insurance corporation (MICOA) and Stratton,
Cheeseman & Walsh-Nevada, Inc., a Nevada corporation, ("Agency"), (sometimes commonly referred to as
the Parties) agree as follows:

A. AUTHORITY OF AGENCY

Subject to requirements imposed by law, the underwriting rules, procedures and regulations of MICOA
and this agreement, the Agency is authorized to:

1. Solicit within the State of Nevada, receive and transmit immediately and directly to MICOA,
proposals for health care liability insurance contracts for which a commission is specified in the
schedule of commissions provided by Exhibit A, attached and as amended or supplemented by such
attachments from time to time.

2. Produce and deliver certificates of insurance and written binders in accordance with MICOA
underwriting requirements. The Agency is not authorized to accept or bind any risk or to otherwise
obligate MICOA without specific authority from MICOA.

3. Provide all usual and customary services of an Agency on all policies placed with MICOA subject
to the following:

a. MICOA will not be responsible for Agency expenses including but not limited to rent,
transportation, employee hire or solicitor's fees, postage, telegrams, telephone, advertising,
licensing fees or any other Agency expenses whatsoever.

b. The Agency will not undertake or initiate advertising of any nature in connection with business
or policies related to MICOA without the approval of MICOA.

4. To promptly report all claims and losses of which the Agency has knowledge and properly notify
MICOA when the Agency receives notice of the commencement of any related legal action. Agency shall
refrain from admitting or denying liability on the part of the company in connection with any claim
or lawsuit.

5. In return for the exclusive appointment of Agency by MICOA to sell its professional liability
products listed on the &sbsp;attached Commission Schedule

in Nevada, Agency agrees not to sell any competing professional liability products in Nevada,
without the written consent of MICOA. Provided that, if a particular risk has been submitted to
MICOA and MICOA has declined that risk, then Agency may search appropriate markets for placement of
that risk, and may place that risk with another insurance company.

6. Designated Agent representatives upon request from MICOA will be expected to participate in
MICOA's Nevada Market Managers Group activities and to attend all scheduled meetings.

7. MICOA will share on a project basis development costs of all promotional materials and some
advertising costs related to Nevada sales, provided that all such expenditures or budgets for them
are approved by MICOA in writing in advance.

8. Agency may solicit subagencies for appointment, subject to MICOA's prior written approval of each
subagency following disclosure to and review by MICOA of information requested by MICOA for each
proposed subagency. All such appointments by Agent shall stipulate that MICOA may terminate the
subagency at any time without cause upon at least 90 days notice and that the subagency shall comply
with all MICOA requirements and duties owed MICOA by Agency concerning solicitation, communications,
and service to insureds. Subagencies shall also be required to submit all proposals immediately and
directly to MICOA.

B. MICOA BILLED POLICIES

For business subject to Exhibit A, placed with and billed by MICOA directly to the policyholder, the
following shall apply in addition to all the other provisions of this agreement:

1. The processing and submittal of all such business shall be subject to provisions outlined in
MICOA's written requirements and forms as they may be implemented by MICOA from time to
<!-- page 2 -->
time;

2. Commissions on premiums shall be paid to the Agency within 30 business days of the month in which
such premiums are received and recorded by MICOA, subject to deduction by MICOA of any return
commissions due from the Agency.

3. Except as provided in Section D or unless authorized by the Agency, MICOA or its affiliates shall
not use its records of business placed by the Agency with MICOA to solicit individual policyholders
for the sale of other lines of

-2-

insurance or other products or services. When the Agency grants such authorization, Agency shall be
paid the applicable commission on such sales, provided an appropriate agreement is in place with
MICOA.

4. If this agreement is terminated, MICOA shall, at the Agency's request, provide the Agency with a
list of existing MICOA-billed policies placed by the Agency including their expiration dates.

5. The Agency's name shall appear on all policies, premium notices, and cancellation notices to
policyholders. Copies of all such items sent to policyholders shall be provided by MICOA to the
Agency.

C. POLICY CANCELLATION

Cancellation of any policy in force, when requested in writing by the insured, will be honored by
MICOA, except for those MICOA is not otherwise permitted to cancel.

D. EXPIRATIONS

1. In the event this Agreement is terminated for any reason, MICOA agrees to purchase from Agency,
and Agency agrees to sell to MICOA Agency's ownership interest in the expirations for the MICOA
insurance issued pursuant to this Agreement. The purchase price shall be two times Agency's
commissions on business produced directly by Agency during the last 12 full months preceding the
termination date. The purchase shall be completed within 60 calendar days after the termination
date. In return for this payment, for a two-year period following the termination date, Agency will
not directly or indirectly sell any professional liability insurance to any individuals or entities
who were MICOA insureds in Nevada at the time of termination of this Agreement.

2. If Agency enters into a subagency agreement under which the subagency has the right to retain
ownership of expirations on business produced by the subagency, then the purchase of expirations
under subparagraph 1 above will not include the purchase of those subagency expirations, and the
purchase price paid to Agency will not include the commissions paid for such business produced by
the subagency.

-3-

E. AGENCY'S ERRORS AND OMISSION, AND FIDELITY & ELECTRONIC CRIME INSURANCE

The Agency will maintain valid errors and omissions insurance, with minimum limits of $1,000,000 per
incident, and a fidelity and electronic crime policy through an insurer, both of which shall contain
terms and limits of coverage acceptable to MICOA covering the Agency's solicitors and each of its
employees. The Agency shall provide MICOA a copy of each policy; doing so on a regular and current
basis shall be a precondition to all of Agency's rights under this Agreement, including but not
limited to the payment of all earned commissions.

F. TERMINATION OF AGREEMENT

1. This agreement shall terminate:

a. Automatically if any public authority cancels or declines to renew the Agency's license or
Certificate of Authority.

b. Immediately if either party gives detailed written notice to the other of alleged gross and
willful misconduct, fraud or material misrepresentation.

2. This Agreement shall terminate, subject to any automatic renewal or extension for one year as
required by law, upon either party giving at least one hundred twenty (120) days advance written
notice to the other, if not otherwise contrary to applicable law or this Agreement.

3. If the Agency is delinquent in either accounting or payment of
<!-- page 3 -->
monies due MICOA, MICOA may by written notice to the Agency immediately terminate, suspend or modify
any of the provisions of this agreement. Such action shall not be taken by MICOA over minor
differences between the records of the Agency and MICOA.

4. All supplies, including forms and policies furnished by MICOA and any copies or other
reproductions of them, shall remain the property of MICOA and shall be returned to MICOA or its
representative upon demand.

G. INDEMNIFICATION

The respective parties shall indemnify and hold one another harmless as follows:

-4-

1. MICOA shall indemnify and hold Agency harmless against any MICOA act or omission, except to the
extent the Agency has caused, compounded, or contributed to such error.

2. Agency shall indemnify and hold Agency harmless against any act or omission of the Agency, except
to the extent MICOA has caused, compounded, or contributed to such error.

3. The Agency and MICOA shall properly notify one another upon receiving notice of the commencement
of any action related to such liabilities. MICOA shall be entitled to participate in any such action
or in consultation with Agency and its carrier to assume the defense of any such action. If MICOA
assumes the defense of any such action, it shall not be liable to the Agency for any legal or other
expenses subsequently incurred on the Agency's behalf absent MICOA's advance approval of such
expenses.

4. Neither party shall, except at its own risk and expense, voluntarily assume any liability, make
any payment or incur any expense without the prior written consent of the other.

H. POTENTIAL OPPORTUNITIES

1. Other Programs. Agency and MICOA agree that Agency may be offered the opportunity to support
MICOA's workers' compensation, and its other nonphysician professional liability or product programs
in Nevada when MICOA proceeds with related marketing plans. Such plans may also include Agency's
involvement in sales of MICOA commercial and personal products. Appropriate agreements must be
negotiated separately from this agreement for each such product, and for each such territory,
including but not limited to Nevada.

2. Territory. Agency and MICOA further agree to consider, subject to successful negotiation of
appropriate agreements separate from this agreement, expansion of Agencies' sales territories for
MICOA beyond Nevada.

I. MISCELLANEOUS

1. Amendment. This agreement may be amended only in writing by mutual agreement of the Agency and
MICOA, except that MICOA's name herein shall be deemed changed automatically for purposes of this
agreement without written amendment upon approval of any such change by MICOA's domiciliary
regulator.

2. Non Waiver. Any failure by MICOA to insist upon compliance with any provisions of this Agreement
or of the rules and regulations of MICOA shall not be construed as or constitute a waiver of them by
MICOA.

-5-

3. Integrated Agreement. This Agreement and its attachments as modified from time to time supersedes
and replaces as of its effective date, all previous agreements, if any, between MICOA and the
Agency. There are other agreements between MICOA and the Agency's parent corporation, SC&W, which
are not superceded.

4. &bbsp; Independent Contractor. The Agency is an independent insurance Agency and independent
contractor, and not an employee, manager, officer or owner of MICOA.

5. Applicable Law. This Agreement shall be interpreted under the laws of the State of Nevada. Any
provisions of this Agreement or any amendments to the Agreement that are or become in conflict with
any applicable statutes or regulations shall be deemed to be amended to conform to those statutes or
regulations.

6. Counterparts. This Agreement and any Exhibits which require signatures may be executed in
counterparts which shall
<!-- page 4 -->
together be regarded as binding upon the Parties.

7. Authority. The persons signing below represent and warrant that they are duly authorized
representatives of the respective Parties, fully willing and able to execute this Agreement.

8. Assignment. MICOA may assign this Agreement to its parent, affiliate, or subsidiary corporations
who are licensed insurers upon written notice to Agency. Agency may not assign this Agreement
without the written permission of MICOA or its successors or assigns.

9. Resolution of Disputes. In the event of any dispute arising out of this Agreement, MICOA and
Agency agree to submit such dispute to arbitration as follows:

a. There shall be three arbitrators; one shall be selected by the Agency, one shall be selected by
MICOA, and a third shall be selected by those two arbitrators. If the two arbitrators cannot agree
on the selection of a third, American Arbitration Association's regional office closest to Agency's
main office shall be requested to appoint the third arbitrator.

b. The determination of the arbitrators shall be final and binding upon the Agency and MICOA.

c. Neither MICOA nor the Agency shall be entitled to punitive and/or exemplary damages.

-6-

d. The arbitration shall be conducted in accordance with the procedures of the above referenced
regional office of the American Arbitration Association. The Agency and MICOA shall pay the cost of
their arbitrator and share equally in the expense of the third arbitrator.

e. Either Party, may where permitted by the law of Nevada, enter judgment upon the arbitrators'
award.

10. Year 2000 Compliance. Agency must at times assure that any of its computers, data processing
systems, software components, and network arrangements use for MICOA business completely and
accurately, present, produce, store and calculate all dates after December 31, 1999; and that they
will not produce abnormally ending or incorrect results involving such dates as used in any forward
or regression data based functions. All such items must yield date-related functionalities and date
fields which accurately indicate the century and millennium and correctly perform all calculations
involving a four digit year field.

Signed and effective this 25th day of May, 1999.

AGENCY

By: /s/ Terrence L. Walsh ------------------------------------

Its: President

MICOA

By: /s/ Thomas C. Payne, M.D. ------------------------------------ Thomas C. Payne, M.D.
Secretary/Treasurer

-7-

EXHIBIT A

AGENCY AGREEMENT SCHEDULE OF COMMISSIONS AND WRITTEN PREMIUM

New Business Policies: 12% of the annual premium Renewal Policies: 12% of the annual premium

Appointed agents who are not a party to a current MICOA agency contract and/or
<!-- page 5 -->
are not affiliated with an agency which has an agency contract will receive a 1% commission rate for
all lines of business stated above.

Commission will decrease by .5% effective 10/1/99 as part of a repayment program under a project
memorandum dated 4/7/99. This decrease will stay in effect until SC&W reaches $10MM in premium or at
a maximum of 10 years.

-8-

April 7, 1999

Mr. Terrence Walsh Stratton, Cheeseman & Walsh, Inc. 1301 N. Hagadorn East Lansing, MI 48823

RE: NEVADA DEPARTMENT PROJECT MEMORANDUM

Dear Terry:

In response to MICOA's request to develop a complete insurance distribution system for Nevada,
including physicians professional liability and personal and commercial insurance by July 1999,
Stratton, Cheeseman & Walsh, Inc. (SC&W) has spent and will continue to spend a substantial amount
of time and money. In recognition that these expenditures will directly benefit MICOA, SC&W and
MICOA agree to the following:

- During the first two years of developing the Nevada distribution system, a portion of the start up
costs will be shared. Subject to compliance with a detailed budget developed by SC&W and MICOA,
these reimbursable costs shall include:

- Salaries and benefits for SCW-Nevada, Inc. employees and agents.

- 20% of your total personal benefits and salary, and 100% of your personal travel expenses incurred
with respect to the Nevada office, which respective percentages are intended to recognize your
personal support of MICOA's Nevada initiative.

- Legal expenses directly attributable to the Nevada initiative.

- Nevada office set up.

- Consultant's expenses paid by SC&W in direct support of the initiative.

- The above costs are to be designated and itemized in the preapproved budget and reimbursed by
MICOA at 100% for the first full year of development and 50% for the second year. It is agreed that
the first year began effective October 1, 1997.

- All other costs attributable to the normal operation of the Nevada insurance agency site are the
sole responsibility of SC&W.

- After the first two years (i.e. after October 1, 1999) all expenses will be borne by SC&W and
those amounts paid to SC&W during the first two years shall be repaid. Repayment shall be through
reduction of commissions due SC&W by 0.5% or if

-7-

SC&W exceeds $10.0 million in premium revenues by offset in the event any money is owed the Agency
by MICOA. Such reduction or offset shall occur for so long as necessary to repay amounts reimbursed
by MICOA during the two-year period of development; but in no event will repayment be collected for
a period of greater than ten years. Any unpaid amounts at the end of ten years shall be forgiven by
MICOA.

- Nevada rent expenses will be shared on a 50/50 basis between MICOA and SC&W.

- In order to allow SC&W to expand the distribution system in Nevada with select and controlled
subagents, an exclusive agency agreement will be negotiated which will spell out the terms and
conditions of the relationship. A commission rate of 12% will be paid for both new and renewal
physicians liability business. Other commission rates will be determined as products become
available. This Agency Agreement should be finalized by April 30, 1999.

- MICOA may pay future payments advanced pursuant to this letter on a monthly basis, unless doing so
would be impractical, in which case another periodic form of&bbsp;payment will be arranged. Amounts
owed for past time periods will be paid as follows: one-third by March 25, 1999; one-third by May 1,
1999; and one-third by June 1, 1999. All other amounts owed under this Project Memorandum to be paid
by October 1, 1999.

SC&W's responsibilities, under this Project Memorandum, will include assisting MICOA with market
assessment, distribution, and sales integration into Nevada. SC&W agrees not to serve in a strategic
marketing capacity for another insurer
<!-- page 6 -->
in Nevada while it is providing such services for MICOA or for a period of one year thereafter.

Terry, please countersign and return this letter to indicate your acceptance.

Sincerely,

MUTUAL INSURANCE CORPORATION OF AMERICA

/s/ Thomas C. Payne, M.D. ----------------------------------------- Thomas C. Payne, M.D.
Secretary/Treasurer

ACCEPTED AND AGREED TO: STRATTON, CHEESEMAN & WALSH, INC.

/s/ Terrence L. Walsh ----------------------------------------- Terrence L. Walsh CEO
