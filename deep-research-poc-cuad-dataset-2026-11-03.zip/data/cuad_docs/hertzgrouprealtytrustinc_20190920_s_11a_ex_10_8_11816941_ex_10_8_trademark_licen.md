<!-- page 1 -->
# FORM OF TRADEMARK LICENSE AGREEMENT
| Field | Value |
|---|---|
| Document Type | License Agreement |
| SEC Filing Date | 2019-09-20 |
| Parties | HERTZ INVESTMENT GROUP, LLC ("Licensor"); HERTZ GROUP REALTY TRUST, INC. ("Licensee" and together with Licensor, the "Parties") |
| Source | CUAD v1 / HertzGroupRealtyTrustInc_20190920_S-11A_EX-10.8_11816941_EX-10.8_Trademark License Agreement |

Exhibit 10.8 FORM OF TRADEMARK LICENSE AGREEMENT This TRADEMARK LICENSE AGREEMENT ( "Agreement"), is
entered into as of September ___, 2019 ("Effective Date"), by and between HERTZ INVESTMENT GROUP,
LLC, a Delaware limited liability company, having a principal place of business at 21860 Burbank
Blvd., Suite 300 South, Woodland Hills, CA 91367 ("Licensor"), and HERTZ GROUP REALTY TRUST, INC., a
Maryland corporation, having a principal place of business at 21860 Burbank Blvd., Suite 300 South,
Woodland Hills, CA 91367 ("Licensee" and together with Licensor, the "Parties"), and the Parties
agree as follows: ARTICLE 1. BACKGROUND AND DEFINITIONS 1.1 Licensor has adopted, is using, and is
the owner of all right, title, and interest in the Licensed Mark (as defined in Article 1.6) in the
United States for financial services. 1.2 Licensee is a real estate investment trust managed by
Hertz Group REIT Advisor, LLC, a Delaware limited liability company (the "Advisor"), an affiliate of
Licensor. 1.3 Licensee desires to use the Licensed Mark as part of, and in conjunction with, the
trade name Hertz Group Realty Trust, Inc. 1.4 Licensor desires to license the Licensed Mark to
Licensee to be used as part of, and in conjunction with, the trade name Hertz Group Realty Trust,
Inc., subject to the terms and conditions set forth in this Agreement. 1.5 "Control" means the
possession, directly or indirectly, of the power to direct or cause the direction of the management
or policies of a person or entity, whether through the ownership of voting securities, by contract
or otherwise. 1.6 "Licensed Mark" means the stylized mark "H", as depicted in the USPTO Registration
No. 5,283,875, attached hereto as Exhibit "A" and made a part hereof. 1.7 "Licensed Trade Name"
means the corporate name Hertz Group Realty Trust, Inc. and any variation thereof including the term
Hertz Group that is used by Licensed Users. 1.8 "Licensed User" and "Licensed Users" means Licensee
and Licensee's subsidiaries. ARTICLE 2. LICENSE GRANT AND CONDITIONS OF LICENSED USE 2.1 Licensor
hereby grants Licensed Users a nonexclusive, nontransferable, nonsublicensable, royalty-free
license, during the term of this Agreement, to use and display the Licensed Trade Name and the
Licensed Mark in the United States solely in connection with the Licensee's corporate name and
identifying mark.

LICENSEOR: HERTZ INVESTMENT GROUP, LLC 1 TRADEMARK LICENSE AGREEMENT LICENSEE: HERTZ GROUP REALTY
TRUST, INC.

Source: HERTZ GROUP REALTY TRUST, INC., S-11/A, 9/20/2019
<!-- page 2 -->
2.2 The Licensed Mark shall remain the exclusive property of Licensor and nothing in this Agreement
shall give Licensed Users any right or interest in the Licensed Mark except the licenses expressly
granted in this Agreement. 2.3 All of Licensor's rights in and to the Licensed Mark, including, but
not limited to, the right to use and to grant others the right to use the Licensed Mark, are
reserved by Licensor. 2.4 No license, right, or immunity is granted by either Party to the other,
either expressly or by implication, or by estoppel, or otherwise with respect to any trademarks,
copyrights, or trade dress, or other property right, other than with respect to the Licensed Trade
Name and the Licensed Mark in accordance with Article 2.1 of this Agreement. 2.5 All use of the
Licensed Mark by Licensed Users, and all goodwill associated with such use, shall inure to the
benefit of Licensor. 2.6 Licensed Users acknowledge that Licensor is the sole owner of all right,
title and interest in and to the Licensed Mark, and that Licensed Users have not acquired, and shall
not acquire, any right, title or interest in or to the Licensed Mark except the right to use the
Licensed Mark in accordance with the terms of this Agreement. 2.7 Licensed Users shall not register
the Licensed Mark in any jurisdiction without Licensor's express prior written consent, and Licensor
shall retain the exclusive right to apply for and obtain registrations for the Licensed Mark
throughout the world. 2.8 Licensed Users shall not challenge the validity of the Licensed Mark, nor
shall Licensed Users challenge Licensor's ownership of the Licensed Mark or the enforceability of
Licensor's rights therein. 2.9 Licensed Users shall use the Licensed Mark in a form which is in
accordance with sound trademark practice so as not to weaken the value of the Licensed Mark.
Licensed Users shall use the Licensed Mark in a manner that does not derogate, based on an objective
business standard, Licensor's rights in the Licensed Mark or the value of the Licensed Mark, and
shall take no action that would, based on an objective standard, interfere with, diminish or tarnish
those rights or value. 2.10 Licensed Users agree to cooperate with Licensor's preparation and filing
of any applications, renewals or other documentation necessary or useful to protect and/or enforce
Licensor's intellectual property rights in the Licensed Mark. 2.10.1 Licensed Users shall notify
Licensor promptly of any actual or threatened infringements, imitations or unauthorized uses of the
Licensed Mark of which Licensed Users become aware. 2.10.2 Licensor shall have the sole right,
though it is under no obligation, to bring any action for any past, present and future infringements
of its intellectual property rights in the Licensed Mark. 2.10.3 Licensed Users shall cooperate with
Licensor, at Licensor's expense for any out-of-pocket costs incurred by Licensed Users, in any
efforts by Licensor to enforce its rights in the Licensed Mark or to prosecute third party
infringers of the Licensed Mark. 2.10.4 Licensor shall be entitled to retain any and all damages and
other monies awarded or otherwise paid in connection with any such action.

LICENSEOR: HERTZ INVESTMENT GROUP, LLC 2 TRADEMARK LICENSE AGREEMENT LICENSEE: HERTZ GROUP REALTY
TRUST, INC.

Source: HERTZ GROUP REALTY TRUST, INC., S-11/A, 9/20/2019
<!-- page 3 -->
ARTICLE 3. TERM AND TERMINATION 3.1 Either Party may terminate this Agreement by giving the other
Party thirty (30) days' prior written notice. 3.2 This Agreement and all rights and licenses granted
under this Agreement shall terminate as soon as practicable, but no longer than thirty (30) days,
after: 3.2.1 Licensee is acquired by a third party; or 3.2.2 Licensor or any affiliate of Licensor
ceases to manage Licensee. 3.3 Upon termination of this Agreement, Licensed Users shall immediately
cease use of the Licensed Trade Name and Licensed Mark as soon as practicable, but no longer than
thirty (30) days, after termination. ARTICLE 4. GENERAL PROVISIONS 4.1 Indemnification. Licensed
Users, at Licensed Users' own expense, shall indemnify, hold harmless and defend Licensor, its
affiliates, successors and assigns, and its and their directors, officers, employees and agents,
against any claim, demand, cause of action, debt, expense or liability (including attorneys' fees
and costs), to the extent that the foregoing (a) is based on a claim resulting solely from any
service provided or offered by Licensed Users, (b) results from a material breach, or is based on a
claim that, if true, would be a material breach, of this Agreement by Licensed Users, or (c) is
based upon Licensed Users' unauthorized or improper use of the Licensed Mark. 4.2 LIMITATION OF
WARRANTY AND LIABILITY. LICENSOR DOES NOT MAKE WARRANTIES OF ANY KIND, WHETHER EXPRESS, IMPLIED,
RELATED TO OR ARISING OUT OF THE LICENSED MARK OR THIS AGREEMENT. 4.2.1 LICENSOR SPECIFICALLY
DISCLAIMS ANY IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE,
NON-INFRINGEMENT AND TITLE, AND ALL OTHER WARRANTIES THAT MAY OTHERWISE ARISE FROM COURSE OF
DEALING, USAGE OF TRADE OR CUSTOM. 4.2.2 IN NO EVENT SHALL LICENSOR OR ANY OF ITS DIRECTORS,
OFFICERS, EMPLOYEES, LICENSORS, SUPPLIERS OR OTHER REPRESENTATIVES BE LIABLE FOR ANY INDIRECT,
SPECIAL OR CONSEQUENTIAL DAMAGES, OR DAMAGES FOR LOSS OF PROFITS, BUSINESS INTERRUPTION, LOSS OF
GOODWILL, COMPUTER FAILURE OR MALFUNCTION OR OTHERWISE, ARISING FROM OR RELATING TO THIS AGREEMENT
OR THE LICENSED MARK, EVEN IF LICENSOR IS EXPRESSLY ADVISED OF THE POSSIBILITY OF SUCH DAMAGES. The
foregoing limitation of liability and exclusion of certain damages shall apply regardless of the
failure of essential purpose of any remedies available to either party.

LICENSEOR: HERTZ INVESTMENT GROUP, LLC 3 TRADEMARK LICENSE AGREEMENT LICENSEE: HERTZ GROUP REALTY
TRUST, INC.

Source: HERTZ GROUP REALTY TRUST, INC., S-11/A, 9/20/2019
<!-- page 4 -->
4.3 Non-Transferable Agreement. Licensed Users may not assign this Agreement and/or any rights
and/or obligations hereunder without the prior written consent of Licensor and any such attempted
assignment shall be void. 4.4 Remedies. Licensed Users acknowledge that a material breach of
Licensed Users' obligations under this Agreement would cause Licensor irreparable damage.
Accordingly, Licensed Users agree that in the event of such breach or threatened breach, in addition
to remedies at law, Licensor shall have the right to enjoin Licensed Users from the unlawful and/or
unauthorized use of the Licensed Trade Name and/or the Licensed Mark and other equitable relief to
protect Licensor's rights in the Licensed Mark. 4.5 Integration. This Agreement contains the entire
agreement of the Parties. No promise, inducement, representation or agreement, other than as
expressly set forth herein, has been made to or by the Parties hereto. All prior agreements and
understandings related to the subject matter hereof, whether written or oral, are expressly
superseded hereby and are of no further force or effect. 4.6 Binding Agreement. This Agreement shall
be binding upon the Parties' permitted assigns and successors and references to each Party shall
include such assigns and successors. 4.7 Amendment. This Agreement cannot be altered, amended or
modified in any respect, except by a writing duly signed by both Parties. 4.8 No Strict
Construction. The normal rule of construction to the effect that any ambiguities are to be resolved
against the drafting Party shall not be employed in the interpretation of this Agreement. Headings
are for reference and shall not affect the meaning of any of the provisions of this Agreement. 4.9
Waiver. At no time shall any failure or delay by either party in enforcing any provisions,
exercising any option, or requiring performance of any provisions, be construed to be a waiver of
same. 4.10 Governing Law and Jurisdiction. The provisions of this Agreement shall be governed by and
construed in accordance with the laws of the State of California (excluding any conflict of law rule
or principle that would refer to the laws of another jurisdiction). Each Party hereto irrevocably
submits to the jurisdiction of the state and federal courts located in California, in any action or
proceeding arising out of or relating to this Agreement, and each Party hereby irrevocably agrees
that all claims in respect of any such action or proceeding must be brought and/or defended in any
such court; provided, however, that matters which are under the exclusive jurisdiction of the
federal courts shall be brought in the Federal District Court for the Central District of
California. Each Party hereto consents to service of process by any means authorized by the
applicable law of the forum in any action brought under or arising out of this Agreement, and each
Party irrevocably waives, to the fullest extent each may effectively do so, the defense of an
inconvenient forum to the maintenance of such action or proceeding in any such court.

LICENSEOR: HERTZ INVESTMENT GROUP, LLC 4 TRADEMARK LICENSE AGREEMENT LICENSEE: HERTZ GROUP REALTY
TRUST, INC.

Source: HERTZ GROUP REALTY TRUST, INC., S-11/A, 9/20/2019
<!-- page 5 -->
4.11 Attorney's Fees. In the event any suit or other legal proceeding is brought for the enforcement
of any of the provisions of this Agreement, the Parties hereto agree that the prevailing party shall
be entitled to recover from the other party upon final judgment on the merits reasonable attorneys'
fees (and sales taxes thereon, if any), including attorneys' fees for any appeal, and costs incurred
in bringing such suit or proceeding. 4.12 Relationship of the Parties. Nothing in this Agreement
will be construed as creating a joint venture, partnership, or employment relationship between
Licensor and Licensee or any of Licensee's subsidiaries. Neither Party will have the right, power or
implied authority to create any obligation or duty on behalf of the other Party. 4.13 Notices.
Unless otherwise specified in this Agreement, all notices shall be in writing and delivered
personally, mailed, first class mail, postage prepaid, or delivered by confirmed electronic or
digital means, to the addresses set forth at the beginning of this Agreement and to the attention of
the undersigned. Either Party may change the addresses or addressees for notice by giving notice to
the other. All notices shall be deemed given on the date personally delivered, when placed in the
mail as specified or when electronic or digital confirmation is received. 4.14 Counterparts. This
Agreement may be executed in counterparts, by manual or facsimile signature, each of which will be
deemed an original and all of which together will constitute one and the same instrument.
[Signatures on following page]

LICENSEOR: HERTZ INVESTMENT GROUP, LLC 5 TRADEMARK LICENSE AGREEMENT LICENSEE: HERTZ GROUP REALTY
TRUST, INC.

Source: HERTZ GROUP REALTY TRUST, INC., S-11/A, 9/20/2019
<!-- page 6 -->
IN WITNESS WHEREOF, the parties hereto have caused this Agreement to be executed as of the day and
year first above written. LICENSOR LICENSEE HERTZ INVESTMENT GROUP, LLC HERTZ GROUP REALTY TRUST,
INC. a Delaware limited liability company a Maryland corporation (Signature) (Signature) John D.
Forbess, Executive VP/Secretary John D. Forbess, Executive VP/Secretary

LICENSEOR: HERTZ INVESTMENT GROUP, LLC Signature Page TRADEMARK LICENSE AGREEMENT LICENSEE: HERTZ
GROUP REALTY TRUST, INC.

Source: HERTZ GROUP REALTY TRUST, INC., S-11/A, 9/20/2019
<!-- page 7 -->
EXHIBIT "A" USPTO REGISTRATION NO. 5,283,875 See Attached.

LICENSEOR: HERTZ INVESTMENT GROUP, LLC Exhibit "A" TRADEMARK LICENSE AGREEMENT LICENSEE: HERTZ GROUP
REALTY TRUST, INC.

Source: HERTZ GROUP REALTY TRUST, INC., S-11/A, 9/20/2019
