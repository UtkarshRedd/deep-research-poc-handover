<!-- page 1 -->
# CO-BRANDING AGREEMENT (FORM)
| Field | Value |
|---|---|
| Document Type | Co-Branding Agreement |
| Agreement Date | 1999-11-05 |
| Parties | NETTAXI Online Communities, Inc. ("NETTAXI"); Solutions Media, Inc.(dba SpinRecords.com, "SpinRecords.com" or "Client") |
| Source | CUAD v1 / RaeSystemsInc_20001114_10-Q_EX-10.57_2631790_EX-10.57_Co-Branding Agreement |

CO-BRANDING AGREEMENT (FORM)

This CO-BRANDING AGREEMENT (the "Agreement") is made and entered into as of Nov 5, 1999, (the
"Effective Date") by and between NETTAXI Online Communities, Inc., a Delaware corporation with
principal offices at 2165 S. Bascom Avenue, Campbell, California 95008 ("NETTAXI"), and Solutions
Media, Inc., dba SpinRecords.com a Delaware Corporation, with offices at 11440 West Barnardo Ct.,
Suite 170, San Diego, CA 32127 ("SpinRecords.com" or "Client").

RECITALS

A. NETTAXI is in the business of providing entertainment, education, and information services over
the world wide web through its Internet web site at http://www.NETTAXI.com.

B. SpinRecords.com is in the business of providing entertainment and information services over the
World Wide Web through its internet website at http://www.spinrecords.com.

C. NETTAXI and SpinRecords.com desire co-brand their services under the terms and conditions set
forth herein.

AGREEMENT

NOW, THEREFORE, in consideration of the mutual promises contained herein, the parties hereby agree
as follows:

1. DEFINITIONS

1.1 "Spinrecords.com Brand Features" means the SpinRecords.com name and logo and other trademarks,
trade names and service names including but not limited to those set forth on Exhibit A attached
hereto and incorporated herein --------- by reference and all Intellectual Property Rights related
thereto. SpinRecords.com Brand Features shall include any derivatives, improvements or modifications
thereto or thereof and any Intellectual Property rights related thereto.

1.2 "SpinRecords.com Pages" means the SpinRecords.com Web-based pages that incorporate certain
SpinRecords.com services, as the same may be updated or modified from time to time in
SpinRecords.com's sole discretion, currently located at http://www.spinrecords.com.

1.3 "Impressions" means the loading of all or part of a Web page into the browser of a User.

1.4 "Intellectual Property Rights" means all current and future worldwide trademark, patents and
patent rights, utility models, copyrights, mask work rights, trade secrets, and all other
intellectual property rights and the related documentation or other tangible expression thereof.

1.5 "NETTAXI Brand Features" means the NETTAXI name and logo and any other trademarks, trade names
and service names of NETTAXI, including but not limited to those set forth on Exhibit B attached
hereto and incorporated herein --------- by reference and all Intellectual Property Rights related
thereto. NETTAXI Brand Features shall include any derivatives, improvements or modifications thereto
or thereof and any Intellectual Property rights related thereto.

1.6 "NETTAXI Pages" means the NETTAXI's Web-based pages that incorporate certain NETTAXI services,
as the same may be updated or modified from time to time in NETTAXI's sole discretion, currently
located at http://www.NETTAXI.com.

1.7 "Statement of Work" means the Statement of Work attached hereto as Exhibit C and incorporated
herein by reference. ----------

1.8 "User" means a person using a software browser to view the World Wide Web.

2. CO-BRANDING, MARKETING AND PROMOTION

2.1 The SpinRecords.com Pages. SpinRecords.com shall brand the ---------------------------

Source: RAE SYSTEMS INC, 10-Q, 11/14/2000
<!-- page 2 -->
SpinRecords.com Pages with the NETTAXI Brand Features in the manner set forth in the Statement of
Work. NETTAXI will provide electronic copies of the NETTAXI Brand Features upon SpinRecords.com's
request. All Spinrecords.com Pages shall display appropriate intellectual property legends,
including but not limited to the copyright notice and trademark references.

1

2.2 The NETTAXI Pages. NETTAXI shall brand certain NETTAXI Pages with ------------------ the
SpinRecords.com Brand Features in the manner set forth in the Statement of Work. SpinRecords.com
will provide electronic copies of the SpinRecords.com Brand Features upon NETTAXI's request. All
NETTAXI Pages shall display appropriate intellectual property legends, including but not limited to
the copyright notice and trademark references. NETTAXI shall not be obligated to co-brand those
pages containing content which NETTAXI has branded with a third party which: (i) NETTAXI is
prohibited from co-branding pursuant to another agreement; (ii) NETTAXI is technically unable to
co-brand; or (iii) are commercially unreasonable, in NETTAXI's discretion, to co-brand.

2.3 Marketing by SpinRecords.com. Throughout the term of this ------------------------------
Agreement, SpinRecords.com shall use reasonable commercial efforts to market the NETTAXI Brand
Features in order to maximize the number of visitors to the NETTAXI Pages in accordance with the
Statement of Work. The parties shall review the Statement of Work and NETTAXI's marketing activities
on a quarterly basis in order to assess the performance and agree upon additional activities, if
necessary, in order to increase usage of the pages.

2.4 Marketing by NETTAXI. Throughout the term of this Agreement, ----------------------- NETTAXI
shall use reasonable commercial efforts to market the SpinRecords.com Brand Features in order to
maximize the number of visitors to the SpinRecords.com Pages in accordance with the Statement of
Work. The parties shall review the Statement of Work and Spinrecords.com's marketing activities on a
quarterly basis in order to assess the performance and agree upon additional activities, if
necessary, in order to increase usage of the pages.

2.5 Additional Statements of Work. If the parties hereto desire to --------------------------------
engage each other for additional services which are not included in the Statement of Work and which
do not constitute merely a revision or modification of the Statement of Work, the parties shall in
good faith negotiate additional Statements of Work, each of which upon signing shall be deemed a
part of this Agreement. Additional Statements of Work shall be entered into by mutual agreement
between NETTAXI and SpinRecords.com and shall be substantially in the form of the Statement of Work
attached hereto. Each Statement of Work shall be signed by authorized representatives of the
parties. This Agreement may cover more than one Statement of Work at any given time.

3. Licenses AND OWNERSHIP.

3.1 Licenses by NETTAXI to SpinRecords.com. NETTAXI hereby grants to
----------------------------------------- SpinRecords.com a non-exclusive, worldwide,
nontransferable, revocable, royalty free license to use the NETTAXI Brand Features as the same may
be modified from time to time for the purposes of this Agreement

3.2 Licenses by SpinRecords.com to NETTAXI. SpinRecords.com hereby
------------------------------------------- grants NETTAXI a nonexclusive, worldwide,
nontransferable, revocable, royalty free license to display and distribute the, and make derivative
works from the SpinRecords.com Brand Features and any enhancements, modifications or improvements
thereto as necessary to carry out the terms of this Agreement.

3.3 Ownership by NETTAXI. NETTAXI shall own all right, title, and ---------------------- interest in
the NETTAXI Brand Features, the NETTAXI Pages and all Intellectual Property Rights therein,
including any derivatives, improvements thereof, excluding the SpinRecords.com Brand Features

3.4 Ownership by SpinRecords.com. Except as otherwise set forth below, -----------------------------
SpinRecords.com shall own all right, title, and interest in the SpinRecords.com Brand Features and
the SpinRecords.com Pages and all Intellectual Property Rights therein, including any derivatives,
improvements thereof, excluding the NETTAXI Brand Features.

Source: RAE SYSTEMS INC, 10-Q, 11/14/2000
<!-- page 3 -->
3.5 Impressions. Neither party nor its employees shall take actions ---------- which will
artificially increase the number of Impressions on the party's web pages. For example, a party's
employees shall not repeatedly access the other party's web pages.

4. PAYMENT

4.1 Payment. In consideration of the duties and obligations of the ------- parties hereto,
SpinRecords.com shall pay NETTAXI in the manner set forth in the Statement of Work.

5. REPRESENTATIONS AND WARRANTIES.

5.1 Representations and Warranties of SpinRecords.com. SpinRecords.com
-------------------------------------------------- hereby represents and warrants to NETTAXI that:
(i) SpinRecords.com has the full power and authority to enter into this Agreement and to carry out
its obligations under this Agreement; (ii) SpinRecords.com has the full power and authority to grant
the rights and licenses granted to NETTAXI in this Agreement; and (iii) SpinRecords.com owns the
SpinRecords.com Brand Features.

2

5.2 Representations and Warranties of NETTAXI. NETTAXI hereby
--------------------------------------------- represents and warrants to SpinRecords.com that (i)
NETTAXI has the full power and authority to enter into this Agreement and to carry out its
obligations under this Agreement; (ii) NETTAXI has the full power and authority to grant the rights
and licenses granted to SpinRecords.com in this Agreement; and (iii) NETTAXI owns the NETTAXI Brand
Features.

5.3 THE NETTAXI SERVICES FURNISHED AS A RESULT OF OR UNDER THIS AGREEMENT ARE PROVIDED ON AN "AS IS"
BASIS, WITHOUT ANY WARRANTIES OR REPRESENTATIONS EXPRESS, IMPLIED OR STATUTORY; INCLUDING, WITHOUT
LIMITATION, WARRANTIES OF QUALITY, PERFORMANCE, NONINFRINGEMENT, MERCHANTABILITY OR FITNESS FOR A
PARTICULAR PURPOSE. NOR ARE THERE ANY WARRANTIES CREATED BY A COURSE OF DEALING, COURSE OF
PERFORMANCE OR TRADE USAGE. NETTAXI DOES NOT WARRANT THAT THE SERVICES, WILL MEET SPINRECORDS.COM'S
OR ANY END USERS NEEDS OR BE FREE FROM ERRORS, OR THAT THE OPERATION OF ITS WEB PAGES WILL BE
UNINTERRUPTED. THE FOREGOING EXCLUSIONS AND DISCLAIMERS ARE AN ESSENTIAL PART OF THIS AGREEMENT.

6. CONFIDENTIALITY.

6.1 Agreement as Confidential Information. The parties shall treat the
-------------------------------------- terms and conditions and the existence of this Agreement as
Confidential Information. Each party shall obtain the other's consent prior to any publication,
presentation, public announcement or press release concerning the existence or terms and conditions
of this Agreement.

6.2 Confidential Information. "Confidential Information" means all -------------------------
information identified in written or oral format by the Disclosing Party as confidential, trade
secret or proprietary information, and, if disclosed orally, summarized in written format within
thirty (30) days of disclosure. "Disclosing Party" is the party disclosing Confidential Information.
"Receiving Party" is the party receiving Confidential Information. The Receiving Party shall not
disclose the Confidential Information to any third party other than persons in the direct employ of
the Receiving Party who have a need to have access to and knowledge of the Confidential Information
solely for the purpose authorized above. Each party shall take appropriate measures by instruction
and agreement prior to disclosure to such employees to assure against unauthorized use or
disclosure. The Receiving Party shall have no obligation with respect to information which (i) was
rightfully in possession of or known to the Receiving Party without any obligation of
confidentiality prior to receiving it from the Disclosing Party; (ii) is, or subsequently becomes,
legally and publicly available without breach of this Agreement; (iii) is rightfully obtained by the
Receiving Party from a source other than the Disclosing Party without any obligation of
confidentiality; (iv) is disclosed by the Receiving Party under a valid order created by a court or
government agency, provided that the Receiving Party provides prior written notice to the Disclosing
Party of such obligation and the opportunity to oppose such disclosure. Upon written demand of the
Disclosing Party, the Receiving Party shall cease using the Confidential

Source: RAE SYSTEMS INC, 10-Q, 11/14/2000
<!-- page 4 -->
Information and return the Confidential Information and all copies, notes or extracts thereof to the
Disclosing Party within seven (7) days of receipt of notice.

7. INDEMNITY AND LIMITATION OF LIABILITY.

7.1 Indemnification by Spinrecords.com. SpinRecords.com shall defend,
------------------------------------ indemnify and hold NETTAXI harmless from any and all damages,
liabilities, costs and expenses (including, but not limited to reasonable attorneys' fees) incurred
by NETTAXI as a result of (i) any breach of this Agreement; (ii) any claim that the SpinRecords.com
Brand Features or any part thereof, infringes or misappropriates any Intellectual Property Right of
a third party; (iii) any claim arising out of NETTAXI's display of the SpinRecords.com Brand
Features; or (iv) the operation of the SpinRecords.com Pages. NETTAXI shall provide SpinRecords.com
with written notice of the claim and permit SpinRecords.com to control the defense, settlement,
adjustment or compromise of any such claim. NETTAXI may employ counsel at its own expense to assist
it with respect to any such claim; provided, however, that if such counsel is necessary because of a
conflict of interest of either SpinRecords.com or its counsel or because SpinRecords.com does not
assume control, SpinRecords.com will bear the expense of such counsel.

7.2 Indemnification by NETTAXI. NETTAXI shall defend, indemnify and ----------------------------
hold SpinRecords.com harmless from any and all damages, liabilities, costs and expenses (including,
but not limited to reasonable attorneys' fees) incurred by SpinRecords.com as a result of (1) any
breach of this Agreement; (ii) any claim that the NETTAXI Brand Features or any part thereof,
infringes or misappropriates any Intellectual Property Right of a third party; or (iii) any claim
arising out of Spinrecords.com's display of the NETTAXI Brand Features SpinRecords.com shall provide
NETTAXI with written notice of the claim and permit NETTAXI to control the defense, settlement,
adjustment or compromise of any such claim. SpinRecords.com may employ counsel at its own expense to
assist it with respect to any such claim; provided, however, that if such counsel is necessary
because of a conflict of interest of either NETTAXI or its counsel or because NETTAXI does not
assume control, NETTAXI will bear the expense of such counsel.

7.3 Limitation of Liability. EXCEPT AS SET FORTH IN SECTION 6 AND 7.1, ------------------------
UNDER NO CIRCUMSTANCES WILL EITHER PARTY BE LIABLE TO THE OTHER UNDER ANY CONTRACT, STRICT
LIABILITY, NEGLIGENCE OR OTHER LEGAL OR EQUITABLE THEORY, FOR ANY INCIDENTAL OR CONSEQUENTIAL
DAMAGES OR LOST PROFITS IN CONNECTION WITH THE SUBJECT MATTER OF THIS AGREEMENT.

3

8. TERM AND TERMINATION

8.1 Term of Agreement. This Agreement shall be effective upon the ------------------- Effective Date
and shall remain in force for a period of one (1) year, and shall be automatically renewed for
successive periods of one (1) year unless otherwise terminated as provided herein.

8.2 Convenience. NETTAXI may terminate this Agreement at any time for ----------- its convenience,
for no reason or for any reason, upon sixty (60) days prior written notice to SpinRecords.com. In
the event of such termination, Spinrecords.com shall be entitled to receive and retain all payments
made or payable by NETTAXI prior to the date of termination. SpinRecords.com may terminate this
Agreement for no reason or for any reason upon sixty (60) days prior written notice to NETTAXI.

8.3 Termination for Cause. This Agreement may be terminated by a party ---------------------- for
cause immediately upon the occurrence of and in accordance with the following:

(a) Insolvency Event. Either may terminate this Agreement by delivering written notice to the other
party upon the occurrence of any of the following events: (i) a receiver is appointed for either
party or its property; (ii) either makes a general assignment for the benefit of its creditors;
(iii) either party commences, or has commenced against it, proceedings under any bankruptcy,
insolvency or debtor's relief law, which proceedings are not dismissed within sixty (60) days; or
(iv) either party is liquidated or

Source: RAE SYSTEMS INC, 10-Q, 11/14/2000
<!-- page 5 -->
dissolved.

(b) Change of Control. In the event more that there is a change in ownership representing fifty
percent (50%) or more of the equity ownership of either party, the other party may, at its option,
terminate this Agreement upon written notice.

(c) Default. Either party may terminate this Agreement effective upon written notice to the other if
the other party violates any covenant, agreement, representation or warranty contained herein in any
material respect or defaults or fails to perform any of its obligations or agreements hereunder in
any material respect, which violation, default or failure is not cured within thirty (30) days after
notice thereof from the non-defaulting party stating its intention to terminate this Agreement by
reason thereof.

8.4 Survival of Rights and Obligations Upon Termination. Sections 6 and
--------------------------------------------------- 7 shall survive termination or expiration of
this Agreement. Notwithstanding anything in the foregoing to the contrary, in the case of
termination by NETTAXI for cause pursuant to Section 8.3 [Termination for Cause], NETTAXI shall not
be required to pay any fee to SpinRecords.com after termination.

8.5 Return of Materials Upon Termination. On or before ten (10) days
--------------------------------------- after the termination of this Agreement, SpinRecords.com
shall deliver to NETTAXI all NETTAXI Confidential Information and NETTAXI Brand Features, including
but not limited to all work product, diagrams, designs and schematics in Spinrecords.com's
possession and NETTAXI.com shall deliver to SpinRecords.com all SpinRecords.com Confidential
Information and SpinRecords.com Brand Features, including but not limited to all work product,
diagrams, designs and schematics in Nettaxi.com's possession

9. MISCELLANEOUS

9.1 Force Majeure. Neither party shall be liable to the other for -------------- delays or failures
in performance resulting from causes beyond the reasonable control of that party, including, but not
limited to, acts of God, labor disputes or disturbances, material shortages or rationing, riots,
acts of war, governmental regulations, communication or utility failures, or casualties.

9.2 Relationship of Parties. The parties are independent contractors ------------------------- under
this Agreement and no other relationship is intended, including a partnership, franchise, joint
venture, agency, employer/employee, fiduciary, master/servant relationship, or other special
relationship. Neither party shall act in a manner which expresses or implies a relationship other
than that of independent contractor, nor bind the other party.

9.3 No Third Party Beneficiaries. Unless otherwise expressly provided, -----------------------------
no provisions of this Agreement are intended or shall be construed to confer upon or give to any
person or entity other than NETTAXI and SpinRecords.com any rights, remedies or other benefits under
or by reason of this Agreement.

9.4 Equitable Relief. Each party acknowledges that a breach by the ----------------- other party of
any confidentiality or proprietary rights provision of this Agreement may cause the non-breaching
party irreparable damage, for which the award of damages would not be adequate compensation.
Consequently, the non-breaching party may institute an action to enjoin the breaching party from any
and all acts in violation of those provisions, which remedy shall be cumulative and not exclusive,
and a party may seek the entry of an injunction enjoining any breach or threatened breach of those
provisions, in addition to any other relief to which the non-breaching party may be entitled at law
or in equity.

4

9.5 Attorneys' Fees. In addition to any other relief awarded, the ---------------- prevailing party
in any action arising out of this Agreement shall be entitled to its reasonable attorneys' fees and
costs.

9.6 Notices. Any notice required or permitted to be given by either ------- party under this
Agreement shall be in writing and shall be personally delivered

Source: RAE SYSTEMS INC, 10-Q, 11/14/2000
<!-- page 6 -->
or sent by a reputable overnight mail service (e.g., Federal Express), or by first class mail
(certified or registered), or by facsimile confirmed by first class mail (registered or certified),
to the party at the address indicated above. Notices will be deemed effective (i) three (3) working
days after deposit, postage prepaid, if mailed, (ii) the next day if sent by overnight mail, or
(iii) the same day if sent by facsimile and confirmed as set forth above.

9.7 Assignment. Neither NETTAXI or SpinRecords.com shall assign its ---------- respective rights or
delegate its obligations hereunder, either in whole or in part, whether by operation of law or
otherwise, without the prior written consent of the other party. Any attempted assignment or
delegation without the other party's written consent will be void.

9.8 Waiver and Modification. Failure by either party to enforce any -------------------------
provision of this Agreement will not be deemed a waiver of future enforcement of that or any other
provision. Any waiver, amendment or other modification of any provision of this Agreement will be
effective only if in writing and signed by the parties.

9.9 Severability. if for any reason a court of competent jurisdiction ------------ finds any
provision of this Agreement to be unenforceable, that provision of the Agreement will be enforced to
the maximum extent permissible so as to effect the intent of the parties, and the remainder of this
Agreement will continue in full force and effect.

9.10 Controlling Law and Jurisdiction. This Agreement and any action
----------------------------------- related thereto shall be governed, controlled, interpreted and
defined by and under the laws of the State of California and the United States, without regard to
the conflicts of laws provisions thereof. Unless waived by NETTAXI (which it may do in its sole
discretion) the exclusive jurisdiction and venue of any action with respect to the subject matter of
this Agreement shall be the Superior Court of California for the County of Santa Clara or the United
States District Court for the Northern District of California and each of the parties hereto submits
itself to the exclusive jurisdiction and venue of such courts for the purpose of any such action.
The parties specifically disclaim the UN Convention on Contracts for the International Sale of
Goods.

9.11 Headings. Headings used in this Agreement are for ease of -------- reference only and shall not
be used to interpret any aspect of this Agreement.

9.12 Entire Agreement. This Agreement, including all exhibits which are ----------------
incorporated herein by reference, constitutes the entire agreement between the parties with respect
to the subject matter hereof, and supersedes and replaces all prior and contemporaneous
understandings or agreements, written or oral, regarding such subject matter.

9.13 Counterparts. This Agreement may be executed in two counterparts, ------------ each of which
shall be an original and together which shall constitute one and the same instrument.

IN WITNESS WHEREOF, the parties hereto have executed this Agreement by persons duly authorized as of
the date and year first above written.

NETTAXI: NETTAXI ONLINE COMMUNITIES, INC. By: /s/ --------------------------------------------- Its:
Executive Vice President Sales & Marketing --------------------------------------------

Solutions Media SOLUTIONS MEDIA, INC. ----------------------- By: /s/
--------------------------------------------- Its: President
---------------------------------------------

TABLE OF EXHIBITS

Source: RAE SYSTEMS INC, 10-Q, 11/14/2000

EXHIBIT A - SPINRECORDS.COM BRAND FEATURES EXHIBIT B - NETTAXI BRAND FEATURES EXHIBIT C - STATEMENT
OF WORK

5

EXHIBIT A

SPINRECORDS.COM BRAND FEATURES
<!-- page 7 -->
1. Service Marks: "SpinRecords.com" "SpinRadio" "Spin TV" "Local Spin" "Spin Chat" "Gig-a-board"
"Spin Cuts" "Spin Charts" "Join the evolution" "The promise of music on the Internet delivered" 2.
SpinRecords.com collateral and dress - SpinRecords.com color scheme, fonts and general "look and
feel" 3. SpinRecords.com logos 4. "Anything but that" cartoon series 5. SpinRecords.com source
materials 6. SpinRecords.com website

6

EXHIBIT B

NETTAXI BRAND FEATURES

1. Service Marks: "NETTAXI" "NETTAXI.COM" "NETTAXI ONLINE COMMUNITIES" "INTERNET THE CITY" "DRIVING
YOUR INTERNET EXPERIENCE" 2. Trade dress - Nettaxi color scheme and checkered motif; "look and feel"
3. Nettaxi logos 4. Nettaxi source materials 5. The Website

7

EXHIBIT C

STATEMENT OF WORK

1. GENERAL

This is a Statement of Work under the Co-Branding Agreement by and between NETTAXI Online
Communities, Inc. ("NETTAXI") and Solutions Media, Inc., ("SpinRecords.com") dated effective as of
Nov. 5, 1999.

2. PROJECT MANAGERS.

NETTAXI: Will Richards SPINRECORDS.COM: Criona Mclaughlin 2165 S. Bascom Avenue 11440 West Bernardo
Ct Campbell, California 95008 San Diego, California 92127 Phone: (408) 879-9880 Phone: (619)451-3223
Fax: (408) 879-9907 Fax: (619)451-2373

3. BRANDING METHODS

Spinrecords.com and Nettaxi.com will enter into a multi-phase launch of a co-branded community for
Nettaxi, and the implementation of community services for Spinrecords.com members. The following
defines the agreement after the final phase. The individual phases are specified following the
Marketing Section of the Statement of Work. 1) SpinRecords.com will develop a co-branded site
showing the Nettaxi.com logo. The co-branding shall not include SpinRadioTM, SpinTVTM, feature

Source: RAE SYSTEMS INC, 10-Q, 11/14/2000
<!-- page 8 -->
modules, and Spin branded charts. All other navigation bar features shall be modified to the
co-brand including localnettaxi, and nettaxichat. The spinwares and spinstore will be modified to
include licensed content purchased directly from Spinrecords.com and to eliminate products that will
compete with the Nettaxi store. 2) Spinrecords.com will incorporate from the navigation bar a link
from nettaxistores to the Nettaxi commerce site. 3) The co-branded nettaximusic store will contain
spingear, spingallery, spinmusic, and Kingdom Skateboard products and services. Spin agrees to pay
Nettaxi a 5% commission of the gross sales price on all transactions. 4) Spinrecords.com will
maintain the Spin logo on the site in a corner of their choice. 5) Nettaxi web based e-mail will
replace spinmail on the co-branded site. 6) Nettaxi's search engine shall be the default search
engine on the co-branded site and on the Spinrecords.com homesite, with the exception that, in the
event Spinrecords.com provides its content to or otherwise develops any co-branded sites with any
ISP, Internet Portal or other entity, Spinrecords.com shall not be required to employ the Nettaxi
search engine. In all cases in which the Nettaxi search engine is employed, the search shall first
deliver results found on the Spinrecords.com website. The search feature shall have the tag line
"Driven by Nettaxi" underneath the search bar. 7) Nettaxi shall cause its search engine to search
and deliver results from the SpinRecords.com site and co-branded site as one of the top results for
all searches for related words on the co-branded site, the SpinRecords.com homesite and the
Nettaxi.com site. Related words shall include, but not be limited to: "music," "mp3," "independent
artist/music" and "CD." 8) Nettaxi will create a music template for the Nettaxi homepage builder.
Every registered member of Spinrecords.com and Nettaximusic will be provided a dynamically generated
home page. Spinrecords.com will submit to Nettaxi the existing list of Spinrecords.com members from
which a homepage shall be generated. 9) Nettaximusic and Spinrecords.com will share registered users
by synchronizing the databases for registered users. Nettaxi will maintain unique ID's for each
community home page built in the Spinrecords.com domain and Nettaximusic.com domain (for the purpose
of the auto-generation of fan page templates). This synchronization shall not include any users that
arrive at SpinRecords.com through any other co-branded site or through any other means of
co-branding/co-marketing with any other ISP, Website or other entity. 10) Nettaxi will develop a
link from the Nettaxi Arts & Entertainment area for the co-branded site. 11) Nettaxi will add
Nettaximusic to the street sign on the A&E page. 12) Nettaxi will make the word "music" on the
splash page, under A&E a link, and have it link to nettaxi.spinrecords.com. the co-branded site. 13)
The co-branded site will have the Nettaxi mp3 player as an available mp3 player on the site. 14)
Spinrecords.com will place the Nettaxi logo on promotional CDROM's and Samplers that contain the
Nettaxi mp3 player or site banners. Banners on CDROM's will link straight to Nettaxi and
Nettaximusic. 15) Nettaxi will include the Spinrecords.com logo on promotional CDROM's containing
music provided Spinrecords.com. 16) Spinrecords.com will provide a link from all artists' pages to
the co-branded registration site for fans to produce fan pages. 17) Nettaxi.com and Spinrecords.com
will develop ability for all registered users of the co-branded site to achieve one-click buying on
the co-branded site whether purchasing from Nettaxi's store or the Spinstore.

8

4. MARKETING EFFORTS

1) Spinrecords.com will sell ad space on the co-branded site, in accordance with the agreement,
within 30 days of the Effective Date. 2) Both Parties agree to develop a Nettaxi co-branded CD
featuring Nettaximusic.com. Both parties will share the production costs of the Nettaximusic.com
Co-Branded CD. The per unit cost shall be 50 cents or less, unless both parties agree otherwise. 3)
Nettaxi will develop a community based affinity model for music that features SpinRecords.com
artists. 4) Nettaxi will provide in-house advertising to promote the co-branded music site. 5)
Spinrecords.com will engage with Nettaxi as an -advertising sponsor promoting the co-branded site
with each party contributing a monthly investment of not less than $20,000 per month, in cash
expenditure or in-kind contribution toward the marketing effort(s). 6) SpinRecords.com will promote
Nettaximusic.com as a music affiliate in their

Source: RAE SYSTEMS INC, 10-Q, 11/14/2000
<!-- page 9 -->
non-traditional street marketing methods, to include flyer's created in-house for Spin Bands, will
have the logo of Nettaxi.com Music in-order that consumers see alternate choices to find the bands
music. 7) Both parties agree to include advertisements for the other party in the advertising
included with their web-based e-mail offered to their users. 8) Spinrecords.com will grant Nettaxi
the rights to use the artist's likeness in promotions of the co-branded site. 9) Nettaxi.com agrees
to participate in Spinrecords.com fourth quarter promotional plans by procuring $250,000 worth of
co-promotional placement in Spinrecords advertising targeted towards colleges, extreme sports and
other mutually agreed upon target audiences. 10) Spinrecords.com agrees to purchase in the fourth
quarter, $250,000 worth of advertising and sponsorship space within the Nettaxi site for promotion
of the co-branded and Spinrecords.com community.

PHASED ROLL OUT PLAN

PHASE I: NOVEMBER 8TH The existing site located at Spinrecords.com/Nettaxi shall be launched -
target date one week from agreement date. This site shall contain the web based e-mail from Nettaxi.
This site shall also use Spinstore and Spinware as it currently exists on the site.

Nettaxi will begin development of the music template for the home page builder. Spinrecords will
submit their existing list of members to Nettaxi to integrate the homepage builder database and
resolve duplicate ID's existing between Nettaxi and Spinrecords member registration.

Nettaxi and Spinrecords will integrate their respective registrations to allow both companies to
synchronize their registered users from the co-branded site.

Spinrecords can announce the partnership in a press release the day the co-branded site launches.
This press release will detail the co-branded relationship.

PHASE II: NOVEMBER 22ND Community home pages will be available to all members of Nettaximusic.com
and Spinrecords.com. Spinrecords.com will announce to their existing membership the existence of
their new homepage, provide them with their Unique URL and promote their ability to develop a unique
web site.

Nettaxi will announce the same ability to all registered members of Nettaximusic.com.

Nettaxi's search engine will be launched on the Spinrecords.com domain.

Nettaxi's e-commerce offering will be launched on the co-branded site. Spinrecords.com e-comnerce
offerings will be reduced to provide licensed merchandise and content and any additional products
mutually agreed upon by Nettaxi.com and Spinrecords.com.

Both companies will announce their users ability to shop on the co-branded site using one-click
buying. Each member can move between the stores on the co-brand site and order in each individual
store.

9

PHASE III: JANUARY 1, 2000

Nettaxi launches citizen and small business e-commerce offering for all community sites. This
feature will allow current Nettaxi home page web sites to integrate e-commerce offerings from their
own products and products from the Nettaxi store.

5. PAYMENT

PERCENTAGE OF ADVERTISING REVENUE

5.1 "SpinRecords.com's Advertising Revenue" means the gross revenue from advertising invoiced by
SpinRecords.com in a calendar quarter for advertising by third parties on the SpinRecords.com Pages,
less any commissions not to exceed 35%.

5.2 "SpinRecords.com's AR Share" means the number of Impressions on the SpinRecords.com Pages by
Users arriving through the Co-branded NETTAXI Pages in

Source: RAE SYSTEMS INC, 10-Q, 11/14/2000
<!-- page 10 -->
a calendar quarter divided by the total number of Impressions on the SpinRecords.com Pages by all
Users in that calendar quarter.

5.3 "NETTAXI Advertising Revenue" means the gross revenue from advertising invoiced by NETTAXI in a
calendar quarter for advertising by third parties on the NETTAXI Pages, less any commissions.

5.4 "NETTAXI's AR Share" means the number of Impressions on the NETTAXI Pages by Users arriving
through the Co-branded SpinRecords.com Pages in a calendar quarter divided by the total number of
Impressions on the NETTAXI Pages by all Users in that calendar quarter.

5.5 SpinRecords.com Rate. In full consideration for the rights granted --------------------- by
NETTAXI, SpinRecords.com agrees to pay NETTAXI fifty (50%) percent of ad revenue at an average rate
no lower then $6.50 per one thousand impressions (CPM) payable to NETTAXI which results when the
SpinRecords.com Advertising Revenue is multiplied by SpinRecords.com's AR Share. SpinRecords.com
shall be responsible for payment of all taxes based on the Advertising Revenue except taxes based on
NETTAXI's income.

5.6 NETTAXI Rate. N/A. -------------

5.7 Payment Schedule. The parties shall make such payments within ----------------- thirty (30) days
of the end of each calendar quarter for the Advertising Revenue invoiced during such calendar
quarter.

5.8 Records. SpinRecords.com agrees to keep accurate books of account ------- and records at its
principal place of business covering all Advertising Revenues and associated commissions. Upon
reasonable notice of not less than seven (7) business days, but in no event more than once per year
(unless the immediately preceding audit showed a material underpayment), NETTAXI shall have the
right, subject to suitable confidentiality measures, to cause a certified public accountant to
inspect those portions of the books of account and records which relate to the royalties owed
NETTAXI, to confirm that the correct amount owing NETTAXI under this Agreement has been paid.
SpinRecords.com shall maintain such books of account and records which support each statement for at
least two years after the termination or expiration of this contract or after the final payment made
by SpinRecords.com to NETTAXI, whichever is later.

2: PER CUSTOMER FEE

1. SpinRecords.com Payment. For each User that accesses the co-branded ------------------------ site
and becomes a paying customer on the co-branded site, SpinRecords.com agrees to pay a fee of five
(5%) percent of the gross sale.

2. NETTAXI Payment. N/A. ----------------

3. Payment Terms. All fees will be paid on or before fifteen (15) days -------------- after the end
of the month in which the party has received payment

4. Audit Rights. SpinRecords.com shall maintain for a period of two ------------- (2) years after
the end of the year to which they pertain, complete records of it's customers in order to calculate
and confirm SpinRecords.com's obligations hereunder. Upon reasonable prior notice, NETTAXI will have
the right, exercisable not more than once every twelve (12) months, to appoint an independent
accounting firm or other agent reasonably acceptable to SpinRecords.com, at NETTAXI'S expense, to
examine such books, records and accounts during SpinRecords.com's normal business hours to verify
the amounts due by SpinRecords.com to NETTAXI herein, subject execution of NETTAXI's standard
confidentiality agreement by the accounting firm or agent; provided, however, that execution of such
agreement will not preclude such firm from reporting its results to NETTAXI. In the event such audit
discloses an underpayment or overpayment of royalties due hereunder, the appropriate party will
promptly remit the amounts due to the other party. If any such audit discloses a shortfall in
payment to NETTAXI of more than five percent (5%) for any quarter, SpinRecords.com agrees to pay or
reimburse NETTAXI for the expenses of such audit.

10

Source: RAE SYSTEMS INC, 10-Q, 11/14/2000
<!-- page 11 -->
Source: RAE SYSTEMS INC, 10-Q, 11/14/2000
