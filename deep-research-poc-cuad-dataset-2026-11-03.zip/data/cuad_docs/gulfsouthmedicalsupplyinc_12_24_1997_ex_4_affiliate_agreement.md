<!-- page 1 -->
# AFFILIATE AGREEMENT
| Field | Value |
|---|---|
| Document Type | Affiliate Agreement |
| Agreement Date | 1997-12-14 |
| Parties | Gulf South Medical Supply, Inc. ("GSMS"); Physician Sales & Service, Inc. ("PSS"); PSS Merger Corp. |
| Source | CUAD v1 / GULFSOUTHMEDICALSUPPLYINC_12_24_1997-EX-4-AFFILIATE AGREEMENT |

EXHIBIT 4 AFFILIATE AGREEMENT -------------------

Physician Sales & Service, Inc. 4345 Southpoint Boulevard Jacksonville, Florida 32216

Attention: Patrick C. Kelly David A. Smith

Gentlemen:

The undersigned is a shareholder of Gulf South Medical Supply, Inc. ("GSMS"), a corporation
organized and existing under the laws of the State of Delaware, and will become a shareholder of
Physician Sales & Service, Inc. ("PSS"), a corporation organized and existing under the laws of the
State of Florida, pursuant to the transactions described in the Agreement and Plan of Merger, dated
as of December 14, 1997 (the "Agreement"), by and among PSS, PSS Merger Corp. ("Merger Corp.") and
GSMS. Under the terms of the Agreement, Merger Corp. will be merged into and with GSMS (the
"Merger"), and the shares of the $.01 par value common stock of GSMS ("GSMS Common Stock") will be
converted into and exchanged for shares of the $.01 par value common stock of PSS ("PSS Common
Stock"). This Affiliate Agreement represents an agreement between the undersigned and PSS regarding
certain rights and obligations of the undersigned in connection with the shares of PSS to be
received by the undersigned as a result of the Merger.

In consideration of the Merger and the mutual covenants contained herein, the undersigned and PSS
hereby agree as follows:

1. Affiliate Status. The undersigned understands and agrees that as to ---------------- GSMS he is
an "affiliate" under Rule 145(c) as defined in Rule 405 of the Rules and Regulations of the
Securities and Exchange Commission ("SEC") under the Securities Act of 1933, as amended ("1933
Act"), and the undersigned anticipates that he will be such an "affiliate" at the time of the
Merger.

2. Initial Restriction on Disposition. The undersigned agrees that he
---------------------------------- will not sell, transfer, or otherwise dispose of his interests
in, or reduce his risk relative to, any of the shares of PSS Common Stock into which his shares of
GSMS Common Stock are converted upon consummation of the Merger until such time as PSS notifies the
undersigned that the requirements of SEC Accounting Series Release Nos. 130 and 135 ("ASR 130 and
135") have been met. The undersigned understands that ASR 130 and 135 relate to publication of
financial results of post-Merger combined operations of PSS and GSMS. PSS agrees that it will
publish such results as promptly as practicable following the Merger in the sole discretion of PSS,
but in any event within 45 days after the end of the first fiscal quarter of PSS containing the
required period of post-Merger combined operations and that it will notify the undersigned promptly
following such publication.

3. Covenants and Warranties of Undersigned. The undersigned represents,
--------------------------------------- warrants and agrees that:

(a) The PSS Common Stock received by the undersigned as a result of the Merger will be taken for his
own account and not for others, directly or indirectly, in whole or in part.

(b) PSS has informed the undersigned that any distribution by the undersigned of PSS Common Stock
has not been registered under the 1933 Act and that shares of PSS Common Stock received pursuant to
the Merger can only be sold by the undersigned (1) following registration under the 1933 Act, or (2)
in conformity with the volume and other requirements of Rule 145(d) promulgated by the SEC as the
same now exist or may hereafter be amended, or (3) to the extent some other exemption from
registration under the 1933 Act might be available. The undersigned understands that PSS is under no
------------------------------------------------ obligation to file a registration statement with
the SEC covering the ---------------------------------------------------------------------
disposition of the undersigned's shares of PSS Common
-----------------------------------------------------

Stock or to take any other action necessary to make compliance with an
---------------------------------------------------------------------- exemption from such
registration available. ------------------------------------------

(c) During the 30 days immediately preceding the Effective Time of the Merger, the undersigned has
not sold, transfered, or otherwise disposed of his interests in, or reduced his risk relative to,
any of the shares of GSMS Common Stock beneficially owned by the undersigned as of the record date
for determination of shareholders entitled to vote at the Shareholders' Meeting of GSMS held to
approve the Merger.

(d) The undersigned is aware that PSS intends to treat the Merger as a tax- free reorganization
under Section 368 of the Internal Revenue Code ("Code")
<!-- page 2 -->
for federal income tax purposes. The undersigned agrees to treat the transaction in the same manner
as PSS for federal income tax purposes. The undersigned acknowledges that Section 1.368-1(b) of the
Income Tax Regulations requires "continuity of interest" in order for the Merger to be treated as
tax-free under Section 368 of the Code. This requirement is satisfied if, taking into account those
GSMS shareholders who receive cash in exchange for their stock, who receive cash in lieu of
fractional shares, or who dissent from the Merger, there is no plan or intention on the part of the
GSMS shareholders to sell or otherwise dispose of the PSS Common Stock to be received in the Merger
that will reduce such shareholders' ownership to a number of shares having, in the aggregate, a
value at the time of the Merger of less than 50% of the total fair market value of the GSMS Common
Stock outstanding immediately prior to the Merger. The undersigned has no prearrangement, plan or
intention to sell or otherwise dispose of an amount of his PSS Common Stock to be received in the
Merger which would cause the foregoing requirement not to be satisfied.

4. Restrictions on Transfer. The undersigned understands and agrees that ------------------------
stop transfer instructions with respect to the shares of PSS Common Stock received by the
undersigned pursuant to the Merger will be given to PSS's transfer agent and that there will be
placed on the certificates for such shares, or shares issued in substitution thereof, a legend
stating in substance:

"The shares represented by this certificate were issued pursuant to a business combination which is
accounted for as a "pooling of interests" and may not be sold, nor may the owner thereof reduce his
risks relative thereto in any way, until such time as PSS, Inc. ("PSS") has published the financial
results covering at least 30 days of combined operations after the effective date of the merger
through which the business combination was effected. In addition, the shares represented by this
certificate may not be sold, transferred or otherwise disposed of except or unless (1) covered by an
effective registration statement under the Securities Act of 1933, as amended, (2) in accordance
with (i) Rule 145(d) (in the case of shares issued to an individual who is not an affiliate of PSS)
or (ii) Rule 144 (in the --- case of shares issued to an individual who is an affiliate of PSS) of
the Rules and Regulations of such Act, or (3) in accordance with a legal opinion satisfactory to
counsel for PSS that such sale or transfer is otherwise exempt from the registration requirements of
such Act."

Such legend will also be placed on any certificate representing PSS securities issued subsequent to
the original issuance of the PSS Common Stock pursuant to the Merger as a result of any transfer of
such shares or any stock dividend, stock split, or other recapitalization as long as the PSS Common
Stock issued to the undersigned pursuant to the Merger has not been transferred in such manner to
justify the removal of the legend therefrom. Upon the request of the undersigned, PSS shall cause
the certificates representing the shares of PSS Common Stock issued to the undersigned in connection
with the Merger to be reissued free of any legend relating to restrictions on transfer by virtue of
ASR 130 and 135 as soon as practicable after the requirements of ASR 130 and 135 have been met. In
addition, if the provisions of Rules 144 and 145 are amended to eliminate restrictions applicable to
the PSS Common Stock received by the undersigned pursuant to the Merger, or at the expiration of the
restrictive period set forth in Rule 145(d), PSS, upon the request of the undersigned, will cause
the certificates representing the shares of PSS Common Stock issued to the undersigned in connection
with the Merger to be reissued free of any legend relating to the restrictions set forth in Rules
144 and 145(d) upon receipt by PSS of an opinion of its counsel to the effect that such legend may
be removed.

- 2 -

5. Understanding of Restrictions on Dispositions. The undersigned has
--------------------------------------------- carefully read the Agreement and this Affiliate
Agreement and discussed their requirements and impact upon his ability to sell, transfer, or
otherwise dispose of the shares of PSS Common Stock received by the undersigned, to the extent he
believes necessary, with his counsel or counsel for GSMS.

6. Filing of Reports by PSS. PSS agrees, for a period of three years ------------------------ after
the effective date of the Merger, to file on a timely basis all reports required to be filed by it
pursuant to Section 13 of the Securities Exchange Act of 1934, as amended, so that the public
information provisions of Rule 145(d) promulgated by the SEC as the same are presently in effect
will be available to the undersigned in the event the undersigned desires to transfer any shares of
PSS Common Stock issued to the undersigned pursuant to the Merger.

7. Transfer Under Rule 145(d). If the undersigned desires to sell or --------------------------
otherwise transfer the shares of PSS Common Stock received by him in connection with the Merger at
any time during the restrictive period set forth in Rule 145(d), the undersigned will provide the
necessary representation letter to the transfer agent for PSS Common Stock together with such
additional information as the transfer agent may reasonably request. If PSS's counsel concludes that
such proposed sale or transfer complies with the requirements of Rule 145(d), PSS shall cause such
counsel to provide such opinions as may be necessary to PSS's Transfer Agent so that the undersigned
may complete the proposed sale or transfer.

8. Acknowledgments. The undersigned recognizes and agrees that the --------------- foregoing
provisions also apply to all shares of the capital stock of GSMS and PSS that are deemed to be
beneficially owned by the undersigned pursuant to applicable federal securities laws, which the
undersigned agrees may include,
<!-- page 3 -->
without limitation, shares owned or held in the name of (i) the undersigned's spouse, (ii) any
relative of the undersigned or of the undersigned's spouse who has the same home as the undersigned,
(iii) any trust or estate in which the undersigned, the undersigned's spouse, and any such relative
collectively own at least a 10% beneficial interest or of which any of the foregoing serves as
trustee, executor, or in any similar capacity, and (iv) any corporation or other organization in
which the undersigned, the undersigned's spouse and any such relative collectively own at least 10%
of any class of equity securities or of the equity interest. The undersigned further recognizes
that, in the event that the undersigned is a director or officer of PSS or becomes a director or
officer of PSS upon consummation of the Merger, among other things, any sale of PSS Common Stock by
the undersigned within a period of less than six months following the effective time of the Merger
may subject the undersigned to liability pursuant to Section 16(b) of the Securities Exchange Act of
1934, as amended.

9. Miscellaneous. This Affiliate Agreement is the complete agreement ------------- between PSS and
the undersigned concerning the subject matter hereof. Any notice required to be sent to any party
hereunder shall be sent by registered or certified mail, return receipt requested, using the
addresses set forth herein or such other address as shall be furnished in writing by the parties.
This Affiliate Agreement shall be governed by the laws of the State of Delaware.

- 3 -

This Affiliate Agreement is executed as of the 14th day of December, 1997.

Very truly yours,

/s/ William W. McInnes ___________________________ Signature

William W. McInnes ___________________________ Print Name 116 30th Avenue S
____________________________ Nashville, TN 37212 ____________________________ Address

[add below the signatures of all registered owners of shares deemed beneficially owned by the
affiliate]

___________________________ Name:

___________________________ Name:

___________________________ Name:

AGREED TO AND ACCEPTED as of December 14, 1997

PHYSICIAN SALES & SERVICE, INC.

/s/ David A. Smith BY:_________________________

-4-

This Affiliate Agreement is executed as of the 14th day of December, 1997.

Very truly yours,

/s/ Edward Shulman ___________________________ Signature

Edward Shulman ___________________________ Print Name 5909 Dalecross CT ____________________________
Glen Allen, VA 23060 ____________________________ Address

[add below the signatures of all registered owners of shares deemed beneficially owned by the
affiliate]

___________________________ Name:

___________________________ Name:

___________________________ Name:

AGREED TO AND ACCEPTED as of December 14, 1997

PHYSICIAN SALES & SERVICE, INC.

/s/ David A. Smith BY:_________________________

-4-

This Affiliate Agreement is executed as of the 14th day of December, 1997.
<!-- page 4 -->
Very truly yours,

/s/ Donna C.E. Williamson ___________________________ Signature

Donna C.E. Williamson ___________________________ Print Name ____________________________
____________________________ Address

[add below the signatures of all registered owners of shares deemed beneficially owned by the
affiliate]

___________________________ Name:

___________________________ Name:

___________________________ Name:

AGREED TO AND ACCEPTED as of December 14, 1997

PHYSICIAN SALES & SERVICE, INC.

/s/ David A. Smith BY:_________________________

- 4 -

This Affiliate Agreement is executed as of the 14th day of December, 1997.

Very truly yours,

/s/ David L. Bogetz ___________________________ Signature

David L. Bogetz ___________________________ Print Name ____________________________
____________________________ Address

[add below the signatures of all registered owners of shares deemed beneficially owned by the
affiliate]

___________________________ Name:

___________________________ Name:

___________________________ Name:

AGREED TO AND ACCEPTED as of December 14, 1997

PHYSICIAN SALES & SERVICE, INC.

/s/ David A. Smith BY:_________________________

-4-

This Affiliate Agreement is executed as of the 14th day of December, 1997.
<!-- page 5 -->
Very truly yours,

/s/ Melvin L. Hecktman ___________________________ Signature

Melvin L. Hecktman ___________________________ Print Name 530 Waters Edge Ct
____________________________ Northbrook, IL 60062 ____________________________ Address

[add below the signatures of all registered owners of shares deemed beneficially owned by the
affiliate]

___________________________ Name:

___________________________ Name:

___________________________ Name:

AGREED TO AND ACCEPTED as of December 14, 1997

PHYSICIAN SALES & SERVICE, INC.

/s/ David A. Smith BY:_________________________

-4-

This Affiliate Agreement is executed as of the 14th day of December, 1997.

Very truly yours,

/s/ Thomas G. Hixon ___________________________ Signature

Thomas G. Hixon ___________________________ Print Name 165 Butler Drive ____________________________
Ridgeland, MS 39154 ____________________________ Address

[add below the signatures of all registered owners of shares deemed beneficially owned by the
affiliate]

___________________________ Name:

___________________________

Name:

___________________________ Name:

AGREED TO AND ACCEPTED as of December 14, 1997

PHYSICIAN SALES & SERVICE, INC.

/s/ David A. Smith BY:_________________________

-4-

This Affiliate Agreement is executed as of the 14th day of December, 1997.
<!-- page 6 -->
Very truly yours,

/s/ Steve Richardson ___________________________ Signature

Steve Richardson ___________________________ Print Name 194 Sunsan Road ____________________________
Madison, MS 39116 ____________________________ Address

[add below the signatures of all registered owners of shares deemed beneficially owned by the
affiliate]

___________________________ Name:

___________________________ Name:

___________________________ Name:

AGREED TO AND ACCEPTED as of December 14, 1997

PHYSICIAN SALES & SERVICE, INC.

/s/ David A. Smith BY:_________________________

-4-

This Affiliate Agreement is executed as of the 14th day of December, 1997.

Very truly yours,

/s/ Guy W. Edwards ___________________________ Signature

Guy W. Edwards ___________________________ Print Name 567 Arbor Drive ____________________________
Madison, MS 39110 ____________________________ Address

[add below the signatures of all registered owners of shares deemed beneficially owned by the
affiliate]

___________________________ Name:

___________________________ Name:

___________________________ Name:

AGREED TO AND ACCEPTED as of December 14, 1997

PHYSICIAN SALES & SERVICE, INC.

/s/ David A. Smith BY:_________________________

-4-

This Affiliate Agreement is executed as of the 14th day of December, 1997.
<!-- page 7 -->
Very truly yours,

/s/ Stanton Keith Pritchard ___________________________ Signature

Stanton Keith Pritchard ___________________________ Print Name #3 Abbey Nord
____________________________ Jackson, MS 39216 ____________________________ Address

[add below the signatures of all registered owners of shares deemed beneficially owned by the
affiliate]

___________________________ Name:

___________________________ Name:

___________________________ Name:

AGREED TO AND ACCEPTED as of December 14, 1997

PHYSICIAN SALES & SERVICE, INC.

/s/ David A. Smith BY:_________________________

-4-

This Affiliate Agreement is executed as of the 14th day of December, 1997.

Very truly yours,

/s/ Louie Vaughan ___________________________ Signature

Louie Vaughan ___________________________ Print Name 318 Woodrun Drive ____________________________
Ridgeland, MS 39157 ____________________________ Address

[add below the signatures of all registered owners of shares deemed beneficially owned by the
affiliate]

___________________________ Name:

___________________________ Name:

___________________________ Name:
<!-- page 8 -->
AGREED TO AND ACCEPTED as of December 14, 1997

PHYSICIAN SALES & SERVICE, INC.

/s/ David A. Smith BY:_________________________

-4-
