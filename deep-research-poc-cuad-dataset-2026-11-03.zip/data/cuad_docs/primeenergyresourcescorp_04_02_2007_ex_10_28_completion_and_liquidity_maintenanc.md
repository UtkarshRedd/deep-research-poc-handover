<!-- page 1 -->
# COMPLEHON AGREEMENT AND UQITDITV MAINTENANCE AGREEMENT
| Field | Value |
|---|---|
| Document Type | Maintenance Agreement |
| Agreement Date | 2006-06-29 |
| Parties | PRIMEEVERGY CORPORATION ("Prime); GUARANTY BANK ("Guaranty"); PRIME OFFSHORE L.L.C. ("Offshore") |
| Source | CUAD v1 / PRIMEENERGYRESOURCESCORP_04_02_2007-EX-10.28-COMPLETION AND LIQUIDITY MAINTENANCE AGREEMENT |

EXHIBIT 10.23

COMPLETION AND LIOUDm MAINTENANCE 4GRFFMFST

THIS COMPLEHON AGREEMENT AND UQITDITV MAINTENANCE AGREEMENT ( 'Agreement") {5 made and entered into
effective as of June 29, 2006 between PRIMEEVERG\'CORPORATION ( Time"), GUARANTY BANK, FSB
('Guaranty") and PRIME OFFSHORELT.C. T: Offshore"!

Prime is the majority shareholder of Prime Offshore L.L.C. COffshore"! Offshore and Guaranty are
parties to a Credit Agreement dated June 29, 2006, by and between Offshore as Borrower and Guaranty,
as Agent and Lender i "Credit Agreement'T wherein Guaranty is loaning certain funds to Offshore to
drill and complete wells and construct, install and operate in-field and flow pipelines, caissons,
platforms and production facilities for wells m South Padre Island Area OCS Blocks 1113, 1059, 1060,
1073 and 1133 and North Padre Island Area OCS Block 998 T'Derelopment Project").

1. Completion Commrtiryr.t

Each of the South Padre Island Area OCS Blocks 1113,1059,1060,1073 and 1133 and the North Padre
Island Area OCS Block 998 shall be defined as a "Project Field.''

For purposes ofthis Agreement, Project Completion shall consist oftwo components and be defined as:

A) each Project Field in the Development Project having all planned in-field and flow pipelines,
caissons, platforms and production facilities for all the wells in such Project Field, for which
Guaranty has loaned funds, installed and operationalsuch that the production from all such wells can
be transported to a readily available sales point for naturalgas. In addition, for each Project
Field, Project Completion will include, but not limited to:

a) obtaining required permits, easements and governmental approvals;

b) executing necessary" construction contract(s);

c) completing tests considered usual and customary" and required to be conducted with results tn
accordance with those necessary" to permit operations;

d) ensuring that each Project Field is free and clear of all bens other than those in favor of
Guaranty and Permitted Liens under the Credit Agreement and:

e) causing all costs of the Development Project to be paid when due; and,

B) the 12-inch loop pipeline fromNorth Padre Island Area OCS Block 996 to the pipeline owned by the
Williams Companies Inc. having been constructed and installed in accordance with the plans and
specifications in the construction contracts).
<!-- page 2 -->
As consideration for Guaranty entering into the Credit Agreement to provide such loans for the
Development Project and to ensure Project Completion. Prime absolutely and unconditionally warrants
to Guaranty to fund the payment to Offshore of all costs that exzeed the available commitments under
the Credit Agreement, including interest, for Project Completion. In the event Offshore is in
Default under Section 7.1(f), (g), (h) and/or (i) ofthe Credit Agreement, then Prime absolutely and
unconditionally warrants to Guaranty" the assumption of all costs for Project Completion.

2. Licuieitv Maintenance

Prime will, during the term of the Credit Agreement, maintain liquidity consisting of unused
revolver availability" under the Credit Agreement dated December!, 2002, as amended, with Prime et
aland Guaranty, and/or unrestricted cash and cash equivalents of $25,000,000. This required
liquidity" win reduce dollar-for-dollar with any additional shareholder advance s and increase
dollar-for-dollar to a maximum of $21,000,000 with any repayment of shareholder advances. To the
extent that shareholder repayment has occurred, Prime agrees to fund additional shareholder loans
equal to the amount repayed by the shareholder, as needed to ensure Project Clomp let ion

This Agreement shall remain in force until each component ofProject Completion is satisfied. Once a
component is satisfied, Prime's absolute and unconditional warranty to Guaranty to fund the payment
to Offshore of ad costs that esceed the available commitments under the Credit Agreement for that
conponent, including interest, wid ejpire.

Prime understands that a breach ofobligations under this Agreement would result in an Event
ofDefault under the Credit Agreement with Offshore that would permit Guaranty to pursue its
available remedies under the Credit Agreement. Offshore is executing this Agreement to acknowledge
that a breach ofthis Agreement would result in an Event ofDefault under the Credit Agreement.

This Agreement shad be deemed a contract made under and shall be construed in accordance with and
governed by the laws ofthe State ofTexas and that actions arising out ofthis Agreement may be
litigated in courts having situs in Harris County, Texas.

This agreement is executed the date first hereinafter written,

PRIMEEVERGY CORPORATION By:-*" Beverly A. Cummings______ Beverly A. Cummings Executive Vice
President

-2 -
<!-- page 3 -->
PRIME OFFSHORE L.L.C. Byi'Sj' JimR- Brcck___________________ JiinE. Brcck President and Chief
Financial Officer
<!-- page 4 -->
GUARANTY BANK, FS B ' Kelly L. ELmcre. El Kell)r L Ebncre. IH Senicr Vice Press idenl
