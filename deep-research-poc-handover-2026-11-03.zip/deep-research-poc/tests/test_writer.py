"""Writer + tier-1 report verification, deterministic (scripted writer model, no network)."""
import json
import time
from dataclasses import replace
from pathlib import Path

import pytest
from langchain_core.messages import AIMessage

from dr.agents.writer import (
    assign_heuristic,
    extract_claims,
    outline_from_question,
    render_report,
    write_report,
)
from dr.config import DEFAULT
from dr.evidence import EvidenceBank
from dr.ingest.load import load_dir
from dr.llm import get_scripted_llm
from dr.models import Claim, EvidenceItem, OutlineSection, Report
from dr.structured import ModelCaller
from dr.trace import Trace
from dr.verify.report import appendix, finalize_report, verify_report
from dr.workspace import Workspace

SAMPLE = Path(__file__).resolve().parents[1] / "data" / "sample_docs"
Q = "What Leverage Ratio covenant applies to Acme Industrial, and how did the amendment change it?"


@pytest.fixture()
def ws(tmp_path):
    return Workspace.materialize(load_dir(SAMPLE), tmp_path / "ws")


@pytest.fixture()
def bank(ws):
    by_title = {m.title: d for d, m in ws.manifest.items()}
    a = by_title["Credit Agreement — Acme Industrial LLC"]
    m = next(d for t, d in by_title.items() if t.startswith("First Amendment"))
    b = EvidenceBank(ws)
    b.add(a, 17, 17, "Borrower shall maintain a Leverage Ratio not exceeding 3.50 to 1.00.", "original covenant")
    b.add(m, 9, 9, "Section 3 is amended to read: Borrower shall maintain a Leverage Ratio not exceeding 4.00 to 1.00.",
          "First Amendment changed the ratio")
    return b


def outline_json(*titles):
    secs = [{"section_id": f"s{i}", "title": t, "intent": f"Establish: {t}"} for i, t in enumerate(titles, 1)]
    return AIMessage(content=json.dumps({"sections": secs}))


def revise_json(assign: dict[str, list[str]], titles: dict[str, str]):
    secs = [{"section_id": sid, "title": titles[sid], "intent": f"Establish: {titles[sid]}", "evidence_ids": ids}
            for sid, ids in assign.items()]
    return AIMessage(content="Here you go:\n```json\n" + json.dumps({"sections": secs}) + "\n```")


def draft_by_title(drafts: dict[str, str]):
    """Script item that picks the draft from the section title in the prompt (thread-order safe)."""
    def _fn(messages):
        prompt = messages[-1].content
        for title, text in drafts.items():
            if f'Write the section "{title}"' in prompt:
                return AIMessage(content=text)
        raise AssertionError("no draft scripted for this prompt")
    return _fn


# --------------------------------------------------------------------------- claims

def test_extract_claims_moves_trailing_markers_and_flags_gaps():
    sec = OutlineSection(section_id="s1", title="t", intent="i")
    draft = ("The cap is 3.50 to 1.00 {{CITE:e1}}. It was later raised to 4.00. {{CITE:e2}} "
             "Fees are unchanged.\n[GAP] The interest rate floor is not in the evidence.")
    claims = extract_claims(sec, draft)
    assert [c.claim_id for c in claims] == ["s1.1", "s1.2", "s1.3", "s1.4"]
    assert claims[0].evidence_ids == ["e1"] and claims[0].text == "The cap is 3.50 to 1.00." and not claims[0].is_gap
    assert claims[1].evidence_ids == ["e2"] and claims[1].text == "It was later raised to 4.00."   # marker after the period
    assert claims[2].is_gap and claims[2].evidence_ids == []                                     # uncited sentence
    assert claims[3].is_gap and claims[3].text.startswith("[GAP]")
    multi = extract_claims(sec, "Both say so {{CITE:e1, e2}}.")
    assert multi[0].evidence_ids == ["e1", "e2"]
    assert extract_claims(sec, "Cap is 4.00 {{CITE:e1}}.\n\n[GAP]\n[GAP]:") == extract_claims(sec, "Cap is 4.00 {{CITE:e1}}.")


# --------------------------------------------------------------------------- outline

def test_outline_falls_back_after_failed_repair(tmp_path):
    llm = get_scripted_llm([AIMessage(content="I would rather not."), AIMessage(content="still no json")])
    tr = Trace(tmp_path / "t.jsonl", "t")
    secs = outline_from_question(Q, ModelCaller(llm, tr, "write", "writer"))
    assert len(secs) == 1 and secs[0].section_id == "s1"
    assert len(llm.script) == 0                                   # one call + one repair, then fallback
    events = [json.loads(ln) for ln in (tmp_path / "t.jsonl").read_text().splitlines()]
    assert sum(1 for e in events if e["kind"] == "json_invalid") == 2
    assert "json_repair" not in events[0] and any("did not match" in m.content for m in llm.seen[1])


def test_assign_heuristic_places_every_item_once(bank):
    secs = [OutlineSection(section_id="s1", title="Original covenant", intent="state the leverage ratio in the original agreement"),
            OutlineSection(section_id="s2", title="First Amendment", intent="state what the first amendment changed")]
    out = assign_heuristic(secs, bank)
    placed = [e for s in out for e in s.evidence_ids]
    assert sorted(placed) == ["e1", "e2"]
    assert "e1" in out[0].evidence_ids and "e2" in out[1].evidence_ids


# --------------------------------------------------------------------------- write_report

def test_write_report_outline_revise_draft(ws, bank):
    titles = {"s1": "Original covenant", "s2": "Effect of the amendment"}
    script = [
        outline_json("Original covenant", "Effect of the amendment", "Context"),
        revise_json({"s1": ["e1"], "s2": ["e2", "e7"]}, titles),           # e7 does not exist: must be dropped
        draft_by_title({
            "Original covenant": "The original agreement caps the Leverage Ratio at 3.50 to 1.00 {{CITE:e1}}.",
            "Effect of the amendment": "The First Amendment raised the cap to 4.00 to 1.00 {{CITE:e2}}. The margin also moved.",
        }),
    ] * 1
    script.append(script[-1])   # two sections draft in parallel; the same title-keyed callable serves both
    report = write_report(Q, bank, llm=get_scripted_llm(script))
    assert [s.section_id for s in report.sections] == ["s1", "s2"]
    assert report.sections[0].evidence_ids == ["e1"] and report.sections[1].evidence_ids == ["e2"]
    assert not report.partial and report.notes == []
    cited = [c for c in report.claims if not c.is_gap]
    assert [c.evidence_ids for c in cited] == [["e1"], ["e2"]]
    assert [c.text for c in report.claims if c.is_gap] == ["The margin also moved."] == report.gaps
    md = report.markdown
    assert md.startswith("# ") and "## Original covenant" in md and "## Effect of the amendment" in md
    assert f"[{bank.get('e1').doc_id} p.2]" in md and "[uncited]" in md and "{{CITE" not in md


def test_outline_bounded_by_evidence_and_empty_sections_collapsed(ws, bank):
    from dr.agents.writer import sections_cap
    assert sections_cap(0) == 1 and sections_cap(1) == 2 and sections_cap(2) == 2 and sections_cap(6) == 4 and sections_cap(50) == 6
    titles = {"s1": "Covenant", "s2": "Amendment", "s3": "Identity", "s4": "Extract"}
    script = [
        outline_json("Covenant", "Amendment", "Identity", "Extract"),
        revise_json({"s1": ["e1"], "s2": ["e2"], "s3": [], "s4": []}, titles),   # model ignored the cap: two empties
        draft_by_title({"Covenant": "Cap 3.50 {{CITE:e1}}.", "Amendment": "Cap 4.00 {{CITE:e2}}."}),
    ]
    script.append(script[-1])
    llm = get_scripted_llm(script)
    report = write_report(Q, bank, llm=llm)
    assert "keep at most 2" in llm.seen[1][-1].content                       # cap from 2 evidence items
    assert [s.section_id for s in report.sections] == ["s1", "s2", "gaps"]
    assert report.sections[-1].title == "Not established by the evidence"
    gap_lines = [c.text for c in report.claims if c.section_id == "gaps"]
    assert len(gap_lines) == 2 and all(t.startswith("[GAP] No evidence was found for: Establish: ") for t in gap_lines)
    assert any("2 empty section(s) collapsed" in n for n in report.notes) and not report.partial
    assert report.markdown.count("## ") == 3 and "## Identity" not in report.markdown


def test_write_report_skips_revision_near_deadline(bank):
    script = [outline_json("Original covenant", "First Amendment"),
              draft_by_title({"Original covenant": "Cap 3.50 {{CITE:e1}}.", "First Amendment": "Cap 4.00 {{CITE:e2}}."})]
    script.append(script[-1])
    report = write_report(Q, bank, llm=get_scripted_llm(script), deadline_ts=time.time() + 5)
    assert report.partial and any("revision skipped" in n for n in report.notes)
    assert sorted(e for s in report.sections for e in s.evidence_ids) == ["e1", "e2"]


def test_write_report_with_empty_bank_is_all_gaps(ws):
    empty = EvidenceBank(ws)
    report = write_report(Q, empty, llm=get_scripted_llm([outline_json("A", "B")]))
    assert report.partial and all(c.is_gap for c in report.claims) and len(report.claims) == 2
    assert "> **Partial report.**" in report.markdown and "[GAP] No evidence was found for" in report.markdown


# --------------------------------------------------------------------------- verification

def test_verify_report_drops_misattributed_and_unknown_citations(ws, bank):
    a = bank.get("e1").doc_id
    # a quote that truly lives in the amendment, mis-cited to the original (bypasses add()'s guard)
    bank.update(EvidenceItem(id="e9", doc_id=a, page=1, start_line=1, end_line=2,
                             quote="Section 3 is amended to read: Borrower shall maintain a Leverage Ratio not exceeding 4.00 to 1.00."))
    sec = OutlineSection(section_id="s1", title="Covenant", intent="i", evidence_ids=["e1", "e9"])
    claims = [
        Claim(claim_id="s1.1", section_id="s1", text="The cap is 3.50 to 1.00.", evidence_ids=["e1"]),
        Claim(claim_id="s1.2", section_id="s1", text="The amendment raised it to 4.00.", evidence_ids=["e9"]),
        Claim(claim_id="s1.3", section_id="s1", text="Both documents agree.", evidence_ids=["e1", "e42"]),
        Claim(claim_id="s1.4", section_id="s1", text="[GAP] No fee evidence.", evidence_ids=[], is_gap=True),
    ]
    report = Report(question=Q, title="t", sections=[sec], claims=claims)
    results = verify_report(ws, bank, report)
    by = {r.claim_id: r for r in results}
    assert by["s1.1"].tier1 == "keep" and by["s1.1"].tier1_score == 1.0
    assert by["s1.2"].tier1 == "drop" and "text found in" in by["s1.2"].note
    assert by["s1.3"].tier1 == "drop" and "unknown evidence id" in by["s1.3"].note
    assert by["s1.4"].tier1 == "gap"
    assert bank.get("e9").tier1_status == "drop" and EvidenceBank(ws).get("e9").tier1_status == "drop"  # persisted

    report, results = finalize_report(ws, bank, report)
    md = report.markdown
    assert "The cap is 3.50 to 1.00." in md and "[DROPPED: claim s1.2" in md and "[DROPPED: claim s1.3" in md
    assert "The amendment raised it to 4.00." not in md                        # dropped text never survives
    assert "## Verification appendix" in md and "dropped: 2" in md and "gaps: 1" in md
    assert "tier-1 support rate: 0.33" in md
    assert (ws.root / "report.md").exists() and json.loads((ws.root / "verify.json").read_text())[1]["tier1"] == "drop"


def test_render_report_flags_truncated(bank):
    sec = OutlineSection(section_id="s1", title="Covenant", intent="i", evidence_ids=["e1"])
    c = Claim(claim_id="s1.1", section_id="s1", text="Leverage is capped.", evidence_ids=["e1"])
    report = Report(question=Q, title="t", sections=[sec], claims=[c])
    from dr.models import VerifyResult
    md = render_report(report, bank, {"s1.1": VerifyResult(claim_id="s1.1", tier1="truncate", tier1_score=0.5)})
    assert "Leverage is capped. [partially supported]" in md
    assert appendix(report, [VerifyResult(claim_id="s1.1", tier1="keep", tier1_score=1.0)], bank).count("| s1.1 |") == 1


def test_small_config_for_writer_is_consistent():
    cfg = replace(DEFAULT, agents=replace(DEFAULT.agents, OUTLINE_MAX_SECTIONS=2))
    assert cfg.agents.OUTLINE_MAX_SECTIONS == 2 and cfg.agents.WRITE_SECTION_CONCURRENCY >= 1
