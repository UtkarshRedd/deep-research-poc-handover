<!-- page 1 -->
# STRATEGIC ALLIANCE AGREEMENT
| Field | Value |
|---|---|
| Document Type | Strategic Alliance Agreement |
| Agreement Date | 2016-12-14 |
| Parties | Hyatt Franchising Latin America, L.L.C. ("Hyatt"); Playa Hotels & Resorts, B.V. ("Playa"); Hyatt and Playa (each a “Party” and collectively as the “Parties”) |
| Source | CUAD v1 / PLAYAHOTELS_RESORTSNV_03_14_2017-EX-10.22-STRATEGIC ALLIANCE AGREEMENT (Hyatt Ziva Cancun) |

Exhibit 10.22

STRATEGIC ALLIANCE AGREEMENT

(Hyatt Ziva Cancun)

THIS STRATEGIC ALLIANCE AGREEMENT (the "Agreement") is made and entered into as of December 14, 2016
(the "Effective Date"), by and between Hyatt Franchising Latin America, L.L.C., a limited liability
company organized and existing under the laws of the State of Delaware (U.S.A.) with its principal
place of business located at 71 South Wacker Drive, Chicago, Illinois 60606, U.S.A. ("Hyatt"), and
Playa Hotels & Resorts, B.V., a private limited liability company organized and existing under the
laws of the Netherlands with its registered address at Prins Bernhardplein 200, 1097 JB Amsterdam,
the Netherlands ("Playa"). Hyatt and Playa are each referred to as a "Party" and collectively as the
"Parties."

R E C I T A L S:

WHEREAS, Hyatt and Playa are parties to that certain Master Development Agreement dated as of August
9, 2013 (as amended, the "Master Development Agreement") under which Hyatt granted Playa the
exclusive (to the extent set forth therein) right, provided that Playa met certain conditions, to
develop all-inclusive resorts under either or both of the Hyatt Ziva® or Hyatt Zilara® brands and
other aspects of the proprietary system owned by Hyatt or its affiliates ("Hyatt All-Inclusive
Resorts") in the countries of Mexico, Costa Rica, the Dominican Republic, Jamaica and Panama, as
their boundaries exist as of the Effective Date (the "Market Area"); and

WHEREAS, simultaneously with signing this Agreement, Hyatt and Playa or its affiliates are
terminating the Master Development Agreement and signing amendments to the following franchise
agreements (collectively, the "Existing Franchise Agreements") covering the following Hyatt
All-Inclusive Resorts:

• Franchise Agreement dated as of August 9, 2013, amended and restated on January 31, 2014 between
Hyatt and Playa Hall JamaicanResort Limited for the operation of the Hyatt Ziva/Zilara® resort at 1
Ritz-Carlton Drive, Rose Hall, Montego Bay, Jamaica

• Franchise Agreement dated as of August 9, 2013, amended and restated on January 31, 2014 between
Hyatt and Playa Cabos Baja, S. DeR.L. De C.V. for the operation of the Hyatt Ziva® resort at Paseo
de Malecón I-5 D, San José del Cabo, 23405, Mexico

• Franchise Agreement dated as of August 9, 2013, amended and restated on January 31, 2014 between
Hyatt and Cameron Del Pacifico S. De R.L. De C.V. for the operation of the Hyatt Ziva® resort at
Carretera Barra de Navidad Km. 3.5, Zona Hotelera, 48300, Puerto Vallarta, Jalisco, Mexico

• Franchise Agreement dated as of August 9, 2013, amended and restated on January 31, 2014 between
Hyatt and Cameron Del Caribe S. De R.L. De C.V. for the operation of the Hyatt Ziva® resort at Blvd.
Kukulkan Km 9.5, Zona Hotelera, Punta Cancún, 77500, Cancún, Quintana Roo, Mexico
<!-- page 2 -->
• Franchise Agreement dated as of August 9, 2013, amended and restated on January 31, 2014 between
Hyatt and The Royal Cancun S. De R.L. De C.V. for the operation of the Hyatt Zilara® resort at Blvd.
Kukulkan Km 11.5, Zona Hotelera, 77500 Cancún, Quintana Roo, Mexico; and

WHEREAS, Hyatt and Playa have agreed to terminate the Master Development Agreement and to enter into
this Agreement.

NOW, THEREFORE, in consideration of the mutual covenants and agreements contained in this Amendment
and for other good and valuable consideration, the receipt and sufficiency of which are hereby
acknowledged, the parties agree as follows:

1. First Offer for Development Opportunities. During the period beginning on the Effective Date and
ending on December 31, 2018 (the "Development Term"), each Party (the "Offering Party") agrees to
provide to the other Party (the "Receiving Party") a right of first offer with respect to any
proposed offer or arrangement, which the Offering Party (or its affiliate) desires to accept, under
which the Offering Party or one of its affiliates would acquire the ownership of real property in
the Market Area (the "Development Property") on which a Hyatt All-Inclusive Resort would operate (a
"Development Opportunity").

If the Offering Party is required to offer the Receiving Party a Development Opportunity pursuant to
this Section 1, the Offering Party must deliver written notice to the Receiving Party, together with
reasonable due diligence information in the Offering Party's possession to enable the Receiving
Party to evaluate the Development Opportunity (collectively, the "Offer Notice"). The Receiving
Party will have ten (10) business days after receiving the Offer Notice to notify the Offering Party
whether the Receiving Party exercises its right of first offer for that Development Opportunity. If
the Receiving Party and exercises its right of first offer hereunder, and:

(a) if the Receiving Party is Playa, then Playa (or its affiliate) and Hyatt's affiliate shall
negotiate in good faith the terms of a management agreement and related documents under which Playa
(or its affiliate) would manage a Hyatt All-Inclusive Resort on the Development Property (subject to
a franchise agreement between Hyatt and the affiliate of Hyatt that would own the Development
Property), provided that Hyatt's affiliate acquires the Development Property on terms acceptable to
it within sixty (60) days after delivery of the Offer Notice, and

(b) if the Receiving Party is Hyatt, then Playa or its affiliate shall negotiate in good faith the
terms of a franchise agreement and related documents for the operation (and, if applicable,
development) of the Hyatt All-Inclusive Resort on the Development Property, provided that Playa's
affiliate acquires the Development Property on terms acceptable to it within sixty (60) days after
delivery of the Offer Notice. 2
<!-- page 3 -->
If the Receiving Party declines its right of first offer with respect to any Development
Opportunity, or fails to notify the Offering Party of its decision within the ten (10) business-day
period described above, or if Hyatt's affiliate or Playa's affiliate (as applicable) fails to
acquire the Development Property within the sixty (60)-day period described above, then the right of
first offer with respect to that Development Opportunity shall expire, and the Offering Party
thereafter may acquire, develop and/or operate (and/or grant any other person or entity the right to
acquire, develop and/or operate) an all-inclusive resort or other business on the Development
Property without any restriction under this Agreement, subject to any restrictions under any
Existing Franchise Agreement or other agreement between Hyatt (or its affiliate) and Playa (or its
affiliate).

2. Introduction to Other Opportunities. If a third party (who is not an affiliate of Hyatt)
approaches Hyatt during the Development Term with a proposed offer or arrangement, which Hyatt
desires to accept, under which the third party would operate a Hyatt All-Inclusive Resort in the
Market Area, and if that third party has not then already designated a management company to operate
that Hyatt All-Inclusive Resort, then Hyatt agrees to provide notice to Playa and introduce Playa to
that third party for purposes of enabling Playa (at its option) to negotiate for the opportunity to
manage that Hyatt All-Inclusive Resort for that third party. Similarly, if a third party (who is not
an affiliate of Playa) approaches Playa during the Development Term with a proposed offer or
arrangement, which Playa desires to accept, under which Playa or its affiliate would manage an all-
inclusive resort in the Market Area for that third party, and if that third party has not then
already designated a brand under which that all-inclusive resort would operate, then Playa agrees to
provide notice to Hyatt and introduce Hyatt to that third party for purposes of enabling Hyatt (at
its option) to negotiate for the opportunity to provide that third party franchise rights to brand
that resort as a Hyatt All-Inclusive Resort.

3. Notices. Any notice required under this Agreement to be given by either Party to the other Party
shall be in writing in the English language. Any required notice shall be effective two business
days after it is sent by a recognized international courier service to the address of the other
Party stated in this Agreement, or such other address as shall be notified to the other Party in
writing, and any receipt issued by the courier service shall be conclusive evidence of the fact and
date of sending of any such notice.

Contact details of the Parties are as follows:

For Hyatt: Hyatt Franchising Latin America Hyatt Hotels Corporation Hyatt Center - 12th Floor 71
South Wacker Drive Chicago, Illinois 60606 U.S.A. Attention: SVP Latin America Development 3
<!-- page 4 -->
with a copy to:

Hyatt Hotels Corporation Hyatt Center - 12th Floor 71 South Wacker Drive Chicago, Illinois 60606
U.S.A. Attention: Executive Vice President, General Counsel

For Playa:

Playa Hotels & Resorts, B.V. c/o Playa Management USA LLC Playa Hotels & Resorts 1560 Sawgrass
Corporate Parkway, Suite 310 Fort Lauderdale, Florida 33323 Attention: General Counsel

or to such other address and to the attention of such persons as the Parties may designate by like
notice hereunder.

4. Choice of Law. All matters relating to arbitration will be governed by the Federal Arbitration
Act (9 U.S.C. Sections 1 et seq.). Except to the extent governed by the Federal Arbitration Act or
other federal law, this Agreement and all claims arising from the relationship between Hyatt (and/or
any of its Affiliates) and Playa (and/or any of its Affiliates) under this Agreement will be
governed by the laws of the State of Illinois (U.S.A.), without regard to its conflict of laws
rules, except that any Illinois law or any other law regulating the offer or sale of franchises,
business opportunities, or similar interests, or governing the relationship between a franchisor and
a franchisee or any similar relationship, will not apply unless its jurisdictional requirements are
met independently without reference to this Section 4.

5. Dispute Resolution.

(a) All disputes arising out of or in connection with this Agreement shall to the extent possible be
settled amicably by negotiation between the Parties within fifteen (15) days from the date of
written notice by either Party of the existence of such dispute, and, failing such amicable
settlement, shall be finally settled by arbitration under the Rules of Arbitration of the
International Chamber of Commerce ("Rules"). To the extent there is any conflict between the Rules
and the Federal Arbitration Act as it pertains to such arbitration, the Rules shall prevail.

(b) The arbitration panel shall consist of:

(i) one arbitrator in the event the aggregate damages sought by the claimant are stated to be less
than Five Hundred Thousand US Dollars (US$500,000), and the aggregate damages sought by the
counter-claimant are stated to be less than Five Hundred Thousand US Dollars (US$500,000); or 4
<!-- page 5 -->
(ii) three arbitrators in the event the aggregate damages sought by the claimant are stated to be
equal to or exceed Five Hundred Thousand US Dollars (US$500,000), or the aggregate damages sought by
the counterclaimant are stated to be equal to or exceed Five Hundred Thousand US Dollars
(US$500,000).

Each arbitrator (1) shall have no fewer than ten (10) years' experience in the international hotel
business, (2) shall be licensed to practice law in the United States, and (3) shall not be a person,
or an affiliate of a person, who has any past, present or currently contemplated future business or
personal relationship with either Playa, Hyatt or any of their respective affiliates.

(c) The place of arbitration shall be New York, New York (USA).

(d) The language to be used in the arbitration shall be English.

(e) The arbitrator(s) shall have the power to grant any remedy or relief that they deem just and
equitable, including injunctive relief, whether interim and/or final, and any provisional measures
ordered by the arbitrator(s) may be specifically enforced by any court of competent jurisdiction.
Each Party hereto retains the right to seek interim measures from a judicial or other governmental
authority, and any such request shall not be deemed incompatible with the agreement to arbitrate or
a waiver of the right to arbitrate.

(f) An arbitral tribunal constituted under this Agreement may, unless consolidation would prejudice
the rights of any Party, consolidate an arbitration hereunder with an arbitration under any
Franchise Agreement between Hyatt (or its affiliate) and Playa (or its affiliate), if the
arbitration proceedings raise common questions of law or fact. If two or more arbitral tribunals
under these agreements issue consolidation orders, the order issued first shall prevail.

(g) The Parties agree that the award(s) shall be binding upon Hyatt and Playa and each Party's
parent company or companies (and all other Affiliates), principals, successors, and assigns, and
that judgment on the award(s) may be entered in any court of competent jurisdiction, and the Parties
waive any personal jurisdiction objections for the purpose of any enforcement proceedings under the
1958 United Nations Convention on the Recognition of Enforcement of Foreign Arbitral Awards. The
arbitrator(s) may not award damages in excess of compensatory damages or otherwise in violation of
the waiver in this Agreement.

(h) Any award(s) shall be payable in U.S. Dollars. In the event that monetary damages are awarded,
the award(s) shall include interest from the date of default to the date of payment of the award in
full. The arbitrator(s) shall fix an appropriate rate of interest, compounded annually, which in no
event shall be lower than the prime commercial lending rate charged by Hyatt's primary bank (as
Hyatt may designate from time to time), to its most creditworthy commercial borrowers, averaged over
the period from the date of the default to the date of the award. 5
<!-- page 6 -->
(i) Any award(s) rendered by the arbitrator(s) shall be final and binding on the parties, and each
party hereby waives to the fullest extent permitted by law any right it may otherwise have under the
laws of any jurisdiction to any form of appeal or collateral attack or to seek determination of a
preliminary point of law by any courts (including any court within the Market Area or elsewhere).

(j) The prevailing Party in any arbitration arising out of or related to this Agreement shall be
entitled to recover from the losing Party all reasonable fees, costs and expenses incurred by the
prevailing Party in connection with such arbitration (including any actions to enforce any award(s)
or any of the provisions of this Section 5). If a Party prevails on some, but not all, of its
claims, such Party shall be entitled to recover an equitable amount of such fees, costs and expenses
as determined by the arbitrator(s). All amounts recovered by the prevailing Party under this
Subsection shall be separate from, and in addition to, any other amount included in any award(s)
rendered in favor of such Party pursuant to this Section 5.

(k) Except as may be required by law, neither a Party nor its representatives nor a witness nor an
arbitrator may disclose the existence, content, or results of any arbitration or amicable settlement
under this Section 5 (collectively, "Dispute Information") without the prior written consent of both
Parties. Each Party shall ensure that the Dispute Information is not disclosed to the press or to
any other third person or entity without the prior consent of the other Party. The Parties shall
coordinate with one another on all public statements, whether written or oral and no matter how
disseminated, regarding the Dispute Information.

6. Entire Agreement. This Agreement constitutes the entire agreement between the Parties with
respect to the subject matter of this Agreement and supersedes all prior understandings and writings
between the Parties. No Party may rely on any alleged oral or written understandings, agreements, or
representations not contained in this Agreement. Any policies that either Party adopts and
implements from time to time to guide them in their decision-making are subject to change, are not a
part of this Agreement, and are not binding on them.

7. Representations and Warranties. Each Party represents and warrants that neither the execution of
this Agreement nor the completion of the transactions contemplated hereby and thereby will (a)
violate any provision of applicable law or any judgment, writ, injunction, order or decree of any
court or governmental authority having jurisdiction over it; (b) cause a breach or default under any
indenture, contract, other commitment or restriction to which it is a party or by which it is bound;
or (c) require any filing, consent, vote or approval which has not been taken, or at the time when
the transaction involved shall not have been given or taken. Each Party represents and warrants that
as of the date hereof it has the full company power and authority to enter into this Agreement and
to perform its respective obligations under this Agreement, and that such Party's execution,
delivery and performance of this Agreement have been duly authorized by all necessary action on the
part of such Party.

8. Amendment. The provisions of this Agreement shall not be supplemented or amended except by an
instrument in writing executed and delivered by both Parties. 6
<!-- page 7 -->
9. Waiver. Failure of either Party at any time to require the performance by the other Party of any
provision hereof shall in no way affect the full right to require such performance at any time
thereafter. Hyatt and Playa will not waive or impair any right, power, or option this Agreement
reserves because of any custom or practice that varies from this Agreement's terms; Hyatt's or
Playa's failure, refusal, or neglect to exercise any right under this Agreement or to insist upon
the other's compliance with this Agreement; Hyatt's or Playa's waiver of or failure to exercise any
right, power, or option, whether of the same, similar, or different nature, with other Hyatt
All-Inclusive Resorts or any other agreements between the parties and/or their affiliates; or
Hyatt's or Playa's acceptance of any payments due from the other Party after any breach of this
Agreement (unless such payments are made within any applicable cure periods).

10. Binding Effect. This Agreement shall inure to the benefit of and bind the permitted assignees,
successors and representatives of the Parties, except that no assignment, transfer, pledge, mortgage
or lease by or through either Party in violation of the provisions of this Agreement shall vest any
rights in the assignee, transferee, mortgagee, pledgee, or lessee, as the case may be.

11. Severability. If any provision of this Agreement shall be determined to be void, illegal, or
unenforceable under the law, all other provisions of this Agreement shall continue in full force and
effect. The Parties are, in this event, obligated to replace the void, illegal or unenforceable
provision with a valid, legal and enforceable provision which corresponds as far as possible to the
spirit and purpose of the void, illegal, or unenforceable provision.

12. Language and Counterparts. This Agreement may be executed in any number of counterparts, all of
which, taken together, shall constitute one and the same agreement and a Party may enter into this
Agreement by executing a counterpart. This Agreement is executed in the English language, which
shall prevail over any translation.

13. No Representation Regarding Forecasts. In entering into this Agreement, Hyatt and Playa
acknowledge that neither Playa nor Hyatt has made any representation to the other regarding
forecasted earnings, the probability of future success or any other similar matter respecting the
business contemplated under this Agreement and that Hyatt and Playa understand that no guarantee is
made to the other as to any amount of income to be received by Hyatt or Playa or as to the future
financial success of the business contemplated under this Agreement.

14. Waiver of Non-compensatory Damages. In any action or proceeding between the Parties (including
any arbitration proceeding) arising under or with respect to this Agreement or in any manner
pertaining to the Hyatt All-Inclusive Resorts or to the relationship of the Parties under this
Agreement, each Party hereby unconditionally and irrevocably waives and releases any right, power or
privilege either may have to claim or receive from the other Party any punitive or exemplary
damages, each Party acknowledging and agreeing that the remedies herein provided and other remedies
at law or in equity will in all circumstances be adequate. Both Parties acknowledge that they are
experienced in negotiating agreements of this sort, and have had the advice of counsel in connection
with, and fully understand the nature of, the waiver contained in this Section 14. 7
<!-- page 8 -->
15. Corrupt Practices. Neither Party, nor any person acting for or on behalf of such Party, shall
make, and each Party acknowledges that the other Party will not make, any expenditure for any
unlawful purposes (i.e. unlawful under the laws or regulations of the United States, the European
Union or the Market Area) in the performance of its obligations under this Agreement or in
connection with its activities in relation thereto. Neither Party, nor any person acting for or on
behalf of such Party, shall, and each Party acknowledges that the other Party will not, bribe or
offer to bribe any government official, any political party or official thereof, or any candidate
for political office, for the purpose of influencing any action or decision of such person in their
official capacity or any governmental authority of any jurisdiction.

IN WITNESS WHEREOF, the parties hereto have duly executed and delivered this Amendment on the day
and year first above written. HYATT FRANCHISING LATIN AMERICA, L.L.C. PLAYA HOTELS & RESORTS B.V.

By: /s/ Peter Sears By: /s/ Bruce D. Wardinski Name: Peter Sears Name: Bruce D. Wardinski Title:
President Title: Executive Director 8
