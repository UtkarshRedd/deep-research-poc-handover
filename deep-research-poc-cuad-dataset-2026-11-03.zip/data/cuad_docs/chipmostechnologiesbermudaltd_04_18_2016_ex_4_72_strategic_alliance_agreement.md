<!-- page 1 -->
# Strategic Alliance Agreement
| Field | Value |
|---|---|
| Document Type | Strategic Alliance Agreement |
| Agreement Date | 2015-12-11 |
| Parties | ChipMOS TECHNOLOGIES INC. ("ChipMOS"); Tsinghua Unigroup Ltd. ("Tsinghua Unigroup"); ChipMOS and Tsinghua Unigroup shall collectively be referred to as the “Parties” |
| Source | CUAD v1 / CHIPMOSTECHNOLOGIESBERMUDALTD_04_18_2016-EX-4.72-Strategic Alliance Agreement |

Exhibit 4.72

Confidential

(Translation, for reference only)

Strategic Alliance Agreement

This Strategic Alliance Agreement ("Agreement") is executed on this 11th day of December, 2015
("Execution Date") by and between ChipMOS TECHNOLOGIES INC., a company incorporated under the laws
of Taiwan ("ChipMOS"), and Tsinghua Unigroup Ltd. ("Tsinghua Unigroup"), a company incorporated
under the laws of the People's Republic of China ("PRC"). ChipMOS and Tsinghua Unigroup shall
collectively be referred to as the "Parties."

WHEREAS, Tsinghua Unigroup actively searches for investment targets which are leading companies in
upstream, midstream, or downstream semiconductor industries, provides abundant funds to build
strategic cooperation, and jointly shares the growing business opportunities of the semiconductor
market in Mainland China; ChipMOS is a leading company engaged in the assembly and testing services
of LCD drivers and wafer bumping process technologies.

WHEREAS, ChipMOS and Tsinghua Unigroup will also, on the Execution Date, enter into the Share
Subscription Agreement ("Share Subscription Agreement"). ChipMOS agrees, according to the terms and
conditions of the Share Subscription Agreement, to increase its capital and issue 299,252,000 common
shares through private placement ("Private Placement Shares") and the Private Placement Shares will
be subscribed to by a company over which Tsinghua Unigroup has de facto control ("Subscriber");
Tsinghua Unigroup also agrees that such Private Placement Shares be subscribed to by the Subscriber
from ChipMOS ("Transaction").

WHEREAS, ChipMOS and Tsinghua Unigroup, in order to strengthen their relationship, are going to form
a strategic alliance, establish a long-term cooperative relationship, share resources and networks,
support each other in the semiconductor industry, and strive for expansion and growth. NOW,
THEREFORE, the Parties hereby agree as follows:

Article 1 Strategic Alliance

1.1 Content of Strategic Alliance and Expected Benefits After the Closing Date (as defined in the
Share Subscription Agreement), Tsinghua Unigroup and ChipMOS shall cooperate, expand, strengthen and
stabilize the relationship with the related upstream, midstream, and downstream industries engaged
in the assembly and testing services of LCD drivers, microelectromechanical systems (MEMS), the
Internet of Things (IoT) and Radio Frequency Integrated Circuits (RFIC) and/or wafer bumping
services in Mainland China. Tsinghua Unigroup shall also introduce other potential suppliers,
customers and business partners in Mainland China to ChipMOS. - 1 -

Confidential
<!-- page 2 -->
(Translation, for reference only) 1.2 Covenants of Parties

(1) Tsinghua Unigroup covenants to follow the Share Subscription Agreement to subscribe for, via the
Subscriber, in compliance with the requirements of Taiwan's laws and regulations relating to
securities transactions and PRC investment in Taiwan, at the Subscription Price per Share (as
defined in the Share Subscription Agreement), 299,252,000 common shares through private placement
from ChipMOS, and Tsinghua Unigroup shall comply with, and shall cause the Subscriber to comply with
the content of the Share Subscription Agreement, Taiwan's laws and regulations concerning securities
transactions and PRC investments in Taiwan so that ChipMOS may make use of the Total Subscription
Price (as defined in the Share Subscription Agreement) to replenish operating capital, recruit
talents, and upgrade its technologies related to the semiconductor assembly and testing services, to
create profits for each of the Parties and its shareholders.

(2) ChipMOS covenants that part or all of the Total Subscription Price shall be used:

(a) To strengthen research and development, and technologies, and expand production capacity in
Taiwan in order to strengthen itsroots in Taiwan, and increase job opportunities.

(b) To increase the capital of ChipMOS TECHNOLOGIES (Shanghai) LTD. ("ChipMOS Shanghai"), and
replenish the operating capital of ChipMOS Shanghai, in order to expand ChipMOS and its affiliates'
business scale in LCD driver and Specialty Memory IC assembly and testing services and/or wafer
bumping services markets, and thus increase ChipMOS' global market share.

(c) As funds for the merger with ChipMOS TECHNOLOGIES (Bermuda) LTD.

(d) As funds for the merger and acquisition by ChipMOS of other appropriate targets in the
semiconductor industry in Taiwanwhich have similar ideals, share a common goal, and are industrially
complimentary. - 2 -

Confidential
<!-- page 3 -->
(Translation, for reference only) 1.3 Implementation of Strategic Alliance Each of the Parties
covenants to, after the Closing Date, designate related staff to hold regular meetings to propose a
specific plan and schedule in connection with Sections 1.1 and 1.2 herein, perform the specific plan
together and review the implementation status. Each Party shall use its reasonable best efforts to
provide immediate assistance to, and actively cooperate with, the other Party, to implement this
Agreement.

Article 2 Term of Agreement

2.1 Term of Agreement Except as otherwise provided herein, the term of this Agreement is three (3)
years from the Execution Date ("Cooperation Period"). The Parties may negotiate for an extension of
this Agreement six (6) months before the expiration of the Cooperation Period.

2.2 Early Termination This Agreement may be terminated as follows:

(1) Tsinghua Unigroup and ChipMOS Taiwan terminate this Agreement by mutual agreement in writing;

(2) In the event that Tsinghua Unigroup or ChipMOS materially breaches this Agreement and such
breach is incurable, the other Party may immediately terminate this Agreement by giving written
notice to the breaching Party; if such breach is curable, this Agreement will be terminated
automatically after ten (10) days from the date on which the breaching Party received the written
notice given by the other Party, if the breaching Party fails to cure such breach; or

(3) This Agreement shall be simultaneously terminated, rescinded or become invalid upon the
termination, rescission, or invalidation of the Share Subscription Agreement.

2.3 Effects of Termination This Agreement shall immediately become void and of no further force and
effect after expiration, pursuant to Section 2.1, or termination, pursuant to Section 2.2; provided,
however, that Sections 2.2, 2.3, 3.1 and 3.9 shall survive after the termination of this Agreement.
- 3 -

Confidential
<!-- page 4 -->
(Translation, for reference only) Article 3 Miscellaneous

3.1 Governing Law and Jurisdiction This Agreement shall be governed by, and construed in accordance
with the laws of Taiwan. The Parties shall first seek to solve any dispute arising out of or related
to this Agreement through negotiation. If the Parties fail to solve such dispute through
negotiation, each Party shall have the right to issue notice ("Dispute Notice") to the other Party,
and such Dispute Notice shall include the content of the dispute. If the Parties fail to resolve
such dispute amicably through negotiation within sixty (60) days from the date on which a Party
issues its Dispute Notice to the other Party, each Party shall have the right to submit such dispute
to the Hong Kong International Arbitration Center, and proceed with the arbitration procedures in
accordance with the Rules of the International Chamber of Commerce with three (3) arbitrators. Each
Party shall each select one (1) arbitrator, and the third arbitrator shall be appointed by the two
(2) arbitrators so selected. All language used in such proceedings shall be Mandarin Chinese. The
Parties agree to keep the content of the dispute and the proceeding of the arbitration confidential.
The arbitration award shall be final and binding on the Parties. The losing Party in such
arbitration shall bear all of the costs and expenses related to the arbitration as determined by the
arbitrators in such dispute (including attorney's fees).

3.2 Assignment of Rights and Obligations Neither Party shall assign any rights or obligations
provided herein without the prior written consent of the other Party.

3.3 Entire Agreement; Amendment This Agreement constitutes the entire agreement between the Parties,
and supersedes all prior documents and agreements in connection with the Transaction. Such documents
or agreements shall be null and void immediately and cease to be applied. Except as otherwise
provided herein, both Parties' consent in writing is necessary to amend, waive, rescind or terminate
the Agreement or any terms and conditions.

3.4 Notice All notices and other expression of intent hereunder shall be issued in writing and shall
be deemed duly given by registered mail or express delivery or personal delivery to the following
address:

(1) if to ChipMOS:

ChipMOS TECHNOLOGIES INC. Representative: Shih-Jye Cheng Address: No. 1, Yanfa 1st Rd., Hsinchu
Science Park, Hsinchu, Taiwan - 4 -

Confidential
<!-- page 5 -->
(Translation, for reference only) (2) if to Tsinghua Unigroup:

Tsinghua Unigroup Ltd. Representative: Weiguo Zhao Address: F10 Unis Plaza, Tsinghua Science Park,
Haidian District, Beijing, PRC

The delivery may also be made to another address provided by a Party to the other Party in writing.
The notices and other expressions of intent for the purpose of this Agreement shall be deemed
received: when delivered by express delivery or personal delivery, at the actual time of receipt;
when delivered by mail, at the actual time of receipt or 72 hours after mailing (whichever is
earlier).

3.5 No Waiver No omission or delay of either Party to exercise any right, power or remedy herein
shall prevent such Party from exercising such right, power or remedy in the future. Any right, power
and remedy that either Party enjoys pursuant to this Agreement shall survive, unless the Party
expressly waives such right, power or remedy in writing. All rights, powers or remedies which each
Party of this Agreement may claim, pursuant to the laws and this Agreement, shall not preclude other
rights, powers or remedies that such Party may claim pursuant to the laws or this Agreement.

3.6 Expenses Regarding the expenses arising from this Agreement and the Transaction, each Party
shall bear the expenses occurred by it pursuant to the nature of such expenses and the relevant
provisions.

3.7 Severability If any provision of this Agreement is held to be illegal, unenforceable or invalid
by the judgment or ruling of the court, other provisions herein shall remain in full force and
effect.

3.8 Headings and Subheadings The headings and subheadings herein are solely for ease of reference by
the Parties, and shall not be used to interpret this Agreement. - 5 -

Confidential
<!-- page 6 -->
(Translation, for reference only) 3.9 Confidentiality The Parties agree that the Parties will not
disclose information in connection with the execution, existence, content, and performance of this
Agreement to any third party before the Parties have made an announcement to the public pursuant to
Section 3.11 of this Agreement. However, the foregoing restriction shall not apply to disclosure
made to the board of the directors, management team, and relevant employees who need to know such
information, attorneys, accountants, financial counsel, and competent authorities for the purposes
of performing this Agreement.

3.10 Actual Performance The Parties acknowledge and agree that if any of the provisions provided
herein are not performed in accordance with the specific terms and conditions or are otherwise
violated, this will cause irreparable damages for which monetary compensation would not be an
adequate remedy. Therefore, the Parties agrees that, in addition to any other remedies available in
common law or equity, each Party shall be entitled to seek injunction and other equitable remedies,
including the actual performance of the terms and conditions provided herein, and it is not
necessary to post any bond or other security.

3.11 Announcement The Parties shall not make an announcement to the public without the consent of
the Parties regarding the execution and content of this Agreement and information in connection with
the performance of this Agreement, which includes, but is not limited to the disclosure of material
information, pursuant to the laws and the content thereof. The Parties shall negotiate and determine
whether to make the announcement by press release, press conference or any other method and the
content of the announcement. However, in the event that a Party discloses the above-mentioned
information pursuant to the laws or requests made in judicial proceedings, and the disclosing Party
could not obtain the consent of the other Party in time or the other Party refused to provide its
consent without proper reasons after the disclosing Party notified the other Party of such
situation, then the disclosing Party may disclose the above-mentioned information.

3.12 Counterparts This Agreement shall be executed in four (4) originals. ChipMOS and Tsinghua
Unigroup shall hold two (2) originals each.

[Signature page follows] - 6 -

Confidential
<!-- page 7 -->
(Translation, for reference only) This is the signature page for the "STRATEGIC ALLIANCE AGREEMENT."
ChipMOS TECHNOLOGIES INC. Tsinghua Unigroup Ltd.

By: /s/ Shih-Jye Cheng By: /s/ Weiguo Zhao Name: Shih-Jye Cheng Name: Weiguo Zhao Title: Chairman
Title: Chairman - 7 -
