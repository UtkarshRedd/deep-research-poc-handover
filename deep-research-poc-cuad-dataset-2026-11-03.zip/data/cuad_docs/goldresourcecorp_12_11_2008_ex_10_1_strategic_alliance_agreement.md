<!-- page 1 -->
# STRATEGIC ALLIANCE AGREEMENT
| Field | Value |
|---|---|
| Document Type | Strategic Alliance Agreement |
| Agreement Date | 2008-12-05 |
| Parties | GOLD RESOURCE CORPORATION ("GRC", "the Company"); HOCHSCHILD MINING HOLDINGS LIMITED ("HOC") |
| Source | CUAD v1 / GOLDRESOURCECORP_12_11_2008-EX-10.1-STRATEGIC ALLIANCE AGREEMENT |

Exhibit 10.1

STRATEGIC ALLIANCE AGREEMENT

THIS AGREEMENT dated for reference the 5th day of December 2008.

BETWEEN:

GOLD RESOURCE CORPORATION, a company organized under the laws of the State of Colorado, with
registered office located at 222 Milwaukee Street, Suite 301, Denver, CO 80206 ("GRC" or "the
Company")

AND:

HOCHSCHILD MINING HOLDINGS LIMITED, a private limited company organized under the laws of England
and Wales, with registered office located at 46 Albemarle Street, London, England W1S 4JL ("HOC")

WHEREAS:

A. The Company is a mineral exploration and development company engaged in the acquisition and
exploration, as well as development of mineral properties (the "Properties") in Mexico through its
Mexican subsidiaries with prospects for hosting gold, silver and base metal deposits, and through
such subsidiaries holds interests in several mineral resource properties, including but not limited
to (i) El Aguila, (ii) Las Margaritas, (iii) Solaga, and (iv) El Rey located in Oaxaca, Mexico (the
"Existing Properties");

B. HOC is an Affiliate of Hochschild Mining plc., a leading underground precious metals producer
operating in the Americas with a primary focus on silver and gold;

C. The Company and HOC believe that their respective corporate strategies are compatible and, as
such, wish to establish a strategic alliance on the terms and conditions set forth herein;

D. The Company and HOC are entering into this Agreement as a condition to and in furtherance of the
investment in Shares (as defined below) contemplated in the Subscription Agreement dated December 5,
2008 (the "Subscription Agreement") between the Company and HOC without the Company having executed
and delivered this Agreement; and

E. The Board of Directors has authorized the Company to enter into this Agreement.

NOW THEREFORE THIS AGREEMENT WITNESSES that in consideration of the mutual premises, covenants and
agreements contained herein, and other good and valuable consideration, the receipt and sufficiency
of which are hereby acknowledged by both parties, the parties hereby covenant and agree as follows:

ARTICLE 1

INTERPRETATION

1.1 Definitions. In this Agreement, unless the context otherwise requires:
<!-- page 2 -->
(a) "Acceptance Notice" has the meaning ascribed to it in Section 4.1(e);

(b) "Additional Securities" has the meaning ascribed to it in Section 4.1(a);

(c) "Additional Shares" has the meaning ascribed to it in Section 2.1;

(d) "Affiliate" shall have the meaning ascribed thereto in the Securities Act;

(e) "Agreement" means this strategic alliance agreement and any instrument amending this Agreement
and "hereof", "hereto", "hereunder" and similar expressions mean and refer to this Agreement and not
to a particular Article, Section, Subsection or Paragraph;

(f) "Alternative Proposal" has the meaning ascribed to it in Section 9.1;

(g) "Authority" and "Authorities" means any (i) multinational, federal, provincial, state, regional,
municipal, local or other government, governmental or public department, securities commission
(including the Securities Commissions), central bank, court, tribunal, arbitral body, commission,
board, bureau or agency, domestic or foreign, (ii) any subdivision, agent, commission, board, or
authority of any of the foregoing, or (iii) any quasi-governmental or private body exercising any
regulatory, expropriation or taxing authority under or for the account of any of the foregoing, and
includes a stock exchange and any other self-regulatory authority;

(h) "Board of Directors" means the board of directors of the Company;

(i) "Business Day" means any day which is not a Saturday, a Sunday or a day on which banks are
generally closed for business in Denver, Colorado or London, England;

(j) "Claims" means all losses, damages, expenses, Liabilities, claims and demands of whatever nature
or kind, including all reasonable legal fees and disbursements;

(k) "Closing Date" has the meaning given to it in the Subscription Agreement;

(l) "Commencement of Production" has the meaning given to it in Section 2.3;

(m) "Common Stock" has the meaning given to it in Section 4.1(a);

(n) "Company" has the meaning given to it in the preamble hereto;

(o) "Company Indemnitees" has the meaning given to it in Section 11.2;

(p) "Convertible Securities" means all warrants, rights, agreements, options, or Debt Instruments
present or future, contingent or absolute, or any right or privilege capable of becoming a right,
agreement or option, for the purchase, subscription or issuance of any Shares in the Company or any
other security or Debt Instruments convertible or exchangeable for Shares, including options granted
to officers, directors or employees, and whether issued pursuant to the Stock Option Plan;

2
<!-- page 3 -->
(q) "Debt Instrument" means any loan, bond, debenture, promissory note or other instrument
evidencing material indebtedness of the Company for borrowed money or other material liability;

(r) "Equity Securities" means Shares, Convertible Securities and any other equity or voting
securities of the Company;

(s) "Existing Properties" has the meaning given to it in the preamble hereto;

(t) "Financing Election" has the meaning ascribed to it in Section 2.3;

(u) "HOC Director" has the meaning ascribed to it in Section 5.1;

(v) "HOC Entities" means HOC and its Affiliates, and any person acting jointly or in concert with
any of them, excluding, for greater certainty, the Company and any of its Subsidiaries to the extent
they may be or become Affiliates at any relevant point in time;

(w) "HOC Indemnitees" has the meaning ascribed to it in Section 11.1;

(x) "HOC JV Acceptance Notice" has the meaning ascribed to it in Section 6.2(b);

(y) "HOC Option" has the meaning ascribed to it in Section 2.1;

(z) "Joint Venture Proposal Notice" has the meaning ascribed to it in Section 6.2(a);

(aa) "JV Negotiation Period" has the meaning ascribed to it in Section 6.2(b);

(bb) "Laws" means any and all applicable (i) laws, constitutions, treaties, statutes, codes,
ordinances, orders, decrees, rules, regulations and municipal by-laws, (ii) judicial, arbitral,
administrative, ministerial, departmental or regulatory judgments or orders of any Authorities, and
(iii) policies, guidelines and protocols;

(cc) "Liabilities" means, with respect to any Person, any liability or obligation of such Person of
any kind, character or description, whether known or unknown, absolute or contingent, accrued or
unaccrued, disputed or undisputed, liquidated or unliquidated, secured or unsecured, joint or
several, due or to become due;

(dd) "Lien" means any mortgage, easement, encroachment, adverse claim, and assignment by way of
security, security interest, servitude, pledge, charge, lien, assignment, hypothecation, conditional
sale agreement, title retention, preferential right, trust arrangement, right of set-off,
counterclaim or banker's lien, financing statement, privilege or priority, or other encumbrance of
any kind having the effect of security, any designation of loss payees or beneficiaries or any
similar arrangement under or with respect to any insurance policy or any preference of one creditor
over another arising by operation of law;

(ee) "Market Purchases" has the meaning ascribed to it in Section 3.1;

3
<!-- page 4 -->
(ff) "Option Exercise Notice" has the meaning ascribed to it in Section 2.1;

(gg) "Option Expiration Date" has the meaning ascribed to it in Section 2.1;

(hh) "Options" means outstanding options to acquire Shares under the Stock Option Plan;

(ii) "Other Purchasers" has the meaning ascribed to it in Section 4.1(a);

(jj) "Parties" means the Company and HOC and their successors and permitted assigns; and "Party"
means any one of them;

(kk) "Person" means an individual, partnership, unincorporated association, organization, syndicate,
corporation or trust or a trustee, executor, administrator or other legal or personal
representative;

(ll) "Private Agreement Purchases" means purchases of Equity Securities other than on any stock
exchange on which the Shares are then listed or quoted provided such purchases are made in
accordance with applicable Laws, including applicable Securities Laws;

(mm) "Pro Rata Interest" has the meaning ascribed to it in Section 4.1(a);

(nn) "Proposed Joint Venture" has the meaning ascribed to it in Section 6.1(a);

(oo) "Properties" has the meaning ascribed to it in the Preamble hereto;

(pp) "Purchased Shares" shall mean the shares of Common Stock to be acquired by HOC pursuant to the
terms of the Subscription Agreement.

(qq) "Rights Notice" has the meaning ascribed to it in Section 4.1(c);

(rr) "Securities Exchange Act" means the Securities Exchange Act of 1934;

(ss) "Securities Commissions" means the securities regulator in each jurisdiction whose Securities
Laws are applicable to the Company;

(tt) "Securities Laws" means the Laws relating to securities of the Company, and the regulations and
rules made and forms prescribed thereunder together with all applicable published policy statements,
blanket orders, rulings and notices adopted by the Securities Commissions of each such jurisdiction
or applicable in such jurisdictions;

(uu) "Shareholders" means the holders of Shares;

(vv) "Shares" means common shares or any other securities into which the common shares in the
capital of the Company are reorganized, exchanged or converted;

(ww) "Stock Option Plan" means any stock option plan, agreement or arrangement adopted by the
Company from time to time which provides for the issuance of options to acquire Shares;

4
<!-- page 5 -->
(xx) "Subscription Agreement" has the meaning ascribed to it in the Preamble hereto;

(yy) "Subsequent Closing Date" has the meaning ascribed to it in Section 2.1;

(zz) "Transactions" means the transactions contemplated in this Agreement.

1.2 Gender and Certain References. Whenever the context requires, the gender of all words used shall
include the masculine, feminine and neuter, and the number of all words shall include the singular
and plural. The terms "hereof", "herein" or "hereunder"shall refer to this Agreement as a whole and
not to any particular Article or Section hereof. All titles and headings to Articles and Sections in
this Agreement are included for convenience and ease of reference. Titles and headings shall not
affect in any way the meaning or interpretation of Articles or Sections of this Agreement. Any
references to specific Articles or Sections shall mean the Articles and Sections in this Agreement.

ARTICLE 2 ADDITIONAL INVESTMENTS BY HOC

2.1 HOC Option to Purchase Additional Shares. From and after the Closing Date and until 5:00 pm
Denver time on the date which is eighty (80) days from the Closing Date (the "Option Expiration
Date"), HOC shall have the option (the "Option"), at its sole discretion, to subscribe for all, but
not less than all, of an additional 4,330,000 Shares from the Company (the "Additional Shares") at a
price of US$3.00 per share, or a total of US$12,990,000. If HOC wishes to exercise the Option, it
shall give written notice to the Company (the "Option Exercise Notice") prior to the Option
Expiration Date in the manner set forth in Section 12.1 of this Agreement. If HOC fails to deliver
the Option Exercise Notice on or before the Option Expiration Date, HOC shall be deemed to have
waived its rights under this Section 2.1. In the event HOC exercises the Option, one or more of the
HOC Entities shall subscribe and pay for and the Company shall issue to the relevant HOC Entities,
free and clear of any liens or encumbrances, the Additional Shares and the Parties shall exchange
representations and warranties substantially similar to those contained in the Subscription
Agreement and execute such documents as may be necessary to complete the subscription and sale of
the Additional Shares. Closing of the purchase and sale of the Additional Shares shall take place
within ten (10) business days of the delivery of the Option Exercise Notice, such date being
referred to as the "Subsequent Closing Date".

2.2 Use of Proceeds. In the event HOC exercises the Option, the Company agrees to use not less than
five million U.S. Dollars (US$5,000,000) of the proceeds from the subscription of the Purchased
Shares and the Additional Shares to fund exploration activities (including but not limited to
drilling, assaying and staking new claims) on the El Aguila project. The Company further agrees that
the balance of the proceeds from the subscription of the Purchased Shares and the Additional Shares
shall be used as follows: (i) ten million U.S. Dollars (US$10,000,000) to fund the development and
construction of the mine and plant for the El Aguila project; and (ii) three million U.S. Dollars
(US$3,000,000) for working capital of the Company and other investments in the El Aguila project.

5
<!-- page 6 -->
2.3. Additional Financing. Subject to the provisions of Section 8.2, if the Company determines to
solicit additional equity financing subsequent to exercise of the Option but prior to Commencement
of Production (hereinafter defined) at the El Aguila project, it shall provide written notice to
that effect to HOC and HOC shall be entitled to exclusively provide such financing upon the terms
and conditions hereinafter set forth. For purposes of the preceding sentence, "Commencement of
Production" shall be defined as the production and delivery to the point of sale (refiner) by the
Company (either directly or through a subsidiary) of not less than 4,000 ounces of gold within a 45
day period. HOC shall have ten (10) Business Days from delivery of such notice in which to notify
the Company that it desires to provide all of such financing (the "Financing Election"). If HOC
delivers the Financing Election, the purchase price for each share shall be equal to eighty percent
(80%) of the average closing price of the Shares during the thirty (30) calendar days preceding the
date HOC delivers the Financing Election. Closing of the subscription, purchase and sale shall be at
such place and time as the Parties agree but not more than ten (10) days from delivery of the
Financing Election. If HOC delivers the Financing Election, one or more of the HOC Entities shall
pay the purchase price for, and the Company shall issue, additional Shares, free and clear of all
liens and encumbrances. The Parties shall exchange representations and warranties, in form and in
substance substantially similar to those provided in the Subscription Agreement and execute such
documents as may be necessary to complete the subscription and sale of the Shares. In the event HOC
fails to provide the Financing Election as set forth above, the Company shall be free to obtain such
financing from one or more additional parties, free of any obligation to HOC.

ARTICLE 3 MARKET PURCHASES AND PRIVATE PURCHASES

3.1 Market Purchases.Subject to compliance with applicable laws, the HOC Entities shall at any time
and from time to time, in their sole discretion, be entitled to make purchases of the Company's
common stock in the over-the-counter market or on any stock exchange on which its common stock is
then quoted or listed (the "Market Purchases"); provided, however, that for a period of two (2)
years following the Closing Date, unless the Parties otherwise agree, the HOC Entities do not
beneficially own, directly or indirectly, more than forty percent (40%) of the Company's outstanding
common stock on an undiluted basis, following any Market Purchase and any Private Agreement
Purchase. For purposes of this Agreement, beneficial ownership shall be determined in accordance
with the provisions of Rule 13d-3 of the Securities Exchange Act.

3.2 Private Purchase.In addition to Market Purchases, as described in Section 3.1 above, HOC shall
be entitled to make Private Agreement Purchases, provided that such purchases are made in accordance
with all applicable laws; and provided further, that for a period of two (2) years following the
Closing Date, unless the Parties otherwise agree, the HOC Entities will not beneficially own more
than forty percent (40%) of the Company's outstanding common stock on an undiluted basis following
any Market Purchase and/or Private Agreement Purchase. At the request of HOC, the Company shall
introduce HOC to persons whom the Company believes may be interested in selling its common stock.

6
<!-- page 7 -->
ARTICLE 4 PRE-EMPTIVE RIGHT

4.1 HOC's Pre-emptive Right.

(a) Subject to the provisions of subsection (g) of this Section 4.1 and Section 8.2 hereof, if at
any time after the Closing Date, the Company proposes to issue or sell Equity Securities
("Additional Securities") other than (i) under any Stock Option Plan, (ii) pursuant to the exercise
of options under any Stock Option Plan, (iii) upon the exercise, exchange or conversion of any
Convertible Securities, or (iv) for property other than money, the HOC Entities shall have the right
to subscribe for and purchase Additional Securities, at the price at which such Additional
Securities are offered for sale to other purchasers (the "Other Purchasers"), up to its Pro Rata
Interest (as defined below) prior to giving effect to the issuance or sale of such Additional
Securities. "Pro Rata Interest" means, at any relevant time, the ownership interest of HOC,
expressed as a percentage, equal to: (i) the number of outstanding shares of common stock of the
Company ("Common Stock") beneficially owned by the HOC Entities, including all shares of Common
Stock issuable upon the conversion, exercise or exchange of all Convertible Securities beneficially
owned by the HOC Entities divided by (ii) the aggregate number of outstanding shares of Common
Stock, plus the number of shares of Common Stock issuable upon the conversion, exercise or exchange
of all outstanding Convertible Securities;

(b) If the Company issues Equity Securities in circumstances that would not give rise to the rights
of the HOC Entities pursuant to Section 4.1(a) (the "Non-Participating Transaction"), then in any
concurrent or subsequent transaction which does give rise to the rights of the HOC Entities pursuant
to Section 4.1(a) (the "Participating Transaction"), the Company shall allow the HOC Entities to
subscribe for and purchase Additional Securities in an amount greater than HOC's Pro Rata Interest;
provided that in the Participating Transaction, HOC shall not be entitled to purchase any more than
its Pro Rata Interest of the securities sold collectively in the Non-Participating Transaction and
the Participating Transaction.

(c) If the Company intends to authorize and/or issue equity securities that give rise to the rights
of HOC pursuant to Section 4.1(a), the Company shall provide notice to HOC (the "Rights Notice") no
less than ten (10) business days before the date on which the Company intends to issue equity
securities giving rise to the rights of HOC in Section 4.1(a).

(d) The Rights Notice shall specify sufficient information regarding the particulars of the issuance
or sale of the Additional Securities to allow HOC to make a reasoned decision in respect of making
the investment, including to the extent any such terms are determinable at such time: (i) the total
number of equity securities outstanding as of the date thereof; (ii) the total number of Additional
Securities which are being offered; (iii) the rights, privileges, restrictions, terms and conditions
of such Additional Securities; (iv) the amount payable by HOC for the Additional Securities to which
it is entitled pursuant to Section 4.1(a); and (v) the proposed closing date, and thereafter, to the
extent it is not included in the Rights Notice, the Company shall immediately provide notice to HOC
of such information as it is determined.

(e) HOC shall give notice (an "Acceptance Notice") to the Company not later than 5:00 p.m. (Denver
time) on the tenth business day following the deemed receipt of any Rights Notice given under
paragraph 4.1(c) setting out the number of Additional Securities, if any, which any of HOC Entities
intends to subscribe for and purchase and, if applicable, the name and address of HOC Entity whose
name in which such securities should be registered, provided that if HOC, acting reasonably,
determines that it has insufficient information to make such investment decision, HOC shall notify
the Company of the information required to make such investment decision and thereafter shall have
the longer of (i) the remainder of the ten (10) Business Days set out in the first sentence of this
paragraph; or (ii) two (2) Business Days from the receipt of such additional information to make the
investment decision and deliver or refrain from delivering the Acceptance Notice. Notwithstanding
the preceding sentence, the Rights Notice shall be deemed to include sufficient information to make
such investment decision if it includes the information specified in items (i) to (iv) of Section
4.1(d). If no Acceptance Notice has been provided to the Company within the required time, HOC will
be deemed to have elected not to subscribe for or purchase any such Additional Securities.

7
<!-- page 8 -->
(f) Following delivery of the Acceptance Notice, if any, the HOC Entities shall pay for, and the
Company shall issue to the relevant HOC Entities, free and clear of any liens, the number of
Additional Securities specified in the Acceptance Notice and, except as otherwise agreed, the
Company shall provide HOC with substantially the same closing documents, including opinions, if
applicable, as are delivered to the other persons subscribing for Additional Securities on the
closing date for such issuance.

(g) The rights granted to HOC under this Article 4 shall terminate and be of no further force or
effect if HOC does not exercise Option and complete the purchase of the Additional Shares.

ARTICLE 5 BOARD REPRESENTATION

5.1 Appointment of HOC Nominee. If, but only if HOC exercises the Option and completes the
acquisition of the Additional Shares, HOC shall be entitled to nominate one (1) individual to the
Board of Directors (the "HOC Director"). Upon receipt of such nomination and its satisfaction that
the individual nominated by HOC meets the qualification requirements for directors under applicable
laws, the Board of Directors further agrees to expand its membership to four (4) positions and
appoint the individual nominated by HOC to the newly-created vacancy. The Board of Directors further
agrees that if HOC maintains a Pro Rata Interest of at least 14.5%, it shall nominate such
individual to the slate of directors at each subsequent annual meeting so long as the provisions of
Section 8.2 are not invoked.

5.2 Increase in Membership of the Board of Directors. If HOC acquires the Additional Shares and
subsequently acquires additional Shares such that it holds a Pro Rata Interest of 40% or more, HOC
shall be entitled to appoint one (1) additional individual to the Board of Directors. For greater
clarity, if HOC exercises the Option and holds a Pro Rata Interest of at least 40%, HOC shall be
entitled to appoint a total of two (2) individuals to the Board of Directors. Upon receipt of a
nomination from HOC for the second director and its satisfaction that the individual meets the
qualification requirements for directors under applicable law, the Board of Directors agrees to
expand its membership to five positions and appoint the individual nominated by HOC to the newly
created vacancy. The Board of Directors further agrees that so long as HOC maintains a Pro Rata
Interest of at least 35%, it shall nominate such individual to the slate of directors at each
subsequent annual meeting so long as the provisions of Section 8.2 are not invoked. The Company
further agrees that if HOC exercises the Option and so long as the provisions of Section 8.2 are not
invoked, it will not take any action to authorize and will cause the Board of Directors not to
authorize any proposal to expand the Board beyond five (5) members without the advance written
approval of HOC.

8
<!-- page 9 -->
5.3 Board Meetings. At all times when the provisions of Section 5.1 are satisfied, the Company shall
provide HOC Director(s) not less than 7 (seven) Business Days advance written notice of the date on
which any meeting of the Board of Directors shall be held. In providing such notice, the Company
shall take into consideration the matters to be discussed at the meeting, the proximity to the place
of the meeting and the time zone in which the HOC Director is resident.

5.4 Resignation of HOC Director(s). If (x) one or both HOC Directors do not meet the individual
qualifications for a director prescribed by applicable laws, (y) the Pro Rata Interest of HOC falls
below 14.5%, or (z) the provisions of Section 8.2 hereof become applicable and the Company delivers
notice to HOC to that effect, all of the HOC Directors shall forthwith resign; provided, however,
that in the event of (x), HOC shall then be entitled to appoint an individual to replace the
resigning director(s) and such resigning director(s) shall be afforded the benefits of any indemnity
and insurance as may exist for all matters occurring prior to such resignation.

5.5 Indemnification and Director's and Officer's Insurance. So long as HOC is entitled to nominate
and maintain a director pursuant to this Article 5, the Company shall indemnify each current and
former HOC Director and shall maintain director's and officer's liability insurance for the benefit
of each such director, with the same rights and benefits as are accorded the directors of the
Company generally.

ARTICLE 6 RIGHT OF FIRST OFFER

The provisions of this Article 6 shall apply if, but only if, HOC exercises the Option and acquires
the Additional Shares and so long as the provisions of Section 8.2 do not apply:

6.1 Joint Venture

(a) If the Company or any of its Subsidiaries decides to seek a joint venture partner to develop,
acquire or otherwise earn an interest in any Properties including the Existing Properties, in
circumstances where the Company's participation in such joint venture is not dependent on the
participation of a particular third party as joint venture partner (such as in the case of an
earn-in) (each a "Proposed Joint Venture"), the Company shall immediately provide notice to HOC (the
"Joint Venture Proposal Notice") specifying sufficient information regarding the particulars of the
Proposed Joint Venture to allow HOC to make a reasoned decision in respect of participating in the
Proposed Joint Venture, including to the extent any such terms are determinable at such time: (A) a
description of the Property in respect of which the Proposed Joint Venture relates, and (B) the
terms, including the purchase price, for the Proposed Joint Venture, and if applicable, a true copy
of any related term sheet setting forth such terms.

Notwithstanding the foregoing, nothing in this Section 6.1 shall prevent the Company from
concurrently negotiating with third parties with respect to those matters set out in this Section
6.1.

(b) If HOC, acting reasonably, determines that the Joint Venture Proposal Notice contains
insufficient information to make a reasoned decision in respect of participating in the Proposed
Joint Venture, it shall notify the Company of the information required to make such decision and
thereafter shall have the greater of (i) five (5) Business Days from the receipt of such information
from the Company, and (ii) the days remaining in the period specified in Section 6.2 to make such
decision and deliver or refrain from delivering the HOC JV Acceptance Notice in accordance with such
Section 6.2. Notwithstanding the foregoing, a copy of the term sheet for the Proposed Joint Venture
shall be deemed to be sufficient information to make such reasoned decision, if it includes the
information specified in Section 6.1(a).

9
<!-- page 10 -->
6.2 Joint Venture Proposal

(a) Receipt of the Joint Venture Proposal Notice by HOC shall be deemed to constitute an invitation
to HOC Entities to participate in the Proposed Joint Venture.

(b) If any of HOC Entities provides the Company an acceptance (the "HOC JV Acceptance Notice") in
writing in respect of the Joint Venture Proposal Notice, within fifteen (15) Business Days of
receipt thereof or such shorter period as may be specified in the Joint Venture Proposal Notice of a
determination in respect of the Proposed Joint Venture, the Company shall negotiate exclusively in
good faith with HOC to finalize terms of the Proposed Joint Venture acceptable to each of the
Parties, acting reasonably, within a period of sixty days or such additional period as the Parties
may from time to time agree in writing (the "JV Negotiation Period"), failing which the Company
shall be entitled to pursue other partners for the Proposed Joint Venture. If HOC does not provide
HOC JV Acceptance Notice to the Company within fifteen (15) Business Days or such shorter period as
may be specified in the Joint Venture Proposal Notice, of receiving of the Joint Venture Proposal
Notice, the Company may enter into negotiations with any other person regarding the Proposed Joint
Venture. If the Company truncates the period during which the HOC JV Acceptance Notice is required
to be returned by HOC, it shall include in the Joint Venture Proposal Notice a statement certified
by an officer of the Company that the Company has determined that it is necessary to truncate such
period to avoid losing the opportunity to make such acquisition or other related transaction and
that it has used commercially reasonable efforts to avoid truncating such period.

ARTICLE 7 STANDSTILL

The provisions of this Article 7 shall apply if HOC acquires the Additional Shares and for a period
of two (2) years after the Subsequent Closing Date:

7.1 Standstill

(a) HOC covenants and agrees that, except as otherwise contemplated in this Agreement, HOC will not,
and will not allow any HOC Entities to, in either case, without the prior written consent of the
Company, directly or indirectly:

(i) acquire or enter into any agreement to acquire or make any proposal or offer to acquire in any
manner any equity securities of the Company (whether issued or unissued) that would result in a Pro
Rata Interest greater than 40% other than (A) as a result of a stock dividend or distribution made
by or a recapitalization of the Company, (B) in accordance with the terms of any dividend
reinvestment or share purchase plan made available from time to time by the Company to holders of
equity securities; (C) pursuant to the exercise of rights issued pursuant to a rights offering made
by the Company to the holders of its equity securities; or (D) pursuant to the exercise of rights
issued pursuant to any shareholder rights plan of the Company and attached to equity securities;

10
<!-- page 11 -->
(ii) assist, encourage or advise any other person to acquire or agree to acquire in any manner any
equity securities;

(iii) propose or support or engage in any discussions or negotiations with respect to, or enter into
any agreement, commitment or understanding with any third party to effect, any tender offer, merger,
business combination, asset or share transaction, financing transaction or corporate restructuring
involving the Company;

(iv) make or participate directly or indirectly in any solicitation of proxies from shareholders of
the Company;

(v) form, join or in any way participate in any group acting jointly or in concert with any of the
foregoing; or

(vi) make any public disclosure of any intention in connection with the foregoing;

(each an "Acquisition Proposal").

(b)Notwithstanding Section 6.1, none of the HOC Entities shall be prohibited from making an
Acquisition Proposal:

(i) in the event the Company materially breaches its obligations under Section 2.3 (Additional
Financing), Article 4 (Pre-Emptive Right), Article 5 (Board Representation) or Article 6 (Right of
First Offer), provided that HOC has notified the Company of any alleged breach and the Company has
failed to cure such alleged breach, if curable, within thirty days of such notice;

(ii) from the date any public announcement of or public disclosure of an intention to commence or
enter into any agreement with respect to any of the following is made by any person (other than any
HOC Entity) to the date of the withdrawal or cancellation of the Tender Offer Transaction or
Business Combination Transaction (each as defined below):

A) a tender offer or an intention to undertake a tender offer for equity securities of the Company
by any person or group of persons (other than any HOC Entities) which if completed would result in
such tender offer person or group of persons holding 20% or more on a non-diluted basis of any class
of then outstanding equity securities of the Company (a "Tender Offer Transaction"); or

11

B) any acquisition (excluding a Tender Offer Transaction), merger, asset purchase and sale, business
combination
<!-- page 12 -->
B) any acquisition (excluding a Tender Offer Transaction), merger, asset purchase and sale, business
combination transaction or other extraordinary transaction involving or relating to the Company or
any of its subsidiaries, or an intention to make an offer to the Company and/or its subsidiaries to
undertake such a transaction, by any person or group of persons (other than any HOC Entities) which
would, if completed, result in (I) any class of outstanding equity securities being converted into
cash or securities of another person resulting in shareholders holding less than 50% of the equity
and/or voting securities of the resulting entity; or (II) all or substantially all of the Company's
assets being sold to any person or group of persons (other than any HOC Entities) (a "Business
Combination Transaction"), provided that in the case of this Section 6.1(b)(ii)(B) HOC must make
such Acquisition Proposal confidentially to the Board of Directors and not by way of public offer to
the shareholders.

For greater certainty, if HOC has commenced an Acquisition Proposal in reliance on this Section
6.1(b)(ii) or in respect of Section 6.1(b)(ii)(B), has agreed with the Company to an Acquisition
Proposal, prior to the withdrawal or cancellation of such Tender Offer Transaction or Business
Combination Transaction, HOC shall not be precluded from continuing with such Acquisition Proposal
by reason only of the withdrawal or cancellation of any relevant Tender Offer Transaction or
Business Combination Transaction; or

(iii) if a person or group of persons other than any of the HOC Entities, the Company or its
subsidiaries obtains proxies carrying a majority of the votes attached to all outstanding voting
securities of the Company and exercises such votes to replace the Board of Directors.

7.2 Most Favored Nation. The Company shall immediately inform HOC and provide HOC with a copy of any
other standstill provisions in any agreement pertaining to the matters set forth in this Article 6,
entered into by the Company with another person subsequent to the date hereof, and notwithstanding
delivery of such notice and a copy of any such provisions, HOC shall have the full benefit of any
materially more favourable terms, in the opinion of HOC, contained in such standstill and Section
6.1 shall be deemed to be amended accordingly.

ARTICLE 8 COVENANTS

8.1 Designation of Consulting Geologists. During the time up to the Option Expiration Date, and
thereafter if HOC exercises the Option and acquires the Additional Shares and the provisions of
Section 8.2 do not apply, HOC shall have the right to designate one full or part time geologist to
act as a consultant to the Company at any of its Existing Properties for the purpose of advising the
Company with regard to ongoing exploration and development. The Company shall provide such geologist
with room and board while such geologist is on-site at any of the Existing Properties. HOC, however,
shall be responsible for payment of any compensation for such geologist. Other consulting services
which may be required by the Company, including metallurgical, underground mining engineering or
concentrate contract negotiations, may be requested from HOC, and provided that HOC agrees to
deliver those services, any charges for such services shall be billed by HOC to the Company at no
more than HOC's actual cost plus 1%.

12
<!-- page 13 -->
8.2 Termination of Certain HOC Rights. Notwithstanding anything in this Agreement to the contrary,
in the event (i) HOC shall hold a Pro Rata Interest less than 14.5% or (ii) HOC shall have achieved
a Pro Rata Interest greater than 14.5% but subsequently sells or otherwise disposes of 20% or more
of its Pro Rata Interest in any one or more transactions, the benefits provided to HOC pursuant to
the provisions of Section 2.3 (Additional Financing), Article 4 (Pre-Emptive Rights), Article 5
(Board Representation), Article 6 (First Offer) and Section 8.1 (Designation of Geologist) above
shall immediately terminate and be of no further force or effect. Furthermore, any HOC Director
nominated and appointed pursuant to the provisions of Section 5.1 or 5.2 shall immediately resign in
the event that the provisions of subsection (i) or (ii) above shall be applicable.

ARTICLE 9 ADDITIONAL COVENANTS

9.1 Covenants of the Company.

(a) Prior to the Option Expiration Date, the Company shall not and shall not permit its Affiliates,
agents or other representatives (including any director, officer, investment banker, legal advisor
or accountant retained by the Company or any of its Susidiaries) to:

(i) initiate, solicit, promote or encourage, directly or indirectly, inquiries or the submission of
proposals or offers from any Person with respect to any proposal or offer or action that would
reasonably be expected to delay, prevent or frustrate the Transactions or any part thereof (an
"Alternative Proposal");

(ii) encourage, or participate or engage in negotiations concerning, or furnish to any Person other
than to HOC Entities, any non-public information with respect to, or otherwise co-operate in any way
with, or participate in, or facilitate or encourage any Person to make an Alternative Proposal; or

(iii) endorse, accept, approve or recommend a proposal of, or enter into any Contract or
understanding with , any Person relating to an Alternative Proposal, or otherwise facilitate any
effort or attempt to make or implement an Alternative Proposal.

(b) Notwithstanding anything else in this Section 9.1, if the Company or any of its subsidiaries
receives an unsolicited Alternative Proposal prior to the Option Exercise Date, the Board of
Directors may participate in discussions with, furnish information to, or enter into an agreement
with the Person that initiated the Alternative Proposal only if: (x) the Board of Directors
determines in good faith, after consultation with outside counsel, that such action is necessary in
order for them to act in a manner consistent with their fiduciary duty under applicable Laws; (y)
the Company shall have provided to HOC notice at least five (5) Business Days prior to the date on
which the agreement to effect such Alternative Proposal is to be entered into specifying the terms
of the Alternative Proposal; and (z) after taking into account modifications to this Agreement
proposed by HOC during such five Business Day period, such proposal would constitute a superior
proposal ("Superior Proposal"). If HOC makes a proposal to amend this Agreement to increase the
purchase price payable for the Additional Shares, such that the proposal of such other Person shall
no longer be a Superior Proposal, and shall complete the purchase of the Additional Shares upon such
terms, then neither the Company nor its subsidiaries shall enter into such Alternative Proposal.

13
<!-- page 14 -->
(c) The Company shall comply with all securities regulatory filing requirements on a timely basis in
connection with the issuance of any Equity Securities of the Company to any HOC Entity, including
filing within the periods stipulated under Securities Laws, at the Company's expense, all private
placement forms required to be filed by the Company and paying all filing fees required to be paid
in connection therewith so that such issuance may lawfully occur without the necessity of filing a
prospectus, registration statement or any similar document under the Securities Laws.

(d) The Company shall, to the extent and for so long as HOC Entities hold at least 14.5% of the
Shares on a non-diluted basis, upon HOC's request, permit representatives of the HOC Entities to
have access to the site and any of the premises where the business and operations of the Company and
its Subsidiaries are conducted and access and duplicating rights (and use commercially reasonable
efforts to cause persons or firms possessing such documentation or information to give similar
access and duplicating rights) to the Company and its Subsidiaries' books of account and records and
such other documents, communications, items and matters, within the knowledge, possession or control
of the Company, which HOC may reasonably request, at HOC's own cost (other than those it is
permitted to examine and make copies of free of charge pursuant to applicable Laws) provided that,
except to the extent the information can be provided in the necessary course of business of the
Company, acting reasonably including to provide HOC Entities with information to assist the HOC
Entities and their advisors with the preparation of the financial statements for such HOC Entities,
nothing herein shall require the Company to provide HOC Entities with any information which would
constitute a material fact with respect to the Company which has not been generally disclosed.

(e) In the event the Company shall breach any representation or warranty, covenant or any other
right of HOC under this Agreement in any material respect, including but not limited to, the rights
afforded to HOC under Articles 2, 4, 5, 6 and 8 hereof, then at the request of HOC, the Company
shall promptly prepare and file with the SEC a registration statement on Form S-l or S-3 (or, if
Form S-l or S-3 is not then available, on such form of registration statement as is then available
to effect a registration for resale of the Purchase Shares and the Additional Shares ("Registration
Statement")), covering the resale of all of the Shares owned by HOC; provided, however, that if
prior to the filing of the Registration Statement, the provisions of Rule 144 of the Securities Act
of 1933, as amended (the "1933 Act") allow the sale of all of the Shares in compliance with that
Rule, the Company shall not be obligated to file such Registration Statement so long as the Company
at its own expense, does the following: (i) complies with any necessary filing or reporting
requirements (under the 1933 Act or otherwise) to permit such sale, (ii) cooperates with HOC in
removing any legend on the certificates representing the Shares, including but not limited to
instructing its transfer agent to remove such restrictive legend and (iii) provides HOC with an
opinion of counsel confirming that such sale is permitted under Rule 144. Such Registration
Statement also shall cover, to the extent allowable under the 1933 Act and the rules promulgated
thereunder (including Rule 416), such indeterminate number of additional shares of Common Stock
resulting from stock splits, stock dividends or similar transactions with respect to the Shares. The
Company shall pay all expenses associated with the registration, including filing and printing fees,
counsel and accounting fees and expenses, and State "Blue Sky" fees and expenses. The Company shall
use its commercially reasonable efforts to have the Registration Statement declared effective by the
SEC as soon as practicable. The Company shall notify HOC by facsimile or e-mail as promptly as
practicable, and in any event, within three (3) business days, after the Registration Statement is
declared effective and shall simultaneously provide HOC with copies of any related prospectus to be
used in connection with the sale or other disposition of the securities covered thereby.

14
<!-- page 15 -->
(f) In connection with the foregoing, the Company shall indemnify and hold harmless HOC against any
losses, claims, damages or liabilities to which it may become subject under the 1933 Act or
otherwise, insofar as such losses, claims, damages or liabilities (or actions in respect thereof)
arise out of or are based upon (i) any untrue statement or alleged untrue statement of any material
fact contained in the Registration Statement or any other public filing by the Company, so long as
such statement has not been provided to the Company by HOC for inclusion in such registration
statement; (ii) the omission or alleged omission to state therein a material fact required to be
stated therein or necessary to make the statements therein not misleading, so long as such omission
or alleged omission does not relate to HOC or the manner of sale for the Shares as provided to the
Company by HOC; or (iii) any violation of the 1933 Act, any rule or regulation thereunder or any
other securities law, rule or regulation applicable to the Company and relating to the action or
inaction required of the Company in connection therewith. The foregoing indemnification obligation
shall extend to the fees and expenses of any counsel retained by HOC in connection with any such
loss, claim, damage or liability.

ARTICLE 10 REPRESENTATIONS & WARRANTIES

10.1 Representations and Warranties of the Company. The Company represents, warrants and agrees with
HOC as of the date of this Agreement, that:

(a) The Company is a corporation duly incorporated under the laws of the State of Colorado, and is
validly existing and in good standing under the laws of the State of Colorado and no proceedings
have been instituted or are pending for the dissolution or liquidation of the Company;

(b) The Company has all requisite legal and corporate power and authority to execute, deliver and
perform its obligations under this Agreement;

(c) This Agreement has been duly authorized by all necessary corporate action on the part of the
Company and has been duly executed and delivered by the Company and constitutes a valid and legally
binding obligation of the Company enforceable against the Company in accordance with its terms; and

15
<!-- page 16 -->
(d) The execution and delivery of this Agreement and the performance by the Company of its
obligations hereunder and the consummation of the Transactions, do not and will not conflict with,
or result in a breach or violation of, any of the terms or provisions of, or constitute a default
under (whether after notice or lapse of time or both): (i) the constating documents of the Company;
(ii) the resolutions of the shareholders or directors (or any committee thereof) of the Company
which are in effect at the date hereof; (iii) any mortgage, note, indenture, contract, agreement,
instrument, lease or other document to which the Company is a party or by which it is bound; or (iv)
any judgement, writ, injunction, decree or order, of any court or of any Authority that is binding
the Company or the property or assets of the Company.

10.2 Representations and Warranties of HOC. HOC represents, warrants and agrees with the Company as
of the date of this Agreement, that:

(a) HOC is a limited company incorporated under the Companies Act 1985 (England) as a limited
company, registered in England and Wales, and is validly existing and in good standing under the
laws of England and no proceedings have been instituted or are pending for the dissolution or
liquidation of HOC;

(b) HOC has all requisite legal and corporate power and authority to execute, deliver and perform
its obligations under this Agreement;

(c) this Agreement has been duly authorized by all necessary corporate action on the part of HOC and
has been duly executed and delivered by HOC and constitutes a valid and legally binding obligation
of HOC enforceable against HOC in accordance with its terms; and

(d) the execution and delivery of this Agreement and the performance by HOC of its obligations
hereunder and the consummation of the Transactions, do not and will not conflict with, or result in
a breach or violation of, any of the terms or provisions of, or constitute a default under (whether
after notice or lapse of time or both): (i) the constating documents of HOC; (ii) the resolutions of
the shareholders or directors (or any committee thereof) of HOC which are in effect at the date
hereof; (iii) any mortgage, note, indenture, contract, agreement, instrument, lease or other
document to which HOC is a party or by which it is bound; or (iv) any judgement, writ, injunction,
decree or order, of any court or of any Authority that is binding on HOC or the property or assets
of HOC.

ARTICLE 11 INDEMNIFICATION

11.1 Indemnification by the Company.

The Company will indemnify and save harmless the HOC Entities and the directors, officers, employees
and agents of the HOC Entities (collectively, the "HOC Indemnitees") from and against all Claims
incurred by any one or more of the HOC Indemnitees directly or indirectly resulting from any breach
of any covenant, representation or warranty of the Company contained in this Agreement.

16
<!-- page 17 -->
11.2 Indemnification by HOC.

HOC will indemnify and save harmless the Company and the directors, officers, employees and agents
of the Company (collectively, the "Company Indemnitees") from and against all Claims incurred by any
one or more of the Company Indemnitees directly or indirectly resulting from any breach of any
covenant, representation or warranty of HOC contained in this Agreement.

11.3 Injunctive Relief.

Notwithstanding any other provision of this Agreement, nothing herein is intended to or shall
restrict a Party from seeking and receiving injunctive relief (whether as a temporary restraining
order, preliminary injunction or otherwise) or specific performance.

ARTICLE 12 MISCELLANEOUS PROVISIONS

12.1 Notices. All notices or other communications required or permitted to be given by one party to
another by the terms hereof shall be given in writing by personal delivery or facsimile delivered to
such other party as follows:

To the Company:

Gold Resource Corporation 222 Milwaukee St., Suite 301 Denver, CO 80206 Attention: William Reid,
President Facsimile No.: (303) 320-7835

To HOC:

Hochschild Mining Holdings Limited Calle La Colonia 180 Surco, Lima 33, Peru Attention: VP & General
Counsel Facsimile No.: +511-437-5009

or at such other address or facsimile number as may be given by either of them to the other in
writing from time to time and such other notices or communications shall be deemed to have been
received when delivered or, if by facsimile, on the next business day after such notice or other
communication has been transmitted by facsimile (with receipt confirmed).

17
<!-- page 18 -->
12.2 Further Assurances. Each of the parties hereto upon the request of each of the other parties
hereto, whether before or after the date of this Agreement, shall do, execute, acknowledge and
deliver or cause to be done, executed, acknowledged and delivered all such further acts, deeds,
documents, assignments, transfers, conveyances, powers of attorney and assurances as may reasonably
be necessary or desirable to complete the transactions contemplated herein.

12.3 Costs and Expenses. All costs and expenses (including, without limitation, the fees and
disbursements of legal counsel) incurred in connection with this Agreement and the transactions
herein contemplated shall be paid and borne by the party incurring such costs and expenses.

12.4 Applicable Law. This Agreement shall be construed and enforced in accordance with, and the
rights of the parties shall be governed by, the laws of the State of New York and the laws of the
United States applicable therein. Any and all disputes arising under this Agreement, whether as to
interpretation, performance or otherwise, shall be subject to the non-exclusive jurisdiction of the
courts of Colorado and each of the parties hereto hereby irrevocably attorns to the jurisdiction of
the courts of such province.

12.5 Entire Agreement. This Agreement constitutes the entire agreement between the parties with
respect to the transactions contemplated herein and cancels and supersedes any prior understandings,
agreements, negotiations and discussions between the parties. There are no representations,
warranties, terms, conditions, undertakings or collateral agreements or understandings, express or
implied, between the parties hereto other than those expressly set forth in this Agreement or in any
such agreement, certificate, affidavit, statutory declaration or other document as aforesaid.

12.6 Amendment and Waivers. No amendment of this Agreement will be effective unless made in writing
and signed by the Parties. A waiver of any default, breach or non-compliance under this Agreement is
not effective unless in writing and signed by the Party to be bound by the waiver. No waiver shall
be inferred from or implied by any failure to act or delay in acting by a Party in respect of any
default, breach or non-observance or by anything done or omitted to be done by the other Party in
respect of any default, beach or non-observance or by anything done or omitted to be done by the
other Party. The waiver by any Party of any default, breach or non-compliance under this Agreement
shall not operate as a waiver of that Party's rights under this Agreement in respect of any
continuing or subsequent default, breach or non-observance (whether of the same or any other
nature).

12.7 Severability. If any one or more provisions in this Agreement, for any reason, shall be
determined to be invalid, illegal or unenforceable in any respect, the validity, legality and
enforceability of any such provision in any other respect and the remaining provisions of this
Agreement shall not be in anyway impaired.

12.8 Counterparts. This Agreement may be executed in two or more counterparts, each of which shall
be deemed to be an original and all of which together shall constitute one and the same Agreement.
Counterparts may be delivered either in original or faxed form and the parties adopt any signature
received by a receiving fax machine as original signatures of the parties.

12.9 Assignment. This Agreement may not be assigned by either party except with the prior written
consent of the other parties hereto.

18
<!-- page 19 -->
12.10 Enurement. This Agreement shall enure to the benefit of and be binding upon the parties hereto
and their respective heirs, executors, successors (including any successor by reason of the
amalgamation or merger of any party), administrators and permitted assigns.

IN WITNESS WHEREOF the parties hereto have executed this Agreement as of the day and year first
above written.

GOLD RESOURCE CORPORATIOn

By: ___________________________________________ Authorized Signing Officer

HOCHSCHILD MINING HOLDINGS LIMITED

By: ___________________________________________ Authorized Signing Officer

19
