<!-- page 1 -->
# COLLABORATION AGREEMENT
| Field | Value |
|---|---|
| Document Type | Collaboration Agreement |
| Agreement Date | 2007-04-01 |
| Parties | INSTITUTE OF GRASSLAND AND ENVIRONMENTAL RESEARCH ("IGER"); CERES, INC. ("CERES") |
| Source | CUAD v1 / CERES,INC_01_25_2012-EX-10.20-Collaboration Agreement |

Exhibit 10.20

Pages where confidential treatment has been requested are stamped 'Confidential Treatment Requested
and the Redacted Material has been separately filed with the Commission,' and the confidential
section has been marked as follows: [***].

Collaboration Agreement

between

Institute of Grassland and Environmental Research

and

Ceres, Inc. CERES-IGER Collaboration Agreement Page 1 of 75
<!-- page 2 -->
TABLE OF CONTENTS 1. RESEARCH PROJECTS 3 2. MANAGEMENT COMMITTEE 7 3. EXCLUSIVITY 8 4. INTELLECTUAL
PROPERTY 11 5. USE AND COMMERCIALIZATION RIGHTS 14 6. ENFORCEMENT OF JOINT INTELLECTUAL PROPERTY
RIGHTS 16 7. CONFIDENTIALITY 16 8. PUBLICATIONS 18 9. PUBLICITY 18 10. RECORDS AND AUDITS 19 11.
INDEPENDENT CONTRACTOR 19 12. CONVENTION ON BIOLOGICAL DIVERSITY 19 13. WARRANTIES 20 14. TERM AND
TERMINATION 23 15. DISPUTE RESOLUTION AND APPLICABLE LAW 25 16. NOTICES 26 17. GENERAL 27 18.
SPECIAL CONDITIONS IN CONNECTION WITH DEFRA AGREEMENT NF 0426 28 EXHIBIT A 30 DEFINITION OF
COLLABORATION CROPS 30 EXHIBIT B 31 PREFERRED FORM OF RECEIPT FORM 31 EXHIBIT C 32 PREFERRED FORMS
OF VARIETY EVALUATION AGREEMENT 32 EXHIBIT D 50 EXTERNAL FUNDING EXHIBIT E 50 51

EXISTING AGREEMENTS 51 EXHIBIT F 56 PRODUCTION AND COMMERCIALIZATION ACTIVITIES 56 EXHIBIT G 57
MODEL LICENSE AGREEMENT FOR NON-TRANSGENIC VARIETIES / NON-UK 57 EXHIBIT H 74 CERTAIN REMUNERATION
PRINCIPLES 74 CERES-IGER Collaboration Agreement Page 2 of 75

COLLABORATION AGREEMENT
<!-- page 3 -->
THIS AGREEMENT is made this 1st day of April, 2007 ("Effective Date"), by and between INSTITUTE OF
GRASSLAND AND ENVIRONMENTAL RESEARCH ("IGER"), a company limited by guarantee, registered in England
No. 473456 and a registered Charity No. 272150, having an office at Plas Gogerddan, Aberystwyth,
Ceredigion, SY23 3EB, United Kingdom and CERES, INC. ("CERES"), a Delaware corporation, having an
office at 1535 Rancho Conejo Blvd., Thousand Oaks, California 91320, United States of America.

WHEREAS, the Parties wish to establish a research program for undertaking specific, collaborative
projects after the Effective Date, to further the scientific research and commercial objectives of
CERES as well as the scientific research objectives of IGER;

WHEREAS, the research programs contemplated by this Agreement and its schedules are consistent with
and in furtherance of IGER research programs;

WHEREAS, CERES and IGER recognize that rights to intellectual property conceived or reduced to
practice in the performance of the Parties' collaboration can be a strong incentive for CERES to
risk money and other resources needed to develop proprietary products for wide commercialization;

NOW THEREFORE, in consideration of the premises and of the mutual covenants and agreements contained
herein and of other good and valuable consideration, the Parties have agreed and do hereby agree as
follows:

1.1 CERES and IGER anticipate that from time to time they may undertake and conduct certain joint
and collaborative research projects (individually a "RESEARCH PROJECT" and collectively "RESEARCH
PROJECTS"). The Parties acknowledge and agree that the RESEARCH PROJECTS will involve the
contributions, whether financial or otherwise, of both Parties. The specific terms and respective
obligations of the Parties for each RESEARCH PROJECT will be negotiated by the Parties and reflected
in a schedule ("SCHEDULE") signed by authorized representatives of both Parties. Any such fully
executed SCHEDULE shall become a part of this Agreement and subject to the terms of this Agreement.
Each Party shall diligently perform its activities in any given RESEARCH PROJECT.

1.2 All rights in property, tangible or intangible, used in the RESEARCH PROJECTS shall remain with
the Party providing such property, unless otherwise agreed between the Parties in this Agreement, a
SCHEDULE or a separate agreement.

1.3 RESEARCH PROJECTS will relate to crop species defined in EXHIBIT A to this Agreement
("COLLABORATION CROPS").

1.4 Each SCHEDULE will at least contain the following:

1. RESEARCH PROJECTS.

• research activities to be performed by each Party in detail CERES-IGER Collaboration Agreement
Page 3 of 75
<!-- page 4 -->
1.5 Unless a SCHEDULE provides for more frequent formal reporting, each Party shall provide to the
other Party a detailed, written annual report on its activities in each RESEARCH PROJECT, as
described in each SCHEDULE. In addition, upon the request of either Party at any time, the Parties
will discuss the RESEARCH PROJECTS, their status, the progress and results achieved, and they will
make available each RESEARCH PROJECT principal investigator (and other employees as needed, in the
discretion of the respective RESEARCH PROJECT principal investigators) at mutually agreeable times,
as needed, for such discussions; provided however, such contacts and discussions shall be reasonable
in frequency and duration so as not to be disruptive to the respective research activities of each
Party or the research activities of the RESEARCH PROJECTS. Each Party will also voluntarily provide
data, information and material generated in the RESEARCH PROJECT to the other Party as required to
further the Parties' mutual goals defined in each RESEARCH PROJECT or in any other agreement between
the Parties. Each Party will have the right, upon reasonable notice to the other Party, to visit any
location where RESEARCH PROJECT activities are conducted for the purposes of evaluating RESEARCH
PROJECT progress and outcomes, and particularly to make observations of any plants in growth
chambers, greenhouses or fields that are a part of a RESEARCH

• timelines of such activities

• goals, expected results and deliverables

• milestones and "go" and "no-go" decision points

• all reports to be delivered to the MANAGEMENT COMMITTEE (Article 2) and the required delivery
dates for the same

• additional information on RESEARCH PROJECT activities: breeding records and biological or other
material generated in such activities to be provided to the other Party, including delivery method
and time

• location of activities

• identity of RESEARCH PROJECT principal investigators for CERES and IGER

• identity and location of any SUBCONTRACTORS (Article 1.13) to be used for the RESEARCH PROJECT
activities

• number of FTE's made available by each Party for the RESEARCH PROJECT, including names of any IGER
PhD-level employees

• other inputs and resources made available by each Party for the RESEARCH PROJECT

• financial contributions of each Party to the RESEARCH PROJECT

• provisions on intellectual property, including lists of BACKGROUND INTELLECTUAL PROPERTY and any
provisions which are different from those set forth in this Agreement

• provisions on use and commercialization rights which are different from those set forth in this
Agreement

• provisions on expiration and early termination

CERES-IGER Collaboration Agreement Page 4 of 75
<!-- page 5 -->
PROJECT. Each Party will comply with any reasonable safety and security measures which may be
imposed by the other Party when visiting such other Party's location.

1.6 Any transfer of information or material pursuant to this Agreement or any SCHEDULE will be
governed by the provisions of this Agreement on CONFIDENTIALITY (Article 7) and PUBLICATIONS
(Article 8). Any transfer of material shall be accompanied by a receipt form in the preferred format
attached as EXHIBIT B to this Agreement. Such receipt forms shall be signed by representatives of
both the sending and receiving Parties.

1.7 Unless otherwise specified in a SCHEDULE, each Party shall bear its own costs and pay its own
SUBCONTRACTORS, with respect to its RESEARCH PROJECT activities.

1.8 Where a SCHEDULE provides that CERES will make a financial contribution to certain RESEARCH
PROJECT activities performed by IGER, unless agreed otherwise in the appropriate SCHEDULE, IGER will
submit invoices after the end of each calendar quarter for the work performed during that quarter.
Each such invoice shall reflect only those costs that have been incurred in performance of the
RESEARCH PROJECT and shall provide a breakdown of costs similar to the detail set forth in the
budget of the related SCHEDULE. CERES will pay all such invoices within thirty (30) days after the
invoice date. Payments shall be remitted to:

Institute Secretary Institute of Grassland and Environmental Research Plas Gogerddan Aberystwyth
Ceredigion SY23 3EB United Kingdom

1.9 Each Party will conduct RESEARCH PROJECT activities exclusively in laboratories, greenhouses or
fields under full control of that Party or of its SUBCONTRACTORS authorized by this Agreement. Each
Party will take all reasonable precautions to prevent damage to, or unintentional destruction of or
release of any germplasm created in the RESEARCH ACTIVITIES.

1.10 Each Party shall be responsible for its compliance with all applicable laws, rules and
regulations, including, without limitation, those relating to genetically modified organisms (to the
extent RESEARCH PROJECTS involve such organisms). Each Party shall obtain any and all permits or
authorizations or proceed to any notifications which may be required by such laws, rules and
regulations.

1.11 Each Party will require any and all of its employees or students who will perform activities in
RESEARCH PROJECTS to be bound by a written agreement(s) that commits their inventions, discoveries
and other intellectual property to the Party-employer and requires confidential treatment of Party
and third-party confidential information.

1.12 The RESEARCH PROJECT principal investigators named in each SCHEDULE shall be charged with
leading the RESEARCH PROJECT described therein. CERES-IGER Collaboration Agreement Page 5 of 75
<!-- page 6 -->
1.12.1 RESEARCH PROJECT principal investigators may not vary the SCHEDULE of delivery, amount,
method of payment or any provision of a SCHEDULE. No such change shall be effective unless and until
it is reduced to writing in the form of an amendment to such SCHEDULE in accordance with Article
17.1.

1.12.2 Substitution by IGER of a RESEARCH PROJECT (a) principal investigator or (b) a CERES-funded,
PhD-level, IGER employee named or filling a defined position listed in a SCHEDULE shall be subject
to CERES' prior written approval, which will not unreasonably be withheld or delayed. IGER will
notify CERES, in writing, of any substitution by IGER of a non-CERES-funded, PhD-level employee
named or who filled a defined position listed in a SCHEDULE. CERES will notify IGER, in writing, of
any substitution by CERES of a RESEARCH PROJECT principal investigator or a PhD-level CERES employee
named or who filled a defined position listed in a SCHEDULE.

1.13 Each Party may subcontract certain parts of its RESEARCH PROJECT activities to third parties,
or use third party consultants in connection with RESEARCH PROJECT activities, but only if the
subcontract or consultancy agreement is in writing and complies with the terms and conditions set
forth hereinafter. Such third parties with whom such a subcontract or consultancy agreement is
executed will be referred to as "SUBCONTRACTORS".

1.13.1 Any intended agreement with a SUBCONTRACTOR shall be identified in a SCHEDULE if known at the
time the SCHEDULE is executed by the Parties. IGER will obtain CERES' prior written consent before
entering into any agreement with a SUBCONTRACTOR which is not listed in a SCHEDULE.

1.13.2 The following terms and conditions shall apply to IGER's SUBCONTRACTORS: (a) the
SUBCONTRACTOR shall perform defined activities on behalf and for the benefit of IGER in exchange for
a fee or other tangible consideration; (b) the SUBCONTRACTOR shall deliver all the results of the
SUBCONTRACTOR'S activities under the subcontract to IGER only, and assign ownership of or
exclusively license any inventions made during the performance of the subcontracting activities to
IGER, without any further remuneration and (c) the SUBCONTRACTOR shall not have the right to use any
results, whether information or material, for any purpose whatsoever other than the performance of
the subcontract; provided however, not-for-profit research institution SUBCONTRACTORS may be granted
the right to use certain information generated pursuant to the subcontract for their internal
academic research and educational purposes (i.e., not in collaboration with or for the benefit of
any third party). IGER will provide to CERES a draft copy of any subcontract IGER is planning to
conclude at least fifteen (15) days before the scheduled signature date and will provide a true copy
of any subcontract to CERES within thirty (30) days of its execution.

1.13.3 It is anticipated that any agreements with commercial SUBCONTRACTORS will be entered into by
CERES. At CERES' request, IGER will assist CERES in identifying SUBCONTRACTORS for any field
activities. The following conditions shall apply to CERES SUBCONTRACTORS: CERES will inform IGER, in
writing, of any SUBCONTRACTORS used by CERES for the performance of RESEARCH PROJECT activities.
CERES-IGER Collaboration Agreement Page 6 of 75
<!-- page 7 -->
1.13.4 All SUBCONTRACTORS shall be bound by confidentiality obligations consistent with the terms
and obligations of this Agreement. All SUBCONTRACTORS shall be responsible for their respective
compliance with all laws, rules and regulations that govern their activities.

1.13.5 For variety evaluation and performance testing using not-for-profit research institution
SUBCONTRACTORS, the Parties agree that each transfer of plant material shall be governed by a
written agreement consistent with the preferred forms set forth in EXHIBIT C to this Agreement.

1.14 The Parties mutually agree that any applications for extramural funding for a RESEARCH PROJECT,
from governmental authorities or other public sources, will be subject to the prior, written
agreement, neither unreasonably withheld or delayed, by both Parties; provided however, the Parties
acknowledge that CERES and/or IGER has or has applied for certain government, extramural funding
prior to the Effective Date (EXHIBIT D to this Agreement), and such funding (or possible funding, if
awarded) shall not be construed as a breach of the obligations of this Article.

1.15 IGER agrees not to accept research funding from for-profit entities to perform any RESEARCH
PROJECT, whether in whole or in part, initiated under this Agreement without the prior written
consent of CERES.

1.16 The Parties acknowledge and agree that certain RESEARCH PROJECT activities may be covered by
government funding set forth in EXHIBIT D and corresponding agreements set forth in EXHIBIT E, as
indicated in the relevant SCHEDULE(S). In particular, the Parties acknowledge and agree that IGER
will comply with its obligations under the DEFRA project NF 0426 "The generic improvement of
miscanthus for biomass" ("DEFRA agreement NF 0426"), including without limitation its obligation to
meet the objectives set forth in such project and to report to DEFRA on its results relating to such
activities. The Parties further agree that such compliance will not affect any provisions of this
Agreement nor of any SCHEDULE, except if explicitly provided otherwise, including without limitation
the provisions on INTELLECTUAL PROPERTY in Article 4 and on USE AND COMMERCIALIZATION RIGHTS in
Article 5.

2.1 The Parties will establish a MANAGEMENT COMMITTEE to supervise the implementation, execution and
progress of this Agreement and its RESEARCH PROJECTS. The MANAGEMENT COMMITTEE will consist of four
(4) members, two (2) to be appointed by each Party and will meet at least once every calendar
quarter, in person or by telephone, on dates and at locations to be mutually agreed. The
representatives of each Party may invite other employees of that Party to meeting on an as-needed
basis, subject to prior notification of the other Party.

2.2 Decisions of the MANAGEMENT COMMITTEE shall be made by unanimous agreement and recorded in a
manner prescribed by the MANAGEMENT COMMITTEE as a true record of the decisions. If the MANAGEMENT
COMMITTEE cannot come to a unanimous agreement on any matter then the status quo shall apply.

2.3 The responsibilities of the MANAGEMENT COMMITTEE shall be as follows:

2. MANAGEMENT COMMITTEE.

CERES-IGER Collaboration Agreement Page 7 of 75
<!-- page 8 -->
3.1 In consideration of CERES' development of new markets for the COLLABORATION CROPS and the
significant activities associated with the development of this market, IGER agrees to grant CERES
exclusive access to IGER's plant improvement activities specifically involving the COLLABORATION
CROPS, whether through plant breeding, transformation, propagation methods or otherwise, subject
however to the exceptions expressly set forth in this Agreement.

3.2 During the term of this Agreement, subject to the provisions of this Agreement on subcontracting
(Article 1.13 and its related subsections) and subject to the agreements entered into by IGER prior
to the Effective Date and defined in EXHIBIT E to this Agreement, as such agreements exist on the
Effective Date ("EXISTING AGREEMENTS"), IGER agrees to comply with the obligations set forth
hereinafter:

3.2.1 for-profit third parties.

IGER will not collaborate with or perform any activities for the benefit of or grant any rights to
any for-profit third party in the field of the COLLABORATION CROPS without the prior written consent
of CERES.

- supervise and review the implementation of the RESEARCH PROJECTS;

- approve principal investigators and project teams for RESEARCH PROJECTS;

- determine the resources necessary to achieve the goals of each RESEARCH PROJECT, within the limits
of the RESEARCH PROJECT budget provided in the relevant SCHEDULE;

- adjust the research activities defined in a RESEARCH PROJECT, subject to the overall budget for
that RESEARCH PROJECT in a given year;

- review achievement of goals and timelines; propose adjustments of goals or timelines to the
Parties;

- review achievement of agreed annual milestones for overhead payment purposes and make
recommendations relating to milestones to the Parties;

- review proposed publications and formulate recommendations to the Parties on publications;

- review intellectual property matters relating to the implementation of this Agreement and
formulate recommendations to the Parties regarding such matters;

- review subcontracting matters and formulate recommendations to the Parties regarding such matters;

- review reports to be provided pursuant to SCHEDULES;

- such other responsibilities as the Parties jointly may explicitly grant to the MANAGEMENT
COMMITTEE.

3. EXCLUSIVITY.

CERES-IGER Collaboration Agreement Page 8 of 75
<!-- page 9 -->
a. CERES will not unreasonably withhold its consent for collaborations with small companies (less
than fifty (50) employees including world-wide affiliates) established in the United Kingdom ("UK
COMPANIES"), with respect to research programs involving COLLABORATION CROPS in the field of
environmental impact, carbon sequestration, climate change mitigation, agronomy, or compositional or
conversion analysis, provided that (i) IGER will receive the exclusive right (subject to Articles
5.1.2(a) and 5.2) to use and exploit commercially the results of such research programs for
GERMPLASM IMPROVEMENT (as defined hereinafter) of the COLLABORATION CROPS, (ii) CERES will have
access to the results of such research programs to the extent allowed by the relevant agreement
between IGER and the third party and IGER will use reasonable efforts to obtain such right for
CERES, and (iii) there is no conflict with CERES' commercial interests.

b. CERES recognizes that IGER may receive requests from third parties to make available germplasm of
CERTAIN MISCANTHUS ACCESSIONS. IGER will have the right to make available germplasm of CERTAIN
MISCANTHUS ACCESSIONS to third parties for research purposes (including breeding), subject to the
terms and conditions under which IGER holds such accessions. "CERTAIN MISCANTHUS ACCESSIONS" shall
mean the Miscanthus accessions collected by IGER in 2006 from China, Taiwan and Japan, as originally
collected by IGER.

3.2.2 not-for-profit third parties.

a. "GERMPLASM IMPROVEMENT" shall mean any activities to improve a crop, including without limitation
selection, breeding, transgenic improvement, markers, propagation systems:

IGER will not collaborate with or perform any activities for the benefit of or grant any rights to
any not-for-profit third party with respect to GERMPLASM IMPROVEMENT of COLLABORATION CROPS without
the prior written consent of CERES. CERES will not unreasonably withhold its consent for research
programs with respect to GERMPLASM IMPROVEMENT of COLLABORATION CROPS with academic institutions in
the European Union under United Kingdom government or European Union funding, provided that (i) IGER
will have the exclusive right to use and exploit commercially the results of such research programs
obtained by IGER, (ii) no COLLABORATION CROP germplasm will be made available by IGER to any third
party for selection, breeding or propagation work, or for genetic transformation of such germplasm,
except that IGER may make available germplasm of CERTAIN MISCANTHUS ACCESSIONS for research purposes
(including breeding), subject to the terms and conditions under which IGER holds such accessions,
and (iii) if requested by CERES, IGER will use reasonable efforts to obtain commercialization rights
for CERES on results CERES-IGER Collaboration Agreement Page 9 of 75
<!-- page 10 -->
obtained by third parties in such collaborative research programs or breeding activities.

b. environmental impact, carbon sequestration, climate change or agronomy studies, and compositional
or conversion analysis:

if IGER would enter into any agreement (or amendment of an existing agreement including without
limitation EXISTING AGREEMENTS) after the Effective Date with a not-for-profit third party with
respect to research in the field of environmental impact, carbon sequestration, climate change
mitigation, agronomy, or compositional or conversion analysis relating to COLLABORATION CROPS, such
agreement must provide that (i) IGER will receive the exclusive right (subject to Articles 5.1.2(a)
and 5.2) to use and exploit commercially the results obtained pursuant to such agreement for
GERMPLASM IMPROVEMENT of COLLABORATION CROPS and (ii) CERES will have access to the results of such
research programs to the extent allowed by the relevant agreement between IGER and the third party
and IGER will use reasonable efforts to obtain such right for CERES.

3.2.3 IGER will provide a draft of any agreement intended to cover an activity referred to in
Article 3.2.1 a. or b. or 3.2.2 a. or b. to CERES, together with its written request for consent
where such consent needs to be obtained. CERES will respond in writing within thirty (30) days or
such other period of time as the Parties may agree in writing. In exceptional urgent cases, when
asked by IGER, CERES will respond as soon as reasonably possible. Further, where Articles 3.2.1 or
3.2.2 refer to Ceres' access to results or right to use and commercially exploit such results, IGER
will report such results to CERES in compliance with the terms hereof.

3.2.4 Whenever rights are granted to IGER pursuant to agreements referred to in Articles 3.2.1 or
3.2.2 ("Third Party Agreement Rights"), the provisions of this Agreement about the grant of rights
by IGER to CERES will apply and such Third Party Agreement Rights shall be treated as IGER
INTELLECTUAL PROPERTY (unless they qualify as JOINT INTELLECTUAL PROPERTY under the circumstances).

3.3 During the term of this Agreement, IGER will notify CERES, in writing, of any contemplated
internal (i.e. not involving third parties but including government-funded) research activities
(i.e., non-RESEARCH PROJECTS) that specifically involve the COLLABORATION CROPS, except research
activities that relate solely to environmental impact, carbon sequestration, climate change or
agronomy studies. If CERES so requests, the Parties will negotiate in good faith to agree on a new
RESEARCH PROJECT and accompanying SCHEDULE or an amendment to an existing SCHEDULE on the basis of
such research proposal. If CERES does not request such negotiations, or if the Parties fail to reach
agreement on a new SCHEDULE (or amendment to an existing SCHEDULE) within thirty (30) days (or such
other time period as the Parties may agree) from IGER's notice, IGER will have the right, subject to
Articles 3.2 and 5.3, to proceed to such internal research, and IGER will provide a written report
to CERES on the results of such research. CERES is hereby granted a first option, to be exercised by
written notice within thirty (30) days from CERES-IGER Collaboration Agreement Page 10 of 75
<!-- page 11 -->
IGER's aforementioned written report or such other time period as the Parties may agree to be
granted the same right as set forth in Article 5.3 to commercialize any results of such activities.

3.3.1 If CERES exercises its option to commercialize under Article 3.3, CERES and IGER shall
negotiate the terms of a commercialization agreement that covers the reported result with reference
to any commercialization agreement then in existence between the Parties or the model license
agreement or remuneration principles included herein (as applicable). If, despite the Parties' good
faith efforts, CERES and IGER are unable to agree upon the terms and conditions of such agreement
within one hundred and eighty (180) days after commencing good faith negotiations, CERES shall have
the right to start the dispute resolution procedure in Article 15 for any outstanding unresolved
issues.

3.3.2 If CERES declines to exercise the option under Article 3.3 or fails to respond within thirty
(30) days of IGER's notice under Article 3.3, then IGER shall then be free to commercially exploit
the results or offer rights in such results to third parties in any and all crops.

3.3.3 IGER will have no restrictions to undertake internal (i.e. not involving third parties but
including government-funded) research activities that involve COLLABORATION CROPS but relate solely
to environmental impact, carbon sequestration, climate change or agronomy studies. IGER will use all
reasonable efforts to inform CERES of the results of any such activities.

4.1 "JOINT INTELLECTUAL PROPERTY" shall mean (a) all patentable inventions conceived, discovered,
developed and/or reduced to practice (i) jointly by one or more employees, agents, or students of
CERES and by one or more employees, agents, or students of IGER in the performance of any RESEARCH
PROJECT(S) or (ii) by one or more employees, agents or students of IGER in the performance of any
RESEARCH PROJECT(S) to the extent CERES provides a financial contribution for such RESEARCH PROJECT,
which is not less than twenty-five percent (25%) of either the overall cost of such RESEARCH PROJECT
or of the activity during which the invention was made, unless expressly provided otherwise in a
SCHEDULE; (b) patents, patent applications, plant variety rights, plant variety right applications,
reissues, continuations, continuations-in-part and divisionals claiming such patentable inventions
in any country of the world; (c) all trade secrets and copyrighted works created jointly by one or
more employees, agents, or students of CERES and by one or more employees, agents, or students of
IGER in the performance of any RESEARCH PROJECT(S); and (d) all germplasm and plant varieties
created in the performance of plant breeding activities in the performance of any RESEARCH
PROJECT(S).

4.2 "CERES INTELLECTUAL PROPERTY" shall mean (a) all patentable inventions conceived, discovered,
developed, and/or reduced to practice by one or more employees, agents, or students of CERES in the
performance of any RESEARCH PROJECT(S), except as set forth in Article 4.1; (b) patents, patent
applications, plant variety rights, plant variety right applications, reissues, continuations,
continuations-in-part, and divisionals claiming such patentable inventions in any country of the
world; and (c) all trade secrets and copyrighted works created by one or more employees, agents, or
students of CERES in the performance of any RESEARCH PROJECT(S) .

4. INTELLECTUAL PROPERTY.

CERES-IGER Collaboration Agreement Page 11 of 75
<!-- page 12 -->
4.3 "IGER INTELLECTUAL PROPERTY" shall mean (a) all patentable inventions conceived, discovered,
developed, and/or reduced to practice by one or more employees, agents, or students of IGER in the
performance of RESEARCH PROJECT(S), except as set forth in Article 4.1; (b) patents, patent
applications, plant variety rights, plant variety right applications, reissues, continuations,
continuations-in-part, and divisionals claiming such patentable inventions in any country of the
world; and (c) all trade secrets and copyrighted works created by one or more employees, agents, or
students of IGER in the performance of RESEARCH PROJECT(S).

4.4 "OTHER RESEARCH RESULTS" shall mean all data, information, procedures, techniques and know-how
generated in the performance of RESEARCH PROJECT(S), but expressly excludes JOINT INTELLECTUAL
PROPERTY, CERES INTELLECTUAL PROPERTY, and IGER INTELLECTUAL PROPERTY.

4.5 "BACKGROUND INTELLECTUAL PROPERTY" shall mean (i) inventions, discoveries, materials, data and
information, whether patentable or not; including related know-how; (ii) patents, patent
applications, plant variety rights, plant variety right applications, reissues, continuations,
continuations-in-part and divisionals in any country of the world; and (iii) trade secrets or
copyrighted works, which are individually or collectively created, developed, made, acquired or
licensed in by CERES or IGER independent of the activities performed pursuant to this Agreement,
including its SCHEDULES.

4.5.1 Any Party asserting that certain intellectual property is BACKGROUND INTELLECTUAL PROPERTY
shall have the burden of substantiating such claim, if necessary, with tangible evidence, including
but not limited to paper or electronic records.

4.5.2 The Parties acknowledge and agree that all relevant BACKGROUND INTELLECTUAL PROPERTY for a
RESEARCH PROJECT should be set forth within the corresponding SCHEDULE. With respect to each element
of BACKGROUND INTELLECTUAL PROPERTY listed in a SCHEDULE, the listing Party shall include the
following: ownership or licensed rights (exclusive or non-exclusive) held by the listing Party (if
no ownership) with respect to the COLLABORATION CROPS. Notwithstanding, subject to Article 4.5.1,
failure to specifically set forth such BACKGROUND INTELLECTUAL PROPERTY in a SCHEDULE will not
foreclose a later claim that certain intellectual property is BACKGROUND INTELLECTUAL PROPERTY.

4.6 CERES and IGER shall have an undivided interest in JOINT INTELLECTUAL PROPERTY. Consequently,
any and all patent applications or plant variety rights applications that cover JOINT INTELLECTUAL
PROPERTY shall be assigned jointly to CERES and IGER as soon as practicable.

4.6.1 All rights and title to CERES INTELLECTUAL PROPERTY and CERES BACKGROUND INTELLECTUAL PROPERTY
shall belong to CERES, and IGER shall not acquire any interest in the same by its performance under
this Agreement.

4.6.2 All rights and title to IGER INTELLECTUAL PROPERTY and IGER BACKGROUND INTELLECTUAL PROPERTY
shall belong to IGER, and CERES shall not CERES-IGER Collaboration Agreement Page 12 of 75
<!-- page 13 -->
acquire any interest in the same by its performance under this Agreement, except as expressly
provided in this Agreement.

4.7 Each Party will notify the other Party, in writing ("INVENTION NOTICE"), within thirty (30) days
of reduction to practice or knowledge of conception or discovery of JOINT INTELLECTUAL PROPERTY, and
each INVENTION NOTICE will describe the JOINT INTELLECTUAL PROPERTY with sufficient specificity to
allow assessment by the other Party.

4.8 The Parties shall consult as soon as possible but in any case within twenty (20) days of
receiving an INVENTION NOTICE whether to proceed to obtain intellectual property protection on the
disclosed JOINT INTELLECTUAL PROPERTY or whether to protect the same through other methods. CERES
shall have the first option to pursue such protection in its best judgment in the joint names of
both Parties. If CERES so elects by written notice within sixty (60) days of such initial
consultation, CERES shall be the "ADMINISTERING PARTY" for the purposes of this Agreement.

4.8.1 The ADMINISTERING PARTY shall be responsible for retaining counsel, overseeing the process of
securing intellectual property protection (i.e., the preparation, filing and prosecution of patent
or plant variety rights application(s)) and maintaining intellectual property protection for the
mutual benefit of the Parties, in its best judgment, for that which it has prosecution
responsibility. In addition to other reporting responsibilities provided below, the ADMINISTERING
PARTY shall promptly notify the other Party following retention of counsel. The Parties will
provide, and cause their respective employees, agents and students to provide, all reasonable
assistance which may be required in connection with the filing and prosecution of such intellectual
property rights, including without limitation the signing of documents.

4.8.2 The ADMINISTERING PARTY shall keep the non-administering Party advised as to all developments
with respect to all patent and plant variety rights application(s) and issued patents and plant
variety rights covering jointly owned JOINT INTELLECTUAL PROPERTY, which includes supplying copies
of all papers received and filed in connection with such applications and patents in sufficient time
for the non- administering Party to comment thereon.

4.9 CERES agrees to bear all legal expenses incurred by CERES as an ADMINISTERING PARTY in obtaining
and maintaining patents and plant variety rights, U.S. and other, covering JOINT INTELLECTUAL
PROPERTY.

4.10 If CERES does not elect to file an application for a patent or plant variety rights or continue
maintenance of a patent or plant variety rights in a particular country, consistent with the
consultation of Article 4.8, IGER may file such application, continue such prosecution, or maintain
such patent or plant variety rights at its own expense; provided however, that prior to filing any
such application IGER will not take any action or proceed to any filing which would lead to the
possible disclosure of information which CERES wishes to keep confidential, as notified by CERES to
IGER in writing. For any such application, patent or plant variety rights, IGER shall serve as the
ADMINISTERING PARTY. CERES shall have non- exclusive rights under the specific patent
application(s), plant variety right application(s), patent(s) and/or plant variety right(s) in the
country(ies) in which CERES declined to initiate or continue its participation, subject to paying
IGER CERES-IGER Collaboration Agreement Page 13 of 75
<!-- page 14 -->
reasonable remuneration (whether as a royalty or in some other form as the Parties may agree) to be
negotiated in good faith, and in any case CERES shall remain free to use and practice the JOINT
INTELLECTUAL PROPERTY covered by such specific patent application(s)/patent(s) or plant variety
rights application(s)/plant variety right(s) for research and evaluation purposes.

4.11 At each quarterly meeting of the MANAGEMENT COMMITTEE, CERES will report CERES INTELLECTUAL
PROPERTY on which patent applications were filed in the preceding quarter and the general subject
matter of patent applications reasonably anticipated to be filed in the near term, and IGER will
report IGER INTELLECTUAL PROPERTY on which patent applications were filed in the preceding quarter
and the general subject matter of patent applications reasonably anticipated to be filed in the near
term. In addition, the Parties may exchange information regarding their respective INTELLECTUAL
PROPERTY at other times as they deem fit.

4.12 The provisions of this Article 4 and specifically but without limitation the definitions in
Articles 4.1 through 4.4 and Articles 4.6 and 4.7 shall apply to any results obtained in RESEARCH
PROJECTS, including results of activities covered by EXISTING AGREEMENTS, except if expressly
provided otherwise in a SCHEDULE or in Article 18.

5.1.1 Through the express grant of such rights in any SCHEDULE, CERES may grant IGER the right to
use CERES INTELLECTUAL PROPERTY to the extent required for, and for the sole purpose of, the
performance by IGER (or its SUBCONTRACTORS) of RESEARCH PROJECTS. SCHEDULES may specify that similar
rights are granted with respect to defined elements of CERES BACKGROUND INTELLECTUAL PROPERTY.

5.1.2 IGER shall have the right to use JOINT INTELLECTUAL PROPERTY and OTHER RESEARCH RESULTS (a)
for the purpose of the implementation of RESEARCH PROJECTS; (b) subject to Article 3 and CERES'
prior written approval, for internal research purposes and research under United Kingdom government
or European Union funding in collaboration with academic institutions in the European Union,
provided that CERES' approval may be conditional upon (i) CERES receiving the exclusive right
(subject to Articles 5.1.2(a) and 5.2) to use and exploit commercially the results of such research
in COLLABORATION CROPS, (ii) adequate safeguards to prevent unauthorized use or disclosure of JOINT
INTELLECTUAL PROPERTY, OTHER RESEARCH RESULTS or results directly or indirectly based on any of the
foregoing and (iii) CERES reviewing and approving the terms and conditions of any agreement
governing such research activities.

5.2.1 "RELEASED VARIETY" shall mean any variety of a COLLABORATION CROP which constitutes JOINT
INTELLECTUAL PROPERTY and which is released for commercialization pursuant to a SCHEDULE. IGER shall
have the non-exclusive right to exploit commercially RELEASED VARIETIES in the United Kingdom.

5. USE AND COMMERCIALIZATION RIGHTS.

5.1 IGER Research Rights.

5.2 Commercialization Rights of IGER in the United Kingdom.

CERES-IGER Collaboration Agreement Page 14 of 75
<!-- page 15 -->
5.2.2 If the commercial exploitation of a RELEASED VARIETY in the United Kingdom by IGER requires a
license on CERES INTELLECTUAL PROPERTY or BACKGROUND INTELLECTUAL PROPERTY of CERES, CERES shall
negotiate in good faith with IGER or a designee of IGER about the grant of such a license, provided
however that CERES shall have no obligation to grant any license on transgenes or transgenic
technologies.

5.2.3 Unless otherwise agreed by the Parties, IGER shall pay royalties to CERES under its
non-exclusive right set forth in Article 5.2.1 at a rate equal to one half of the royalty rate in
CERES' exclusive license agreement for the same RELEASED VARIETY, and CERES shall pay royalties at
the same rate to IGER for sales by CERES, its AFFILIATED COMPANIES or licensees in the United
Kingdom.

5.3.1 Subject to Articles 5.1 and 5.2, the Parties acknowledge and agree that CERES shall have the
exclusive right, with the right to grant sublicenses to this right, to use and commercially exploit
JOINT INTELLECTUAL PROPERTY (including but not limited to RELEASED VARIETIES) and OTHER RESEARCH
RESULTS for any and all uses and fields, including, but not limited to, use in the COLLABORATION
CROPS and crops other than the COLLABORATION CROPS. Any commercialization (including, but not
limited to, the grant of commercialization licenses) of JOINT INTELLECTUAL PROPERTY and/or OTHER
RESEARCH RESULTS shall result in CERES paying IGER a reasonable remuneration (whether as a royalty
or in some other form as the Parties may agree) to be negotiated in good faith. The terms for
remuneration will be specified, with respect to specific RESEARCH PROJECTS, JOINT INTELLECTUAL
PROPERTY and/or OTHER RESEARCH RESULTS, either in the respective SCHEDULES or in other agreements to
be executed by the Parties.

5.3.2 Subject to Articles 5.1 and 5.2, IGER grants CERES an exclusive, world-wide license, with the
right to grant sublicenses, to use and exploit commercially (a) IGER's interest in any JOINT
INTELLECTUAL PROPERTY (including but not limited to RELEASED VARIETIES) and OTHER RESEARCH RESULTS;
(b) IGER INTELLECTUAL PROPERTY and (c) when and only to the extent necessary for the
commercialization or use of JOINT INTELLECTUAL PROPERTY and/or OTHER RESEARCH RESULTS and/or IGER
INTELLECTUAL PROPERTY for the COLLABORATION CROPS, IGER BACKGROUND INTELLECTUAL PROPERTY, subject to
paying IGER reasonable remuneration (whether as a royalty or in some other form as the Parties may
agree) to be negotiated in good faith. Such license grants will be further specified in SCHEDULES to
this Agreement and/or other agreements to be executed by the Parties. Unless otherwise agreed by
both Parties, license agreements for non-transgenic RELEASED VARIETIES will be based on the Model
License Agreement for Non-transgenic Varieties in EXHIBIT G or such other model license agreements
as the Parties may agree upon. Certain remuneration principles to be included in other license
agreements, unless the Parties agree otherwise, are set forth in EXHIBIT H.

5.3 Commercialization Rights — Other.

CERES-IGER Collaboration Agreement Page 15 of 75
<!-- page 16 -->
6.1 CERES will have the right, at its own discretion and expense, to take any action to enforce and
to initiate and prosecute suits for infringement of jointly owned intellectual property rights
covering JOINT INTELLECTUAL PROPERTY. CERES and IGER will consult with each other upon a course of
action and enforcement strategy. CERES will be responsible for the conduct of any such enforcement
action, and IGER will reasonably cooperate with CERES to effect the enforcement action, and if
appropriate, determine a settlement position. CERES shall be responsible for retaining counsel and
shall promptly notify IGER following retention of counsel, and IGER agrees to be represented by such
counsel as may be required for any enforcement action or settlement. For purposes of settlement,
CERES shall be the contact with the Parties' counsel as well as the opposing Party(ies) and shall
have the right to enter into settlements. CERES shall keep IGER advised as to all developments with
respect to the enforcement action and settlement discussions, which includes supplying to IGER
copies of all papers received and filed in sufficient time for IGER to comment thereon. IGER may
attend any and all meetings with the Parties' counsel and the opposing side for settlement purposes.
IGER agrees to join voluntarily in any action brought by CERES as a Party plaintiff/defendant, if
necessary, at the expense of CERES. If necessary, IGER agrees to enter into a joint defense
agreement.

6.2 In situations where a substantial commercial interest of IGER in the United Kingdom is harmed by
infringement, and CERES elects not to pursue any action to enforce and to initiate and prosecute
suits for infringement, IGER shall have the right to pursue any such action and CERES will
reasonably cooperate with IGER, if necessary, to permit IGER to properly enforce its rights. IGER
will be responsible for the conduct of any such enforcement action. IGER shall be responsible for
retaining counsel and shall promptly notify CERES following retention of counsel, and CERES agrees
to be represented by such counsel as may be required for any enforcement action or settlement. For
purposes of settlement, IGER shall be the contact with the Parties' counsel as well as the opposing
Party(ies) and shall have the right to enter into settlements. IGER shall keep CERES advised as to
all developments with respect to the enforcement action and settlement discussions, which includes
supplying to CERES copies of all papers received and filed in sufficient time for CERES to comment
thereon. CERES may attend any and all meetings with the Parties' counsel and the opposing side for
settlement purposes. CERES agrees to join voluntarily in any action brought by IGER as a Party
plaintiff/defendant, if necessary, at the expense of IGER. If necessary, CERES agrees to enter into
a joint defense agreement.

6.3 Any damages received by a Party as a result of an enforcement action of rights to JOINT
INTELLECTUAL PROPERTY, after deduction of all enforcement related costs incurred by such Party,
shall be considered as revenues for the purpose of remuneration payments to the other Party, as set
forth in any applicable license/commercialization agreement between the Parties. In the absence of
any such license/commercialization agreement, the Parties will share such damages after deduction of
all enforcement related costs incurred by the Party receiving the damages, in proportion to their
relative financial contributions to the creation (i.e., research and development) of such JOINT
INTELLECTUAL PROPERTY.

7.1 As used in this Agreement, the term "Confidential Information" shall mean (a) all non-public
information and material received by one Party from the other in furtherance of the

6. ENFORCEMENT OF JOINT INTELLECTUAL PROPERTY RIGHTS.

7. CONFIDENTIALITY.

CERES-IGER Collaboration Agreement Page 16 of 75
<!-- page 17 -->
collaboration contemplated by this Agreement and (b) any and all information, results including
material and observations generated in the performance of any RESEARCH PROJECT including, without
limitation, CERES INTELLECTUAL PROPERTY, IGER INTELLECTUAL PROPERTY, JOINT INTELLECTUAL PROPERTY and
OTHER RESEARCH RESULTS. Confidential Information can include, but is not limited to, information
concerning the disclosing Party's operations, research, processes, techniques, data and non-public
materials.

7.2 Subject to Article 7.3, for a period of five (5) years after the termination of the related
RESEARCH PROJECT, the receiving Party shall not use, except (a) for the benefit of the Parties'
collaboration or (b) such use as is expressly allowed by this Agreement and/or disclose any
Confidential Information to any third party (i) without the prior written consent of the disclosing
Party if the Confidential Information was received from the other Party, or (ii) the prior written
consent of both Parties if the Confidential Information was generated during a RESEARCH PROJECT,
provided however that CERES shall have no restrictions regarding CERES INTELLECTUAL PROPERTY or
regarding any information of material resulting from RESEARCH PROJECT activities in which IGER does
not participate. Confidential Information shall only be made accessible to each Party's employees or
students on a need-to-know basis and not to any third party, subject to Articles 7.3 and 7.4.
Manuscripts and papers published in scientific journals and presentations made at public meetings
that include Confidential Information are exempt from the confidentiality obligations of this
Article, provided the Parties followed the procedure set forth in Article 8.

7.3 The receiving Party shall have no obligations of confidentiality for information that: can be
established through written evidence to be in the possession of the receiving Party prior to the
disclosure by the disclosing Party; is or becomes public knowledge through no fault of the
disclosing Party; and/or is acquired from others not under an obligation of confidentiality to the
disclosing Party. In addition, the Parties, pursuant to the express terms of this Agreement or any
SCHEDULE or other agreement between the Parties, shall have the right to proceed to disclosures of
Confidential Information (a) as required to file for intellectual property protection or
registration or deregulation or approval of genetically modified organisms; (b) as required to
exercise commercialization rights granted in or on the basis of this Agreement and for related
marketing activities; (c) as required by laws, rules or regulation or court ordering such as,
without limitation, SEC regulations and IRS regulations; or (d) in CERES' reasonable judgment for
the limited purpose of (potential) investors and business partners, but only with respect to the
Confidential Information defined in Article 7.1 (b) and not other Confidential Information of IGER.

7.4 The Parties acknowledge and agree that IGER will comply with its reporting obligations to DEFRA
as required by the DEFRA agreement NF 0426 referred to in EXHIBIT E, provided that IGER shall (i)
not disclose any CERES BACKGROUND INTELLECTUAL PROPERTY, CERES INTELLECTUAL PROPERTY or OTHER
RESEARCH RESULTS obtained by CERES, (ii) use all reasonable efforts to ensure that the
confidentiality of all other results of RESEARCH PROJECTS is maintained to the extent allowed by the
applicable regulations, and (iii) provide a draft of any such report to CERES at least thirty (30)
days before the submission date and take CERES' comments, if any, into account. CERES-IGER
Collaboration Agreement Page 17 of 75
<!-- page 18 -->
8. PUBLICATIONS.

8.1 The Parties agree that the researchers involved in the RESEARCH PROJECTS are permitted to
present methods and/or results of the RESEARCH PROJECTS at symposia and professional meetings and to
publish the same in journals or the like; provided however, the disclosing Party must furnish copies
of any proposed publication, presentation or disclosure (collectively "Disclosure") to the other
Party at least thirty (30) days in advance of the specific submission, presentation or other
disclosure.

8.2 The non-disclosing Party shall have the thirty (30) day notice period to object, in writing, to
such proposed Disclosure because it contains (a) potentially patentable subject matter that needs
protection or (b) BACKGROUND INTELLECTUAL PROPERTY or JOINT INTELLECTUAL PROPERTY or INTELLECTUAL
PROPERTY of the non-disclosing Party or OTHER RESEARCH RESULTS which need to be kept confidential
for compelling business reasons in the non-disclosing Party's reasonable judgment. In the event that
the non-disclosing Party makes such objection, the disclosing Party will (x) if applicable, elect to
cooperate with the non-disclosing Party to obtain proper protection in accordance with the
provisions of Article 4 herein or (y) remove the objectionable subject matter from the Disclosure.
No delay caused by the non-disclosing Party under this Article shall extend beyond three (3) months,
wherein upon such delay, the disclosing Party shall be permitted to proceed without being in breach
of this Article.

8.3 CERES and IGER shall use reasonable efforts to avoid any action that might jeopardize the
ability of the Parties, individually or jointly as the case may be, to obtain or retain
valid/enforceable intellectual rights in JOINT INTELLECTUAL PROPERTY, IGER INTELLECTUAL PROPERTY or
CERES INTELLECTUAL PROPERTY.

8.4 Nothing in this Article 8 shall restrict disclosures that are allowed under Article 7.

8.5 Upon recommendation of the MANAGEMENT COMMITTEE, the Parties may adopt alternative review
processes, in particular for information to be presented at symposia or professional meetings or for
activities directed towards legislative and regulatory bodies.

9.1 CERES will not identify IGER in any products, publicity, promotion, promotional advertising or
other promotional materials to be disseminated to the public, or use any trademark, service mark,
trade name, logo or symbol that is representative of IGER or its entities, whether registered or
not, or use the name, title, likeness or statement of any IGER faculty member, employee or student,
without IGER's prior written consent. Any use of IGER's name shall be limited to statements of fact
and shall not imply endorsement by IGER of CERES' research, products or services.

9.2 IGER will not identify CERES in any products, publicity, promotion, promotional advertising or
other promotional materials to be disseminated to the public, or use any trademark, service mark,
trade name, logo or symbol that is representative of CERES or its entities, whether registered or
not, or use the name, title, likeness or statement of any CERES employee or student, without CERES'
prior written consent. Any use of CERES' name shall be limited to statements of fact and shall not
imply endorsement by CERES of IGER's research, products or services.

9. PUBLICITY.

CERES-IGER Collaboration Agreement Page 18 of 75
<!-- page 19 -->
9.3 Notwithstanding any provision of this Article, either of the Parties can disclose or otherwise
acknowledge, without restriction, the existence of this Agreement as well as the collaborative
relationship between the Parties without the prior consent of the other Party. Notwithstanding the
unilateral disclosure rights provided for in this Article, if the disclosure or acknowledgement
takes the form of a written release by the disclosing Party, the disclosing Party shall provide the
other Party a copy of any such unilateral disclosure prior to its release so as to allow the other
Party to comment and shall take such comments reasonably into account. However, no advance copy
needs to be provided of any releases referred to in Article 9.4(a) or 9.4(b) or of any releases
which are identical to previous releases.

9.4 The Parties intend to issue joint press releases regarding their collaboration. Any such press
release and any press release by either Party will be subject to the prior written approval of both
Parties; provided however, that (a) CERES shall have the right to otherwise disclose information as
may be required in CERES' judgment to comply with SEC or IRS regulations or other laws, rules or
regulations governing disclosure of information and (b) IGER shall have the right to otherwise
disclose information as may be required in IGER's judgment to comply with laws, rules or regulations
governing disclosure of information. Notwithstanding the unilateral disclosure rights provided for
in this Article, the disclosing Party shall provide the other Party a copy of any such unilateral
disclosure preferably prior to its release.

10. RECORDS AND AUDITS.

IGER shall keep accurate and detailed records in accordance with good accounting practices of all
expenses and extramural income, if any, relating to the RESEARCH PROJECTS. All such records shall be
subject to inspection by an independent auditor designated by CERES and reasonably acceptable to
IGER within normal business hours with at least fourteen (14) days notice. Such inspection rights
shall terminate, with respect to each RESEARCH PROJECT, on the third anniversary of the expiration
or termination of such RESEARCH PROJECT.

11. INDEPENDENT CONTRACTOR.

The relationship of the Parties is that of independent contractors. Nothing herein is intended or
will be construed to establish any agency, partnerships or joint ventures. Neither Party is
authorized or empowered to act as an agent for the other Party for any purpose, nor shall either
Party be bound by the acts or conduct of the other Party.

12. CONVENTION ON BIOLOGICAL DIVERSITY.

12.1 The Parties agree that they shall at all times comply with the Convention on Biological
Diversity signed in 1992 at the Rio Earth Summit ("CBD") in the implementation of this Agreement, to
the extent the CBD is applicable.

12.2 Any germplasm of COLLABORATION CROPS made available by IGER for a RESEARCH PROJECT will be
identified in detail in the relevant SCHEDULE. The origin of the material, date of collection and
references to any agreements governing such material and/or the collection thereof will be included.
Reference to any such agreements existing on the Effective Date is included in EXHIBIT E or in
Article 13.2.1.8. CERES-IGER Collaboration Agreement Page 19 of 75
<!-- page 20 -->
12.3 With respect to any germplasm made available by IGER for a RESEARCH PROJECT which is covered by
the CBD, CERES, in collaboration with IGER who will provide all required assistance, will use
reasonable efforts to obtain commercialization rights from the relevant competent authorities in the
countries where the germplasm was collected, allowing the grant of rights to CERES as provided in
this Agreement.

13. WARRANTIES.

13.1 Representations and Warranties of CERES.

"To the Knowledge of CERES" as used in this Article 13.1 shall mean: to the actual knowledge, as of
the Effective Date, of any member of the Board of Directors or any officer of CERES or any employee
of CERES who has actively participated in the negotiation of the transactions contemplated by this
Agreement.

13.1.1 CERES represents and warrants to IGER that:

13.1.1.1 CERES (a) is a corporation duly incorporated, validly existing and in good standing under
the laws of the State of Delaware; (b) has all requisite power and authority to conduct the business
in which it is currently, or is currently proposed to be, engaged; (c) has the corporate power and
authority to execute and deliver this Agreement; and (d) has the corporate power and authority to
perform its obligations under this Agreement;

13.1.1.2 the execution, delivery, and performance by CERES of this Agreement have been duly
authorized by all necessary corporate action of CERES;

13.1.1.3 this Agreement has been duly executed and delivered by CERES, and constitutes the legal,
valid and binding obligations of CERES enforceable against CERES in accordance with its terms;

13.1.1.4 as of the Effective Date, CERES has not received notice of, and is not in default under, or
with respect to, any contractual obligation, which, individually or together with all such defaults,
would have a material adverse effect on the ability of CERES to perform its obligations under this
Agreement;

13.1.1.5 to the Knowledge of CERES, no approval, consent, compliance, exemption, authorization or
other action by, or notice to, or filing with, any governmental agency or other person and no lapse
of a waiting period is necessary or required in connection with the execution, delivery or
performance by, or enforcement against, CERES of this Agreement or the transactions contemplated
hereby;

13.1.1.6 to the Knowledge of CERES, CERES has the right to make the conveyances and grants in
accordance with the Articles hereof, including, without limitation, the license grants in this
Agreement, and no such conveyance or grant violates or constitutes an event that is or would be with
the passage of time, in any CERES-IGER Collaboration Agreement Page 20 of 75
<!-- page 21 -->
material way, a violation, breach or default of, any material agreement or material obligation to
which CERES is a party or by which it is bound; and

13.1.1.7 all former and current employees of CERES have executed written agreements with CERES that
assign to CERES all rights to any inventions, improvements, discoveries or information relating to
CERES' business, subject however to Section 2870 of the California Labor Code. To the Knowledge of
CERES, no employee of CERES has entered into any agreement with a former employer that would be
violated by his or her employment with CERES.

13.2 Representations and Warranties of IGER.

"To the Knowledge of IGER" as used in this Article 13.2 shall mean: to the actual knowledge, as of
the Effective Date, of any member of the Executive Committee of IGER or of any employee of IGER who
has actively participated in the negotiation of the transactions contemplated by this Agreement.

13.2.1 IGER represents and warrants to CERES that:

13.2.1.1 IGER (a) is a company limited by guarantee, registered in England No. 473456 and a
registered Charity No. 272150, duly incorporated, validly existing and in good standing under the
laws of England and Wales; (b) has all requisite power and authority to conduct the business in
which it is currently, or is currently proposed to be, engaged; (c) has the corporate power and
authority to execute and deliver this Agreement; and (d) has the corporate power and authority to
perform its obligations under this Agreement;

13.2.1.2 the execution, delivery, and performance by IGER of this Agreement have been duly
authorized by all necessary corporate action of IGER;

13.2.1.3 this Agreement has been duly executed and delivered by IGER, and constitutes the legal,
valid and binding obligations of IGER enforceable against IGER in accordance with its terms;

13.2.1.4 as of the Effective Date, IGER has not received notice of, and is not in default under, or
with respect to, any contractual obligation, which, individually or together with all such defaults,
would have a material adverse effect on the ability of IGER to perform its obligations under this
Agreement;

13.2.1.5 to the Knowledge of IGER, no approval, consent, compliance, exemption, authorization or
other action by, or notice to, or filing with, any governmental agency or other person and no lapse
of a waiting period is necessary or required in connection with the execution, delivery or
performance by, or enforcement against, IGER of this Agreement or the transactions contemplated
hereby;

13.2.1.6 to the Knowledge of IGER, and subject to the Assignment/License referred to in Article 14.1
(e) (v), IGER has the right to make the conveyances and grants in accordance with the Articles
hereof, including, without CERES-IGER Collaboration Agreement Page 21 of 75
<!-- page 22 -->
limitation, the license grants, and no such conveyance or grant violates or constitutes an event
that is or would be with the passage of time, in any material way, a violation, breach or default
of, any material agreement or material obligation to which IGER or any such Affiliate of IGER is a
party or by which it is bound;

13.2.1.7 all former and current employees of IGER have executed written agreements with IGER that
assign to IGER all rights to any inventions, improvements, discoveries or information relating to
IGER's business. To the Knowledge of IGER, no employee of IGER has entered into any agreement with a
former employer that would be violated by his or her employment with IGER; and

13.2.1.8 EXHIBIT E sets forth an exhaustive list of all agreements and commitments in existence on
the Effective Date to which IGER is a party, or that contain obligations or restrictions affecting
IGER, in connection with the COLLABORATION CROPS, except for the following agreements which are not
included in EXHIBIT E:

13.3 EXCEPT AS PROVIDED IN ARTICLES 13.1 AND 13.2, THE PARTIES ACKNOWLEDGE AND AGREE THAT NEITHER
PARTY HAS MADE ANY REPRESENTATIONS OR WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO,
WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT SHALL EITHER PARTY BE
HELD RESPONSIBLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL OR CONSEQUENTIAL DAMAGES OR LOSS OF PROFIT
ARISING OUT OF THE USE OF ANY JOINT INTELLECTUAL PROPERTY, CERES INTELLECTUAL PROPERTY, IGER
INTELLECTUAL PROPERTY, OTHER RESEARCH RESULTS OR BACKGROUND INTELLECTUAL PROPERTY COVERED BY THIS
AGREEMENT OR ANY SCHEDULE OR ARISING OUT OF THE IMPLEMENTATION OF THIS AGREEMENT, EVEN IF SUCH PARTY
IS ADVISED IN ADVANCE OF THE POSSIBILITY OF SUCH DAMAGES.

13.4 Nothing in this Agreement is or shall be construed as:

(a) a warranty or representation by either Party as to the validity or scope of any patent rights or
plant variety rights;

(b) a warranty or representation by either Party that anything made, used, sold or otherwise
disposed of pursuant to any license granted under this Agreement is or will be free from
infringement of patents, copyrights or other rights of third parties;

(c) any obligations by either Party to bring or prosecute actions or suits against third

Confidential Treatment Requested and the Redacted Material has been separately filed with the
Commission

1. Agreement of July 12, 2004 between Bio-Renewables Limited, IGER and Plant Research International
B.V.;

2. Agreement dated the 23rd of June 2005 between [***] and IGER; and

3. Agreement dated October 18, 2006 between [***] and IGER.

CERES-IGER Collaboration Agreement Page 22 of 75
<!-- page 23 -->
parties for patent infringement; or parties for patent infringement, or

a grant by implication, estoppel or otherwise of any licenses under patent applications, patents,
plant variety rights applications and/or plant variety rights of CERES and/or IGER or other person
other than as provided in the express provisions of this Agreement or a SCHEDULE on this Agreement.

14.1 The term of this Agreement shall be fifteen (15) years from the Effective Date, unless sooner
terminated in accordance with the following provisions of this Article:

(a) mutual, written agreement of the Parties;

(b) failure of one Party to satisfy its material obligations under this Agreement, and such Party
subsequently fails to cure such failure(s) within (i) thirty (30) days for failures to remit payment
for amounts due under this Agreement and (ii) ninety (90) days for all other obligations in each
case after receipt of written notice from the non-breaching Party specifying such failure(s);

(c) one (1) year's written notice of termination by either CERES or IGER to the other Party in case
either the terminating Party or the other Party ceases substantially all activities in the
COLLABORATION CROPS;

(d) IGER will have the right to terminate this Agreement unilaterally with thirty (30) days' written
notice to CERES, (i) if CERES seeks protection under any bankruptcy, insolvency, receivership,
trust, deed, creditors arrangement or comparable proceeding or if any such proceeding is instituted
against CERES (and not dismissed within one hundred twenty (120) days); (ii) in case of dissolution
or winding up of CERES (excluding any situation where all or substantially all of CERES' assets,
stock or business to which this Agreement relates are acquired by a third party (whether by sale,
acquisition, merger, operation of law or otherwise)); or (iii) with written notice to CERES, if
CERES has failed in a substantial manner, three (3) years after either Party or the Parties jointly
have developed a propagation method for Miscanthus that results in the crop being commercially
competitive in the United States or in Europe as compared to other energy crops being grown at that
time in the relevant geography, to implement the activities set forth in EXHIBIT F, and does not
remedy such failure or offer a remediation plan which is reasonably acceptable to IGER within ninety
(90) days after receipt of a written notice from IGER specifying such failure;

(e) CERES will have the right to terminate this Agreement unilaterally: (i) with thirty (30) days'
written notice to IGER if John Clifton-Brown or Iain Donnison cease(s) to be associated with IGER
and the RESEARCH PROJECTS contemplated by this Agreement, and IGER has not replaced such person(s)
within one hundred twenty (120) days by (a) person(s) reasonably acceptable to CERES; (ii) with
ninety (90) days' written notice to IGER, if the institutional mission, purpose, structure or
funding of IGER would change substantially and adversely affect IGER's ability to satisfy its
obligations hereunder; (iii) with one (1) years' written notice to IGER, if CERES has a documented
compelling business reason to cease the collaboration, (for example, without limitation, lack of
sufficient processing capacity for COLLABORATION CROPS within the expected timeframe in the United
States; COLLABORATION CROPS are non-competitive with other biomass sources); (iv) with three (3)
months' prior written notice to IGER, such notice to be given no earlier than eighteen (18)

14. TERM AND TERMINATION.

CERES-IGER Collaboration Agreement Page 23 of 75
<!-- page 24 -->
months after the Effective Date, if no rights to commercialize (including determination of the
compensation due upon commercialization) COLLABORATION CROPS germplasm provided by IGER which is
included in a RESEARCH PROJECT have been secured to CERES' reasonable satisfaction in compliance
with the CBD; or (v) with thirty (30) days' written notice to IGER if Defra has not assigned to
IGER, or granted to IGER an exclusive license reasonably satisfactory to CERES on, the Intellectual
Property vested in Defra or the Crown or the Secretary of State pursuant to the DEFRA agreement NF
0426 within sixty (60) days from the Effective Date (the "Assignment/License").

(f) either Party will have the right to terminate this Agreement if no active RESEARCH PROJECTS
exist for more than two (2) years, provided that on or after the second anniversary of the
expiration or termination of the last SCHEDULE to expire or terminate, the Parties have not agreed
on any new SCHEDULE despite (i) negotiations in good faith by both Parties or (ii) diligent,
documented attempts by the terminating Party to conduct negotiations in good faith with respect to
one or more new SCHEDULES, to which attempts the other Party has not been responsive.

14.2 Promptly upon the delivery of a notice of termination of this Agreement, the Parties will meet
to discuss the ongoing RESEARCH PROJECTS, and each Party will provide to the other Party any data,
information and germplasm that constitutes or is covered by JOINT INTELLECTUAL PROPERTY and which
has not been provided prior to the notice of termination, without prejudice to additional on-going
delivery obligations set forth in any SCHEDULES.

14.3 Termination of this Agreement shall not affect the rights and obligations of the Parties
accrued prior to termination hereof nor any license grants then in existence, nor either Party's
non-exclusive rights to commercialize then existing RELEASED VARIETIES in the United Kingdom,
subject to payment of remuneration as set forth in any relevant license/commercialization
agreements. Further, the provisions set forth hereinafter shall apply.

14.3.1 In case of termination on the basis of Article 14.1 (b) if CERES is the breaching Party,
Article 14.1 (c) if CERES ceases substantially all activities in the COLLABORATION CROPS, Article
14.1 (d) (i), (ii) or (iii) or Article 14.1. (e) (iii), at or about the effective date of
termination, the Parties will negotiate in good faith to reach agreement as to the rights to use and
commercially exploit JOINT INTELLECTUAL PROPERTY not covered by any relevant
license/commercialization agreement between the Parties, which rights will be addressed in one or
more written agreements. If the Parties fail to reach agreement within ninety (90) days after the
start of such negotiations, which shall be evidenced by written notice from one Party to the other
initiating such negotiations, each Party shall have the non-exclusive right to use and commercially
exploit JOINT INTELLECTUAL PROPERTY for any and all purposes, with the right to grant sublicenses,
subject to the obligations of the first sentence of Article 14.3, provided that no licenses on any
transgenes or transgenic technologies of the other Party shall be included or implied.

14.3.2 In case of termination on the basis of Article 14.1 (b) if IGER is the breaching Party,
Article 14.1 (c) if IGER ceases substantially all activities in the COLLABORATION CROPS, Article
14.1 (e) (i) or (ii) or Article 14.1 (f), subject to the obligations of the first sentence of
Article 14.3, CERES shall have the exclusive right to use and commercially exploit any JOINT
INTELLECTUAL PROPERTY to the extent such JOINT CERES-IGER Collaboration Agreement Page 24 of 75
<!-- page 25 -->
INTELLECTUAL PROPERTY is not covered by any relevant license/commercialization agreement between the
Parties. At or about the effective date of termination, the Parties will negotiate in good faith to
reach agreement as to reasonable remuneration (whether as a royalty or in some other form as the
Parties may agree), which will be addressed in one or more written agreements. If the Parties fail
to reach agreement within ninety (90) days after the start of such negotiations, which shall be
evidenced by written notice from one Party to the other initiating such negotiations, the
remuneration shall be settled in accordance with the dispute resolution procedure in Article 15.

14.4 Termination of this Agreement for any reason will not relieve either Party of any obligation or
liability accrued under this Agreement before termination or rescind any payments made or due before
termination. Articles 4, 5 (subject to Article 14.3), 6, 7, 8, 9.1, 9.2, 10, 12.3, 13, 14.2, 14.3,
14.4, 14.5, 15, 16 and 18 will survive any termination of this Agreement.

14.5 Termination of this Agreement shall not automatically terminate any existing RESEARCH PROJECT,
which can only be terminated according to the specific terms of the related SCHEDULE. The terms and
provisions of this Agreement shall continue to apply to the activities and outcomes of any such
RESEARCH PROJECTS, notwithstanding the termination of this Agreement, unless provided otherwise in
the relevant SCHEDULE or by written agreement of the Parties upon termination.

15.1 All disputes, differences or questions arising out of or in connection with this Agreement or
its SCHEDULES, or related to the alleged breach, termination, validity, interpretation or violation
thereof, shall be submitted to the MANAGEMENT COMMITTEE for resolution, which shall convene, whether
in person or otherwise, to resolve such dispute in a timely manner. Either Party may initiate a
resolution procedure by providing written notice ("Dispute Notice") to the other Party, and any such
Dispute Notice must set forth the subject matter of the dispute, difference or question. If after
sixty (60) days the dispute remains unresolved, the Chief Scientific Officer of CERES and the
Director of IGER shall seek to resolve the dispute through negotiation. The Parties agree that at
least eight (8) cumulative hours of negotiations will be undertaken. If the dispute still remains
unresolved ninety (90) days after the Dispute Notice, either Party may initiate proceedings pursuant
to Article 15.2.

15.2 Dispute Resolution and Arbitration.

In the event of any dispute arising out of or in connection with this Agreement, the Parties agree
to submit the matter to settlement proceedings under the ICC ADR Rules. If the dispute has not been
settled pursuant to the said Rules within forty-five (45) days following the filing of a Request for
ADR or within such other period as the Parties may agree in writing, such dispute shall be finally
settled under the Rules of Arbitration of the International Chamber of Commerce by three (3)
arbitrators appointed in accordance with the said Rules of Arbitration. The provisions set forth
hereinafter shall apply to the arbitration procedures, without prejudice to the ICC Rules of
Arbitration.

15.2.1 Qualifications of Arbitrators.

15. DISPUTE RESOLUTION AND APPLICABLE LAW.

CERES-IGER Collaboration Agreement Page 25 of 75
<!-- page 26 -->
Each arbitrator appointed shall have a reputation as being experienced in the legal and technical
matters related to the dispute, shall be required to disclose, among other disclosures, any prior
involvement with the legal and technical matters related to the dispute and any involvement with a
competitor of any Party, and shall not be presently nor in the past have been affiliated with any
Party or a competitor of any Party. Notwithstanding the method of their appointment, each arbitrator
shall be required to meet the standards contained in the Rules with respect to independence.

15.2.2 Location of the Arbitration.

The seat of arbitration shall be Paris, France. The arbitrators may hold hearings at such other
locations as the arbitrators shall determine, after consultation with the Parties.

15.2.3 Language of Arbitration.

The arbitral proceedings and all pleadings and written evidence shall be in the English language.
Any written evidence originally in a language other than English shall be submitted in English
translation accompanied by the original or true copy thereof

15.2.4 Limitation on Remedies.

The arbitrators are precluded from awarding punitive or exemplary damages. In no event shall the
arbitrators have the powers of an amiable compositeur.

15.3 Applicable law.

This Agreement shall be governed by, and construed and interpreted in accordance with, the laws of
the State of New York, United States of America, without regard to the principles of conflicts of
law thereof.

Any notices required to be given or which shall be given under this Agreement shall be in writing
and delivered by overnight (trackable) courier addressed to the Parties as follows:

Vice President of Product Development cc: Legal Department Ceres, Inc. 1535 Ranch Conejo Blvd.
Thousand Oaks, California 91320 United States of America

Institute Business Manager OR for legal or financial notices: Institute Secretary Institute of
Grassland and Environmental Research

16. NOTICES.

CERES-IGER Collaboration Agreement Page 26 of 75

Plas Gogerddan Aberystwyth Ceredigion SY23 3EB United Kingdom

Notices under this Agreement sent by overnight courier by one Party to the other Party at its above
address, shall be deemed to have been given or made as of the date following the date so mailed.
<!-- page 27 -->
17. GENERAL.

17.1 Entire Agreement/Modifications.

This Agreement constitutes the entire agreement between the Parties hereto with respect to the
subject matter hereof, and there are no representations, warranties, covenants or obligations except
as set forth herein. This Agreement supersedes all prior and contemporaneous agreements,
understandings, negotiations and discussions, written or oral, of the Parties hereto relating to the
subject matter hereof. This Agreement and its SCHEDULES may only be amended, modified or superseded
by a writing executed by the authorized representatives of the Parties hereto. It is anticipated
that SCHEDULES will be attached to and become part of this Agreement as new RESEARCH PROJECTS are
undertaken, as described in Article 1.1.

17.2 Severability.

This Agreement, to the greatest extent possible, shall be construed so as to give validity to all of
the provisions hereof. If any provision of this Agreement is or becomes invalid, is ruled illegal by
a court of competent jurisdiction or is deemed unenforceable under the current applicable law from
time to time in effect during the term of this Agreement, the remainder of this Agreement will not
be affected or impaired thereby and will continue to be construed to the maximum extent permitted by
law. In lieu of each provision which is invalid, illegal or unenforceable, there will be substituted
or added as part of this Agreement by mutual written agreement of the Parties, a provision which
will be as similar as possible, in economic and business objectives as intended by the Parties to
such invalid, illegal or unenforceable provision, but will be valid, legal and enforceable.

17.3 Waiver.

No failure or delay by either Party in exercising any right or remedy under this Agreement will
waive any provision of this Agreement. Nor will any single or partial exercise by either Party of
any right or remedy under this Agreement preclude it from otherwise or further exercising any rights
or remedies which it may have, or any other rights or remedies granted by any law or any related
document.

17.4 Enforcement.

In the event an action is commenced by either Party against the other to enforce any of the
provisions of this Agreement, the prevailing Party shall be entitled to recover from the other Party
reasonable attorneys' fees, court costs and necessary disbursements incurred in connection with such
action. CERES-IGER Collaboration Agreement Page 27 of 75
<!-- page 28 -->
17.5 Assignablility.

This Agreement binds and enures to the benefit of the Parties, their successor or assigns, but may
not be assigned by either Party without the prior written consent of the other Party; provided
however, CERES shall have the right to assign its rights and obligations under this Agreement to any
Affiliated Company without such prior consent. Each Party shall have the right to assign its rights
and obligations under this Agreement to a third party in conjunction with the transfer to such third
party of substantially all of the assets of such Party associated with performance under this
Agreement without such prior consent. "Affiliated Company" defined as any company owned or
controlled by, under common control with or controlling CERES, "control" meaning in this context the
direct or indirect ownership of fifty percent (50%) or more of the voting stock/shares of a company,
or the power to nominate at least half of the directors.

17.6 Force Majeure.

No Party shall be responsible to the other Party for delay or failure in performance of any the
obligations imposed by this Agreement, provided such failure shall be occasioned by fire, flood,
explosion, lightning, wind storm, hailstorm, earthquake, subsidence of soil, failure of machinery or
equipment or supply of materials, discontinuity in the supply of power, court order or governmental
interference, terrorist attacks, civil commotion, riot, war, strikes, labor disturbances,
transportation difficulties, labor shortage, natural genetic variation of any living matter or by
any other cause of like or unlike nature beyond the reasonable control and without fault or
negligence of such Party.

18. SPECIAL CONDITIONS IN CONNECTION WITH DEFRA AGREEMENT NF 0426.

The Parties acknowledge that Defra is expected to assign or license exclusively to IGER any rights
in Intellectual Property which would vest in Defra or the Crown or the Secretary of State pursuant
to the DEFRA agreement NF 0426. If IGER receives an exclusive license from Defra rather than an
assignment of rights, the following will apply.

18.1 To the extent the license grant to CERES on IGER BACKGROUND INTELLECTUAL PROPERTY in Article
5.3.2 relates to IGER BACKGROUND INTELLECTUAL PROPERTY that constitutes Intellectual Property to
which rights vest in Defra or the Crown or the Secretary of State, the word "license" will be read
as "sublicense" and all other terms of such Article will remain unchanged.

18.2 To the extent that IGER INTELLECTUAL PROPERTY or JOINT INTELLECTUAL PROPERTY created in a
RESEARCH PROJECT constitutes or includes Intellectual Property to which rights vest in Defra or the
Crown or the Secretary of State, any conveyance or grant of rights or licenses by IGER to CERES in
this Agreement with respect to such IGER INTELLECTUAL PROPERTY or JOINT INTELLECTUAL PROPERTY, will
be read as the grant of an exclusive sublicense under IGER's exclusive license from Defra.
CERES-IGER Collaboration Agreement Page 28 of 75
<!-- page 29 -->
IN WITNESS WHEREOF, IGER and CERES have caused this Agreement to be duly executed as indicated
below. INSTITUTE OF GRASSLAND AND ENVIRONMENTAL RESEARCH CERES, INC.

By: /s/ MERVYN HUMPHREYS By: /s/ RICHARD FLAVELL Name:

Professor Mervyn Humphreys Name:

Richard Flavell, CBE, FRS Title: Director Title: Chief Scientific Officer By: /s/ RICHARD HAMILTON
Name:

Richard Hamilton Title: President and Chief Executive Officer CERES-IGER Collaboration Agreement
Page 29 of 75
<!-- page 30 -->
EXHIBIT A

to the Collaboration Agreement between IGER and CERES

DEFINITION OF COLLABORATION CROPS

Miscanthus and interbreeding species, including without limitation Saccharum and Erianthus species.
CERES-IGER Collaboration Agreement Page 30 of 75
<!-- page 31 -->
EXHIBIT B

to the Collaboration Agreement between IGER and CERES

PREFERRED FORM OF RECEIPT FORM

Packing Slip and Receipt Form for material transferred pursuant to the Collaboration Agreement dated
[x] between INSTITUTE OF GRASSLAND AND ENVIRONMENTAL RESEARCH and CERES, INC. and SCHEDULES to such
Agreement.

Material transferred pursuant to SCHEDULE [x] dated [...]

The undersigned [IGER/CERES] signatory certifies that the material and related information set forth
hereinafter are included in the shipment with which this form is enclosed.

The undersigned [IGER/CERES] signatory acknowledges having received in good order the material and
related information set forth hereinafter. The signature does not constitute an acceptance of the
receiving party's qualification of the intellectual property (IP) status of the material
transferred, such IP status being defined in the Parties' Collaboration Agreement.

[Include description of material and related information with indication of IP status (e.g.
Background, Joint IP) and any restrictions on transfer to subcontractors.]

THIS MATERIAL AND RELATED INFORMATION ARE TRANSFERRED ONLY FOR USE IN COMPLIANCE WITH THE ABOVE
MENTIONED COLLABORATION AGREEMENT AND SCHEDULE. CONFIDENTIALITY OBLIGATIONS APPLY. For
sending/receipt, For receipt/sending, Signature: Signature:

Date: Date:

Name: Walter E. Nelson Name:

Title: Product Development Manager CERES, INC.

Title: INSTITUTE OF GRASSLAND AND ENVIRONMENTAL RESEARCH

CERES-IGER Collaboration Agreement Page 31 of 75
<!-- page 32 -->
EXHIBIT C

to the Collaboration Agreement between IGER and CERES

PREFERRED FORMS OF VARIETY EVALUATION AGREEMENT

(to be used for field evaluation)

FIELD TRIAL AGREEMENT (Non transgenic. Fee for service. Academic.)

and

FIELD TRIAL AGREEMENT (Non transgenic. No payment. Academic.)

PREFERRED FORM OF MATERIAL TRANSFER AGREEMENT (to be used for transfer of material for other
purposes than field evaluation) CERES-IGER Collaboration Agreement Page 32 of 75

FIELD TRIAL AGREEMENT (Non transgenic. Fee for service. Academic.)

1. THE PARTIES
<!-- page 33 -->
This Agreement is made effective on [date] ("Effective Date") by and between [Ceres, Inc., a
Delaware corporation with principal offices at 1535 Rancho Conejo Blvd., Thousand Oaks, CA 91320,
United States of America] or [Institute of Grassland and Environmental Research, a company limited
by guarantee, registered in England No. 473456 and a registered Charity No. 272150, having an office
at Plas Gogerddan, Aberystwyth, Ceredigion, SY23 3EB, United Kingdom] hereinafter "[CERES/IGER],"
and [Party information to be completed], hereinafter "[Party]."

THE PARTIES HERETO COVENANT AND AGREE AS FOLLOWS:

2. FIELD TRIAL PROGRAM

2.1 [CERES/IGER] will deliver to [Party] seeds or other propagating material as described in ANNEX I
and related information (jointly referred to as the "CERES/IGER Plant Material"). The delivery
conditions are set forth in ANNEX I. Promptly upon receipt of the CERES/IGER Plant Material, Party
will sign and return the Receipt Form, in the preferred format attached as ANNEX II to this
Agreement, to [CERES/IGER] (attn: [responsible person at CERES/IGER]).

2.2 [Party] agrees to perform the activities defined in ANNEX I which shall be referred to
hereinafter as the "Program." With reasonable notice [CERES/IGER] may change the activities to be
performed in the Program. If such changes do not result in additional work to be performed by
[Party], but consist for example of changes in experimental design or in observations to be made or
in information to be included in reports, they shall be set forth in a written document provided by
[CERES/IGER] to [Party] which will be attached to ANNEX I and form part of it. If such changes
result in additional work to be performed by [Party] and require an adaptation of the remuneration,
they shall be set forth in an amendment to this Agreement signed by both Parties. [CERES/IGER] will
consider any suggestions for changes in the Program which [Party] may suggest.

2.3 In performing the Program activities [Party] undertakes to comply with the work plan and time
schedule set forth in ANNEX I.

2.4 [Party] undertakes only to use the CERES/IGER Plant Material or any part, progeny or seeds
thereof for performing the Program activities to be carried out under the Program and not for any
other purpose. Specifically, but without limitation, [Party] shall not use the Plant Material or any
progeny, plants, parts of plants, plant material, seeds or products derived therefrom in any form of
reselection, breeding, sexual crossing, seed production, back crossing, tissue culturing,
mutagenesis, genetic transformation or any biotechnological process, except as specifically approved
in this Agreement. CERES-IGER Collaboration Agreement Page 33 of 75
<!-- page 34 -->
2.5 The CERES/IGER Plant Material will be used only on fields and at premises under the control of
[Party] and identified in ANNEX I.

2.6 Upon termination of the Program, [Party] will, at the option of [CERES/IGER], (i) allow
[CERES/IGER] to remove any Plant Material and any progeny, plants, plant material, seeds or products
obtained in the Program or (ii) destroy any remaining CERES/IGER Plant Material and any plants,
plant material and seeds obtained under the Program within fifteen (15) days from [CERES/IGER]'s
request to destroy, and will send [CERES/IGER] forthwith an attestation of such destruction.

2.7 Subject to giving at least one day's prior written notice in writing or by email to [Party],
[CERES/IGER] and [CERES/IGER] invitees will have the right to visit the fields where Program
activities are being conducted at any time, to make observations and to collect samples.

3. REPORTS

3.1 [Party] shall send [CERES/IGER] detailed written reports on the implementation of the Program
activities and the observations made and results obtained during the implementation of the Program.
The frequency of the reports and the type of information to be included in same is set forth in
ANNEX I.

3.2 During the entire Program, [Party] will promptly communicate to [CERES/IGER] any information on
the Program activities or the results obtained or observed that [CERES/IGER] may ask. Between
reports, [Party] will also spontaneously communicate to [CERES/IGER] any unexpected observations or
results.

4. REMUNERATION. PAYMENT

4.1 [CERES/IGER] will pay [Party] a remuneration as set forth in ANNEX I for the implementation of
the Program, in accordance with the payment schedule set forth in such annex. Overhead costs
included in the remuneration shall not exceed [x] percent (x%).

4.2 The payments will be made on the dates set forth in the payment schedule in ANNEX I provided
that [CERES/IGER] has received a corresponding invoice from [Party] at least thirty (30) days in
advance, by bank transfer to [Party's] account mentioned in its invoice.

5. OWNERSHIP. INTELLECTUAL PROPERTY RIGHTS. EXPLOITATION

5.1 This Agreement does not bring any change to the ownership and intellectual property rights
relating to the CERES/IGER Plant Material. [Party] acknowledges that the CERES/IGER Plant Material
may be covered by patents or patent applications of [CERES/IGER].

5.2 [CERES/IGER] will exclusively own any plants, parts of plants, plant material, seeds,
information, data, technology, or other findings or inventions resulting from the CERES-IGER
Collaboration Agreement Page 34 of 75
<!-- page 35 -->
Program that relate to the CERES/IGER Plant Material (hereinafter "Results"). [CERES/IGER] will have
the exclusive rights to protect any of the Results through patents or plant variety protection
rights or similar protection, and any intellectual property rights arising therefrom will belong
exclusively to [CERES/IGER]. In case [Party] has made or contributed to any invention forming part
of the Results, [Party] shall promptly inform [CERES/IGER] thereof in writing and shall assign its
rights and cause its employees and staff members to assign their rights in any such invention to
[CERES/IGER]. [Party] shall render such assistance as may be required for assigning any rights
[Party] inventors may have in such invention to [CERES/IGER] or [CERES/IGER]'s designee and for
protecting such invention, including but not limited to the signing of documents. Any inventor of
[Party] will be recognized in patent applications on an invention which is part of the Results in
accordance with [U.S./U.K. patent law].

5.3 [CERES/IGER] will have the exclusive right to commercialize any of the Results.

6. CONFIDENTIALITY. PUBLICATIONS.

6.1 [Party] will treat any and all information and material communicated or transferred to it by
[CERES/IGER] pursuant to this Agreement (including but not limited to the CERES/IGER Plant Material)
and any Results (including without limitation any progeny, plants, seeds, parts of plants, plant
material, or products obtained directly or indirectly from the Plant Material) as strictly
confidential and will not use the same for any purpose other than as expressly allowed by this
Agreement nor disclose or transfer the same to any third party other than its employees or staff
members necessary to carry out the Program and bound by appropriate secrecy and non-use undertakings
consistent with [Party's] obligations under this Agreement.

6.2 [Party] shall take all precautions to prevent theft or pilferage of the Plant Material and any
progeny, plants, seeds, parts of plants or plant material obtained directly or indirectly from the
Plant Material.

6.3 [Party] will not grant access to any field where Plant Material or any progeny, plants, seeds,
parts of plants or plant material obtained directly or indirectly from the Plant Material can be
viewed to any third party except with the prior written permission of [CERES/IGER].

6.4 "Publication" and "Publish" shall include any discussion with or presentation to a third party,
other than parties referred to in Article 6.1. Examples of Publications include, without limitation:
presentation at a conference, submission for publication to a journal, submission of joint
proposals, posting information on a website, posters, abstracts, Ph.D. dissertations, and informal
oral discussions. Subject to [CERES/IGER]'s prior written approval, which will not unreasonably be
withheld, [Party] may proceed to Publication of selected Results provided that: (i) no confidential
information of [CERES/IGER] is revealed thereby, (ii) [Party] shall take into account any
suggestions which may be formulated by [CERES/IGER], and (iii) at least thirty (30) days prior to
the submission to a publisher or presentation to any third party, [Party] CERES-IGER Collaboration
Agreement Page 35 of 75
<!-- page 36 -->
delivers copies of the proposed Publication to [CERES/IGER] for review. At [CERES/IGER]'s request,
[Party] shall, for a reasonable period up to ninety (90) days from initial delivery to [CERES/IGER],
delay revealing any patentable subject matter in the disclosure in order to permit the filing of
patent applications. In any Publication, the Parties shall consider joint authorship and acknowledge
the contributions and publications of the other as scientifically appropriate.

7. WARRANTIES. LIMITED LIABILITY

7.1 [Party] acknowledges that the CERES/IGER Plant Material is of an experimental nature and will
take all reasonable precautions to prevent any damage or injury by the CERES/IGER Plant Material and
any progeny, plants, parts of plants, plant material, seeds or products derived therefrom.

7.2 [Party] warrants that the CERES/IGER Plant Material will exclusively and restrictedly be used
under suitable containment conditions, and in accordance with all applicable regulations, and it
will not be used on human subjects. In addition, [Party] will strictly comply with any planting
distance, isolation and similar requirements set forth in ANNEX I. [Party] will obtain any
authorizations or permits or proceed to any notifications which may be required for the Program
activities, [Party] will inform [CERES/IGER] in writing, within thirty (30) days from the Effective
Date, of any such requirements and certify its compliance with same.

7.3 [CERES/IGER] declines any liability for any damage which may be caused by the CERES/IGER Plant
Material or the Program activities or Results to [Party] or any third party.

7.4 Neither Party shall be liable for indirect, special, remote, incidental or consequential damages
or loss of profit in connection with this Agreement or its implementation.

8. GENERAL CONDITIONS

8.1 Amendments: This Agreement, including its annexes, may only be amended by a written document
signed by duly authorized representatives of the Parties.

8.2 Ambiguities: In case of ambiguity between this Agreement and its annexes, the contents of the
agreement shall prevail.

8.3 Number of copies: This Agreement including its annexes is being made in two (2) copies, one for
each Party.

8.4 Assignment / Subcontracts: [CERES/IGER] has concluded this Agreement with [Party] in view of
[Party]'s specific qualifications and [Party] shall not have the right to assign any of its rights
or obligations under this Agreement nor to sub-contract any part of the Program activities to any
third party, except with the prior written approval of [CERES/IGER]. [CERES/IGER] has the right to
assign its rights and obligations under this Agreement to any third party. Further, [CERES/IGER] has
the right to CERES-IGER Collaboration Agreement Page 36 of 75
<!-- page 37 -->
Made in two (2) copies.

entrust the implementation of all or part of its obligations under this Agreement to any of its
affiliates.

8.5 Equitable Remedies: It is understood and agreed that money damages would not be a sufficient
remedy for any breach of this Agreement by [Party] and that [CERES/IGER] is entitled to equitable
relief, including injunction and specific performance, as a remedy for any such breach. Such
remedies shall not be deemed to be the exclusive remedies for a breach by [Party] of this Agreement
but shall be in addition to all other remedies available at law or equity to [CERES/IGER].

8.6 Governing Law / Jurisdiction: [to be completed]

9. DURATION

9.1 This Agreement will enter into force on the Effective Date and will remain in full force and
effect until the latest of the following dates: (i) the [third] anniversary of the Effective Date,
(ii) the date of delivery by [Party] of the last report provided for in this Agreement, or (iii) the
dates on which the last payment due by [CERES/IGER] pursuant to this Agreement is made.

9.2 Notwithstanding Article 9.3., [CERES/IGER] will have the right to terminate this Agreement
including the Program at any time with [three (3)] months' prior written notice. In case of such
early termination, [CERES/IGER] will pay the remuneration provided in this Agreement up to the
effective date of termination, and all costs relating to the implementation of this Agreement which
[Party] irrevocably committed to prior to receipt of the notice of termination.

9.3 Either Party will have the rights to terminate this Agreement unilaterally by registered letter
addressed to the other Party in case such other Party has committed a breach of any of its
obligations under this Agreement and has failed to remedy such breach within thirty (30) days from
the receipt of a registered letter specifying the breach.

9.4 The provisions of Articles 2.6, 5, 6, 7.3, 7.4, 8.5 and 8.6 will survive the expiration or
termination of this Agreement.

[Party] [Institute of Grassland and Environmental Research] or [Ceres, Inc.] By: By:

Name: Name:

Title: Title:

By: By:

Name: Name:

Title: Title:

CERES-IGER Collaboration Agreement Page 37 of 75
<!-- page 38 -->
ANNEX I

to the Field Trial Agreement between [CERES/IGER] and [Party]

PLANTING / MANAGEMENT PLAN FOR [CERES/IGER] MISCANTHUS EVALUATION TRIAL — [Party]

Trial Scope and Purpose:

1. Planting Material

2. Program Activities

3. Content and timing of reports CERES-IGER Collaboration Agreement Page 38 of 75
<!-- page 39 -->
ANNEX II

to the Field Trial Agreement between [CERES/IGER] and [Party]

FORM OF RECEIPT FORM

Packing Slip and Receipt Form for material transferred pursuant to the Field Trial Agreement dated
[x] between [CERES/IGER] and [Party].

The undersigned [Party/[CERES/IGER]] signatory certifies that the material and related information
set forth hereinafter are included in the shipment with which this form is enclosed.

The undersigned [Party/[CERES/IGER]] signatory acknowledges having received in good order the
material and related information set forth hereinafter.

[Include description of material and related information.]

THIS MATERIAL AND RELATED INFORMATION ARE TRANSFERRED ONLY FOR USE IN COMPLIANCE WITH THE ABOVE
MENTIONED FIELD TRIAL AGREEMENT. CONFIDENTIALITY OBLIGATIONS APPLY. For sending/receipt, For
receipt/sending, Signature: Signature:

Date: Date:

Name: Name: Title: Title: [CERES/IGER] [Party] CERES-IGER Collaboration Agreement Page 39 of 75

FIELD TRIAL AGREEMENT (Non transgenic. No payment. Academic.)

1. THE PARTIES
<!-- page 40 -->
This Agreement is made effective on [date] ("Effective Date") by and between [Ceres, Inc., a
Delaware corporation with principal offices at 1535 Rancho Conejo Blvd., Thousand Oaks, CA 91320,
United States of America] or [Institute of Grassland and Environmental Research, a company limited
by guarantee, registered in England No. 473456 and a registered Charity No. 272150, having an office
at Plas Gogerddan, Aberystwyth, Ceredigion, SY23 3EB, United Kingdom] hereinafter "[CERES/IGER],"
and [Party information to be completed], hereinafter "[Party]."

WHEREAS, [CERES/IGER] wishes to obtain information from field trialing certain CERES/IGER plant
material;

WHEREAS, [Party] wishes to include CERES/IGER's plant material in field trials in consideration of
its scientific interest in the observations to be made in such trials and the right to publish
certain observations, all subject to the terms and conditions of this Agreement;

[or other introduction as appropriate]

NOW THEREFORE, for and in consideration of the covenants, conditions and undertakings hereinafter
set forth, [CERES/IGER] and [Party] hereby agree as follows:

2. FIELD TRIAL PROGRAM

2.1 [CERES/IGER] will deliver to [Party] seeds or other propagating material as described in ANNEX I
and related information (jointly referred to as the "CERES/IGER Plant Material"). The delivery
conditions are set forth in ANNEX I. Promptly upon receipt of the CERES/IGER Plant Material, Party
will sign and return the Receipt Form, in the preferred format attached as ANNEX II to this
Agreement, to [CERES/IGER] (attn: [responsible person at CERES/IGER]).

2.2 [Party] agrees to perform the activities defined in ANNEX I which shall be referred to
hereinafter as the "Program." With reasonable notice [CERES/IGER] may change the activities to be
performed in the Program. If such changes do not result in additional work to be performed by
[Party], but consist for example of changes in experimental design or in observations to be made or
in information to be included in reports, they shall be set forth in a written document provided by
[CERES/IGER] to [Party] which will be attached to ANNEX I and form part of it. If such changes
result in additional work to be performed by [Party], they shall be set forth in an amendment to
this Agreement signed by both Parties. [CERES/IGER] will consider any suggestions for changes in the
Program which [Party] may suggest.

2.3 In performing the Program activities [Party] undertakes to comply with the work plan and time
schedule set forth in ANNEX I. CERES-IGER Collaboration Agreement Page 40 of 75
<!-- page 41 -->
2.4 [Party] undertakes only to use the CERES/IGER Plant Material or any part, progeny or seeds
thereof for performing the Program activities to be carried out under the Program and not for any
other purpose. Specifically, but without limitation, [Party] shall not use the Plant Material or any
progeny, plants, parts of plants, plant material, seeds or products derived therefrom in any form of
reselection, breeding, sexual crossing, seed production, back crossing, tissue culturing,
mutagenesis, genetic transformation or any biotechnological process, except as specifically approved
in this Agreement.

2.5 The CERES/IGER Plant Material will be used only on fields and at premises under the control of
[Party] and identified in ANNEX I.

2.6 Upon termination of the Program, [Party] will, at the option of [CERES/IGER], (i) allow
[CERES/IGER] to remove any Plant Material and any progeny, plants, plant material, seeds or products
obtained in the Program or (ii) destroy any remaining CERES/IGER Plant Material and any plants,
plant material and seeds obtained under the Program within fifteen (15) days from [CERES/IGER]'s
request to destroy, and will send [CERES/IGER] forthwith an attestation of such destruction.

2.7 Subject to giving at least one day's prior written notice in writing or by email to [Party],
[CERES/IGER] and [CERES/IGER] invitees will have the right to visit the fields where Program
activities are being conducted at any time, to make observations and to collect samples.

3. REPORTS

3.1 [Party] shall send [CERES/IGER] detailed written reports on the implementation of the Program
activities and the observations made and results obtained during the implementation of the Program.
The frequency of the reports and the type of information to be included in same is set forth in
ANNEX I.

3.2 During the entire Program, [Party] will promptly communicate to [CERES/IGER] any information on
the Program activities or the results obtained or observed that [CERES/IGER] may ask. Between
reports, [Party] will also spontaneously communicate to [CERES/IGER] any unexpected observations or
results.

4. REMUNERATION. PAYMENT

No remuneration will be due.

5. OWNERSHIP. INTELLECTUAL PROPERTY RIGHTS. EXPLOITATION

5.1 This Agreement does not bring any change to the ownership and intellectual property rights
relating to the CERES/IGER Plant Material. [Party] acknowledges that the CERES/IGER Plant Material
may be covered by patents or patent applications of [CERES/IGER].

5.2 [CERES/IGER] will exclusively own any plants, parts of plants, plant material, seeds,
information, data, technology, or other findings or inventions resulting from the CERES-IGER
Collaboration Agreement Page 41 of 75
<!-- page 42 -->
Program that relate to the CERES/IGER Plant Material (hereinafter "Results"). [CERES/IGER] will have
the exclusive rights to protect any of the Results through patents or plant variety protection
rights or similar protection, and any intellectual property rights arising therefrom will belong
exclusively to [CERES/IGER]. In case [Party] has made or contributed to any invention forming part
of the Results, [Party] shall promptly inform [CERES/IGER] thereof in writing and shall assign its
rights and cause its employees and staff members to assign their rights in any such invention to
[CERES/IGER]. [Party] shall render such assistance as may be required for assigning any rights
[Party] inventors may have in such invention to [CERES/IGER] or [CERES/IGER]'s designee and for
protecting such invention, including but not limited to the signing of documents. Any inventor of
[Party] will be recognized in patent applications on an invention which is part of the Results in
accordance with [U.S./U.K. patent law].

5.3 [CERES/IGER] will have the exclusive right to commercialize any of the Results.

6. CONFIDENTIALITY. PUBLICATIONS.

6.1 [Party] will treat any and all information and material communicated or transferred to it by
[CERES/IGER] pursuant to this Agreement (including but not limited to the CERES/IGER Plant Material)
and any Results (including without limitation any progeny, plants, seeds, parts of plants, plant
material, or products obtained directly or indirectly from the Plant Material) as strictly
confidential and will not use the same for any purpose other than as expressly allowed by this
Agreement nor disclose or transfer the same to any third party other than its employees or staff
members necessary to carry out the Program and bound by appropriate secrecy and non-use undertakings
consistent with [Party's] obligations under this Agreement.

6.2 [Party] shall take all precautions to prevent theft or pilferage of the Plant Material and any
progeny, plants, seeds, parts of plants or plant material obtained directly or indirectly from the
Plant Material.

6.3 [Party] will not grant access to any field where Plant Material or any progeny, plants, seeds,
parts of plants or plant material obtained directly or indirectly from the Plant Material can be
viewed to any third party except with the prior written permission of [CERES/IGER].

6.4 "Publication" and "Publish" shall include any discussion with or presentation to a third party,
other than parties referred to in Article 6.1. Examples of Publications include, without limitation:
presentation at a conference, submission for publication to a journal, submission of joint
proposals, posting information on a website, posters, abstracts, Ph.D. dissertations, and informal
oral discussions. Subject to [CERES/IGER]'s prior written approval, which will not unreasonably be
withheld, [Party] may proceed to Publication of selected Results provided that: (i) no confidential
information of [CERES/IGER] is revealed thereby, (ii) [Party] shall take into account any
suggestions which may be formulated by [CERES/IGER], and (iii) at least thirty (30) days prior to
the submission to a publisher or presentation to any third party, [Party] CERES-IGER Collaboration
Agreement Page 42 of 75
<!-- page 43 -->
delivers copies of the proposed Publication to [CERES/IGER] for review. At [CERES/IGER]'s request,
[Party] shall, for a reasonable period up to ninety (90) days from initial delivery to [CERES/IGER],
delay revealing any patentable subject matter in the disclosure in order to permit the filing of
patent applications. In any Publication, the Parties shall consider joint authorship and acknowledge
the contributions and publications of the other as scientifically appropriate.

7. WARRANTIES. LIMITED LIABILITY

7.1 [Party] acknowledges that the CERES/IGER Plant Material is of an experimental nature and will
take all reasonable precautions to prevent any damage or injury by the CERES/IGER Plant Material and
any progeny, plants, parts of plants, plant material, seeds or products derived therefrom.

7.2 [Party] warrants that the CERES/IGER Plant Material will exclusively and restrictedly be used
under suitable containment conditions, and in accordance with all applicable regulations, and it
will not be used on human subjects. In addition, [Party] will strictly comply with any planting
distance, isolation and similar requirements set forth in ANNEX I. [Party] will obtain any
authorizations or permits or proceed to any notifications which may be required for the Program
activities, [Party] will inform [CERES/IGER] in writing, within thirty (30) days from the Effective
Date, of any such requirements and certify its compliance with same.

7.3 [CERES/IGER] declines any liability for any damage which may be caused by the CERES/IGER Plant
Material or the Program activities or Results to [Party] or any third party.

7.4 Neither Party shall be liable for indirect, special, remote, incidental or consequential damages
or loss of profit in connection with this Agreement or its implementation.

8. GENERAL CONDITIONS

8.1 Amendments: This Agreement, including its annexes, may only be amended by a written document
signed by duly authorized representatives of the Parties.

8.2 Ambiguities: In case of ambiguity between this Agreement and its annexes, the contents of the
agreement shall prevail.

8.3 Number of copies: This Agreement including its annexes is being made in two (2) copies, one for
each Party.

8.4 Assignment / Subcontracts: [CERES/IGER] has concluded this Agreement with [Party] in view of
[Party]'s specific qualifications and [Party] shall not have the right to assign any of its rights
or obligations under this Agreement nor to sub-contract any part of the Program activities to any
third party, except with the prior written approval of [CERES/IGER]. [CERES/IGER] has the right to
assign its rights and obligations under this Agreement to any third party. Further, [CERES/IGER] has
the right to CERES-IGER Collaboration Agreement Page 43 of 75
<!-- page 44 -->
Made in two (2) copies.

entrust the implementation of all or part of its obligations under this Agreement to any of its
affiliates.

8.5 Equitable Remedies: It is understood and agreed that money damages would not be a sufficient
remedy for any breach of this Agreement by [Party] and that [CERES/IGER] is entitled to equitable
relief, including injunction and specific performance, as a remedy for any such breach. Such
remedies shall not be deemed to be the exclusive remedies for a breach by [Party] of this Agreement
but shall be in addition to all other remedies available at law or equity to [CERES/IGER].

8.6 Governing Law / Jurisdiction: [to be completed]

9. DURATION

9.1 This Agreement will enter into force on the Effective Date and will remain in full force and
effect until the latest of the following dates: (i) the [third] anniversary of the Effective Date,
(ii) the date of delivery by [Party] of the last report provided for in this Agreement, or (iii) the
dates on which the last payment due by [CERES/IGER] pursuant to this Agreement is made.

9.2 Notwithstanding Article 9.3., [CERES/IGER] will have the right to terminate this Agreement
including the Program at any time with [three (3)] months' prior written notice.

9.3 Either Party will have the rights to terminate this Agreement unilaterally by registered letter
addressed to the other Party in case such other Party has committed a breach of any of its
obligations under this Agreement and has failed to remedy such breach within thirty (30) days from
the receipt of a registered letter specifying the breach.

9.4 The provisions of Articles 2.6, 5, 6, 7.3, 7.4, 8.5 and 8.6 will survive the expiration or
termination of this Agreement.

[Party] [Institute of Grassland and Environmental Research] or [Ceres, Inc.] By: By:

Name: Name:

Title: Title:

By: By:

Name: Name:

Title: Title:

CERES-IGER Collaboration Agreement Page 44 of 75
<!-- page 45 -->
ANNEX I

to the Field Trial Agreement between [CERES/IGER] and [Party]

PLANTING / MANAGEMENT PLAN FOR [CERES/IGER] MISCANTHUS EVALUATION TRIAL — [Party]

Trial Scope and Purpose:

1. Planting Material

2. Program Activities

3. Content and timing of reports CERES-IGER Collaboration Agreement Page 45 of 75
<!-- page 46 -->
ANNEX II

to the Field Trial Agreement between [CERES/IGER] and [Party]

FORM OF RECEIPT FORM

Packing Slip and Receipt Form for material transferred pursuant to the Field Trial Agreement dated
[x] between [CERES/IGER] and [Party].

The undersigned [Party/[CERES/IGER]] signatory certifies that the material and related information
set forth hereinafter are included in the shipment with which this form is enclosed.

The undersigned [Party/[CERES/IGER]] signatory acknowledges having received in good order the
material and related information set forth hereinafter.

[Include description of material and related information.]

THIS MATERIAL AND RELATED INFORMATION ARE TRANSFERRED ONLY FOR USE IN COMPLIANCE WITH THE ABOVE
MENTIONED FIELD TRIAL AGREEMENT. CONFIDENTIALITY OBLIGATIONS APPLY. For sending/receipt, For
receipt/sending, Signature: Signature:

Date: Date:

Name: Name: Title: Title: [CERES/IGER] [Party] CERES-IGER Collaboration Agreement Page 46 of 75
<!-- page 47 -->
Material Transfer Agreement — Biological Material for Research Purposes

You have requested that the Institute of Grassland & Environmental Research (IGER) provides you with
the Biological Material listed in the Schedule. In consideration of providing the Biological
Material, IGER asks you, and you agree, to observe the following conditions, for a period of ten
years from the date hereof:

To: Name: (the "Recipient") Organisation: ("the Recipient Institution") Address:

1. To use the Biological Material only for the purpose of academic research at the laboratories of
the Recipient and not in any collaboration with a third party. More specifically the Biological
Material will only be used for the following purpose:

[to be completed]

The Recipient will specifically but without limitation not use the Biological Material for the
following purposes:

Generation of plants for use in seed production to increase the volume of seed available; generation
of plants for use in any breeding or back crossing experiments; any tissue culture, mutagenesis,
genetic transformation or any biotechnological process, except if expressly defined as the purpose
of this Agreement.

The Biological Material will not be used for production of a commercial product, or for patent
purposes or for applications for plant variety rights.

2. Not to provide samples of the Biological Material or samples of material extracted from or
derived from the Biological Material or any technical information relating thereto, to third parties
without specific written permission from IGER. Samples may only be provided to members of your
immediate research team, who undertake to respect these conditions.

3. Not without IGER's prior written permission (which shall not be unreasonably refused) to disclose
to any third party or publish details of the Biological Material, its manufacture or use, or details
of any other material that could not have been made but for the Biological Material, or information
on results obtained through the use of the Biological Material and to acknowledge the source of the
Biological Material in any such publication for which permission is granted. The Recipient must
provide IGER any proposed publication at least thirty (30) days prior to submission. IGER will
review such proposed publication for the need of intellectual property protection and/or to identify
any inadvertent disclosure of proprietary information. If necessary, the Recipient agrees to (i)
delay publication by no more than sixty (60) days to enable the filing of an application for
intellectual property protection and/or (ii) remove any proprietary information identified by IGER.
CERES-IGER Collaboration Agreement Page 47 of 75
<!-- page 48 -->
The Schedule

[to be completed]

4. The Recipient acknowledges that the Biological Material and any material or information obtained
through the use thereof shall always remain the property of IGER. Upon completion of the research
activities defined herein, the Recipient shall, at the option of IGER, (i) return to IGER all unused
Biological Material supplied by IGER and all materials, regardless of type, produced from the
Biological Material or (ii) destroy all unused Biological Material supplied by IGER and all
materials, regardless of type, produced from the Biological Material.

5. The Recipient will not obtain, and will not attempt to obtain patent coverage on the Biological
Material or on any use of the Biological Material or on any other material or information that could
not have been made or obtained but for the Biological Material.

6. The Recipient agrees promptly to disclose to IGER all information relating to research performed
using the Biological Material and all information relating to any modifications or improvements of
the Biological Material or any material derived from the Biological Material. [specific reporting
obligations to be included]

7. The Recipient and Recipient Institution will use the Biological Material in compliance with all
applicable laws and regulations including current health and safety guidelines for work with
recombinant DNA (if applicable) and for transport of materials and protection of the environment.
The Recipient and Recipient Institution agree to waive all claims against IGER and to defend and
Indemnify IGER from all claims and damages asserted by third parties arising from the use, storage,
handling and disposal of the Biological material by the Recipient.

8. The Biological Material is experimental in nature and is provided without any warranties express
or implied, including any warranties of merchantability or fitness for any purpose.

9. IGER makes no representation that the use of the Biological Material will not infringe any patent
or other intellectual property right and the Recipient hereby indemnifies IGER from and against all
actions, claims, proceedings or demands which may be brought against IGER by third parties in
respect of the infringement of any intellectual property right arising out of the Recipient's'
exercising of its rights under this Agreement.

10. The Recipient shall ensure that its employees, officers and agents comply with the obligations
imposed upon the Recipient by this Agreement as if personally bound by such obligations.

CERES-IGER Collaboration Agreement Page 48 of 75
<!-- page 49 -->
Signed for and on behalf of IGER:

Signature:

Name: P.A. Fentem

Title: Institute Business Manager

Date:

Recipient Institution: Recipient:

Signature: Signature:

Name: Name:

Position: Date:

Date:

CERES-IGER Collaboration Agreement Page 49 of 75
<!-- page 50 -->
EXHIBIT D

to the Collaboration Agreement between IGER and CERES

EXTERNAL FUNDING

• Defra project NF0426 The genetic improvement of miscanthus for Biomass

1 April 2004 — 31 March 2009 — see EXHIBIT E

• Energy crops in the Atlantic space: Possibilities for large scale implementation Interreg IIIB
Atlantic Area

1 January 2004 — 31 December 2007 — see EXHIBIT E

• Supergen — Biomass, Biofuels and Energy Crops Consortium

1 April 2003 — 31 March 2007 — see EXHIBIT E

• BBSRC project: Optimising the development of the energy grass Miscanthus through manipulation of
flowering time

1 April 2007 — 31 March 2011 — see EXHIBIT E CERES-IGER Collaboration Agreement Page 50 of 75
<!-- page 51 -->
EXHIBIT E

to the Collaboration Agreement between IGER and CERES

EXISTING AGREEMENTS

Title: Defra project NF 0426 'The genetic improvement of miscanthus for biomass'

Duration: 1/4/04 — 31/3/09

Partners: PRI

Scope and roles of partners

Material and information provided and to be provided by IGER: Provision of reports on results to
Defra.

Rights of IGER and PRI on results: IP owned by Defra but now being assigned to IGER. Rights to use
of results by PRI not specified in contract.

Rights of third parties on any IGER background material/information

IGER materials from China subject to rights of GAGE in royalty sharing and in access for research
purposes.

Any exclusivity/non competition

No

Any rights of third parties on results obtained by IGER

Rights of Tinplant with respect to materials developed using their germplasm. NOTE: any future use
of Tinplant germplasm for breeding purposes will be subject to mutual agreement of IGER and CERES.

1. Assessment of genetic resources available in UK and elsewhere for yield, canopy development,
flowering time (IGER) overwintering and combustion quality (PRI)

2. Hybridisation and selection based on general and specific combining ability of diploid accessions
(IGER, PRI)

3. Hybridisation of diploid and tetraploid accessions to produce new sterile triploid hybrids (IGER)

4. Improvement of breeding efficiency based on early morpho-physiological prediction of productivity
and persistence and indirect measurement of chemical composition (IGER)

5. The production of large trait mapping populations and identification of a realistic cost
effective road map to more efficient breeding through the development of marker-assisted selection
(IGER,PRI)

6. Identification with Defra of the exploitation route in UK and Europe taking into account
expertise in large scale production and marketing (IGER,PRI)

CERES-IGER Collaboration Agreement Page 51 of 75
<!-- page 52 -->
Title: Energy crops in the Atlantic space: Possibilities for large scale implementation Interreg
IIIB Atlantic Area

Duration: 1/1/04 — 31/12/07

Partners and roles:

Instituto Superior de Agronomia (Portugal) Agronomy and harvesting of Cynara, Arundo, Sorghum

Associacao de Prudutores Florestias (Portugal) Agronomy, harvesting and conversion of Cynara, Arundo
and Sorghum

Universidade de Evora (Portugal) Agronomy, harvesting of Cynara, Sorghum

Instituto Nacional de Engenharia, Tecnologia e Invacao (Portugal) Gasification and combustion of
Cynara, Arunda, Sorghum

Associacao Florestal da Galizia (Spain) Agronomy, combustion analysis and alcohol production from
Cynara, Arunda, Sorghum

Mid-South Roscommon Rural Development Company Ltd (Ireland) Identify and monitor farm performance of
biomass crops including miscanthus, reed canary grass, and willow.

IGER (UK) Agronomy and chemical composition analysis of miscanthus. Hybrid miscanthus trials.

Scope: Analysis of technical and economic aspects of installation of Cynara cardunculus, Arundo
donax, Sorghum bicolor and miscanthus in different regions. Conversion of biomass by burning and
through conversion to alcohol

Material and information provided and to be provided by IGER

Agronomy data, hybrid trial data, chemical composition data.

Rights of parties to results

All project results to be left 'free of all rights'

Rights of third parties on any Background

None

Any exclusivity/non competition

None

Rights of third parties on results obtained by IGR outside of agreement activities

None CERES-IGER Collaboration Agreement Page 52 of 75
<!-- page 53 -->
Title: Supergen — Biomass, Biofuels and Energy Crops Consortium

Duration: 1/4/03 — 31.3.07

Scope: Feedstock options and meeting criteria of fuel quality for willow, miscanthus, reed canary
grass and switch grass.

Conversion and energy generation — pyrrolysis and combustion Economics and market issues Integration
of fuel production, conversion and end use Environmental issues

Partners and roles

University of Leeds Combustion behaviour of buiomass

Aston University Mass pyrrolysis for biooil

University of Sheffield Modelling combustion processes

University of Ulster Techno-economics of combustion and pyrrolysis

Cranfield University Corrosion in combustion

University of Manchester Socio-economic analysis

Rothamsted Research Agronomy (fertilizer requirements) of reed canary grass, switch grass and
miscanthus

Alston Power Ltd Combustion

Bical Ltd Miscanthus agronomy

E.ON UK Ltd Combustion

Rural Regeneration Ltd Environmental impact CERES-IGER Collaboration Agreement Page 53 of 75
<!-- page 54 -->
IGER

Materials and information provided by IGER

Lolium, Dactylis and Festuca material. NIRS calibrations for lignin, ADF and NDF for miscanthus
(material sourced from European Miscanthus Initiative)

Rights of IGER and other parties on results

All parties own their own Resulting IP. Partners must make their Resulting IP available to other
partners for research purposes Subject to agreement on commercial terms partners grant each other
non-exclusive license to use their IP for commercial purposes A partner can not unreasonably refuse
access on reasonable terms to a second partner to its IP if access is necessary for that second
partner to commercialise its own IP

Rights to IGER Background

Partners may use IGER's Background for purposes of project and for internal research purposes IGER's
Background may be made available to another partner for commercial purposes subject to commercial
terms IGER's Background to be licensed on fair and reasonable terms when necessary for another
partner to commercially exploit its own Resulting IP.

Exclusivity/non competition

Should partners wish to exploit their own resulting IP with a third party (outside consortium)
during the duration of the project, that party must notify the other partners.

Ay rights of third parties/partners on results obtained outside of agreement activities

None CERES-IGER Collaboration Agreement Page 54 of 75
<!-- page 55 -->
Title: BBSRC project: Optimising the development of the energy grass Miscanthus through manipulation
of flowering time

Duration: 1/4/07 — 31/3/11

Scope: Identification of genes involved in flowering time of the two parents of Miscanthus X
giganteus

Roles of partners:

Materials and information provided and to be provided by IGER:

A range of miscanthus genotypes from Japan, China and Taiwan to be characterised at field sites at
IGER and Rothamsted. M siniensis mapping family will also be assessed at IGER and Rothamsted. IGER
mapping data will be made publicly available through a database which is part of the BBSRC cross
institute programme on monocot genetics.

Rights of parties to results

Each party owns the IP on the results it produces

Rights of third parties to any background

Rights of GAGE to collection covered in GAGE agreement

Exclusivity/non competition

None

Rights of third parties on IGER results outside of agreement activities

None

IGER — Assessment of flowering time of miscanthus populations in the Field. Association of flowering
time and senescence QTL with miscanthus Genes. Identify miscanthus genes which are homologues of
Arabidopsis, maize and rice flowering genes. Build genetic maps around these genes and map flowering
time QTL

Rothamsted — Assessment of flowering times of miscanthus populations in the field

CERES-IGER Collaboration Agreement Page 55 of 75
<!-- page 56 -->
EXHIBIT F

to the Collaboration Agreement between IGER and CERES

PRODUCTION AND COMMERCIALIZATION ACTIVITIES

CERES will:

CERES shall provide to IGER a detailed, written annual report on its activities in furtherance of
the obligations of this EXHIBIT, such report shall be due at or about March 31 of each year. In
addition, upon the request of IGER at any time, CERES will discuss the progress and results achieved
in regard to such activities; provided however, such contacts and discussions shall be reasonable in
frequency and duration so as not to be disruptive to the respective operations of either Party.

1. Identify growers and establish grower contracts

2. Lease, build or buy production facility

3. Establish quality testing capability

4. Establish a sales force and distribution network and/or distribution through existing
distribution systems and/or establish any other commercialization system.

CERES-IGER Collaboration Agreement Page 56 of 75
<!-- page 57 -->
EXHIBIT G

to the Collaboration Agreement between IGER and CERES

MODEL LICENSE AGREEMENT FOR NON-TRANSGENIC VARIETIES / NON-UK

EXCLUSIVE LICENSE AGREEMENT FOR [VARIETY X]

THIS AGREEMENT is made this ___ day of _________, 20— ("Effective Date"), by and between INSTITUTE
OF GRASSLAND AND ENVIRONMENTAL RESEARCH ("IGER"), a company limited by guarantee, registered in
England No. 473456 and a registered Charity No. 272150, having an office at Plas Gogerddan,
Aberystwyth, Ceredigion, SY23 3EB, United Kingdom and CERES, INC. ("CERES"), a Delaware corporation,
having an office at 1535 Rancho Conejo Blvd., Thousand Oaks, California 91320, United States of
America.

WHEREAS, CERES and IGER entered into a COLLABORATION AGREEMENT, ("CA"), that contemplates a
long-term research relationship by and between the Parties for the enhancement and improvement of
COLLABORATION CROPS (as defined in the CA) for biomass crops;

WHEREAS, CERES and IGER have jointly developed and jointly own a new MISCANTHUS variety [X] pursuant
to SCHEDULE [1] to the CA;

WHEREAS, CERES wishes to commercialize MISCANTHUS variety [X];

WHEREAS, CERES has the ability to assume production of and to commercialize MISCANTHUS variety [X]
and wishes to receive an exclusive, world-wide license (except in the United Kingdom) to produce,
use, sell and commercially exploit MISCANTHUS variety [X];

WHEREAS, in accordance with the provisions of the CA concerning the commercialization of MISCANTHUS
varieties jointly developed and jointly owned by the Parties under the CA, the Parties have
developed this Agreement and its terms in accordance with the terms and obligations set forth in the
CA;

WHEREAS, CERES and IGER recognize that the rights intended to be granted hereunder can be a strong
incentive for CERES to risk money and other resources needed to produce, use, sell and commercially
exploit MISCANTHUS for wide public enjoyment;

NOW THEREFORE, in consideration of the premises and of the mutual covenants and agreements contained
herein and of other good and valuable consideration, the Parties have agreed and do hereby agree as
follows:

1.1 "MISCANTHUS" is defined as "COLLABORATION CROPS" in the CA, and such definition is incorporated
by reference herein.

1. DEFINITIONS.

CERES-IGER Collaboration Agreement Page 57 of 75
<!-- page 58 -->
1.2 "LICENSED VARIETY" shall mean the [NAME] MISCANTHUS variety jointly developed by the Parties
pursuant to SCHEDULE [1] to the CA and released, jointly by IGER and CERES, pursuant to the terms of
SCHEDULE [1].

1.3 "VARIETY RELEASE DATE" shall mean the date the LICENSED VARIETY was released pursuant to the
terms of SCHEDULE [1].

1.4 "TERRITORY" shall mean all countries of the world except the United Kingdom.

1.5 "COMMERCIAL PROPAGULE" shall mean [propagules — seed — reproductive material] of MISCANTHUS that
is sold for purposes other than the production of propagating material.

1.6 "INTELLECTUAL PROPERTY RIGHTS" shall mean all rights in any plant variety, patent, plant
breeders rights, registration or equivalent intellectual property protection, or any applications
thereof, for the LICENSED VARIETY, which may be filed in any jurisdiction in the TERRITORY, with the
exception of TRADEMARKS. INTELLECTUAL PROPERTY RIGHTS, when applied for or granted, will be set
forth in ANNEX I.

1.7 "JOINT INTELLECTUAL PROPERTY" is defined in the CA, and such definition is incorporated by
reference herein. Any and all JOINT INTELLECTUAL PROPERTY licensed under this Agreement shall be set
forth in ANNEX I.

1.8 "IGER INTELLECTUAL PROPERTY" is defined in the CA, and such definition is incorporated by
reference herein. Any and all IGER INTELLECTUAL PROPERTY licensed under this Agreement shall be set
forth in ANNEX I.

1.9 "OTHER RESEARCH RESULTS" is defined in the CA, and such definition is incorporated by reference
herein.

1.10 "BACKGROUND INTELLECTUAL PROPERTY" is defined in the CA, and such definition is incorporated by
reference herein. Any and all IGER BACKGROUND INTELLECTUAL PROPERTY licensed under this Agreement
shall be set forth in ANNEX I.

1.11 "TRADEMARK" shall mean any trademark, trade name or logo owned by CERES and intended for use
with a LICENSED VARIETY.

1.12 "COMMERCIAL NAME" shall mean the complete, preferred name of a LICENSED VARIETY under which a
specific LICENSED VARIETY will be marketed and sold.

1.13 "NET SALES" shall mean the actual wholesale price for COMMERCIAL PROPAGULES of the LICENSED
VARIETY received by CERES or any AFFILIATED COMPANY for the sale of such propagules, excluding
propagating material for further production of propagating material, less any (a) customary trade,
quantity, or cash discounts; (b) amounts repaid or credited by reason of rejection or return; (c)
any sales, use, tariff, customs duties, V.A.T. and/or other taxes, duties and similar governmental
assessments (except taxes based on income); (d) outbound transportation, shipping, packing, costs of
insurance in transit paid by CERES or an AFFILIATED COMPANY; and (e) cost of any coating materials
that may have been applied to the COMMERCIAL PROPAGULES. CERES-IGER Collaboration Agreement Page 58
of 75
<!-- page 59 -->
Where there is no identifiable sale price or when a LICENSED VARIETY is sold to other than bona
fide, arms length customers of CERES or any AFFILIATED COMPANY, CERES or the AFFILIATED COMPANY
shall be deemed to have received an amount of NET SALES calculated based on the final sale of the
COMMERCIAL PROPAGULES (wholesale level) to an independent third party, usually referred to as net
wholesale price payable by dealers. If no such current price is available, a hypothetical fair
market value price will be determined by the Parties jointly in good faith for the purpose of
calculating NET SALES. Further, TRAIT FEES, if any, shall be added to NET SALES.

1.14 "TRAIT FEE" shall mean any upfront or annual fee collected by CERES or any AFFILIATED COMPANY
in conjunction with NET SALES as an additional remuneration for the sale of COMMERCIAL PROPAGULES
that have a particular valuable non-transgenic trait or characteristic.

1.15 "LICENSE INCOME" shall mean the amount actually received by either CERES or any AFFILIATED
COMPANY in consideration for the grant of SUBLICENSES to SUBLICENSEES that are not AFFILIATED
COMPANIES to produce and sell COMMERCIAL PROPAGULES of the LICENSED VARIETY, including up-front
fees, lump sum payments and any running royalties on a product-by-product and jurisdiction-by-
jurisdiction basis.

*NOTE: definitions of NET SALES and LICENSE INCOME may vary in function of the business models that
may be developed

1.16 "AFFILIATED COMPANY" shall mean any company owned or controlled by, under common control with
or controlling CERES, "control" meaning in this context the direct or indirect ownership of more
than fifty percent (50%) of the voting stock/shares of a company, or the power to nominate at least
half of the directors.

1.17 "SUBLICENSE" shall mean any sublicense granted (a) by CERES to an AFFILIATED COMPANY or (b) by
CERES or an AFFILIATED COMPANY to any third party ("SUBLICENSEE"), as authorized by this Agreement,
to produce and sell a LICENSED VARIETY (or LICENSED VARIETIES).

1.18 "MARKETING PLAN" shall mean a detailed written plan for production, distribution, sale and
promotion of the LICENSED VARIETY prepared by or on behalf of CERES and submitted to IGER. Each
MARKETING PLAN shall include at least the information outlined in ANNEX II. Actual, adopted
MARKETING PLANS shall be attached as further annexes to this Agreement as adopted.

2. GRANT OF LICENSE.
2.1 IGER hereby grants CERES under IGER'S interest in any JOINT INTELLECTUAL PROPERTY and OTHER
RESEARCH RESULTS, the IGER INTELLECTUAL PROPERTY set forth in ANNEX I, and the IGER BACKGROUND
INTELLECTUAL PROPERTY set forth in ANNEX I:

(a) the exclusive right and license to produce COMMERCIAL PROPAGULES of the LICENSED VARIETY in the
TERRITORY, including intermediate propagation material; and CERES-IGER Collaboration Agreement Page
59 of 75
(b) the exclusive right and license to use, sell and commercially exploit the COMMERCIAL PROPAGULES
of the LICENSED VARIETY in the TERRITORY.
<!-- page 60 -->
2.2 Sublicenses. CERES shall have the right to grant SUBLICENSES within the TERRITORY provided that:

(a) The terms and obligations of any such SUBLICENSE shall be consistent with the terms and
obligations of this Agreement;

(b) CERES shall deliver to IGER (under an obligation of confidentiality) a written summary of each
SUBLICENSE agreement, which shall include the name and address of the SUBLICENSEE, scope of the
SUBLICENSE, exclusive/non-exclusive status, territory, remuneration, reporting and diligence
obligations, if any. This summary shall be provided within thirty (30) days after execution,
modification or termination of the summarized agreement; and

(c) CERES will use commercially reasonable efforts to collect any and all amounts due to CERES under
any SUBLICENSE for the sale of COMMERCIAL PROPAGULES of the LICENSED VARIETY.

2.3 Nothing in this Agreement shall be construed as conferring by implication, estoppel, or
otherwise any license or rights under any INTELLECTUAL PROPERTY RIGHTS, whether owned by IGER or
licensed to IGER, other than the one(s) expressly set forth in this Agreement.

3. INTELLECTUAL PROPERTY RIGHTS.

3.1 CERES will prepare and file, in accordance with its best judgment, any and all applications for
plant variety rights or other forms of intellectual property protection or variety registration for
the LICENSED VARIETY in the United States and/or Europe. Applications for plant variety rights shall
be filed in the joint names of CERES and IGER. At CERES' discretion, plant variety rights and/or
other forms of intellectual property protection may be filed in any other jurisdiction in the
TERRITORY.

3.2 If CERES intends to abandon any plant variety rights, pending or granted in any jurisdiction,
CERES shall first give sufficient written notice to IGER to permit IGER the opportunity to assume
such filing, examination and/or maintenance.

3.3 CERES and IGER will consult with regard to INTELLECTUAL PROPERTY RIGHTS.

3.4 The obligations of this Article 3.4 shall not apply to any jurisdictions in which CERES has
elected not to apply for intellectual property protection. CERES and IGER shall avoid carrying out
any act that would prejudice the grant of INTELLECTUAL PROPERTY RIGHTS. Without limitation, neither
Party shall make available reproductive material of the LICENSED VARIETY at a date or in a manner
that might jeopardize the right to seek INTELLECTUAL PROPERTY RIGHTS protection for the LICENSED
VARIETY. CERES, whether directly or through any SUBLICENSEE, shall not sell any propagules of the
LICENSED VARIETY until such time as the requirements for INTELLECTUAL PROPERTY RIGHTS have been
established.
CERES-IGER Collaboration Agreement Page 60 of 75
<!-- page 61 -->
3.5 CERES shall use all reasonable endeavors to ensure in any sales jurisdiction of the TERRITORY in
which INTELLECTUAL PROPERTY RIGHTS exist that all bags or containers supplied by CERES and any
SUBLICENSEE containing only propagules of such LICENSED VARIETY are clearly labeled to show that the
LICENSED VARIETY is protected by INTELLECTUAL PROPERTY RIGHTS.

4.1 In partial consideration for the rights granted in this Agreement, CERES shall be responsible
for any and all fees and expenses incurred in filing, examining, certifying and maintaining any
INTELLECTUAL PROPERTY RIGHTS for the LICENSED VARIETY, subject to the provisions of Article 3.

4.2 In partial consideration for the rights granted in this Agreement, CERES agrees to pay to IGER,
on behalf of CERES and any AFFILIATED COMPANY, for the LICENSED VARIETY, a royalty of:

Confidential Treatment Requested and the Redacted Material has been separately filed with the
Commission

4. LICENSED VARIETY CONSIDERATION.

4.2.1 on NET SALES

(a) [***] percent ([***]%) of NET SALES if the LICENSED VARIETY constitutes IGER INTELLECTUAL
PROPERTY, where the genotype exists before the Effective Date of the CA, no further breeding or
selection is required after the Effective Date of the CA, and the LICENSED VARIETY is propagated by
rhizomes;

(b) [***] percent ([***]%) of NET SALES if the LICENSED VARIETY constitutes IGER INTELLECTUAL
PROPERTY, in all cases not included in Article 4.2.1 (a); or

(c) [***] percent ([***]%) of NET SALES if the LICENSED VARIETY constitutes JOINT INTELLECTUAL
PROPERTY.

4.2.2 on LICENSE INCOME

(a) [x percentage to be determined in function of the business model] of LICENSE INCOME if the
LICENSED VARIETY constitutes IGER INTELLECTUAL PROPERTY, where the genotype exists before the
Effective Date of the CA, no further breeding or selection is required after the Effective Date of
the CA, and the LICENSED VARIETY is propagated by rhizomes;

(b) [[***] x%] of LICENSE INCOME if the LICENSED VARIETY constitutes IGER INTELLECTUAL PROPERTY, in
all cases not included in Article 4.2.2 (a); or

(c) [[***] x%] of LICENSE INCOME if the LICENSED VARIETY constitutes JOINT INTELLECTUAL PROPERTY.
CERES-IGER Collaboration Agreement Page 61 of 75
<!-- page 62 -->
4.3 In addition to the royalty provided in Article 4.2, CERES agrees to pay a royalty on NET SALES
of the LICENSED VARIETY equal to the royalty due, on the basis of the Convention on Biological
Diversity, by IGER to the country or countries where the material on which the LICENSED VARIETY is
based has been collected, up to a maximum of [***] percent ([***]%) of NET SALES, and an equivalent
additional royalty on LICENSE INCOME to be determined.

4.4 Where any royalty payments are subject to a withholding tax, CERES shall pay the net royalty and
shall provide to IGER proper certificates for such withholding tax.

4.5 All sums payable by CERES to IGER under this Agreement shall be payable in United States
dollars. Royalties shall be payable by March 31 of each year with respect to the NET SALES and
LICENSE INCOME received by CERES and any AFFILIATED COMPANIES in the preceding calendar year.
Payments shall be made by check to the following address:

Institute Secretary Institute of Grassland and Environmental Research Plas Gogerddan Aberystwyth
Ceredigion SY23 3EB United Kingdom

Such payments shall be accompanied by a written report setting forth the production volumes and
sales by CERES, and each SUBLICENSEE, of COMMERCIAL PROPAGULES during the calendar year, permitted
exclusions, NET SALES, LICENSE INCOME and the royalties due.

4.6 Payments required under this Agreement shall, if overdue, bear interest at a per annum rate of
one percent (1%) above the prime interest rate in effect on the due date, as reported in the Wall
Street Journal, from the date the payment is due until it is received.

5.1 The Parties acknowledge that the denomination for the subject variety is established as: [X].

5.2 CERES shall use the denomination of the LICENSED VARIETY to identify that variety.

5.3 CERES will determine a COMMERCIAL NAME for the LICENSED VARIETY under which the COMMERCIAL
PROPAGULES of the LICENSED VARIETY will be marketed and sold.

5.4 CERES may determine TRADEMARK(s) associated or intended for use with a LICENSED VARIETY. CERES
shall be the owner of all rights in any such TRADEMARK, chosen, applied to, used or registered in
association with the LICENSED VARIETY.

Confidential Treatment Requested and the Redacted Material has been filed separately field with the
Commission

5. DENOMINATIONS, VARIETY NAMES, TRADE MARKS.

CERES-IGER Collaboration Agreement Page 62 of 75
<!-- page 63 -->
6.1 CERES shall be responsible for multiplying propagating material of the LICENSED VARIETY within
the TERRITORY and using commercially reasonable efforts to produce, market and sell the resultant
COMMERCIAL PROPAGULES so as to ensure that COMMERCIAL PROPAGULES of the LICENSED VARIETY are
commercially available in the United States and/or Europe in reasonable quantities and at a
reasonable price no later than [X years — depends on propagation] from the Effective Date.

6.2 CERES shall meet its own cost of promotion, trials and listing of the LICENSED VARIETY in the
TERRITORY.

6.3 CERES shall use reasonable endeavors to ensure that all COMMERCIAL PROPAGULES of the LICENSED
VARIETY offered for sale by CERES, any AFFILIATED COMPANY or SUBLICENSEE shall meet the normally
accepted standards of the propagule trade or certifying authorities relating to propagule quality
within the relevant jurisdiction of the TERRITORY.

6.4 CERES shall at all times comply with and abide by any governing law, rules, regulations, plant
variety rights legislation or the like and/or requirements relating to the quality and sale of
COMMERCIAL PROPAGULES of the LICENSED VARIETY in the relevant jurisdictions of the TERRITORY and
shall use all reasonable commercial endeavors to obtain any necessary regulatory approvals for the
LICENSED VARIETY.

7.1 CERES will use commercially reasonable efforts to actively market the LICENSED VARIETY in the
United States, and in CERES' discretion, in other jurisdictions in the TERRITORY, wherein such
efforts shall be appropriately reflected in the MARKETING PLAN.

7.2 This provision shall apply after the third (3rd) anniversary of the market introduction of the
LICENSED VARIETY in the United States propagated by a method that results in the LICENSED VARIETY
being commercially competitive as compared to other energy crops being grown at that time in the
United States. If IGER identifies a bona fide third party who presents a sound commercialization
plan for the LICENSED VARIETY in a country or countries of the TERRITORY where the LICENSED VARIETY
is not commercially developed by or through CERES, or an AFFILIATED COMPANY ("COUNTRY"), IGER will
refer such opportunity to CERES by written notification and CERES will diligently investigate such
opportunity. No later than one (1) year after the aforementioned notification from IGER, CERES will
inform IGER in writing whether or not CERES wishes to commercialize the LICENSED VARIETY, directly
or indirectly, in the COUNTRY. If CERES declines the opportunity entirely, without REASONABLE
GROUNDS, IGER will be granted a non-exclusive license with the right to grant sublicenses to test,
produce and sell the LICENSED VARIETY in the COUNTRY. If CERES informs IGER in writing that CERES is
planning to commercialize the LICENSED VARIETY in all or part of the COUNTRY, directly or indirectly
(whether or not through the third party identified by IGER), and CERES has not taken reasonable
steps towards the implementation of such commercialization within two (2) years after so informing
IGER, unless CERES informs IGER of REASONABLE GROUNDS for its failure or delay

6. QUALITY AND PERFORMANCE REGULATIONS.

7. DILIGENCE.

CERES-IGER Collaboration Agreement Page 63 of 75
<!-- page 64 -->
to implement commercialization plans, IGER will be granted a non-exclusive license with the right to
grant sublicenses to test, produce and sell the LICENSED VARIETY in the COUNTRY.

"REASONABLE GROUNDS" shall mean any factors that a reasonable business person would view as too
negative to justify the market opportunity in the light of usual legal business practices in the
United States or Europe, including without limitation factors such as the risk that products will be
sold below a normal market price, the risk that dumping will occur, the risk of cannibalization of
other markets for the LICENSED VARIETY or of other products sold directly or indirectly by CERES,
poor intellectual property protection or enforcement, no propagation method which allows the
LICENSED VARIETY to be commercially competitive in that country, etc.

7.3 CERES shall submit to IGER with its annual report under Article 4.5 a report of progress made by
CERES (and any AFFILIATED COMPANY), directly or through its SUBLICENSEES, in achieving marketing
goals of previous years and meeting the objectives of the MARKETING PLAN submitted and agreed upon
for the TERRITORY. From time to time, but at least annually, CERES shall submit an amended and
updated MARKETING PLAN.

8.1 CERES shall keep and shall cause any SUBLICENSEE to keep accurate records of all production and
sales of COMMERCIAL PROPAGULES of the LICENSED VARIETY in each country of the TERRITORY where such
sales are made. These records will include, at least, the number of acres of LICENSED VARIETY
COMMERCIAL PROPAGULES under production, the physical location of the LICENSED VARIETY production
field owned or controlled by CERES, any AFFILIATED COMPANY or any SUBLICENSEE, the total amount of
LICENSED VARIETY COMMERCIAL PROPAGULES produced, the total amount of LICENSED VARIETY COMMERCIAL
PROPAGULES sold and all invoices or shipping documents relating to such sales.

8.2 CERES shall allow an independent auditor, reasonably acceptable to CERES, appointed by and paid
for by IGER to inspect the records of CERES and any AFFILIATED COMPANY pertaining to the LICENSED
VARIETY for the exclusive purpose of verifying the accuracy of the reports provided. Any such audit
shall occur no more frequently than annually. Any such inspection shall occur during normal business
hours and after IGER has provided written notice at least ten business days prior to the date of the
intended inspection. IGER agrees that it and its representatives will hold the information obtained
from the inspection in confidence, and not use it for any purpose other than verification of the
royalties required to be paid hereunder.

9.1 Each Party shall notify the other of any suspected infringement of any INTELLECTUAL PROPERTY
RIGHTS covering the LICENSED VARIETY. CERES will have the exclusive right, but no obligation, at its
own discretion and expense, to take any action to enforce and to initiate and prosecute suits for
infringement of the INTELLECTUAL PROPERTY RIGHTS. CERES and IGER will consult with each other upon a
course of action and enforcement strategy. CERES will be responsible for the conduct of any such
enforcement action, and IGER will reasonably cooperate with CERES to effect the enforcement action,
and if appropriate, determine a settlement position. CERES shall be responsible for retaining
counsel and shall promptly notify IGER following

8. BOOKS, RECORDS AND RIGHT OF AUDIT.

9. ABATEMENT OF INFRINGEMENT.

CERES-IGER Collaboration Agreement Page 64 of 75

retention of counsel, and IGER agrees to be represented by such counsel as may be required for any
enforcement action or settlement. For purposes of settlement, CERES shall be the contact with the
parties' counsel as well as the opposing party(ies) and shall have the right to enter into
settlements. CERES shall keep IGER advised as to all developments with respect to the enforcement
action and settlement discussions, which includes supplying to IGER copies of all papers received
and filed in sufficient time for IGER to comment thereon. IGER may attend any and all meetings with
the parties' counsel and the opposing side for settlement purposes. IGER agrees to voluntarily join
in any action brought by CERES as a party plaintiff/defendant, if necessary, at the expense of
CERES. If necessary, IGER agrees to enter into a joint defense agreement.
<!-- page 65 -->
9.2 Any damages received by the CERES as a result of an enforcement action of the INTELLECTUAL
PROPERTY RIGHTS, after deduction of all enforcement related costs incurred by CERES, shall be
considered as either NET SALES or LICENSE INCOME for the purpose of remuneration payments to IGER,
to whichever the damages are reasonably deemed equivalent.

10.1 As used in this Agreement, the term "Confidential Information" shall mean all
non-public-information received by one Party from the other in the framework of this Agreement.
Confidential Information can include, but is not limited to, information concerning the disclosing
Party's operations, research, processes, techniques, data, sales, marketing, promotion and other
activities.

10.2 From receipt to five (5) years after the disclosure of the relevant CONFIDENTIAL INFORMATION,
the receiving Party shall not use, except (a) for the benefit of the Parties' collaboration, or (b)
such use as is expressly allowed by this Agreement, and/or disclose any Confidential Information to
any third party without the prior written consent of the disclosing Party if the Confidential
Information was received from the other Party, or the prior written consent of both Parties if the
Confidential Information was generated during the performance of this Agreement, excepting that
information described in Article 10.3. Confidential Information shall only be made accessible to
each Party's employees on a need- to-know basis.

10.3 The receiving Party shall have no obligations of confidentiality for information that: can be
established through written evidence to be in the possession of the receiving Party prior to the
disclosure by the disclosing Party; is or becomes public knowledge through no fault of the
disclosing Party; is acquired from others not under an obligation of confidentiality to the
disclosing Party. In addition, CERES shall have the right to proceed to disclosures of Confidential
Information (a) as required to file for INTELLECTUAL PROPERTY RIGHTS or registration, (b) as
required to exercise its commercialization rights granted in or on the basis of this Agreement and
for related marketing activities, (c) as required by laws, rules or regulation or court ordering
such as, without limitation, SEC regulations, or (d) in CERES' reasonable judgment, to (potential)
investors and business partners.

Any notices required to be given or which shall be given under this Agreement shall be in writing
and delivered by overnight (trackable) courier addressed to the Parties as follows:

10. CONFIDENTIALITY.

11. NOTICES.

CERES-IGER Collaboration Agreement Page 65 of 75
<!-- page 66 -->
Vice President of Product Development cc: Legal Department Ceres, Inc. 1535 Ranch Conejo Blvd.
Thousand Oaks, California 91320 United States of America

Institute Business Manager OR for legal or financial notices: Institute Secretary Institute of
Grassland and Environmental Research Plas Gogerddan Aberystwyth Ceredigion SY23 3EB United Kingdom

Notices under this Agreement sent by overnight courier by one Party to the other Party at its above
address shall be deemed to have been given or made as of the date following the date so mailed.

12.1 THE PARTIES ACKNOWLEDGE AND AGREE THAT NEITHER PARTY HAS MADE ANY REPRESENTATIONS OR
WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO, WARRANTIES OF MERCHANTABILITY OR
FITNESS FOR A PARTICULAR PURPOSE.

12.2 IN NO EVENT SHALL EITHER PARTY BE HELD RESPONSIBLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL OR
CONSEQUENTIAL DAMAGES OR LOSS OF PROFIT ARISING OUT OF THE USE OF ANY INTELLECTUAL PROPERTY RIGHTS
COVERED BY THIS AGREEMENT, OR THE IMPLEMENTATION OF THIS AGREEMENT, EVEN IF SUCH PARTY IS ADVISED IN
ADVANCE OF THE POSSIBILITY OF SUCH DAMAGES.

12.3 Nothing in this Agreement shall be construed as:

12. DISCLAIMERS.

(a) a warranty or representation by either Party as to the validity or scope of any INTELLECTUAL
PROPERTY RIGHTS, patent rights or plant variety rights;

(b) a warranty or representation by either Party that anything made, used, sold or otherwise
disposed of pursuant to any license granted under this Agreement is or will be free from
infringement of patents of third parties;

(c) any obligations by either Party to bring or prosecute actions or suits against third parties for
patent infringement; and

(d) a grant by implication, estoppel, or otherwise of any licenses under any intellectual property
rights of IGER or other persons other than as provided in Article 2.1 hereof. CERES-IGER
Collaboration Agreement Page 66 of 75
<!-- page 67 -->
Excluding those acts directly attributable to the negligence or willful misconduct of IGER, CERES
agrees to indemnify, hold harmless and defend IGER, its trustees, officers, employees and agents and
the breeders (as named in the INTELLECTUAL PROPERTY RIGHTS, if any) against any and all liability
and/or damages with respect to any claims, suits, demands, judgments or causes arising out of (a)
the production, development, storage, sale or any other use of the LICENSED VARIETY propagules
and/or exercise of rights granted hereunder by CERES, its SUBLICENSEES, distributors, agents,
representatives or AFFILIATED COMPANIES; (b) the use by end-users and other third parties of
LICENSED VARIETY propagules; and/or (c) any representation, warranty or statement by CERES, its
SUBLICENSEES, distributors, agents, representatives or AFFILIATED COMPANIES, concerning IGER,
LICENSED VARIETY propagules or any INTELLECTUAL PROPERTY RIGHTS. In the event any such claims,
demands or actions are made, CERES shall defend IGER at CERES' sole expense by counsel selected by
CERES and reasonably acceptable to IGER. IGER shall promptly notify CERES, in writing, of any such
claims, suits or demands upon discovery and shall cooperate with CERES in the defense, provided that
CERES shall have the right to lead the defense including entering into any settlement. CERES will
keep IGER informed about the conduct of the defense and consult IGER regarding any settlement
proposals.

14.1 Neither Party shall publicize or disclose the terms of this Agreement without the prior written
approval of the other Party, subject to the same exceptions as set forth in Article 10.3(a) through
(d).

14.2 The Parties intend to issue joint press releases regarding this collaboration. Any such press
release and any press release by either Party will be subject to the prior written approval of both
Parties; provided however, that (i) CERES shall have the right to otherwise disclose information as
may be required in CERES' judgment to comply with SEC regulations or other laws, rules or
regulations governing disclosure of information and (ii) IGER shall have the right to otherwise
disclose information as may be required in IGER's judgment to comply with applicable regulations or
other laws, rules or regulations governing disclosure of information. Notwithstanding the unilateral
disclosure rights provided for in this article, the disclosing Party shall provide the other Party a
copy of any such unilateral disclosure preferably prior to its release.

15.1 All disputes, differences or questions arising out of or in connection with this Agreement, or
related to the alleged breach, termination, validity, interpretation or violation thereof, shall be
submitted for resolution to the Chief Executive Officer of CERES and the Director of IGER, who shall
convene, whether in person or otherwise, to resolve such dispute through negotiation in a timely
manner. Either Party may initiate a resolution procedure by providing written notice ("Dispute
Notice") to the other Party, and any such Dispute Notice must set forth the subject matter of the
dispute, difference or question. If the dispute remains unresolved sixty (60) days after the Dispute
Notice, either Party may initiate proceedings pursuant to Article 15.2.

13. INDEMNIFICATION.

14. PUBLICITY AND USE OF NAMES.

15. DISPUTE RESOLUTION AND APPLICABLE LAW.

CERES-IGER Collaboration Agreement Page 67 of 75
<!-- page 68 -->
15.2 Dispute Resolution and Arbitration. In the event of any dispute arising out of or in connection
with this Agreement, the Parties agree to submit the matter to settlement proceedings under the ICC
ADR Rules. If the dispute has not been settled pursuant to the said Rules within forty- five (45)
days following the filing of a Request for ADR or within such other period as the Parties may agree
in writing, such dispute shall be finally settled under the Rules of Arbitration of the
International Chamber of Commerce by three (3) arbitrators appointed in accordance with the said
Rules of Arbitration. The provisions set forth hereinafter shall apply to the arbitration
procedures, without prejudice to the ICC Rules of Arbitration.

15.2.1 Qualifications of Arbitrators. Each arbitrator appointed shall have a reputation as being
experienced in the legal and technical matters related to the dispute, shall be required to
disclose, among other disclosures, any prior involvement with the legal and technical matters
related to the dispute and any involvement with a competitor of any Party, and shall not be
presently nor in the past have been affiliated with any Party or a competitor of any Party.
Notwithstanding the method of their appointment, each arbitrator shall be required to meet the
standards contained in the Rules with respect to independence.

15.2.2 Location of the Arbitration. The seat of arbitration shall be Paris, France. The arbitrators
may hold hearings at such other locations as the arbitrators shall determine, after consultation
with the Parties.

15.2.3 Language of Arbitration. The arbitral proceedings and all pleadings and written evidence
shall be in the English language. Any written evidence originally in a language other than English
shall be submitted in English translation accompanied by the original or true copy thereof

15.2.4 Limitation on Remedies. The arbitrators are precluded from awarding punitive or exemplary
damages. In no event shall the arbitrators have the powers of an amiable compositeur.

15.3 Applicable law. This Agreement shall be governed by, and construed and interpreted in
accordance with, the laws of the State of New York without regard to the principles of conflicts of
law thereof.

16.1 Subject to any other rights of termination under this Article, this Agreement shall remain in
full force and effect until:

16. TERM AND TERMINATION.

(a) on a jurisdiction-by-jurisdiction basis, the expiration of the INTELLECTUAL PROPERTY RIGHTS in
the respective jurisdiction covering the LICENSED VARIETY; or

(b) in those jurisdictions in which the LICENSED VARIETY is sold but no INTELLECTUAL PROPERTY RIGHTS
are obtained, the tenth (10th) anniversary of the date of the first sale of a LICENSED VARIETY in
such jurisdiction. CERES-IGER Collaboration Agreement Page 68 of 75
<!-- page 69 -->
16.2 Each Party shall have the right to terminate this Agreement unilaterally by giving written
notice of termination to the other Party if such other Party fails to satisfy its material
obligations, which shall include but are not limited to, making required reports and making required
payments, under this Agreement, and such Party subsequently fails to cure such failure(s) within (a)
thirty (30) days for failures to remit payment for amounts due under this Agreement and (b) ninety
(90) days for all other obligations after receipt of written notice from the non-breaching Party
specifying such failure.

16.3 IGER will have the right to terminate this Agreement unilaterally with thirty (30) days'
written notice to CERES, (a) if CERES seeks protection under any bankruptcy, insolvency,
receivership, trust, deed, creditors arrangement or comparable proceeding or if any such proceeding
is instituted against CERES (and not dismissed within one hundred twenty (120) days) or (b) in case
of dissolution or winding up of CERES (excluding any situation where all or substantially all of
CERES' assets, stock or business to which this Agreement relates are acquired by a third party
(whether by sale, acquisition, merger, operation of law or otherwise)).

16.4 CERES may after consultation with IGER terminate this Agreement by written notice if in the
commercially reasonable opinion of CERES the markets for the LICENSED VARIETY change or do not
develop as anticipated, so as to render the production, promotion and sale of the LICENSED VARIETY
uneconomical or impractical or if CERES decides to cease substantially all activities in MISCANTHUS.

16.5 The Parties may terminate this Agreement at any time by mutual, written agreement.

16.6 Termination of this Agreement for any reason will not relieve either Party of any obligation or
liability accrued under this Agreement before termination or rescind any payments made or due before
termination. Articles 8, 10, 11, 12, 13, 14, 15, and 17 will survive any termination of this
Agreement.

16.7 Termination of this Agreement shall not affect the rights and obligations of the Parties
accrued prior to termination hereof.

16.8 Upon termination of this Agreement, no existing SUBLICENSES granted by CERES or AFFILIATED
COMPANIES to third parties shall be affected by such termination, and all such sublicenses shall
remain in effect according to their terms, pursuant to the election of each SUBLICENSEE. IGER shall
continue to be entitled to payments relating to such SUBLICENSES pursuant to this Agreement and such
SUBLICENSES.

16.9 Termination of this Agreement shall not prevent:

(a) IGER from recovering any royalties due as of termination; and

(b) either Party from obtaining a remedy for any breach of the provisions of this Agreement.
CERES-IGER Collaboration Agreement Page 69 of 75
<!-- page 70 -->
17.1 Entire Agreement/Modifications. This Agreement constitutes the entire agreement between the
Parties hereto with respect to the subject matter hereof, and there are no representations,
warranties, covenants or obligations except as set forth herein. This Agreement supersedes all prior
and contemporaneous agreements, understandings, negotiations and discussions, written or oral, of
the Parties hereto relating to the subject matter hereof. This Agreement may only be amended,
modified or superseded by a writing executed by the authorized representative of the Parties hereto.

17.2 Severability. This Agreement, to the greatest extent possible, shall be construed so as to give
validity to all of the provisions hereof. If any provision of this Agreement is or becomes invalid,
is ruled illegal by a court of competent jurisdiction or is deemed unenforceable under the current
applicable law from time to time in effect during the term of this Agreement, the remainder of this
Agreement will not be affected or impaired thereby and will continue to be construed to the maximum
extent permitted by law. In lieu of each provision which is invalid, illegal or unenforceable, there
will be substituted or added as part of this Agreement by mutual written agreement of the Parties, a
provision which will be as similar as possible, in economic and business objectives as intended by
the Parties to such invalid, illegal or unenforceable provision, but will be valid, legal and
enforceable.

17.3 Waiver. No failure or delay by either Party in exercising any right or remedy under this
Agreement will waive any provision of this Agreement. Nor will any single or partial exercise by
either Party of any right or remedy under this Agreement preclude it from otherwise or further
exercising any rights or remedies which it may have, or any other rights or remedies granted by any
law or any related document.

17.4 Enforcement. In the event an action is commenced by either Party against the other to enforce
any of the provisions of this Agreement, the prevailing Party shall be entitled to recover from the
other Party reasonable attorneys' fees, court costs and necessary disbursements incurred in
connection with such action.

17.5 Licensor-Licensee Relationship. The relationship of the Parties is that of independent
contractors and licensor-licensee. Nothing herein is intended or will be construed to establish any
agency, partnerships, or joint ventures. Neither Party has any authority to act for and/or to bind
the other Party in any way or to represent that either is in any way responsible for the acts of the
other, except as may be explicitly provided for herein or authorized by the non-acting Party in
writing. Neither Party is authorized or empowered to act as an agent for the other Party for any
purpose, nor shall either Party be bound by the acts or conduct of the other Party.

17.6 Assignablility. This Agreement binds and enures to the benefit of the Parties, their successor
or assigns, but may not be assigned by either Party without the prior written consent of the other
Party; provided however, CERES shall have the right to assign its rights and obligations under this
Agreement to any AFFILIATED COMPANY without such prior consent. Each Party shall have the right to
assign its rights and obligations under this Agreement to a third party in conjunction with the
transfer to such third party of substantially all of the assets of such Party associated with
performance under this Agreement without such prior consent.

17. GENERAL.

CERES-IGER Collaboration Agreement Page 70 of 75
<!-- page 71 -->
17.7 Force Majeure. No Party shall be responsible to the other Party for delay or failure in
performance of any the obligations imposed by this Agreement, provided such failure shall be
occasioned by fire, flood, explosion, lightning, wind storm, hailstorm, earthquake, subsidence of
soil, failure of machinery or equipment or supply of materials, discontinuity in the supply of
power, court order or governmental interference, terrorist attacks, civil commotion, riot, war,
strikes, labor disturbances, transportation difficulties, labor shortage, natural genetic variation
of any living matter or by any other cause of like or unlike nature beyond the reasonable control
and without fault or negligence of such Party.

IN WITNESS WHEREOF, IGER and CERES have caused this Agreement to be duly executed as indicated
below. INSTITUTE OF GRASSLAND AND ENVIRONMENTAL RESEARCH CERES, INC.

By: By:

Name: Name:

Title: Title:

Date: Date:

By: By:

Name: Name:

Title: Title:

Date: Date:

CERES-IGER Collaboration Agreement Page 71 of 75
<!-- page 72 -->
ANNEX I INTELLECTUAL PROPERTY

INTELLECTUAL PROPERTY RIGHTS for the LICENSED VARIETY

JOINT INTELLECTUAL PROPERTY

IGER INTELLECTUAL PROPERTY

IGER BACKGROUND INTELLECTUAL PROPERTY CERES-IGER Collaboration Agreement Page 72 of 75
<!-- page 73 -->
ANNEX II MARKETING PLAN (Article 1.18)

1. TIMING

The MARKETING PLAN is to cover a five year period and shall be reviewed annually with adjustments
made for further five year periods in line with market conditions (or projections of the same) and
the agronomic performance of the LICENSED VARIETY.

2. POSITIONING

An assessment of the potential of the LICENSED VARIETY in an identified market.

3. PROMOTION

Details of all project promotional activities, plus anticipated, related expenditures, that are
intended to the LICENSED VARIETY achieves its maximum market potential.

4. DISTRIBUTION

Details of the proposed distribution network and activities for supporting the distributor or
retailer plus anticipated promotion activities of the distributor/retailer. NOTE: If the anticipated
distribution network includes the creation of a new COMMERCIAL PROPAGULES company, details regarding
this important component should be included here.

5. EVALUATION

Details of planned evaluation and demonstration, if any.

6. PROTECTION

Anticipated intellectual property protection requirements.

7. COMMERCIAL PROPAGULES SALES

Estimated sales including grade of COMMERCIAL PROPAGULES, volume and price and country of
destination.

8. ROYALTY INCOME

a. Estimated royalty payments; and

b. Commencement date of payment.

9. COMMERCIAL PROPAGULES PRODUCTION

Estimated production, including grade of COMMERCIAL PROPAGULES, land area to be sown, estimated
production and harvest date. CERES-IGER Collaboration Agreement Page 73 of 75
<!-- page 74 -->
EXHIBIT H

to the Collaboration Agreement between IGER and CERES

CERTAIN REMUNERATION PRINCIPLES

1. If CERES uses germplasm that is IGER INTELLECTUAL PROPERTY or IGER BACKGROUND INTELLECTUAL
PROPERTY or JOINT INTELLECTUAL PROPERTY to develop varieties of the COLLABORATION CROP outside the
RESEARCH PROJECTS, the following guiding principles will apply to determine the remuneration due to
IGER by CERES upon commercialization of such varieties:

1.1 Royalty on NET SALES (defined as in EXHIBIT H) of varieties resulting from crosses of IGER
INTELLECTUAL PROPERTY or IGER BACKGROUND INTELLECTUAL PROPERTY germplasm with CERES or third party
or public germplasm:

1.1.1 if the variety contains equal to or less than one hundred percent (100%) but more than
seventy-five percent (75%) of IGER INTELLECTUAL PROPERTY or IGER BACKGROUND INTELLECTUAL PROPERTY
germplasm where said germplasm's genotype exists before the Effective Date of the CA, no further
breeding or selection is done in any RESEARCH PROJECT and the variety is commercialized by rhizomes:
[***] percent ([***]%)

1.1.2 if the variety contains equal to or less than one hundred percent (100%) but more than
seventy-five percent (75%) of IGER INTELLECTUAL PROPERTY or IGER BACKGROUND INTELLECTUAL PROPERTY
germplasm in all cases not included in 1.1.1: [***] percent ([***]%)

1.1.3 if the variety contains equal to or less than one hundred percent (100%) but more than
seventy-five percent (75%) of JOINT INTELLECTUAL PROPERTY germplasm: [***] percent ([***]%)

1.1.4 if the variety contains equal to or less than seventy-five percent (75%) but more than
twenty-five percent (25%) of IGER INTELLECTUAL PROPERTY or IGER BACKGROUND INTELLECTUAL PROPERTY
germplasm: [***] percent ([***]%)

1.1.5 if the variety contains equal to or less than seventy-five percent (75%) but more than
twenty-five percent (25%) of JOINT INTELLECTUAL PROPERTY germplasm: [***] percent ([***]%)

1.1.6 if the variety contains twenty-five percent (25%) or less IGER INTELLECTUAL PROPERTY or IGER
BACKGROUND INTELLECTUAL PROPERTY or JOINT INTELLECTUAL PROPERTY germplasm, but contains one (1)
TRAIT that has been introduced through crossing from such germplasm: [***] percent ([***]%); if two
(2) or more TRAITS introduced through crossing from such germplasm: [***] percent ([***]%)

Confidential Treatment Requested and the Redacted Material has been separately filed with the
Commission

CERES-IGER Collaboration Agreement Page 74 of 75
<!-- page 75 -->
1.1.7 in cases other than 1.1.1 through 1.1.6 no remuneration will be due (except if clause 2
hereinafter applies).

2. If CERES uses IGER INTELLECTUAL PROPERTY or JOINT INTELLECTUAL PROPERTY other than germplasm to
develop a product, a fair and reasonable remuneration will be due by CERES to IGER, taking into
account the relative contributions of the Parties to the research, development, production,
marketing and sales of the product. Upon CERES' request, the Parties will negotiate diligently and
in good faith to determine such remuneration for one or more particular inventions or products.

3. Duration of royalty payments will be similar to what is provided in the model license agreement
for non-transgenic varieties (non-UK) in EXHIBIT G.

"TRAIT" shall mean a valuable characteristic of a plant selected by CERES (e.g. drought tolerance,
specific flowering time) where at least seventy percent (70%) of such characteristic is associated
with no more than two (2) identified markers.

1.2 Royalty on LICENSE INCOME (defined as in EXHIBIT H) — to be determined in function of business
model.

CERES-IGER Collaboration Agreement Page 75 of 75
<!-- page 76 -->
AMENDMENT I

to the Collaboration Agreement effective as of April 1, 2007 between Institute of Grassland and
Environmental Research ("IGER") and Ceres, Inc. ("CERES") (the "Agreement").

Made in two (2) copies.

Page 1 of 1

1. The Parties agree to replace "sixty (60) days" by "two hundred ten (210) days" in Article 14.1
(e) (v) of the Agreement.

2. The Parties agree that this Amendment I is effective as of June 1, 2007.

3. For the remainder, the Agreement remains unchanged and this Amendment I shall form an integral
part thereof.

INSTITUTE OF GRASSLAND AND ENVIRONMENTAL RESEARCH CERES, INC. By: /s/ MERVYN HUMPHREYS By: /s/
RICHARD FLAVELL Name:

Professor Mervyn Humphreys Name:

Richard Flavell, CBE, FRS Title: Director Title: Chief Scientific Officer By: /s/ RICHARD HAMILTON
Name:

Richard Hamilton Title: President and Chief Executive Officer

AMENDMENT II

to the Collaboration Agreement effective as of April 1, 2007 between the Institute of Grassland and
Environmental Research ("IGER") and Ceres, Inc. ("CERES"), as amended (the "Agreement") and to
SCHEDULE 1 between the Institute of Grassland and Environmental Research ("IGER") and Ceres, Inc.
("CERES") and dated April 1, 2007, as amended ("Schedule 1").

WHEREAS, the Institute of Grassland and Environmental Research ("IGER") and CERES entered into the
Agreement and Schedule 1 on April 1, 2007;

WHEREAS, on April 1, 2008 IGER merged with Aberystwyth University Institutes of Biological Sciences
and Rural Sciences to form the new Institute of Biological, Environmental and Rural Sciences of
Aberystwyth University ("AU");

WHEREAS, as a consequence of such merger, the Parties wish to substitute AU in place of IGER as a
contract party to the Agreement;

WHEREAS, AU and CERES wish to amend the Agreement, as set forth hereinafter.

NOW THEREFORE, in consideration of the premises and of the mutual covenants and agreements contained
herein and of other good and valuable consideration, the Parties have agreed and do hereby agree as
follows:
<!-- page 77 -->
Page 1 of 2

Confidential Treatment Requested and the Redacted Material has been separately filed with the
Commission

1. The Parties agree that Aberystwyth University, a Higher Education Establishment registered in the
United Kingdom No. RC000641, having an office at Old College, King Street, Aberystwyth SY23 2AX
("AU") should be substituted as a contract party to the Agreement in place of IGER.

2. The Parties agree to amend Article 14.1 (e) (v) of the Agreement so as to read as follows:

"(v) with thirty (30) days' written notice to AU if Defra has not assigned to AU, or granted to AU a
license reasonably satisfactory to CERES on, the Intellectual Property vested in Defra or the Crown
or the Secretary of State pursuant to the DEFRA agreement NF 0426 within three (3) years from the
Effective Date (the "Assignment/License"); provided however that Ceres will not unreasonably refuse
to extend such three (3) year term by six (6) months if so requested by AU by December 31, 2009."

3. The Parties agree to add the following clause in Article 6 of Schedule 1:

"As long as the assignment or license grant by Defra to AU, and the corresponding grant of a license
or sublicense to CERES in compliance with the Agreement, has not occurred, CERES will have the right
to withhold [***]
<!-- page 78 -->
Made in two (2) copies.

Page 2 of 2

Confidential Treatment Requested and the Redacted Material has been separately filed with the
Commission

percent ([***]%) of the funding payable by CERES to AU pursuant to Attachment B — Budget, attached
to Schedule 1 (as this may be amended from time to time). CERES' rights to withhold such payments
will terminate:

(i) with respect to [***] percent ([***]%) of the funding, as of the date CERES effectively receives
a license or sublicense satisfactory to CERES on CERTAIN MISCANTHUS ACCESSIONS (defined in Article
3.2.1 b. of the Agreement) and related information.

(ii) with respect to [***] percent ([***]%) of the funding as of the date CERES effectively receives
a license or sublicense satisfactory to CERES on the Intellectual Property vested in Defra or the
Crown or the Secretary of State pursuant to the Defra agreement NF0426."

4. The Parties agree that this Amendment II is deemed to have become effective as of May 1, 2008.

5. For the remainder, the Agreement and Schedule 1 remain unchanged and this Amendment II shall form
an integral part thereof.

ABERYSTWYTH UNIVERSITY CERES, INC. By: Name: /s/ S.G.A. DURBIN

S.G.A. Durbin By: Name: /s/ RICHARD FLAVELL

Richard Flavell, CBE, FRS

Title: Director, Risk & Research Finance Title: Chief Scientific Officer

By: Name: /s/ RICHARD HAMILTON

Richard Hamilton

Title: President and Chief Executive Officer

Pages where confidential treatment has been requested are stamped 'Confidential Treatment Requested
and the Redacted Material has been separately filed with the Commission,' and the confidential
section has been marked as follows: [***].
<!-- page 79 -->
SCHEDULE 1—Plant Breeding, Markers, Composition, Agronomy and Propagation

THIS SCHEDULE is made this 1st day of April, 2007.

WHEREAS, CERES and IGER have entered into a Collaboration Agreement ("CA"), dated April 1, 2007,
which allows for the undertaking of RESEARCH PROJECTS pursuant to SCHEDULES, these terms being
defined in the CA; and

THEREFORE, the Parties have agreed to undertake the following RESEARCH PROJECT as defined herein on
the following terms and conditions:

GENERAL

RESEARCH PROJECT TITLE: Developing Miscanthus Cultivars for Use in Bioenergy Production

Development of Miscanthus Species for Energy Crops — Scientific Overview

Miscanthus species are capable of producing large quantities of biomass with minimal inputs over a
wide geographic range. CERES and IGER aim to develop commercial biomass crops from leading
Miscanthus lines via a collaboration with 2 major foci: I) propagation; and II) breeding. These are
described in turn below.

I. Propagation.

The major barrier to profitable Miscanthus cropping is efficient and inexpensive propagation. In the
UK, subsidy support makes [***] of Miscanthus x giganteus an economically viable planting method.
This is not the case in [***], where there is no government support for the crop and initial [***]
from which to generate planting material is extremely limited.

It is not commercially feasible to produce Miscanthus on a large scale in [***] from traditional
[***] schemes. Success of Miscanthus crops for large markets will be determined by development of

CERES-IGER SCHEDULE 1

Page 1 of 10

Confidential Treatment Requested and the Redacted Material has been separately filed with the
Commission

BETWEEN CERES, INC. ("CERES"), a Delaware corporation, having its principal place of business at
1535 Rancho Conejo Blvd., Thousand Oaks, CA 91320, United States of America, and

INSTITUTE OF GRASSLAND AND ENVIRONMENTAL RESEARCH ("IGER"), a company limited by guarantee,
registered in England No. 473456 and a registered Charity No. 272150, having an office at Plas
Gogerddan, Aberystwyth, Ceredigion, SY23 3EB, United Kingdom

A. Unless otherwise specified herein, the terms of the CA shall apply to this SCHEDULE.

B. In the event of any difference between the terms of this SCHEDULE and the CA, then the terms of
this SCHEDULE shall prevail.

I.A. Rationale:
<!-- page 80 -->
cost-effective propagation technology, and the magnitude of success depends on the speed with which
this technology can be developed.

All other lines of crop development research in this collaboration will be dependent on success with
propagation.

To be successful, Miscanthus must be planted from small, homogenous propagules that can be cheaply
and rapidly produced, flow-ably transported, stored for months and consistently emerge after
planting. In theory, the best propagule for Miscanthus production is seed. However, propagation of
Miscanthus from seed is complicated and difficult. Development of [***] Miscanthus varieties will be
a [***] of the [***] of this collaboration.

An alternative approach to seed in the short term is to [***] Miscanthus from [***] as is common in
[***]. [***] is more feasible with decreasing [***] and has not been thoroughly explored in Europe.
The potential of [***] should be investigated from both an applied and basic perspective. It was
agreed that while the approach is more likely to work in [***], it should also include x [***] and
at least initially [***].

Development of [***] and [***] techniques for [***] Miscanthus cropping systems will utilize a
combination of theoretical and applied methods in the lab, glasshouse and field.

CERES-IGER SCHEDULE 1

Page 2 of 10

Confidential Treatment Requested and the Redacted Material has been separately filed with the
Commission

I.B. Goal: Applied methods for effective [***] of Miscanthus hybrids.

I.B.i. Objective 1: Identify [***] techniques and optimize them with existing hybrids.

Methods: Screen [***], x [***] and other species at least initially for [***] ability with multiple
techniques in a broad range of factorial field and glasshouse experiments. Glasshouse experiments
can be conducted year-round at IGER and at CERES in Thousand Oaks, CA. Additional experiments may be
conducted at other CERES locations added at a later date. Field experiments will be conducted [***]
at IGER and begin in multiple locations in [***] during the three (3) year period of this SCHEDULE.

I.B.ii. Objective 2: More basic genetic and physiological work aimed at characterising and
understanding [***].

Methods: A series of experiments into the [***] of [***] with a focus on inducing plant growth from
[***] ([***] and [***]) [***]. Work should explore [***] cues ([***], [***], [***]) as well as [***]
([***]). Explore [***] and score in [***] if possible, to locate [***]. Evaluate candidate [***]
(from Arabidopsis, [***] if possible and other species) promoting [***] frequency.

I.C. Goal: Applied methods for effective [***] of Miscanthus hybrids.

I.C.i. Objective 1: Demonstrate potential of [***] and create protocols.

Methods: Check [***] of [***] and [***] of a wide range of [***] in response to [***] and [***] with
a combination of [***], glasshouse and finally field experiments. Interpret results in context of
[***] range, genotype and [***] conditions under which the [***] was [***]. Produce guidelines for
effective [***] and [***].

I.D. Goal: [***] based systems for rapid [***] of germplasm and plants to be used in [***].
<!-- page 81 -->
II. Breeding

Miscanthus is an unimproved plant species with great potential as an energy crop. [***] has not yet
been fully collected and characterized. Miscanthus species are capable of crossing with [***] — a
characteristic that has long been exploited in [***] where Miscanthus germplasm is used to [***].
The use of Miscanthus for biomass is a relatively new area, thus initial collection and evaluation
of germplasm may discover lines already suited to the commercial market, and will certainly provide
the base for the breeding needed to develop [***] into dedicated bioenergy crops. This breeding
programme will employ traditional methodology to [***] and [***] for traits of interest. Molecular
markers will be developed to assist identification of traits and expedite development of elite
lines. Major traits of interest include increased biomass production, altered composition for
improved conversion to fuel, [***] tolerance and seed suitable to produce [***] ([***]) [***].

As lines with commercial potential are identified they will be selected for direct field trialing at
IGER and/or at CERES locations in [***] to speed up commercial variety development.

CERES-IGER SCHEDULE 1

Page 3 of 10

Confidential Treatment Requested and the Redacted Material has been separately filed with the
Commission

I.D.i. Objective 1: Provide plants for [***] based [***].

Methods: [***] plants using clean systems for shipment to [***] in accordance with international
regulations.

I.D.ii. Objective 2: Investigate [***] in [***] of lines potentially useful in breeding, including
hybrids.

Methods: Evaluate the [***] capacity of breeding line candidates in response to standard or improved
[***] techniques.

I.D.iii. Objective 3: Develop estimates of time and cost required to [***] plants in [***] based
systems.

Methods: Conduct a desk study to compare the costs/benefits and barriers associated with large scale
[***] methodology including [***].

I.E. Goal: Proof of Concept field trials of research findings in target locations.

I.E.i. Objective 1: Evaluate and optimize propagation techniques under commercially relevant
conditions.

Methods: Use IGER and CERES infrastructure for field trialing methods in the UK and at multiple
locations in [***] and elsewhere. These should expand on research performed at IGER and test
genotype by environment interactions, with a focus on potentially commercial genotypes.

I.E.ii. Objective 2: Evaluate and optimize germplasm performance in the UK and in multiple [***].

Methods: Use IGER and CERES infrastructure for field trialing at multiple locations in the UK, [***]
and elsewhere. These should expand on research performed at IGER and test genotype by environment
interactions with a focus on potentially commercial genotypes.

II.A. Rationale:

II. B. Goal: A complete and documented Miscanthus [***].
<!-- page 82 -->
CERES-IGER SCHEDULE 1

Page 4 of 10

Confidential Treatment Requested and the Redacted Material has been separately filed with the
Commission

II.B.i. Objective 1: [***] to [***] in [***].

Methods: In accordance with international conventions, e.g., the Convention on Biodiversity (CBD),
[***] Miscanthus [***] from the [***] of [***]. Document the phenotype and growing [***], using
[***] to accurately record the [***]. [***] to [***] for [***] and subsequent phenotype
documentation.

II B.ii. Objective 2: Characterize full [***].

Methods: Document the morphological, physiological and [***] of interest in the [***] using
consistent phenotyping nomenclature and [***] compositional analysis. Develop molecular markers
associated with phenotypic traits.

II.B.iii. Objective 3: Assess relatedness of plants identified as useful parents for hybrids.

Methods: Use molecular markers developed for traits of interest in combination with germplasm
characterization data, particularly [***], to select parents with desired traits that are also
likely to present [***].

II.B.iv. Objective 4: Develop a dynamic warehouse to store data and develop systems to analyse data
and support multidisciplinary collaborative research.

Methods: IGER and CERES to consider best options for developing the database. Populate the database
with the [***] and [***] information [***]. As germplasm is characterized, integrate phenotype and
marker data and use to facilitate choice of promising [***] lines as well as inform the preparation
needed to ensure [***] (e.g. [***]). As data become available from other components of the
collaborative research, such as field trialing and conversion analysis, it will be added to the
database to allow PIs to synergistically design next step experiments.

II.C. Goal: Improved Miscanthus hybrids for commercial use.

II.C.i. Objective: Select improved parents.

Methods: [***] within [***] using information from molecular markers and composition analysis to
shorten and streamline the selection of parents. Cross between [***] and evaluate hybrids to
identify improved parents.

II.C.ii. Objective: Make crosses of selected [***] lines.

Methods: Appropriate germplasm will be selected for crossing using the database decision tool.
Plants will be [***] to [***] in glasshouses and [***] made both in the glasshouse and outdoors at
IGER, depending on time of year. Improve efficiency of [***] and, for [***], [***]. Determine [***]
— and [***]. Send seed of [***] candidates and [***] to CERES locations for trialing.

II.C. iii Objective: Selection of superior [***].

Methods: [***] will be transplanted to field. Important morpho-physiological traits will be recorded
over [***] years after which the best genotypes will be selected, [***] and [***] into rhizomes. The
value of early prediction of traits will be assessed. A mass selection reservoir (MSR) will be
maintained as a safety net and to contain interesting genotypes that do not justify commercial
development.
<!-- page 83 -->
CERES-IGER SCHEDULE 1

Page 5 of 10

Confidential Treatment Requested and the Redacted Material has been separately filed with the
Commission

II.C.iv. Objective: Field evaluation of hybrids.

Methods: From rhizomes taken in iii, replicated trials will be established. After [***] (or [***])
years, the best genotypes will be provided to CERES to test at diverse locations for commercially
relevant evaluation.

II D. Goal: Improved Miscanthus Varieties.

II.D.i. Objective: Explore new methods of breeding.

Methods: Set up and test [***] in terms of [***] and [***]. Set up and test [***] in terms of [***]
and [***] to determine whether [***] will be acceptable. The results will guide applications for the
setting up of Plant Breeders' Rights schemes.

3. RESEARCH AND DEVELOPMENT PLAN

The RESEARCH AND DEVELOPMENT PLAN (Attachment A to this SCHEDULE) contains:

• Research and evaluation activities to be performed by each Party in detail, including locations
for such activities

• Timelines of such activities

• Goals, expected results and deliverables

• Milestones and go/no-go decision points, if applicable

• FTEs

4. LOCATION OF WORK:

IGER Work:

IGER laboratory and glasshouse facilities and properties at its Welsh location and potential
subcontractor locations.

CERES Work:

Thousand Oaks, CA and potential subcontractor locations.

5. PHD LEVEL SCIENTIFIC STAFF:

Dr. John Clifton-Brown (IGER) Dr. Iain Donnison (IGER)

Dr. Richard Flavell (CERES) Dr. Bonnie Hames (CERES) Dr. Emily Heaton (CERES) Dr. Peter Mascia
(CERES) Dr. Steve Thomas (CERES)

The Parties agree to complete this list within three (3) months from the commencement date of this
SCHEDULE.
<!-- page 84 -->
CERES-IGER SCHEDULE 1

Page 6 of 10

Confidential Treatment Requested and the Redacted Material has been separately filed with the
Commission

6. FUNDING APPROVED:

See attached Budget (Attachment B).

7. REPORTS:

All reports shall be delivered to the MANAGEMENT COMMITTEE on or before the required delivery dates
for the same.

IGER and CERES will deliver at each quarterly MANAGEMENT COMMITTEE meeting (or annual meeting, as
the case may be):

• Quarterly status update and FTE breakout based on attached planning document.

• Actual spending relative to budget.

• INTELLECTUAL PROPERTY generated during the period.

• Copies of slide presentations summarizing research progress (template attached as Attachment C to
this SCHEDULE).

• Annual Report (compilation of slide presentations and quarterly minutes) (annual meeting).

Additional information, if not specifically included in the delivered information (above), shall be
delivered (or later provided, wherein the delivering Party shall indicate the delivery method and
time) as supporting information at the related quarterly meeting, if available:

• Breeding records.

• Copies of field or glasshouse books and records.

• Copies of raw field trial data.

• Biological material, including [***] lines from crosses and/or [***].

8. REPORT DATES:

Annual report: Due at annual meeting in January.

Quarterly reports and information: Due at quarterly meetings of the MANAGEMENT COMMITTEE per the CA
(e.g., April, July, October, January).

9. SUBCONTRACTORS AND LOCATIONS:

Actual locations and work at the locations will be decided by the MANAGEMENT COMMITTEE at the
quarterly meetings.

10. MAJOR CONSUMABLES TO BE PURCHASED:

None designated at the commencement date of this SCHEDULE.

11. ASSETS:
<!-- page 85 -->
CERES-IGER SCHEDULE 1

Page 7 of 10

Confidential Treatment Requested and the Redacted Material has been separately filed with the
Commission

Not applicable.

12. INSURANCE:

Not applicable.

13. INTELLECTUAL PROPERTY RIGHTS:

13.1 IGER Background Intellectual Property:

See Attachment D. The Parties agree that Attachment D will be worked out in more detail and
completed within thirty (30) days of the commencement date of this SCHEDULE.

13.2. CERES Background Intellectual Property:

• Molecular markers

• Genome sequence information

• [***]

• [***] information

• Proprietary software

14. USE AND COMMERCIALIZATION RIGHTS:

Controlled by CA. License agreements for non-transgenic varieties developed pursuant to this
SCHEDULE 1 will be based on the Model License Agreement for Non-transgenic Varieties in EXHIBIT G to
the CA.

15. CONFIDENTIALITY/PUBLICATION:

Controlled by CA.

16. COMMENCEMENT/TERM:

Commencement: April 1, 2007

Term: Three (3) years provided however, at least one (1) year before the end of the term of this
SCHEDULE, the Parties shall decide whether to extend it for one (1) or more years, with appropriate
updates to the RESEARCH AND DEVELOPMENT PLAN (Attachment A), and FUNDING (Article 6 of this
SCHEDULE).

17. PROVISIONS FOR EARLY TERMINATION:

This SCHEDULE does not terminate automatically upon termination of the CA.
<!-- page 86 -->
CERES-IGER SCHEDULE 1

Page 8 of 10

Confidential Treatment Requested and the Redacted Material has been separately filed with the
Commission

This SCHEDULE shall expire pursuant to the terms set forth in this SCHEDULE, unless extended by the
mutual agreement of the Parties, or unless sooner terminated in accordance with the following
provisions of this Article:

(a) mutual, written agreement of the Parties;

(b) failure of one Party to satisfy its material obligations under this SCHEDULE, and such Party
subsequently fails to cure such failure(s) within (i) thirty (30) days for failures to remit payment
for amounts due under this SCHEDULE and (ii) ninety (90) days for all other obligations in each case
after receipt of written notice from the non-breaching Party specifying such failure(s);

(c) one (1) year's written notice of termination by either CERES or IGER to the other Party in case
either the terminating Party or the other Party ceases substantially all activities in the
COLLABORATION CROPS;

(d) IGER will have the right to terminate this SCHEDULE unilaterally with thirty (30) days' written
notice to CERES, (i) if CERES seeks protection under any bankruptcy, insolvency, receivership,
trust, deed, creditors arrangement or comparable proceeding or if any such proceeding is instituted
against CERES (and not dismissed within one hundred twenty (120) days); (ii) in case of dissolution
or winding up of CERES (excluding any situation where all or substantially all of CERES' assets,
stock or business to which the CA relates are acquired by a third party (whether by sale,
acquisition, merger, operation of law or otherwise)); (iii) with written notice to CERES, if CERES
has failed in a substantial manner, three (3) years after either Party or the Parties jointly have
developed a [***] method for Miscanthus that results in the crop being commercially competitive in
the United States or in Europe as compared to other energy crops being grown at that time in the
relevant geography, to implement the activities set forth in EXHIBIT F to the CA, and does not
remedy such failure or offer a remediation plan which is reasonably acceptable to IGER within ninety
(90) days after receipt of a written notice from IGER specifying such failure;

(e) CERES will have the right to terminate this SCHEDULE unilaterally: (i) with thirty (30) days'
written notice to IGER if John Clifton-Brown or Iain Donnison cease(s) to be associated with IGER
and the research activities associated with this SCHEDULE, and IGER has not replaced such person(s)
within one hundred twenty (120) days by (a) person(s) reasonably acceptable to CERES; (ii) with
ninety (90) days' written notice to IGER, if the institutional mission, purpose, structure or
funding of IGER would change substantially and adversely affect IGER's ability to satisfy its
obligations hereunder; (iii) with one (1) years' written notice to IGER, if CERES has a documented
compelling business reason to cease the collaboration, (for example, without limitation, lack of
sufficient processing capacity for COLLABORATION CROPS within the expected timeframe in the United
States; COLLABORATION CROPS are non-competitive with other biomass sources); (iv) with three (3)
months' prior written notice to IGER, such notice to be given no earlier than eighteen (18) months
after the Effective Date of the CA, if no rights to commercialize (including determination of the
compensation due upon commercialization) COLLABORATION CROPS germplasm provided by IGER which is
included in the RESEARCH PROJECT covered by this SCHEDULE have been
<!-- page 87 -->
CERES-IGER SCHEDULE 1

Page 9 of 10

Confidential Treatment Requested and the Redacted Material has been separately filed with the
Commission

secured to CERES' reasonable satisfaction in compliance with the CBD; or (v) with thirty (30) days'
written notice to IGER if Defra has not assigned to IGER, or granted to IGER an exclusive license
reasonably satisfactory to CERES on, the Intellectual Property vested in Defra or the Crown or the
Secretary of State pursuant to the DEFRA agreement NF 0426 within sixty (60) days from the Effective
Date (the "Assignment/License"), provided however that such termination may be for the entirety of
this SCHEDULE or only for certain parts of the RESEARCH PROJECT covered by this SCHEDULE.

18. SPECIAL CONDITIONS:

18.1 VARIETY RELEASE

18.1.1 "RELEASE DATE" shall mean the date that CERES determines that a variety developed, tested and
evaluated pursuant to the terms of this SCHEDULE is ready for release, wherein upon such decision,
such variety will be formally released by IGER and CERES jointly (if the variety constitutes JOINT
INTELLECTUAL PROPERTY) or by IGER (if the variety constitutes IGER INTELLECTUAL PROPERTY) or by
CERES (if the variety constitutes CERES INTELLECTUAL PROPERTY).

18.1.2 For the purposes of this SCHEDULE, CERES, on advice of the breeder(s) of each variety via the
MANAGEMENT COMMITTEE, shall establish, in its sole discretion, an appropriate RELEASE DATE for such
varieties.

18.1.3 At or about the RELEASE DATE for a variety, CERES will determine a COMMERCIAL NAME for such
variety under which the seed of the same will be marketed and sold. "COMMERCIAL NAME" means the
complete, preferred name of a released variety under which it will be marketed and sold.

18.1.4 The Parties agree that the development of new varieties will not always result in varieties
that are commercially acceptable or releasable. Provided all Parties execute their respective
obligations under this SCHEDULE in an appropriate and reasonable manner, no one Party shall be
liable to the other for any refund or other recompense because no commercially acceptable new
variety is produced.

18.2 BBSRC project: Optimizing the development of the energy grass Miscanthus through manipulation
of the flowering time.

Reference to this project ("BBSRC grant") is included in EXHIBIT E to the CA.

The RESEARCH AND DEVELOPMENT PLAN in Attachment A hereto refers to certain activities to be
conducted by IGER pursuant to the BBSRC grant. The Parties expressly acknowledge and agree that:
<!-- page 88 -->
IN WITNESS THEREOF this SCHEDULE has been executed on the date hereinbefore entered.

CERES-IGER SCHEDULE 1

Page 10 of 10

(i) the results of such activities shall constitute IGER INTELLECTUAL PROPERTY, and

(ii) IGER may make certain data resulting from such activities publicly available in compliance with
the BBSRC grant.

INSTITUTE OF GRASSLAND AND ENVIRONMENTAL RESEARCH CERES, INC. By: /s/ M. Humphreys By: /s/ Richard
Flavell

Name: Professor Mervyn Humphreys Name: Richard Flavell, CBE, FRS Title: Director Title: Chief
Scientific Officer By: /s/ Richard Hamilton

Name: Richard Hamilton Title: President and Chief Executive Officer
<!-- page 89 -->
Attachment A - RESEARCH AND DEVELOPMENT PLAN Breeding Project Plan A B C D E F G H I J K L M N O P Q
R S T U V W X Y Z AA AB AC AD AE AF AG Ah 1 IGER Task Objective Comments year 1 year 2 year 3 2
Ceres FTE Ceres [***] IGER [***] FTE Ceres [***] IGER [***] FTE Ceres [***] 3 CIGER 1 2 3 4 5 6 7 8
9 10 11 12 1 2 3 4 5 6 7 8 9 10 11 12 1 2 3 4 4 1 [***] 5 IGER [***] 6

A

IGER

[***]

To capture important [***] to improve productivity and [***] (re [***] for climate change).
Particular [***] are geographical including [***] where [***]. [***] can demonstrate Google map
showing [***]

The earliest this could be done in Oct/Nov 20 [***]. It may be possible to continue to work with our
[***] of 20 [***]. Target countries are [***] (incl [***], [***] and [***]. EH would also like to
know about ethnobiology.

This needs to be included in the budget at £30- 40K.

7

B

IGER

[***]

Ensure these can be used without importation of disease outside [***]

[***] will be inspected in Sept [***] by DEFRA. I have contacted DEFRA about [***] import and await
a reply. [***] could be [***] in [***] to 1) fulfil [***] requirements 2) make a modest level of
multiplication so that [***] can be compared on different sides of the [***]. 8

IGER

Sample leaf material

Detailed genetic analysis

from 1 rep, extract DNA, using markers send to Ceres 9 Ceres SNPmarker analysis Evaluate material
for

markers, send results to IGER [***] [***] [***] 10

C

IGER

[***] and send subset of about [***] to [***] for further evaluation. Decide which lines Nov
20[***]. Also see [***] sheet.

Characterise morphological and physiological [***] relevant [***] in [***]

This obviously would link to the Trials worksheet. It is practical to start identifying key material
in 20[***] - which perhaps should be put [***]. 11 Ceres Evaluate [***] in [***]. 12

IGER

Identify G X E

Analyse if G has a [***]

Completion may be beyond

interactions and effect in [***] [***] year workplan

identify climatic zones 13 IGER Develop supporting I guess we mean the

techniques for phenotype

protocols, which I suggest

trials

we base on EMI. These can be

drawn up with statistical

advice ro test 30 genotypes

well in advance of the [***]

multiplication stage 14 C IGER [***] 15 IGER Dig samples of [***] key Test [***] to [***]

Miscanthus genotypes

from EMI plots, [***] and transfer to

Confidential Treatment Requested and the Redacted Material has been separately filed with the
Commission
<!-- page 90 -->
[***] 16 Ceres [***] in [***] Test [***] and [***] in [***] 17

D

CIGER JCB

WvA and

Obtain Commecialization Rights

Freedom to commercialize [***] developed in program 18 2 Characterise A) existing and B) new [***]
at

IGER C) selected [***] in [***] 19

A

IGER

Assess phenotype trial (planted at IGER in April [***]) for morphological and physiological [***]
relevant [***]. Include [***], [***] status etc in [***].

Record important morphometric characters including winter [***], spring [***], [***] to [***] spring
[***] and summer [***] (incl [***]), [***]/ [***], [***] and intensity, [***] and [***], [***],
[***], [***] and [***], visual assessment of [***]

Scoring systems need to be transferable. Bar code reading needs to be investigated.

This is the [***] year following [***] so the mature phenotype is ready for the 20 [***] season. It
should be repeated in 20[***] to check the impact of [***] in [***]

CERES-IGER SCHEDULE 1 April 1, 2007
<!-- page 91 -->
Attachment A - RESEARCH AND DEVELOPMENT PLAN Breeding Project Plan A B C D E F G H I J K L M N O P Q
R S T U V W X Y Z AA AB AC AD AE AF AG Ah AI AJ Ak Al AM AN AO 20 IGER Sample leaf material from 1
rep, extract DNA, send to Ceres

Detailed genetic analysis using markers

NB One sacc was received as four plants and may not be a clone

[***] [***] [***]

21 Ceres SNPmarker analysis Evaluate material for markers, send results to IGER

22 B IGER New phenotype trial to be [***] 20 [***] based on [***].NB [***] material will consist of
[***] plants per [***] derived from [***].

Characterise morphological and physiological [***] relevant [***]

We plan to follow the design of Phenotype Trial [***] above with the [***] at IGER. If [***] through
[***] works (we have started this), we may get this trial started in June [***]. However, it is also
likely planting will be delayed until May [***]. We could then include the [***] which should have
cleared [***].

23 3 [***] for [***]

24 CIGER Set [***] protocols for [***] analysis

Method harmonization for future [***] analysis

25 IGER Sample whole plant material harvested at [***], analyze using [***], send [***] to Ceres

More detailed [***] characterisation will reveal important [***]

Samples to be taken for 20 [***] spring harvest from [***] and [***] (this is earlier than ideal -
and should be repeated in 20 [***])

SuperGen funds work on [***] phenotype trial for [***], [***] and [***]. CERES will provide added
value to this (eg [***], [***], [***], [***], [***])

26 Ceres Obtain [***] and/or [***] Enable review of IGER [***]

27 Ceres Review [***] phenotype trial [***] and choose samples to analyze for [***] set

Choose subset of samples to analyze with [***] from [***] x [***] reps = ~ [***]

IGER will review as well as part of Supergen project. SuperGen will concentrate on combustion and
gasification.

28 IGER Send selected samples to Ceres for [***] analysis

Develop [***] sets at Ceres and IGER to harmonise [***] analysis

29 CIGER [***] analysis of samples for [***] of [***] models

Develop models of biomass [***] to harmonise Ceres/IGER [***] analysis

30 CIGER [***] analytical methods

Protocol development and harmonisation so that [***] data sent to Ceres can be translated to [***]
data as collected by Ceres.

IGER can perform some [***] based assays for which [***] already exist ([***], [***], and [***] for
calculation of [***] and [***]) or those being developed ([***] and [***]) however Ceres may wish to
perform additional analyses and there will be a need to standardise protocols and equipment between
sites at Aberystwyth and Thousand Oaks

[***] [***] [***]

31 Ceres send [***] results from [***] set to IGER

includes [***] results of the [***] set, the validation data for the [***] and the [***] of the
[***] samples in 05 phenotype trial (total [***] x [***])

Joint publication?

32 sample whole plant material, analyze using [***], send [***] to Ceres

More detailed [***] characterisation will reveal important [***]

33 Ceres Use developed model to determine [***] from [***]. Send results to IGER

Provide timely detailed information on [***] of phenotype trial [***]

May need additional samples to ensure accuracy/expand [***] set

34 CIGER Develop database and analytical tools to assist in making [***]

To assist [***] and recording of [***] data

We are currently developing the tools to integrate different types of datasets and to query them.

CERES and IGER to share inforamtion on this using both IT

Confidential Treatment Requested and the Redacted Material has been separately filed with the
Commission
<!-- page 92 -->
decisions parties. 35 4 [***] 36 a IGER Plan [***] programme according phenotypic, genotypic and
[***] data

Make useful [***] Use preliminary database as a decision support tool.

37 IGER Plant maintenance and

We prototyped large

set up including containers in 20[***]. These

staggering of plant lead to plants with more

development [***] - improving the [***].

CERES-IGER SCHEDULE 1 April 1, 2007
<!-- page 93 -->
Attachment A - RESEARCH AND DEVELOPMENT PLAN Breeding Project Plan A B C D E F G H I J K L M N O P Q
R S T U V W X Y Z AA AB AC AD AE AF AG AH AI AJ AK AL AM AN AO

38 IGER Carry out the [***] - a)

[***] additional [***] for CERES ([***]) Sub-samples of [***] (if available) protected by agreement
to be sent to Ceres to inform IGER selection. (Material from

[***] glasshouses

CIGER shall not be

used to create

CERES material.)

39 IGER b) [***] (outside)

40 IGER c) [***] (inside)

41 IGER Development of [***] a) [***] of [***]. With M. [***] this is easier. With M. [***] we have
now modified the [***] on the glass house to follow the [***] - [***]. 42 IGER b) detached [***] 43
IGER c) optimising [***] incl. [***] and [***] 44 IGER d) [***] with [***]

45 b IGER Carry out and optimise [***] Increase [***] of [***] from [***] Optimise media and [***].

46 IGER Make [***] x [***] Make [***] [***] with [***] and [***] (JML to help?)

47 IGER [***] from [***]. Obtain [***] for selection

phase. Determine [***]- and

[***] relationships [***] [***] [***]

48 5 IGER

Test alternative [***] A step in [***]

systems as proof of principle 49 IGER Plan [***] Produce [***] Make [***] in 20[***] using database
for [***] etc. Include [***] if possible in 20[***].

50 IGER Carry out [***] in The emphasis would be on

[***] chambers [***] genotypes but we would test several [***] of [***], [***] and [***].

51 CIGER Test [***], [***] and see [***] tab for methodology

[***] characteristics

52 CIGER [***] and/or [***] from Evaluate [***] in IGER and [***]

relevant [***] to [***]

53 CIGER Assess [***] in field Determine if [***] is Field scale phenotypic acceptable assessments
for above [***].

54 d IGER Create [***] Develop methods for large

scale [***] with [***] advantages 55 IGER Harvest [***]

56 CIGER [***] of [***] to [***] Evaluate [***] in IGER and [***]

57 CIGER

Assess phenotype in field Record important

morphometric characters as described in 2A i.

58 CIGER Evaluate [***] relative Determine levels of [***],

to [***] in field [***] of [***]

59 6 Selection from [***] To identify superior genotypes

60 IGER

Raise plants from [***] in Glasshouse Select best on basis of [***]

61 IGER Sample, extract DNA, Use marker analysis to aid [***]-[***] samples x

send to Ceres for marker selection [***]-[***] markers. analysis Throughput of [***] needs to be
confirmed. Include [***] trial, [***] x [***] material and [***] of all [***]. See marker section.

62 Ceres SNP marker analysis evaluate material for

markers, send results to IGER

63 IGER Transplant to field

64 IGER Raise plants from [***]. Select [***]. [***] MORE [***] TO BE [***].

Confidential Treatment Requested and the Redacted Material has been separately filed with the
Commission
<!-- page 94 -->
Also [***] to [***].

65 CIGER Assess phenotype Recaord important

morphometric characters

including winter [***],

spring [***], [***] to [***]

spring [***] and summer

[***] (incl [***]), [***]/

[***], [***] and intensity,

[***] and [***], [***],

[***], [***] and [***],

visual assessment of [***] [***] [***] [***]

CERES-IGER SCHEDULE 1 April 1, 2007

Confidential Treatment Requested and the Redacted Material has been separately filed with the
Commission
<!-- page 95 -->
Attachment A - RESEARCH AND DEVELOPMENT PLAN Breeding Project Plan A B C D E F G H I J K L M N O P Q
R S T U V W X Y Z AA AB AC AD AE AF AG AH AI AJ AK AL AM AN AO 66 IGER Sample whole plant More
detailed [***]

material, analyze using characterisation will reveal [***], send [***] to important [***] Ceres 67
IGER Select, [***] and [***] (or [***] This depends on the success of the early morphometirc

best genotypes for replicated trials. selection. If selections Interesting plants not after year
[***] are quite making the grade reliable reflection of the will be transferred to a mature
phenotype, then we mass selection could start this in 20[***] reservoir to continue - making plots.
montoring for [***]. 68 Ceres Use developed model to Provide timely detailed determine [***] from
information on [***] [***]. Send results to of [***]. IGER 69 7 [***] Trials NEED TO DETERMINE WHAT
IS

DONE OUTSIDE [***] PROGRAM Small plot yield assessments in replicated ([***] or [***]) single or
multiple rows ([***]) of [***] or [***] plants Promising lines to be [***]. per row, depending on To
test [***] on an area Connects to [***] and 70 IGER [***] on [***]. basis and scale up Trialling
project schedules 71 IGER After [***] years, the I suspect we will need help best genotypes will be
from [***] to multiply provided to [***] and promising plants for

UK for testing at [***] agronomic trials since [***] locations as part of is [***] only about [***]
[***] relevant [***] after [***] growing evaluation. seasons. [***] [***] [***] 72 IGER Evaluate
green cut of Miscanthus in terms of [***], [***] and [***] 73 IGER To investigate [***] Several
suitable [***] were not tested in 20[***] application. 74 IGER To investigate methods This is
practical issue and of preventing [***] at may be sorted by [***] or field borders (applies more
likely by [***] to M. [***]) 75 8 Project Management Telemeetings would be fine every quarter - with
an 76 Telemeetings annual visit. 77 Face to face meetings

78 Reporting based on these project plans [***] [***] [***]

CERES-IGER SCHEDULE 1 April 1, 2007

Confidential Treatment Requested and the Redacted Material has been separately filed with the
Commission
<!-- page 96 -->
Attachment A - RESEARCH AND DEVELOPMENT PLAN Marker Project Plan IGER CERES year 1 year 2 year 3
CIGER FTE Ceres [***] IGER [***] FTE FTE Ceres [***] IGER [***] FTE Ceres [***] IGER [***] 1 Marker
Development ( Year 1-) Objectives Notes 1 2 3 4 5 6 7 8 9 10 11 12 1 2 3 4 5 6 7 8 9 10 11 12 1 2 3
4 5 6 7 8 9 10 11 12 A

Identify target [***] for mapping including [***], [***], [***], [***], [***], [***], [***], [***]

B

Compare and share candidate gene sequences. Use [***] and proprietary gene databases to predict
Miscanthus variants of genes of interest.

C

Agree on joint list and determine long-term strategy including complementation of BBSRC funded work

D

Grow plants of [***] and mapping [***]. Take samples from [***]. DNA extractions to be made at IGER
using Autogen and sent to Ceres

a) [***] Planted April [***]; grow out in field [***]

[***]

[***]

[***] planted April [***]; sample, extract, send DNA to Ceres

b) ~[***] in November [***], timing dependent on [***]; grow plants in field

~[***] in November [***], timing dependent on [***]; sample, extract, send DNA to Ceres

c) [***] mapping [***] individuals, for [***]; grow plants in field

[***] mapping [***] individuals; sample, extract, send DNA to Ceres

d) [***] ([***]), for [***], [***],

[***] and [***]; grow plants in field

[***] ([***]; [***] + [***] plants);

sample, extract, send DNA to Ceres

e) [***] ([***]), for [***], [***];

grow plants in field

[***] ([***]; [***]); sample, extract, send DNA to Ceres

E

DNA to be used at IGER for AFLP analysis (a and b above)

determine [***] diversity and [***] structure

CERES-IGER SCHEDULE 1 April 1, 2007

Confidential Treatment Requested and the Redacted Material has been separately filed with the
Commission
<!-- page 97 -->
Attachment A - RESEARCH AND DEVELOPMENT PLAN Marker Project Plan IGER CERES year 1 year 2 year 3
CIGER FTE Ceres [***] IGER [***] FTE FTE Ceres [***] IGER [***] FTE Ceres [***] IGER [***] F

Define primers [[***] to be tested] for "[***]" carefully selected and agreed genes such that PCR
[***] can be sequenced and results unequivocally interpreted.

Develop markers for consensus genes

G

Evaluate polymorphisms in selected [***]. Assay ~[***] DNA samples from [***] in a) c) d) and e)
supplied by IGER to search for SNP polymorphisms in [***] genes using primers, PCR and Sequencing.
Define additional [***] (?)primers for genes that show insufficient polymorphisms in key materials

Evaluate polymorphisms in selected [***]. Assay ~[***] DNA samples from [***] in [***] supplied by
IGER to search for SNP polymorphisms in [***] genes using primers, PCR and Sequencing.

H Compare and share strategies for association mapping

I

Conduct association mapping with field phenotype data for a) Conduct association mapping with [***]
and field phenotype data for b)

[***]

[***]

[***]

J

DNA to be used at IGER for SSR analysis using primers from [***], [***] and [***] (BBSRC [***]
grant) ([***] and [***] from [***] and [***])

integration of [***] maps

K

Construct private and public [***] maps and associate marker polymorphisms with [***] in [***] and
mapping [***]. [***]

L

Review results, write-up in confidential reports and non- confidential papers and devise strategies
for implentation

2 Marker validation and implementation (Year 2-)

A

Phenotype mapping [***] for the target [***] selected in 1A (start in year [***] to enable early
morphometric analyses) and grown in 1D

B

Map [***] and relate to markers particularly those derived from candidate genes

CERES-IGER SCHEDULE 1 April 1, 2007

Confidential Treatment Requested and the Redacted Material has been separately filed with the
Commission
<!-- page 98 -->
Attachment A - RESEARCH AND DEVELOPMENT PLAN Marker Project Plan IGER CERES year 1 year 2 year 3
CIGER FTE Ceres [***] IGER [***] FTE FTE Ceres [***] IGER [***] FTE Ceres [***] IGER [***] 3 Develop
new mapping [***] of > [***] plants

A Agree on [***] for new mapping [***]

B Assess results of [***] for target [***]

C Grow and phenotype new mapping [***] for agreed [***]

D make maps from new [***] from mapping [***] d) and e)

4 Use markers 'routinely' in the [***] programme

A

Assess relatedness of plants as useful [***] in [***] program based on correlations with [***],
conclusions from Items 1-3 and [***] data and [***] in field

B IGER to extract DNA from [***] of [***] for marker analysis [***]

[***]

[***]

C

Assay all [***] from all [***] for a subset of markers ( [***]) based on results from Items1-3,
[***] required and [***] of plants in field. Aim is to discover if we can [***] many of the [***]
early on from marker work.

D

Compare performance of using markers on [***] of [***] from the [***] programme with [***] where no
markers are used

5

Functional analysis of target genes which map to [***] (from association or QTL mapping)

A Q -PCR using a range of [***] from selected genotypes

B [***] of Miscanthus with selected target genes which map to [***]

6

Development of BAC libraries (BBSRC)

Identification of [***] gene sequences and generation of a physical map

CERES-IGER SCHEDULE 1 April 1, 2007
<!-- page 99 -->
Attachment A - RESEARCH AND DEVELOPMENT PLAN Propagation Project Plan IGER Consultant year 1 year 2
year 3 Ceres CIGER FTE Ceres [***] IGER [***] FTE Ceres [***] IGER [***] FTE Ceres [***] Task
Objective Comment 1 2 3 4 5 6 7 8 9 10 11 12 1 2 3 4 5 6 7 8 9 10 11 12 1 2 3 4 5 1 [***] A Assess
[***] for [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***]
[***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***]
[***] [***]

Quantify [***] number and size by [***] individual [***] from

Assessing [***] and [***] in [***]

Investigate [***] conditions to dicipher G x E impacts on [***] [***] [***] [***] [***] [***] [***]
[***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***]
[***] [***] [***] [***] [***] [***] [***] [***] [***] [***]

a) in the 20[***] [***] Trial at IGER

Existing range of [***] in [***], [***]

Mature 20 [***]

[***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***]
[***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***]

b) 20[***] [***] as [***]

new range of [***] in [***], [***]

[***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***]
[***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***]

c) from 20[***] [***] in field / glasshouse at IGER

new range

[***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***]
[***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***]

d) on [***] ([***] and [***] from [***] to [***])

[***]

[***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***]
[***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***]
[***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***]
[***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***]

[***] to [***] number of [***] plants

Increase the identified promising genotypes for [***]

[***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***]
[***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***]
[***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***]
[***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] B

A series of field relevant experiments to guide Best Management Practices

Demonstrate potential of [***] and create protocols. Find [***] associated with [***]

[***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***]
[***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***]

[***] from all [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***]
[***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***]
[***] [***] [***]

Typically [***] from each [***] which are [***] in trays for raising [***] for field selection will
be monitored. We intend to datalog [***] (order for equipment in progress)

To screen all [***] for [***] and rate of [***] under monitored [***]

Year 1 data will be less detailed than in later years.

[***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***]
[***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***]

Greenhouse /CE experiments to investigate [***] best practice

to determine [***] in [***] under controlled [***] and optimise [***]

depends on a PhD student

[***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***]
[***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***]

Test [***] on [***] of selected genotypes

Characteristaion of [***] conditions to stimulate [***] in different genotypes. This provides
information about [***] where [***] could be considereds (based on [***]).

One can test [***] over [***] days of [***] genotypes (each in one lane) at [***] different [***]
([***] has [***] wells). [***] per [***] therefore we can only do this with genotypes that produce >
[***]. [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***]
[***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***]
[***]

Field bed preparation ([***]) at [***] (use [***] as a control)

scale up to real conditions including effect of [***] & [***]

[***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***]
[***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***]

Record [***] & [***]

relate laboratory tests to field conditions

[***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***]
[***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***]

Monitoring [***] + winter [***]

ensure proper quantification of conditions

[***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***]
[***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***]

CERES-IGER SCHEDULE 1 April 1, 2007
<!-- page 100 -->
Confidential Treatment Requested and the Redacted Material has been separately filed with the
Commission
<!-- page 101 -->
Attachment A - RESEARCH AND DEVELOPMENT PLAN Propagation Project Plan IGER Consultant year 1 year 2
year 3 Ceres CIGER FTE Ceres [***] IGER [***] FTE Ceres [***] IGER [***] FTE Ceres [***]

Development of [***] techniques

Precision [***] considerations. Optimising [***] and [***] at field scale.

[***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***]
[***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***]
[***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***]
[***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] 2
[***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***]
[***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***]
[***]

Establish [***] capacity of certain genotypes and protocols

Identify [***] amenable lines.

[***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***]
[***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***]

Send lines to external contractor for [***].

[***] promising [***] lines

[***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***]
[***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***]

Send [***] to Ceres

Provide [***] successfully produced in [***] program for additional

dependent on [***] success

[***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***]
[***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] 3

[***]

Demonstrate potential of [***] and create protocols. Explore timing of basic research to inform
applied work.

[***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***]
[***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] A
Applied [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***]
[***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***]
[***] [***]

visit global [***] experts

benefit from expertise and tie into the project ([***])

done during [***] trip to [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***]
[***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***]
[***] [***] [***] [***] [***]

[***] global experts visit IGER

benefit from expertise ([***])

[***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***]
[***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***]

Expert Consultancy ([***])

provide guidance for [***] projects, possibly advise student

[***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***]
[***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***]

gather information to develop field and glasshouse protocols

[***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***]
[***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***]

assess [***] in Miscanthus [***] characteristics of [***] and [***]

optimise [***], inform [***]

20[***] assessment will be include [***]. 20 [***]+ [***] will be [***] [***] [***] [***] [***]
[***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***]
[***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***]

treatments to [***], e.g. [***]

optimise [***]

[***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***]
[***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***]

Glasshouse tests of [***] growth conditions

to predict conditions in which [***] can be used

[***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***]
[***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***]

Field tests of [***]

survivorship of [***] plants and G by E interactions

[***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***]
[***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***]

Iterative field testing of [***] techniques

Evaluate field suitability of [***] techniques

[***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***]
[***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] B
Basic [***] Research [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***]
[***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***]
[***] [***] [***]

Assess [***] leading to [***] growth

develop articicial [***] of [***] growth and [***]

[***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***]
[***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***]

Assess [***] cues leading to [***] growth.

develop articicial [***] of [***] growth and [***]

[***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***]
[***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] 4
[***]/[***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***]
[***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***]
[***] [***] A [***] Lines, [***] lines [***] [***] [***] [***] [***] [***] [***] [***] [***] [***]
[***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***]
[***] [***] [***] [***] [***] [***]

Desk study of state of art in industry

[***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***]
[***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***]
Discuss with PM what could

Confidential Treatment Requested and the Redacted Material has been separately filed with the
Commission
<!-- page 102 -->
be done quickly to demonstrate feasibility [***] [***] [***] [***] [***] [***] [***] [***] [***]
[***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***]
[***] [***] [***] [***] [***] [***] [***]

CERES-IGER SCHEDULE 1 April 1, 2007
<!-- page 103 -->
Attachment B - Budget

* See page 2

Page 1

Confidential Treatment Requested and the Redacted Material has been separately filed with the
Commission

2007/8 2008/9 2009/10 No of Months 12.00 12.00 12.00 SALARY [***] [***] [***] NI [***]% [***] [***]
[***] super [***]% [***] [***] [***] PAY COSTS [***] [***] [***] OTHER RECURRENT CONSUMABLES [***]
[***] [***] CONSUMABLES MOLECULAR BIO [***] [***] [***] CASUAL & OVERTIME [***] [***] [***] TRAVEL &
SUBSISTENCE [***] [***] [***] STUDENTSHIP (PhD) [***] [***] [***] SUB- TOTAL [***] [***] [***] OTHER
COSTS ESTATES COST [***] [***] [***] RECRUITMENT [***] [***] [***] ANALYTICAL CHEMISTRY [***] [***]
[***] CONTROLLED ENVIRONMENT [***] [***] [***] BIOINFORMATICS [***] [***] [***] ULTRASTRUCTURE &
IMMUNOLOGY [***] [***] [***] MASS SPECTOMETRY [***] [***] [***] SEQUENCING [***] [***] [***]
EXTENSION TECHNOLOGIES [***] [***] [***] TRANSFORMATION TECHNOLOGIES [***] [***] [***] SEED STORE
[***] [***] [***] ROAD VEHICLES [***] [***] [***] AGRI VEHICLES [***] [***] [***] FARM [***] [***]
[***] GLASSHOUSE [***] [***] [***] SUB CONT [***] [***] [***] TOTAL OTHER COSTS [***] [***] [***]
OVERHEAD COSTS* ESTABLISHMENT SERVICES [***] [***] [***] ADMIN SERVICES [***] [***] [***] INSTITUTE
& SITE MANAGEMENT [***] [***] [***] FEC NOTIONAL INSURANCE [***] [***] [***] CAPITAL CHARGE [***]
[***] [***] DEPARTMENT [***] [***] [***] TOTAL OVERHEAD COSTS [***] [***] [***] TOTAL [***] [***]
[***] CERES payment for reasonable perf [***] [***] [***] CERES payment for full completion [***]
[***] [***] TOTAL paid by CERES [***] [***] [***] SURPLUS OVER TOC [***] [***] [***]

CERES-IGER SCHEDULE 1 April 1, 2007
<!-- page 104 -->
Attachment B — Budget

This Budget is agreed upon for contract years 1 through 3. A contract year ("Year") is April 1 —
March 31, starting April 1, 2007. CERES agrees to provide funding for IGER's RESEARCH PROJECT
activities covered by this SCHEDULE in accordance with Article 1.8 of the CA as set forth in the
Budget in page 1 of this Attachment B, taking into account what is provided hereinafter. Pay Costs,
Other Recurrent and Other Costs are as in the Budget. Overhead Costs will be payable as follows:

Page 2

Confidential Treatment Requested and the Redacted Material has been separately filed with the
Commission

- Each contract year CERES will pay [***]% of the overheads asked, (e.g. of the [***] pounds in Year
1), for the expected reasonable performance in the various aspects of the program Year by Year and
especially for all the items listed in the attached document. This [***]% amounts to [***] pounds in
contract Year 1.

- Furthermore, CERES will pay for Year 1 an additional [***]% of the asked overhead ( i.e.[***]% in
total of the asked overhead) for full completion of the Year 1 items A and B listed hereinafter.
This additional [***]% equals [***] pounds.

- For Year 2 CERES will pay an additional [***]% of the overhead costs asked for full and successful
completion of Year 2 items A and C hereinafter.

- For Year 3 CERES will pay an additional [***]% of the overhead costs asked for full and successful
completion of Year 3 items A, B, C and D listed hereinafter.

- The MANAGEMENT COMMITTEE will bring forth recommendations to the Parties at the beginning of each
Year for the items that IGER should satisfy to obtain extra overheads, outlined in the framework
above.

- Assessment on achievements of the nominated items will be made at the end of each Year by the
MANAGEMENT COMMITTEE and recommendations made to the Parties. Upon agreement, CERES will respond to
an invoice from IGER as agreed. Should some items in a section not be achieved then the amount paid
will be reduced on a pro-rata basis on the number of items in the section. CERES-IGER SCHEDULE 1
April 1, 2007
<!-- page 105 -->
Attachment B — Budget

Suggested milestones, for discussion, for full overhead payments

The Parties agree to finalize this document within thirty (30) days from the commencement date of
this SCHEDULE.

Year 1 (April 1 to March 31):

A. [***] research to create an economically viable business

1. [***] and [***] variation affecting [***] amongst available (numbers?) [***] and their behaviour
through the season/[***] reported; any clear winners [***]

2. [***] and [***] variation affecting [***] (numbers?) [***] and early [***] across different [***]
and [***] reported; any clear leaders [***] and sent to Ceres

3. XXX [***] of Miscanthus [***] ([***]?) (good [***]) with Miscanthus [***] made and followed by
[***] where necessary. [***] of [***] sent to Ceres by early 20[***].

4. First [***] of [***] x [***] made based on results from 20[***] field [***] and [***]

B. [***] to Ceres to help [***] in [***] as early as possible

1. [***] of latest [***] of [***] from [***] via [***] (how many?) sent into [***] in 20[***] when
requested by Ceres

2. Selected set of promising [***] including [***] lines and [***] trialled to date sent to Ceres in
[***] in 20[***] for trial in [***]

3. Samples of [***] of Year 1 [***] sent to Ceres, including a sample of [***] (Numbers of [***]?)

4. Approximately [***] from [***] (how many?) occurring in the field in 20[***] believed to be
[***]x x [***]x sent to Ceres

C. Advancing the [***] assisted [***] program as early as possible

1. DNA from about [***] plant [***] phenotyped in the field since 20[***] and first [***] delivered
to Ceres in 20[***].

2. DNA from about new [***] plant [***] in [***] in 20[***], other [***] and other selected [***]
delivered to Ceres in 20[***]

D. Advancing the [***] program

1. xxx new [***] of [***] x [***] made based on phenotypes and presumed [***]

2. xxx [***] of M [***] x other made

Page 3

Confidential Treatment Requested and the Redacted Material has been separately filed with the
Commission

CERES-IGER SCHEDULE 1 April 1, 2007
<!-- page 106 -->
Attachment B — Budget

3. [***] phenotype/[***] assessments of material in [***] since 20[***] reported and correlations
made with assessments in years 1 and 2 and with [***]

E. Advancing [***] research

1. Samples (how many?) and [***] (how many?) sent to Ceres

F. Enhancing [***]

1. Additional [***] made and materials brought into [***] in IGER to fill in specific [***] needed
for likely commercialization locations

Year 2 (April 1 to March 31):

A. [***] research to create an economically viable business

1. [***]/[***] variation affecting [***] amongst large range of [***] (numbers?) and their behaviour
through the season/[***] reported; any clear winners [***]

2. [***]/[***] variation affecting [***] (numbers?) [***] and early growth across different [***]
and [***] reported; any clear leaders [***] and sent to Ceres

3. XXX [***] of Miscanthus [***] ([***]) (good [***]) with Miscanthus [***] made and followed by
[***] where necessary. [***] of [***] sent to Ceres by early 20[***].

4. Next [***] of [***] x [***] made based on results from 20[***] field [***] and [***]

5. Synthesis of best practice for [***] of miscanthus based on [***] and [***], [***] and other
methods to meet market costs and commercialization in different geographies

B. [***] to Ceres to help [***] in [***] as early as possible

1. Approximately [***] from [***] occurring in the field in 20[***] believed to be [***]x x [***]x
sent to Ceres

2. Samples of [***] of Year 2 [***] (numbers?) sent to Ceres, including a sample of [***]

3. Promising selected genotypes from [***]/[***]/[***] program [***] in [***] and sent to Ceres

C. Advancing the [***] assisted [***] program as early as possible

1. DNA from relevant [***] from [***] program, [***] etc delivered to Ceres in 20[***]

2. Preliminary phenotyping of [***] in field and preliminary [***] made with Ceres

3. [***] and [***] aligned with [***] and [***] and [***]

Page 4

Confidential Treatment Requested and the Redacted Material has been separately filed with the
Commission

CERES-IGER SCHEDULE 1 April 1, 2007
<!-- page 107 -->
Attachment B — Budget

D. Advancing the [***] program

1. xxx new [***] of [***] x [***] made based on phenotypes, presumed [***], [***] and other
characters

2. xxx new [***] of M [***] x other made

3. [***] phenotype/[***] assessments of material in [***] since 20[***] reported and correlations
made with assessments in previous years and with [***]

4. Selection and [***] of genotypes for further trialing for potential commercialization based on
geography, [***] and [***]

5. Report on methods to [***] large scale [***] with commercial advantages

Year 3 (April 1 to March 31):

A. [***] research to create an economically viable business

1. [***]/[***] variation affecting [***] amongst available [***] (how many?) and their behaviour
through the season/[***] reported; any clear winners [***]

2. [***]/[***] variation affecting [***] ( how many?) [***] and early [***] across different [***]
and [***] reported; any clear leaders [***] and sent to Ceres.

3. Synthesis of best practice for [***] of miscanthus based on [***] and [***], [***] and other
methods to meet market costs and commercialization in different geographies.

4. XXX [***] of Miscanthus [***] ([***]) (good [***]) with Miscanthus [***] made and followed by
[***] where necessary. [***] of [***] sent to Ceres by early 20[***].

5. Next [***] of [***] x [***] made based on results from 20[***] field [***] and [***]

B. [***] to Ceres to help [***] in [***] as early as possible

1. Approximately [***] from [***] occurring in the field in 20[***] believed to be [***]x x [***]x
sent to Ceres

2. Samples of [***] of Year 3 [***] (how many?) sent to Ceres, including a sample of [***]

3. Promising selected genotypes from [***]/[***] program [***] in [***] and sent to Ceres

C. Advancing the [***] assisted [***] program as early as possible

1. DNA from relevant [***] from [***] program, [***] etc delivered to Ceres in 20[***]

2. Advanced phenotyping of [***] in field and [***] made with Ceres

D. Advancing the [***] program

Page 5

Confidential Treatment Requested and the Redacted Material has been separately filed with the
Commission

CERES-IGER SCHEDULE 1 April 1, 2007
<!-- page 108 -->
Attachment B — Budget

1. xxx new [***] of [***] x [***] made based on phenotypes and presumed [***], [***] and [***] and
[***] samples transferred to Ceres

2. xxx new [***] of M [***] x other made and [***] samples transferred to Ceres

4. Initial evaluation of [***] in field; report on [***], and commercial feasibility of [***]

5. Selection and [***] of promising genotypes from all [***] to date for further trialing for
potential commercialization based on geography, [***] and [***] and selections transferred to Ceres

6. Establishment of multisite trial of promising genotypes

Page 6

Confidential Treatment Requested and the Redacted Material has been separately filed with the
Commission

CERES-IGER SCHEDULE 1 April 1, 2007
<!-- page 109 -->
Attachment C CERES-IGER SCHEDULE 1 April 1, 2007

Quarterly Report Format

Prepared by Date

1

Confidential Project # and name
<!-- page 110 -->
Concept and Goals

2

• Concept

• Goals

Confidential Project # and name
<!-- page 111 -->
FTEs and Budget Projected vs. Actual

Dollars

FTEs

3

• People and activities

Confidential Project # and name
<!-- page 112 -->
Action Items and Deliverables for the Period

4

Expected Actual Action Item or Deliverable Finish Finish Confidential Project # and name
<!-- page 113 -->
Key Milestones or Deliverables for the Period

5

• Progress on Key Milestones and Deliverables

• Are we on, ahead or behind schedule Confidential Project # and name
<!-- page 114 -->
Technical Highlights

6

• 1 or 2 slides covering technical highlights Confidential Project # and name
<!-- page 115 -->
Results

7

• Several slides summarizing results (if applicable) Confidential Project # and name
<!-- page 116 -->
What's Ahead: Key Milestones and Deliverables Next 4 Quarters

8

• Quarter 1

• Quarter 2

• Quarter 3

• Quarter 4 Confidential Project # and name
<!-- page 117 -->
Research Plan

9

• Goal

— Impact

— Tasks

— Milestones

— Deliverables

• Duplicate this slide as needed to cover each goal for the next period Confidential Project # and
name
<!-- page 118 -->
Timeline Summary

10

T i m e t o a c h i e v e M i l e s t o n e 1 2 3 4 5 6 7 8 9 1 0 1 1 1 2 M i l e s t o n e 1 M i l
e s t o n e 2 M i l e s t o n e 3 E t c

• Assumptions and risk factors

• Use additional slide if necessary

• Use red if behind schedule until completed or otherwise resolved

• Should be indicated in red as soon as the delay is identified

• See issue resolution if behind schedule Confidential Project # and name
<!-- page 119 -->
IP

11

• Filings during the period

• Applications in progress

Confidential Project # and name
<!-- page 120 -->
SOPs

12

• List SOPS for all Key processes Confidential Project # and name
<!-- page 121 -->
Issue Resolution and Decision Making Slides

These can be used to address new issues or implement corrective action or assist in decision making
such as variety release, etc.

13

Confidential Project # and name

Issue Resolution and Decision Making

14

• Issue (e.g. milestone 3 behind schedule)

Confidential Project # and name
<!-- page 122 -->
Actual

• What is happening

Expected

• What should be happening

Issue Resolution and Decision Making

15

• Issue (e.g. milestone 3 behind schedule)
<!-- page 123 -->
• Possible alternative slide to address new issues

Confidential Project # and name

Needs Wants
<!-- page 124 -->
Decision

16

• Summary of decision to be made Confidential Project # and name
<!-- page 125 -->
Options

17

• Summary of options Confidential Project # and name
<!-- page 126 -->
Recommendations

18

• What do we need to do to get back on track or address new issue Confidential Project # and name
<!-- page 127 -->
Resources Required

19

Confidential Project # and name
<!-- page 128 -->
Plan and Schedule

20

Action Items Who When Confidential Project # and name
<!-- page 129 -->
Attachment D

IGER BACKGROUND INTELLECTUAL PROPERTY

Confidential Treatment Requested and the Redacted Material has been separately filed with the
Commission

Miscanthus accessions from the following sources: Number IGER collection from [***] ([***]), [***]
and [***] in 20[***] approx. [***] Kew/ADAS (BRL agreement) -see attached list [***] -see attached
list [***] -see attached list Other European sources -see attached list CERES-IGER SCHEDULE 1 April
1, 2007
<!-- page 130 -->
List of Donated Accessions AccID Accession Species SuppliedBy PreviousID Restrictions [***] Type
[***] Comments 1 Mb 1 Miscanthus [***] [***] [***] under MTA [***] [***] [***]

2 Mb 2 Miscanthus [***] [***] [***] under MTA [***] [***] [***]

3 Mb 3 Miscanthus [***] [***] [***] under MTA [***] [***] [***]

4 Mb 4 Miscanthus [***] [***] [***] under MTA [***] [***] [***]

5 Mb 5 Miscanthus [***] [***] [***] under MTA [***] [***] [***]

6 Mb 6 Miscanthus [***] [***] [***] under MTA [***] [***] [***]

7 Mb 7 Miscanthus [***] [***] [***] under MTA [***] [***] [***]

8 Mb 8 Miscanthus [***] [***] [***] under MTA [***] [***] [***]

9 Mb 9 Miscanthus [***] [***] [***] under MTA [***] [***] [***]

10 Mb 10 Miscanthus [***] [***] [***] under MTA [***] [***] [***]

11 Mb 11 Miscanthus [***] [***] [***] under MTA [***] [***] [***]

12 Mb 12 Miscanthus [***] [***] [***] under MTA [***] [***] [***]

13 Mb 13 Miscanthus [***] [***] [***] under MTA [***] [***] [***]

14 Mb 14 Miscanthus [***] [***] [***] under MTA [***] [***] [***]

15 Mb 15 Miscanthus [***] [***] [***] under MTA [***] [***] [***]

16 Mb 16 Miscanthus [***] [***] [***] under MTA [***] [***] [***]

17 Mb 17 Miscanthus [***] [***] [***] under MTA [***] [***] [***]

18 Mb 18 Miscanthus [***] [***] [***] under MTA [***] [***] [***]

19 Mb 19 Miscanthus [***] [***] [***] under MTA [***] [***] [***]

20 Mb 20 Miscanthus [***] [***] [***] under MTA [***] [***] [***]

21 Mb 21 Miscanthus [***] [***] [***] under MTA [***] [***] [***]

22 Mb 22 Miscanthus [***] [***] [***] under MTA [***] [***] [***] No longer retained.

23 Mb 23 Miscanthus [***] [***] [***] under MTA [***] [***] [***]

24 Mb 24 Miscanthus [***] [***] [***] under MTA [***] [***] [***]

25 Mb 25 Miscanthus [***] [***] [***] under MTA [***] [***] [***]

26 Mb 26 Miscanthus [***] [***] [***] under MTA [***] [***] [***]

27 Mb 27 Miscanthus [***] [***] [***] under MTA [***] [***] [***]

28 Mb 28 Miscanthus [***] [***] [***] under MTA [***] [***] [***]

29 Mb 29 Miscanthus [***] [***] [***] under MTA [***] [***] [***]

30 Mb 30 Miscanthus [***] [***] [***] under MTA [***] [***] [***]

31 Mb 31 Miscanthus [***] [***] [***] under MTA [***] [***] [***]

32 Mb 32 Miscanthus [***] [***] [***] under MTA [***] [***] [***]

33 Mb 33 Miscanthus [***] [***] [***] under MTA [***] [***] [***]

34 Mb 34 Miscanthus [***] [***] [***] under MTA [***] [***] [***]

35 Mb 35 Miscanthus [***] [***] [***] under MTA [***] [***] [***]

36 Mb 36 Miscanthus [***] [***] [***] under MTA [***] [***] [***]

37 Mb 37 Miscanthus [***] [***] under MTA [***] [***] [***]
<!-- page 131 -->
[***] 38 Mb 38 Miscanthus [***] [***] [***] under MTA [***] [***] [***]

39 Mb 39 Miscanthus [***] [***] [***] under MTA [***] [***] [***]

40 Mb 40 Miscanthus [***] [***] [***] under MTA [***] [***] [***]

41 Mb 41 Miscanthus [***] [***] [***] under MTA [***] [***] [***]

42 Mb 42 Miscanthus [***] [***] [***] under MTA [***] [***] [***]

43 Mb 43 Miscanthus [***] [***] [***] under MTA [***] [***] [***] No longer retained.

44 Mb 44 Miscanthus [***] [***] [***] under MTA [***] [***] [***]

45 Mb 45 Miscanthus [***] [***] [***] under MTA [***] [***] [***] No longer retained.

46 Mb 46 Miscanthus [***] [***] [***] under MTA [***] [***] [***]

47 Mb 47 Miscanthus [***] [***] [***] under MTA [***] [***]

48 Mb 48 Miscanthus [***] [***] [***] under MTA [***] [***]

49 Mb 49 Miscanthus [***] [***] [***] under MTA [***] [***]

50 Mb 50 Miscanthus [***] [***] [***] under MTA [***] [***]

51 Mb 51 Miscanthus [***] [***] [***] under MTA [***] [***]

52 Mb 52 Miscanthus [***] [***] [***] under MTA [***] [***]

53 Mb 53 Miscanthus [***] [***] [***] under MTA [***] [***]

54 Mb 54 Miscanthus [***] [***] [***] under MTA [***] [***]

55 Mb 55 Miscanthus [***] [***] [***] under MTA [***] [***]

56 Mb 56 Miscanthus [***] [***] [***] under MTA [***] [***]

57 Mb 57 Miscanthus [***] [***] [***] under MTA [***] [***]

58 Mb 58 Miscanthus [***] [***] [***] under MTA [***] [***]

59 Mb 59 Miscanthus [***] [***] [***] under MTA [***] [***]

60 Mb 60 Miscanthus [***] [***] [***] under MTA [***] [***]

61 Mb 61 Miscanthus [***] [***] [***] under MTA [***] [***]

62 Mb 62 Miscanthus [***] [***] [***] under MTA [***] [***] No longer retained.

63 Mb 63 Miscanthus [***] [***] [***] under MTA [***] [***]

64 Mb 64 Miscanthus [***] [***] [***] under MTA [***] [***]

65 Mb 65 Miscanthus [***] [***] [***] under MTA [***] [***]

66 Mb 66 Miscanthus [***] [***] [***] under MTA [***] [***]

67 Mb 67 Miscanthus [***] [***] [***] under MTA [***] [***]

68 Mb 68 Miscanthus [***] [***] [***] under MTA [***] [***]

69 Mb 69 Miscanthus [***] [***] [***] under MTA [***] [***]

70 Mb 70 Miscanthus [***] [***] [***] under MTA [***] [***]

71 Mb 71 Miscanthus [***] [***] [***] under MTA [***] [***]

72 Mb 72 Miscanthus [***] [***] [***] under MTA [***] [***]

73 Mb 73 Miscanthus [***] [***] [***] under MTA [***] [***]

74 Mb 74 Miscanthus [***] [***] [***] under MTA [***] [***]

75 Mb 75 Miscanthus [***] [***] [***] under MTA [***] [***]

76 Mb 76 Miscanthus [***] [***] under MTA [***] [***]

Page 1

Confidential Treatment Requested and the Redacted Material has been separately filed with the
Commission
<!-- page 132 -->
[***] 77 Mb 77 Miscanthus [***] [***] [***] under MTA [***] [***]

78 Mb 78 Miscanthus [***] [***] [***] under MTA [***] [***]

79 Mb 79 Miscanthus [***] [***] [***] under MTA [***] [***]

80 Mb 80 Miscanthus [***] [***] [***] under MTA [***] [***]

81 Mb 81 Miscanthus [***] [***] [***] under MTA [***] [***]

82 Mb 82 Miscanthus [***] [***] [***] under MTA [***] [***]

83 Mb 83 Miscanthus [***] [***] [***] under MTA [***] [***]

84 Mb 84 Miscanthus [***] [***] [***] under MTA [***] [***]

85 Mb 85 Miscanthus [***] [***] [***] under MTA [***] [***]

86 Mb 86 Miscanthus [***] [***] [***] under MTA [***] [***]

87 Mb 87 Miscanthus [***] [***] [***] under MTA [***] [***]

88 Mb 88 Miscanthus [***] [***] [***] under MTA [***] [***]

89 Mb 89 Miscanthus [***] [***] [***] under MTA [***] [***]

90 Mb 90 Miscanthus [***] [***] [***] under MTA [***] [***]

91 Mb 91 Miscanthus [***] [***] [***] under MTA [***] [***]

92 Mb 92 Miscanthus [***] [***] [***] under MTA [***] [***]

93 Mb 93 Miscanthus [***] [***] [***] under MTA [***] [***]

94 Mb 94 Miscanthus [***] [***] [***] under MTA [***] [***]

95 Mb 95 Miscanthus [***] [***] [***] under MTA [***] [***]

96 Mb 96 Miscanthus [***] [***] [***] under MTA [***] [***]

97 Mb 97 Miscanthus [***] [***] [***] under MTA [***] [***]
<!-- page 133 -->
List of Donated Accessions 98 Mb 98 Miscanthus [***] [***] [***] under MTA [***] [***]

99 Mb 99 Miscanthus [***] [***] [***] under MTA [***] [***]

100 Mb 100 Miscanthus [***] [***] [***] under MTA [***] [***]

101 Mb 101 Miscanthus [***] [***] [***] under MTA [***] [***]

102 Mb 102 Miscanthus [***] [***] [***] under MTA [***] [***]

103 Mb 103 Miscanthus [***] [***] [***] under MTA [***] [***]

104 Mb 104 Miscanthus [***] [***] [***] under MTA [***] [***]

105 Mb 105 Miscanthus [***] [***] [***] under MTA [***] [***]

106 Mb 106 Miscanthus [***] [***] [***] under MTA [***] [***]

107 Mb 107 Miscanthus [***] [***] [***] under MTA [***] [***]

108 Mb 108 Miscanthus [***] [***] [***] none [***] [***]

109 Mb 109 Miscanthus [***] [***] [***] none [***] [***]

110 Mb 110 Miscanthus [***] [***] [***] none [***] [***]

111 Mb 111 Miscanthus [***] [***] [***] none [***] [***]

112 Mb 112 Miscanthus [***] [***] [***] none [***] [***]

113 Mb 113 Miscanthus [***] [***] [***] none [***] [***]

114 Mb 114 Miscanthus [***] [***] [***] none [***] [***]

115 Mb 115 Miscanthus [***] [***] [***] none [***] [***]

116 Mb 116 Miscanthus [***] [***] [***] unclear [***] [***]

117 Mb 117 Miscanthus [***] [***] [***] unclear [***] [***]

118 Mb 118 Miscanthus [***] [***] [***] unclear [***] [***]

119 Mb 119 Miscanthus [***] [***] [***] unclear [***] [***]

120 Mb 120 Miscanthus [***] [***] [***] unclear [***] [***]

121 Mb 121 Miscanthus [***] [***] [***] unclear [***] [***] No longer retained.

122 Mb 122 Miscanthus [***] [***] [***] unclear [***] [***] No longer retained.

123 Mb 123 Miscanthus [***] [***] [***] unclear [***] [***]

124 Mb 124 Miscanthus [***] [***] [***] unclear [***] [***]

125 Mb 125 Miscanthus [***] [***] [***] unclear [***] [***]

126 Mb 126 Miscanthus [***] [***] [***] unclear [***] [***]

127 Mb 127 Miscanthus [***] [***] [***] unclear [***] [***]

128 Mb 128 Miscanthus [***] [***] [***] unclear [***] [***]

129 Mb 129 Miscanthus [***] [***] [***] unclear [***] [***]

130 Mb 130 Miscanthus [***] [***] [***] unclear [***] [***]

131 Mb 131 Miscanthus [***] [***] [***] unclear [***] [***]

132 Mb 132 Miscanthus [***] [***] [***] unclear [***] [***]

133 Mb 133 Miscanthus [***] [***] [***] unclear [***] [***]

134 Mb 134 Miscanthus [***] [***] [***] unclear [***] [***]
<!-- page 134 -->
135 Mb 135 Miscanthus [***] [***] [***] none [***] [***]

136 Mb 136 Miscanthus [***] [***] [***] none [***] [***]

137 Mb 137 Miscanthus [***] [***] [***] none [***] [***]

138 Mb 138 Miscanthus [***] [***] [***] none [***] [***]

139 Mb 139 Miscanthus [***] [***] [***] none [***] [***] [***]

140 Mb 140 Miscanthus [***] [***] [***] under MTA [***] [***] [***]

141 Mb 141 Miscanthus [***] [***] [***] under MTA [***] [***]

142 Mb 142 Miscanthus [***] [***] [***] under MTA [***] [***] [***]

143 Mb 143 Miscanthus [***] [***] [***] under MTA [***] [***] [***]

144 Mb 144 Miscanthus [***] [***] [***] under MTA [***] [***] [***]

145 Mb 145 Miscanthus [***] [***] [***] none [***] [***] [***]

146 Mb 146 Miscanthus [***] [***] [***] none [***] [***] [***]

147 Mb 147 Miscanthus [***] [***] [***] none [***] [***] [***]

148 Mb 148 Miscanthus [***] [***] [***] none [***] [***] [***]

149 Mb 149 Miscanthus [***] [***] [***] none [***] [***]

150 Mb 150 Miscanthus [***] [***] [***] none [***] [***] No longer retained.

151 Mb 151 Miscanthus [***] [***] [***] under MTA [***] [***]

152 Mb 152 Miscanthus [***] [***] [***] under MTA [***] [***]

153 Mb 153 Miscanthus [***] [***] [***] under MTA [***] [***]

154 Mb 154 Miscanthus [***] [***] [***] none [***] [***] No longer retained.

155 Mb 155 Miscanthus [***] [***] [***] none [***] [***]

156 Mb 156 Miscanthus [***] [***] [***] none [***] [***]

157 Mb 157 Miscanthus [***] [***] [***] none [***] [***] No longer retained.

158 Mb 158 Miscanthus [***] [***] [***] under MTA [***] [***]

159 Mb 159 Miscanthus [***] [***] [***] under MTA [***] [***]

160 Mb 160 Miscanthus [***] [***] [***] under MTA [***] [***]

161 Mb 161 Miscanthus [***] [***] [***] under MTA [***] [***]

162 Mb 162 Miscanthus [***] [***] [***] under MTA [***] [***]

163 Mb 163 Miscanthus [***] [***] [***] under MTA [***] [***]

164 Mb 164 Miscanthus [***] [***] [***] under MTA [***] [***]

165 Mb 165 Miscanthus [***] [***] [***] under MTA [***] [***]

166 Mb 166 Miscanthus [***] [***] [***] under MTA [***] [***]

167 Mb 167 Miscanthus [***] [***] [***] under MTA [***] [***]

168 Mb 168 Miscanthus [***] [***] [***] under MTA [***] [***]

169 Mb 169 Miscanthus [***] [***] [***] under MTA [***] [***]

170 Mb 170 Miscanthus [***] [***] [***] under MTA [***] [***]

171 Mb 171 Miscanthus [***] [***] [***] under MTA [***] [***]

172 Mb 172 Miscanthus [***] [***] [***] under MTA [***] [***]

173 Mb 173 Miscanthus [***] [***] [***] under MTA [***] [***]

Page 2

Confidential Treatment Requested and the Redacted Material has been separately filed with the
Commission
<!-- page 135 -->
174 Mb 174 Miscanthus [***] [***] [***] under MTA [***] [***]

175 Mb 175 Miscanthus [***] [***] [***] under MTA [***] [***]

176 Mb 176 Miscanthus [***] [***] [***] no MTA [***] [***]

177 Mb 177 Miscanthus [***] [***] [***] no MTA [***] [***]

178 Mb 178 Miscanthus [***] [***] [***] no MTA [***] [***]

179 Mb 179 Miscanthus [***] [***] [***] no MTA [***] [***]

180 Mb 180 Miscanthus [***] [***] [***] no MTA [***] [***]

181 Mb 181 Miscanthus [***] [***] [***] no MTA [***] [***]

182 Mb 182 Miscanthus [***] [***] [***] no MTA [***] [***]

183 Mb 183 Miscanthus [***] [***] [***] no MTA [***] [***]

184 Mb 184 Miscanthus [***] [***] [***] no MTA [***] [***] No longer retained.

185 Mb 185 Miscanthus [***] [***] [***] none [***] [***]

186 Mb 186 Miscanthus [***] [***] [***] none [***] [***]

187 Mb 187 Miscanthus [***] [***] [***] none [***] [***]

188 Mb 188 Miscanthus [***] [***] [***] none [***] [***]

189 Mb 189 Miscanthus [***] [***] [***] under MTA [***] [***]

190 Mb 190 Miscanthus [***] [***] [***] under MTA [***] [***]

191 Mb 191 Miscanthus [***] [***] [***] none [***] [***] [***]

192 Mb 192 Miscanthus [***] [***] [***] none [***] [***] [***]

193 Mb 193 Miscanthus [***] [***] [***] none [***] [***] [***]

194 Mb 194 Miscanthus [***] [***] [***] none [***] [***] [***]

195 Mb 195 Miscanthus [***] [***] [***] none [***] [***] [***]
<!-- page 136 -->
List of Donated Accessions 196 Mb 196 Miscanthus [***] [***] [***] none [***] [***] [***]

197 Mb 197 Miscanthus [***] [***] [***] none [***] [***] [***]

198 Mb 198 Miscanthus [***] [***] [***] none [***] [***] [***]

199 Mb 199 Miscanthus [***] [***] [***] none [***] [***] [***]

200 Mb 200 Miscanthus [***] [***] [***] none [***] [***] [***]

201 Mb 201 Miscanthus [***] [***] [***] none [***] [***] [***]

202 Mb 202 Miscanthus [***] [***] [***] none [***] [***] [***]

203 Mb 203 Miscanthus [***] [***] [***] none [***] [***] [***]

204 Mb 204 Miscanthus [***] [***] [***] none [***] [***] [***]

205 Mb 205 Miscanthus [***] [***] [***] none [***] [***] [***]

206 Mb 206 Miscanthus [***] [***] [***] none [***] [***] [***]

207 Mb 207 Miscanthus [***] [***] [***] none [***] [***] [***]

208 Mb 208 Miscanthus [***] [***] [***] none [***] [***] [***]

209 Mb 209 Miscanthus [***] [***] [***] none [***] [***] [***]

210 Mb 210 Miscanthus [***] [***] [***] none [***] [***] [***]

211 Mb 211 Miscanthus [***] [***] [***] none [***] [***] [***]

212 Mb 212 Miscanthus [***] [***] [***] none [***] [***] [***]

213 Mb 213 Miscanthus [***] [***] [***] none [***] [***] [***]

214 Mb 214 Miscanthus [***] [***] [***] none [***] [***] [***]

215 Mb 215 Miscanthus [***] [***] [***] none [***] [***] [***]

216 Mb 216 Miscanthus [***] [***] [***] none [***] [***] [***]

217 Mb 217 Miscanthus [***] [***] [***] none [***] [***] [***]

218 Mb 218 Miscanthus [***] [***] [***] none [***] [***] [***]

219 Mb 219 Miscanthus [***] [***] [***] none [***] [***] [***]

220 Mb 220 Miscanthus [***] [***] [***] none [***] [***] [***]

221 Mb 221 Miscanthus [***] [***] [***] under MTA [***] [***] [***]

222 Mb 222 Miscanthus [***] [***] [***] under MTA [***] [***] [***]

223 Mb 223 Miscanthus [***] [***] [***] under MTA [***] [***] [***]

224 Mb 224 Miscanthus [***] [***] [***] under MTA [***] [***] [***]

225 Mb 225 Miscanthus [***] [***] [***] under MTA [***] [***] [***]

226 Mb 226 Miscanthus [***] [***] [***] under MTA [***] [***] [***]

227 Mb 227 Miscanthus [***] [***] [***] under MTA [***] [***] [***] No longer retained.

228 Mb 228 Miscanthus [***] [***] [***] under MTA [***] [***] [***]

229 Mb 229 Miscanthus [***] [***] [***] under MTA [***] [***] [***]

230 Mb 230 Miscanthus [***] [***] [***] under MTA [***] [***] [***]

231 Mb 231 Miscanthus [***] [***] [***] under MTA [***] [***] [***]

232 Mb 232 Miscanthus [***] [***] [***] under MTA [***] [***] [***]
<!-- page 137 -->
233 Mb 233 Miscanthus [***] [***] [***] under MTA [***] [***] [***]

234 Mb 234 Miscanthus [***] [***] [***] under MTA [***] [***] [***] No longer retained.

235 Mb 235 Miscanthus [***] [***] [***] under MTA [***] [***] [***]

236 Mb 236 Miscanthus [***] [***] [***] under MTA [***] [***] [***]

237 Mb 237 Miscanthus [***] [***] [***] under MTA [***] [***] [***]

238 Mb 238 Miscanthus [***] [***] [***] under MTA [***] [***] [***]

239 Mb 239 Miscanthus [***] [***] [***] under MTA [***] [***] [***]

240 Mb 240 Miscanthus [***] [***] [***] under MTA [***] [***] [***]

241 Mb 241 Miscanthus [***] [***] [***] under MTA [***] [***] [***]

242 Mb 242 Miscanthus [***] [***] [***] under MTA [***] [***] [***]

243 Mb 243 Miscanthus [***] [***] [***] under MTA [***] [***]

244 Mb 244 Miscanthus [***] [***] [***] none [***] [***]

245 Mb 245 Miscanthus [***] [***] [***] none [***] [***]

246 Mb 246 Miscanthus [***] [***] [***] none [***] [***]

247 Mb 247 Miscanthus [***] [***] [***] none [***] [***] [***]

248 Mb 248 Miscanthus [***] [***] [***] none [***] [***] [***]

249 Mb 249 Miscanthus [***] [***] [***] none [***] [***] [***]

250 Mb 250 Miscanthus [***] [***] [***] none [***] [***] [***]

251 Mb 251 Miscanthus [***] [***] [***] none [***] [***] [***]

252 Mb 252 Miscanthus [***] [***] [***] none [***] [***] [***]

253 Mb 253 Miscanthus [***] [***] [***] none [***] [***] [***]

254 Mb 254 Miscanthus [***] [***] [***] none [***] [***] [***]

255 Mb 255 Miscanthus [***] [***] [***] none [***] [***] [***]

256 Mb 256 Miscanthus [***] [***] [***] none [***] [***] [***]

257 Mb 257 Miscanthus [***] [***] [***] none [***] [***] [***]

258 Mb 258 Miscanthus [***] [***] [***] none [***] [***] [***]

259 Mb 259 Miscanthus [***] [***] [***] none [***] [***] [***]

260 Mb 260 Miscanthus [***] [***] [***] none [***] [***] [***]

261 Mb 261 Miscanthus [***] [***] [***] none [***] [***] [***]

262 Mb 262 Miscanthus [***] [***] [***] none [***] [***]

263 Mb 263 Miscanthus [***] [***] [***] none [***] [***]

264 Mb 264 Miscanthus [***] [***] [***] under MTA [***] [***] [***]

265 Mb 265 Miscanthus [***] [***] [***] under MTA [***] [***]

266 Mb 266 Miscanthus [***] [***] [***] under MTA [***] [***] [***]

267 Mb 267 Miscanthus [***] [***] [***] under MTA [***] [***]

268 Mb 268 Miscanthus [***] [***] [***] under MTA [***] [***]

269 Mb 269 Miscanthus [***] [***] [***] under MTA [***] [***] [***]

270 Mb 270 Miscanthus [***] [***] [***] under MTA [***] [***] [***]

271 Mb 271 Miscanthus [***] [***] [***] under MTA [***] [***] [***]

Page 3

Confidential Treatment Requested and the Redacted Material has been separately filed with the
Commission
<!-- page 138 -->
272 Mb 272 Miscanthus [***] [***] [***] under MTA [***] [***] [***]

273 Mb 273 Miscanthus [***] [***] [***] no MTA [***] [***]

274 Mb 274 Miscanthus [***] [***] [***] no MTA [***] [***]

275 Mb 275 Miscanthus [***] [***] [***] no MTA [***] [***] No longer retained.

276 Mb 276 Miscanthus [***] [***] [***] no MTA [***] [***] No longer retained.

277 Mb 277 Miscanthus [***] [***] [***] no MTA [***] [***] No longer retained.

278 Mb 278 Miscanthus [***] [***] [***] no MTA [***] [***]

279 Mb 279 Miscanthus [***] [***] [***] no MTA [***] [***]

280 Mb 280 Miscanthus [***] [***] [***] no MTA [***] [***]

281 Mb 281 Miscanthus [***] [***] [***] no MTA [***] [***] No longer retained.

282 Mb 282 Miscanthus [***] [***] [***] no MTA [***] [***]

283 Mb 283 Miscanthus [***] [***] [***] no MTA [***] [***] No longer retained.

284 Mb 284 Miscanthus [***] [***] [***] no MTA [***] [***]

285 Mb 285 Miscanthus [***] [***] [***] no MTA [***] [***] No longer retained.

286 Mb 286 Miscanthus [***] [***] [***] no MTA [***] [***] No longer retained.

287 Mb 287 Miscanthus [***] [***] [***] no MTA [***] [***] No longer retained.

288 Mb 288 Miscanthus [***] [***] [***] no MTA [***] [***] No longer retained.

289 Mb 289 Miscanthus [***] [***] [***] no MTA [***] [***] No longer retained.

290 Mb 290 Miscanthus [***] [***] [***] no MTA [***] [***]

291 Mb 291 Miscanthus [***] [***] [***] no MTA [***] [***]

292 Mb 292 Miscanthus [***] [***] [***] no MTA [***] [***] No longer retained.

293 Mb 293 Miscanthus [***] [***] [***] unclear [***] [***]
<!-- page 139 -->
List of Donated Accessions 294 Mb 294 Miscanthus [***] [***] [***] unclear [***] [***]

295 Mb 295 Miscanthus [***] [***] [***] unclear [***] [***]

296 Mb 296 Miscanthus [***] [***] [***] none [***] [***] [***]

297 Mb 297 Miscanthus [***] [***] [***] none [***] [***] [***]

298 Mb 298 Miscanthus [***] [***] [***] none [***] [***]

299 Mb 299 Miscanthus [***] [***] [***] none [***] [***]

300 Mb 300 Miscanthus [***] [***] [***] none [***] [***]

301 Mb 301 Miscanthus [***] [***] [***] none [***] [***]

302 Mb 302 Miscanthus [***] [***] [***] none [***] [***]

303 Mb 303 Miscanthus [***] [***] [***] none [***] [***]

304 Mb 304 Miscanthus [***] [***] [***] none [***] [***] No longer retained.

305 Mb 305 Miscanthus [***] [***] [***] no MTA [***] [***] Mix of accessions

306 Mb 306 Miscanthus [***] [***] [***] no MTA [***] [***] Mix of accessions

307 Mb 307 Miscanthus [***] [***] [***] under MTA [***] [***]

308 Mb 308 Miscanthus [***] [***] [***] under MTA [***] [***]

309 Mb 309 Miscanthus [***] [***] [***] under MTA [***] [***]

310 Mb 310 Miscanthus [***] [***] [***] under MTA [***] [***]

311 Mb 311 Miscanthus [***] [***] [***] no MTA [***] [***]

312 Mb 312 Miscanthus [***] [***] [***] none [***] [***] [***]

313 Mb 313 Miscanthus [***] [***] [***] none [***] [***] [***]

314 Mb 314 Miscanthus [***] [***] [***] none [***] [***]

315 Mb 315 Miscanthus [***] [***] [***] none [***] [***]

316 Mb 316 Miscanthus [***] [***] [***] none [***] [***]

317 Mb 317 Miscanthus [***] [***] [***] none [***] [***] [***]

318 Mb 318 Miscanthus [***] [***] [***] none [***] [***] [***]

319 Mb 319 Miscanthus [***] [***] [***] none [***] [***]

320 Mb 320 Miscanthus [***] [***] [***] under MTA [***] [***]

321 Mb 321 Miscanthus [***] [***] [***] none [***] [***] No longer retained.

322 Mb 322 Miscanthus [***] [***] [***] under MTA [***] [***] No longer retained.

323 Mb 323 Miscanthus [***] [***] [***] under MTA [***] [***]

324 Mb 324 Miscanthus [***] [***] [***] under MTA [***] [***]

325 Mb 325 Miscanthus [***] [***] [***] no MTA [***] [***] [***]

326 Mb 326 Miscanthus [***] [***] [***] no MTA [***] [***] [***]

327 Mb 327 Miscanthus [***] [***] [***] no MTA [***] [***] [***]

328 Mb 328 Miscanthus [***] [***] [***] no MTA [***] [***] [***]

329 Mb 329 Miscanthus [***] [***] [***] no MTA [***] [***] [***]

330 Mb 330 Miscanthus [***] [***] [***] no MTA [***] [***] [***] No longer retained.

Page 4

Confidential Treatment Requested and the Redacted Material has been separately filed with the
Commission
<!-- page 140 -->
331 Mb 331 Miscanthus [***] [***] [***] none [***] [***]

332 Mb 332 Miscanthus [***] [***] [***] none [***] [***]

333 Mb 333 Miscanthus [***] [***] [***] none [***] [***]

334 Mb 334 Miscanthus [***] [***] [***] none [***] [***]

335 Mb 335 Miscanthus [***] [***] [***] none [***] [***]

Pages where confidential treatment has been requested are stamped 'Confidential Treatment Requested
and the Redacted Material has been separately filed with the Commission,' and the confidential
section has been marked as follows: [***].
<!-- page 141 -->
AMENDMENT I

to SCHEDULE 1 between CERES, INC. and INSTITUTE OF GRASSLAND AND ENVIRONMENTAL RESEARCH dated April
1, 2007 (the "Schedule").

Made in two (2) copies.

Page 1 of 3

1. The Parties agree to replace the suggested Year 1 (April 1 to March 31) milestones in Attachment
B of the Schedule in their entirety by the Ceres-IGER Milestones — Year 1, as attached hereto. For
clarity, no change is made to pages 1 and 2 of such Attachment B. Any changes to the suggested Year
2 and Year 3 milestones will be addressed in separate amendments to the Schedule.

2. The Parties agree that this Amendment I is effective as of January 1, 2008.

3. For the remainder, the Schedule remains unchanged and this Amendment I shall form an integral
part thereof.

INSTITUTE OF GRASSLAND AND ENVIRONMENTAL RESEARCH CERES, INC.

By: /s/ M Humphreys By: /s/ Peter Mascia

Name: Professor Mervyn Humphreys

Name: Peter Mascia Title: Director Title: Vice President of Product Development By: /s/ Richard
Flavell

Name: Richard Flavell, CBE, FRS Title: Chief Scientific Officer

Ceres-IGER Milestones — Year 1
<!-- page 142 -->
Page 2 of 3

Confidential Treatment Requested and the Redacted Material has been separately filed with the
Commission

Contract Year (April 1 - March 31) Schedule Milestone See key Year 1 Agronomy Characterise [***] in
the potential for [***] amongst [***] from the [***] A

Year 1 Agronomy Survey of [***] capacity of [***] genotypes taken from the [***] trial during July
20[***]. A Year 1 Agronomy Understand [***] affecting [***] across different [***] of [***]
different [***]. A Year 1 [***] [***] of [***] controlled [***] of Miscanthus [***] ([***]) with
Miscanthus [***]. [***] of [***] or [***] to [***] by early 20[***]. A

Year 1 Agronomy [***] of [***] (additional to [***] required by DEFRA) [***] of [***] x [***] made
based on staggered [***]. D

Year 1 [***] [***] of [***] x [***] will be made based on results from 20[***] field [***] and
[***]. A Year 1

[***]

[***] based on outstanding phenotype and [***] geography at [***] from [***] put into [***]. In
[***] or [***] or [***] (multiples per [***]) available to put into [***] in 20[***] when requested
by Ceres

B

Year 1 [***] [***] promising [***] including [***] lines and [***] trialed to date [***] to [***] in
[***] or [***] or [***] for trial in [***] when requested. B

Year 1 [***] Samples of [***] from Year 1 [***] and [***] sent to Ceres. At a minimum [***] + [***]
= [***]; more if possible from [***] of [***] x [***] and [***] x [***] and [***] of [***] x [***]
([***]). B

Year 1 [***] [***] to Ceres from M. [***] ([***]) x M. [***] ([***]) in the field in 20[***];
believed to be [***] . B

Year 1 Markers [***]/DNA from [***] plant [***] phenotyped in the field since 20[***] and first
[***] delivered to Ceres in 20[***]. C

Year 1

Markers

[***]/DNA from plant [***] in [***] in 20[***] where material is available, plus other [***]
individuals (numbers defined in Marker schedule) and other selected genotypes where material is
available delivered to Ceres in 20[***]

C

Year 1 [***] Year 2 and [***] phenotype/[***] assessments of material in [***] trials reported for
Ceres to make correlations between assessments and markers D

Year 1 Markers [***] sent to Ceres, samples as requested by Ceres for [***]. E Year 1 [***] [***]
made in 20[***] and materials brought into [***] in IGER to fill in specific [***] needed for likely
[***]. F
<!-- page 143 -->
KEY

Page 3 of 3

Confidential Treatment Requested and the Redacted Material has been separately filed with the
Commission

A [***] research to create an economically viable business

B [***] to Ceres to help [***] in [***] as early as possible

C Advancing the marker assisted [***] program as early as possible

D Advancing the [***] program

E Advancing [***] research

F Enhancing [***]
<!-- page 144 -->
Pages where confidential treatment has been requested are stamped 'Confidential Treatment Requested
and the Redacted Material has been separately filed with the Commission,' and the confidential
section has been marked as follows: [***].

AMENDMENT II

to the Collaboration Agreement effective as of April 1, 2007 between the Institute of Grassland and
Environmental Research ("IGER") and Ceres, Inc. ("CERES"), as amended (the "Agreement") and to
SCHEDULE 1 between the Institute of Grassland and Environmental Research ("IGER") and Ceres, Inc.
("CERES") and dated April 1, 2007, as amended ("Schedule 1").

WHEREAS, the Institute of Grassland and Environmental Research ("IGER") and CERES entered into the
Agreement and Schedule 1 on April 1, 2007;

WHEREAS, on April 1, 2008 IGER merged with Aberystwyth University Institutes of Biological Sciences
and Rural Sciences to form the new Institute of Biological, Environmental and Rural Sciences of
Aberystwyth University ("AU");

WHEREAS, as a consequence of such merger, the Parties wish to substitute AU in place of IGER as a
contract party to the Agreement;

WHEREAS, AU and CERES wish to amend the Agreement, as set forth hereinafter.

NOW THEREFORE, in consideration of the premises and of the mutual covenants and agreements contained
herein and of other good and valuable consideration, the Parties have agreed and do hereby agree as
follows:

Page 1 of 2

1. The Parties agree that Aberystwyth University, a Higher Education Establishment registered in the
United Kingdom No. RC000641, having an office at Old College, King Street, Aberystwyth SY23 2AX
("AU") should be substituted as a contract party to the Agreement in place of IGER.

2. The Parties agree to amend Article 14.1 (e) (v) of the Agreement so as to read as follows:

"(v) with thirty (30) days' written notice to AU if Defra has not assigned to AU, or granted to AU a
license reasonably satisfactory to CERES on, the Intellectual Property vested in Defra or the Crown
or the Secretary of State pursuant to the DEFRA agreement NF 0426 within three (3) years from the
Effective Date (the "Assignment/License"); provided however that Ceres will not unreasonably refuse
to extend such three (3) year term by six (6) months if so requested by AU by December 31, 2009."

3. The Parties agree to add the following clause in Article 6 of Schedule 1:

Made in two (2) copies.

Page 2 of 2

Confidential Treatment Requested and the Redacted Material has been separately filed with the
Commission
<!-- page 145 -->
"As long as the assignment or license grant by Defra to AU, and the corresponding grant of a license
or sublicense to CERES in compliance with the Agreement, has not occurred, CERES will have the right
to withhold [***] percent ([***]%) of the funding payable by CERES to AU pursuant to Attachment B —
Budget, attached to Schedule 1 (as this may be amended from time to time). CERES' rights to withhold
such payments will terminate:

(i) with respect to [***] percent ([***]%) of the funding, as of the date CERES effectively receives
a license or sublicense satisfactory to CERES on CERTAIN MISCANTHUS ACCESSIONS (defined in Article
3.2.1 b. of the Agreement) and related information.

(ii) with respect to [***] percent ([***]%) of the funding as of the date CERES effectively receives
a license or sublicense satisfactory to CERES on the Intellectual Property vested in Defra or the
Crown or the Secretary of State pursuant to the Defra agreement NF0426."

4. The Parties agree that this Amendment II is deemed to have become effective as of May 1, 2008.

5. For the remainder, the Agreement and Schedule 1 remain unchanged and this Amendment II shall form
an integral part thereof.

ABERYSTWYTH UNIVERSITY CERES, INC. By: /s/ S.G.A. Durbin By: /s/ Richard Flavell Name: S.G.A. Durbin
Name: Richard Flavell, CBE, FRS Title: Director, Risk & Research Finance Title: Chief Scientific
Officer By: /s/ Richard Hamilton Name: Richard Hamilton Title: President and Chief Executive Officer

Pages where confidential treatment has been requested are stamped 'Confidential Treatment Requested
and the Redacted Material has been separately filed with the Commission,' and the confidential
section has been marked as follows: [***].
<!-- page 146 -->
CONFIDENTIAL

AMENDMENT III

to the SCHEDULE 1 between the Institute of Biological, Environmental and Rural Sciences ("IBERS") of
Aberystwyth University and Ceres, Inc. ("CERES") and dated April 1, 2007, as amended ("Schedule 1").

WHEREAS, IBERS and CERES entered into Schedule 1 on April 1, 2007;

WHEREAS, the initial term of Schedule 1 was for three (3) years;

WHEREAS, the Parties wish to extend the term of Schedule 1 to cover additional research and
development activities;

WHEREAS, IBERS and CERES further wish to amend Schedule 1, as set forth hereinafter.

NOW THEREFORE, in consideration of the premises and of the mutual covenants and agreements contained
herein and of other good and valuable consideration, the Parties have agreed and do hereby agree as
follows:

Richard Flavell (CERES) Jeff Gwyn (CERES) Charlie Rodgers (CERES) Timothy Swaller (CERES)

Page 1 of 9

1. The Parties agree to substitute the RESEARCH AND DEVELOPMENT PLAN referred to in Article 3 of
Schedule 1 and attached as Attachment A to Schedule 1 by a new Attachment A/2010 revision, as
attached to this Amendment III.

2. The Parties agree to amend Article 5 PHD LEVEL SCIENTIFIC STAFF for CERES staff so as to read as
follows:

3. The Parties agree to substitute the Budget referred to in Article 6 of Schedule 1 and attached as
Attachment B to Schedule 1 by a new Attachment B/2010 revision, as attached to this Amendment III.

4. The Parties agree to amend Article 16 Term of Schedule 1 so as to read as follows:

"Term: Five (5) years provided however, at least one (1) year before the end of the term of this
SCHEDULE, the Parties shall decide whether to extend it for one (1) or more years, with appropriate
updates to the RESEARCH AND DEVELOPMENT
<!-- page 147 -->
Made in two (2) copies.

Page 2 of 9

PLAN (Attachment A/2010 revision), and FUNDING (Article 6 of this SCHEDULE)."

5. The Parties agree that this Amendment III is deemed to have become effective as of March 31,
2010.

6. For the remainder, Schedule 1 remains unchanged and this Amendment III shall form an integral
part thereof.

ABERYSTWYTH UNIVERSITY CERES, INC. By: /s/ E. Reynolds By: /s/ Jefferson Gwyn Name: Emyr Reynolds
Name: Jefferson Gwyn Title: Head of Research Grants Title: Vice President of Breeding & Genomics By:
/s/ Richard Flavell Name: Richard Flavell, CBE, FRS Title: Chief Scientific Officer

Attachment A/2010 revision

RESEARCH AND DEVELOPMENT PLAN
<!-- page 148 -->
April 1, 2010 — March 31, 2011 workplan

Page 3 of 9

Confidential Treatment Requested and the Redacted Material has been separately filed with the
Commission

Action proposed Dates Performed Summary of action taken 1. Supply [***] from the [***] best [***] to
CERES partners in [***]

April 2010

Supplied [***], [***] checked [***] to [***] company as directed by CERES

2. Supply plants for [***] observation and miniplot trials

April to July 2010

Supplied [***] for the establishment of the following trials [***] 4 ON ([***]) [***] 5 MP (best
lines — [***] and [***]) [***] 1 ON (best lines — [***] and [***]) [***] 4 ON [***] 13 MP (best
[***] from [***], JKI etc.) [***] A9 ON ([***] survivors, [***], [***]) [***] A 10 ([***] survivors,
[***], [***]) [***] A11 RP (small plots of [***]) 3. Gather phenotyping data from [***] trials to
identify the most promising [***] to be used in [***]

July to November

Best [***] was identified based on autumn [***] scores. [***] 'Generic high [***] found in [***] at
[***] and [***]. Technical enabling A new [***] field nomenclature was developed to ensure clear
communication so that each plant or plot in the [***] trials was identified by a UID. Photographs
and data loaded to MSCAN and discussed at the January 2011 quarterly. Development of the controlled
vocabularies for phenotyping fields is ongoing. [***] data was recorded in [***] and [***] on the
[***] [***] data in Feb 2011 gathered but needs developed of the controlled vocabularies before this
can be loaded to MSCAN and analysed.
<!-- page 149 -->
Page 4 of 9

Confidential Treatment Requested and the Redacted Material has been separately filed with the
Commission

Action proposed Dates Performed Summary of action taken 4. Send [***] of the best selections from
[***] and [***] to [***] identified by June 2010

October

[***] Miscanthus samples for [***] under [***] on behalf of Dr. Charlie Rodgers. The Miscanthus
[***] in this package are provided under a research agreement between IBERS and CERES and are
restricted to release only to CERES, Inc. They are not [***].

6. Develop knowledge of [***] for [***] in a wide range of [***] in order to [***]

April — Oct

[***] experiments were run in 2010. Discovery of the [***] effect when plants were grown under
simulated [***] conditions.

5. Create [***] based on a knowledge of [***] available All year and ongoing Table shows number of
[***] attempted by [***] types.

Restricted: a form of [***] where [***] within a [***] has occurred and the plants have been [***]
to [***]. The potential [***] contributors can be short listed from the [***] monitoring data.
[***]: [***] wise [***] produce two [***] records since [***] contain both [***] and [***] parts.
[***]: single [***] [***]: Here the [***] from [***] are registered as [***] ops.

In 2010 encumbrances ([***] and [***]) stopped us going down the route of [***] M. [***] with the
well characterized [***] from [***].

[***] Type Number % [***] Produced >[***] [***] [***] [***] [***] [***] [***] [***] [***] [***]
[***] [***] [***] [***] [***] [***] [***] Total [***] [***] [***]
<!-- page 150 -->
April 1, 2011 — March 31, 2012 workplan

Page 5 of 9

Confidential Treatment Requested and the Redacted Material has been separately filed with the
Commission

Action proposed Dates Performed Summary of action taken 7. [***] experiments April to Oct A small
trial revealed the value of [***] in [***] of [***] M. [***] from [***]. 8. Leaf samples from DNA to
develop the [***] Oct Freeze dried samples sent to CERES from [***]

9. [***] from 2010 [***] raised for planting in [***] trials Jan — March [***] tests identified
successful [***]. A tray of each [***] was raised where possible (1 tray = [***] plants) 10. [***]
from 2010 [***] sent to CERES April 2011 From these [***] from [***] with interesting [***] were
sent to Charlie.

11. Reporting

Powerpoints of July 13 meeting sent Powerpoints of August 28 meeting sent Powerpoints of 1 and 2 Nov
meeting sent Document on forward plans (Nov 2010) Powerpoints of meeting 20-21 Jan 2011

milestone Projected Dates Summary of planned actions 1. Characterise [***] from the [***] to inform
development tracks 1 to 4

Ongoing

For [***] from the [***] we will perform measurements to collect:

[***] (when plants are [***] ([***] years from planting) [***] status in autumn [***] (scores and
measurements) 2. Development of [***]/ [***] with desirable characters

Ongoing

Attempt >[***] exploratory [***] between [***] in [***] of the [***] Perform at least [***] with
best [***] identified in [***] using the [***] and [***] in 2010 From these [***] of [***] and [***]
with interesting [***] to be sent to Charlie.
<!-- page 151 -->
Page 6 of 9

Confidential Treatment Requested and the Redacted Material has been separately filed with the
Commission

milestone Projected Dates Summary of planned actions 3. Development of [***] (CERES, IBERS)

Organize [***] phenotype data for use by CERES in collaboration with [***] (on a BBSRC funded
flowering grant) and [***] (on the [***]). Monitor [***] planted in 20[***] through collaboration
with [***] and the [***]. Supply of further leaf samples as requested for [***] analysis.
<!-- page 152 -->
Page 7 of 9

Confidential Treatment Requested and the Redacted Material has been separately filed with the
Commission

milestone Projected Dates Summary of planned actions 4. Initiate field evaluation of selected
potential new Miscanthus [***] and [***], measure [***] and other key [***].

April to Aug 2011

Notes [***] and [***] for [***] selections

Putative Trial name [***] 6 ST

plus [***] controls [***] 7 MP [***] blocks based on best [***] [***] 5 CB [***] blocks based on
best [***] [***] 6 CB [***] blocks based on best [***] [***] 7 CB [***] blocks based on best [***]
[***] 8 CB [***] testing [***] 9 ON miniplots, sue's choices [***] 3 MP miniplots, sue's choices
[***] 25 MP [***] from 2010 [***] [***] 26 ST [***] [***] 27 CB [***] [***] 28 CB [***] which are
now in [***]' [***] 29 ON Library of [***] used in [***] (E.G. #1 To 5'S) [***] 30 ON Selected lines
into [***] [***] 3 ON Sue's MP selections [***] 1 MP
<!-- page 153 -->
Page 8 of 9

Confidential Treatment Requested and the Redacted Material has been separately filed with the
Commission

milestone Projected Dates Summary of planned actions 5. [***] and [***]

Ongoing

[***] of [***] currently being raised from use in [***] will be supplied to [***]. [***] screens on
[***] to be performed and added to MSCAN. 6. [***] experiments Field experiments with direct sowing
using [***]. 7. Reporting Minutes and powerpoints from meetings

Attachment B/2010 revision
<!-- page 154 -->
Budget

CERES shall pay IBERS £[***] (GBP) per year for the implementation of the RESEARCH AND DEVELOPMENT
PLAN set forth in Attachment A/2010 revision. Annual payments from CERES to IBERS shall not exceed
£[***] (GBP).

Payment details shall be as set forth in Article 1.8 of the Collaboration Agreement.

"1.8 Where a SCHEDULE provides that CERES will make a financial contribution to certain RESEARCH
PROJECT activities performed by IBERS, unless agreed otherwise in the appropriate SCHEDULE, IBERS
will submit invoices after the end of each calendar quarter for the work performed during that
quarter. Each such invoice shall reflect only those costs that have been incurred in performance of
the RESEARCH PROJECT and shall provide a breakdown of costs similar to the detail set forth in the
budget of the related SCHEDULE. CERES will pay all such invoices within thirty (30) days after the
invoice date. Payments shall be remitted to:

Institute of Biological, Environmental and Rural Sciences ("IBERS") of Aberystwyth University Plas
Gogerddan Aberystwyth Ceredigion SY23 3EB United Kingdom"

Page 9 of 9 Confidential Treatment Requested and the Redacted Material has been separately filed
with the Commission.
