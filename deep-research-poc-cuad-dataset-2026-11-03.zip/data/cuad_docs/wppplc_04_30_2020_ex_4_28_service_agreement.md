<!-- page 1 -->
# SERVICE AGREEMENT
| Field | Value |
|---|---|
| Document Type | Service Agreement |
| Agreement Date | 2019-10-01 |
| Parties | WPP 2005 LIMITED ("Company"); JOHN ROGERS ("Executive") |
| Source | CUAD v1 / WPPPLC_04_30_2020-EX-4.28-SERVICE AGREEMENT |

Table of Contents

Exhibit 4.28

SERVICE AGREEMENT

1 OCTOBER 2019

WPP 2005 LIMITED

and

JOHN ROGERS
<!-- page 2 -->
Table of Contents

CONTENTS Clause Page

1. Interpretation 3 2. Commencement of Appointment 4 3. Executive's Duties 4 4. Place of Work 5 5.
Working Hours 5 6. Remuneration 5 7. Expenses 6 8. Pensions 6 9. Insurances 7 10. Sickness Absence 8
11. Holidays 8 12. Other Interests 8 13. Confidential Information 9 14. Intellectual Property 10 15.
Termination of Employment 12 16. Garden Leave 14 17. Office as a Director 14 18. Protective
Covenants 15 19. Data Protection 15 20. Grievance and Disciplinary Procedure 15 21. Collective
Agreements 16 22. General 16

Signatories 16

Schedule

1. Power of Attorney 17 2. Incentive Plans 18 3. Protective Covenants 21
<!-- page 3 -->
Table of Contents

THIS AGREEMENT is made on 1 October 2019

BETWEEN: (1) WPP 2005 LIMITED (registered number 01003653) whose registered office is at Sea
Containers, 19 Upper Ground, London SE1 9GL (the Company) (2) JOHN ROGERS (the Executive).

IT IS AGREED as follows: 1. INTERPRETATION 1.1 In this Agreement:

Appointment means the employment of the Executive by the Company on and subject to the terms of this
Agreement;

Board means the board of directors of the Company or any committee of the board duly appointed for
the purpose in question, from time to time;

Financial Year means the Company's financial year ending on 31 December each year;

Group means the Company, any holding company of the Company, and any holding company of the holding
company from time to time, together with any subsidiary of the Company or its holding company or the
holding company of its holding company, and Group Company means any one of them;

holding company and subsidiary shall, as the context so permits, have the meaning given by section
1159 of the Companies Act 2006 or under relevant applicable laws in Jersey;

Recognised Investment Exchange means a relevant EEA market as defined in, or a market established
under, the rules of any investment exchange specified in schedule 3 to the Financial Services and
Markets Act 2000 (Financial Promotion) Order 2005;

Compensation Committee means the committee of non-executive directors as appointed by the Board of
WPP plc from time to time for the purposes of determining the Company's policy on executive
remuneration;

Termination Date means the date on which the Appointment terminates for whatever reason; and

UK Listing Authority means the FCA, acting in its capacity as the competent authority for the
purposes of part VI of the Financial Services and Markets Act 2000. 1.2 A reference to a particular
law is a reference to it as it is in force for the time being, taking account of any amendment,
extension or re-enactment, and includes any subordinate legislation for the time being in force made
under it. 1.3 The headings in this Agreement are for convenience only and do not affect its
interpretation. 3
<!-- page 4 -->
Table of Contents

2. COMMENCEMENT OF APPOINTMENT 2.1 The Appointment will begin on 27 January 2020 or such other date
as the parties shall agree and when the Executive is not subject to any restrictions to prevent the
commencement of his employment with the Company. There is no period of previous employment with the
Company. 2.2 The Appointment may be terminated in accordance with clause 15 (or in furtherance of
any right either party may have at common law). 3. EXECUTIVE'S DUTIES 3.1 The Executive shall serve
the Company as Chief Financial Officer and as an Executive Director of WPP plc, and/or in such other
capacity or capacities, within the Group as the Company may reasonably require from time to time,
but subject always to it being consistent with his status, skills and experience. 3.2 During the
Appointment the Executive shall: (a) diligently exercise such powers and perform such duties as may
from time to time be assigned to him by the Board of WPP plc; (b) accept any offices or
directorships as reasonably required by the Company; (c) use his best endeavours to promote,
protect, develop and extend the business of the Company and any Group Company; (d) comply with all
reasonable and lawful directions given to him by the Board of WPP plc; (e) comply with all policies
and procedures of the Company and/or the Group. The Executive's attention is drawn, in particular,
but without limitation, to the Company's data protection, anti-bribery and corruption and expenses
policies and the WPP Code of Conduct; (f) comply with all requirements, recommendations or
regulations of any regulatory authority which is relevant to the Executive's role and/or to the
Company or any relevant Group Company; (g) promptly make such reports to the Board of WPP plc in
connection with the affairs of the Company or any Group Company on such matters and at such times as
are reasonably required; (h) report to the Board of WPP plc his own wrongdoing and any wrongdoing or
proposed wrongdoing of any other employee who reports to him or a director of the Company or any
Group Company, to the extent he has first-hand knowledge of such wrongdoing or proposed wrongdoing
by such employee or director, promptly on becoming aware of it; (i) comply with the articles of
association (as amended from time to time) of any Group Company of which he is a director; (j) abide
by all statutory, fiduciary or common law duties to the Company or any Group Company of which he is
a director; (k) do such things as are necessary to ensure compliance by himself and the Company or
any relevant Group Company with the UK Corporate Governance Code of the UK Listing Authority (as
amended from time to time); 4
<!-- page 5 -->
Table of Contents

(l) comply with all requirements, recommendations or regulations, as amended from time to time, of
the UK Listing Authority, the Market Abuse Regulation (596/2014/EU), the FCA and all other
regulatory authorities relevant to the Company or any Group Company and any code of practice issued
by the Company (as amended from time to time) relating to dealing in the securities of the Company
or any Group Company; and (m) comply with the requirements under both legislation and regulations on
insider dealing. 4. PLACE OF WORK 4.1 The Executive's normal place of work shall be the Company's
head office in the UK from time to time as the Company may reasonably determine, for the proper
performance of his duties. The Executive shall travel to such places (inside and) outside the UK as
may be required in order to properly perform his duties, in particular, to the head office in the
USA. In connection therewith, the Executive is likely from time to time to be required to work
outside the UK for periods exceeding one month. 4.2 There are currently no additional terms which
apply where the Executive is required to work outside the UK for a period exceeding one month, but
the Company reserves the right to issue such terms, and any such terms will be notified to the
Executive. 5. WORKING HOURS 5.1 The parties agree that the Executive's role and senior status are
such that the Executive will determine the whole of his working time himself and his working time
cannot be measured or pre-determined and, accordingly, that the Appointment falls within the scope
of Regulation 20 of the Working Time Regulations 1998, meaning that the restrictions on working time
set out in the Working Time Regulations do not apply to him. 5.2 During the Appointment, unless
prevented by ill-health or accident and except during holiday taken in accordance with clause 11,
the Executive shall devote the whole of his time, skill and attention during normal business hours,
and at such other times as may be reasonably necessary (without additional remuneration), to his
duties under this Agreement. 6. REMUNERATION 6.1 The Company will pay the Executive a salary of
£740,000 and a fixed benefits allowance of £30,000 per annum. The salary (and so far, as is
reasonably possible) the benefits allowance will accrue from day to day and be payable in equal
instalments in arrears on or around the 25th day of every month, less deductions for income tax and
National Insurance contributions and shall be inclusive of any fees receivable by the Executive as a
director of any Group Company. 6.2 The Executive's salary will be reviewed by the Compensation
Committee every two years. There will be no salary review after notice to terminate this Agreement
has been given by either party. The Company has no obligation to increase the Executive's salary
following a review. 6.3 The Executive will be eligible to participate in any bonus or discretionary
remuneration plan on such terms as the Compensation Committee may from time to time decide and
always subject to the terms of the Executive Remuneration policy as approved by shareholders of WPP
plc and to additional terms and conditions including the malus and clawback provisions of all
relevant share or stock plans and as referred to in Schedule 2. 6.4 Any bonus payment to the
Executive shall be purely discretionary and shall not form part of the Executive's contractual
remuneration under this Agreement. Payment of a bonus to the Executive in 5
<!-- page 6 -->
Table of Contents

one year shall confer no right on the Executive to receive a bonus in any other year. Specifically,
but without limitation, the Executive shall have no right to be considered for, or payment of, a
bonus where the Executive is subject to, or may about to be subject to, an ongoing investigation or
disciplinary process into facts or matters which could lead to such bonus being forfeited, or
reduced and in all events if the Appointment has terminated for any reason or if he is under notice
of termination whether given by the Executive or the Company at or prior to the date when a bonus
might otherwise have been payable. For the avoidance of doubt, if the Executive is exonerated of any
of the allegations made during any such disciplinary process or if any investigation does not result
in any material action against the Executive, he will (once the disciplinary process or
investigation is concluded) have the right to be considered for a bonus as if there had been no such
investigation or disciplinary process. If any bonus becomes payable in such circumstances it will be
paid without delay following the conclusion of the disciplinary process or investigation. 6.5 The
Executive hereby irrevocably consents to the Company, at any time during the Appointment or on its
termination (however arising), deducting from salary or any other payments due to the Executive in
respect of the Appointment any monies due from him to the Company or any Group Company. 6.6 The
Executive agrees that every benefit arising out of or in connection with his employment whilst he
remains a director is subject to change (including detrimental change without compensation) where
any particular benefit paid, or otherwise owing or becoming payable to him in the future, breaches
or may breach the terms of the shareholder approved Executive Compensation Policy at any time. 7.
EXPENSES

The Company will reimburse the Executive (on production of such evidence as it may reasonably
require) the amount of all travelling and other expenses properly and reasonably incurred by him in
the discharge of his duties in strict accordance with the Company's expenses policy from time to
time. 8. PENSION 8.1 The Company operates a Group pension plan (the Plan). The Executive is entitled
to participate in the Plan (or such pension scheme as may be established by the Company to replace
the Plan), subject to its trust deeds and rules from time to time. The Executive has opted out of
the Plan. Whilst his status remains so, he will receive in lieu the annual sum of 10% of his current
salary, paid monthly in instalments, together with his salary. 8.2 The Company reserves the right to
terminate the Plan at any time without replacing it. In this event, and assuming he is, or has been,
a member, the Executive's rights (if any) will be in accordance with the said trust deeds and rules.
8.3 The Executive has been grated Fixed Protection. The Company acknowledges that once the Executive
has informed the Company that he has Fixed Protection, under Regulation 5D of the Occupational and
Personal Pension Schemes (Automatic Enrolment) Regulations 2010 it does not need to
automatically-enrol or automatically re-enrol the Executive into a pension scheme. The Company
therefore agrees not to enrol the Executive in the Plan or any other pension scheme at any time
after the Executive has informed the Company that he has Fixed Protection 2016,

The Company agrees in the meantime that it will not enrol the Executive into the Plan or any other
pension scheme unless it is compelled to do so by law or the parties agree in writing otherwise. If
the Company is compelled to enrol the Executive into the Plan or another pension scheme under law,
or the Executive opts to join the Plan or any other pension scheme the Executive acknowledges and
agrees that: 6
<!-- page 7 -->
Table of Contents

(a) the Company has no liability to him if payment of any contribution to, or the provision of any
benefit under, the Plan (whether by itself or when aggregated with any contribution to or any
increase in value of the Executive's rights under any other arrangement) gives rise to an annual
allowance or lifetime allowance charge (within the meaning of the Finance Act 2004) and that the
Company has no responsibility to make any enquiry or advise the Executive as to the possibility of
any such charge; (b) he is liable for reporting and paying any such charge in accordance with the
Finance Act 2004; and (c) the Company has no liability to him in respect of any loss for any reason
of enhanced protection, fixed protection, fixed protection 2014, fixed protection 2016 or any
similar protection allowed in future (for the purposes of the Finance Act 2004) if applicable to the
Executive. 9. INSURANCES 9.1 In partial spend of the fixed benefits allowance referred to in
sub-clause 6.1, the Executive and his spouse or civil partner and any children under the age of 21
(or 24 if in full time education) are entitled to membership of a private medical insurance scheme.
9.2 The Executive is entitled to membership of a Group income protection plan and life assurance
cover, which will be paid for by the Company. 9.3 Participation in all insurance schemes from time
to time is subject to: (a) the terms of the relevant insurance scheme, as amended from time to time;
(b) the rules or the insurance policy of the relevant insurance provider, or WPP Healthcare Trust as
amended from time to time; and (c) the Executive (and where relevant any other potential
beneficiary) satisfying the normal underwriting requirements of the relevant insurance provider and
the premium being at a rate which the Company considers reasonable. 9.4 If the insurer refuses for
any reason to provide the benefit to the Executive (or any relevant dependant) the Company shall not
be liable to provide to the Executive any replacement benefit of the same or similar kind or to pay
any compensation in lieu of such benefit. Full details of the insurance schemes are available from
the Company's Worldwide Compensation and Benefits Director. 9.5 For the avoidance of doubt, the
Company's sole obligations in respect of the insurance benefits referred to in sub clause 9.1 and
9.2 is to pay the premia from time to time requested by the provider and to pay to the Executive any
sums as may from time to time be received by the Company from the provider in respect of any claim
made by the Executive (for him or a dependent) under any insurance scheme. 9.6 The Company shall
have the right at its sole discretion to alter the cover provided or any term of any insurance
scheme or to cease to provide (without replacement) any insurance scheme or cover at any time. 9.7
The Executive is entitled to the benefit of any indemnity in the Company's articles of association
and may also entitled to the benefit of cover under such directors and officers liability insurance
policy as may be maintained by the Company from time to time. 7
<!-- page 8 -->
Table of Contents

10. SICKNESS ABSENCE 10.1 If the Executive cannot attend work due to sickness or injury, the
Executive will keep the Chairman informed of his condition and, where the absence lasts for a period
of seven calendar days or more, the Executive will (at the request of the Company) produce a
doctor's certificate to the Company in respect of his absence. (a) Provided the Executive complies
with the Company's sickness absence notification and certification requirements, the Executive shall
be entitled to receive his full salary and contractual benefits during any period of sickness
absence not exceeding 26 weeks in any rolling period of 12 months. These payments shall be inclusive
of any Statutory Sick Pay due. No payment of salary will be made during any subsequent period of
absence when the Executive is eligible to receive benefits under the Group income protection plan
referred to in sub clause 9.2. 10.2 If the Company so reasonably requires, the Executive agrees to
consent to a medical examination by a medical practitioner nominated by the Company, at the
Company's expense. The Executive agrees that the Company may have access to reports and results
produced in connection with any such examination and that it may discuss the contents of the report
with the relevant medical practitioner, subject to the Executive being given the opportunity to
review and comment on the report before it is disclosed to anyone within the Company. 10.3 If the
Executive is absent due to illness for more than one month, the Board shall be entitled at any time
thereafter to appoint an executive director or employee to perform the Executive's duties and to
exercise his powers until the Executive is able to resume his duties, following which such
substitute will cease to act in the Executive's role. 10.4 The Company reserves the right to
terminate the Appointment under the terms of this Agreement even when this would or might cause the
Executive to forfeit any entitlement to sick pay or Group income protection benefit. 11. HOLIDAYS
11.1 The Company's holiday year runs from 1 January to 31 December (the Holiday Year). The Executive
is entitled to 25 days' paid holiday in addition to the usual public or bank holidays in England) in
every Holiday Year, to be taken at times convenient to the Company. 11.2 No accrued but untaken
holiday may be carried forward to the next holiday year and will lapse unless the Executive has been
prevented from taking holiday due to sickness or statutory family leave to which he is or may be
entitled further to Company policy from time to time. 11.3 The Company reserves the right to require
the Executive to take any outstanding holiday during any period of notice of termination of
employment or to make a payment in lieu of holiday outstanding at the Termination Date. If, at the
Termination Date, the Executive has taken more holiday than he has accrued, the Executive hereby
expressly consents to the Company deducting an appropriate amount from any payments otherwise due
him. Deductions and payments in lieu of holiday are to be calculated on the basis that a day's
holiday is equal to 1/260 of the Executive's basic salary. 12. OTHER INTERESTS

During the Appointment, the Executive may not accept any employment with or appointment to any
office, whether paid or unpaid, in relation to anybody, whether corporate or not (other than a Group
Company), or directly or indirectly be interested in any manner in any other business except: 8
<!-- page 9 -->
Table of Contents

(a) as holder or beneficial owner (for investment purposes only) of any class of securities in a
company if those securities are listed or dealt in on a Recognised Investment Exchange and the
Executive (together with his spouse, children, parents and parents' issue) neither holds nor is
beneficially interested in more than 1% of the securities of that class; or (b) with the consent in
writing of the Company, which may be given subject to any terms which the Company requires. 13.
CONFIDENTIAL INFORMATION 13.1 In this clause 13, Confidential Information means information (whether
or not recorded in documentary form, or stored on any magnetic or optical disk or memory) relating,
without limitation, to the business, clients, customers, products, affairs and finances of the
Company or any Group Company for the time being confidential to the Company or any Group Company or
in relation to which the Company or any Group Company is subject to a duty of confidentiality and
trade secrets including, without limitation, technical data and know-how relating to the business of
the Company or any Group Company or of any persons having dealings with the Company or any Group
Company, whether or not such information (if it is not in oral form) is marked confidential, and
includes, without limitation: (a) existing and prospective activities of the Company or any Group
Company, including timing, business plans and financial information; (b) existing and prospective
terms of business, prices and pricing strategies and structures, profit margins, trading
arrangements, discounts and rebates of the Company or any Group Company; (c) existing and
prospective marketing information, plans, strategies, tactics and timing relating to the Company or
any Group Company; (d) existing and prospective lists of suppliers and rates of charge relating to
the Company or any Group Company; (e) existing and prospective financial and other products or
services, including applications, designs, technical data and qualifications relating to the Company
or any Group Company; (f) existing and prospective software applications relating to the Company or
any Group Company; (g) information relating to existing and prospective officers, employees and
consultants of the Company or any Group Company including their engagement, their contractual terms
including commission and bonuses and information relating to the termination of their employment or
appointment with the Company or any Group Company; (h) any disputes and litigation proposed, in
progress or settled in relation to the Company or any Group Company; (i) any invention, technical
data, know-how or other manufacturing information of the Group or its customers/clients; and (j)
existing and prospective research and development activities. 13.2 The Executive must not make use
of or divulge to any person or entity, and must use his best endeavours to prevent the unauthorised
use, publication or disclosure of, any Confidential 9
<!-- page 10 -->
Table of Contents

Information which is disclosed or made available to the Executive, either directly or indirectly,
during the course of, or in connection with, the Executive's employment or his holding any office
within the Group from any source within the Company or any Group Company and shall be under an
obligation promptly to report to the Group any such unauthorised use or disclosure which comes to
his knowledge. 13.3 This clause 13 does not apply to information which: (a) is used or disclosed in
the proper performance of the Executive's duties or with the prior written consent of the Company or
any Group Company; (b) is ordered to be disclosed by a court of competent jurisdiction or otherwise
required to be disclosed by law; (c) is already in the public domain (other than as a result of
unauthorised disclosure by the Executive or any other person); or (d) is already lawfully possessed
by the Executive without any obligations of confidentiality or restrictions on use. 13.4 The
Executive shall not, during the Appointment or at any time thereafter, make, except for the benefit
of the Company or any Group Company, any copy, record or memorandum (whether or not recorded in
writing or on computer disk or tape) of any Confidential Information and any such copy, record or
memorandum made by the Executive during the Appointment shall be and remain the property of the
Company and accordingly shall be returned by the Executive to the Company on the Termination Date or
when required to do so by the Company. 13.5 The Executive shall not other than in the ordinary
course of the Appointment without the prior written consent of the Board either directly or
indirectly publish any opinion, fact or material or deliver any lecture or address or participate in
the making of any film, radio broadcast or television transmission or communicate with any
representative of the media or any third party relating to: (a) the business or affairs of the
Company or of any other Group Company or to any of its or their officers, employees, customers,
clients, suppliers, distributors, agents or shareholders; or (b) the development or exploitation of
any Intellectual Property Rights, including Confidential Information. 13.6 Each of the restrictions
in each sub clause above will be enforceable independently of each of the others and its validity
will not be affected if any of the others are invalid. If any of those restrictions are void but
would be valid if some part of the restriction were deleted, the restriction in question will apply
with such modification as may be necessary to make it valid. 13.7 For the avoidance of doubt,
nothing in this Agreement precludes the Executive from making a protected disclosure within the
meaning of Part 4A (Protected Disclosures) of the Employment Rights Act 1996. 14. INTELLECTUAL
PROPERTY 14.1 For the purposes of this Agreement, the following definitions shall apply: (a)
Intellectual Property Rights means: (i) copyrights, moral rights, patents, inventions, know-how,
Confidential Information, database rights, brands, business names, domain names, 10
<!-- page 11 -->
Table of Contents

and rights in trademarks, service marks and designs (whether registered or unregistered); (ii)
applications for registration, and the right to apply for registration, and registrations for any of
the same, and any renewals, reissues, extensions, continuations or divisions thereof; (iii) rights
to use such assets listed in subparagraphs (i) and (ii) under licences, consents, orders, statutes
or otherwise; and (iv) all other intellectual property rights and equivalent or similar forms of
protection now or hereafter existing anywhere in the world. (b) IP Materials means all documents,
software, photographic or graphic works of any type, and other materials in any medium or format
which are created by or on behalf of the Executive in the course of performing his obligations under
this Agreement and which are protected by or relate to Intellectual Property Rights. 14.2 Any
Intellectual Property Rights created by the Executive or arising in the course of his employment or
his performing his obligations under this Agreement shall belong to and vest in the Company. 14.3 To
the extent that ownership of Intellectual Property Rights does not vest in the Company by operation
of law, the Executive hereby assigns to the Company his entire right, title and interest in all
Intellectual Property Rights which arise in the course of performing his obligations under this
Agreement (including all present and future copyright, and copyright revivals and extensions). This
assignment shall take effect upon the creation of each of the Intellectual Property Rights but if
for any reason this does not occur, he agrees that he will hold all such Intellectual Property
Rights on trust for the benefit of the Company until such time as it does. 14.4 The Executive agrees
to sign all documents and to do all other acts which the Company requests (at its expense) to enable
the Company to enjoy the full benefit of this clause 14. This includes joining in any application,
which may be made in the Company's sole name for registration of any Intellectual Property Rights
(such as a patent, trademark or registered design), and assisting the Company in defending and
enforcing such rights during and after the employment (at the Company's expense). 14.5 Without
prejudice to the generality of clause 13 (Confidential Information), the Executive may only use the
Intellectual Property Rights and IP Materials to perform his obligations under this Agreement, and
shall not disclose any Intellectual Property Rights or IP Materials to any third party without the
express prior written consent of the Company. 14.6 The Executive waives all moral rights in IP
Materials to which he may otherwise be entitled under the law of any relevant jurisdiction and which
cannot be vested or assigned pursuant to sub clause 14.2 or 14.3. To the extent that any moral
rights cannot be waived under the laws of any relevant jurisdiction, the Executive agrees that he
will not enforce such rights. 14.7 The Executive shall promptly transfer to the Company all IP
Materials in his possession or under his control as at the Termination Date, or at any time when the
Company requests. No copies or other record of any IP Materials may be retained by the Executive
except with the prior written consent of the Company. 14.8 The Executive understands and accepts
that the remuneration and benefits provided to him by the Company in accordance with this Agreement
constitute sufficient consideration to the Executive for the performance of his obligations under
this clause 14 including, for the avoidance of doubt, the waiver of or covenant not to assert any
moral rights that he may have. 14.9 This clause 14, and the rights and obligations of the parties
contained herein, shall survive expiry of this Agreement, or its termination, for any reason. 11
<!-- page 12 -->
Table of Contents

15. TERMINATION OF EMPLOYMENT 15.1 The Appointment may be terminated by either party giving the
other at least 12 months' notice in writing. 15.2 The Company may in its sole and absolute
discretion (whether or not any notice of termination has been given under sub clause 15.1) terminate
this Agreement at any time and with immediate effect by giving notice in writing to the Executive
that the Company is exercising its rights pursuant to this clause 15. If the Company elects to
terminate the Executive's employment in this way, it will make, within 30 days, either the first
instalment (of equal monthly instalments) of a, or an entire, payment in lieu of notice (Payment in
Lieu) equal to the basic salary, benefit allowance and any benefits, as at the Termination Date,
which the Executive would have been entitled to receive under this Agreement during the notice
period referred to at sub clause 15.1 (or, if notice has already been given, during the remainder of
the notice period), less all relevant deductions for income tax and National Insurance
contributions. For the avoidance of doubt, the Payment in Lieu shall not include any element in
relation to: (a) any bonus or discretionary payment(s) that might otherwise have been due during the
period for which the Payment in Lieu is made; and (b) any payment in respect of any holiday
entitlement that would have accrued during the period for which the Payment in Lieu is made. 15.3
The Company may pay any sums due under sub clause 15.2 in equal monthly instalments until the date
on which the notice period referred to at sub clause 15.1 would have expired if notice had been
given (the Payment Period). 15.4 The Payment in Lieu is at all times conditional on the Executive
informing the Company immediately in the event that he receives, or has a right to receive,
remuneration from any source in respect of his employment or the provision of his services during
the Payment Period or relating to the Payment Period (remuneration shall include any salary, fee or
other benefit). 15.5 If the Executive obtains alternative employment or an alternative engagement
during the Payment Period any further monthly instalments of the Payment in Lieu will be reduced on
a pro rata basis by any payment or remuneration in respect of such alternative employment or
alternative engagement during the Payment Period or relating to the Payment Period. 15.6 The
Executive shall have no right to receive a Payment in Lieu unless the Company has exercised its
discretion in sub clause 15.2. 15.7 Nothing in this clause 15 shall prevent the Company from
terminating the Appointment in breach of contract or of common law. 15.8 If the Executive: (a) in
the reasonable opinion of the Board fails or neglects efficiently and diligently to discharge his
duties, including, without limitation his duties under Chapter 2 of part 10 of the Companies Act
2006, or is guilty of any serious or repeated material breach of his obligations under this
Agreement and, if that material breach is remediable, fails to remedy the breach within a period of
21 days after being notified in writing to do so; (b) is guilty of any fraud, dishonesty, serious
misconduct or any other conduct which, in the reasonable opinion of the Board, brings or is likely
to bring the Executive or the Company or 12
<!-- page 13 -->
Table of Contents

any Group Company into disrepute or affects or is likely to affect prejudicially the interests of
the Company or the Group; (c) is convicted of an arrestable offence (other than a road traffic
offence for which a non-custodial penalty is imposed); (d) is guilty of any material breach or
material non-observance of any code of conduct, requirement, rule or regulation referred to in sub
clause 3.2; (e) becomes bankrupt or makes any arrangement or composition with his creditors; (f) is
prohibited from being a director by law; (g) resigns as a director without the Company's prior
consent; (h) has become physically or mentally incapable of acting as a director and may remain so
for more than six months, according to a written opinion issued in relation to the Executive to the
Company from a registered medical practitioner who is treating the Executive; or (i) is not or
ceases to be eligible to work in the UK,

the Company may by written notice to the Executive terminate this Agreement with immediate effect.
15.9 The Company's rights under clause 15.8 are without prejudice to any other rights that it might
have at common law to terminate the Appointment or to accept any breach of this Agreement by the
Executive as having brought the agreement to an end. Any delay by the Company in exercising its
rights shall not constitute a waiver thereof. 15.10 On the Termination Date or, at the request of
the Board on either party giving notice to terminate this Agreement, the Executive will immediately:
(a) deliver to the Company all other property in his possession, custody or under his control
belonging to any Group Company including (but not limited to) computers and any other electronic
devices, business cards, credit and charge cards, security passes, original and copy documents or
other media on which information is held in his possession relating to the business or affairs of
any Group Company; and (b) to the extent possible, irretrievably delete (without keeping any copies
in any format) any information relating to the business or affairs of the Company or any Group
Company or any of its or their business contacts from any computer or communications systems,
including any website or email account, owned or used by the Executive outside the Company's
premises and notify the Company of any passwords the Executive used in relation to its computer
system. 15.11 If the Executive's rights or benefits under any share option or share incentive scheme
in which the Executive may participate (as set out at the date hereof in Schedule 2) are affected by
the termination of the Employment, his rights will be determined solely in accordance with the rules
of the relevant scheme and the Executive shall not be entitled to any compensation for the loss of
any rights or benefits under such scheme. 15.12 If the Appointment is terminated for the purpose of
the reconstruction or amalgamation of the Company or by reason of the Company transferring all or a
substantial part of its business to another company and the Executive is offered employment by the
reconstructed or amalgamated or transferee company on similar terms to the terms of this Agreement,
the Executive will have no claim 13
<!-- page 14 -->
Table of Contents

against the Company or such reconstructed or amalgamated or transferee company in respect of the
termination of the Appointment. 16. GARDEN LEAVE 16.1 Following service of notice to terminate the
Appointment by either party or if the Executive purports to terminate the Appointment in breach, the
Board may suspend all or any of the Executive's duties and powers for such periods and on such terms
as he considers expedient and this may include a term that: (a) the Executive must stay away from
all or any of the Company's premises, and/or (b) will not be provided with any work, and/or (c) will
have no business contact with all or any of the Group's agents, employees, customers, clients,
distributors and suppliers, and/or (d) will have no access to the Company's communications systems.

(referred to as Garden Leave). 16.2 During any period of Garden Leave the Company will continue to
pay the Executive's salary, benefits allowance and maintain the benefits to which he is
contractually entitled prior to the commencement of his Garden Leave (for the avoidance of doubt the
Executive shall not be entitled to any bonus or discretionary payment(s) during any period of Garden
Leave). 16.3 During any period of Garden Leave may appoint a replacement to exercise any of the
Executive's duties and responsibilities and may require the Executive to take such actions as he
reasonably requires to effect a proper handover of any of his duties and responsibilities.
Alternatively, the Company may require the Executive to carry out exceptional duties or special
projects outside the normal scope of his duties and responsibilities (provided such projects are
broadly commensurate with his status). 16.4 During any period of Garden Leave the Executive's
employment will continue and the Executive will continue to be bound by his obligations under this
Agreement and by his general duties of fidelity and good faith (and, where applicable, as a
fiduciary). The Executive agrees that the Company may, if it so chooses, announce to third parties
that the Executive has resigned or been given notice (as the case may be) but the Executive will not
make any comment on his status or change of duties, except to confirm he is on garden leave. 17.
OFFICE AS A DIRECTOR 17.1 Any office or directorship which the Executive holds in any Group Company
is subject to the articles of association of the relevant company from time to time. 17.2 The
Executive is required to familiarise himself with all his responsibilities as a director, legal
and/or otherwise. 17.3 Upon termination of this Agreement, or on the Board's request, the Executive
will resign from any office held by him in any Group Company without any claim for compensation.
17.4 The Executive shall, at the time of signing this Agreement, appoint the Company as his attorney
by executing a Power of Attorney in the form set out in Schedule 1 so that the Company can give
effect to the provisions of sub clause 17.3 above and clause 14 above as required. 14
<!-- page 15 -->
Table of Contents

17.5 In the event that the Executive fails to be re-elected as a director of any Group Company, or
if the Executive resigns as a director of any Group Company at the Company's request, this Agreement
shall not automatically terminate and the Executive will continue as an employee of the Company
unless and until either party elect to terminate the employment (either in accordance with clause
15.1, or where the Company may have a right to terminate his employment summarily under clause 15 or
at common law). 17.6 The Executive must not resign from any directorship or office of any Group
Company, except on termination of this Agreement (by either party), on the Board's request or as
provided in the articles of association of the Company, and he must not do anything that would cause
him to be disqualified from continuing to act as a director. 18. PROTECTIVE COVENANTS 18.1 The
Executive acknowledges that his senior position with the Company and any Group Company gives him
access to and the benefit of confidential information vital to the continuing business of the
Company and any Group Company and influence over and connection with the Company's customers,
clients, suppliers, distributors, agents, employees, workers, consultants and directors and those of
any Group Company in or with which the Executive is engaged or in contact and acknowledges and
agrees that the provisions in Schedule 3 are reasonable in their application to him and necessary
but no more than sufficient to protect the interests of the Company and any Group Company. 18.2 If
any person offers to the Executive any arrangement, contractual or otherwise, and whether paid or
unpaid, which might or would cause the Executive to breach any of the covenants in Schedule 3, he
will notify that person of the terms of that Schedule 3 and provide that person with a complete copy
of it. 19. DATA PROTECTION 19.1 The Company takes its data protection obligations very seriously and
complies with its legal obligations under the General Data Protection Regulation and the Data
Protection Act 2018 to protect the privacy and security of the Executive's personal information. As
a data controller the Company is required to inform the Executive how we hold and use his
information. 20. GRIEVANCE AND DISCIPLINARY PROCEDURE 20.1 If the Executive is dissatisfied with any
disciplinary decision relating to him, including any decision to dismiss him, he will have the right
to appeal to the Chairman of WPP plc, whose decision will be final. 20.2 If the Executive seeks to
redress any grievance relating to his employment, the Executive should raise this in the first
instance with the Chairman. If the matter is not satisfactorily resolved, the Executive should then
apply in writing to the Board and the Board's decision will be final. 20.3 The Company may suspend
the Executive from any or all of his duties for as long as is reasonably necessary to investigate
any matter in which the Executive is implicated or involved, whether directly or indirectly, or in
the event that the Company believes that the Executive's presence in the office would be detrimental
to any investigation or to other employees or to the Executive. The provisions of clause 16.1 (a) to
(d) and 16.2 will apply during any such period of suspension, with any additional terms depending on
the circumstances that may be notified to the Executive in writing at that time. 15
<!-- page 16 -->
Table of Contents

21. COLLECTIVE AGREEMENTS

The Company is not a party to any collective agreement which affects the Executive's employment. 22.
GENERAL 22.1 This Agreement is governed by and construed in accordance with English law, save where
provided otherwise herein. 22.2 The parties irrevocably agree that the courts of England and Wales
shall have exclusive jurisdiction to settle any dispute or claim that arises out of or in connection
with this Agreement or its subject matter or formation (including non-contractual disputes or
claims). 22.3 This Agreement contains all the information which is required to be provided to the
Executive under section 1 of the Employment Rights Act 1996. 22.4 As from the effective date of this
Agreement, all other agreements or arrangements between the Company or any Group Company relating to
the employment of the Executive cease to have effect. This Agreement (and the documents referred to
within it, including but not limited to the share plans that the Executive participates in from time
to time) comprises the whole agreement between the Executive and the Company relating to the
Executive's employment by the Company. 22.5 Each Group Company shall have the right under the
Contracts (Rights of Third Parties) Act 1999 to enforce the rights bestowed on it by this Agreement.
The consent of a Group Company is not required to amend any terms of this Agreement. Except as set
out in this clause 22, a person who is not a party to this Agreement may not enforce any of its
provisions under the Contracts (Rights of Third Parties) Act 1999. 22.6 This Agreement may be
executed in any number of counterparts, each of which, when executed, shall constitute a duplicate
original, but all the counterparts shall together constitute the one agreement.

AS WITNESS the hands of the Executive and of the duly authorised representatives of the Company on
the date which appears first on page 1.

SIGNATORIES SIGNED by WPP 2005 LIMITED acting by MARK READ ) /s/ Mark Read

SIGNED by JOHN ROGERS ) /s/ John Rogers 16
<!-- page 17 -->
Table of Contents

SCHEDULE 1 POWER OF ATTORNEY

By this Power of Attorney made on 1 October 2019, I JOHN ROGERS in accordance with the terms of my
service agreement (the Service Agreement) with WPP 2005 Limited (the Company) dated today HEREBY
APPOINT the Company to act as my attorney with authority in my name and on my behalf (so that words
and expressions defined in the Service Agreement shall have the same meaning herein): (a) during my
employment or after it has terminated, to do anything and sign or execute any document and generally
to use my name for the purpose of giving to the Company or to any Group Company or its or their
nominee(s) the full benefit of clause 14 (Intellectual Property); (b) during my employment or after
it has terminated, to do anything and sign or execute any document as may be required under the
constitution of the Company and each Group Company to make my resignation as a director from those
companies effective; and (c) to appoint any substitute and to delegate to that substitute all or any
powers conferred by this Power of Attorney.

I declare that this Power of Attorney, having been given by me to secure my obligations under clause
14 (Intellectual Property) and clause 15 (Termination of Employment) of the Service Agreement, shall
be irrevocable in accordance with section 4 of the Powers of Attorney Act 1971.

This Power of Attorney is governed by and construed in accordance with English law, save where
provided otherwise herein.

The parties irrevocably agree that the courts of England and Wales shall have exclusive jurisdiction
to settle any dispute or claim that arises out of or in connection with this Power of Attorney or
its subject matter or formation (including non-contractual disputes or claims).

IN WITNESS whereof this Power of Attorney has been duly executed. EXECUTED as a deed by JOHN ROGERS
) ) /s/ John Rogers in the presence of: )

Witness: Signature: /s/ Rachel Blackman - Rogers

Name: Rachel Blackman - Rogers

Address:

17
<!-- page 18 -->
Table of Contents

SCHEDULE 2 INCENTIVE PLANS

The Executive will be eligible to participate in each of the Incentive plans referred to below in
accordance with the rules of the relevant plans from time to time.

The receipt of any bonus, award, stock or payment under any or all of these plans in one year shall
not create any right or expectation to any bonus or payment in any subsequent year. 1 SHORT TERM
INCENTIVE PLAN (STIP) 1.1 The Executive's STIP target award will be up to 112% of base salary with a
potential award of up to a maximum of 225% of basic salary depending how far the target may be
exceeded. 1.2 All payments under the STIP are discretionary and subject to the approval of the
Compensation Committee. 1.3 STIP awards are paid out partly in cash and partly in the form of a
deferred stock award under the ESA, the exact split from time to time being a matter of Compensation
Committee discretion. The cash element under the STIP is payable in the year following the year for
which the bonus is payable. The deferred stock element will be governed by the rules of the relevant
stock plan. 1.4 In the event the Executive's employment is terminated or he is under notice of
termination, whether such notice is given or received by the Company, prior to the date on which the
bonus is paid (in respect of the cash element) or prior to the vesting date of the deferred stock
award (in respect of the deferred stock element) the Executive will forfeit all and any rights or
entitlements under the STIP and will not have any rights against the Company and/or WPP plc in
respect of the loss of such entitlement. 2 EXECUTIVE SHARE AWARD (ESA) 2.1 The Executive will be
eligible to receive Executive Share Awards (ESA) further to his STIP awards. 2.2 Annual targets
based on the financial results of the Company will be determined by WPP plc. ESAs are granted in
form of awards (if any) made after the end of the relevant calendar year, under the relevant stock
plan and are subject to such conditions as the Compensation Committee may determine from time to
time. All ESAs are subject to the overriding discretion of the Compensation Committee up to the
point at which the award under the relevant stock plan is granted. Currently the ESA share vesting
period is three years from the start of the Financial Year to which the relevant ESA award relates.
2.3 The granting and vesting of stock awards will be subject to such conditions as the Compensation
Committee may determine from time to time and subject always to the provisions of the relevant stock
plan. 3 EXECUTIVE PERFORMANCE SHARE PLAN (EPSP) 3.1 At the discretion of the Compensation Committee,
the Executive will be eligible to participate in the Executive Performance Share Plan. 3.2 The
Company currently expects that the Executive will be granted a target award under the EPSP of WPP
plc stock of 300% of his base salary (but this is subject always to the discretion of the 18
<!-- page 19 -->
Table of Contents

Compensation Committee and may be adjusted downwards prior to the grant being made) which will vest
subject to performance (as deemed by the Compensation Committee in its discretion) at the end of the
performance period. 3.3 The granting and vesting of awards under the EPSP will be subject to such
conditions as the Compensation Committee may determine from time to time and subject always to the
provisions of the EPSP 4 PERFORMANCE ADJUSTMENTS 4.1 If the Executive: (a) commits an act of fraud,
dishonesty, deceit, breach of fiduciary duty or other gross misconduct; (b) does or omits to do
something that results in a set of audited accounts of a Group Company being materially wrong or
misleading; and either (i) those accounts have to be materially corrected; or (ii) a subsequent set
of accounts or data have to be adjusted or include a provision or write down as a result of that act
or omission; or (iii) a liquidation event occurs in relation to that Group Company; or (c) knew or
should have known that any information used to calculate any STIP awarded to him was incorrect; or
(d) prior to the award or payment of any STIP award, committed any material wrongdoing that had the
Company known of it would have entitled the Company to terminate the Executive's employment in
accordance with clause 15 of the Agreement,

then the Compensation Committee can decide that: (i) any STIP award or part of a STIP award awarded
to him pursuant to this Agreement will be cancelled; and/or (ii) any STIP award or part of a STIP
award paid to him in satisfaction of any STIP award under this Agreement must be repaid by the
Executive. 4.2 This sub-clause 4.2 applies if, at any time prior to the third anniversary of the
payment of any STIP awarded pursuant to this Agreement, the Compensation Committee determines that
any of the circumstances described in sub-clauses 4.1(a) to 4.1(d) has arisen. 4.3 If sub-clause 4.2
applies, the Compensation Committee can decide that the relevant STIP award or part of the STIP
award will be cancelled or should not have been paid and must be repaid by the Executive to
compensate the Company for any overpayment. 4.4 Subject to sub-clause 4.5 the Executive will, if
required to do so by the Compensation Committee, repay to the Company or to another Group Company as
notified by the Company the amount of cash that the Compensation Committee determines is required to
compensate the Company for any overpayment. 19
<!-- page 20 -->
Table of Contents

4.5 If the Executive was subject to tax, social security contributions or other levies (Taxes) on
payment of the STIP award, and in the Compensation Committee's reasonable opinion he will not get a
credit or repayment of some or all of the Taxes, the Compensation Committee will reduce the amount
of cash that the Executive can be required to transfer under sub-clause 4.4 by the amount that
reflects the Taxes in respect of which credit or repayment is unavailable. 4.6 The Compensation
Committee will act reasonably in using its authority under sub-clauses 4.1to 4.5of this Schedule 2 5
ONE-TIME AWARDS

5.1 The Executive will, subject to the terms of this Schedule 2, be eligible to receive the
following one-time awards in compensation for the short term and long-term incentive awards he will
cease to be entitled to on cessation of his previous directorship of and employment with J Sainsbury
plc or one of its subsidiaries ("JS"):

(a) a cash award equivalent to the cash bonus he would have received from JS in respect of the 2019
financial year and payable in 2020 determined on the same basis as the compensation committee of JS
awards a cash bonus to the CEO and Executive management team of JS; and

(b) £361,252 payable in cash in respect of the JS 2018 Deferred Share Award; and

(c) £368,455 payable in cash in respect of the JS 2016 LTIP Award; and

(d) an award equivalent to the value of the deferred share award he would have received from JS in
respect of the 2019 financial year and awarded in 2020 determined on the same basis as the
compensation committee of JS awards a cash bonus to the CEO and Executive management team of JS, to
be granted over restricted ordinary WPP shares with a vesting date in May 2022;

(e) an award to the value of £364,102 to be granted over restricted ordinary WPP shares with a
vesting date in May 2021 in respect of the JS 2019 Deferred Share Award; and

(f) a cash award in respect of the JS 2017 LTIP award currently estimated to be valued at £644,160
but to be determined based on the actual performance disclosed in the JS 2020 annual report and
accounts and to include JS dividend equivalents. The Executive commits to utilise the net amount
after tax and deductions to acquire WPP ordinary shares that he will hold beneficially for a minimum
of two years; and

(g) an award to the value of £1,069,788 to be granted over ordinary shares under the terms of the
WPP EPSP 2019 award with a vesting date of March 2021 in respect of the JS 2018 LTIP. The Executive
commits to utilise the net amount after tax and deductions to acquire WPP ordinary shares that he
will hold beneficially for a minimum of two years; and

(h) an award to the value of £1,427,991 to be granted over ordinary shares under the terms of the
WPP EPSP 2019 award with a vesting date of March 2022 in respect of the JS 2019 LTIP. The Executive
commits to utilise the net amount after tax and deductions to acquire WPP ordinary shares that he
will hold beneficially for a minimum of two years.

5.2 In relation to the one-time awards in clause 5.1 payable in cash, the payment will be made in
the second month following the Executive's commencement of employment with the Company or such later
date when the outcomes of the JS incentive plans are available. The one-time share award in clause
5.1 will be made in the first open period of WPP plc following the Executive's commencement of
employment with the Company. 20
<!-- page 21 -->
Table of Contents

SCHEDULE 3 PROTECTIVE COVENANTS 1 The Executive agrees and undertakes with the Company acting on
behalf of itself and as agent for each Group Company that he will not in any Relevant Capacity at
any time during the Restricted Period: (a) within or in relation to the Restricted Territory take
any steps preparatory to or be directly or indirectly engaged, employed, interested or concerned in:
(i) any Competing Business; and/or (ii) any Target Business Entity, (b) within or in relation to the
Restricted Territory acquire a substantial or controlling interest directly or by or through any
nominee or nominees in any Competing Business, Target Business Entity or in any Person owning or
controlling a Competing Business or Target Business Entity; or (c) solicit or attempt to solicit,
canvass, interfere with or entice away from the Company or any Relevant Group Company the custom or
any prospective custom of any Client or any Prospect with a view to providing to that Client or
Prospect any products or services which are the same as or materially similar to any Restricted
Business in competition with the Company or any Relevant Group Company; or (d) provide or agree to
provide any products or services which are the same as or materially similar to any Restricted
Business to any Client or any Prospect in competition with the Company or any Relevant Group
Company; or (e) solicit, entice or encourage or attempt to solicit, entice or encourage any Key
Individual to leave the employment of the Company or any Relevant Group Company (whether or not such
person would commit any breach of his contract of employment by doing so); or (f) employ, engage,
appoint, enter into partnership or association with or in any way cause to be employed, engaged or
appointed any Key Individual in relation to any Person which is or is proposing to be a Competing
Business or is or is proposed to be directly or indirectly owned by or controlling any Competing
Business; or (g) provide or agree to provide any products or services which are the same as or
materially similar to any Restricted Business in respect of any Competitor Account; or (h) be
employed or engaged by any Client or Prospect if as a result the Client or Prospect will cease to
use or materially reduce its usage of the products or services of the Company or any Relevant Group
Company or, in the case of a Prospect, will not use the products or services of the Company or any
Relevant Group Company or use them to a materially lesser extent; or (i) solicit or try to solicit
or place orders for the supply of products or services from any Supplier if as a result the Supplier
will cease supplying, materially reduce its supply or vary detrimentally the terms on which it
supplies products or services to the Company or any Relevant Group Company; or 21
<!-- page 22 -->
Table of Contents

(j) encourage, assist or procure any Person to do anything which if done by the Executive would be a
breach of sub clauses 1 (a) to (i). 2 The Executive agrees that updating his profile and/or
connecting or reconnecting to Clients, Suppliers or Prospects using Social Media during the
Restricted Period may amount to a breach of sub clauses 1 (a) to (j) above. 3 The parties agree that
the restrictions (whether taken individually or as a whole) in sub clauses 1 (a) to (j) above are
reasonable having regard to the legitimate protectable interests of the Company and the Group and
that each such restriction is intended to be separate and severable and the validity of each is not
affect if any of the others are involved. In the event that any of the restrictions is held to be
void but would be valid if part of its wording was deleted, that restriction shall apply with
whatever deletion is necessary to make it valid and effective. 4 It is understood and agreed by the
parties that damages shall be an inadequate remedy in the event of a breach by the Executive of any
of the restrictions contained in sub clauses 1 (a) to (i) above and that any such breach by him or
on his behalf will cause the Company and any Relevant Group Company great and irreparable injury and
damage. Accordingly, he agrees that the Company and/or any Relevant Group Company shall be entitled,
without waiving any additional rights or remedies otherwise available to it at law or in equity or
by statute, to injunctive and other equitable relief in the event of a breach or intended or
threatened breach by the Executive of any of those restrictions. 5 If the Company exercises its
right to suspend the Executive's duties and powers under clause 16, the period of the suspension
will reduce the Restricted Period. 6 For the purposes of this Schedule 3 the following additional
definitions shall apply:

Client means any Person with whom or which the Company or any Relevant Group Company has
arrangements in place for the provision of any Restricted Business and with whom or which the
Executive had material involvement or for whose business he was responsible or about which he
acquired material Confidential Information, in the course of his employment at any time during the
Relevant Period.

Competing Business means any Person providing or proposing to provide any products or services which
are the same as or materially similar to and competitive with any Restricted Business.

Competitor Account means any account, product or brand which competes with any Client's account,
product or brand in respect of which the Executive had material dealings or responsibility on behalf
of the Company or any Relevant Group Company or about which he acquired Confidential Information,
during the course of his employment at any time during the Relevant Period.

Key Individual means any individual who was employed by the Company or any Relevant Group Company to
provide services personally at the date on which the Appointment terminates (or but for the breach
by the Executive of his obligations under this Agreement and/or implied by law would have been so
employed at the date on which the Appointment terminates) and who in the course of his duties during
the Relevant Period had material dealings with the Executive and: (a) either: (i) reported directly
to him; and 22
<!-- page 23 -->
Table of Contents

(ii) had material contact with clients or suppliers of the Company or any other Relevant Group
Company in the course of his employment;

or (b) was a member of the board of directors or the senior management team of the Company or any
Relevant Group Company or reported to any such board of directors or senior management team.

Prospect means any Person who was at any time during the Relevant Period negotiating or discussing
(which shall include for these purposes a pitch or presentation) with the Company or any Relevant
Group Company the provision of any Restricted Business and in respect of which such negotiations or
discussions the Executive was materially involved or had responsibility for or about which he
acquired material Confidential Information, in the course of his employment at any time during the
Relevant Period.

Relevant Capacity means either alone or jointly with another or others, whether as principal, agent,
consultant, director, partner, shareholder, independent contractor, employee or in any other
capacity, whether directly or indirectly, through any Person and whether for the Executive's own
benefit or that of others (other than as a shareholder holding directly or indirectly by way of bona
fide investment only and subject to prior disclosure to the Company up to 1% in nominal value of the
issued share capital or other securities of any class of any company listed or dealt in on any
Recognised Investment Exchange).

Relevant Group Company means any Group Company to which the Executive rendered services or for which
he had management or operational responsibility during the course of his employment at any time
during the Relevant Period.

Relevant Period means the twelve-month period ending with the Termination Date.

Restricted Business means and includes any of the products or services provided by the Company or
any Relevant Group Company at any time during the Relevant Period with which the Executive had a
material involvement or about which he acquired Confidential Information at any time during the
Relevant Period.

Restricted Period means the 12-month period commencing on the Termination Date in relation to
sub-clause 1(a) and the 18- month period commencing on the Termination Date in relation to all
remaining sub-clauses in clause 1 above.

Restricted Territory means England and such other countries in which the Company or any Relevant
Group Company carried on any Restricted Business at the Termination Date.

Supplier means any Person who at any time during the Relevant Period provided products or services
to the Company or any Relevant Group Company being a Person with whom the Executive had material
dealings or for whom he had responsibility or about whom he acquired material Confidential
Information, in the course of his employment at any time during the Relevant Period.

Target Business Entity means any business howsoever constituted (whether or not conducting a
Restricted Business) which was at the Effective Date or at any time during the Relevant Period a
business which the Company or any Relevant Group Company had entered into negotiations with or had
approached or had identified as: 23
<!-- page 24 -->
Table of Contents

(a) a potential target with a view to its acquisition by the Company or any Relevant Group Company;
and/or (b) a potential party to any joint venture with the Company or any Relevant Group Company,

in either case where such approach or negotiations or identity were known to a material degree by
the Executive or about which he acquired material Confidential Information, in the course of his
employment during the Relevant Period. 24
