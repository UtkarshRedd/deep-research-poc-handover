<!-- page 1 -->
# STRATEGIC ALLIANCE AGREEMENT
| Field | Value |
|---|---|
| Document Type | Strategic Alliance Agreement |
| Agreement Date | 2017-04-17 |
| Parties | Loin Biotechnologies, Inc. ("LBIO"); The University of Texas M. D. Anderson Cancer Center ("MD Adnserson"); ("LBIO" and "MD Adnserson" individually referred to as "Party", collectively as the "Parties") |
| Source | CUAD v1 / IOVANCEBIOTHERAPEUTICS,INC_08_03_2017-EX-10.1-STRATEGIC ALLIANCE AGREEMENT |

Exhibit 10.1 Text Marked By [* * *] Has Been Omitted Pursuant To A Request For Confidential
Treatment And Was Filed Separately With The Securities And Exchange Commission. STRATEGIC ALLIANCE
AGREEMENT Effective Date: April 17, 2017 THIS STRATEGIC ALLIANCE AGREEMENT (this "Agreement"), is
entered into by and between Lion Biotechnologies, Inc., with a place of business located at 999
Skyway Road, Suite 150, San Carlos, CA 94070 ("LBIO"), and The University of Texas M. D. Anderson
Cancer Center, with a place of business located at 1515 Holcombe Blvd., Houston, TX 77030 ("MD
Anderson"), a member institution of The University of Texas System ("System"), as of the date set
forth above (the "Effective Date"). MD Anderson and LBIO are hereinafter individually referred to as
a "Party" and are collectively known as the "Parties". WHEREAS, as a comprehensive cancer research,
treatment, and educational center, MD Anderson undertakes research and experimental activities in a
variety of disciplines; and WHEREAS, the Parties hereby wish to establish a collaboration
("Collaboration") with respect to the performance of one or more research studies to be conducted
pursuant to this Agreement (each such study, a "Study", and collectively the "Studies", and the
activities to be performed with respect to the Studies collectively, the "Research"). NOW,
THEREFORE, in consideration of the mutual covenants contained herein, the receipt and sufficiency of
which are hereby acknowledged, LBIO and MD Anderson hereby agree to be legally bound as follows: 1.
Governance. 1.1 Joint Steering Committee. The Parties will establish a joint steering committee
("JSC") of equal representation, comprised of three members from each Party, with the members of
each Party collectively having one vote on all matters to be decided upon by the JSC. Each Party can
appoint and replace its members in the JSC at its own discretion through timely written notice to
the other Party. The Principal Investigators for each Study (as defined hereinafter) shall attend
each JSC meeting, except in the event of exigent circumstances that do not permit such attendance.
1.2 JSC Meetings. The JSC will have meetings (either in person, by teleconference or via electronic
means) at least quarterly. At least one meeting per year will be conducted in person or by
videoconference (including the kick-off meeting), with the location alternating between a site a
selected by LBIO and a site selected by MD Anderson. LBIO will choose the location of the first such
in-person meeting. Subject to Section 1.4 below, the JSC will decide on matters by unanimous vote;
provided, however, that no action may lawfully be taken at any meeting unless at least two members
from each Party (including for this purpose any proxy member appointed as provided below) are
present at the meeting. If a member of the JSC is unable to attend a meeting, he or she may appoint,
in writing, a proxy to participate and vote in his or her stead.

1
<!-- page 2 -->
1.3 JSC Responsibilities. The main task of the JSC will be to oversee the Collaboration. In order to
achieve the objectives of the Collaboration, the JSC will oversee each Study under the
Collaboration. The JSC will provide technical, scientific, clinical, and regulatory guidance
regarding the Studies and will be responsible for monitoring progress of the Studies. In addition,
the JSC will be responsible for coordinating resolution of problems arising in the Studies or in the
Collaboration as a whole. Additional members can be invited by the JSC on a case by case basis
should discussion of certain topics require so; provided, that such members will be subject to
obligations of confidentiality and non-use at least as strict as those set forth in Section 5 below.
1.4 Dispute Resolution. Decisions regarding Study design, changes and/or additions to the
initially-agreed Protocols must be unanimous, with each Party exercising one vote each, and in the
absence of such unanimity the status quo shall be maintained. For all other matters before the JSC,
a unanimous decision, with each Party exercising one vote, is required; provided, that, if unanimity
cannot be achieved regarding such other matters, then LBIO's chief executive officer may make the
decision on behalf of the JSC, provided that LBIO's chief executive officer will first make a good
faith effort to consult with a designated executive at MD Anderson to resolve such matter. 2.
Performance of Studies. 2.1 Studies. (a) During the Term (as defined below), LBIO and MD Anderson
may periodically agree to collaborate with respect to the performance of one or more Studies. In
connection with each Study, the Parties shall execute, as applicable, a Study-specific clinical
trial agreement or a pre-clinical work order where a clinical trial is not being conducted (each, a
"Study Order"). Study Orders shall be numbered sequentially and, when executed, appended to this
Agreement and made a part hereof. The first three Study Orders, when completed, will be incorporated
into this Agreement as Exhibit I, Exhibit II, and Exhibit III, and the Studies that are the subject
of such Study Orders are also referred to herein as the "Initial Studies". Each Study Order shall
detail the specifics of the Study to be performed under such Study Order including (i) a detailed
Study-specific protocol ("Protocol") that will be developed jointly by the Parties working together
in good faith and (ii) any Study-specific resources or support to be provided by LBIO, including any
financial consideration ("Collaboration Funding", but excluding financial support associated with
the Initial Studies to the extent addressed in Section 4 of this Agreement). Any revisions or
amendments to a Study Order or Protocol shall be implemented, if at all, solely in accordance with
the terms of the relevant Study Order and shall be subject to the approval of the JSC. The Parties
acknowledge and agree that MD Anderson will be the "sponsor" of the Initial Studies that are
clinical studies, as defined at 21 C.F.R. §§ 50.3(f) and 312.3(b), and will be the holder of the
investigational new drug applications (INDs) submitted to the FDA (as defined hereinafter) for such
Initial Studies. (b) In the event of any conflict of any terms of this Agreement and the terms of a
Study Order, the terms of this Agreement shall govern, unless the Study Order specifically and
expressly supersedes this Agreement with respect to a specific term, and then only with respect to
the particular Study Order and specific term. If there is any discrepancy or conflict between the
terms contained in a Protocol and this Agreement and/or the relevant Study Order, the terms of the
Protocol shall govern and control with respect to clinical matters and the terms of this Agreement
and/or the relevant Study Order shall govern and control with respect to all other matters (e.g.,
legal and financial matters).

2
<!-- page 3 -->
2.2 Investigators. (a) Principal Investigator. Each Study Order will identify the individual that
will serve as the "Principal Investigator" for the relevant Study at MD Anderson and shall be
responsible for MD Anderson's administration and supervision of its portion of such Study. If the
originally named Principal Investigator becomes unable or unwilling to continue a Study for any
reason, MD Anderson shall propose a substitute Principal Investigator with comparable qualifications
within two business days of MD Anderson becoming aware of such event. If the proposed candidate is
not available or is not acceptable to LBIO, LBIO may terminate the applicable Study in accordance
with Section 8.3(ii). (b) MD Anderson and Principal Investigator may appoint one or more
collaborating physicians ("Sub-Investigators") to participate in a Study. Such Sub-Investigators
shall work under the supervision of, shall report to and be the sole responsibility of Principal
Investigator, and Principal Investigator and MD Anderson shall each ensure that all
Sub-Investigators undertake all activity related to the Study in accordance with the terms of this
Agreement, the applicable Study Order, and the Protocol. (c) On a Study Order-by-Study Order basis,
in the event that a Principal Investigator leaves or is removed from MD Anderson (or is otherwise
unwilling or unavailable to direct the applicable Study in accordance with this Agreement and the
applicable Study Order), then MD Anderson shall, as soon as practicable but in any event within two
(2) business days of such event, provide written notice of such event to LBIO. Any subsequently
appointed principal investigator must be approved, in writing in advance, by LBIO and such new
principal investigator shall be required to agree to all the terms and conditions of the applicable
Study Order and this Agreement and to sign each such document as evidence of such agreement
(although failure to so sign will not relieve such new principal investigator from abiding with all
the terms and conditions of the applicable Study Order and this Agreement). If LBIO does not approve
of the new principal investigator, or the new principal investigator does not sign this Agreement,
then LBIO may terminate the applicable Study Order in accordance with Section 8.3(ii). 2.3
Performance; Compliance with Law. (a) MD Anderson shall, and shall cause each of its employees,
agents, contractors, and subcontractors performing Research activities or other obligations under
this Agreement, including the Principal Investigator (collectively, "Representatives") to, conduct
such activities, and use, store and handle all materials used in the performance of activities under
this Agreement and each Study Order, or cause the same to be done, in accordance with (i) all
applicable laws, regulations, and guidelines, including, to the extent applicable, the Federal Food,
Drug, and Cosmetic Act ("FFCDA"); the anti-kickback and related provisions of the Social Security
Act; the Public Health Services Act; the regulations promulgated by the Food and Drug Administration
("FDA"), including 21 C.F.R. Parts 50, 56, and 58, and, with respect to clinical Studies, the
requirements of the Statement of Investigator, FDA Form 1572 (as described in 21 312.53), the terms
of which are incorporated by reference into any Study Order pertaining to a clinical Study (and the
Principal Investigator for any such clinical Study shall complete, sign, and deliver a Form 1572 to
LBIO prior to the commencement of such Study); the United States Health Insurance Portability and
Accountability Act of 1996, as amended by the HITECH Act, including the Standards for Privacy of
Individually Identifiable Health Information; the EU Data Protection Directive; and all other
applicable privacy, security and data protection laws (collectively, this sub-clause (i), "Laws"),
and, as applicable, the quality standards of "Good Clinical Practice" (which term shall mean
generally accepted good clinical practices including those set out in the current version of the
Declaration of Helsinki and the International Conference on Harmonization Guidelines for Good
Clinical Practice in force from time to time and FDA's most recent guidance and regulations
concerning current Good Clinical Practice), (ii) the provisions of this Agreement (including each
applicable Study Order and Protocol), and (iii) all written instruction from LBIO, as well as MD
Anderson's internal policies and procedures to the extent they do not conflict with the foregoing
subsections (i) and (ii).

3
<!-- page 4 -->
(b) LBIO is a United States corporation subject to the provisions of the Foreign Corrupt Practices
Act (the "FCPA"). Under the FCPA it is unlawful to pay or to offer to pay anything of value,
directly or indirectly, to foreign government officials, government employees, political candidates,
or political parties, or to persons or entities who will offer or give such payments to any of the
foregoing, in order to obtain or retain business or to secure an improper commercial advantage for
LBIO. MD Anderson shall not, and MD Anderson shall ensure that its Representatives do not, take or
permit any action, including paying or transferring anything of value, directly or indirectly, to
any official or other person to influence any decision to obtain or retain business or gain an
advantage in the conduct of business, or to induce such official or other person to perform a
function in violation of any Laws, that will either constitute a violation under, or cause LBIO to
be in violation of, the provisions of the FCPA or applicable local bribery and corruption Laws. (c)
MD Anderson shall register each Study that is a clinical study with the relevant governmental
authorities and government websites (including http://www.clinicaltrials.gov) and make all updates
as required under the Laws, and shall identify LBIO as a financial collaborator (e.g., a
"Collaborator" for the purposes of www.clinicaltrials.gov) in such registrations. (d) To the extent
required by Law, MD Anderson and Principal Investigator shall be responsible for ensuring that the
Research and all applicable documents, including any Protocol and informed consent and authorization
forms are properly approved by applicable regulatory authorities and an Institutional Review Board
("IRB"). As may be required by Law, and with respect to any given applicable Study hereunder, MD
Anderson and Principal Investigator shall further be responsible for making all reports and
obtaining the continuing approval from the applicable IRB. Prior to making any submission to an IRB
with respect to any given applicable Study hereunder (including a Protocol, and information to be
provided to potential Study subjects including the informed consent and HIPAA authorization, and as
applicable, the Case Report Forms ("CRFs") or supporting source documentation), MD Anderson shall
provide the proposed submission to LBIO for LBIO's review and approval. MD Anderson shall promptly
further provide LBIO with documentation of the IRB's initial and continuing review and approval with
respect to any given applicable Study hereunder, as well as any other communications and/or
interactions with the IRB (summaries in the case of oral interactions and/or communications) that is
related to or which may impact the Research, prior to the commencement of the Research and promptly
thereafter. In the event MD Anderson's IRB requires changes in any Protocol, informed consent or
related forms for a Study after the Effective Date of the applicable Study Order, LBIO shall be
advised in advance and all such modifications must be approved in advance and in writing by the JSC
under this Agreement. MD Anderson and Principal Investigator shall not modify a Study described in a
Protocol without the prior written approval of the JSC.

4
<!-- page 5 -->
(e) MD Anderson and/or Principal Investigator shall be responsible for reporting and tracking of all
adverse events with respect to a Study ("AEs") in compliance with all Laws and each applicable
Protocol and Principal Investigator shall be responsible for updating all AEs, including any
expedited safety reports. MD Anderson and LBIO will share information with each other of any
findings that may impact the safety of a Study Drug including as Study Drug safety may adversely
affect the health and safety of any Study subject, influence the conduct of a Study, alter an IRB's
approval to continue a Study, or affect the willingness of a Study subject to continue participation
in the Study. Principal Investigator and MD Anderson shall notify LBIO within twenty-four (24) hours
after learning of any serious AE and any special situation report (both as defined in the applicable
Protocol) incurred during or as the result of the Study, and provide a written confirmation report
of such individual serious adverse event and special situation report promptly thereafter, as well
as a monthly listing of all such serious adverse events and special situation reports, by electronic
mail to: lionbiosafety@lionbio.com. LBIO shall have the ability to request additional information
related to any such safety finding, serious AE or special situation report, if applicable,
thereafter. Additionally, MD Anderson and/or Principal Investigator will promptly provide LBIO with
all information in their possession or control as may be needed to assist LBIO in the identification
and resolution of problems or unexpected occurrences involving the Study Drug or its use in the
Study. 2.4 Facilities. MD Anderson shall cause its Representatives to perform the Research only at
the facility(ies) identified in the applicable Study Order (the "Facility(ies)"). MD Anderson may
not utilize any facility, other than the Facility(ies), for performing any portion of the Research
without obtaining LBIO's prior written consent to do so. MD Anderson shall maintain, or cause to be
maintained, the Facility(ies), all personal property, equipment, machinery, excipients, materials,
systems, intangibles, intellectual property and contract rights in use at the Facility(ies) free of
defects, except for defects attributable to wear and tear consistent with the age and usage of such
assets, and except for such defects as do not and will not, in the aggregate, materially impair the
ability to use such assets in connection with the Research. 2.5 No Inducement. MD Anderson agrees
that LBIO's support of the Research is not conditioned on the value or volume of business generated
between the Parties and is not being provided or received as a reward or in exchange for
recommending, prescribing, dispensing, purchasing, supplying, selling, administering, referring,
arranging for, or ordering any product that is manufactured, sold, or distributed by LBIO, or to
induce recommending, prescribing, dispensing, purchasing, supplying, selling, administering,
referring, arranging for, or ordering any product that is manufactured, sold, or distributed by LBIO
in the future.

5
<!-- page 6 -->
3. Materials. 3.1 Study Materials and Equipment. Unless otherwise provided by this Agreement
(including as expressly set forth in a Study Order), Principal Investigator shall conduct the
Research with MD Anderson's materials and equipment. MD Anderson shall be responsible for the
acquisition, purchasing, replacement, repair, maintenance, and calibration, to the extent
applicable, of all materials and equipment, unless otherwise provided by this Agreement (including
as expressly set forth in a Study Order), necessary for MD Anderson to conduct the Research. LBIO
shall have no role, responsibilities, and or liability with regard to any materials and equipment
necessary for MD Anderson and Principal Investigator to conduct the Research, except as provided in
this Agreement (including as expressly set forth in a Study Order). 3.2 Informed Consent. MD
Anderson shall ensure that all patients from whom Patient Materials (as defined below) were
obtained, provided their informed consent and authorization for MD Anderson's and Principal
Investigator's transfer of the applicable Patient Materials, data, and information to LBIO as called
for in any applicable Study Order, LBIO's use of Patient Materials, data, and information, and
LBIO's further transfer of the Patient Materials, data, and information to governmental or
regulatory authorities and other third parties, as applicable. Upon LBIO's request, MD Anderson
shall provide LBIO with copies of the patient informed consent and authorization forms for LBIO to
confirm the provisions of this Section 3.2. 3.3 LBIO Materials. (a) "Material" shall mean the
tangible materials, Patient Materials (as defined below) and equipment described in an exhibit to a
given Study Order (such exhibit, if provided, the "Materials Exhibit"). The Parties will amend a
given Materials Exhibit from time to time as additional Materials are provided by or to LBIO in
connection with a given Study Order. The Parties shall provide, or cause to be provided, Materials,
and rights with respect to associated intellectual property, to each other in the quantities
described in the applicable Study Order (or if no such quantities are described, in reasonable
quantities) and at the times set forth in the applicable Study Order (or if no such times are set
forth, as soon as reasonably practicable and necessary after the effective date of the applicable
Study Order). All Materials supplied to MD Anderson by or on behalf of LBIO shall, as between LBIO
and MD Anderson, remain the exclusive property of LBIO. (b) THE MATERIALS PROVIDED TO INSTITUTION BY
LBIO ARE PROVIDED BY LBIO ON AN "AS IS" BASIS. LBIO HEREBY DISCLAIMS ANY WARRANTIES, EXPRESS OR
IMPLIED, CONCERNING THE MATERIALS, INCLUDING ANY WARRANTIES OF TITLE, INFRINGEMENT, MERCHANTABILITY
OR FITNESS FOR A PARTICULAR PURPOSE. NO OFFICER, EMPLOYEE, AGENT OR REPRESENTATIVE OF LBIO HAS ANY
AUTHORITY TO BIND LBIO TO ANY AFFIRMATION, REPRESENTATION OR WARRANTY CONCERNING THE MATERIALS,
EXCEPT AS SET EXPRESSLY FORTH HEREIN. THE MATERIALS PROVIDED TO LBIO BY INSTITUTION ARE PROVIDED BY
INSTITUTION ON AN "AS IS" BASIS. INSTITUTION HEREBY DISCLAIMS ANY WARRANTIES, EXPRESS OR IMPLIED,
CONCERNING THE MATERIALS, INCLUDING ANY WARRANTIES OF TITLE, INFRINGEMENT, MERCHANTABILITY OR
FITNESS FOR A PARTICULAR PURPOSE. NO OFFICER, EMPLOYEE, AGENT OR REPRESENTATIVE OF INSTITUTION HAS
ANY AUTHORITY TO BIND INSTITUTION TO ANY AFFIRMATION, REPRESENTATION OR WARRANTY CONCERNING THE
MATERIALS, EXCEPT AS SET EXPRESSLY FORTH HEREIN.

6
<!-- page 7 -->
(c) The Materials provided by or on behalf of LBIO shall only be used as necessary to conduct the
Research, in accordance with the Research Plan, this Agreement, all written instructions from LBIO
and all Laws and not for any other uses or activities whatsoever, including in connection with
research for any third person or entity. MD Anderson shall maintain control over Materials received
by it from or on behalf of LBIO hereunder and shall not transfer any portion of such Materials to
any third party for any purpose other than the purposes of performing its obligations under, and in
accordance with, this Agreement, the Research Plan, all written instructions from LBIO and all Laws.
MD Anderson shall maintain complete and accurate records relating to the disposition of all
Materials provided by or on behalf of LBIO. MD Anderson shall return to LBIO all unused supplies of
Materials provided by or on behalf of LBIO in accordance with Section 8.4 or at LBIO's earlier
request. MD Anderson shall have no right to provide samples of the Materials provided by or on
behalf of LBIO (or products created thereby) to any person or entity. 3.4 Patient Materials.
"Patient Materials" shall mean those certain biological materials, and derivatives thereof and
related patient data and information, received from individual patients and described in an
applicable Materials Exhibit. Without limiting Section 3.3, MD Anderson shall further handle,
transport, use and store Patient Materials exclusively at the Facility(ies) or otherwise in
accordance with this Agreement, unless otherwise requested by LBIO in writing, and at all times
strictly in accordance with (a) MD Anderson's standards of security and confidentiality and (b) all
applicable privacy, security and data protection Laws (including the United States Health Insurance
Portability and Accountability Act of 1996, as amended by the HITECH Act, including the Standards
for Privacy of Individually Identifiable Health Information, and the EU Data Protection Directive).

7
<!-- page 8 -->
4. Certain Financial Matters. 4.1 Initial Funding. LBIO agrees to commit funding in an amount not to
exceed $14,211,864.00 for the performance of the Studies during the Term (collectively, "Initial
Funding"), with the Initial Funding specifically allocated as follows: (a) $[* * *] for an upfront
payment, and a minimum of $[* * *] for enrollment and treatment of a minimum of 40 patients in the
Study described in Exhibit I (i.e., the Minimum Enrollment Target as defined in Exhibit 1) or up to
$[* * *] (an "Individual Study Budget") for enrollment and treatment of up to 60 patients in the
Study described in Exhibit I (i.e., the Maximum Enrollment Target as defined in Exhibit 1); (b) $[*
* *] (which shall also be considered an Individual Study Budget) for enrollment, manufacturing of
product, and treatment of 30 patients in the Study described in Exhibit II; and (c) $[* * *] for the
Study described in Exhibit III. LBIO shall pay the Initial Funding in accordance with Section 4.3.
For clarity, the Initial Funding is Collaboration Funding. MD Anderson agrees that all costs of this
Collaboration, with the sole exceptions of any costs to supply clinical-grade aldesleukin and 4-1BB
agonist for use in the expansion of tumor infiltrating lymphocytes ("TILs"), and in the case of
aldesleukin, for use in the treatment of patients, are included in the Initial Funding. Subject to
the foregoing exceptions, MD Anderson shall be solely responsible for any costs it incurs in
performing the Studies that are in excess of the Initial Funding. 4.2 Collaboration Funding
Generally. MD Anderson shall use the Collaboration Funding solely to conduct the applicable Study
and MD Anderson shall be responsible for managing cash flow between payments. It is understood and
agreed that the Collaboration Funding shall cover all administrative, IRB review, patient
recruitment, and all other fees, costs and expenses of MD Anderson and any of its Representatives
for the conduct of the Studies or the provision of equipment or services to facilitate the Studies,
and that no other form of compensation shall be paid to MD Anderson in connection with the Studies
except as otherwise may be specifically and mutually agreed upon by the Parties in writing. 4.3
Payments. LBIO shall pay the Initial Funding to MD Anderson as follows. An upfront payment of $[* *
*] (the "Upfront Payment") shall be invoiced by MDACC on the Effective Date. The remainder of the
Initial Funding shall be paid as follows: (a) In the event that the Study Order covers the
performance of a clinical trial, funding shall be invoiced based on Study patient enrollment as
follows, based on the Maximum Enrollment Target as defined in each Study Order:

Milestone (on Study Order-by-Study Order basis)

Payment (% of the Individual Study Budget) to be provided in connection with such Study Order*
Enrollment of [* * *]% of the target patient enrollment as set forth in the applicable Protocol [* *
*]%

Enrollment of [* * *]% of the target patient enrollment as set forth in the applicable Protocol [* *
*]%

Enrollment of [* * *]% of the target patient enrollment as set forth in the applicable Protocol [* *
*]%

Enrollment of final patient as set forth in the applicable Protocol [* * *]% Receipt by LBIO of both
(a) the final clinical study report and (b) all raw clinical data (anonymized and without including
any identifying information)

[* * *]%

*With respect to Exhibit 1, the Individual Study Budget shall be the one associated with the Minimum
Enrollment Target (as defined in Exhibit 1), and in the event that the Parties move to the Maximum
Enrollment Target (as defined in Exhibit 1) then this table shall be applied to the incremental
additional patients as if the incremental additional patients constitute their own protocol/budget.
For example, if LBIO decides to add ten (10) additional patients to the clinical study in Exhibit 1,
each patient will be accrued at $[* * *] per patient, and LBIO will be invoiced for percentage
enrollment of these ten (10) patients based on the table above.

8
<!-- page 9 -->
(b) In the event that the Study Order covers activities other than the performance of a clinical
trial, a payment schedule will be set forth in the relevant Study Order. (c) Notwithstanding the
foregoing, LBIO may suspend payment if, in LBIO's reasonable opinion after review of the Reports (as
defined below), MD Anderson has not been performing the Research diligently and in the manner agreed
upon herein. (d) Upon the occurrence of one of the milestones identified in the table in Section
4.3(a), or described in an applicable Study Order for a non-clinical Study according to Section
4.3(b), MD Anderson shall invoice LBIO for the related payment amount. In each case, invoices shall
be itemized, including by reference to Study Order title, and otherwise shall include such
supporting documentation as LBIO may reasonably request. LBIO shall pay all undisputed invoices
within thirty (30) days of receipt of such invoice. (e) If the Study described in Exhibit II is not
commenced, the portion of the Upfront Payment that would have been applied to that Study ($[* * *])
will be credited by MD Anderson towards the Studies described in Exhibit I and Exhibit III. (f) All
terms and payments of compensation, benefits, and any other conditions of engagement, including
payment of taxes, for any person working with Principal Investigator and any other support staff who
may be used in the performance of a Study (including any Sub- Investigator) shall be solely a matter
between MD Anderson and such individuals. Principal Investigator and any MD Anderson personnel shall
not be deemed to be employees of LBIO or entitled to any benefits offered by LBIO to LBIO's
employees. 5. Records and Reports. 5.1 Records. MD Anderson shall, and shall cause its
Representatives to, keep appropriate records of the Research, including laboratory notebooks, in
accordance with MD Anderson policies and all Laws, sufficient to properly document the results of
the Research and otherwise sufficient to determine identity and dates of inventorship of Inventions
(as defined in Section 7.1(a)). MD Anderson shall make such records available to LBIO upon
reasonable notice during MD Anderson's normal business hours. LBIO may use the records and Reports
(as defined below) for any purpose, including interactions and communications with, and/or
submissions and filings to the applicable governmental or regulatory authorities.

9
<!-- page 10 -->
5.2 Reports. MD Anderson, through the Principal Investigator, shall provide to LBIO (a) interim
written reports regarding the Research, no less than once per calendar quarter, and (b) on
Study-by-Study basis, (i) a draft final written Study report within thirty (30) days after
completion (or earlier termination) of each such Study and (ii) a final written Study report within
thirty (30) days after receipt of LBIO's comments to the draft final written Study report with
respect to each such Study, which shall be given by LBIO not later than thirty (30) days after
LBIO's receipt of the draft final Study report (collectively, the "Reports"); provided, that, if
this schedule of reports differs from the reporting obligations provided in a Study Order, the
schedule listed in the Study Order shall be followed. LBIO shall own all Reports and data
compilations resulting from the Research, excluding the physical original lab notebooks themselves
(but not excluding the data and data compilations contained therein, which shall be deemed to be
owned by LBIO) and any patient medical records. 5.3 Electronic Transfer. In addition to MD
Anderson's reporting obligations under Section 5.2, no less than once per calendar quarter, MD
Anderson shall provide to LBIO an electronic transfer of all data and results (including all raw
data and process data) generated through the performance of the Research. 5.4 Other Notifications.
During the performance of the Research, MD Anderson shall notify LBIO promptly if the Research
reveals any unexpected result or any accident or harm occurs, and shall also comply with any safety
notifications required under each Study Order.

10
<!-- page 11 -->
6. Confidentiality and Publications. 6.1 Confidential Information. (a) "Confidential Information"
means any proprietary or confidential information, technical data, trade secrets or know-how,
including research, product plans, products, services, customer lists and customers, markets,
software, developments, inventions, processes, formulas, technology, designs, drawings, engineering,
marketing, distribution and sales methods and systems, sales and profit figures, finances and other
business information disclosed by a Party or its Representatives ("Disclosing Party") to the other
Party or its Representatives ("Receiving Party"), whether in writing, orally or by drawings or
inspection of documents or other tangible property; provided that: (i) Confidential Information
shall not include any of the foregoing items to the extent that (1) they are or have become publicly
known and made generally available through no wrongful act of Receiving Party, (2) they were known
to Receiving Party prior to disclosure by Disclosing Party, as evidenced by pre-existing written
records promptly provided to Disclosing Party by Receiving Party, (3) they were disclosed to
Receiving Party without an obligation of confidentiality by a third party having a lawful right to
make such disclosure, or (4) they were developed by Receiving Party without use or aid of Disclosing
Party's Confidential Information, and (ii) the results of the Research (including the contents of
each Report and any Inventions) shall be deemed to be LBIO's Confidential Information, subject to MD
Anderson's right to publish any Research data and information as set forth in and in accordance with
Section 6.4, MD Anderson's right to use any Inventions (and any Work) as set forth in and in
accordance with Section 7.2, and MD Anderson's right to use any Research data and information for
internal research, academic, and non-commercial patient care purposes prior to publication or public
disclosure and for any purpose thereafter. LBIO shall be deemed the Disclosing Party with respect to
such results of the Research, regardless of the Party initially disclosing the same. (b) Receiving
Party shall take reasonable steps to ensure that Disclosing Party's Confidential Information (as
defined in Section 6.1(a)) is maintained in confidence, used only for the purpose of exercising
rights and performing obligations under this Agreement, and disclosed only to persons and/or
entities authorized under this Agreement. As used herein, "reasonable steps" means the steps that
Receiving Party takes to protect its own, similar confidential and proprietary information, which
shall not be less than a reasonable standard of care. Receiving Party further agrees not to reveal,
publish or otherwise disclose Disclosing Party's Confidential Information to any third party without
the prior written consent of Disclosing Party as described in Section 6.4 below, however, Receiving
Party is permitted to disclose Confidential Information obtained under the terms of this Agreement
to its Representatives on a need-to-know basis related to the exercise of rights and performance of
its obligations under this Agreement and only if such Representatives are informed by Receiving
Party of the confidential nature of such information and are bound by confidentiality obligations
consistent with those set forth in this Section 6.1. Receiving Party shall ensure that its
Representatives having a need- to-know Disclosing Party's Confidential Information observe these
obligations of confidentiality. These obligations of confidentiality and nondisclosure shall remain
in effect after the termination or expiration of this Agreement for a period of five (5) years.

11
<!-- page 12 -->
(c) Neither Party shall improperly use or disclose to the other Party or any of its directors,
officers, employees or agents, any confidential information of any current or former client or other
person or entity with whom such Party has an agreement or duty to keep such information
confidential, and such Party shall not bring onto the premises of the other Party any such
information in any medium unless consented to in writing by such client, person or entity. In the
event of a Party's breach of this Section 6.1(c), the breaching Party shall ensure that the other
Party may freely and fully utilize the information so disclosed for any and all purposes. 6.2
Required Disclosure of Confidential Information. (a) If Receiving Party is required by Law or court
order to disclose Disclosing Party's Confidential Information, Receiving Party shall give Disclosing
Party prompt written notice of such requirement such that Disclosing Party shall have the
opportunity to apply for a protective order, injunction or for confidential treatment of such
Confidential Information. Receiving Party shall cooperate with Disclosing Party in seeking any
Disclosing Party requested protective order, injunction or confidential treatment of such
Confidential Information and shall only disclose the minimal amount of such Confidential Information
required under Law or court order. Notwithstanding the forgoing, any information disclosed by
Receiving Party pursuant to Law or a court order shall remain Confidential Information hereunder,
and may not be disclosed under any other circumstances unless and until the Confidential Information
so disclosed falls into one of the exceptions set forth in subclauses (1) through (4), inclusive, in
Section 6.1(a). (b) If Principal Investigator is a member of or affiliated with any committee that
sets formularies or develops clinical practice guidelines that could influence the prescribing of
medicines or is otherwise affiliated with any other healthcare institution, medical committee, or
other medical or scientific organization, Principal Investigator will inform the committee of the
existence and nature of Principal Investigator's relationship with LBIO under this Agreement.
Principal Investigator also agrees to disclose Principal Investigator's relationship with LBIO as
needed to comply with any disclosure requirements of any healthcare institution, medical or
formulary committee, or other medical or scientific organization with which Principal Investigator
is affiliated and agrees to comply with any such entities' recusal or other requirements relating to
the relationship with LBIO. This duty to disclose will continue during the term of this Agreement
and for two years after its termination 6.3 LBIO Mandatory Disclosures. MD Anderson and Principal
Investigator recognize that LBIO may be required under Law, including the Physician Payment Sunshine
Act, to report to the relevant governmental or regulatory authorities or publicly disclose
information related to this Agreement and/or the Research, including any payments, reimbursements,
or other transfers of value made to MD Anderson or Principal Investigator. Nothing herein shall
prevent LBIO from making any reports or disclosures required under Law or by a relevant governmental
or regulatory authority. Moreover, nothing herein shall prevent LBIO from disclosing any information
relating to this Agreement and/or the Research for the purpose of making any regulatory or other
submissions, patent applications and pursuing patent prosecution.

12
<!-- page 13 -->
6.4 Publications. MD Anderson agrees to provide LBIO with a copy of any manuscript, abstract or
other proposed publication or presentation relating to the Research or the Materials (a
"Publication"), prior to submission thereof to a publisher or to any third party, and in any case,
not less than 45 days prior to any public disclosure, for the purpose of protecting proprietary or
intellectual property of LBIO that might be contained in such Publication. Following receipt of such
proposed Publication, LBIO shall have the right to cause MD Anderson to (i) withhold publication or
other public disclosure thereof for a period of up to 90 days in order to provide LBIO time to
obtain appropriate intellectual property protection thereof, and (ii) remove any proprietary, or
otherwise confidential, information of LBIO contained in such Publication (excluding Research
results). In any event, MD Anderson will not disclose proprietary, or otherwise confidential,
information in an "unblinded" manner when it can be done so in a "blinded" manner. In the event of
any Publication (including any public presentation relating to the Research or the Materials), MD
Anderson agrees to acknowledge LBIO and/or give credit to LBIO scientists, as scientifically
appropriate, based on any contribution they may have made to the work which shall be in accordance
with any relevant policies and guidelines of the publication, presentation forum, as well as
policies and guidelines of general applicability, such as the International Committee of Medical
Journal Editors recommendations. In addition, to the extent that it is legally able to do so, MD
Anderson hereby grants LBIO a royalty-free right and license to use and reproduce any Publication.
LBIO shall be acknowledged as a financial collaborator of the Study reported in a Publication. 6.5
Unauthorized Disclosure. Receiving Party shall be responsible for any breach of this Section 6 by
any of its Representatives. Receiving Party shall take reasonable steps to ensure that unauthorized
persons do not gain access to Disclosing Party's Confidential Information. Receiving Party shall
promptly notify Disclosing Party of any unauthorized release of or access to Disclosing Party's
Confidential Information. For clarity, such notice shall not remedy any breach of this Agreement
resulting from such unauthorized release or access. 6.6 Prior CDA. This Agreement supersedes that
certain Confidentiality Agreement between LBIO and MD Anderson, dated July 22, 2016 ("Prior CDA"),
which is hereby terminated; provided, however, that all information disclosed or received by the
Parties under the Prior CDA will be deemed Confidential Information hereunder (to the extent
applicable) and will be subject to the terms and conditions of this Agreement. The Parties agree
that this Agreement provides the written notice required for termination of the Prior CDA pursuant
to Section 6.8 of the Prior CDA. 6.7 Publicity. LBIO shall be permitted to publicly disclose the
existence of this Agreement, and the title and purpose of each clinical Study, in LBIO's electronic
materials, printed materials, oral presentations, and press releases, and LBIO shall be permitted to
include each clinical Study as a component of LBIO's clinical product pipeline. 6.8 Health
Information. Notwithstanding anything to the contrary in this Agreement or any Study Order, all
individually identifiable health information shall be treated as confidential by the Parties in
accordance with all Laws governing the confidentiality and privacy of individually identifiable
health information, including HIPAA, and any regulations and official guidelines promulgated
thereunder, and the Parties agree to take such additional steps and/or to negotiate such amendments
to this Agreement as may be required to ensure that the Parties are and remain in compliance with
the HIPAA regulations and official guidance.

13
<!-- page 14 -->
7. Inventions. 7.1 Background Intellectual Property and Definitions. (a) Neither Party will, as a
result of this Agreement, acquire any right, title or interest in, to, or under any Intellectual
Property (as defined below) owned or controlled by the other Party or the other Party's affiliates
prior to the Effective Date or developed independently of this Agreement ("Background Intellectual
Property"), except for the licenses expressly granted under this Agreement. (b) "Invention" means
any idea, invention or discovery, whether or not patented or patentable, that is first conceived,
discovered, developed or reduced to practice by a Party in connection with this Agreement, including
through MD Anderson's performance of the Research (solely or jointly with others) or that result, to
any extent, from use of Confidential Information or the Study article that is the subject of a given
Study, including any developments, discoveries, improvements, compositions, know-how, trade secrets,
procedures, technical information, data, reports, processes, methods, devices, formulae, protocols,
techniques, designs, drawings, methodologies, and biological or chemical material. (c) "Intellectual
Property Rights" means any and all moral rights and intellectual property rights, including all
patent rights, copyrights, trademarks, know-how and trade secrets and the rights to apply for the
same. (d) "Fields" means the treatment of platinum resistant ovarian cancer, chondrosarcoma, and
pancreatic ductal adenocarcinoma, and, solely for the purposes of Section 7.3(b), double refractory
melanoma, such treatment being performed using TILs manufactured by MD Anderson using a 4-1BB
agonist; provided that Fields shall also include the treatment of other diseases in the event that
the JSC decides to amend or replace the initially-agreed clinical Protocol for the Study Order
provided in Exhibit II to include the treatment of such other diseases. 7.2 Assignment of
Inventions; Further Assurances. (a) MD Anderson shall promptly make full written disclosure to LBIO,
shall hold in trust for the sole right and benefit of LBIO, and hereby assigns, transfers and
conveys to LBIO, or its designee, all of MD Anderson's worldwide right, title and interest in and to
any and all Inventions and all Intellectual Property Rights therein and relating thereto[, provided
that MD Anderson shall retain the right to use any such Invention for internal research, academic,
and patient care purposes]. MD Anderson further acknowledges and agrees that all original works of
authorship that are made by MD Anderson (solely or jointly with others) in the performance of the
Research, excluding any publication made in accordance with Section 6.4 (a "Work") and that are
protectable by copyright are "works made for hire," as that term is defined in the United States
Copyright Act. However, to the extent that any Work may not, by operation of any Laws, be a work
made for hire, MD Anderson hereby assigns, transfers and conveys to LBIO all of MD Anderson's
worldwide right, title and interest in and to such Work, including all Intellectual Property Rights
therein and relating thereto, subject to MD Anderson's right to use such Work for internal research,
academic, and non-commercial patient care purposes prior to publication or public disclosure.

14
<!-- page 15 -->
(b) Upon the request and at the reasonable expense of LBIO, MD Anderson shall execute and deliver
any and all instruments and documents and take such other acts as may be reasonably necessary to
document or perfect the assignment and transfer described in Section 7.2(a) or to enable LBIO to
secure its rights in the Inventions, Works and Intellectual Property Rights therein and relating
thereto in any and all jurisdictions, or to apply for, prosecute and enforce Intellectual Property
Rights in any and all jurisdictions with respect to any Inventions or Works, or to obtain any
extension, validation, re-issue, continuance or renewal of any such Intellectual Property Right. (c)
As between the Parties, and without limiting MD Anderson's assistance obligations under Section
7.2(b), LBIO shall have the sole and exclusive right to file patents covering or claiming Inventions
and shall bear all costs with respect to the prosecution and maintenance thereof. In furtherance of
the foregoing, the Parties shall work together in good faith to, as expeditiously as possible
following the Effective Date, put in place a power of attorney granted by the System to LBIO for
purposes of enabling LBIO to apply for or to pursue any application for any United States or foreign
patent, trademark, copyright or other registration covering Inventions or Works assigned to LBIO
hereunder in the event that LBIO is unable to secure MD Anderson's assistance in connection with the
same. 7.3 Background Licenses. (a) MD Anderson hereby grants LBIO a non-exclusive, royalty free,
perpetual license (with rights to sub-license) under, in and to all Background Intellectual Property
that is: (a) owned by MD Anderson; (b) consists of and/or comprises the manufacturing protocol
utilized by MD Anderson in the conduct of a Study; and (c) reasonably necessary to exploit
(including developing, obtaining and maintaining regulatory approval for, manufacturing, or
commercializing) any Invention, Study result, or Study article, or any improvement or derivative
thereof, strictly limited to the Fields (collectively, the "Non-Exclusively Licensed MD Anderson
Background Intellectual Property"), to the extent that such Non- Exclusively Licensed MD Anderson
Background Intellectual Property does not include Third Party IP (as defined hereinafter). (b) MD
Anderson also grants LBIO a non-exclusive, royalty free, perpetual license (with rights to
sub-license) under, in and to any and all data generated by MD Anderson in conducting studies of
TILs in double refractory melanoma outside of the Collaboration and as of the Effective Date, and
LBIO shall have unrestricted rights to use such double refractory melanoma data in governmental and
regulatory submissions, including submissions that may become public. 7.4 Third Party Intellectual
Property. To the extent that MD Anderson controls any Background Intellectual Property that it will
use in conducting a Study or manufacturing any Study article through a license agreement with a
third party ("Third Party IP"), MD Anderson shall notify LBIO thereof as soon as any such Third
Party IP is identified. MD Anderson shall not use any Third Party IP in performing activities under
this Agreement or otherwise in connection with a Study unless and until the JSC approves the use
thereof. In addition, MD Anderson shall provide such assistance as is reasonably requested by LBIO
in connection with LBIO obtaining a license in and to any such Third Party IP.

15
<!-- page 16 -->
7.5 No Implied Licenses; Retained Rights. Except as explicitly set forth in this Agreement, neither
Party grants any license, express or implied, under its intellectual property rights to the other
Party, whether by implication, estoppel or otherwise, and each Party hereby agrees that it does not
have rights under any intellectual property of the other Party that are broader than the licenses
expressly granted herein. 7.6 Effectiveness. The provisions of Section 7 shall become effective upon
payment by LBIO of the Upfront Payment and the approval by LBIO of the Study Orders in Exhibit I and
Exhibit III. For clarity, the commencement of work, or the lack thereof, under the Study Order in
Exhibit II shall have no effect upon the effectiveness of the provisions of Section 7. 8. Term and
Termination. 8.1 Term. The term of this Agreement commences on the Effective Date and shall continue
in effect until the later of (a) the fourth (4th) anniversary of the Effective Date, or (b) the
completion or termination of the Research and receipt by LBIO of all deliverables due from MD
Anderson hereunder, unless sooner terminated in accordance with the provisions of Section 2.2 or
Section 9.14. 8.2 Termination. Either Party may terminate this Agreement for the material breach or
default of any of the terms or conditions of this Agreement by the other Party upon thirty (30)
days' written notice and the opportunity to cure during such notice period; and such termination
shall be in addition to any other remedies that it may have at law or in equity. Additionally, LBIO
may terminate this Agreement if MD Anderson is declared insolvent or enters into liquidation or has
a receiver or an administrator appointed over all or any part of its assets or ceases or threatens
to cease to carry on business, or a resolution is passed or a petition presented to any court for
the winding up of the Party or for the granting of an administration order in respect of MD
Anderson, or any proceedings are commenced relating to the insolvency or possible insolvency of MD
Anderson. 8.3 Termination of a Study Order. LBIO may terminate a Study Order immediately upon
written notice to MD Anderson if: (i) the applicable approvals, authorizations, and/or continuing
reviews for a Study are not obtained or maintained; (ii) Principal Investigator is no longer
available for the Study and a replacement deemed acceptable by LBIO is not provided; (iii) the Study
is canceled, terminated, suspended, delayed or placed on hold for any reason; (iv) an Institutional
Review Board or other review authority, including governmental or regulatory authorities, does not
approve a Study or recommends the cancelation, termination, suspension, or hold of a Study for any
reason; (v) immediate termination of the Study is necessary due to LBIO's evaluation of risks to
Study subjects, such risks including the futility of treatment; or

16
<!-- page 17 -->
(vi) MD Anderson or Principal Investigator materially breaches any obligations with respect to the
Study, including failure to comply with this Agreement, the Protocol or the Study Order or any Law
relevant to the Study. 8.4 Obligations upon Termination. Upon expiration or termination of this
Agreement, in addition to its other obligations hereunder, including Section 5.2, MD Anderson shall
return to LBIO all of its Confidential Information and all Materials or, at LBIO's option, destroy
or completely delete such Confidential Information and Materials, at LBIO's option. With respect to
each item of Confidential Information and Materials destroyed or completely deleted, such
destruction or complete deletion shall be certified in writing to LBIO. In the event that this
Agreement is terminated prior to MD Anderson's receipt of all internal approvals to commence work on
the Study Orders in Exhibit I, Exhibit II and/or Exhibit III, MD Anderson shall refund the Upfront
Payment to LBIO. 8.5 Effects of Termination. Termination of this Agreement by either Party shall not
affect the rights and obligations of the Parties accrued prior to the effective date of termination.
No termination of this Agreement, however effectuated, shall release the Parties, the Principal
Investigator, or any other Representative of MD Anderson having access to Confidential Information
from their respective rights and obligations under Sections 6, 7, and 9. 9. Miscellaneous. 9.1
Mutual Representations. Each Party hereto hereby represents, warrants and covenants to the other
that: (a) it is duly incorporated or otherwise formed, validly existing and in good standing; (b) it
has taken all necessary actions on its part to authorize the execution, delivery and performance of
the obligations undertaken in this Agreement, and no other corporate or regulatory actions (e.g.,
obtaining permits, licenses or authorizations) are necessary with respect thereto; (c) it is not a
party to, and will not become a party to, any agreement or understanding and knows of no law or
regulation that would prohibit it from entering into and performing this Agreement, or that would
conflict with this Agreement; and (d) when executed and delivered by it, this Agreement will
constitute a legal, valid and binding obligation of it, enforceable against it in accordance with
this Agreement's terms. 9.2 MD Anderson Representations. MD Anderson represents, warrants, and, to
the extent applicable, covenants, that: (a) MD Anderson and all of its Representatives maintain as
current the applicable licenses and permits, including medical practitioner licenses as required by
the applicable national, state, and/or local licensing body and that no license or permit has been
revoked, limited, suspended, or otherwise modified. (b) Neither MD Anderson nor any of its
Representatives have (i) violated or caused a violation of any federal or state health care fraud
and abuse or false claims statute or regulation, including the anti-kickback provisions of the
Social Security Act, 42 U.S.C. § 1320a-7b(b), (ii) violated or caused a violation of any federal or
state privacy or security law or regulation, including HIPAA, (iii) not been excluded or threatened
with exclusion under state or federal statutes or regulations, including under 42 U.S.C. § 1320a-7
or relevant regulations in 42 C.F.R. Part 1001, or (iv) not been assessed or threatened with
assessment of civil money penalties pursuant to 42 C.F.R. Part 1003, or any foreign equivalent.

17
<!-- page 18 -->
(c) Neither MD Anderson nor any of its Representatives have been charged, named in an action, found
liable, or convicted for conduct relating to the development or approval of, or otherwise related to
the regulation of any healthcare product or the practice of medicine. (d) Neither MD Anderson nor
any of its Representatives (i) have been found by the FDA or any other relevant governmental or
regulatory authority to have violated any Laws, regulations or guidelines concerning the conduct of
clinical investigations or related services; (ii) have been debarred, denied, or suspended by the
FDA under 21 U.S.C. § 335a, disqualified or restricted by the FDA, named on any FDA list related to
investigator disqualifications, restrictions, restrictions removed, or adequate assurances, or are
otherwise ineligible to participate in federal procurement or non-procurement programs or any
foreign equivalents of the above; and (iii) have any unresolved FDA warning letter, Form 483, or
other regulatory enforcement action threatened against or issued to them; (e) MD Anderson and its
Representatives will not make and have not made any untrue statement of material fact to or filed a
false claim or report with any governmental or regulatory authority, or failed to disclose a
material fact required to be disclosed to any governmental or regulatory authority, or have ever
been investigated by the FDA, National Institutes of Health ("NIH"), Office of the Inspector General
for the Department of Health and Human Services ("OIG"), Department of Justice or other comparable
governmental or regulatory authority for data or healthcare program fraud. (f) There is no
investigation, threat, pending, or proposed proceeding, notice, or action by a governmental or
regulatory entity which could result in 9.2(a)-9.2(e) above. (g) MD Anderson has no knowledge of any
facts or circumstances that may affect the accuracy or completeness of any the foregoing
representations and warranties. MD Anderson is responsible for (i) requiring all of its
Representatives to disclose the occurrence of 9.2(a)-9.2(f) above and (ii) reviewing on reasonable
intervals all available public filings and lists to confirm that it and its Representatives are not
subject to 9.2(a)-9.2(f) above. If MD Anderson becomes aware of any such facts or circumstances
during the Term or otherwise determines that any representation or warranty made by it under this
Agreement is no longer true, correct, or complete, MD Anderson will notify LBIO immediately, but in
no case later than twenty-four (24) hours after MD Anderson becomes aware of such facts,
circumstances, or determination. MD Anderson shall immediately remove any of its Representatives
from performing activities relating to the Research to which the facts, circumstances, or
determination relate. Any such facts, circumstances, or determinations shall be grounds for
termination of this Agreement. (h) Each of MD Anderson's Representatives is under a written
obligation to assign to MD Anderson all Inventions and any Intellectual Property Rights therein or
relating thereto made by such Representative in the course of his or her employment. (i) Neither the
United States government nor any agency thereof nor any other third party has funded or will fund
any part of the Research.

18
<!-- page 19 -->
(j) MD Anderson's applicable database applications and electronic records systems and facilities
which are used in the performance of the Research, including the database to be used by MD Anderson
and Principal Investigator for the tracking, handling, recording, reporting and transmitting of data
generated during a Study, have been fully validated and are compliant with all Laws. (k) MD Anderson
is not entering into this Agreement (i) as a result of any pre-existing or future business
relationships between MD Anderson and/or Principal Investigator and LBIO, (ii) as a result of any
business or other decisions MD Anderson and/or Principal Investigator have made or may make in the
future relating to LBIO or LBIO products, or (iii) as a reward or in exchange for MD Anderson or
Principal Investigator prescribing or purchasing LBIO products or to induce the prescription or
purchase of LBIO products by MD Anderson or Principal Investigator. 9.3 Warranty of cGMP. LBIO
represents and warrants that any Study Drug (as defined in an applicable Study Order) manufactured
by and provided by it for any Study hereunder has been and will be manufactured in accordance with
current Good Manufacturing Practice regulations. 9.4 Independent Status. MD Anderson shall not be
considered a partner, co-venturer, agent, employee, or representative of LBIO by reason of this
Agreement, but shall remain in all respects an independent contractor, and neither Party shall have
any right or authority to make or undertake any promise, warranty or representation, to execute any
contract or otherwise to assume any obligation in the name of or on behalf of the other Party. MD
Anderson's employees, including the Principal Investigator and the other Representatives of MD
Anderson, are not and shall not be deemed to be employees of LBIO, and MD Anderson shall indemnify
and hold harmless LBIO from all liabilities arising from any allegation or determination to the
contrary. 9.5 Notices. All notices and other communications required or permitted hereunder shall be
in writing and deemed to have been given when hand delivered, or mailed by registered or certified
mail or overnight courier with tracking capabilities, as follows or as a Party may otherwise notify
to the other in accordance with this Section 9.5 (provided that such notice of change of address or
recipient shall be deemed given only when received), with an electronic copy to an email address if
specified below: If to LBIO, to: If to MD Anderson: Lion Biotechnologies, Inc. The University of
Texas M.D. Anderson Cancer Center 999 Skyway Road, Suite 150 1515 Holcombe Blvd. San Carlos, CA
94070 Houston, TX 77030 Attention: Legal Department Attention: Chief Legal Officer With a copy to:
legal@lionbio.com

19
<!-- page 20 -->
9.6 Assignment; No Third Party Beneficiaries. LBIO may assign or transfer this Agreement without the
prior written consent of but with written notice to MD Anderson promptly following consummation of
the relevant transaction. MD Anderson hereby acknowledges and agrees that the rights and obligations
hereunder are of a personal nature and, therefore, neither this Agreement nor any right or
obligation contained within shall be assignable, transferable or delegable in whole or in part by MD
Anderson and MD Anderson shall not, without the prior written consent of LBIO, sub-contract or
otherwise engage any consultant or other third party to perform any of MD Anderson's activities or
obligations under this Agreement or any Study Order. All of the terms and provisions of this
Agreement shall be binding upon, and inure to the benefit of and be enforceable by, the respective
successors and permitted assigns of the Parties. Nothing in this Agreement, express or implied, is
intended to confer on any person or entity, other than the Parties or their respective successors
and permitted assigns, any benefits, rights or remedies. 9.7 Governing Law, Jurisdiction. This
Agreement shall be governed by and interpreted in accordance with the laws of the State of Texas,
United States of America, without giving effect to any conflict of laws provisions. The Parties
agree that any dispute or controversy arising out of or relating to any interpretation,
construction, performance or breach of this Agreement may be brought in a United States District
Court in Texas, or if such court does not accept jurisdiction or will not accept jurisdiction, in
any court of general jurisdiction in the State of Texas. 9.8 Equitable Relief. MD Anderson agrees
that it may be impossible or inadequate to measure and calculate LBIO's damages from any breach of
MD Anderson's obligations under Section 6 and/or Section 7 of this Agreement, and that a breach of
such obligations could cause serious and irreparable injury to LBIO. Accordingly, LBIO shall have
available, in addition to any other right or remedy available to it, the right to seek an injunction
from a court of competent jurisdiction restraining such a breach (or threatened breach) and to
specific performance of any such Section. MD Anderson further agrees that no bond or other security
shall be required in obtaining such equitable relief. 9.9 Entire Agreement, Amendment and Waiver.
This Agreement contains the entire understandings of the Parties and supersedes all previous
agreements (oral and written), negotiations and discussions with respect to the subject matter
herein. The Parties may modify any of the provisions hereof only by an instrument in writing duly
executed by the Parties. No waiver of any rights under this Agreement shall be effective unless in
writing signed by the Party to be charged. 9.10 Severability. In the event of the invalidity of any
provisions of this Agreement containing any gaps, the Parties agree that such invalidity or gap
shall not affect the validity of the remaining provisions of this Agreement. The Parties will
replace an invalid provision or fill any gaps with valid provisions, which most closely approximate
the purpose and economic effect of the invalid provision or, in the case of a gap, the Parties'
presumable intentions. 9.11 Further Assurances. Each Party shall, as and when reasonably requested
by the other Party, do all acts and execute all documents as may be reasonably necessary to give
effect to the provisions of this Agreement. 9.12 Interpretation. The headings in this Agreement are
intended solely for convenience or reference and shall be given no effect in the construction or
interpretation of this Agreement. This Agreement shall be construed as if both Parties drafted it
jointly, and shall not be construed against either Party as principal drafter. The words "include",
"includes" and "including" (and words of similar meaning) shall be deemed to be followed by the
phrase "without limitation".

20
<!-- page 21 -->
9.13 Counterparts. This Agreement may be executed in two (2) or more counterparts, including by
"PDF" exchange, each of which shall be deemed to be an original as against any Party whose signature
appears thereon, but all of which together shall constitute but one and the same instrument. 9.14
Texas State Agency. MD Anderson is an agency of the State of Texas and under the constitution and
laws of the State of Texas possesses certain rights and privileges and only such authority as is
granted to it under the constitution and laws of the State of Texas. Notwithstanding any provision
hereof, nothing herein is intended to be, nor will it be construed to be, a waiver of the sovereign
immunity of the State of Texas or a prospective waiver or restriction of any of the rights,
remedies, claims, and privileges of the State of Texas. Moreover, notwithstanding the generality or
specificity of any provision hereof, the provisions of this agreement as they pertain to MD Anderson
are enforceable only to the extent authorized by the constitution and laws of the State of Texas.
9.15 DISCLAIMER OF SPECIAL DAMAGES. NEITHER LBIO NOR MD ANDERSON, NOR ANY OF THEIR AFFILIATES, NOR
ANY OF THEIR RESPECTIVE DIRECTORS, OFFICERS, MEMBERS OR EMPLOYEES, SHALL HAVE ANY LIABILITY OF ANY
TYPE, FOR ANY SPECIAL, PUNITIVE, INCIDENTAL, INDIRECT OR CONSEQUENTIAL DAMAGES, INCLUDING THE LOSS
OF OPPORTUNITY, LOSS OF USE, OR LOSS OF REVENUE OR PROFIT, IN CONNECTION WITH OR ARISING OUT OF THIS
AGREEMENT OR ANY STUDY ORDER; PROVIDED, THAT, THE FOREGOING DISCLAIMER SHALL NOT APPLY WITH RESPECT
TO (1) A PARTY'S INDEMNIFICATION OBLIGATIONS, (2) A PARTY'S BREACH OF ITS OBLIGATIONS UNDER THIS
AGREEMENT WITH RESPECT TO CONFIDENTIALITY AND NON-USE OR INTELLECTUAL PROPERTY-RELATED MATTERS OR
(3) A PARTY'S GROSS NEGLIGENCE OR WILLFUL MISCONDUCT. [Signature Page Follows]

21
<!-- page 22 -->
IN WITNESS WHEREOF, the undersigned, intending to be legally bound, have duly executed this
Agreement as of the Effective Date. LION BIOTECHNOLOGIES, INC. THE UNIVERSITY OF TEXAS M. D.
ANDERSON CANCER CENTER /s/ Maria Fardis /s/ Chris McKee Authorized Signature Authorized Signature
Name: Maria Fardis Name: Chris McKee, M.H.A. Title: CEO & President Title: VP, Business Operations
Date: April 17, 2017 Date: April 12, 2017 This Agreement is to be executed in duplicate. Please
return one fully executed copy to LBIO at the address for notices set forth above.
