# Implementation plan — deep research over a pre-filtered document set

Status legend: `[ ]` todo · `[~]` in progress · `[x]` done (skeleton in repo) · `[-]` dropped

Three approaches, built **one by one on a shared foundation**, each evaluated on the same
golden set before the next starts. Later phases depend on the contracts fixed in Phase 1.
Models: GPT-OSS / Nemotron Nano / Gemma via OpenAI-compatible endpoints only (see `CLAUDE.md`).

| Phase | What | Days |
|---|---|---|
| 0 | Setup, endpoints, corpus loading, golden set | 1–2 |
| 1 | Foundation: workspace, tools, evidence bank | 2–4 |
| 2 | **Approach 2** — filesystem agent (default loop) | 4–7 |
| 3 | Shared writer + tier-1 verifier + deadline (first full reports) | 7–9 |
| 4 | **Approach 1** — ephemeral BM25 deep list + first move + paging | 9–12 |
| 5 | **Approach 3** — planner-selected fan-out + extract grid | 12–16 |
| 6 | Three-way eval and ablations | 16–18 |
| 7 | Tier-2 verification + provenance gate | week 4 |
| 8 | Hardening, budgets, audit | week 4 |

---

## Phase 0 — Setup, endpoints, corpus loading, golden set (days 1–2)

Build the eval *before* the agent so every later phase has a number.

- [x] `pyproject.toml`; `pip install -e .[dev]` into `.venv`; `pytest -q` green (17 tests, no model calls).
- [x] `dr/llm.py::get_llm(role)` → `ChatOpenAI(base_url, model, api_key)` per role from env
      (`DR_ENDPOINT_<ROLE>`, `DR_MODEL_<ROLE>`). Roles: planner, researcher, writer, verifier,
      extractor, judge. Defaults: planner/researcher → GPT-OSS; extractor/verifier → Nemotron
      Nano; writer/judge → Gemma. `FakeLLM` for tests.
- [x] **Endpoint capability probe** (`scripts/probe_endpoints.py`, run 2026-11-01 against NVIDIA Build; `docs/endpoints.md` holds the tables and dated notes — back it up before re-running, the script rewrites it): for each model confirm
      (a) OpenAI `tools` param + parallel tool calls, (b) JSON/structured output, (c) context
      length, (d) measured concurrency and p50 latency for a 2K-in/300-out call. Record in
      `docs/endpoints.md`. If Gemma fails (a), it is writer/judge only; if GPT-OSS emits one
      tool call per turn, the harness fans out clue retrieval itself (Phase 4).
- [x] `dr/ingest/load.py`: load existing markdown + metadata into `DocRecord`s; content-hash
      `doc_id`; verify `<!-- page N -->` markers exist.
- [~] `dr/ingest/metadata.py`: parse the metadata block from the first ~2 pages into
      `ManifestEntry` fields (title, doc_type, date, parties, …). Write a sidecar `meta.json`
      per doc. **Decision:** keep the in-body block (simplest) vs. strip it to a sidecar /
      YAML front matter so body line numbers stay clean for citations — recommended sidecar.
      Fallback extractor: Nemotron Nano over the first 2 pages → structured JSON (this is the
      "document card" and costs ~1 call/doc, one-time).
      *Status:* deterministic parser done (front matter, `Key: Value`, markdown table) and tested;
      `load.py` reads a `.meta.json` sidecar if present but `scripts/make_cuad_corpus.py` writes one per CUAD document; the LLM
      fallback is a stub; the sidecar-vs-in-body decision is not yet recorded.
- [ ] `dr/ingest/pages.py`: only if markers are missing — derive page boundaries from the PDFs
      (pymupdf page text ↔ markdown alignment) and insert markers.
- [x] **Golden set v1** (`data/golden/questions.jsonl`, 42 synthetic questions over 31 docs, plus `cuad_questions.jsonl`, 112 questions over 510 real contracts, and the 12-question `cuad_smoke.jsonl`; see `data/golden/README.md`) with gold `doc_id` +
      page. Mix: single-doc factoid · multi-doc synthesis · exact identifier/amount ·
      "across all these documents" coverage · not-in-corpus (≥ 10%) · version/date-sensitive.
      Prefer real user asks; developer-written questions are too easy.
- [x] `dr/eval/golden.py` loader + schema validation (rejects a set with no `not_in_corpus` questions).

**Accept when:** `pytest -q` passes; `docs/endpoints.md` filled for all three models;
`python -m dr.eval.run --dry` lists golden questions; 1,000 docs load in < 10 s; every doc
has page markers and a manifest entry.

---

## Phase 1 — Foundation: workspace, tools, evidence bank (days 2–4)

Given a list of `DocRecord`s, produce a per-query workspace and a tested, framework-agnostic
tool set. **No model calls in this phase.**

- [x] `dr/models.py` — pydantic contracts (DocRecord, ManifestEntry, Grep*, Read*, Outline*,
      EvidenceItem, Finding, Clue/FirstMoveResult, RouteDecision, OutlineSection, Claim, VerifyResult).
- [x] `dr/workspace.py::Workspace.materialize(docs, root)` — writes `docs/<doc_id>.md`,
      `manifest.json`, line→page map; `page_of()`, `path_of()`, `line_count()`, path-escape guard.
- [x] `dr/tools/grep.py` — regex over the workspace; per-doc counts, total, capped matches with
      context, `truncated`; pure-Python with `rg` acceleration; `doc_ids` scoping.
- [x] `dr/tools/read.py` — `read(doc_id, start_line, n_lines)` → line-numbered window with page
      annotations, capped; read tracker returns `already_read=True` with no text on repeats.
- [x] `dr/tools/outline.py` — headings with line numbers and pages (the agent's TOC).
- [x] `dr/tools/manifest.py` — `list_docs(doc_ids?)` compact rows from metadata.
- [x] `dr/tools/registry.py` — `ToolSpec`s + `as_langchain_tools(workspace, …)`; add
      LlamaIndex / internal-SDK adapters here if needed.
- [x] `dr/evidence.py` — `EvidenceBank` JSONL: `add()`, `get()`, `by_sub_question()`,
      overlap dedupe, `render_for_writer()`.
- [ ] `dr/tools/bash.py` — sandboxed shell restricted to the workspace (allow-list
      `rg|grep|wc|head|tail|sort|uniq|cut|awk|sed -n`), 10 s timeout, output cap; off by default.
- [x] `dr/tools/offload.py` — write tool results > `OFFLOAD_TOKENS` to `workspace/tool_out/`
      and return a pointer + preview (`OFFLOAD_PREVIEW_LINES`).
- [x] `tests/test_tools.py` on synthetic docs; add 1,000-doc perf test (`tests/test_perf.py`).

**Accept when:** tool tests pass; pure-Python `grep` over a 1,000-doc workspace (~50 MB)
returns in < 1 s; every tool result ≤ its cap; `../` and absolute paths are rejected.

---

## Phase 2 — Approach 2: filesystem agent (days 4–7)

One ReAct agent over the workspace tools. This is the default path and the eval floor.

- [x] `prompts/researcher.md` (drafted, untested against a model): role, tool descriptions,
      evidence-writing contract (verbatim quote + doc_id + line range + one-line note), stop condition, "submit requires ≥ 1
      evidence ID per claim", not-in-corpus answer allowed.
- [x] `prompts/width_turn.md` (drafted): **per-turn** nudge — "issue up to 3 independent tool calls this
      turn; start wide, narrow as evidence accumulates" (W&D: works better than system prompt).
- [x] `dr/agents/researcher.py`: LangGraph ReAct loop with parallel tool execution,
      `RESEARCH_MAX_CALLS` (25) and `RESEARCH_MIN_CALLS` (6), token cap, offload, `add_evidence`
      and `submit` tools. Tools exposed: `grep`, `read`, `outline`, `list_docs`,
      `add_evidence`, `submit` (≤ 6 — small-model rule).
      *Status:* implemented as a LangGraph state machine (`ResearchLoop`): per-turn width message
      with a (3, 2, 1) wide-to-narrow schedule, search tools in parallel, `add_evidence` sequential,
      `submit` last; call budget, min-calls floor, exact-repeat short-circuit, offload, compaction
      (`RESEARCH_MAX_CONTEXT_TOKENS`), deadline with forced submit, document scoping for fan-out.
      16 harness tests with a scripted model (`tests/test_researcher.py`); **run live on the sample, synthetic and CUAD corpora (docs/findings.md §4, §8)**.
- [x] Small-model robustness: pydantic-validated tool args with one repair retry; if the model
      emits malformed calls twice, fall back to a constrained "pick one tool" JSON step.
      *Status:* validation errors come back as tool results; after `MALFORMED_TURNS_MAX` all-malformed
      turns the `constrained` node asks for one call as bare JSON (`prompts/constrained_call.md`,
      one repair), then the run ends as `stalled` with a low-confidence Finding from the bank.
- [x] `dr/trace.py`: per-call events → `workspace/trace.jsonl` (wired into the loop: stage start/end,
      model, tool, submit, tool_repeat, tool_offload, compaction, model_error, force_skip).
- [x] Minimal answer path: `Finding` + evidence IDs rendered as a short cited answer (full
      report writer comes in Phase 3). `render_finding(finding, bank)` resolves `[e<n>]` to
      `[doc_id p.N]`; a forced or stalled run yields a low-confidence Finding built from the bank.
- [~] `notebooks/01_approach2_filesystem_agent.ipynb`: 5 golden questions end-to-end (written;
      not executed — needs the researcher endpoint).

**Accept when:** on single-doc + multi-hop slices, **opened-or-cited recall** ≥ 0.8; median
calls within [MIN, MAX]; p95 wall-clock < 150 s; no tool result exceeds caps; GPT-OSS
malformed-call rate < 5% after repair.

---

## Phase 3 — Shared writer, tier-1 verifier, deadline (days 7–9)

Turn an evidence bank into a report whose every sentence is bound to evidence, then check it.

- [x] `prompts/outline.md`: outline **from the question alone** (before evidence); one revision
      pass with Expansion / Contraction / Revision ops given the bank summary. Cap 2 iterations.
      *Status:* `outline.md` + `outline_revise.md` (revision and evidence assignment in one JSON call,
      one repair retry via `json_repair.md`; `dr/structured.py::ModelCaller`).
- [x] `dr/agents/writer.py` (Gemma): assign each `EvidenceItem` to ≤ 1 section; draft section by
      section from only that section's items with `{{CITE:e<n>}}`; prune after each section;
      assemble; resolve to `[doc_id p.N]`. Unmarked sentences → flagged coverage gaps.
      *Status:* `write_report()` = outline → revise+assign (code enforces ids exist and appear once;
      keyword heuristic for leftovers or when the deadline is near) → parallel section drafts →
      sentence-level `Claim`s → markdown rendered FROM claims. Uncited sentences are `[uncited]`,
      `[GAP]` lines stay as written, empty bank → all gaps + partial. Markers written after the
      period are moved before it. Scripted-model tests in `tests/test_writer.py`.
- [x] `dr/verify/tier1.py`: 5-gram alignment of quote vs. cited page → `keep | truncate | drop`;
      zero-overlap → search other workspace docs for the true source. Implemented; wire it.
- [x] `dr/verify/report.py`: apply tier 1 to every claim; emit `VerifyResult`s + appendix.
      *Status:* claim status = worst of its citations (unknown id = drop); dropped sentences are
      replaced by `[DROPPED: claim …]`, truncated ones flagged `[partially supported]`; tier-1 status
      persisted on the bank; `report.md` + `verify.json` written to the run folder.
- [x] `dr/graph.py`: deadline (`TOTAL_BUDGET_S` = 300) with stage budgets; on deadline, skip
      remaining research and write from the bank, marking the report partial.
      *Status:* `Pipeline` (LangGraph: materialize → research | write → verify). Research gets
      min(RESEARCH, time left − WRITE − VERIFY − RESERVE) and is skipped when nothing is left; the
      writer skips its revision pass below half of WRITE. Only `A2_fs_agent` is wired; other variants
      raise `NotImplementedError`. Per-stage ms and errors in `RunState`; `tests/test_graph.py`.
- [~] `notebooks/02_end_to_end_a2.ipynb`: question → report + verification appendix (written).

**Accept when:** 100% of claims carry ≥ 1 evidence ID or a gap flag; tier-1 support rate
≥ 0.9; nothing survives with `drop`; p95 end-to-end ≤ 300 s; deadline path exercised in a test.

---

## Phase 4 — Approach 1: ephemeral BM25 deep list + first move + paging (days 9–12)

Adds retrieval depth before and during the loop. BM25-only unless a local embedder is approved.

- [x] `dr/tools/bm25.py`: `bm25s` over paragraph chunks (~300 tokens, header-prefixed), built
      lazily per query (< 3 s for 1,000 docs); `search(query, k)` → compact hits; cached
      ranking to depth 1,000 for `page_results(n)`.
      *Status:* `BM25Index` with our own tokenizer (keeps `FAC-2024-0117`-style ids whole); chunks cut
      at headings / blank lines; ~2.7 s for a dense 1,000-doc synthetic corpus (17k chunks) on a laptop.
- [x] `dr/tools/page_results.py`: 10 hits per page over the cached ranking. *Folded into
      `bm25.py::BM25Index.page()`; exposed as the `page_results` tool in `registry.py`.*
- [x] `prompts/first_move.md` + `dr/agents/first_move.py`: decompose into 5–10 clues (entities,
      identifiers, dates, phrasings) each with grep patterns + a BM25 query; run them **in the
      harness, in parallel** (not dependent on the model's multi-tool support); union; optional
      local cross-encoder rerank (`dr/tools/rerank.py`, no-op if unavailable); emit opening
      observation (top ~10 with snippets) + cached deep ranking.
      *Status:* planner JSON with one repair, `fallback_clues` from the question text when the model
      fails; grep + BM25 per clue in a thread pool; docs ranked by (clues hit, score); opening
      observation with per-clue counts, top candidates and line-cited hits; `rerank.py` no-op hook.
- [x] `prompts/router.md` + `dr/agents/router.py`: `RouteDecision{single | breadth |
      long_context}`; `long_context` only if first-move evidence < `LONG_CONTEXT_MAX_TOKENS`
      (100K) **and** the question is holistic.
      *Status:* code guards in `apply_guards` (long_context refused above the token estimate, breadth
      without sub-questions gets doc batches, unknown modes → single); breadth/long_context are
      recorded but run as single until Phase 5.
- [x] Wire materialize → first_move → router → researcher; researcher tool set becomes
      `search`, `page_results`, `grep`, `read`, `add_evidence`, `submit` (`outline`/`list_docs`
      folded into the opening observation to stay ≤ 6 tools).
      *Status:* `A1_deep_list` variant in `dr/graph.py`; per-tool help now comes from
      `prompts/tool_help.md` so the system prompt describes only the exposed tools.
- [~] `notebooks/03_approach1_deep_list.ipynb` (written, not executed).
      *Live A1 run (q011 temporal, 31-doc synthetic corpus):* first move 27 s with candidate recall 1.0
      (gold doc rank 2), router single, research 42 s, write 3.9 s once writer thinking was disabled
      (`DR_THINKING_WRITER=0`; with thinking: 188 s and a timeout), verify 4 ms; 76 s total, all cited
      claims kept. Then added: per-clue pseudo-relevance feedback expansion (`BM25Index.expand_query`,
      query-time only) and an evidence-bounded outline with empty sections collapsed into one gaps
      section; same question 61 s, a governing-law question 43 s, both fully cited. BM25 k1/b left at
      defaults on purpose: tuning them fits the corpus and needs a held-out split (Phase 6).
      CUAD (510 real contracts, 9,348 pages, 112 questions) is in `data/cuad_docs` / `data/golden/`.

**Accept when:** first move < 30 s p50; **candidate recall** (gold doc in first-move union)
≥ 0.9; Approach 1 vs Approach 2 delta recorded on every slice; router agreement with
hand-labeled mode ≥ 0.85.

---

## Phase 5 — Approach 3: planner-selected fan-out + extract grid (days 12–16)

For "across all these documents, list every X" questions, where single-agent search under-samples.

- [x] `dr/agents/fanout.py`: LangGraph `Send` to 4–6 **context-isolated researchers** (GPT-OSS),
      each with a sub-question *or* a doc batch of 30–50 ids, tools scoped to those ids,
      `FANOUT_MAX_CALLS` (12), schema-validated `Finding` ≤ 1.5K tokens, evidence into the
      shared bank; reject + retry once on contract violation.
      *Status:* units are full `ResearchLoop`s in a thread pool of `FANOUT_WIDTH` (not LangGraph
      `Send`: same fan-out, contract kept in plain code, each unit owns its deadline); scoped tools,
      fresh transcript, `created_by="fanout:<i>"`, answer cap enforced, unknown ids dropped, a unit
      with no submission retried once then recorded as a failed hand-off.
- [x] `dr/tools/extract.py` (Nemotron Nano): the **grid** — a structured question over N docs in
      parallel → `{answer, quote, doc_id, line_range}` each → evidence bank. Concurrency from
      the Phase 0 probe; ≤ 90 s for 1,000 docs.
      *Status:* per document the extractor sees the head + its best BM25 chunks for the question
      (numbered lines, `EXTRACT_DOC_MAX_TOKENS`); quotes pass the bank's verbatim guard or are
      rejected and counted. 1,000-doc timing not yet measured live.
- [x] One **gap-check round** max: planner lists uncovered sub-questions → targeted calls →
      patch; previously verified claims must survive (regression check).
      *Status:* `prompts/gap_check.md` → up to `GAP_UNITS_MAX` targeted units inside the GAP budget;
      the bank is append-only so earlier evidence survives; claim-level regression is verification's job.
- [x] Router emits `breadth` with `doc_batches` or `sub_questions` (prompt now asks for one
      sub-question per listed document; code builds batches when none are given).
- [ ] Optional spike: the same branch on `deepagents` (`task` sub-agents + virtual FS) with
      GPT-OSS — record whether it is viable with these models (see `TODO.md`).
- [~] `notebooks/04_approach3_fanout.ipynb` (written, not executed). Variants `A3_fanout` and
      `A3_grid_only` are in the eval runner; `tests/test_fanout.py` covers grid, contract, gap round, graph.
      *Live (CUAD cq077, 8 agreements):* 4 iterations, see `eval/README.md`; v4 = 33 claims, no failed
      hand-offs, 111 s, 436k tokens, judge still failing on two agreements (clause worded without
      "non-compete"; a judgment call). Units are scoped to the agreements they name (`docs_named_in`)
      and briefed with the document outline.

**Accept when:** on the coverage slice, item-level recall ≥ 1.5× Approach 1/2; token cost
≤ 5× single-agent; zero unvalidated hand-off returns reach the writer; gateway concurrency
never exceeded.

---

## Phase 6 — Three-way eval and ablations (days 16–18)

- [x] `dr/eval/metrics.py` (candidate / opened-or-cited recall, gold-page-cited, support rate, hallucination
      gate, gap rate, contains-answer, item recall, abstention, rubric judge with an `unknown` verdict via
      `prompts/judge.md`, per-slice `summarize` + markdown table): candidate recall, **opened-or-cited recall**, tier-1 support rate,
      completeness/correctness via LLM judge with rubric (`prompts/judge.md`, "Unknown" option),
      not-in-corpus abstention, hallucination gate, wall-clock, tokens, **cost per correct answer**.
- [x] `dr/eval/run.py` (thread pool, `--limit/--qids/--types/--no-judge`, per-question errors recorded,
      run folders kept under `eval/results/runs/`): runs a variant over the golden
      set with concurrency control →
      `eval/results/<variant>-<ts>.jsonl` + per-slice summary.
- [~] Variants: `A2_fs_agent`, `A1_deep_list`, `A1_no_first_move`, `A3_fanout`,
      `A3_grid_only`, `LC_small` (router-forced), `A2_grep_only`, `A1_bm25_only`.
      *Status:* `VARIANTS` table in `dr/graph.py` implements the first five (A2 + A1 and their
      ablations); `A3_fanout` and `A3_grid_only` were added in Phase 5; `LC_small` is not implemented.
- [ ] Per-role model swaps (GPT-OSS 120B vs 20B as researcher; Nemotron vs Gemma as writer).
- [ ] `eval/README.md`: results table by slice; recommendation for the production default.

**Accept when:** every variant has results; the table answers "which approach, for which
question type, at what cost"; the recommended default is written down with its numbers.

---

## Phase 7 — Tier-2 verification and provenance gate (week 4)

- [x] `dr/verify/tier2.py` (Nemotron Nano / GPT-OSS): group 5–10 related claims → verifier agent
      re-checks against the workspace with `grep`/`read` → `supported | partially | unsupported`.
      Sampled on clean reports, 100% on flagged; ≤ 60 s.
      *Status:* grouped JSON review (groups of 8) with the cited quote + 12 lines of context per
      citation instead of a tool loop; flagged claims always, clean sampled at 20 %; `unsupported`
      flags the sentence and fails the gate; never overrides a tier-1 drop. Wired into
      `finalize_report` and the graph; verifier = Lightning without thinking.
- [x] `dr/verify/provenance.py`: MinHash near-duplicate clustering at materialize time; a claim
      is multi-sourced only across ≥ 2 clusters; appendix shows cluster count per claim.
      *Status:* computed lazily for the documents a report cites (cached per workspace), plus
      `cluster_all` with LSH banding for corpus statistics. Calibrated thresholds: 0.95, or 0.8 when
      both documents list the same parties (templated agreements for different borrowers reach 0.94).
- [x] Seeded test: plant 10 wrong claims → tier 2 flags ≥ 80%.
      *Live:* `tier2.seeded_check` on the synthetic corpus: 10/10 planted errors flagged, 0 false
      flags (after fixing the perturbation to change substantive values, not section numbers).

---

## Phase 8 — Hardening and operability (week 4)

- [ ] Stage budgets tuned from traces (first move ≤ 30 s · research ≤ 150 s · gap ≤ 45 s ·
      write ≤ 45 s · verify ≤ 30 s · reserve).
- [ ] Cost: prompt-cache the stable prefix (system prompt + manifest); `reasoning_effort` per
      role; read tracker; tool-output caps.
- [ ] Tripwires with tests: under-fill (workspace < expected docs), duplicate flood, loop stall
      (same tool+args ≥ 3×), under-search (calls < floor), deadline hit.
- [ ] Audit export per run: `trace.jsonl` + evidence bank + verification appendix; redaction hook.
- [ ] `notebooks/05_ablations.ipynb` + one-page architecture summary.

---

## 5-minute budget (default allocation)

| Stage | Budget | Config |
|---|---|---|
| Materialize (+ TOC / BM25 build) | ≤ 10 s | `MATERIALIZE_BUDGET_S` |
| First move (A1) | ≤ 30 s | `FIRST_MOVE_BUDGET_S` |
| Research (single or fan-out) | ≤ 150 s | `RESEARCH_BUDGET_S`, call caps |
| Gap round (once, optional) — runs **inside** the research budget | ≤ 45 s of the 150 s | `GAP_BUDGET_S` |
| Outline + write | ≤ 45 s | `WRITE_BUDGET_S` |
| Verify (tier 1 always; tier 2 sampled) | ≤ 30 s | `VERIFY_BUDGET_S` |
| Reserve | 30 s | `RESERVE_S`; deadline forces write from bank |

Sequential stages sum to 265 s; with the 30 s reserve that is 295 s ≤ 300 s. `StageBudgetsS`
in `dr/config.py` rejects any configuration where stages + reserve exceed `TOTAL` or the gap
round does not fit inside research. Small models are faster per call but need more calls;
re-tune after the Phase 0 probe.

## Prompts inventory (`prompts/`)

`first_move.md` · `router.md` · `researcher.md` · `width_turn.md` · `fanout_researcher.md` ·
`extract.md` · `outline.md` · `writer_section.md` · `verifier_tier2.md` · `judge.md` ·
`metadata_extract.md` *(not written; the LLM metadata fallback is a stub)*

## Golden set spec (`data/golden/questions.jsonl`)

```json
{"qid": "q001", "type": "single|multihop|identifier|coverage|not_in_corpus|temporal",
 "question": "...", "gold_docs": [{"doc_id": "...", "pages": [3,4]}],
 "gold_answer": "...", "gold_items": ["..."],
 "rubric": ["must mention X", "must cite the 2024 amendment"], "notes": ""}
```

## Risks and mitigations

| Risk | Mitigation |
|---|---|
| Small models call tools unreliably | ≤ 6 tools, flat schemas, pydantic repair retry, harness-side fan-out for the first move, constrained fallback step; measure malformed-call rate |
| Lexical-only misses paraphrase | Agent reformulation (BRIGHT-Pro), ephemeral BM25, grep alternations, optional local cross-encoder; eval slice tracks it; upgrade path is *adding* a dense tool |
| Markdown lacks page markers / metadata noisy | `ingest/pages.py` from PDFs; Nemotron metadata extractor fallback |
| Under-search | Min-calls floor; per-turn width message; calls/question in eval |
| Silent fan-out hand-off failures | Schema-validated returns; retry once; orchestrator spot-checks 1 evidence ID per Finding |
| Near-duplicate corroboration | Provenance gate (Phase 7) |
| Deadline → thin reports | Write from bank with explicit gaps; never time out silently |
| Endpoint concurrency | Probe first; fan-out width and grid concurrency from config |

## Open decisions for the team

1. Confirm model ids, endpoint URLs, and which endpoints support `tools` / parallel tool calls.
2. Sandboxed `bash` acceptable? If not: grep/read/outline only.
3. Ephemeral per-query BM25 acceptable under "no index"? (Recommended yes.)
4. Local sentence-transformers embedder / cross-encoder permitted? (Enables hybrid A1 + rerank.)
5. Metadata: leave in body, or move to sidecar JSON / front matter? (Recommended sidecar.)
6. Report format: markdown + citation appendix, or JSON for a downstream UI?
7. Golden-set owners; can questions come from real user requests?

## Out of scope

Knowledge graphs / GraphRAG · persistent indexes · model training · web search ·
multi-tenant permissions (handled upstream by the filter).
