<!-- page 1 -->
# AMENDMENT TO SERVICES AGREEMENT
| Field | Value |
|---|---|
| Document Type | Service Agreement |
| Agreement Date | 2009-03-30 |
| Parties | FEDERATED INVESTMENT MANAGEMENT COMPANY ("Adviser"); FEDERATED ADVISORY SERVICES COMPANY ("FASC") |
| Source | CUAD v1 / FEDERATEDGOVERNMENTINCOMESECURITIESINC_04_28_2020-EX-99.SERV AGREE-SERVICES AGREEMENT_AMENDMENT |

AMENDMENT TO SERVICES AGREEMENT

This AMENDMENT TO SERVICES AGREEMENT, dated and effective as of March 30, 2009 (this "Amendment"),
is made between FEDERATED INVESTMENT MANAGEMENT COMPANY, a Delaware statutory trust (the "Adviser"),
and FEDERATED ADVISORY SERVICES COMPANY, a Delaware statutory trust ("FASC"). Capitalized terms
used, but not defined, in this Amendment have the meanings given to such terms in the Services
Agreement (as defined below).

RECITALS

WHEREAS, the Adviser and FASC have entered into that certain Services Agreement dated as of January
1, 2004 (as amended, the "Services Agreement"), pursuant to which FASC provides certain performance
attribution, administration and risk management, equity trading and transaction settlement,
fundamental analysis, and quantitative analysis services to Adviser in connection with Adviser
providing investment advisory or sub-advisory services to investment companies registered under the
Investment Company Act of 1940 ("1940 Act") and/or separate accounts not required to be so
registered (collectively, "Accounts"); and

WHEREAS, the Adviser and FASC desire to amend the Services indicated in Exhibit A to the Services
Agreement, solely with respect to Accounts that are not investment companies registered under the
1940 Act, to provide that, as part of the administration and risk management services provided by
FASC, FASC may provide certain coordination of client portfolios and related fixed income trade
execution implementation and administration services to Adviser when Adviser is acting as adviser or
sub-adviser with respect to such Accounts.

NOW, THEREFORE, the parties hereto, intending to be legally bound, agree as follows:

1. Amendment to Exhibit A to Services Agreement. Solely with respect to Accounts that are not
investment companies registered under the 1940 Act, the section of Exhibit A to the Services
Agreement entitled "Administration and Risk Management" shall be, and hereby is, deleted in its
entirety and replaced with the following:

"2. Administration and Risk Management. Employees of Federated Advisory Services Company provide
support to portfolio managers and other employees of affiliated advisers. Such services may include
development of risk management programs, production of portfolio and compliance reports for clients
and/or fund Boards, coordination of client portfolios and related fixed income trade execution
implementation and administration, completion of required broker and custody documentation,
development and documentation of operational procedures, coordination of proxy voting activities,
on-site support of hardware and software, etc."

2. Miscellaneous. This Amendment shall be effective as of the date first above written upon its
execution and delivery by each of the parties hereto. The Services Agreement, as amended by this
Amendment with respect to Accounts that are not investment companies registered under the 1940 Act,
shall remain in full force and effect. The Services Agreement also shall remain in full force and
effect without amendment with respect to Accounts that are investment companies under the 1940 Act.
This Amendment shall be governed by and construed in accordance with the laws of the Commonwealth of
Pennsylvania. This Amendment may be executed in one or more counterparts, each of which will be
deemed to be an original copy of this Amendment and all of which, when taken together, will be
deemed to constitute one and the same agreement.

IN WITNESS WHEREOF, the parties hereto, through their duly authorized officers, have executed this
Amendment as of the date first above written.

FEDERATED INVESTMENT MANAGEMENT FEDERATED ADVISORY SERVICES COMPANY

COMPANY

By: /s/ John B. Fisher By: /s/ J. Christopher Donahue

Name: John B. Fisher Name: J. Christopher Donahue

Title: President Title: Chairman
