<!-- page 1 -->
# Media Content and License Agreement
| Field | Value |
|---|---|
| Document Type | License Agreement |
| SEC Filing Date | 2006-12-01 |
| Parties | Watchit Media; Oceanic Time Warner Cable |
| Source | CUAD v1 / WatchitMediaInc_20061201_8-K_EX-10.1_4148672_EX-10.1_Content License Agreement |

Exhibit 10.1

Oceanic Time Warner Cable and Watchit Media Content and License Agreement

Effective Dates: September 1, 2006, August 31, 2007

Watchit agrees to provide Oceanic Time Warner Cable the following content:

- Watchit Gaming Guides - Lunchtime with Ira segments every week

Watchit will provide the content on BetaSp format and reserves the right to modify the content to
reflect sponsorship by an advertiser and advertisers.

Oceanic Time Warner Cable agrees to not edit or modify the above content.

Oceanic Time Warner Cable will use the content solely on channel 777, the Las Vegas channel.

In the event that Oceanic Time Warner Cable removes the above content and or terminates this
agreement prior to December 31, 2006, Oceanic Time Warner Cable agrees to pay a cancellation fee of
Five Thousand Dollars ($5,000) per month multiplied by the number of months remain on the agreement.

Watchit shall have the exclusive right to sell third party advertising as sponsors of their content
and will have the right to brand the content under the Watchit brand and place a "bug" on the screen
identifying the content with a Watchit trademark.

Oceanic Time Warner Cable will include the following disclaimer on the Watchit Content: "The
materials shown are for entertainment purposes only and does not provide any guarantees of winning
or improving your odds of winning on this program. The rules of the games as shown may not apply to
all properties and may change from time to time."

Ocean Time Warner Cable will provide Watchit with data on viewership to both Channel 777 and
specifically to the content provided by Watchit.

Ocean Time Warner Cable will be able to not include any content that it deems inappropriate or
distasteful.

This agreement will be in effect until the end of 2006 and will be evaluated at that time.

Both parties agree to discuss use of information gathered form this arrangement before using it in
any kind of promotional or public message.

Accepted by:

Oceanic Time Warner Cable/Date

Watchit Media/Date

Source: WATCHIT MEDIA, INC., 8-K, 12/1/2006
