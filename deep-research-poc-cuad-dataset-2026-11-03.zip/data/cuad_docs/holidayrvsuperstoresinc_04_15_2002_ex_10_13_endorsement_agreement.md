<!-- page 1 -->
# ENDORSEMENT AGREEMENT
| Field | Value |
|---|---|
| Document Type | Endorsement Agreement |
| Agreement Date | 2002-03-20 |
| Parties | Holiday RV Superstores, Inc. d/b/a Recreation USA ("Company"); Affinity Group, Inc. ("AGI"); Company and AGI (each a "Party" and collectively the "Parties") |
| Source | CUAD v1 / HOLIDAYRVSUPERSTORESINC_04_15_2002-EX-10.13-ENDORSEMENT AGREEMENT |

EXHIBIT 10.13

ENDORSEMENT AGREEMENT

This Agreement is made as of the 20th day of March 2002, by and between Holiday RV Superstores,
Inc., d/b/a Recreation USA (the "Company"), a Delaware corporation having its principal office at
200 East Broward Boulevard, Suite 920, Ft. Lauderdale, Florida 33301, and Affinity Group, Inc.
("AGI"), a Delaware corporation having its principal office located at 2575 Vista Del Mar Drive,
Ventura, California 93001 (each a "Party" and collectively the "Parties").

WHEREAS, the Company is a multi-state chain of dealerships engaged in the retail sales of service of
recreational vehicles (the "Business"); and

WHEREAS, AGI, either directly or through subsidiaries, operates the "Good Sam" club for recreational
vehicle enthusiasts; and

WHEREAS, the Company has determined that it would be beneficial sell vehicles with the Good Sam
endorsement; and

WHEREAS, the Company has raised capital that it represents will be sufficient to fund its operations
as projected for at least the next year and AGI is willing to make the Good Sam name available as an
endorsement for certain vehicles sold by the Company on the terms and for the consideration set
forth herein.

NOW THEREFORE, in consideration of the foregoing and the promises contained herein and other good
and valuable consideration, the receipt and sufficiency of which are acknowledged, the parties agree
as follows:

1. License of Good Sam Name and Logo.

A. AGI hereby grants a non-exclusive license (the "License") to the Company and its operating
subsidiaries now or hereafter existing to use the Good Sam name and logo, including trademarks,
trade names, or service marks as designated by AGI (the "Trademarks"), in connection with the sale
of such new and used vehicles by the Company that have satisfied such criteria and standards as are
established from time to time by AGI (the "Approved Use"). AGI warrants that it has the right and
ability to grant the License to the Company to use the Trademarks for the Approved Use in accordance
with the terms of this Agreement and, provided that the Company uses the Trademarks for the Approved
Use in accordance with the terms of this Agreement, such grant will not infringe upon the rights of
any other party. If the Company promptly notifies AGI in writing of a third party claim against the
Company alleging that the Company's use of the Trademarks infringes a United States registered
trademark, and if such claim of infringement is not caused in whole or in part by the Company having
used the Trademarks other than for the Approved Use or other than strictly in the manner approved by
AGI in accordance with the terms of this

-1-

Agreement, AGI will defend such claim at its expense and will indemnify the Company, its agents and
representatives, for all losses, claims, charges, costs and expenses incurred by the Company as a
result of such claim. The Company hereby agrees to reimburse and indemnify and hold AGI harmless
from and against all losses, claims, charges, costs and expenses (including reasonable attorneys'
fees) incurred by AGI as a result of any claim involving or arising in connection with any use other
than an Approved Use or a use otherwise approved by AGI in accordance with the terms of this
Agreement.

B. In order to protect the good will of AGI and the Good Sam club, AGI retains the right to review
and approve in advance and in its sole discretion, all uses of the Trademarks and the Good Sam name
and logo. Therefore, the Company shall give AGI at least ten business days prior written notice and
description of intended use by the Company of the Trademark and the Good Sam name and logo, and the
Company's use of the Trademarks and the Good Sam name and logo is subject to approval of AGI.

C. The Company agrees that its use of the Trademarks and the Good Sam name and logo is restricted to
the Approved Use, and the Company shall not use the Trademarks or the Good Sam name or logo for any
other purpose. In connection with the Approved Use, the Company shall not use the Trademarks or the
Good Sam name or logo in any manner that is detrimental to AGI, the Good Sam Club or any of their
affiliates or any of their respective goodwill or business. Upon the termination of this Agreement,
whether by expiration of its term pursuant to Paragraph 6A or otherwise, the Company shall cease all
uses of the Trademarks and the Good Sam logo and name in any fashion.

2. Endorsement. Subject to the Terms of Section 7 hereof, AGI hereby grants the Company the right to
hold the Business out as having the License (the "Endorsement").

3. Term and Termination.

A. Unless otherwise provided for in this Agreement, the term of this Agreement shall be three years,
commencing on the date of this Agreement and expiring on the third anniversary date of this
Agreement (the "Termination
<!-- page 2 -->
Date"). In the event that the Company desires to terminate the Agreement prior to the Termination
Date, it shall provide AGI with at least 60 days prior written notice of its intention to terminate
this Agreement and this Agreement shall so terminate following the expiration of this 60-day period,
without any further responsibility by either Party except as provided in Section 5.

B. Either Party may terminate this Agreement at any time in the event of a material breach by the
other Party which remains uncured after thirty days written notice thereof.

-2-

C. Either Party may terminate this Agreement immediately following written notice to the other Party
if the other Party:

(i) ceases to do business in the normal course; suffers the entry of an order for relief declaring
such Party insolvent or bankrupt;

(ii) is the subject of any proceeding related to its liquidation or insolvency (whether voluntary or
involuntary) which is not dismissed within ninety calendar days;

(iii) makes an assignment for the benefit of creditors.

D. Notwithstanding any termination of this Agreement for any reason, AGI has earned and shall be
entitled to retain all royalties paid prior to termination and, in addition AGI shall be entitled to
payment from the Company of all compensation and unreimbursed expenses, if any, outstanding as of
the date of termination.

4. Royalties. As consideration of Endorsement, concurrently with the execution of this Agreement,
the Company shall pay to AGI a fee in the amount of $1,500,000. This fee shall be fully earned by
AGI upon the receipt thereof and shall not be refundable for any reason. As consideration for the
License, the Company shall pay to AGI such fees as may be established from time to time by mutual
agreement of the Company and AGI.

5. Marketing of Products. AGI and the Company agree to develop and implement a program for marketing
certain products and services offered by AGI through the Good Sam program, including, without
limitation, the emergency road service program and the extended warranty program offered through
Good Sam. Such marketing program will be on terms acceptable to AGI and the Company and shall be
subject to standards and procedures designated by AGI. The terms of the marketing program will be
set forth in a marketing agreement between AGI and the Company. The marketing agreement will
provide, among other things, the terms pursuant to which the Company shall make "Fulfillment
Deposits" for warranty products sold as a part of the marketing program.

6. Relationship. This Agreement shall not create a partnership or a joint venture between AGI and
the Company, and neither party hereto shall have any authority to act for or represent the other
party hereto or bind it to any agreements or obligations.

7. Public Disclosure Requirement. The Company may cause the release of a public announcement of the
Endorsement which sets forth, in pertinent part, a

-3-

description of this Agreement, including without limitation, the name of AGI and the nature of the
License. At least three business days prior to the dissemination of any such public announcement or
filing containing the above-required description, the Company shall submit to AGI for its review and
comment the proposed public announcement or description. AGI shall thereafter have three business
days within which to submit its editions or amendments to the public announcement and/or description
for inclusion therein, and the Company shall in its reasonable judgment and subject to the advice of
its counsel attempt to incorporate such editions and amendments in the final version disseminated by
the Company.

In the event of a breach of this Agreement by the Company, the Endorsement may be withdrawn by AGI
in its sole discretion and this Agreement terminated pursuant to the terms of Section 3B. In the
event of such withdrawal, the Company agrees forthwith to take such action as AGI may request to
publicly evidence that the Endorsement has been withdrawn and the Company agrees not to hold the
Business out as having the Endorsement.

8. Notices. Any notices hereunder shall be sent to the Company and AGI at their respective address
above set forth. Any notice shall be given by registered or certified mail, postage prepaid, and
shall be deemed to have been given when deposited in the United States mail. Either party may
designate any other address to which notice shall be given, by giving written notice to the other of
such address in the manner herein provided.

9. Entire Agreement. This Agreement contains the entire agreement and understanding between the
Parties with respect to its subject matter and supersedes all prior discussion, agreements and
understandings between them with respect thereto. This Agreement may not be modified except in a
writing signed by the Parties.
<!-- page 3 -->
10. Governing Law. This Agreement has been made in the State of California and shall be governed by
and construed in accordance with the laws thereof without regard to principles of conflicts of laws.

11. No Assignment. Neither this Agreement nor the rights of either Party hereunder shall be assigned
by either Party without the prior written consent of the other Party.

12. Counterparts. This Agreement may be executed in one or more counterparts, each of which shall be
deemed an original, but all of which together shall constitute one and the same instrument.

13. Non-Compliance. If any provision of this Agreement conflicts with any law, rule or regulation of
any federal, state or self-regulatory organization, or any other governmental authority having
jurisdiction over the activities or services described

-4-

herein, then in that event, the Company and AGI shall amend this Agreement to bring any affected
provision into compliance with such regulations.

14. No Third-Party Beneficiaries. Both Parties intent that this Agreement shall not benefit or
create any right or cause of action in or on behalf of any person or entity other than the Parties
hereto.

15. No Party Deemed Drafter. Both Parties agree that they have each materially and fully
participated in the negotiation and drafting of this Agreement and, if this Agreement ever should be
the subject of interpretation by a court or arbitrator, it shall not be construed or interpreted
against either Party for the reason that it was drafted by only one Party.

16. Headings. The headings in this Agreement are for reference purposes only and shall not in any
way affect the meaning or interpretation of this Agreement. Whenever the context so requires or
permits, all references to the masculine herein shall include the feminine and neuter, all
references to the neuter herein shall include the masculine and feminine, all references to the
plural shall include the singular and all references to the singular shall include the plural.

17. Attorneys' Fees. If legal action shall be necessary to enforce any of the provisions of this
Agreement, the prevailing party shall be entitled to reasonable attorneys' fees and costs incurred
thereby.

18. Further Assurances. At any time and from time to time, both Parties agree, without further
consideration, to take such actions and to execute and deliver such documents as may be reasonably
necessary to effectuate the purposes of this Agreement.

19. No Implied Waivers. This Agreement may be amended, modified, superseded, cancelled, renewed or
extended, and the terms and conditions hereof may be waived, only by a written instrument signed by
the Parties or, in the case of a waiver, by the Party waiving compliance. No delay on the part of
any Party in exercising any right, power or privilege hereunder shall operate as a waiver thereof,
nor shall any waiver on the part of any Party of any right, power or privilege hereunder, nor any
single or partial exercise of any right, power or privilege hereunder, preclude any other or further
exercise thereof or the exercise of any other right, power or privilege hereunder.

[The balance of this page intentionally left blank.]

-5-

IN WITNESS WHEREOF, the parties hereto have caused this Agreement to be executed the day and year
first above written.

Affinity Group, Inc.

By: /s/ Paul E. Schedler ------------------------------- Name: Paul E. Schedler Title: Vice
President

Holiday RV Superstores, Inc.

By: /s/ Marcus A. Lemonis ------------------------------- Name: Marcus A. Lemonis Title: Chief
Executive Officer
<!-- page 4 -->
-6-
