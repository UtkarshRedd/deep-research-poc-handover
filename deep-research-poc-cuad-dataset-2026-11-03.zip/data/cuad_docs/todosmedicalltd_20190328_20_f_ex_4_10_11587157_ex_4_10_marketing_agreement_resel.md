<!-- page 1 -->
# MARKETING AND RESELLER AGREEMENT
| Field | Value |
|---|---|
| Document Type | Marketing Agreement |
| Agreement Date | 2018-12-20 |
| Parties | Todos Medical Ltd. ("Todos"); Care G. B. Plus Ltd. ("Reseller") |
| Source | CUAD v1 / TodosMedicalLtd_20190328_20-F_EX-4.10_11587157_EX-4.10_Marketing Agreement_ Reseller Agreement |

Exhibit 4.10 MARKETING AND RESELLER AGREEMENT (the "Agreement") THIS AGREEMENT is made and entered
into this 20t h day of December 2018 (the "Effective Date"), by and between Todos Medical Ltd., a
corporation organized and existing under the laws of the State of Israel, with an address at 1
Hamada St., Rehovot, Israel ("Todos") and Care G. B. Plus Ltd., a corporation organized and existing
under the laws of the State of Israel, with an address at Rechov HaYasmin 50, Carmei Yosef, Israel
(the "Reseller"). WHEREAS, Todos has developed and owns a proprietary blood screening test for the
early detection of certain forms of cancer which consists of a Physician Kit (for collecting blood
samples) and a Lab Kit (for separating plasma and mononuclear cells in the blood samples) which
consists of an Isolation Kit and an Analysis Kit, all as more fully described on Exhibit A attached
hereto (the "Products"), as well as a proprietary algorithm for the analysis of the blood samples
data; and WHEREAS, the Reseller is interested in marketing, distributing, and reselling the Products
to customers located in and taking delivery in the State of Israel, including the territory of the
Palestinian Authority, (the "Territory" and the "Customers"), all in accordance with the terms set
forth herein; NOW THEREFORE in consideration of the agreements, covenants, and conditions
hereinafter set forth, the parties agree as follows: 1. Grant of Rights 1.1 Subject to the terms and
conditions of this Agreement, Todos hereby grants the Reseller a non-sublicensable,
non-transferable, exclusive right to distribute and sell the Products to Customers in the Territory;
provided, however, that Reseller may sub-license or transfer its distribution rights to a subsidiary
or affiliate of the Reseller. The Reseller shall have a right of first refusal to include within
this Agreement any additional products developed, manufactured, or sold by the Company following the
Effective Date that are not currently included in Exhibit A, and upon the exercise of such right,
the term "Products" shall be expanded to mean such additional products as well. For purposes of
clarity, the parties agree that upon Todos's development of a blood screening test for colon cancer,
such product shall be added to this Agreement and included within the definition of "Products",
subject to the Reseller and Todos agreeing on the commercial terms for such product, including the
price. 1.2 The Reseller shall not market, distribute, or sell the Products, whether directly or
indirectly, to customers outside of the Territory. This Section 1.2 is a fundamental provision of
this Agreement. 1.3 Subject to Section 1.4 below, Todos shall not market, distribute, or sell the
Products, whether directly or indirectly, to customers inside of the Territory in any manner other
than through the Reseller.

Source: TODOS MEDICAL LTD., 20-F, 3/28/2019
<!-- page 2 -->
1.4 Notwithstanding the grant of exclusivity to the Reseller, nothing herein shall derogate from
Todos's right to distribute the Products in the Territory for non-revenue producing purposes such as
research, testing, evaluation, proof of concept, and clinical trials. 2. Exclusivity 2.1 The
Reseller's exclusive right to market and sell the Products in the Territory is subject to the
Reseller achieving the following milestones by the end of each year this Agreement is in effect (the
"Annual Milestones"): Year Annual Milestone(s) Year 1 Not Applicable Each Year Thereafter The
parties will agree at the beginning of the year on the Annual Milestone for such year 2.2 If the
Reseller sells less than 50% of any year's Annual Milestone, Todos, in its sole discretion, may
either (a) cancel the Reseller's exclusivity, and market, distribute, and sell the Products in the
Territory directly or indirectly through other distributors and resellers, while leaving the
Reseller with a non-exclusive right to distribute and sell the Products for the remainder of the
term, or (b) terminate the Agreement upon one hundred eighty (180) days prior written notice,
provided that the Reseller does not cure its failure to achieve 50% of the applicable year's Annual
Milestone within the 180-day notice period. 3. Duties of Todos 3.1 Todos shall provide technical
assistance and advice to support the Reseller's preparation of marketing materials, including
technical sales literature, catalogs and the like, to be used in the Territory. 3.2 Todos shall
provide the Reseller, at no charge, with initial training relating to the efficient use and
operation of the Products as well as instruction regarding use of all associated equipment required
to effectively carry out the TM-B1 and TM-B2 cancer screening tests. Additionally, Todos will
provide the Reseller with training relating to the handling of all blood samples throughout the
screening process, and any and all other training, guidance and support reasonably required to sell
the Products in the Territory. 3.3 Todos shall provide the Reseller, at no charge, with technical
support relating to the use of the Products. 3.4 Todos shall support the Reseller, at no charge, in
providing Customers with scientific data supporting the efficacy of the Products. 3.5 Todos is
responsible for obtaining AMAR approval from the Israeli Ministry of Health. 3.6 Todos shall comply
with all relevant standards of quality assurance and shall ensure that the Products conform to all
Israeli standards and certifications.

2

Source: TODOS MEDICAL LTD., 20-F, 3/28/2019
<!-- page 3 -->
3.7 Todos shall appoint a relationship manager, who shall serve as the primary point of contact with
Reseller regarding all maters arising from the business relationship contemplated in this Agreement.
3.8 Todos shall be available for periodic meetings with the Reseller to discuss any issues arising
in connection with this Agreement. 3.9 Todos shall fulfill with reasonable dispatch all orders
received from the Reseller and accepted by Todos. 3.10 Todos shall refer to the Reseller all Product
inquiries and sales opportunities in the Territory that come to the attention of Todos. 4. Duties of
the Reseller 4.1 The Reseller shall use all commercially reasonable efforts to market, promote,
distribute, and sell the Products to Customers in the Territory, and shall, on its own account,
provide a trained and competent sales and marketing team for the efficient promotion and sale of the
Products. The Reseller shall achieve the commercialization milestones by the dates set forth in the
Commercialization Timetable attached hereto as Exhibit C. 4.2 The Reseller shall be responsible for
preparing marketing materials, including technical sales literature, catalogs and the like, to be
used in the Territory. All marketing materials shall be subject to the prior written approval of
Todos. 4.3 Except for AMAR approval which is the responsibility of Todos, the Reseller shall be
responsible for obtaining all necessary governmental, regulatory, and other permits and licenses
required to distribute and sell the Products in Israel. Todos shall provide the Reseller with all
required assistance in this matter in order to obtain the necessary licenses and permits. 4.4 The
Reseller shall be responsible for setting up at least one laboratory in the Territory to support the
assay protocol (the "Laboratory"), including the provision of a FTIR that is approved by Todos, as
further described in Exhibit B. The Reseller shall obtain the prior approval of Todos for all lab
equipment. The Reseller will contract with existing certified laboratories in Israel to obtain the
blood samples data, subject to the approval by Todos of each such laboratory. 4.5 The Reseller shall
be responsible for providing post-sale support services to Customers, and shall, on its own account,
provide a trained and competent support team for the efficient support of the Products. The Reseller
shall retain a medical doctor to assist with the provision of support services. 4.6 The Reseller
shall run a fifty (50) patient pilot trial to evaluate the performance of the Laboratory and the
Reseller's support team. 4.7 The Reseller shall follow Todos's protocols in dealing with or handling
the Products, including the shipment of blood samples to the laboratory.

3

Source: TODOS MEDICAL LTD., 20-F, 3/28/2019
<!-- page 4 -->
4.8 The Reseller shall, in marketing, selling, and distributing the Products, not make any promises,
representations, statements, warranties or guarantees on behalf of Todos or concerning the Products,
except as are expressly authorized in writing by Todos. 4.9 The Reseller shall comply at all times
with all applicable laws, rules, regulations, and industry standards relating to the storage,
packaging, marketing, distribution, laboratory work, and sale of the Products in the Territory. 4.10
The Reseller shall appoint a relationship manager, who shall serve as the primary point of contact
with Todos regarding all maters arising from the business relationship contemplated in this
Agreement. Todos's relationship manager shall meet with Todo no less frequently than quarterly and
provide a status report on the Reseller's commercialization efforts. In addition, the Reseller will
promptly bring to the notice of Todos any information which it has or which it may receive in future
which is likely to be of interest, benefit, or use to Todos in relation to both the marketing of the
Products in the Territory and the future market requirements of Customers. 4.11 The Reseller shall
provide Todos with feedback for a least one percent (1%) of the consumed tests, including providing
the actual screening result (by a yearly base) of each test. 4.12 The Reseller shall not market,
distribute, or sell any product that competes with Products, nor provide services to any direct
competitor of Todos. 4.13 The Parties hereby declare and confirm their awareness to the fact that to
the date of the signing of this Agreement, Todos has yet to sell a single Product and lacks any and
all sales experience and/or knowledge of the matter. The Reseller shall act as a pioneer in the
sales department and shall share with Todos all the sales experience and information it shall gather
in order to help Todos' with its worldwide sales. 4.14 The Reseller shall be entitled to enter into
agreements with its subsidiaries and affiliates to act as sub-distributors and/or selling agents of
the Products in the Territory. 4.15 The Reseller herby declares its awareness that Todos has not yet
acquired the required AMAR approval for distribution of the Products in the Territory nor FDA
approval. 5. Ordering, Pricing, and Payment Procedures 5.1 Non-Binding Forecasts. On the first day
of each calendar quarter, the Reseller will provide Todos with a non-binding rolling weekly forecast
of the Reseller's estimated Product purchase requirements over the upcoming six months (the
"Forecasts"). 5.2 Orders. From time to time as needed, the Reseller shall provide Todos with firm
purchase orders for the Products. Each purchase order shall include the name and address of the
Customer. All orders are subject to written acceptance by Todos, which acceptance shall be provided
unless the order contains terms that differ from the terms set forth in this Agreement. 5.3 Product
Price. The Reseller shall be entitled to purchase the Products from Todos for resale to Customers at
a price between US$[ ] and US$[ ], with the actual price to be agreed upon by the Parties (the
"Product Price"). At the end of each year this Agreement is in effect, the Parties will discuss each
party's costs and whether to revise the Product Price. Todos shall provide the Reseller with
Products for clinical trials at no charge.

4

Source: TODOS MEDICAL LTD., 20-F, 3/28/2019
<!-- page 5 -->
5.4 Lead Time. The lead time for each Lab Kit is three (3) months, and the lead time for each
Physician Kit is one month, provided that Reseller's order for the Products does not deviate from
the applicable Forecast by more than ten percent (10%). 5.5 Delivery. Todos shall ship ordered
Products to the Reseller within ninety (90) days of Todos's acceptance of the applicable purchase
order DAP Reseller's warehouse (Incoterms 2010), provided that Reseller's order for the Products
does not deviate from the applicable Forecast by more than ten percent (10%). 5.6 Todos shall
provide the Reseller with the screening results and analysis of each customer blood sample data sent
to Todos within one business day of receiving the blood sample data. 5.7 Payment for Products. Todos
shall invoice the Reseller for all sums due for Products ordered upon shipment of the ordered
Products to the Reseller, and the Reseller shall pay such sums by no later than thirty (30) days
from the date of shipment. All payments made to Todos shall be in New Israeli Shekels. 5.8 Taxes.
Reseller shall be responsible for paying all sales, use, excise, and value-added taxes imposed on
the sale or use of the Products. 6. Reporting and Audit Rights 6.1 Books and Records. During the
term and for a period of three (3) years following the termination or expiration of this Agreement,
the Reseller shall maintain complete books of accounts and records consistent with sound business
and accounting principles and practices consistently applied. 6.2 Quarterly Reports. Within fifteen
(15) days of the end of each quarter, the Reseller shall provide Todos with a written report of (a)
the quantities of Products distributed, sold, or otherwise transferred; the prices at which the
Products were sold; and payments received therefore; and (b) the identity and location of all
Customers to whom Products were sold, during the preceding quarter (each a "Quarterly Report"). 6.3
Audits. Todos shall have the right to have an inspection and audit of all the relevant accounting
and sales books and records of Reseller conducted by an independent auditor reasonably acceptable to
both parties. Any such audit shall be upon five (5) days prior written notice and shall be conducted
during normal business hours. If any such audit should disclose any material error in the Quarterly
Reports or any resale of the Products by Reseller in contravention of the terms of this Agreement,
in addition to any other remedies to which Todos shall be entitled, Reseller shall promptly
reimburse Todos for the reasonable cost of the audit. 6.4 On-Site Inspections. Todos shall have the
right to conduct periodic on-site inspections to ensure the quality control of the cancer screening
processes and the Reseller's compliance with Todos's protocols.

5

Source: TODOS MEDICAL LTD., 20-F, 3/28/2019
<!-- page 6 -->
6.5 Medical Device Reporting. The Reseller shall provide Todos with reports of any adverse events
and product problems in accordance with the Mandatory Medical Device Reporting regulations of 21 CFR
803. 7. Warranties 7.1 Performance Warranty. Todos warrants that for a period of one (1) year from
the date of delivery of each Product to the Reseller, the Product, except for those components that
have a shorter expiration date as set forth on Exhibit A, shall perform substantially in accordance
with the Product's documentation and specifications, and shall be free from all defects in
materials, manufacture, and workmanship. Todos shall correct or repair any reported non-conformity
or defect, or replace the non-conforming Product with a Product that conforms to this warranty. 7.2
Non-Infringement. Todos represents and warrants to the Reseller that Todos has full right to produce
and sell the Products as contemplated by this Agreement, and that the Reseller's exercise of the
resale rights granted herein will not violate any copyright, patent, or other proprietary right of
any third party. 7.3 EXCEPT FOR THE EXPRESS WARRANTIES STATED IN THIS SECTION 7, TODOS DISCLAIMS ANY
AND ALL WARRANTIES, INLCUDING ANY IMPLIED WARRANTY OR CONDITION OF MERCHANTABLE QUALITY,
MERCHANTABILITY, DURABILITY OR FITNESS FOR A PARTICULAR PURPOSE. NO REPRESENTATION OR OTHER
AFFIRMATION OF FACT, INCLUDING BUT NOT LIMITED TO STATEMENTS REGARDING PERFORMANCE OF THE PRODUCTS,
WHICH IS NOT CONTAINED IN THIS AGREEMENT, SHALL BE DEEMED TO BE A WARRANTY BY TODOS. 8. Insurance.
Each party shall carry appropriate and commercially reasonable amounts of insurance adequate for the
activities detailed in this Agreement, as well as sufficient levels of all legally mandated
insurance, if any. 9. Intellectual Property 9.1 Reseller acknowledges and agrees that any and all
proprietary rights, trade secrets, trademarks, trade names, copyrights, patents, know-how, and other
intellectual property rights used or embodied in, related to, or associated with the Products,
including all developments, modifications, enhancements, improvements, and derivative works thereof,
and all documentation with respect thereto, are and shall remain the sole and exclusive property of
Todos or its licensors. 9.2 Subject to the terms and conditions of this Agreement, Todos hereby
grants Reseller a limited license to use the Todos name and Todos's trademarks, trade names, service
marks, logos and related symbols (the "Todos Marks") in the performance of its activities hereunder
and in the marketing of the Products in the Territory. The Reseller's use of the Todos Marks shall
be subject to Todos's prior approval. The Reseller will use Todos's designated trademarks, trade
names, and intellectual property related notices on or in all marketing materials and packaging, and
the Reseller shall market and sell the Products under the Todos brand name. The Reseller will not
register or take other action with respect to any Todos Mark used anywhere in the world by Todos,
except to the extent authorized in writing by Todos in advance.

6

Source: TODOS MEDICAL LTD., 20-F, 3/28/2019
<!-- page 7 -->
9.3 Reseller shall immediately bring to the attention of Todos any improper or wrongful use of
Todos's trademarks or other intellectual or commercial property rights which come to the notice of
Reseller, and will, in the performance of its duties hereunder, use every effort to safeguard the
property rights and interests of Todos, and will, at the request and cost of Todos, take all steps
required by Todos to defend such rights. 9.4 Reseller acknowledges that it does not have and that it
will not obtain any proprietary interest in the Todos Marks and agrees not to use the same in any
other manner and to discontinue all use thereof immediately upon termination of the Agreement. 10.
Confidentiality 10.1 Any technical, scientific, design, or commercial information transferred by one
Party to the other under this Agreement which is identified as confidential or which may reasonably
be deemed to be confidential, shall be considered confidential and shall be maintained in confidence
by the receiving party. In addition, each party shall comply with all applicable health care privacy
rules and regulations and maintain the confidentiality of all health care and patient information.
10.2 The receiving party shall maintain in confidence and protect the secrecy of all confidential
information of the other Party, and agrees that it shall not disclose, transfer, use in an
unauthorized manner, copy, or allow access to any such confidential information to any employees,
agents, or third parties, except for those who have a need to know such confidential information to
fulfill the purposes of this Agreement, and who are bound by contractual obligations of
confidentiality and limitation of use sufficient to give effect to this Section 10. In no event
shall the receiving party disclose any of the other Party's confidential information to any
competitor of the disclosing party. 10.3 The receiving party shall use the same degree of care to
avoid publication, unauthorized disclosure, and unauthorized use of such confidential information as
it applies with respect to its own confidential information (but no less than reasonable care), and
shall take all reasonable care to ensure that such confidential information is not disclosed to
third parties, except insofar as: (a) such confidential information is made public by the disclosing
party; (b) such confidential information is in the public domain otherwise than as a consequence of
a breach of the obligations herein undertaken; or (c) such confidential information was previously
and demonstrably known to the receiving party, or was subsequently independently developed. 10.4 The
terms of this Agreement shall be deemed to be confidential information. Each party undertakes that
it will not make any announcement or issue any circular or other publicity relating to the existence
or subject matter of this Agreement, the terms of this Agreement, or the transactions contemplated
hereby, without the prior written approval of the other party as to such
announcement's/circular's/publicity's content, form, and manner of publication.

7

Source: TODOS MEDICAL LTD., 20-F, 3/28/2019
<!-- page 8 -->
10.5 Each party acknowledges that the unauthorized use, commercialization or disclosure of the other
party's confidential information would cause irreparable harm to such other party. The parties
acknowledge that remedies at law may be inadequate to redress the actual or threatened unauthorized
use, commercialization, or disclosure of such confidential information and that the foregoing
restrictions may be enforced by temporary and permanent injunctive relief without necessity of
posting bond. In addition, any award of injunctive relief shall include recovery of associated costs
and expenses (including reasonable attorneys' fees). 10.6 The provisions of this Section 10 shall
survive the expiration or termination of this Agreement. 11. Term and Termination 11.1 This
Agreement shall be effective as of the Effective Date and shall continue in effect for a period of
five (5) years from the Reseller's first purchase order for Product issued to Todos (the "Initial
Term"), unless terminated earlier by one of the parties in accordance with the terms of this Section
11. Upon completion of the Initial Term, provided that the Reseller has achieved the Annual
Milestones, the term of the Agreement shall be automatically renewed for an additional five (5)
years. Thereafter, at the end of each renewal term, the Agreement shall renew for an additional two
(2) years unless one party provides the other party with prior written notice of non-renewal at
least sixty (60) days prior to the expiration of the then-current term. 11.2 Notwithstanding
anything to the contrary, a party may terminate this Agreement upon the occurrence of any of the
following events, and such party shall not be liable to the other party for the proper exercise of
such right: (a) The other party materially breaches this Agreement and continues in such breach for
thirty (30) days after the non-breaching party has given written notice thereof to the other party;
or (b) For a period of ninety (90) consecutive days, the other party is declared to be insolvent or
is the subject of bankruptcy or liquidation proceedings, whether compulsory or voluntary, or has a
receiver, judicial administrator or similar officer appointed over all or any material part of its
assets, or any security holder or encumbrance lawfully takes possession of any property of or in
possession of the other party, or if the other party ceases to carry on its business. 12. Limitation
of Liability 12.1 IN NO EVENT SHALL EITHER PARTY BE LIABLE TO THE OTHER PARTY FOR ANY INCIDENTAL,
CONSEQUENTIAL, INDIRECT, SPECIAL, OR PUNITIVE DAMAGES (INCLUDING, BUT NOT LIMITED TO, LOST PROFITS,
BUSINESS INTERRUPTION, LOSS OF BUSINESS INFORMATION OR OTHER PECUNIARY LOSS) REGARDLESS OF WHETHER
SUCH LIABILITY IS BASED ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), STRICT LIABILITY, BREACH
OF WARRANTIES, FAILURE OF ESSENTIAL PURPOSE OR OTHERWISE AND EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGES.

8

Source: TODOS MEDICAL LTD., 20-F, 3/28/2019
<!-- page 9 -->
12.2 Except with regard to a breach of confidentiality, a party's indemnification obligations
hereunder, or infringement of intellectual property rights, either party's total liability to the
other party under this Agreement shall be limited to the amounts paid or payable by the Reseller to
Todos during the twelve-month period preceding the interposition of the claim. 13. Indemnification
13.1 Todos's Duty to Indemnify. Todos shall defend against any claim or lawsuit by a third party (a
"Claim") against Reseller to the extent such Claim alleges that the Products infringe any patent,
copyright, or trademark or misappropriate a trade secret of a third party, and will indemnify
Reseller against all costs, damages, losses, liabilities and expenses (including reasonable
attorneys' fees and costs) ("Damages") awarded against Reseller by a court of competent
jurisdiction, or agreed to in a written settlement agreement signed by Todos, arising out of such
Claim. Todos shall have no indemnification obligation or other liability for any Claim of
infringement arising from (a) use of the Products other than in accordance with this Agreement; (b)
modification of the Products or the combination of the Products with any other products, services,
or materials if the Products would not be infringing without such modification or combination; or
(c) any third party products, services, or materials. If Reseller's use of the Products under the
terms of this Agreement is enjoined or Todos determines that such use may be enjoined, then Todos
may, at its sole option and expense, either (i) procure for Reseller a license to continue using the
Products in accordance with the terms of this Agreement; (ii) replace or modify the allegedly
infringing Products to avoid the infringement; or (iii) terminate this Agreement. 13.2 Reseller's
Duty to Indemnify. Reseller agrees to defend any Claim against Todos (i) that the Reseller's actions
infringe any third party patent, or copyright, or any other proprietary right; or (ii) arising out
of any act or omission by Reseller relating to the Products. Reseller will indemnify Todos (and its
directors, employees and agents) against all Damages awarded against Todos or agreed to in a written
settlement agreement signed by Reseller arising out of such Claim. 13.3 General Indemnity. Each
party shall defend and indemnify the other party and its employees, officers, directors and agents
against all Damages for Claims for bodily injury, death, or damage to real property or tangible
physical equipment, proximately caused by the indemnifying Party in the course of performing this
Agreement. 13.4 Conditions to Indemnification. The obligations set forth in this Section 13 shall
apply only if (i) the indemnified Party promptly notifies the indemnifying Party in writing of a
claim upon learning of or receiving the same; (ii) the indemnified Party provides the indemnifying
Party with reasonable assistance requested by the indemnifying Party, at the indemnifying Party's
expense, for the defense and settlement, if applicable, of any claim; and (iii) the indemnified
Party provides the indemnifying Party with the exclusive right to control and the authority to
settle any claim. 13.5 Sole and Exclusive Remedies. THE RIGHTS AND OBLIGATIONS IN THIS SECTION 13
ARE THE INDEMNIFYING PARTY'S SOLE AND EXCLUSIVE OBLIGATIONS, AND THE INDEMNIFIED PARTY'S SOLE AND
EXCLUSIVE REMEDIES, WITH RESPECT TO ANY SUCH CLAIMS.

9

Source: TODOS MEDICAL LTD., 20-F, 3/28/2019
<!-- page 10 -->
14. Relationship of the Parties The parties to this Agreement are independent contractors. No
relationship of principal to agent, master to servant, employer to employee, or franchisor to
franchisee is established hereby between the parties. Neither party has the authority to bind the
other or incur any obligation on the other's behalf. Any agreement for the sale of Products
negotiated or executed between the Reseller and a Customer shall be binding upon the Reseller alone.
The Reseller is not authorized to, and shall not, enter into any contracts nor make any other
commitments on behalf of or in the name of Todos, unless expressly authorized in writing to do so by
Todos. Reseller shall not incur any liabilities, obligations, or commitments on behalf of Todos. 15.
Miscellaneous 15.1 Entire Agreement. This Agreement, including its exhibits, constitutes the entire
agreement between the parties concerning the subject matter hereof, and supersedes all prior or
contemporaneous statements, representations, discussions, negotiations, and agreements, both oral
and written. 15.2 Amendments or Waiver. This Agreement may not be amended or modified except in a
writing signed by authorized officers of both parties. No order, invoice, or similar document will
modify the terms of this Agreement even if accepted by the receiving party. 15.3 Severability. In
the event that any one or more of the provisions of this Agreement shall be found to be illegal or
unenforceable, this Agreement shall nevertheless remain in full force and effect, and such term or
provision shall be deemed severed unless such severance defeats the purpose of this Agreement or
results in substantial injustice to one of the parties. 15.4 No Waiver. Neither of the party's
rights to enforce provisions of this Agreement shall be affected by any prior course of dealing,
waiver, delay, omission, or forbearance. 15.5 Assignment. This Agreement and the rights granted
hereunder shall not be assigned, encumbered by security interest or otherwise transferred by the
Reseller without the prior written consent of Todos, except for the assignment or transfer of rights
to a subsidiary company or an affiliated company. 15.6 Governing Law. This Agreement shall be
governed by and construed in accordance with the laws of the State of Israel, and the courts of
Tel-Aviv, Israel 15.7 Arbitration. Any dispute, controversy, or claim relating to, connected with,
or arising out of this Agreement, including any question regarding its existence, validity, or
termination, shall be referred to and finally resolved by arbitration in accordance with the
Arbitration Law, before a single arbitrator to agreed upon by both parties and in lack of such
agreement as to the identity of the arbitrator, each side shall be eligible, within 7 days of any
notice given by any party to the other, to request that the head of the Tel-Aviv Bar Association
appoint said arbitrator. [Remainder of Page Left Blank]

10

Source: TODOS MEDICAL LTD., 20-F, 3/28/2019
<!-- page 11 -->
IN WITNESS WHEREOF, the parties have caused this Agreement to be executed by their duly authorized
representatives. Todos Medical Ltd. Care G. B. Plus Ltd. /s/ Herman Weiss /s/ Assaf Gold Name:
Herman Weiss Name: Assaf Gold Title: CEO Title: Manager Date: 20/12/2018 Date: 20/12/2018 Lists of
Exhibits: Exhibit A: The Products Exhibit B: The Laboratory Exhibit C: Commercialization Timetable

11

Source: TODOS MEDICAL LTD., 20-F, 3/28/2019
<!-- page 12 -->
EXHIBIT A THE PRODUCTS Each unit of Product consists of one Physician Kit and one Laboratory Kit.
TM-B1 breast cancer screening test and TB-B2 breast cancer diagnostic test General Information:
Physician Kit: Laboratory Kit: The Laboratory Kit consists of the Isolation Kit and the Analysis
Kit. Isolation Kit: Item 7 (page 8) in the "Isolation Kit" are items that are not provided with the
kit and the Reseller is responsible to purchase these items. Analysis Kit: Item 7 (page 8) in the
"Analysis Kit" are the items that are not provided with the kit and the Reseller is responsible to
purchase these items. Components with an expiration date: [please insert]

12

Source: TODOS MEDICAL LTD., 20-F, 3/28/2019
<!-- page 13 -->
EXHIBIT B THE LABORATORY [please insert description of the laboratory and its components]

13

Source: TODOS MEDICAL LTD., 20-F, 3/28/2019
<!-- page 14 -->
EXHIBIT C COMMERCIALIZATION TIMETABLE Milestone Target Date Todos to obtain AMAR approval Q3 2019
Reseller to set-up a diagnostic Laboratory (internal or external) that complies with the
requirements in the TM-B2 Isolation Kit Instruction for Use. Q3 2019 Reseller to commence 30-50
Women Pilot Trial. Isolation at Reseller's lab, and FTIR analysis at Todos's facility. Q3 2019
Reseller to commence commercial sales. Q4 2019 Todos to provide kits and computer analysis of files.
Q4 2019 14

Source: TODOS MEDICAL LTD., 20-F, 3/28/2019
