# Can a party terminate the Outsourcing Agreement between Paratek Pharmaceuticals, Inc. a...

*Question:* Can a party terminate the Outsourcing Agreement between Paratek Pharmaceuticals, Inc. and CARBOGEN AMCIS AG (dated 2016-12-30) for convenience, and on what terms?

> **Partial report.** Research or writing ended before completion; see the gaps and the appendix.

## Answer

[GAP] No evidence was found for: Answer the question: Can a party terminate the Outsourcing Agreement between Paratek Pharmaceuticals, Inc. and CARBOGEN AMCIS AG (dated 2016-12-30) for convenience, and on what terms?

## Verification appendix

Claims: 1 · supported: 0 · partially: 0 · dropped: 0 · gaps: 1

Notes: no evidence in the bank; every section is a gap; OpenAIRateLimitError: Error code: 429

| claim | section | tier 1 | score | sources | note |
|---|---|---|---|---|---|
| s1.1 | s1 | gap |  |  |  |

### Evidence

