# Among the following 8 agreements, which contain a non-compete clause? For each, quote t...

*Question:* Among the following 8 agreements, which contain a non-compete clause? For each, quote the clause. Agreements: the Endorsement Agreement between Eco Science Solutions, Inc and Stephen Marley (dated 2017-11-14); the Network Affiliate Agreement between National CineMedia, LLC and Digital Cinema Destinations Corp. (dated 2011-03-14); the Exclusive Distributor Agreement between Erchonia Corporation and InnerScope Hearing Technologies Inc (filed 2018-11-09); the Supply Agreement between Integra LifeSciences Corporation and PcoMed, LLC (dated 2013-05-15); the Reseller Agreement between Touchstar Software Corporation and Worldwide Strategies (filed 2005-11-02); the Cooperation Agreement between e.l.f. Beauty, Inc. and Marathon Partners Equity Management, LLC (dated 2020-07-01); the Sponsorship Agreement between Stallings Capital Group Consultants, Ltd. and GAINSCO, INC. (dated 2010-01-01); the Strategic Alliance Agreement between Freedom Mortgage Corporation and Cherry Hill Mortgage Investment Corp. (filed 2013-09-26).

## Identify agreements containing non-compete clauses

The Strategic Alliance Agreement between Freedom Mortgage Corporation and Cherry Hill Mortgage Investment Corp. contains a non-compete clause. [6c075b58090b9b68 p.34] The clause states: "The parties agree that irreparable damage would occur in the event that any of the provisions of this Agreement were not performed in accordance with their specific terms. [uncited] It is accordingly agreed that the parties shall be entitled to seek specific performance of the terms hereof, this being in addition to any other remedies to which they are entitled at law or equity. [uncited] In the event of any dispute between the parties concerning the terms and provisions of this Agreement, the party prevailing in such dispute shall be entitled to collect from the other party all costs incurred in such dispute, including reasonable attorneys' fees.". [6c075b58090b9b68 p.34]

[GAP] Evidence for the Endorsement Agreement between Eco Science Solutions, Inc and Stephen Marley, the Network Affiliate Agreement between National CineMedia, LLC and Digital Cinema Destinations Corp., the Exclusive Distributor Agreement between Erchonia Corporation and InnerScope Hearing Technologies Inc, the Supply Agreement between Integra LifeSciences Corporation and PcoMed, LLC, the Reseller Agreement between Touchstar Software Corporation and Worldwide Strategies, the Cooperation Agreement between e.l.f.

Beauty, Inc. and Marathon Partners Equity Management, LLC, and the Sponsorship Agreement between Stallings Capital Group Consultants, Ltd. and GAINSCO, INC. is missing. [uncited]

## Extract non-compete clauses

[GAP] The evidence does not contain any non-compete clause language for the Endorsement Agreement between Eco Science Solutions, Inc and Stephen Marley (dated 2017-11-14), the Network Affiliate Agreement between National CineMedia, LLC and Digital Cinema Destinations Corp. (dated 2011-03-14), the Exclusive Distributor Agreement between Erchonia Corporation and InnerScope Hearing Technologies Inc (filed 2018-11-09), the Supply Agreement between Integra LifeSciences Corporation and PcoMed, LLC (dated 2013-05-15), the Reseller Agreement between Touchstar Software Corporation and Worldwide Strategies (filed 2005-11-02), the Cooperation Agreement between e.l.f. Beauty, Inc. and Marathon Partners Equity Management, LLC (dated 2020-07-01), the Sponsorship Agreement between Stallings Capital Group Consultants, Ltd. and GAINSCO, INC. (dated 2010-01-01), or the Strategic Alliance Agreement between Freedom Mortgage Corporation and Cherry Hill Mortgage Investment Corp. (filed 2013-09-26).

## Verification appendix

Claims: 7 · supported: 2 · partially: 0 · dropped: 0 · gaps: 5 · tier-1 support rate: 1.00

| claim | section | tier 1 | score | sources | note |
|---|---|---|---|---|---|
| s1.1 | s1 | keep | 1.00 | e1→[6c075b58090b9b68 p.34] |  |
| s1.2 | s1 | gap |  |  | no evidence cited |
| s1.3 | s1 | gap |  |  | no evidence cited |
| s1.4 | s1 | keep | 1.00 | e1→[6c075b58090b9b68 p.34] |  |
| s1.5 | s1 | gap |  |  |  |
| s1.6 | s1 | gap |  |  | no evidence cited |
| s2.1 | s2 | gap |  |  |  |

### Evidence

- e1 [6c075b58090b9b68 p.34 L1262-1268] keep (1.0): "The parties agree that irreparable damage would occur in the event that any of the provisions of this Agreement were not performed in accordance with their specific terms. It is accordingly agreed that the parties shall be entitled to seek …"
