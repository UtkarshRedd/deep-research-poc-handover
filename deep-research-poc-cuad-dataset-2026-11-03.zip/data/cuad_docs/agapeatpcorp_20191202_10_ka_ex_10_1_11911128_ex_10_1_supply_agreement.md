<!-- page 1 -->
# ODM SUPPLY AGREEMENT
| Field | Value |
|---|---|
| Document Type | Supply Agreement |
| Agreement Date | 2018-01-15 |
| Parties | ORGANIC PREPARATIONS INC. ("the Manufacturer"); AGAPE ATP INTERNATIONAL HOLDING LIMITED ("the Customer") |
| Source | CUAD v1 / AgapeAtpCorp_20191202_10-KA_EX-10.1_11911128_EX-10.1_Supply Agreement |

ODM - SUPPLY AGREEMENT BETWEEN: ORGANIC PREPARATIONS INC. 2nd Floor, Transpacific Haus Lini Highway,
Port Vila. Vanuatu "the Manufacturer" -- AND -- AGAPE ATP INTERNATIONAL HOLDING LIMITED Unit 05, 4F,
Energy Plaza No. 92, Granville Road Tsim Sha Tsui East Kowloon, Hong Kong "the Customer"

Source: AGAPE ATP CORP, 10-K/A, 12/2/2019
<!-- page 2 -->
ODM SUPPLY AGREEMENT THIS AGREEMENT is made on the 15t h day of January 2018. BETWEEN: ORGANIC
PREPARATIONS INC. 2nd Floor, Transpacific Haus Lini Highway, Port Vila. Vanuatu ('the Manufacturer')
of one part AND: AGAPE ATP INTERNATIONAL HOLDING LIMITED Unit 05, 4F, Energy Plaza No. 92, Granville
Road Tsim Sha Tsui East Kowloon, Hong Kong ('the Customer') of the other part. RECITALS a. The
Manufacturer wishes to appoint the Customer to be the sole and exclusive agent for the promotion,
sales, marketing distribution and administration of the Products listed in schedule A of this
agreement. b. The Manufacturer and the Customer wish to record their agreement under the
stipulations of this Agreement. NOW IT IS AGREED as follows:- 1. TERMS OF AGREEMENT 1.1 Commencement
This agreement commences upon execution of this document. 1.2 Term This agreement is for a term of
ten (10) years. 1.3 Renewal This agreement will be automatically renewed at the end of every ten
(10) year term, with each subsequent term of renewal being for a ten (10) year term. A six (6)
months notice must be given by either party of their intention to terminate relations due to any
reason other than breach of this agreement. ODM Supply Agreement 2 Organic Preparations INC. & Agape
ATP International Holding Limited

Source: AGAPE ATP CORP, 10-K/A, 12/2/2019
<!-- page 3 -->
2. PROVISION OF DOCUMENTATION 2.1 Provision by the Manufacturer The Manufacturer agrees to supply to
the Customer, within a reasonable period of time, all documentation and information relating to the
Products and their Manufacture as is required for the registration of the Products in the
Territories as listed in Schedule C of this document. The party responsible for documentation fees
and costs will be the Customer. 2.2 Provision by the Customer The Customer agrees to supply to the
Manufacturer at its own expense, within a reasonable period of time, all documentation and
information as is reasonably required by or would be beneficial to the Manufacturer in the
performance of its obligations under this agreement. 3. COVENANTS BY THE MANUFACTURER 3.1 Compliance
with Local Laws and Regulations The Manufacturer covenants that it is and will remain for the term
of this agreement in compliance with any and all Local Laws and Regulations. This includes without
limitation laws relating to business practice, workplace relations, safety and taxation. 3.2
Manufacturing standards The Manufacturer covenants that it is and will remain for the term of this
agreement in compliance with all International standards in production and manufacturing. 3.3
Packaging The Manufacturer covenants that it is and will remain for the term of this agreement in
compliance with any and all packaging laws and regulations in all of the Territories. 3.4 Ability to
Perform The Manufacturer covenants that it is willing and able to perform any and all of its
obligations under this agreement. 3.5 Intellectual Property 3.5 (a) The Manufacturer covenants that
the Products are clear of any Intellectual Property claims by third parties and that the Customer
has full rights to sell and market the Products worldwide. The Manufacturer indemnifies the Customer
for the same. ODM Supply Agreement 3 Organic Preparations INC. & Agape ATP International Holding
Limited

Source: AGAPE ATP CORP, 10-K/A, 12/2/2019
<!-- page 4 -->
3.5 (b) The composition of the below individuals is also relevant and related to the Intellectual
Property of the Manufacturer. The following names listed as Medical Team members, and any subsequent
consultations in that capacity, are considered the Intellectual Property of The Manufacturer: 1. Dr
Lily Tomas 2. Dr Bernd Friedlander 3. Mr Markus Eistert 4. Dr Ed Smith 5. Mr Vic Cherikoff 6. Dr
Pavel Yutsis 7. Dr Michael Tirant 8. Mr Frank Ellis 9. Mr Peter Davids 10. Dr Rutledge Taylor The
list shall be expanded and added to in future addendums to this agreement. 3.6 Sale of Product The
Manufacturer covenants not to sell any product listed in this agreement, or product name (as listed
in schedule A of this agreement) to any other party without prior written consent of the Customer.
4. COVENANTS BY THE CUSTOMER 4.1 Compliance with Local Laws and Regulations The Customer covenants
that it is and will remain for the term of this agreement in compliance with any and all Local Laws
and Regulations. This includes without limitation laws relating to business practice, workplace
relations, safety and taxation. 4.2 Ability to Perform The Customer covenants that it is and will
remain for the term of this agreement willing and able to perform any and all of its obligations
under this agreement. 4.3 Market Penetration The Customer covenants to give its best endeavours to
establish and develop a market for the Products in the Territories with maximum market penetration.
ODM Supply Agreement 4 Organic Preparations INC. & Agape ATP International Holding Limited

Source: AGAPE ATP CORP, 10-K/A, 12/2/2019
<!-- page 5 -->
5. SHIPPING AND PAYMENT TERMS 5.1 Shipping Products delivered pursuant to the terms of this
Agreement shall be suitably packed for shipment in the Manufacturer's standard shipping cartons,
marked for shipment to the destination specified in the Customer's Purchase Order, and delivered to
the destination Ex Works. The Customer agrees to pay freight, insurance and any associated expenses.
The Customer agrees to help the Manufacturer select the most appropriate carrier for each of the
Territories. All freight, insurance, and other shipping expenses shall be paid by the Customer. 5.2
Guarantee of packaging quality The Manufacturer further guarantees that the Products, when shipped,
are packaged in such a way as to be protected from any foreseeable damage during shipment. 5.3
Rejection of defective products The Customer shall inspect all Products promptly upon receipt
thereof and may reject any defective Product, provided that the Customer shall within seven (7) days
after receipt of such alleged defective Product, notify the Manufacturer of its rejection and
either: (i) request to destroy in field for credit of the value of the defective product and the
associated shipping costs (with approval), or (ii) request a Return Material Authorization ("RMA")
number and within seven (7) days of receipt of the RMA number from the Manufacturer return such
rejected Product to the Manufacturer. Products not rejected within the foregoing time periods shall
be deemed accepted by the Customer. In the event that the Manufacturer determines that the returned
Product is defective and properly rejected by the Customer, the Manufacturer shall credit to the
Customer the value of the defective product and the associated shipping costs. 5.4 Payment terms
Unless separate payment terms are agreed to outside of this Agreement by both parties in writing,
payment terms will be as follows: (i) 50% of the Total Order Cost must be paid on placement of the
customer's order. (ii) The remaining 50% of the total order cost must be paid prior to the goods
leaving the warehouse of the manufacturer. The Manufacturer will notify the Customer when the goods
are ready for shipment prior to the goods leaving the warehouse. ODM Supply Agreement 5 Organic
Preparations INC. & Agape ATP International Holding Limited

Source: AGAPE ATP CORP, 10-K/A, 12/2/2019
<!-- page 6 -->
6. INDEMNITY / INSURANCE 6.1 The Manufacturing Companies utilised by the Agent to manufacture the
products listed in Schedule A of this agreement shall maintain throughout the term of this agreement
product liability insurance issued by a reputable insurance company under standard terms and
conditions in the industry to cover the liability of the Customer and to indemnity the Customer from
any costs, expenses, loss or damages resulting from any act, neglect or default of the company. 6.2
The Customer shall at all times during the term of this agreement maintain product liability
insurance, covering all products sold by the Manufacturer to the Customer and which policy shall
name the Manufacturer as Additional Insured. 7. BREACH / TERMINATION 7.1 Notice of Breach Each party
has an obligation to notify immediately the other party of any breach of this agreement. 7.2
Rectification of Breach Where the breach is rectifiable, the breaching party has 21 days from the
date of notification of its breach to rectify. Following the expiry of this period, the
non-breaching party may execute any rights it may have both in law and under this agreement. 7.3
Rights to termination Without prejudice to any right or remedy both parties may have against each
other for breach or non-performance of this Agreement each party shall have the right to summarily
terminate this Agreement: (a) On the committing of a material breach of this agreement providing
that where the breach is capable of rectification the breaching party has been advised in writing of
the breach and has not rectified it within twenty-one (21) days of receipt of such advice. (b) On
the commencement of the winding up or bankruptcy of either party or on the appointment of a receiver
of the distributor's assets or on either party ceasing to do business at any time for thirty
consecutive days (other than for annual holidays). (c) On either party for any reason (other than a
default of the other party) being substantially prevented from performing or becoming unable to
perform its obligations under this agreement. (d) On either party assigning or attempting to assign
this agreement without the prior written consent of the other party. ODM Supply Agreement 6 Organic
Preparations INC. & Agape ATP International Holding Limited

Source: AGAPE ATP CORP, 10-K/A, 12/2/2019
<!-- page 7 -->
(e) If control of either party shall pass from the present shareholders or owners or controllers to
other persons whom the other party shall in their absolute discretion regard as unsuitable. (f)
Either parties voting stock is transferred to any third party to such extent as to result in a
change in effective control of the company or its ownership or active management is changed in any
other manner. The termination of this agreement shall be without prejudice to the rights of either
party to payment or other claims due or accrued up to the termination of this agreement. For
termination to be effective, written notice of termination must be served on the other party. Where
valid, termination takes effect immediately upon service. 8. ARBITRATION 8.1 Any and all disputes,
claims or differences arising out of or relating to this agreement or the alleged breach thereto
shall be settled by mutual consultation between the parties in good faith as promptly as possible
but failing such amicable settlement, shall be decided by Arbitration by the Arbitration Committee
of the International Chamber of Commerce located in Switzerland. 8.2 The language to be used in the
Arbitration proceedings shall be English. 8.3 The award/decision of the Arbitration Committee shall
be final and binding on both the parties and enforceable in any jurisdiction. 9. COSTS Each of the
parties shall bare its own legal costs and expenses incurred by it in connection with this agreement
and any stamp duty payable under this agreement shall be borne by equally by both parties. 10.
GOVERNING LAW This agreement shall be governed by the Laws of England (English common and statutory
Law). 11. INTELLECTUAL PROPERTY The Manufacturer is the owner of the intellectual Property
pertaining to the products listed in schedule A of this agreement as well as to the book 'How to
Achieve Super Health beyond 2000 - Advanced Edition' ODM Supply Agreement 7 Organic Preparations
INC. & Agape ATP International Holding Limited

Source: AGAPE ATP CORP, 10-K/A, 12/2/2019
<!-- page 8 -->
12. TRANSFER OF INTELLECTUAL PROPERTY The Manufacturer agrees to offer the Customer the first right
of refusal to purchase the intellectual property for the products listed in Schedule A of this
agreement based upon agreed terms. 13. APPOINTMENT AND GRANT OF LICENSE 13.1 The Manufacturer hereby
appoints the Customer to be the sole and exclusive agent for the promotion, sales, marketing,
distribution and administration of the products listed in schedule A of this agreement based on
minimum annual product purchase requirements as listed in Schedule B of this agreement. 13.2 The
Manufacturer grants exclusive rights to the Customer for the term of ten (10) years from the date of
the signing of this agreement and for an indefinite period upon the customer fulfilling the minimum
annual purchase requirement as listed in Schedule B. of this agreement. 14. MISCELLANEOUS PROVISIONS
14.1 Notice Any notice to be served under this agreement must be served by sending it to the usual
business address of the recipient by ordinary mail, facsimile, or personal delivery, and in the case
of ordinary mail service will be deemed to occur one (1) day after the date of posting, and in all
other cases deemed to occur on the same day. 14.2 Entire Agreement This agreement contains the
entire understanding of the parties with respect to the subject matter hereof and supersedes all
prior agreements relating thereto, written or oral, between the parties. Amendments to this
agreement must be in writing, signed by the duly authorized officers of the parties. The terms of
any purchase order are expressly excluded 14.3 Conflicting Terms The parties agree that the terms
and conditions of this agreement shall prevail, notwithstanding contrary or additional terms, in any
purchase order, sales acknowledgment, confirmation or any other document issued by either party
effecting the purchase and/or sale of Products. 14.4 Severability If any provision of this agreement
is held to be invalid by a court of competent jurisdiction, then the remaining provisions will
nevertheless remain in full force and effect. The parties agree to renegotiate in good faith those
provisions so held to be invalid to be valid, enforceable provisions which provisions shall reflect
as closely as possible the original intent of the parties, and further agree to be bound by the
mutually agreed substitute provisions. ODM Supply Agreement 8 Organic Preparations INC. & Agape ATP
International Holding Limited

Source: AGAPE ATP CORP, 10-K/A, 12/2/2019
<!-- page 9 -->
14.5 No Implied Waivers The failure of either party at any time to require performance by the other
of any provision hereof shall not affect the right of such party to require performance at any time
thereafter, nor shall the waiver of either party of a breach of any provision hereof be taken or
held to be a waiver of a provision itself. 14.6 Assignment The Manufacturer may not transfer or
assign any of its rights or obligations under this agreement without the prior written consent of
the Customer. The Customer may not freely transfer or assign its rights or obligations under this
agreement without the prior written consent of the Manufacturer. Subject to the foregoing, this
agreement will be binding upon and inure to the benefit of the parties hereto, their successors and
assignees. 14.7 Force Majeure Neither party to this agreement is liable to the other for a breach of
this agreement when the breach is as a result of the occurrence of one of the events below: (i) The
outbreak of hostilities (whether or not accompanied by any formal declaration of war), riot, civil
disturbance, or acts of terrorism; or (ii) The act of any government or competent authority
(including the cancellation or revocation of any approval, authority or permit); or (iii) Fire,
explosion, flood, inclement weather, or natural disaster; or (iv) The declaration of a state of
emergency or the invocation of martial law having an effect on commerce generally; or (v) Industrial
action (including strikes and lock-outs) that is of a widespread nature affecting the Principal
solely or the industry or sector of which the Principal is a part (whether in a vertical sense or
horizontal sense); or (vi) Any other cause, impediment or circumstance beyond the reasonable control
of any party. Where the occurrence of one of the above events is to any extent as a result of an act
or omission of the breaching party, this section will not apply. 14.8 New Products Designed,
Formulated and Supplied by the Manufacturer The Manufacturer agrees to maintain its focus on the
design and formulation of new products and agrees to provide the Customer with one new product each
quarter for a minimum of four (4) new products per year. The Manufacturer agrees to give the
Customer exclusive rights to the marketing, promotion and sales of the new products should the
Customer decide to take on the new products. ODM Supply Agreement 9 Organic Preparations INC. &
Agape ATP International Holding Limited

Source: AGAPE ATP CORP, 10-K/A, 12/2/2019
<!-- page 10 -->
14.9 Other products outside of the product range listed in schedule A of this document The
Manufacturer agrees that the Customer has the right under this agreement to consider, source,
promote, market and sell other product outside of the products listed in Schedule A of this
agreement in line with the following assumptions: That they are non-competing products to the range
of products or those products listed in schedule A of this agreement. 14.10 HOW TO ACHIEVE SUPER
HEALTH BEYOND 2000 - ADVANCED EDITION BOOK The Manufacturer has appointed the Customer the copyright
holder of both the English and the Chinese version of the book How to achieve Super Health beyond
2000 - Advanced Edition, authored by Frank D.P. Ellis and Dr. Michael Tait M.D. This appointment
shall be deemed valid provided the Customer fulfils and maintains the criteria of this agreement.
The Customer will provide the Manufacturer with prior notification of printing runs of the book and
the quantity of books to be printed in each run. The Customer will compensate the Manufacturer the
amount of AUS $1.00 per book prior to printing. ODM Supply Agreement 10 Organic Preparations INC. &
Agape ATP International Holding Limited

Source: AGAPE ATP CORP, 10-K/A, 12/2/2019
<!-- page 11 -->
EQUITY HOLDINGS LIMITED by the duly authorised Officer: __________________________________
____________________________ Common Seal of Organic Preparations INC. was hereunto affixed in the
presence of Duly authorized to sign on behalf of Organic Preparations INC. Date 15 JANAURY, 2018 In
the presence of: Witness Signature ____________________ Date 15 JANAURY, 2018 Witness Name Mercy
Saula Address 2nd Floor, Transpacific Hous, Port Vila, Vanuatu. Signed under common seal of Agape
ATP International Holding Limited with authority of the board. Signature ______________ Name How Kok
Choong ______________________ Common Seal of Agape ATP International Holding Limited Date 31
JANAURY, 2018 In the presence of: Witness Signature ___________________________ Date 31 JANAURY,
2018 Witness Name Ku Suat Hong Address 17-1, 17-2, 17-3, 17-4, Wisma Laxton, Jalan Desa,Taman Desa,
Off Jalan Klang Lama, 58100 Kuala Lumpur. ODM Supply Agreement 11 Organic Preparations INC. & Agape
ATP International Holding Limited

Source: AGAPE ATP CORP, 10-K/A, 12/2/2019
<!-- page 12 -->
SCHEDULE A - The Products at Commencement Product names: ATP 1S Survivor Select ATP 2 Energized
Mineral Concentrate ATP 3 Ionized Cal-Mag ATP 4 Omega Blend ATP 5 BetaMaxx AGP 1 Iron YFA Young
Formula ORYC Organic Soap SCHEDULE B - Minimum Annual Product Performance Requirements Performance
targets have been discussed between the Manufacturer and the Customer to determine fair and
reasonable performance targets. Minimum Annual Product Performance Requirements are listed below:
Product Name: Agreed Quantity of Units to be purchased per Annum: ATP 1 S Survivor Select 150gm
packaged 15,000 ATP 2 Energized Mineral Concentrate 29.5mL packaged 20,000 ATP 3 Ionized Cal-Mag
114gm packaged 15,000 ATP 4 Omega Blend 250mL packaged 15,000 ATP 5 BetaMaxx 150gm packaged 15,000
AGP 1 Iron 29.5mL packaged 1000 YFA Young Formula 450gm packaged 3000 ORYC Organic Soap 150gm
packaged 2500 ODM Supply Agreement 12 Organic Preparations INC. & Agape ATP International Holding
Limited

Source: AGAPE ATP CORP, 10-K/A, 12/2/2019
<!-- page 13 -->
SCHEDULE C - THE TERRITORIES The Territories consisting of the following Countries: Global - All
countries ODM Supply Agreement 13 Organic Preparations INC. & Agape ATP International Holding
Limited

Source: AGAPE ATP CORP, 10-K/A, 12/2/2019
