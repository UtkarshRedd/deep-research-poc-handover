"""Approach 3 (PLAN Phase 5): planner-selected fan-out + extract grid + one gap round.

Never the default (3–10x tokens): the router selects `breadth`, and only then does this run.

Units. A `RouteDecision` gives either sub-questions (one context-isolated researcher each, scoped to
the first move's candidate documents) or doc batches (the extract grid asks the whole question of
every document in the batch, cheaply, in parallel). `A3_grid_only` forces the grid over the
candidates.

Researcher contract ("researcher with a contract"):
  * input: ONE sub-question, tools scoped to its doc ids, budget FANOUT_MAX_CALLS, fresh transcript
  * output: a schema-validated `Finding` whose answer is capped at FANOUT_FINDING_MAX_TOKENS and
    whose evidence ids exist in the SHARED bank (spot-checked); a unit that ends without a
    submission is retried once while time allows, then recorded as a failed hand-off
  * evidence goes straight into the shared bank with created_by="fanout:<i>"

Gap round (<= GAP_ROUNDS_MAX): the planner reads the findings and lists what is still missing;
each gap becomes one more targeted researcher. The bank is append-only, so evidence gathered
before the round cannot be lost (the regression check for claims happens in verification).

Units run in a thread pool of FANOUT_WIDTH; each unit is a full `ResearchLoop` (itself a LangGraph
state machine). LangGraph `Send` would express the same fan-out; threads keep the contract in
plain code and let every unit own its deadline.
"""
from __future__ import annotations

import re
import time
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field, replace
from typing import Any

from langchain_core.messages import HumanMessage
from pydantic import BaseModel, Field

from ..agents.researcher import A1_TOOLS, A2_TOOLS, ResearchContext, ResearchLoop
from ..config import DEFAULT, Config
from ..evidence import EvidenceBank
from ..models import Finding, FirstMoveResult, RouteDecision
from ..prompts import load
from ..structured import ModelCaller
from ..tools import outline as _outline
from ..tools.extract import GridResult, extract_grid
from ..tools.read import ReadTracker
from ..trace import Trace
from ..workspace import Workspace

_GENERIC = {"agreement", "inc", "llc", "corp", "corporation", "company", "ltd", "limited", "the", "and",
            "between", "dated", "filed", "group", "co", "plc", "holdings", "services", "international", "partners",
            "management", "technologies", "systems", "solutions", "capital", "trust", "bank", "first", "national"}
_WORD = re.compile(r"[A-Za-z][A-Za-z.&'-]{2,}")


def _name_terms(text: str) -> set[str]:
    return {w.lower().strip(".&'-") for w in _WORD.findall(text)} - _GENERIC


def docs_named_in(text: str, ws: Workspace, min_score: int = 2, limit: int = 8, near_ties: bool = True) -> list[str]:
    """Documents whose manifest title + parties share at least `min_score` distinctive words with
    `text` (e.g. "Touchstar Software ... Worldwide Strategies" -> the Reseller Agreement). Used to
    scope a fan-out unit or the grid to the agreements a question names; empty when nothing matches."""
    words = _name_terms(text)
    scored: list[tuple[int, str]] = []
    for doc_id, me in ws.manifest.items():
        terms = _name_terms(me.title + " " + " ".join(me.parties))
        hit = len(terms & words)
        if hit >= min_score or (hit == 1 and len(terms) == 1):
            scored.append((hit, doc_id))
    scored.sort(key=lambda x: (-x[0], x[1]))
    if not scored:
        return []
    best = scored[0][0]
    floor = max(min_score, best - 1) if near_ties else min_score   # near_ties: one agreement (+ its amendment)
    return [d for sc, d in scored[:limit] if sc >= floor]


@dataclass
class FanoutUnit:
    index: int
    sub_question: str
    doc_ids: list[str]
    kind: str = "sub_question"   # sub_question | gap


@dataclass
class FanoutResult:
    findings: list[Finding] = field(default_factory=list)
    failed_units: list[str] = field(default_factory=list)
    grid: GridResult | None = None
    gaps: list[str] = field(default_factory=list)
    elapsed_ms: int = 0

    def merged_answer(self) -> str:
        parts = []
        for f in self.findings:
            flag = " (not in its documents)" if f.not_in_corpus else ""
            parts.append(f"- {f.sub_question}{flag}: {f.answer}")
        if self.grid is not None:
            parts.append(self.grid.summary())
        if self.failed_units:
            parts.append(f"- {len(self.failed_units)} unit(s) returned no submission: " + "; ".join(self.failed_units))
        return "\n".join(parts)


class GapJSON(BaseModel):
    gaps: list[str] = Field(default_factory=list)


def plan_units(decision: RouteDecision, fm: FirstMoveResult | None, ws: Workspace, config: Config = DEFAULT) -> list[FanoutUnit]:
    """Sub-questions -> researcher units scoped to the first-move candidates (or all docs)."""
    scope = list(fm.candidate_doc_ids) if fm and fm.candidate_doc_ids else ws.doc_ids()
    subs = decision.sub_questions[: config.agents.FANOUT_UNITS_MAX]
    units = []
    for i, sq in enumerate(subs):
        named = docs_named_in(sq, ws)          # a sub-question that names its agreement gets just that scope
        units.append(FanoutUnit(index=i + 1, sub_question=sq, doc_ids=named or scope))
    return units


def _unit_config(config: Config) -> Config:
    a = config.agents
    return replace(config, agents=replace(a, RESEARCH_MAX_CALLS=a.FANOUT_MAX_CALLS, RESEARCH_MIN_CALLS=a.FANOUT_MIN_CALLS))


def _contract(finding: Finding, bank: EvidenceBank, config: Config) -> tuple[Finding, list[str]]:
    """Enforce the hand-off contract; returns (possibly adjusted finding, violations)."""
    problems: list[str] = []
    max_chars = config.agents.FANOUT_FINDING_MAX_TOKENS * 4
    if len(finding.answer) > max_chars:
        finding = finding.model_copy(update={"answer": finding.answer[:max_chars] + " …[truncated by the harness]"})
        problems.append("answer over the token cap (truncated)")
    bad = [e for e in finding.evidence_ids if bank.get(e) is None]
    if bad:
        finding = finding.model_copy(update={"evidence_ids": [e for e in finding.evidence_ids if e not in bad]})
        problems.append(f"unknown evidence ids dropped: {bad}")
    if not finding.evidence_ids and not finding.not_in_corpus:
        problems.append("no evidence and not marked not_in_corpus")
    return finding, problems


def run_units(units: list[FanoutUnit], question: str, ws: Workspace, bank: EvidenceBank, config: Config = DEFAULT,
              llm: Any | None = None, bm25: Any | None = None, trace: Trace | None = None,
              deadline_ts: float | None = None, run_id: str = "fanout") -> tuple[list[Finding], list[str]]:
    """Run researcher units in parallel under the contract; retry a unit once if it did not submit."""
    cfg = _unit_config(config)
    tools = A1_TOOLS if bm25 is not None else A2_TOOLS
    n = len(units)

    def one(unit: FanoutUnit) -> tuple[FanoutUnit, Finding | None, str | None]:
        task = load("fanout_researcher", index=unit.index, n_units=n, sub_question=unit.sub_question,
                    n_docs=len(unit.doc_ids), max_calls=cfg.agents.FANOUT_MAX_CALLS,
                    max_words=config.agents.FANOUT_FINDING_MAX_TOKENS * 3 // 4)
        if len(unit.doc_ids) <= 3:   # a unit on one agreement starts from its table of contents (RISE: TOC +1-4 pts)
            task += "\n\n" + "\n\n".join(_outline.render(_outline.outline(ws, d, config=config)) for d in unit.doc_ids)
        last_done = None
        for attempt in range(2):
            if deadline_ts is not None and time.time() >= deadline_ts:
                break
            ctx = ResearchContext(ws=ws, bank=bank, tracker=ReadTracker(), trace=trace, config=cfg,
                                  scoped_doc_ids=unit.doc_ids, created_by=f"fanout:{unit.index}",
                                  tool_names=tools, bm25=bm25, deadline_ts=deadline_ts, llm=llm,
                                  run_id=f"{run_id}-u{unit.index}", opening_observation=task)
            run = ResearchLoop(ctx).run(question, sub_question=unit.sub_question)
            last_done = run.done
            if run.done in ("submitted", "forced_submit"):
                finding, problems = _contract(run.finding, bank, config)
                if trace:
                    trace.event("fanout_unit", unit=unit.index, unit_kind=unit.kind, attempt=attempt + 1, done=run.done,
                                calls=run.calls_used, n_ids=len(finding.evidence_ids), problems=problems)
                if problems and "no evidence and not marked not_in_corpus" in problems and attempt == 0:
                    continue   # contract violation: one retry
                return unit, finding, None
            if trace:
                trace.event("fanout_unit", unit=unit.index, unit_kind=unit.kind, attempt=attempt + 1, done=run.done,
                            calls=run.calls_used, problems=["no submission"])
        return unit, None, f"unit {unit.index} ({unit.sub_question[:60]}): {last_done or 'no time left'}"

    with ThreadPoolExecutor(max_workers=max(1, min(config.agents.FANOUT_WIDTH, n or 1))) as ex:
        results = list(ex.map(one, units))
    findings = [f for _, f, _ in results if f is not None]
    failed = [err for _, f, err in results if f is None and err]
    return findings, failed


def gap_check(question: str, findings: list[Finding], caller: ModelCaller, config: Config = DEFAULT) -> list[str]:
    if not findings:
        return []
    summary = "\n".join(
        f"- [{f.sub_question}] {'NOT IN DOCUMENTS. ' if f.not_in_corpus else ''}{f.answer[:600]}" for f in findings
    )
    got = caller.json([HumanMessage(content=load("gap_check", question=question, findings=summary,
                                                  max_gaps=config.agents.GAP_UNITS_MAX))], GapJSON)
    if got is None:
        return []
    return [g.strip() for g in got.gaps if g.strip()][: config.agents.GAP_UNITS_MAX]


def run_breadth(question: str, decision: RouteDecision, fm: FirstMoveResult | None, ws: Workspace, bank: EvidenceBank,
                config: Config = DEFAULT, llms: dict[str, Any] | None = None, bm25: Any | None = None,
                trace: Trace | None = None, deadline_ts: float | None = None, grid_only: bool = False,
                run_id: str = "fanout") -> FanoutResult:
    """The whole breadth branch: units (researchers or grid) -> gap round -> merged result."""
    llms = llms or {}
    t0 = time.perf_counter()
    res = FanoutResult()
    s = config.stages
    research_deadline = deadline_ts
    candidates = list(fm.candidate_doc_ids) if fm and fm.candidate_doc_ids else ws.doc_ids()

    if grid_only or (not decision.sub_questions and decision.doc_batches):
        # grid scope: the router's batches, else the top first-move candidates (one batch); a grid over
        # hundreds of documents blows the research budget on a rate-limited endpoint
        named = docs_named_in(question, ws, limit=config.agents.FANOUT_BATCH_SIZE, near_ties=False)   # every agreement the question lists
        default = named or candidates[: config.agents.FANOUT_BATCH_SIZE]
        batches = decision.doc_batches if (decision.doc_batches and not grid_only) else [default]
        ids = [d for b in batches for d in b]
        res.grid = extract_grid(ws, bank, question, ids, llm=llms.get("extractor"), bm25=bm25, config=config,
                                trace=trace, deadline_ts=research_deadline)
    else:
        units = plan_units(decision, fm, ws, config)
        res.findings, res.failed_units = run_units(units, question, ws, bank, config, llm=llms.get("researcher"),
                                                   bm25=bm25, trace=trace, deadline_ts=research_deadline, run_id=run_id)

    # one gap round, inside the research budget
    if config.agents.GAP_ROUNDS_MAX > 0 and res.findings and (deadline_ts is None or time.time() < deadline_ts - s.GAP / 3):
        planner = llms.get("planner")
        if planner is None:
            from ..llm import get_llm

            planner = get_llm("planner")
        gap_deadline = min(time.time() + s.GAP, deadline_ts) if deadline_ts else time.time() + s.GAP
        caller = ModelCaller(planner, trace, "gap_check", "planner", deadline_ts=gap_deadline)
        res.gaps = gap_check(question, res.findings, caller, config)
        if res.gaps:
            units = [FanoutUnit(index=len(res.findings) + i + 1, sub_question=g, doc_ids=candidates, kind="gap")
                     for i, g in enumerate(res.gaps)]
            more, failed = run_units(units, question, ws, bank, config, llm=llms.get("researcher"), bm25=bm25,
                                     trace=trace, deadline_ts=gap_deadline, run_id=f"{run_id}-gap")
            res.findings += more
            res.failed_units += failed
    res.elapsed_ms = int((time.perf_counter() - t0) * 1000)
    if trace:
        trace.stage("fanout", "end", n_findings=len(res.findings), n_failed=len(res.failed_units),
                    n_gaps=len(res.gaps), grid=res.grid is not None, n_evidence=len(bank), ms=res.elapsed_ms)
    return res
