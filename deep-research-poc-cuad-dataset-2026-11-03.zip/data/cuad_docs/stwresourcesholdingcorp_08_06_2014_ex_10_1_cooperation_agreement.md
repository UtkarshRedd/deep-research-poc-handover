<!-- page 1 -->
# COOPERATION AGREEMENT
| Field | Value |
|---|---|
| Document Type | Collaboration Agreement |
| SEC Filing Date | 2014-08-06 |
| Parties | City of Fort Stockton ("COFS"); STW resources Holding Corp ("STW"); individually referred to as a "Party, collectively referred to as "Parties" |
| Source | CUAD v1 / STWRESOURCESHOLDINGCORP_08_06_2014-EX-10.1-COOPERATION AGREEMENT |

Exhibit 10.1 COOPERATION AGREEMENT BETWEEN THE CITY OF FORT STOCKTON, TEXAS AND STW RESOURCES
HOLDING CORP. REGARDING DEVELOPMENT OF WATER WELL(S) IN THE CAPITAN REEF AQUIFER FORMATION

This AGREEMENT regarding development of water well(s) in the Capitan Reef Aquifer Formation (the
"AGREEMENT") is entered into by the City of Fort Stockton, Texas, a Texas Type A-General Law city
("COFS") and STW Resources Holding Corp., a Nevada corporation ("STW"), effective as of the last
date of signature on the signature pages below. STW and COFS are sometimes individually referred to
as a "Party" and collectively referred to as the "Parties."

WHEREAS, the City of Fort Stockton, Texas ("COFS") owns the surface and groundwater rights to
several areas of the Capitan Reef Aquifer Formation; and

WHEREAS, COFS has an existing Capitan Reef Aquifer ("CRA") water well located at Section 112 on COFS
property, which is currently drilled to an approximate depth of 3,500 feet (the "Existing CRA
Well"), and also owns property at Section 71; and

WHEREAS, STW desires to attempt to deepen the Existing CRA Well in order to make it a producing
water well and/or drill an alternate well(s) at its own expense, and to lease CRA groundwater rights
from Sections 112 and 71 of COFS property; and WHEREAS, STW and COFS desire to work together for the
development of a CRA water supply project within the area that will serve to meet the future needs
of COFS and the municipal and industrial needs within the region.

THE PARTIES HEREBY AGREE AS FOLLOWS:

1. Leasing of Property and Drilling of Water Well(s). COFS hereby grants, leases and lets unto STW
the right to explore for, drill for, produce, utilize, transport, and treat groundwater from the CRA
only from beneath the surface of the property more specifically described in Exhibit "A," which is
attached hereto and fully incorporated into this AGREEMENT (hereinafter collectively referred to as
the "Property"). STW is further authorized to drill, deepen, and/or rework at its expense the
Existing CRA Well on Section 112 of the Property from its current depth of approximately 3,500 feet
to approximately 4,000 feet, so as to determine the following to be verified by a study to be
performed by a hydrogeologist mutually agreed upon by both Parties ("Post-Well Study"): (a) the
gallons per day ("GPD") of maximum water capacity of the Existing CRA Well or alternate well, as may
be required under Section 5 of the AGREEMENT; and (b) the quality of the water to be obtained from
the Existing CRA Well or alternate well. The rights granted to STW under this AGREEMENT also include
the right of access to the Property to perform the activities authorized herein. 2. Acces s and
Surface Use. STW agrees to coordinate reasonably with COFS with respect to location of any new
wells, roadways, power infrastructure, and other improvements that are to be constructed or used on
the Property. COFS shall provide STW rent free site leases for the commercially reasonable amounts
of surface area required for CRA pumping and filling stations located on the Property. STW shall pay
for or repair all actual damages to roads, fences, or improvements caused by its activities on the
Property within sixty (60) days of the occurrence, and will fill and level all pits, mounds, ruts,
and shall restore the surface to as near its original condition as is reasonably practicable within
ninety (90) days after termination of the provisions of this AGREEMENT related only to the Property.
Upon termination of the provisions of this AGREEMENT related to the Property only, STW, or its
successors or assigns, shall transfer title of all water conveyance pipelines from the Property to
COFS. STW shall administer and provide all necessary and reasonable insurance to insure its
activities on the Property in relation to the AGREEMENT and shall list COFS as additional insured.

-1-
<!-- page 2 -->
3. Term. Subject to the other provisions contained herein, this AGREEMENT shall be for a term of
thirty (30) years from the Effective Date, which shall automatically renew from year-to-year
thereafter unless terminated by a Party upon sixty (60) days' written notice after the end of the
term. Notwithstanding the 30-year term of this agreement, should STW procure sales agreements with
customers for a duration of longer than 30 years, STW shall be authorized to maintain and service
such contract(s) to the extent of the water volume(s) purchased, and this AGREEMENT shall not
terminate during the initial term of any such water supply agreement with a term extending beyond
this AGREEMENT. 4. Post-Well Study Generally. The Post-Well Study shall provide information on the
feasibility of developing a water well field in that location that would produce water from the CRA
for: (a) the availability of a minimum 1,200 gallons per minute ("GPM") per day CRA water production
for STW, its successors or assignees, to sell to communities and users within a 500-mile radius
outside of COFS (the "Permitted Sale Water") during the Term, with the further requirement that STW
would be responsible for the pipelines and pumping facilities required to transport the Permitted
Sale Water to the intended end-users; and that all such water obtained from the Existing CRA Well
contains acceptable levels of Total Dissolved Solids ("TDS") to meet municipal use standards. If
such water does not meet municipal use standards according to the Post-Well Study, STW may either
treat the water to municipal use standards or to sell it as-is to industrial end-users. 5.
Replacement CRA Well. If, based on the Post-Well Study of the Existing CRA Well, it is determined
that the Existing CRA Well is not suitable for the purposes of this AGREEMENT, then STW may elect to
drill at its expense a second water well (the "Replacement CRA Well") at a place to be mutually
agreed on the Property, with the Existing CRA Well to remain as a monitoring well. After completion
of the Replacement CRA Well, a second Post-Well Study will be conducted for the same purposes as
that for the Existing CRA Well. 6. Construction Requirements. STW's construction of the improvements
to the Existing CRA Well, any Replacement CRA Well, and any additional production wells shall be
pursuant to any recommendation and requirements as may be specified by and agreed upon with COFS,
and the construction shall also be conducted in a manner meeting prevailing industry standards, the
Middle Pecos Groundwater Conservation District regulations, Texas Department of Licensing and
Regulation (TDLR) regulations, and the Texas Commission on Environmental Quality (TCEQ) regulations.
7. Cooperation Regarding Studies. COFS shall provide to STW any and all documents pertaining to this
project, including all hydrogeological studies and any existing Pre-Well Studies for the Existing
CRA Well, as well as any similar documents for the Replacement CRA Well to include: a. the best
location for the Replacement CRA Well on the Property, considering the spacing with any other wells
that might now or in the future be located on the Property; b. the location on the Property that
will best provide data for determining the feasibility of pumping water from the CRA on the Property
and be the most productive; c. documents showing current ownership of the Property including both
CRA and surface ownership rights, to demonstrate COFS' ability to lease the land for the Sale of CRA
Water Rights to STW, including any documents showing the prior sale or conveyance of any CRA or
water rights from the Property; and d. names and addresses of engineers and/or hydrogeologists
recommended to perform the Post-Well Study (ies). The Post-Well Study (ies) shall be performed by a
hydrogeologist(s) mutually agreed to by both Parties.

-2-
<!-- page 3 -->
8. Post-Well Study Requirements. Any Post-Well Studies shall be paid for by STW and shall include:
a. a chemical analysis and performance by a qualified certified laboratory mutually approved by the
Parties to determine the quality of the water and its characteristics at that location; b. any
documents related to the drawdown or recharge rate affecting the producing capacity; and c. TDS
measurements of CRA water produced by STW. 9. COFS Responsibilities. COFS shall perform the
following services: a. administer and provide all necessary insurance to insure its activities in
relation to the AGREEMENT; and b. possess or obtain any and all necessary property rights for the
activities covered in this AGREEMENT, including both CRA and surface rights to the Property. 10.
Construction and Post-Well Study Costs. STW will pay all reasonable and necessary costs to: (a)
construct the improvements to the Existing CRA Well or the Replacement CRA Well (including the cost
of securing any necessary regulatory approval for the improvements to the Existing CRA Well and the
Replacement CRA Well); (b) obtain the Post-Well Study (ies); and (c) reasonable consulting costs
related to the negotiation and execution of the AGREEMENT. 11. STW Termination Rights. STW shall
have the right to unilaterally terminate the provisions of this AGREEMENT related only to the
Property, and not proceed further after the completion of any phase of the project and not incur any
additional costs. So long as STW is progressing through the following phases, and subject to the
other terms of this AGREEMENT, COFS may not terminate the AGREEMENT during the: a. Pre-well study
(ies), b. completion of improvements to the Existing CRA Well, c. completion of the Replacement CRA
Well, if necessary, and d. Post-Well Study (ies). Should COFS unilaterally terminate the provisions
of this AGREEMENT related to COFS Property only, with the right to do so beginning on a period
beginning no sooner than ninety (90) days following the Post-Well Study (ies), and ending at the one
year period following the Post-Well Study (ies), during which STW may exercise its Option to Produce
Water, in accordance with Section 15 of this AGREEMENT, COFS shall reimburse STW for 100% of the
costs paid by STW up to the point of such termination, pursuant to the AGREEMENT, according to a
reasonable accounting schedule of costs prepared by STW and submitted to COFS. Once STW exercises
its Option to Produce Water pursuant to Section 15 of this AGREEMENT, and pays COFS its Bonus
Payment, in accordance with Section 14(b) of this AGREEMENT, COFS may no longer unilaterally
terminate this AGREEMENT during the Term. If STW terminates the AGREEMENT and COFS sells water
within twenty (20) years from the Effective Date of this AGREEMENT from one or more producing water
well(s) developed by STW, STW shall be reimbursed the amount expended for drilling the producing
well(s), to be paid from the sale of water produced by COFS from the producing well(s). Such
reimbursement shall occur based on COFS' net revenues received from CRA water sales from the
producing well(s) in six (6) month increments, which shall begin on the date COFS begins selling CRA
water from producing water well(s), and shall end upon reimbursement in full of the amount STW is
owed for drilling any producing well(s).

-3-
<!-- page 4 -->
12. Title of Producing Wells. Title and ownership of the Existing CRA Well, the Replacement CRA Well
and any additional wells drilled on the Property by STW (the "Additional Wells") shall be
transferred to STW by COFS and shall be held by STW; however, upon termination of the provisions of
this AGREEMENT that relate to COFS Property, STW shall transfer the title(s) back to COFS upon COFS'
reimbursement of STW as necessary under this AGREEMENT. 13. Uses, Maintenance, Construction and
Operation of Wells. STW will construct, maintain, operate, own, and repair (as needed) the Existing
CRA Well, the Replacement CRA Well and any Additional Wells, and in doing so, and in the wells'
operation and repair, STW shall: a. conduct all work and operations in a businesslike manner
consistent with good and economical practices and with due regard for good land management, damage
prevention and environmental protection; b. comply with all federal, state, and local laws,
regulations and requirements governing the development, production, collection, transportation, and
disposal of the water (and any waste or reject water); c. allow COFS or its authorized
representatives to enter upon the premises at reasonable times to be arranged in advance of entry;
and d. plug all wells, when abandoned, in accordance with the applicable regulatory requirements of
the Middle Pecos Groundwater Conservation District, TDLR, and/or TCEQ. 14. Obligations Following the
Post-Well Study. a. For purposes of this section, the Post-Well Study must show that the Existing
CRA Well or Replacement CRA Well can produce CRA water at a minimum of 1,200 GPM or more or a
combination of 1,200 GPM from one or more wells on the Property in order for STW to proceed with the
obligations set forth in this section ("Critical Criterion"). b. Obligations if Post-Well Study
shows that the Critical Criterion has been met: If all necessary regulatory approvals are obtained
that allow the production and transport of up to 10 million GPD or the maximum capacity of the well,
for STW's use or resale, in conjunction with STW exercising its Option to Produce Water under
Section 15 of this AGREEMENT, STW will pay COFS an upfront Bonus Payment of Five Million and 00/100
Dollars ($5,000,000.00), and STW shall have the immediate right to develop Additional Wells on the
Property, subject to all necessary regulatory approvals, in the event STW procures additional water
supply contracts that require additional volume of production, the feasibility of which shall be by
a Post Well hydrogeological study and report that shows the ability of STW to produce the additional
amounts of CRA water. STW shall have the right to the sale of and transport of such additional water
produced from Additional Wells. STW shall pay COFS a seventeen percent (17%) royalty of the price
STW receives per 1,000 gallons of CRA water produced from the Property and sold. STW shall also
provide to COFS three (3) million GPD of CRA water at no cost to COFS at such time that COFS
requests delivery of the water for COFS use. Each payment made by STW to COFS will include an
accounting statement providing the number of gallons sold, the price paid by any customer(s), the
gross revenues received by STW, and the expenses paid by STW for the sale, treatment, use, and/or
delivery of the CRA water. STW shall calculate the amount owed to COFS every one hundred-eighty
(180) days ("Accrual Period"), and shall provide required payments to COFS within thirty (30) days
after the end of the previous Accrual Period.

-4-
<!-- page 5 -->
c. Options if Post-Well Study shows that the Critical Criterion has not been met: (1) STW may choose
to not pursue the production and transport of the water from the Property. If one or more producing
wells are developed by STW and COFS sells the CRA water produced from the well(s), COFS will
reimburse STW from the net revenues COFS receives up to the point STW has been fully reimbursed for
drilling any producing well(s) if such sale occurs within twenty (20) years from the date of this
AGREEMENT. (2) STW may choose to pursue the production and transport of the water. STW shall have
the right to produce and transport the water upon obtaining all necessary regulatory approvals, and
will not seek reimbursement of any of its costs incurred pursuant to the AGREEMENT. (3) If
regulatory approvals have been granted, but the permit obtained from the Middle Pecos Groundwater
Conservation District allows the transport of less than the full amount requested for STW's use or
sale, then STW may: i. elect to produce and transport the water; or ii. elect to not produce and
transport the water, in which case the conditions of Subsection (c)(1) of this section shall apply.
15. Option to Produce Water. a. STW will have one year from completion of the last of the Post-Well
Study (ies) completed on the Existing CRA Well or Replacement CRA Well to exercise its option to
produce and transport the water produced from the CRA on the Property ("Option to Produce"). The
AGREEMENT shall thereafter terminate as to both Parties if STW has not exercised its Option to
Produce at the expiration of the one-year period unless STW pays as royalty on the first day of each
month the sum of Five Hundred and 00/100 Dollars ($500.00) per month. STW shall have no right to
maintain this AGREEMENT through payment of such a royalty for any one period greater than three
consecutive years. b. If, after STW has exercised its option to produce CRA water from the Property,
one or more producing wells on the Property are capable of producing CRA water for sale, but CRA
water is not being sold for a consecutive period of 180 days or more, then the lease shall terminate
as to both parties unless STW pays as royalty on the first day of each month after such period of
180 days, the sum of Five Thousand and 00/100 Dollars ($5,000) per month. STW shall have no right to
maintain this AGREEMENT through payment of such a royalty for any one period greater than three (3)
consecutive years. c. If STW exercises its option to produce and transport the CRA water, STW will
construct additional facilities or expand existing facilities, as necessary, to be able to produce
and transport the CRA water for sale. -5-
<!-- page 6 -->
16. Payment for Use of COFS Pipeline Easements and COFS Assistance with Project. a. STW shall be
entitled to use existing COFS easements and right of ways within Pecos County for laying of
pipelines necessary for the delivery of CRA water produced within Pecos County. COFS will assist STW
with any negotiations required to procure any additional easements and groundwater rights in Pecos
County that are necessary for the production and delivery of CRA water. STW shall also be entitled
to use and upgrade existing COFS water treatment infrastructure as necessary for the treatment of
raw CRA water. STW shall pay COFS a seven percent (7%) royalty of the price STW receives per 1,000
gallons of CRA water produced from other properties within Pecos County and sold as consideration
for the rights provided by COFS to STW under this subsection. Such payment shall be made according
to the schedule and terms set forth in Section 14(b) of this AGREEMENT. The requirements under this
Section 16 shall remain in force and effect despite any termination of those provisions of this
AGREEMENT that apply only to COFS Property. The provisions of this section shall terminate in the
event STW is not producing CRA water from other properties in Pecos County for sale due to
termination of all such agreements or failure of STW to enter into such agreements regarding other
properties in Pecos County within ten (10) years from the Effective Date of this AGREEMENT. b. COFS
shall manage well maintenance and production operations for all CRA water produced within Pecos
County under the direction of STW. STW shall pay COFS for its reasonable costs incurred to manage
such well maintenance and production operations. c. STW shall conduct all necessary storage,
holding, and treatment of CRA water produced from the Property and from other properties within
Pecos County, as set forth in Subsection (a) of this section, within the boundaries of Pecos County.
17. Authorized Third Party Beneficiary. STW shall be listed as a third party beneficiary to any
contracts to guarantee payment of any of the obligations of this contract between COFS and Pecos
County or any other entity or individual. 18. Venue. This AGREEMENT is controlled by the laws of the
State of Texas, and venue for any actions brought to enforce this AGREEMENT shall be brought
exclusively in a court of competent jurisdiction in Pecos County, Texas. 19. Authority. The Parties
executing this AGREEMENT represent that they have full and actual authority to sign and to be bound
by this AGREEMENT. 20. Taxes and Fees. STW shall pay all taxes, fees, assessments, and costs
associated with the rights, pumping, and use of the CRA water from the Property and other properties
in Pecos County. COFS shall bear and pay any ad valorem taxes assessed directly against COFS'
royalty, any federal or state income taxes payable on the royalty and on the other compensation
payable to COFS under this AGREEMENT, and taxes assessed on COFS' ownership of the surface of the
Property and other minerals not conveyed under this AGREEMENT. 21. Governmental Authority. STW shall
be responsible for obtaining any approval required from any applicable governmental authority with
jurisdiction over the activities under this AGREEMENT. COFS shall assist STW with any documentation
needed to obtain the necessary approvals required.

-6-
<!-- page 7 -->
22. Force Majeure. If a Party is rendered unable, wholly or in part, to carry out any of its
obligations under the Agreement, other than an obligation to pay money, as a result of Force
Majeure, then its obligations shall be suspended, to the extent affected by such Force Majeure,
during the continuance of any inability so caused, provided that notice of the Force Majeure is
provided to the other Party as soon as reasonably practicable. The Party claiming the Force Majeure
shall use due diligence to resume performance at the earliest practicable time, and such suspension
shall not extend for a period longer than twenty-four (24) months from the date notice of the Force
Majeure is provided without payment as set forth under Section 15(a) of this AGREEMENT by STW, or
the option to terminate this AGREEMENT by STW if COFS is the party asserting the Force Majeure. 23.
Notice of Breach. In the event of default by any Party, a non-defaulting party may give the
defaulting party written notice specifying the default. If the defaulting party fails to fully cure
any monetary default that can be cured by payment within sixty (60) days after receipt of the
notice, or fails to commence the curing of any default specified in such notice that is other than a
monetary default within sixty (60) days from the date of the notice provided, then the
non-defaulting party may pursue all legal or equitable remedies against the defaulting party. 24.
Notices. Service of all notices under this AGREEMENT shall be sufficient when hand- delivered or
sent by certified mail to the respective address set forth below, unless notice is provided by a
Party under this section to the other Party indicating a change to the address listed herein. Any
such notice mailed to such address shall be effective when hand- delivered, deposited in the United
States mail, certified, duly addressed, and with postage prepaid or national overnight courier. STW:
STW Resources Attn: Stanley Weiner 3424 South County Road 1192 Midland, Texas 70706 COFS: City of
Fort Stockton Attn: City Manager 121 W. 2nd Street Fort Stockton, Texas 79735 25. Indemnification.
The Parties shall indemnify, hold harmless, and defend each other, their heirs, successors, and
assigns, from and against any and all losses, liabilities, damages, costs, attorney's fees,
expenses, causes of action, suits, claims, and judgments of any kind or character for injury to
person or property arising in whole or in part out of the responsibilities set forth in this
AGREEMENT, whether due to the negligence of a Party or otherwise. 26. Waiver. The failure on the
part of either Party to require performance by the other of any portion of this AGREEMENT shall not
be deemed a waiver of, or in any way affect that Party's rights to enforce such provision. Any
waiver by either Party or any provision of this AGREEMENT shall not be a waiver of any other
provision hereof. 27. Severability. The invalidity or unenforceability of any provision of this
AGREEMENT shall not affect the validity or enforceability of any other provision of this AGREEMENT.
The provisions of Section 16 are severable from the provisions of the AGREEMENT related to the
Property, and shall remain in full force in effect upon termination of the provisions related only
to the Property. 28. Binding Effect. The AGREEMENT shall be binding upon and inure to the benefit of
the parties and their respective successors and assigns.

-7-
<!-- page 8 -->
29. No Partnership, Agency, or Third Party Beneficiaries Intended. Nothing in this AGREEMENT will be
construed as creating any form of partnership or joint venture relationship between the Parties, nor
shall any party be authorized to act as an agent for any other party. Nothing in this AGREEMENT
shall be construed to confer any right, privilege or benefit on, or to otherwise create any vested
right or third-party beneficiary relationship with any person or entity not a party to the
AGREEMENT, unless otherwise provided in this AGREEMENT. 30. Authority. Each of the persons signing
on behalf of the Parties hereby confirm that they have the authority to execute this AGREEMENT on
behalf of the Party indicated by their signature and have the authority to bind such Party hereto.
31. Further Assurances. STW and COFS shall take all further actions and shall execute and deliver to
the other any other document or instrument which is necessary to fully carry out the transactions
evidenced by this AGREEMENT. STW and COFS shall cooperate with each other and act in good faith to
accomplish the purposes of this AGREEMENT. 32. Compliance with Laws. The Parties agree that each
Party will comply with all applicable federal, state, and local laws and any applicable ordinances,
rules, orders, and regulations of any of the authorities having jurisdiction in carrying out its
duties and obligations hereunder. However, nothing contained in this AGREEMENT shall be construed as
a waiver of any right to question or contest any law, ordinance, order, rule, or regulation in any
forum having jurisdiction. 33. Entire Agreement. This AGREEMENT contains the entire agreement
between the Parties and any agreement not contained herein shall not be recognized by the parties.
The captions used herein are for convenience only and shall not be used to construe this AGREEMENT.
34. Counterparts. This AGREEMENT may be executed by the parties in any number of counterparts, each
of which when so executed and delivered shall be deemed an original instrument, but all such
counterparts together shall constitute but one and the same instrument.

(Signature Pages Follow)

-8-
<!-- page 9 -->
CITY OF FORT STOCKTON:

CITY OF FORT STOCKTON

By: _ (Printed Name) Title: Date:

STATE OF TEXAS § COUNTY OF PECOS §

This instrument was acknowledged before me on the day of , 2014, by Raul B. Rodriguez, City Manager
of the City of Fort Stockton.

Notary Public, State of Texas My Commission Expires

-9-

STW RESOURCES HOLDING CORP.:

STW Resources Holding Corp.
<!-- page 10 -->
By: _ Stanley T. Weiner

Title: CEO Date:

STATE OF TEXAS § COUNTY OF §

This instrument was acknowledged before me on the day of , 2014, by Stanley T. Weiner, CEO of STW
Resources Holding Corp.

Notary Public, State of Texas My Commission Expires
