<!-- page 1 -->
# TRANSFER AND SERVICING AGREEMENT, d
| Field | Value |
|---|---|
| Document Type | Service Agreement |
| Agreement Date | 2020-01-29 |
| Parties | VERIZON OWNER TRUST ("Issuer"); VERIZON ABS LLC ("Depositor"); Cellco Partnership d/b/a Verizon Wireless ("Cellco", "Servicer", "Marketing Agent", "Custodian") |
| Source | CUAD v1 / VerizonAbsLlc_20200123_8-K_EX-10.4_11952335_EX-10.4_Service Agreement |

Exhibit 10.4

FORM OF TRANSFER AND SERVICING AGREEMENT

among

VERIZON OWNER TRUST 2020-A, as Issuer,

VERIZON ABS LLC, as Depositor

and

CELLCO PARTNERSHIP d/b/a VERIZON WIRELESS, as Servicer, Marketing Agent and Custodian

Dated as of January 29, 2020

Source: VERIZON ABS LLC, 8-K, 1/23/2020
<!-- page 2 -->
TABLE OF CONTENTS

ARTICLE I USAGE AND DEFINITIONS 1 Section 1.1 Usage and Definitions 1

ARTICLE II TRANSFER AND ACQUISITION OF DEPOSITOR TRANSFERRED PROPERTY; REPRESENTATIONS AND
WARRANTIES

Section 2.1 Transfers of Depositor Transferred Property 1 Section 2.2 Acknowledgement of Further
Assignments 3 Section 2.3 Savings Clause 3 Section 2.4 Representations and Warranties About
Depositor Transferred Property. 3 Section 2.5 Originators' Reacquisition and Servicer's Acquisition
of Receivables for Breach of Representations 5

Section 2.6 Originators' Reacquisition or Servicer's Acquisition of Bankruptcy Surrendered
Receivables 6

ARTICLE III SERVICING OF RECEIVABLES 7 Section 3.1 Engagement 7 Section 3.2 Servicing of
Receivables. 7 Section 3.3 Servicer's Acquisition of Receivables 9 Section 3.4 Sale of Written-Off
Receivables 10 Section 3.5 Servicer Reports and Compliance Statements 11 Section 3.6 Review of
Servicer's Records 12 Section 3.7 Servicer's Authorized and Responsible Persons 13 Section 3.8
Servicer's Fees 13 Section 3.9 Servicer's Expenses 13 Section 3.10 Custodian. 13 Section 3.11
Marketing Agent 14 Section 3.12 Termination of Upgrade Programs; Credits Related to Upgrade Programs
15 Section 3.13 Notices to Obligors 16

ARTICLE IV ACCOUNTS, COLLECTIONS AND APPLICATION OF FUNDS 16 Section 4.1 Bank Accounts 16 Section
4.2 Investment of Funds in Bank Accounts 18 Section 4.3 Deposits and Payments 19 Section 4.4 Reserve
Account; Negative Carry Account; Acquisition Account 21 Section 4.5 Direction to Indenture Trustee
for Distributions 22

ARTICLE V DEPOSITOR 23 Section 5.1 Depositor's Representations and Warranties 23 Section 5.2
Liability of Depositor 24 Section 5.3 Merger, Consolidation, Succession or Assignment 25 Section 5.4
Depositor May Own Notes 25 Section 5.5 Depositor's Authorized and Responsible Persons 25 Section 5.6
Company Existence 25 Section 5.7 No Division 25

ARTICLE VI SERVICER AND MARKETING AGENT 25 Section 6.1 Servicer's and Marketing Agent's
Representations and Warranties 25 Section 6.2 Liability of Servicer and Marketing Agent 29 Section
6.3 Indemnities of Servicer and the Marketing Agent 29

Source: VERIZON ABS LLC, 8-K, 1/23/2020
<!-- page 3 -->
Section 6.4 Delegation and Contracting 31 Section 6.5 Servicer May Own Notes 31 Section 6.6 Annual
Statement as to Compliance 31 Section 6.7 Assessment of Compliance and Accountants' Attestation 31

ARTICLE VII SERVICER RESIGNATION AND TERMINATION; SUCCESSOR SERVICER 32 Section 7.1 No Resignation
32 Section 7.2 Servicer Termination Events 33 Section 7.3 Continue to Perform 34 Section 7.4
Successor Servicer 35 Section 7.5 Transition of Servicing 36 Section 7.6 Merger, Consolidation,
Succession or Assignment 37

ARTICLE VIII TERMINATION 37 Section 8.1 Optional Acquisition of Receivables; Clean-Up Redemption of
Notes 37 Section 8.2 Optional Redemption of Notes 38 Section 8.3 Termination 39

ARTICLE IX OTHER AGREEMENTS 39 Section 9.1 Financing Statements 39 Section 9.2 No Transfer or Lien
by Depositor 40 Section 9.3 Expenses 40 Section 9.4 Receivables Information 40 Section 9.5 No
Petition 40 Section 9.6 Limited Recourse 40 Section 9.7 Limitation of Liability 41 Section 9.8 Tax
Treatment of Notes 41 Section 9.9 Regulation RR Risk Retention 41 Section 9.10 Cap Collateral
Account 41

ARTICLE X MISCELLANEOUS 42 Section 10.1 Amendments 42 Section 10.2 Assignment; Benefit of Agreement;
Third-Party Beneficiary 44 Section 10.3 Notices 44 Section 10.4 Agent for Service 45 Section 10.5
GOVERNING LAW 45 Section 10.6 Submission to Jurisdiction 45 Section 10.7 WAIVER OF JURY TRIAL 46
Section 10.8 No Waiver; Remedies 46 Section 10.9 Severability 46 Section 10.10 Headings 46 Section
10.11 Counterparts 46 Section 10.12 Limitation of Rights of the Cap Counterparty 46 Section 10.13
Intent of the Parties; Reasonableness 46

ARTICLE XI ASSET REPRESENTATIONS REVIEW; DISPUTE RESOLUTION 47 Section 11.1 Asset Representations
Review 47 Section 11.2 Dispute Resolution 47

Source: VERIZON ABS LLC, 8-K, 1/23/2020
<!-- page 4 -->
Schedule A Schedule of Initial Receivables SA-1 Schedule B Notice Addresses SB-1 Appendix A Usage
and Definitions AA-1 Exhibit A Custodian's Security Requirements EA-1 Exhibit B Form of Annual
Certification EB-1

Source: VERIZON ABS LLC, 8-K, 1/23/2020
<!-- page 5 -->
TRANSFER AND SERVICING AGREEMENT, dated as of January 29, 2020 (this "Agreement"), among VERIZON
OWNER TRUST 2020-A, a Delaware statutory trust, as issuer (the "Issuer"), VERIZON ABS LLC, a
Delaware limited liability company, as depositor (the "Depositor"), and Cellco Partnership d/b/a
Verizon Wireless, a Delaware general partnership ("Cellco"), as servicer (in such capacity, the
"Servicer"), as marketing agent (in such capacity, the "Marketing Agent") and as custodian (in such
capacity, the "Custodian").

BACKGROUND

In the normal course of their businesses, Cellco and the other Originators originate device payment
plan agreements for various wireless devices. In addition, the Master Trust holds certain device
payment plan agreements originated by Cellco and certain other Originators.

In connection with a securitization transaction sponsored by Cellco in which the Issuer will issue
Notes secured by a pool of Receivables consisting of device payment plan agreements, certain of the
Originators and/or the Master Trust have transferred a pool of Receivables and related property, and
any of the Originators and/or the Master Trust may from time to time transfer additional pools of
Receivables and related property to the Depositor, who will transfer them to the Issuer. The Issuer
will engage the Servicer to service the Receivables.

The parties agree as follows:

ARTICLE I USAGE AND DEFINITIONS

Section 1.1 Usage and Definitions. Capitalized terms used but not defined in this Agreement are
defined in Appendix A. Appendix A also contains usage rules that apply to this Agreement. Appendix A
is incorporated by reference into this Agreement.

ARTICLE II TRANSFER AND ACQUISITION OF DEPOSITOR TRANSFERRED PROPERTY; REPRESENTATIONS AND
WARRANTIES

Section 2.1 Transfers of Depositor Transferred Property.

(a) Transfer and Absolute Assignment of Initial Receivables. In consideration of the Issuer's
delivery to the Depositor of the Notes, the Class A Certificate and the Class B Certificate,
effective on the Closing Date, the Depositor transfers and absolutely assigns to the Issuer, without
recourse (other than the Depositor's obligations under this Agreement), all of the Depositor's
right, title and interest, whether now owned or later acquired, in the Initial Receivables and the
other related Depositor Transferred Property. The Depositor certifies that the Credit Enhancement
Test and the Pool Composition Tests are satisfied for the transfer and assignment of the Initial
Receivables and the other related Depositor Transferred Property on the Closing Date.

(b) Transfers and Absolute Assignments of Additional Receivables. Subject to the satisfaction of the
conditions in Section 2.1(d), effective on each Acquisition Date, in consideration of the Issuer's
distribution to the Depositor of the (i) Additional Receivables Cash

Source: VERIZON ABS LLC, 8-K, 1/23/2020
<!-- page 6 -->
Transfer Amount for the Additional Receivables to be transferred to the Issuer on that Acquisition
Date and (ii) an increase in the Class B Certificate Principal Balance in an amount equal to the
excess, if any, of the Additional Receivables Transfer Amount over the Additional Receivables Cash
Transfer Amount for such Additional Receivables, the Depositor will transfer and absolutely assign
to the Issuer, without recourse (other than the Depositor's obligations under this Agreement), all
of the Depositor's right, title and interest, whether then owned or later acquired, in the
Additional Receivables and the other related Depositor Transferred Property.

(c) No Assumption of Obligations. These transfers and absolute assignments do not, and are not
intended to, include any obligation of the Depositor or any Originator to the Obligors or any other
Person relating to the Receivables and the other Depositor Transferred Property, and the Issuer does
not assume any of these obligations.

(d) Conditions for Transfers of Additional Receivables. The transfer and assignment of the
Additional Receivables and the other related Depositor Transferred Property on each Acquisition Date
will be subject to the satisfaction of the following conditions on or before such Acquisition Date:

(i) Transfer Notice. At least two (2) Business Days before the applicable Acquisition Date, the
Administrator shall deliver to the Issuer and the Indenture Trustee a Transfer Notice for the
Additional Receivables to be transferred and absolutely assigned on that Acquisition Date, which
will specify the Additional Receivables Transfer Amount and attach or include therewith the Schedule
of Receivables;

(ii) Satisfaction of Tests. After giving effect to the transfer and assignment of the Additional
Receivables by the Depositor to the Issuer, (A) the Credit Enhancement Test is satisfied and (B) the
Receivables, in the aggregate, owned by the Issuer, excluding any Temporarily Excluded Receivables,
satisfy each of the Pool Composition Tests under Section 3.5(b); and

(iii) Depositor's Certifications. The Depositor certifies that:

(A) as of such Acquisition Date, (1) the Depositor is Solvent and will not become insolvent as a
result of the transfer and assignment of the Additional Receivables on the Acquisition Date, (2) the
Depositor does not intend to incur or believe that it would incur debts that would be beyond the
Depositor's ability to pay as they matured and (3) the transfer and assignment of the Additional
Receivables is not made by the Depositor with actual intent to hinder, delay or defraud any Person;

(B) each of the representations and warranties made by the Depositor under Sections 2.4(a) and
2.4(b), in each case, solely with respect to the related Additional Receivables, will be true and
correct as of the Acquisition Date; and

(C) all conditions to the transfer and assignment of the related Additional Receivables by the
Originators to the Depositor under

2

Source: VERIZON ABS LLC, 8-K, 1/23/2020
<!-- page 7 -->
Section 2.1(d) of the Originator Receivables Transfer Agreement and by the Master Trust to the
Depositor under Section 2.1(d) of the Master Trust Receivables Transfer Agreement, as applicable,
have been satisfied.

The delivery by the Administrator, on behalf of the Depositor, of the Transfer Notice will be
considered a certification by the Depositor that the conditions set forth in this Section 2.1(d)
have been satisfied or will be satisfied on the Acquisition Date.

Section 2.2 Acknowledgement of Further Assignments. The Depositor acknowledges that, under the
Indenture, the Issuer will assign and pledge the Depositor Transferred Property and related property
and rights to the Indenture Trustee for the benefit of the Secured Parties.

Section 2.3 Savings Clause. The Depositor and the Issuer intend that each transfer and assignment
under this Agreement be an absolute transfer and assignment of the Depositor Transferred Property,
conveying good title to the Depositor Transferred Property free and clear of any Lien, other than
Permitted Liens, from the Depositor to the Issuer. The Depositor and the Issuer intend that the
Depositor Transferred Property not be a part of the Depositor's estate if there is a bankruptcy or
insolvency of the Depositor. If, despite the intent of the Depositor and the Issuer, a transfer and
assignment of Depositor Transferred Property under this Agreement is determined to be a pledge for a
financing or is determined not to be an absolute transfer and assignment, the Depositor Grants to
the Issuer a security interest in the Depositor's right, title and interest in the Depositor
Transferred Property to secure a loan in an amount equal to all amounts payable by the Depositor
under this Agreement, all amounts payable as principal of or interest on the Notes, all amounts
payable as Servicing Fees under this Agreement and all other amounts payable by the Issuer under the
Transaction Documents. In that case, this Agreement will be a security agreement under Law and the
Issuer will have the rights and remedies of a secured party and creditor under the UCC.

Section 2.4 Representations and Warranties About Depositor Transferred Property.

(a) Representations and Warranties About Pool of Receivables. The Depositor makes the following
representations and warranties about the pool of Receivables on which the Issuer is relying in
acquiring the Depositor Transferred Property. The representations and warranties are made as of the
Closing Date (for the Initial Receivables) and as of each Acquisition Date (for the related
Additional Receivables) and will survive the transfer and absolute assignment of the Depositor
Transferred Property by the Depositor to the Issuer under this Agreement and the pledge of the
Depositor Transferred Property by the Issuer to the Indenture Trustee under the Indenture.

(i) Valid Transfer and Assignment. This Agreement evidences a valid transfer and absolute assignment
of the Depositor Transferred Property from the Depositor to the Issuer, enforceable against
creditors of, purchasers from and transferees and absolute assignees of the Depositor.

(ii) Good Title to Depositor Transferred Property. Immediately before the transfer and absolute
assignment under this Agreement, the Depositor has good title to

3

Source: VERIZON ABS LLC, 8-K, 1/23/2020
<!-- page 8 -->
the Depositor Transferred Property free and clear of any Lien, other than Permitted Liens, and,
immediately after the transfer and absolute assignment under this Agreement, the Issuer will have
good title to the Depositor Transferred Property, free and clear of any Lien, other than Permitted
Liens.

(iii) Security Interest in Depositor Transferred Property.

(A) This Agreement creates a valid and continuing security interest (as defined in the applicable
UCC) in the Depositor Transferred Property in favor of the Issuer, which is prior to any Lien, other
than Permitted Liens, and is enforceable against all creditors of, purchasers from and transferees
and absolute assignees of the Depositor.

(B) All filings (including UCC filings) necessary in any jurisdiction to give the Depositor a first
priority, validly perfected ownership and security interest in the Originator Transferred Property
and the Master Trust Transferred Property, to give the Issuer a first priority, validly perfected
ownership and security interest in the Depositor Transferred Property and to give the Indenture
Trustee a first priority perfected security interest in the Collateral, will be made within ten (10)
days after the Closing Date or the related Acquisition Date, as applicable.

(C) All financing statements filed or to be filed against the Depositor in favor of the Issuer
describing the Depositor Transferred Property transferred under this Agreement will contain a
statement to the following effect: "A purchase, absolute assignment or transfer of or security
interest in any collateral described in this financing statement will violate the rights of the
Secured Party/Assignee."

(D) The Depositor has not authorized the filing of and is not aware of any financing statements
against the Depositor that include a description of collateral covering any Depositor Transferred
Property other than the financing statements relating to the security interest Granted to the
Depositor under the Receivables Transfer Agreements, by the Depositor to the Issuer under this
Agreement or by the Issuer to the Indenture Trustee under the Indenture, or that has been
terminated.

(b) Representations and Warranties About Security Interest. If the transfer and absolute assignment
of the Depositor Transferred Property under this Agreement is determined to be a pledge relating to
a financing or is determined not to be a transfer and absolute assignment, the Depositor makes the
following representations and warranties on which the Issuer is relying in acquiring the Depositor
Transferred Property, which representations and warranties are made as of the Closing Date or as of
the related Acquisition Date, as applicable,

4

Source: VERIZON ABS LLC, 8-K, 1/23/2020
<!-- page 9 -->
will survive termination of this Agreement and may not be waived by the Issuer or the Indenture
Trustee:

(i) Valid Security Interest. This Agreement creates a valid and continuing security interest (as
defined in the applicable UCC) in the Depositor Transferred Property in favor of the Issuer, which
is prior to all other Liens, other than Permitted Liens, and is enforceable against creditors of,
purchasers from and transferees and absolute assignees of the Depositor.

(ii) Type. Each Receivable is (A) if the Receivable is not secured by the related Device, an
"account" or "payment intangible," or (B) if the Receivable is secured by the related Device,
"chattel paper," in each case, within the meaning of the applicable UCC.

(iii) Good Title. Immediately before the transfer and absolute assignment under this Agreement, the
Depositor owns and has good title to the Depositor Transferred Property free and clear of all Liens,
other than Permitted Liens. The Depositor has received all consents and approvals required by the
terms of the Depositor Transferred Property to Grant to the Issuer its right, title and interest in
the Depositor Transferred Property, except to the extent the requirement for consent or approval is
extinguished under the applicable UCC.

(iv) Filing Financing Statements. The Depositor has caused, or will cause within ten (10) days after
the Closing Date, the filing of all appropriate financing statements in the proper filing office in
the appropriate jurisdictions under applicable Law to perfect the security interest Granted in the
Depositor Transferred Property to the Issuer under this Agreement. All financing statements filed or
to be filed against the Depositor in favor of the Issuer under this Agreement describing the
Depositor Transferred Property will contain a statement to the following effect: "A purchase,
absolute assignment or transfer of or grant of a security interest in any collateral described in
this financing statement will violate the rights of the Secured Parties."

(v) No Other Transfer, Grant or Financing Statement. Other than the security interest Granted to the
Issuer under this Agreement, the Depositor has not transferred or Granted a security interest in any
of the Depositor Transferred Property. The Depositor has not authorized the filing of and is not
aware of any financing statements against the Depositor that include a description of collateral
covering any of the Depositor Transferred Property, other than financing statements relating to the
security interest Granted to the Issuer. The Depositor is not aware of any judgment or tax Lien
filings against it.

Section 2.5 Originators' Reacquisition and Servicer's Acquisition of Receivables for Breach of
Representations.

(a) Representations and Warranties from Receivables Transfer Agreements. Each Originator and the
Servicer, severally has made, as of the Closing Date, and each Originator or the Servicer, as
applicable, severally will make, as of each Acquisition Date, the Eligibility

5

Source: VERIZON ABS LLC, 8-K, 1/23/2020
<!-- page 10 -->
Representation about the Receivables transferred and absolutely assigned by such Originator or the
Master Trust, respectively, on that date, and has consented to the transfer by the Depositor to the
Issuer of the Depositor's rights to such Eligibility Representation. The Issuer is relying on each
applicable Originator's or the Servicer's Eligibility Representation in acquiring the Receivables,
which Eligibility Representation will survive the transfer and absolute assignment of the
Receivables by the Depositor to the Issuer under this Agreement and the pledge of the Receivables to
the Indenture Trustee under the Indenture.

(b) Reacquisition or Acquisition. Under Section 2.1(a), the Depositor has transferred and absolutely
assigned to the Issuer the Depositor's rights under the Receivables Transfer Agreements, including
the right to require (i) an Originator to reacquire any Receivables transferred and absolutely
assigned by it under the Originator Receivables Transfer Agreement or (ii) the Servicer to acquire
any Receivable transferred and absolutely assigned by the Master Trust under the Master Trust
Receivables Transfer Agreement, in each case, for which such party has made the Eligibility
Representation if, in each case, there is a breach of such Eligibility Representation, such breach
is not cured and such breach results in a material adverse effect on the Issuer. If any Originator
or the Servicer breaches the Eligibility Representation made by it with respect to any Receivable
transferred by such Originator or the Master Trust, respectively, to the Depositor, such breach is
not cured and such breach has a material adverse effect on the Issuer, then the Depositor will
enforce such Originator's or the Servicer's obligation, as applicable, to reacquire or acquire,
respectively, any such Receivable transferred and absolutely assigned by it to the Depositor for
which the Eligibility Representation was breached pursuant to Section 3.4 of the applicable
Receivables Transfer Agreement.

(c) Reacquisition or Acquisition Sole Remedy. The sole remedy of the Depositor, the Issuer or the
Indenture Trustee for a breach of any Eligibility Representation is to require the related
Originator or the Servicer, as applicable, to reacquire or acquire, respectively, the Receivable
under Section 3.4 of the applicable Receivables Transfer Agreement.

Section 2.6 Originators' Reacquisition or Servicer's Acquisition of Bankruptcy Surrendered
Receivables.

(a) Reacquisition or Acquisition. Under Section 2.1(a), the Depositor has transferred and absolutely
assigned to the Issuer the Depositor's rights under the Receivables Transfer Agreements, including
the right to require (i) an Originator to reacquire any Receivables transferred and absolutely
assigned by it under the Originator Receivables Transfer Agreement or (ii) the Servicer to acquire
any Receivable transferred and absolutely assigned by the Master Trust under the Master Trust
Receivables Transfer Agreement, in each case, when such Receivable becomes a Bankruptcy Surrendered
Receivable. If any Receivable becomes a Bankruptcy Surrendered Receivable, the Depositor will
enforce such Originator's or the Servicer's obligation, as applicable, to reacquire or acquire,
respectively, any such Receivable transferred and absolutely assigned by it to the Depositor
pursuant to Section 4.6 or 4.7, respectively, of the applicable Receivables Transfer Agreement.

(b) Reacquisition or Acquisition Sole Remedy. If a Receivable becomes a Bankruptcy Surrendered
Receivable, the sole remedy of the Depositor, the Issuer or the Indenture Trustee is to require the
related Originator or the Servicer, as applicable, to reacquire

6

Source: VERIZON ABS LLC, 8-K, 1/23/2020
<!-- page 11 -->
or acquire, respectively, the Bankruptcy Surrendered Receivable under Section 4.6 or 4.7,
respectively, of the applicable Receivables Transfer Agreement.

ARTICLE III SERVICING OF RECEIVABLES

Section 3.1 Engagement. The Issuer engages Cellco as the Servicer of the Receivables for the Issuer
and the Indenture Trustee, and Cellco accepts this engagement.

Section 3.2 Servicing of Receivables.

(a) General Servicing Obligations. The Servicer will manage, service, administer and collect on the
Receivables with reasonable care using that degree of skill and attention that the Servicer
exercises for all comparable device payment plan agreement receivables that it services for itself
or others according to the Servicing Procedures. Without limiting the generality of the foregoing,
the Servicer's obligations will include:

(i) collecting and applying all payments made on, or credits applied to, the Receivables and any
other amounts received related to the Depositor Transferred Property;

(ii) investigating delinquencies;

(iii) sending invoices and notices and responding to inquiries of Obligors;

(iv) processing requests for extensions, modifications and adjustments;

(v) administering payoffs, prepayments, defaults and delinquencies;

(vi) maintaining accurate and complete accounts and receivables systems for servicing the
Receivables;

(vii) providing to the Custodian copies, or access to, any documents that modify or supplement
information in the Receivable Files; and

(viii) preparing and providing Monthly Investor Reports and any other periodic reports required to
be prepared by the Servicer under this Agreement or any other Transaction Document.

(b) Collection of Payments; Extensions and Amendments. The Servicer shall take, or cause to be
taken, all actions necessary or advisable to collect each Receivable in accordance with this
Agreement and the Servicing Procedures using commercially reasonable care and diligence and in any
event, with no less care or diligence than the Servicer exercises in collecting other similar
receivables or obligations owed to it and its Affiliates. All payments remitted by an Obligor to the
Servicer in respect of a Receivable, any release of a security deposit, and any application of a
Credit granted to a customer by Verizon Wireless (other than applications of payments and credits
granted to an Obligor under a Receivable in respect of cancellations, prepayments, invoicing errors
or in connection with an Upgrade Offer as described under Section

7

Source: VERIZON ABS LLC, 8-K, 1/23/2020
<!-- page 12 -->
3.12(b)) will be applied to the related account by the Servicer based on invoice aging, so that such
amounts are applied to the oldest invoiced balances first, then the second oldest invoiced balances,
etc., and finally to current billing amounts, in each case, in the order described below:

• late fees;

• service and all other charges, including, but not limited to, insurance premium payments and
purchases (including accessories) billed to the account, other than amounts due under any device
payment plan agreement, including any Receivable; and

• any amounts related to any device payment plan agreements, including Receivables, which, in the
case of multiple device payment plan agreements related to a single account, will be applied in the
order in which such device payment plan agreements were originated with the most recent device
payment plan agreement being paid last.

Notwithstanding anything to the contrary in any other Transaction Document, the process for
application of payments remitted by an Obligor to the Servicer in respect of a Receivable, releases
of security deposits, and applications of Credits granted to an Obligor under a Receivable by
Verizon Wireless (other than those credits granted to an Obligor in respect of an Upgrade Offer as
described under Section 3.12(b)) described in the bullet points above may be changed at any time in
the sole discretion of the Servicer, as long as any change in such application of any such amounts
applicable to the Receivables (i) is also applicable to any device payment plan agreements that the
Servicer services for itself and others and (ii) so long as Cellco is the Servicer, does not have a
material adverse effect on the Noteholders. In addition, the Servicer may waive late payment charges
or other fees that may be collected in the ordinary course of servicing a Receivable. The Servicer
may grant extensions, refunds, rebates or adjustments on any Receivable or amend any Receivable
according to the Servicing Procedures. However, if the Servicer (i) grants payment extensions
resulting in the final payment date of the Receivable being later than the Collection Period
immediately preceding the Final Maturity Date for the latest maturing Class of Notes, (ii) cancels a
Receivable or reduces or waives (including with respect to any Upgrade Offer) the remaining
Principal Balance under a Receivable or any portion thereof and/or as a result, the monthly payments
due thereunder, or (iii) modifies, supplements, amends or revises a Receivable to grant the Obligor
under such Receivable a contractual right to upgrade the related Device, it will acquire the
affected Receivable solely as described under Section 3.3, unless it is required to take the action
by Law. In addition, if the Marketing Agent or the Servicer (x) applies a payment or grants a credit
to an Obligor with respect to cancellations, prepayments or invoicing errors the Servicer may apply
such credits either directly to the applicable device payment plan agreement or in accordance with
its customary payment application procedures set forth above and (y) applies a payment or grants a
credit to an Obligor under a Receivable in connection with an Upgrade Offer as set forth in Section
3.12(b), the Servicer will apply such credits directly to the applicable device payment plan
agreement and will not apply such credits in accordance with its customary payment application
procedures set forth above.

8

Source: VERIZON ABS LLC, 8-K, 1/23/2020
<!-- page 13 -->
(c) Maintenance of Security Interests in the Receivables. The Servicer will maintain perfection of
the security interest of the Issuer and the Indenture Trustee in each Receivable.

(d) No Impairment. The Servicer will not impair in any material respect the rights of the Issuer or
the Noteholders in any Receivable except as permitted by this Agreement.

(e) Assignment for Enforcement. Effective as of the related Cutoff Date, the Receivables are
assigned to the Servicer solely for the purpose of permitting the Servicer to perform its servicing
and administrative obligations under this Agreement, including the start or pursuit of or
participation in a legal proceeding to enforce its rights or remedies with respect to a Receivable
or such other Proceeding otherwise related to a Receivable. If in a legal proceeding it is held that
the Servicer may not enforce its rights or remedies with respect to a Receivable on the grounds that
it is not a real party in interest or a holder entitled to enforce rights or remedies with respect
to the Receivable, the Issuer will, at the Servicer's expense and direction, assign the Receivable
to the Servicer solely for that purpose or take steps to enforce its rights and remedies with
respect to the Receivable, including bringing suit in the names of the Indenture Trustee, the
Noteholders and the Issuer.

(f) Powers of Attorney. The Issuer appoints the Servicer as the Issuer's attorney-in-fact, with full
power of substitution to exercise all rights of the Issuer for the servicing and administration of
the Receivables. This power of attorney, and all authority given, under this Section 3.2(f) is
revocable and is given solely to facilitate the performance of the Servicer's obligations under this
Agreement and may only be used by the Servicer consistent with this Agreement. On request of the
Servicer, the Issuer will furnish the Servicer with written powers of attorney and other documents
to enable the Servicer to perform its obligations under this Agreement.

(g) Release Documents. The Servicer is authorized to execute and deliver, on behalf of itself, the
Issuer, the Indenture Trustee and the Noteholders any documents of satisfaction, cancellation,
partial or full release or discharge, and other comparable documents, for the Receivables.

(h) Enforcement of Receivables Under an Upgrade Offer. If an Obligor accepts an Upgrade Offer with
respect to a Receivable but fails to satisfy the required terms and conditions related to such
Upgrade Offer, the Servicer agrees to (i) not waive any amounts due by such Obligor under the
related Receivable and pursue its Servicing Procedures against such Obligor in respect of the
related Receivable until all amounts due under the related Receivable are received and (ii) enforce,
on behalf of the Issuer, any rights and obligations under the related Receivable.

Section 3.3 Servicer's Acquisition of Receivables.

(a) Acquisition for Servicer Modifications. If extensions, modifications, amendments, cancellations
or waivers of Receivables or any terms thereof are made that would require such Receivables to be
acquired under Section 3.2(b), the Servicer will acquire all such Receivables as set forth in
Section 3.3(d).

(b) Acquisition for Breach of Servicer's Obligations. If a Responsible Person of the Servicer
receives written notice from the Depositor, the Issuer, the Owner Trustee or the

9

Source: VERIZON ABS LLC, 8-K, 1/23/2020
<!-- page 14 -->
Indenture Trustee of a breach of the Servicer's obligations in Section 3.2(c) or (d), and the
Servicer fails to correct such failure or impairment in all material respects by the end of the
second month following the month in which the Servicer received such written notice, the Servicer
will acquire all Receivables with respect to which such breach was not so cured as set forth in
Section 3.3(d).

(c) Acquisition for System Limitation or Inability to Service. If the Servicer, in its sole
discretion, determines that as a result of a receivables systems error or receivables systems
limitation or for any other reason the Servicer is unable to service a Receivable according to the
Servicing Procedures and the terms of this Agreement, the Servicer may acquire the relevant
Receivable as set forth in Section 3.3(d).

(d) Acquisition of Receivables; Payment of Acquisition Amount. For any acquisition of a Receivable
by the Servicer under this Section 3.3, the Servicer will acquire the Receivable by remitting the
related Acquisition Amount on or prior to the second Business Day before the Payment Date related to
the Collection Period in which such Receivable was acquired by the Servicer. If Cellco is the
Servicer, it may pay any Acquisition Amounts according to Section 4.3(c).

(e) Transfer and Assignment of Acquired Receivables. When the Servicer's payment of the Acquisition
Amount for a Receivable is included in Available Funds for a Payment Date, the Issuer will be deemed
to have transferred and assigned to the Servicer, effective as of the last day of the Collection
Period immediately preceding the related Collection Period, all of the Issuer's right, title and
interest in the Receivable and all security and documents relating to the Receivable. The transfer
and assignment will not require any action by the Issuer or the Indenture Trustee and will be
without recourse, representation or warranty by the Issuer except the representation that the Issuer
owns the Receivable free and clear of any Lien, other than Permitted Liens. After the transfer and
assignment, the Servicer will mark its receivables systems to indicate that the receivable is no
longer a Receivable and may take any action necessary or advisable to transfer the Receivable free
from any Lien of the Issuer or the Indenture Trustee.

(f) No Obligation to Investigate. None of the Issuer, the Owner Trustee, the Indenture Trustee
(including in its capacity as Successor Servicer hereunder), the Sponsor, the Marketing Agent, the
Depositor, the Parent Support Provider, the Administrator or the Servicer will be obligated to
investigate whether a breach or other event has occurred that would require the acquisition of any
Receivable under this Section 3.3 or whether any Receivables are otherwise required to be acquired
under this Section 3.3.

(g) Acquisition is Sole Remedy. The sole remedy of the Issuer, the Indenture Trustee, the Owner
Trustee, and the Secured Parties for any extension, modification, amendment, cancellation or waiver
of a Receivable or any terms thereof under Section 3.2(b) or a breach of the covenants made by the
Servicer in Section 3.2(c) or (d) is the Servicer's acquisition of the Receivables, as described
under this Section 3.3.

Section 3.4 Sale of Written-Off Receivables. The Servicer may sell to any third party a Receivable
that has been written off. Proceeds of any sale allocable to the Written-Off

10

Source: VERIZON ABS LLC, 8-K, 1/23/2020
<!-- page 15 -->
Receivable will be Recoveries. Any Recoveries will be paid to the Servicer as Supplemental Servicing
Fees and will not be a part of Available Funds. If the Servicer elects to sell a Written-Off
Receivable, the Receivable will be deemed to have been transferred and assigned by the Issuer to the
Servicer immediately before the sale by the Servicer. After the sale, the Servicer will mark its
receivables systems to indicate that the Written-Off Receivable sold is no longer a Receivable and
may take any action necessary or advisable to transfer the receivable free from any Lien of the
Issuer or the Indenture Trustee.

Section 3.5 Servicer Reports and Compliance Statements.

(a) Monthly Investor Report.

(i) On or about the 15th day of each month, and in no case later than at least two (2) Business Days
before each Payment Date, the Servicer will deliver to the Depositor, the Indenture Trustee, the
Owner Trustee, the Note Paying Agent, the Cap Counterparty, the Rating Agencies and the
Administrator a servicing report (the "Monthly Investor Report") for that Payment Date and the
related Collection Period. The Monthly Investor Report will include (i) an Acquisition Date
Supplement if the Collection Period includes an Acquisition Date and (ii) a statement as to whether
or not a Delinquency Trigger has occurred in respect of the related Collection Period, together with
reasonably detailed calculations thereof. A Responsible Person of the Servicer will certify that the
information in the Monthly Investor Report is accurate in all material respects. The Monthly
Investor Report will also be posted on the Indenture Trustee's password protected website located at
https://pivot.usbank.com.

(ii) The Sponsor, in its capacity as Servicer, will include information about the pool of Initial
Receivables and the disclosure required by Section 246.4(c)(1)(ii) of the U.S. Credit Risk Retention
Rules in the Monthly Investor Report for the first Payment Date, which Monthly Investor Report will
also be included in the Distribution Report on Form 10-D filed with the Commission for the related
Collection Period.

(iii) The Sponsor, in its capacity as Servicer, will include in the Monthly Investor Report notice
of the occurrence of (i) any Benchmark Transition Event and its related Benchmark Replacement Date,
(ii) the determination of any Benchmark Replacement, and (iii) the making of any Benchmark
Replacement Conforming Changes.

(b) Credit Enhancement and Pool Composition Tests. On or before each Payment Date and each
Acquisition Date, the Servicer will determine whether the pool of Receivables to be held by the
Issuer as of the related Cutoff Date, including any Additional Receivables to be acquired, satisfies
the Credit Enhancement Test and each Pool Composition Test. If the pool of Receivables does not
satisfy all of the Pool Composition Tests, the Administrator may identify Receivables in the pool as
Temporarily Excluded Receivables so that the remaining Receivables in the pool will satisfy all of
the Pool Composition Tests; provided, that the Administrator may only deem Receivables to be
Temporarily Excluded Receivables if the Overcollateralization Target Amount is reached as of the
close of business on such date of determination, without taking into account the Temporarily
Excluded Receivables. In addition, the Principal Balance of any Temporarily Excluded Receivables
will be subtracted from the Adjusted Pool Balance for

11

Source: VERIZON ABS LLC, 8-K, 1/23/2020
<!-- page 16 -->
purposes of calculating the Credit Enhancement Test. The Servicer will state on the Acquisition Date
Supplement for each Collection Period for which there is an Acquisition Date the aggregate Principal
Balance of the Receivables deemed Temporarily Excluded Receivables. For the avoidance of doubt,
Collections on Temporarily Excluded Receivables (solely during the time that they are Temporarily
Excluded Receivables) will not constitute Available Funds and, up to the amount of the Temporarily
Excluded Receivables Servicing Fee will be distributed to the Servicer, and any remaining amounts
will be deposited into the Certificate Distribution Account for distribution to the
Certificateholders in the priority set forth in Section 4.1(b) of the Trust Agreement. The
Administrator may, at its sole option, designate Receivables that were deemed Temporarily Excluded
Receivables on any prior date to no longer be deemed Temporarily Excluded Receivables as long as
after such designation by the Administrator, all of the Pool Composition Tests either will remain
satisfied or will not be adversely affected.

(c) Amortization Events. In connection with the preparation of each Monthly Investor Report, the
Servicer will review the Amortization Events and determine whether an Amortization Event occurred
during the Collection Period immediately preceding the related Collection Period (after giving
effect to any acquisition of Additional Receivables during such Collection Period), and the Monthly
Investor Report shall indicate whether or not an Amortization Event has occurred.

(d) Remittance Reports. For as long as the Servicer and the Marketing Agent are depositing
Collections pursuant to Section 4.3(b)(ii) and depositing any required Upgrade Payments within two
(2) Business Days after the identification that all of the terms and conditions related to such
Upgrade Offer have been satisfied by the related Obligor, the Servicer will provide a written report
(which may be electronically submitted) to the Indenture Trustee and the Note Paying Agent on each
such deposit or remittance date setting forth (x) the aggregate dollar amount deposited or remitted
into the Collection Account by the Servicer, the Marketing Agent or an Originator on such date, (y)
the aggregate dollar amount of Collections deposited by the Servicer on such date and (z) the
aggregate number of Upgrade Offers accepted since the deposit or remittance date immediately
preceding the related deposit or remittance date, and the aggregate amount of Upgrade Payments
remitted by the Marketing Agent or an Originator on such date.

Section 3.6 Review of Servicer's Records. The Servicer will maintain records and documents relating
to its performance under this Agreement according to its customary business practices. Upon
reasonable request not more than once during any calendar year, and with reasonable notice, the
Servicer will give the Issuer, the Depositor, the Parent Support Provider, the Administrator, the
Owner Trustee and the Indenture Trustee (or their representatives) access to the records and
documents to conduct a review of the Servicer's performance under this Agreement. Any access or
review will be conducted by all parties at the same time at the Servicer's offices during its normal
business hours at a time reasonably convenient to the Servicer and in a manner that will minimize
disruption to its business operations. Any access or review will be subject to the Servicer's
security, confidentiality and privacy policies and any regulatory, legal and data protection
policies. Notwithstanding the foregoing, the permissive right of the Indenture Trustee to access or
review any records of the Servicer shall not be deemed to be an obligation of the Indenture Trustee
to do so.

12

Source: VERIZON ABS LLC, 8-K, 1/23/2020
<!-- page 17 -->
Section 3.7 Servicer's Authorized and Responsible Persons. On or before the Closing Date, the
Servicer will notify the Indenture Trustee and the Owner Trustee and provide a specimen signature of
each Person who (a) is authorized to give instructions and directions to the Indenture Trustee and
the Owner Trustee on behalf of the Servicer and (b) is a Responsible Person for the Servicer. The
Servicer may change such Persons at any time by notifying the Indenture Trustee and the Owner
Trustee.

Section 3.8 Servicer's Fees. As compensation for performing its obligations under this Agreement,
the Servicer will be paid the Servicing Fee. On each Payment Date, the Issuer will pay the Servicing
Fee to the Servicer according to Section 8.2 of the Indenture. In addition, the Servicer may retain
any Supplemental Servicing Fees. The Servicer will also receive the Temporarily Excluded Receivables
Servicing Fee on each Payment Date, which will be payable solely from Collections on the Temporarily
Excluded Receivables, as set forth in Section 3.5(b).

Section 3.9 Servicer's Expenses. Except as otherwise stated in this Agreement, the Servicer will pay
all its expenses for servicing the Receivables under this Agreement, including fees and expenses of
legal counsel and independent accountants, taxes imposed on the Servicer and expenses to prepare
reports, certificates or notices under this Agreement.

Section 3.10 Custodian.

(a) Appointment of Custodian. To reduce administrative costs and facilitate the servicing of the
Receivables by the Servicer, the Issuer appoints Cellco, in its capacity as the Servicer, to act as
the Custodian of the Receivables for the Issuer and the Indenture Trustee (for the benefit of the
Secured Parties), as their interests may appear. Cellco accepts the appointment and agrees to
perform the custodial obligations in this Section 3.10.

(b) Custody of Receivable Files. The Custodian will hold and maintain in custody the following
documents for each Receivable (the "Receivable File") for the benefit of the Issuer and the
Indenture Trustee, using reasonable care and according to the Servicing Procedures:

(i) the original Receivable (or an imaged copy of such Receivable) or an authoritative copy of the
Receivable, if in electronic form; and

(ii) all other documents, notices and correspondence relating to the Receivable or the Obligor that
the Servicer generates in the course of servicing the Receivable.

Except as stated above, any document in a Receivable File may be a photocopy or in electronic format
or may be converted to electronic format at any time. The Custodian will hold and maintain the
Receivable Files, including any receivables systems on which the Receivable Files are electronically
stored, in a manner that will permit the Servicer and the Issuer to comply with this Agreement and
the Indenture Trustee to comply with the Indenture.

(c) Delivery of Receivable Files. The Receivable Files are or will be constructively delivered to
the Indenture Trustee, as pledgee of the Issuer under the Indenture, and the Custodian confirms to
the Issuer and the Indenture Trustee that it has received the Receivable Files for the Initial
Receivables and, by its delivery (in its capacity as Servicer) to the Issuer and the Indenture
Trustee of an Acquisition Date Supplement, will be deemed to confirm to the

13

Source: VERIZON ABS LLC, 8-K, 1/23/2020
<!-- page 18 -->
Issuer and the Indenture Trustee that it has received the Receivable Files for the Additional
Receivables. No initial review or any periodic review of the Receivable Files by the Issuer, the
Owner Trustee or the Indenture Trustee is required.

(d) Location of Receivable Files. The Custodian will maintain the Receivable Files (or access to any
Receivable Files stored in an electronic format) at one of its offices or the offices of one of its
custodians in the United States. On request of the Depositor, the Issuer and the Indenture Trustee,
the Custodian will provide a list of locations of the Receivable Files.

(e) Access to Receivable Files. The Custodian will give the Servicer access to the Receivable Files
and, on request of the Servicer, the Custodian will promptly release any document in the Receivable
Files to the Servicer for purposes of servicing the Receivables. The Custodian will give the
Depositor, the Issuer and the Indenture Trustee access to the Receivable Files and the receivables
systems to conduct a review of the Receivables. Any access or review will be conducted at the
Custodian's offices during normal business hours at a time reasonably convenient to the Custodian in
a manner that will minimize disruption of its business operations. Any access or review will be
subject to the Custodian's legal, regulatory, confidentiality, privacy and data protection policies.
Attached hereto as Exhibit A is a copy of the Custodian's security requirements in effect on the
date of this Agreement.

(f) Effective Period and Termination. Cellco's appointment as custodian is effective as of the
Initial Cutoff Date and will continue until the later of (i) the date on which all obligations of
the Issuer have been paid in full and (ii) the date on which such appointment is terminated under
this Section 3.10(f). If the Servicer resigns under Section 7.1 or is terminated under Section 7.2,
the Servicer's appointment as custodian under this Agreement may be terminated in the same manner as
the Servicer may be terminated under Section 7.2. As soon as practicable after any termination of
its appointment as custodian and subject to the legal, regulatory, confidentiality, privacy and data
protection policies of the Custodian and Cellco, the Custodian will deliver the Receivable Files to
the Indenture Trustee or its designee or successor custodian at a place designated by the Indenture
Trustee. All reasonable expenses of transferring the Receivable Files to the designee or successor
custodian will be paid by the terminated custodian on receipt of an invoice in reasonable detail.

(g) No Agency. Neither the Custodian nor the Servicer shall be deemed to be an agent of the
Indenture Trustee, and the Indenture Trustee shall have no liability for the acts or omissions of
the Custodian or the Servicer.

Section 3.11 Marketing Agent.

(a) Appointment of Marketing Agent. The Issuer and the Servicer appoint Cellco to act as Marketing
Agent for the Receivables. Cellco accepts the appointment and agrees to perform its obligations set
forth in this Agreement.

(b) Duties of the Marketing Agent. The Marketing Agent will be required to remit, or to cause the
related Originator to remit, to the Collection Account the amounts set forth in Sections 4.3(g), (h)
and (i).

14

Source: VERIZON ABS LLC, 8-K, 1/23/2020
<!-- page 19 -->
(c) Fees and Expenses of the Marketing Agent. Fees and expenses, if any, of the Marketing Agent will
be paid by the Originators, as separately agreed to under the Marketing Agent Agency Agreement.

(d) Covenants of the Marketing Agent. The Marketing Agent will not (i) make any Upgrade Offers that
waive any obligations of an Obligor under the related device payment plan agreement, (ii) eliminate
the obligation of Verizon Wireless to pay off a device payment plan agreement if an Obligor
satisfies the related terms and conditions thereof, or (iii) eliminate or impair any third party
beneficiary rights of an assignee under an Upgrade Offer, including the right of such assignee to
enforce Verizon Wireless' payment obligation under any Upgrade Offer.

Section 3.12 Termination of Upgrade Programs; Credits Related to Upgrade Programs.

(a) To the extent any Upgrade Offer has not been terminated and an Obligor satisfies all of the
terms and conditions of such Upgrade Offer in respect of a Receivable, and (i) the Marketing Agent
fails to make, or to cause the related Originator to make, the required Upgrade Payment into the
Collection Account as set forth in Section 4.3(g) and (ii) the Parent Support Provider fails to make
any required Upgrade Payments as set forth in Section 1 of the Parent Support Agreement, the
Servicer and the Marketing Agent shall terminate all Upgrade Offers within ten (10) Business Days
after the date the Parent Support Provider received notice from the Indenture Trustee that an
Upgrade Payment was due under Section 1 of the Parent Support Agreement.

(b) If the Marketing Agent, the relevant Originator and the Parent Support Provider fail to make
such Upgrade Payments with respect to an Upgrade Offer, (i) the Servicer shall deliver the notice to
Obligors pursuant to Section 3.13 with respect to such Obligors' recoupment rights against Verizon
Wireless, and (ii) notwithstanding any failure to deliver such notice, (x) if Cellco is still the
Servicer, the Servicer shall give a monthly credit to the Obligor against amounts owing with respect
to the new device payment plan agreement resulting from the Upgrade Offer, in an amount equal to the
amount due that month under the original device payment plan agreement that is a Receivable, or (y)
if Cellco is no longer the Servicer, Cellco, (1) if required, shall give such monthly credit to the
Obligor only if Cellco has received notice from the Servicer that the Obligor has paid the amount
due in the prior month under the original device payment plan agreement that is a Receivable, and
(2) shall cooperate with any Successor Servicer to properly bill and credit such Obligor's account
with respect to the Receivable and the new device payment plan agreement related to the Upgrade
Offer. Any such monthly credit granted to an Obligor shall be applied directly against the monthly
payment due on the new device payment plan agreement and will not be applied in accordance with the
Servicer's customary payment application procedures pursuant to its Servicing Procedures, if
different. For the avoidance of doubt, if during such time as Cellco is no longer the Servicer, an
Obligor remits the full amount due under the related new device payment plan agreement, but does not
make a payment to the new Servicer for the original device payment plan agreement, a portion of such
amount equal to the amount of the monthly credit granted to such Obligor resulting from the Upgrade
Offer in respect of the original device payment plan agreement that is a Receivable shall be paid by
Cellco to the new Servicer. In such case, to the extent that all other amounts owed on the related
account are current, the Servicer will not consider such account or payments

15

Source: VERIZON ABS LLC, 8-K, 1/23/2020
<!-- page 20 -->
under the new device payment plan agreement to be Delinquent. In addition, regardless of whether
Cellco continues to be the Servicer of any Receivable for which the terms and conditions of an
Upgrade Offer (other than the requirement that the Marketing Agent remit, or cause the related
Originator to remit, an Upgrade Payment for such Receivable) were satisfied by the related Obligor
and for which the Marketing Agent, the related Originator and the Parent Support Provider failed to
make the related Upgrade Payment, Cellco shall remit any Collections received on such Receivable to
the Collection Account in the time period in which it would have been otherwise obligated to do so.

Section 3.13 Notices to Obligors.

Within ten (10) days following the earlier to occur of (i) a ratings downgrade by each of the Rating
Agencies of Verizon to below investment grade, or (ii) a Servicer Termination Event, the Servicer
will send a notice to all Obligors indicating (a) that their Receivables have been assigned to the
Issuer, and (b)(x) if Cellco has not been removed as Servicer, that the Obligors shall continue to
make their payments as they had previously, or (y) if Cellco has been removed as Servicer, the name
of the Successor Servicer and any new instructions with respect to their payments. In addition, if
the Servicer Termination Event was as a result of the failure of the Marketing Agent to satisfy its
obligation to make, or to cause the related Originators to make, required Upgrade Payments pursuant
to Section 7.2(a)(i)(y), then Cellco shall also send a notice to (i) all Obligors who have a
continuing right to an upgrade, indicating that Cellco has recently failed to make the necessary
prepayments with respect to one or more of its customers in connection with an Upgrade Offer, and
that if any Obligor chooses to upgrade and Cellco fails to make the related Upgrade Payment with
respect to them, such Obligor will still be required to make payments on his or her original device
payment plan agreement, but that such Obligor will have a corresponding recoupment right against his
or her new device payment plan agreement with Verizon Wireless, and (ii) all Obligors who had
initiated upgrades under an Upgrade Offer, indicating that Cellco had failed to make the relevant
Upgrade Payment, and stating that such Obligors will continue to have an obligation to make payments
on their original device payment plan agreements, but will have a corresponding right of recoupment
against their new device payment plan agreements with Verizon Wireless.

ARTICLE IV ACCOUNTS, COLLECTIONS AND APPLICATION OF FUNDS

Section 4.1 Bank Accounts.

(a) Establishment of Bank Accounts. On or before the Closing Date, the Servicer will establish the
following segregated accounts or subaccounts at a Qualified Institution (initially the corporate
trust department of U.S. Bank National Association), each in the name of "U.S. Bank National
Association, as Note Paying Agent for the benefit of the Indenture Trustee, as secured party for
Verizon Owner Trust 2020-A", to be designated as follows:

(i) "Collection Account" with account number 272062000;

(ii) "Reserve Account" with account number 272062001;

16

Source: VERIZON ABS LLC, 8-K, 1/23/2020
<!-- page 21 -->
(iii) "Acquisition Account," as a subaccount of the Collection Account, with account number
272062002; and

(iv) "Negative Carry Account" with account number 272062003.

(b) Control of Bank Accounts. Each of the Bank Accounts will be under the control of the Indenture
Trustee so long as the Bank Accounts remain subject to the Lien of the Indenture, except that the
Servicer may make deposits into and direct the Note Paying Agent to make deposits into or
withdrawals from the Bank Accounts according to the Transaction Documents. The Servicer may direct
the Note Paying Agent to withdraw from the Collection Account and pay to the Servicer, or as
directed by the Servicer, amounts that are not Available Funds for a Collection Period or that were
deposited into the Collection Account in error. Following the payment in full of the Notes and the
release of the Bank Accounts from the Lien of the Indenture, the Bank Accounts will be under the
control of the Issuer.

(c) Benefit of Accounts; Deposits and Withdrawals. The Bank Accounts and all cash, money,
securities, investments, financial assets and other property deposited in or credited to them will
be held by the Note Paying Agent for the benefit of the Indenture Trustee as secured party for the
benefit of the Secured Parties and, after payment in full of the Notes and the release of the Bank
Accounts from the Lien of the Indenture, as agent of the Issuer and as part of the Trust Property.
All deposits to and withdrawals from the Bank Accounts will be made according to the Transaction
Documents.

(d) Maintenance of Accounts. If an institution maintaining the Bank Accounts ceases to be a
Qualified Institution, the Servicer will, with the Indenture Trustee's assistance as necessary, move
the Bank Accounts to a Qualified Institution within thirty (30) days.

(e) Compliance. Each Bank Account will be subject to the Account Control Agreement. The Servicer
will ensure that the Account Control Agreement requires the Qualified Institution maintaining the
Bank Accounts to comply with "entitlement orders" (as defined in Section 8-102 of the UCC) from the
Indenture Trustee without further consent of the Issuer, if the Notes are Outstanding, and to act as
a "securities intermediary" according to the UCC.

(f) Agreements With Respect to Accounts. The Servicer, the Issuer, the Indenture Trustee and the
Securities Intermediary agree as follows:

(i) each of the Bank Accounts is, and will be maintained as, a "securities account" (as defined in
Section 8-501 of the UCC);

(ii) the Securities Intermediary is acting, and will act as a "securities intermediary" (as defined
in the UCC) with respect to the Bank Accounts;

(iii) this Agreement (together with the Indenture and the Account Control Agreement) is the only
agreement entered into among the parties with respect to the Bank Accounts and the parties will not
enter into any other agreement related to the Bank Accounts; and

17

Source: VERIZON ABS LLC, 8-K, 1/23/2020
<!-- page 22 -->
(iv) at the time this Agreement was entered into and the Bank Accounts were established, the
Securities Intermediary has one or more offices in the United States of America that maintains the
securities accounts.

Section 4.2 Investment of Funds in Bank Accounts.

(a) Permitted Investments. If (i) no Default or Event of Default has occurred and is continuing and
(ii) Cellco is the Servicer, the Servicer may instruct the Indenture Trustee to invest any funds in
the Collection Account, the Acquisition Account, the Reserve Account and the Negative Carry Account
in Permitted Investments and, if investment instructions are received, the Indenture Trustee will
direct the Qualified Institution maintaining the Bank Accounts to invest the funds in the Collection
Account, the Acquisition Account, the Reserve Account or the Negative Carry Account, as applicable,
in those Permitted Investments; provided, that, if on any Payment Date, the amount on deposit in the
Acquisition Account (after giving effect to the acquisition of any Additional Receivables on such
date) is greater than 25% of the aggregate Note Balance (after giving effect to any payments made on
the Notes on such date), the Servicer shall instruct the Indenture Trustee to invest any amounts in
the Acquisition Account in excess of such amount in any Permitted Investments, other than (x) any
investments set forth in clauses (b) or (c) of the definition of Permitted Investments that are held
by or at the Indenture Trustee or (y) any investments set forth in clause (e) of the definition
thereof. If (i) the Servicer fails to give investment instructions for any funds in the Collection
Account, the Acquisition Account, the Reserve Account or the Negative Carry Account to the Indenture
Trustee by 11:00 a.m. New York time (or other time as may be agreed by the Indenture Trustee) on the
Business Day before a Payment Date or (ii) the Qualified Institution receives notice from the
Indenture Trustee that a Default or Event of Default has occurred and is continuing, the Qualified
Institution will invest and reinvest funds in such Bank Account according to the last investment
instructions received, if any. If no prior investment instructions have been received or if the
instructed investments are no longer available or permitted, the Indenture Trustee will notify the
Servicer and request new investment instructions, and the funds will remain uninvested until new
investment instructions are received. The Servicer may direct the Indenture Trustee to consent,
vote, waive or take any other action, or not to take any action, on any matters available to the
holder of the Permitted Investments. If Cellco is not the Servicer, funds on deposit in the
Collection Account, the Acquisition Account, the Reserve Account and the Negative Carry Account will
remain uninvested. Notwithstanding anything to the contrary in this Section 4.2(a) or in the
Transaction Documents, the Servicer shall not allow amounts held in the Collection Account or the
Acquisition Account to be invested unless it is able to maintain records on a daily basis as to the
amounts realized from the investment of Collections received on each Originator's Receivables.

(b) Maturity of Investments. For so long as Cellco is the Servicer, any Permitted Investments of
funds in the Collection Account and the Reserve Account (or any reinvestments of the Permitted
Investments) for a Collection Period must mature, if applicable, and be available no later than the
second Business Day before the related Payment Date and any Permitted Investments of funds in the
Acquisition Account and the Negative Carry Account (or any reinvestments of the Permitted
Investments) for a Collection Period must mature or be available overnight. Any Permitted
Investments with a maturity date will be held to their maturity, except

18

Source: VERIZON ABS LLC, 8-K, 1/23/2020
<!-- page 23 -->
that such Permitted Investments may be sold or disposed of before their maturity in connection with
the sale or liquidation of the Collateral under Section 5.6 of the Indenture.

(c) No Liability for Investments. None of the Depositor, the Servicer, the Indenture Trustee, the
Note Paying Agent or the Qualified Institution maintaining any Bank Account will be liable for the
selection of Permitted Investments or for investment losses incurred on Permitted Investments (other
than in the capacity as obligor, if applicable).

(d) Continuation of Liens in Investments. The Servicer will not direct the Indenture Trustee or the
Note Paying Agent to make any investment of funds or to sell any investment held in the Bank
Accounts unless the security interest Granted and perfected in the account in favor of the Indenture
Trustee will continue to be perfected in the investment or the proceeds of the sale without further
action by any Person.

(e) Investment Earnings. Investment earnings (net of losses and investment expenses) on the
Collection Account, the Acquisition Account, the Reserve Account and the Negative Carry Account will
be deposited into the Certificate Distribution Account for distribution to the Certificateholders in
the priority set forth in Section 4.1(b) of the Trust Agreement.

Section 4.3 Deposits and Payments.

(a) Closing Date and Acquisition Date Deposit. On the Closing Date and on each Acquisition Date, the
Servicer will deposit into the Collection Account all amounts received and applied as interest or
principal on the Initial Receivables or the Additional Receivables, as applicable, during the period
from the related Cutoff Date to two (2) Business Days before the Closing Date or Acquisition Date,
as applicable.

(b) Deposit of Collections.

(i) If Cellco is the Servicer and (x) Verizon's long-term unsecured debt is rated equal to or higher
than "Baa2" by Moody's and "A" by S&P (the "Monthly Deposit Required Ratings"), (y) Verizon
guarantees certain payment obligations of Cellco, as Servicer, as provided in the Parent Support
Agreement and (z) no Servicer Termination Event has occurred, the Servicer may deposit Collections
into the Collection Account on the second Business Day before each Payment Date.

(ii) For as long as (x) Verizon's long-term unsecured debt is not rated at least the Monthly Deposit
Required Ratings, (y) Verizon does not guaranty certain payment obligations of Cellco, as Servicer
or (z) a Servicer Termination Event occurs, the Servicer will (1) deposit into the Collection
Account all amounts received and applied as interest or principal on the Receivables within two (2)
Business Days after identification of receipt of good funds and (2) provide a written report (which
may be electronically submitted) to the Indenture Trustee and the Note Paying Agent regarding such
deposit set forth in clause (1) above, as required by Section 3.5(d).

(c) Reconciliation of Deposits. If Cellco is the Servicer and for any Payment Date, the sum of (i)
Collections for the Collection Period, plus (ii) Acquisition Amounts for the

19

Source: VERIZON ABS LLC, 8-K, 1/23/2020
<!-- page 24 -->
Payment Date, exceeds the amounts deposited under Section 4.3(b) for the Collection Period, Cellco
will deposit an amount equal to the excess into the Collection Account on the second Business Day
before the Payment Date. If, for any Payment Date, the amounts deposited under Section 4.3(b) for
the Collection Period exceed the sum of (i) Collections for the Collection Period, plus (ii)
Acquisition Amounts for the Payment Date, the Indenture Trustee or the Note Paying Agent will pay to
Cellco from Available Funds in the Collection Account an amount equal to the excess within two (2)
Business Days after Cellco's direction, but no later than the Payment Date. If requested by the
Indenture Trustee, Cellco will provide reasonable supporting details for its calculation of the
amounts to be deposited or paid under this Section 4.3(c).

(d) Net Deposits. Cellco may make the deposits and payments required by Section 4.3(b) net of
Servicing Fees to be paid to Cellco for the Collection Period and amounts the Servicer is permitted
to retain under Section 3.8 and be reimbursed for under Section 3.9. The Servicer will account for
all deposits and payments in the Monthly Investor Report as if the amounts were deposited and/or
paid separately.

(e) No Segregation. Pending deposit in the Collection Account, the Servicer is not required to
segregate Collections from its own funds.

(f) Negative Carry Account Deposits. Any Certificateholder may, at its option, deposit funds into
the Negative Carry Account on any date.

(g) Deposit of Upgrade Payments. If any Upgrade Offer has not been terminated and an Obligor
satisfies all of the terms and conditions of such Upgrade Offer in respect of a Receivable, the
Marketing Agent shall deposit, or shall cause the related Originator to deposit, into the Collection
Account the related Upgrade Payment, within two (2) Business Days after the identification that all
of the terms and conditions related to such Upgrade Offer have been satisfied by the related Obligor
in respect of a Receivable; provided, that if the conditions set forth in Section 4.3(b) (i) are
satisfied, the Marketing Agent shall deposit, or shall cause the related Originators to deposit,
such amounts into the Collection Account on the second Business Day before the Payment Date related
to the Collection Period in which the related Obligor has satisfied all of the terms and conditions
(for the avoidance of doubt, other than the required prepayment) related to such Upgrade Offer in
respect of a Receivable. The parties acknowledge that the failure of the Marketing Agent to deposit,
or to cause the related Originator to deposit, into the Collection Account the related Upgrade
Payment or otherwise to pay off the Receivable would constitute a breach by the related Originator
of its obligation to the Obligor under the Upgrade Contract and that this breach would adversely
affect the value of the Receivables, and give the Obligor a claim in recoupment against the related
Originator and a right to offset that claim against the amounts that the Obligor would owe to the
related Originator under the new device payment plan agreement (each such agreement, a "New Upgrade
DPP") entered into by the related Originator (or its agent, on its behalf) pursuant to the Upgrade
Contract. The parties hereto intend that the payment by the Marketing Agent or the related
Originator of the Upgrade Payment as provided in this Section 4.3(g) shall extinguish such Obligor's
claim in recoupment against the related Originator and the Obligor's right to offset the amount of
that claim against the amounts that the Obligor would owe under the New Upgrade DPP
contemporaneously with such Upgrade Payment by the Marketing Agent or the related Originator. The
parties hereto also intend that the payment by the Marketing Agent or the related Originator of the
Upgrade

20

Source: VERIZON ABS LLC, 8-K, 1/23/2020
<!-- page 25 -->
Payment as provided in Section 2.2.1 of the Marketing Agent Agency Agreement shall extinguish each
Obligor's claim in recoupment against the "Verizon Originator" described in that Section and the
Obligor's right to offset the amount of that claim against the amounts that the Obligor would owe
under the new device payment plan agreement entered into by such Verizon Originator (or its agent,
on its behalf) pursuant to the Upgrade Contract as described in that Section 2.2.1 contemporaneously
with such Upgrade Payment by the Marketing Agent or the related Originator.

(h) Deposit of Credit Payments. If an Obligor is granted a Credit and the application of such Credit
to the related Obligor's account results in a shortfall in Collections for the related Collection
Period, the Marketing Agent shall deposit, or shall cause the related Originator to deposit, into
the Collection Account the related Credit Payment within two (2) Business Days after identification
that such Credit was applied to an Obligor account; provided, that if the conditions set forth in
Section 4.3(b)(i) are satisfied, the Marketing Agent shall deposit, or shall cause the related
Originator to deposit, such amounts into the Collection Account on the second Business Day before
the Payment Date related to the Collection Period in which such Credit was applied to an Obligor
account.

(i) Deposit of Assumption of Liability Payments. If an Originator or the Servicer allows a device
payment plan agreement that is a Receivable to be transferred to a new Obligor, the Marketing Agent
shall acquire such Receivable and deposit, or cause the related Originator to acquire and deposit,
into the Collection Account an amount equal to the applicable Acquisition Amount for the related
Receivable on or prior to the second Business Day before the Payment Date related to the Collection
Period in which such transfer occurred.

Section 4.4 Reserve Account; Negative Carry Account; Acquisition Account.

(a) Initial Reserve Account Deposit. On the Closing Date, the Depositor will deposit or cause to be
deposited the Required Reserve Amount into the Reserve Account from the net proceeds of the sale of
the Notes.

(b) Reserve Account Draw Amount. On or before two (2) Business Days before a Payment Date, the
Servicer will calculate the Reserve Account Draw Amount for the Payment Date and will direct the
Note Paying Agent to withdraw from the Reserve Account and deposit into the Collection Account on or
before the Payment Date (x) the Reserve Account Draw Amount and (y) any amount in excess of the
Required Reserve Amount for such Payment Date, after giving effect to the withdrawal of the Reserve
Account Draw Amount with respect to such Payment Date.

(c) Negative Carry Account Amounts.

(i) To the extent that the Class A Certificateholder, solely at its option, deposits any amounts
into the Acquisition Account, pursuant to Section 4.4(d)(i), the Class A Certificateholder will
deposit into the Negative Carry Account an amount equal to the Required Negative Carry Amount
related to such amount deposited into the Acquisition Account on such date.

21

Source: VERIZON ABS LLC, 8-K, 1/23/2020
<!-- page 26 -->
(ii) On or before two (2) Business Days before a Payment Date, the Servicer will calculate the
Negative Carry Account Draw Amount for the Payment Date and will instruct the Note Paying Agent to
withdraw from the Negative Carry Account and deposit the Negative Carry Account Draw Amount into the
Collection Account on or before the Payment Date.

(iii) On each Payment Date, any amounts in the Negative Carry Account in excess of the Required
Negative Carry Amount, after giving effect to any acquisition of Receivables on such Payment Date,
shall be withdrawn from the Negative Carry Account and deposited into the Certificate Distribution
Account, for distribution to the Certificateholders in the priority set forth in Section 4.1(b) of
the Trust Agreement.

(iv) On or before the first Payment Date during the Amortization Period, the Servicer will direct
the Note Paying Agent to withdraw all funds in the Negative Carry Account and deposit the funds into
the Collection Account.

(d) Acquisition Account Amounts.

(i) From time to time, the Class A Certificateholder may, solely at its option, deposit amounts into
the Acquisition Account, as set forth in Section 2.5 of the Trust Agreement.

(ii) On or before two (2) Business Days before an Acquisition Date, the Issuer, or the Servicer on
its behalf, will direct the Note Paying Agent to withdraw the Additional Receivables Cash Transfer
Amount from the Acquisition Account and pay that amount to the Depositor on the Acquisition Date in
consideration for the acquisition of Additional Receivables by the Issuer on the Acquisition Date.

(iii) On each Payment Date, any amounts in the Acquisition Account in excess of the Required
Acquisition Deposit Amount, after giving effect to any acquisition of Receivables on such Payment
Date, shall be withdrawn from the Acquisition Account and deposited into the Certificate
Distribution Account, for distribution to the Certificateholders in the priority set forth in
Section 4.1(b) of the Trust Agreement.

(iv) On or before the first Payment Date during the Amortization Period, the Servicer will direct
the Note Paying Agent to withdraw all funds in the Acquisition Account and deposit the funds into
the Collection Account.

(e) Release of Funds. The Indenture Trustee shall, at such time as there are no Notes outstanding,
release any remaining portion of the Collection Account from the Lien of the Indenture and release
to or to the order of the Issuer or, in the case of the Reserve Account, to the Depositor.

Section 4.5 Direction to Indenture Trustee for Distributions. On or about the 15th day of each
month, and in no case later than at least two (2) Business Days before each Payment Date, the
Servicer will direct the Indenture Trustee or Note Paying Agent (based on the most recent Monthly
Investor Report) to make the withdrawals, deposits, distributions and payments

22

Source: VERIZON ABS LLC, 8-K, 1/23/2020
<!-- page 27 -->
required to be made on the Payment Date under Section 8.2 of the Indenture and Section 4.3(c) of
this Agreement.

ARTICLE V DEPOSITOR

Section 5.1 Depositor's Representations and Warranties. The Depositor represents and warrants to the
Issuer as of the Closing Date and as of each Acquisition Date, on which representations and
warranties the Issuer is relying in purchasing the Depositor Transferred Property and which will
survive the transfer and assignment of the Depositor Transferred Property by the Depositor to the
Issuer under this Agreement and the pledge of the Depositor Transferred Property by the Issuer to
the Indenture Trustee under the Indenture:

(a) Organization and Good Standing. The Depositor is a validly existing limited liability company in
good standing under the laws of the State of Delaware and has full power and authority to own its
properties and conduct its business as presently owned or conducted, and to execute, deliver and
perform its obligations under this Agreement and each other Transaction Document to which it is a
party.

(b) Due Qualification. The Depositor is duly qualified to do business, is in good standing as a
foreign limited liability company (or is exempt from such requirements) and has obtained all
necessary licenses and approvals in each jurisdiction in which the conduct of its business requires
such qualification, licenses or approvals, except where the failure to so qualify or obtain licenses
or approvals would not reasonably be expected to have a Material Adverse Effect.

(c) Due Authorization. The execution, delivery, and performance of this Agreement and each other
Transaction Document to which it is a party, have been duly authorized by the Depositor by all
necessary limited liability company action on the part of the Depositor.

(d) No Proceedings. There are no actions, suits, investigations or other proceedings pending, or to
its knowledge threatened, against the Depositor or any of its properties: (i) asserting the
invalidity of this Agreement or any other Transaction Document to which it is a party; (ii) seeking
to prevent the consummation of any of the transactions contemplated by this Agreement or any other
Transaction Document to which it is a party; or (iii) seeking any determination or ruling that might
have a Material Adverse Effect on the performance by the Depositor of its obligations under, or the
validity or enforceability of, this Agreement or any other Transaction Document to which it is a
party.

(e) All Consents. All authorizations, consents, orders or approvals of or registrations or
declarations with any Governmental Authority required to be obtained, effected or given to it, if
any, in connection with the execution and delivery of this Agreement and each other Transaction
Document to which it is a party and the performance of the transactions contemplated by this
Agreement or any other Transaction Document by the Depositor, in each case, have been duly obtained,
effected or given and are in full force and effect, except for those which the failure to obtain
would not reasonably be expected to have a Material Adverse Effect.

23

Source: VERIZON ABS LLC, 8-K, 1/23/2020
<!-- page 28 -->
(f) Binding Obligation. This Agreement and each other Transaction Document to which it is a party
constitutes, when duly executed and delivered by each other party hereto and thereto, a legal, valid
and binding obligation of the Depositor, enforceable against it in accordance with its terms, except
as such enforceability may be limited by applicable bankruptcy, insolvency, reorganization,
moratorium, receivership, conservatorship or other similar Laws affecting creditors' rights
generally or by general principles of equity.

(g) No Conflict. The execution and delivery of this Agreement or any other Transaction Document to
which it is a party by the Depositor, and the performance by it of the transactions contemplated by
the Transaction Documents and the fulfillment of the terms hereof and thereof applicable to the
Depositor, (i) do not contravene (A) its limited liability company agreement, (B) any contractual
restriction binding on or affecting it or its property, or (C) any order, writ, judgment, award,
injunction or decree binding on or affecting it or its property, except, in each case of (A), (B) or
(C), where such contravention would not reasonably be expected to have a Material Adverse Effect and
(ii) do not result in or require the creation of any Adverse Claim upon or with respect to any of
its properties.

(h) No Violation. The execution and delivery of this Agreement by the Depositor, the performance by
the Depositor of the transactions contemplated by this Agreement or any other Transaction Document
to which it is a party and the fulfillment of the terms hereof and thereof applicable to the
Depositor will not violate any Law applicable to the Depositor, except where such violation would
not reasonably be expected to have a Material Adverse Effect.

Section 5.2 Liability of Depositor.

(a) Liability for Specific Obligations. The Depositor will be liable under this Agreement only for
its specific obligations under this Agreement. All other liability is expressly waived and released
as a condition of, and consideration for, the execution of this Agreement by the Depositor and the
issuance of the Notes. The Depositor will be liable for its willful misconduct, bad faith or gross
negligence in performing its obligations under this Agreement.

(b) No Liability of Others. The Depositor's obligations under this Agreement are corporate
obligations. No Person will have recourse, directly or indirectly, to any member, manager, officer,
director, employee or agent of the Depositor for the Depositor's obligations under this Agreement.

(c) Legal Proceedings. The Depositor will not be required to start, pursue or participate in any
legal proceeding that is unrelated to its obligations under this Agreement and that, in its opinion,
may result in liability or cause it to pay or risk funds or incur financial liability.

(d) Payment of Taxes. The Depositor will pay all taxes levied or assessed on the Trust Property.

(e) Reliance by Depositor. The Depositor may rely in good faith on the advice of counsel or on any
document believed to be genuine and to have been executed by the proper party for any matters under
this Agreement.

24

Source: VERIZON ABS LLC, 8-K, 1/23/2020
<!-- page 29 -->
Section 5.3 Merger, Consolidation, Succession or Assignment. Any Person (a) into which the Depositor
is merged or consolidated, (b) resulting from a merger or consolidation to which the Depositor is a
party, (c) succeeding to the Depositor's business or (d) that is an Affiliate of the Depositor to
whom the Depositor has assigned this Agreement, will be the successor to the Depositor under this
Agreement. Within fifteen (15) Business Days after the merger, consolidation, succession or
assignment, such Person will (i) execute an agreement to assume the Depositor's obligations under
this Agreement and each Transaction Document to which the Depositor is a party (unless the
assumption happens by operation of Law), (ii) deliver to the Issuer, the Owner Trustee and the
Indenture Trustee an Officer's Certificate and an Opinion of Counsel each stating that the merger,
consolidation, succession or assignment and the assumption agreement comply with this Section 5.3,
(iii) deliver to the Issuer, the Owner Trustee and the Indenture Trustee an Opinion of Counsel
stating that the security interest in favor of the Issuer in the Depositor Transferred Property and
the Indenture Trustee in the Collateral is or will be perfected and (iv) notify the Rating Agencies
of the merger, consolidation, succession or assignment.

Section 5.4 Depositor May Own Notes. The Depositor and any Affiliate of the Depositor, in its
individual or any other capacity, may become the owner or pledgee of Notes with the same rights as
any other Person except as limited in any Transaction Document. Notes owned by or pledged to the
Depositor or any Affiliate of the Depositor will have an equal and proportionate benefit under the
Transaction Documents, except as limited in any Transaction Document.

Section 5.5 Depositor's Authorized and Responsible Persons. On or before the Closing Date, the
Depositor will notify the Indenture Trustee and the Owner Trustee and provide specimen signatures of
(i) each Person who is authorized to give instructions and directions to the Indenture Trustee and
the Owner Trustee on behalf of the Depositor and (ii) each Person who is a Responsible Person for
the Depositor. The Depositor may change such Persons at any time by notifying the Indenture Trustee
and the Owner Trustee in writing.

Section 5.6 Company Existence. During the term of this Agreement, the Depositor shall keep in full
force and effect its existence, rights and franchises as a limited liability company under the Laws
of the jurisdiction of its formation and shall obtain and preserve its qualification to do business
in each jurisdiction in which such qualification is or shall be necessary to protect the validity
and enforceability of the Transaction Documents and each other instrument or agreement necessary or
appropriate to the proper administration of this Agreement and the transactions contemplated hereby.

Section 5.7 No Division. Notwithstanding Section 18- 217 of the Delaware Limited Liability Company
Act or the Depositor's limited liability company agreement, for so long as the Notes remain
Outstanding, the Depositor shall not divide or enter into a plan of division within the meaning of
Section 18- 217 of the Delaware Limited Liability Company Act.

ARTICLE VI SERVICER AND MARKETING AGENT

Section 6.1 Servicer's and Marketing Agent's Representations and Warranties.

25

Source: VERIZON ABS LLC, 8-K, 1/23/2020
<!-- page 30 -->
(a) The Servicer represents and warrants to the Issuer as of the Closing Date and as of each
Acquisition Date, on which representations and warranties the Issuer is relying in purchasing the
Depositor Transferred Property and which will survive the transfer and assignment of the Depositor
Transferred Property by the Depositor to the Issuer under this Agreement and the pledge of the
Depositor Transferred Property by the Issuer to the Indenture Trustee under the Indenture:

(i) Organization and Good Standing. The Servicer is a validly existing partnership in good standing
under the laws of the State of Delaware and has full power and authority to own its properties and
conduct its servicing business as presently owned or conducted, and to execute, deliver and perform
its obligations under this Agreement and each other Transaction Document to which it is a party.

(ii) Due Qualification. The Servicer is duly qualified to do business, is in good standing as a
foreign entity (or is exempt from such requirements) and has obtained all necessary licenses and
approvals in each jurisdiction in which the servicing of the Receivables requires such
qualification, licenses or approvals, except where the failure to so qualify or obtain licenses or
approvals would not reasonably be expected to have a Material Adverse Effect.

(iii) Due Authorization. The execution, delivery, and performance of this Agreement and each other
Transaction Document to which it is a party, have been duly authorized by the Servicer by all
necessary partnership action on the part of the Servicer.

(iv) No Proceedings. There are no actions, suits, investigations or other proceedings pending, or to
its knowledge threatened, against the Servicer or any of its properties: (i) asserting the
invalidity of this Agreement or any other Transaction Document to which it is a party; (ii) seeking
to prevent the consummation of any of the transactions contemplated by this Agreement or any other
Transaction Document to which it is a party; or (iii) seeking any determination or ruling that might
have a Material Adverse Effect on the performance by the Servicer of its obligations under, or the
validity or enforceability of, this Agreement or any other Transaction Document to which it is a
party.

(v) All Consents. All authorizations, consents, orders or approvals of or registrations or
declarations with any Governmental Authority required to be obtained, effected or given to it, if
any, in connection with the execution and delivery of this Agreement and each other Transaction
Document to which it is a party and the performance of the transactions contemplated by this
Agreement or any other Transaction Document by the Servicer, in each case, have been duly obtained,
effected or given and are in full force and effect, except for those which the failure to obtain
would not reasonably be expected to have a Material Adverse Effect.

(vi) Binding Obligation. This Agreement and each other Transaction Document to which it is a party
constitutes, when duly executed and delivered by each other party hereto and thereto, a legal, valid
and binding obligation of the Servicer, enforceable against it in accordance with its terms, except
as such enforceability may be

26

Source: VERIZON ABS LLC, 8-K, 1/23/2020

limited by applicable bankruptcy, insolvency, reorganization, moratorium, receivership,
conservatorship or other similar Laws affecting creditors' rights generally or by general principles
of equity.
<!-- page 31 -->
(vii) No Conflict. The execution and delivery of this Agreement or any other Transaction Document to
which it is a party by the Servicer, and the performance by it of the transactions contemplated by
the Transaction Documents and the fulfillment of the terms hereof and thereof applicable to the
Servicer, (i) do not contravene (A) the organizational documents of the Servicer, (B) any
contractual restriction binding on or affecting it or its property, or (C) any order, writ,
judgment, award, injunction or decree binding on or affecting it or its property, except, in each
case of (A), (B) or (C), where such contravention would not reasonably be expected to have a
Material Adverse Effect and (ii) do not result in or require the creation of any Adverse Claim upon
or with respect to any of its properties.

(viii) No Violation. The execution and delivery of this Agreement by the Servicer, the performance
by the Servicer of the transactions contemplated by this Agreement or any other Transaction Document
to which it is a party and the fulfillment of the terms hereof and thereof applicable to the
Servicer will not violate any Law applicable to the Servicer, except where such violation would not
reasonably be expected to have a Material Adverse Effect.

(ix) Compliance with Law. It has complied with all Laws applicable to the servicing of the
Receivables, except where the failure to do so, individually or in the aggregate, would not
reasonably be expected to have a Material Adverse Effect.

(x) Servicing Procedures. It has complied in all material respects with the Servicing Procedures
with respect to the Receivables.

(b) The Marketing Agent represents and warrants to the Issuer as of the Closing Date and as of each
Acquisition Date, on which representations and warranties the Issuer is relying in purchasing the
Depositor Transferred Property and which will survive the transfer and assignment of the Depositor
Transferred Property by the Depositor to the Issuer under this Agreement and the pledge of the
Depositor Transferred Property by the Issuer to the Indenture Trustee under the Indenture:

(i) Organization and Good Standing. The Marketing Agent is a validly existing partnership in good
standing under the laws of the State of Delaware and has full power and authority to own its
properties and conduct its business as presently owned or conducted, and to execute, deliver and
perform its obligations under this Agreement and each other Transaction Document to which it is a
party.

(ii) Due Qualification. The Marketing Agent is duly qualified to do business, is in good standing as
a foreign entity (or is exempt from such requirements) and has obtained all necessary licenses and
approvals in each jurisdiction in which the conduct of its business requires such qualification,
licenses or approvals, except where the failure to

27

Source: VERIZON ABS LLC, 8-K, 1/23/2020

so qualify or obtain licenses or approvals would not reasonably be expected to have a Material
Adverse Effect.
<!-- page 32 -->
(iii) Due Authorization. The execution, delivery, and performance of this Agreement and each other
Transaction Document to which it is a party, have been duly authorized by the Marketing Agent by all
necessary partnership action on the part of the Marketing Agent.

(iv) No Proceedings. There are no actions, suits, investigations or other proceedings pending, or to
its knowledge threatened, against the Marketing Agent or any of its properties: (i) asserting the
invalidity of this Agreement or any other Transaction Document to which it is a party; (ii) seeking
to prevent the consummation of any of the transactions contemplated by this Agreement or any other
Transaction Document to which it is a party; or (iii) seeking any determination or ruling that might
have a Material Adverse Effect on the performance by the Marketing Agent of its obligations under,
or the validity or enforceability of, this Agreement or any other Transaction Document to which it
is a party.

(v) All Consents. All authorizations, consents, orders or approvals of or registrations or
declarations with any Governmental Authority required to be obtained, effected or given to it, if
any, in connection with the execution and delivery of this Agreement and each other Transaction
Document to which it is a party and the performance of the transactions contemplated by this
Agreement or any other Transaction Document by the Marketing Agent, in each case, have been duly
obtained, effected or given and are in full force and effect, except for those which the failure to
obtain would not reasonably be expected to have a Material Adverse Effect.

(vi) Binding Obligation. This Agreement and each other Transaction Document to which it is a party
constitutes, when duly executed and delivered by each other party hereto and thereto, a legal, valid
and binding obligation of the Marketing Agent, enforceable against it in accordance with its terms,
except as such enforceability may be limited by applicable bankruptcy, insolvency, reorganization,
moratorium, receivership, conservatorship or other similar Laws affecting creditors' rights
generally or by general principles of equity.

(vii) No Conflict. The execution and delivery of this Agreement or any other Transaction Document to
which it is a party by the Marketing Agent, and the performance by it of the transactions
contemplated by the Transaction Documents and the fulfillment of the terms hereof and thereof
applicable to the Marketing Agent, (i) do not contravene (A) the organizational documents of the
Marketing Agent, (B) any contractual restriction binding on or affecting it or its property, or (C)
any order, writ, judgment, award, injunction or decree binding on or affecting it or its property,
except, in each case of (A), (B) or (C), where such contravention would not reasonably be expected
to have a Material Adverse Effect and (ii) do not result in or require the creation of any Adverse
Claim upon or with respect to any of its properties.

28

Source: VERIZON ABS LLC, 8-K, 1/23/2020
<!-- page 33 -->
(viii) No Violation. The execution and delivery of this Agreement by the Marketing Agent, the
performance by the Marketing Agent of the transactions contemplated by this Agreement or any other
Transaction Document to which it is a party and the fulfillment of the terms hereof and thereof
applicable to the Marketing Agent will not violate any Law applicable to the Marketing Agent, except
where such violation would not reasonably be expected to have a Material Adverse Effect.

Section 6.2 Liability of Servicer and Marketing Agent.

(a) Liability for Specific Obligations. Each of the Servicer and the Marketing Agent, severally and
not jointly, will be liable under this Agreement only for its specific obligations under this
Agreement. All other liability is expressly waived and released as a condition of, and consideration
for, the execution of this Agreement by the Servicer or the Marketing Agent, as applicable. Each of
the Servicer and the Marketing Agent, severally and not jointly, will be liable only for its own
willful misconduct, bad faith or gross negligence in performing its obligations under this
Agreement.

(b) No Liability of Others. Each of the Servicer's and the Marketing Agent's obligations under this
Agreement are corporate obligations. No Person will have recourse, directly or indirectly, to any
member, manager, officer, director, employee or agent of the Servicer for the Servicer's obligations
or the Marketing Agent for the Marketing Agent's obligations, as applicable, under this Agreement.

(c) Legal Proceedings. The Servicer will not be required to start, pursue or participate in any
legal proceeding that is not incidental or related to its obligations to service the Receivables
under this Agreement and that in its opinion may result in liability or cause it to pay or risk
funds or incur financial liability. The Servicer may in its sole discretion start or pursue any
legal proceeding to protect the interests of the Noteholders or the Depositor under the Transaction
Documents. The Servicer will be responsible for the fees and expenses of legal counsel and any
liability resulting from the legal proceeding.

(d) Force Majeure. Neither the Servicer nor the Marketing Agent will be responsible or liable for
any failure or delay in performing its obligations under this Agreement caused by, directly or
indirectly, forces beyond its control, including strikes, work stoppages, acts of war, terrorism,
civil or military disturbances, fire, flood, earthquakes, storms, hurricanes or other natural
disasters or failures of mechanical, electronic or communication systems; provided, however that
this provision shall not limit the right to remove the Servicer for a Servicer Termination Event as
provided in Section 7.2(a), other than with respect to the extension of the grace periods as
provided in Section 7.2(a). Each of the Servicer and the Marketing Agent, as applicable, will use
commercially reasonable efforts to resume performance as soon as practicable in the circumstances.

(e) Reliance by Servicer and Marketing Agent. Each of the Servicer and the Marketing Agent may rely
in good faith on the advice of counsel or on any document believed to be genuine and to have been
executed by the proper party for any matters under this Agreement.

Section 6.3 Indemnities of Servicer and the Marketing Agent.

29

Source: VERIZON ABS LLC, 8-K, 1/23/2020
<!-- page 34 -->
(a) Indemnification.

(i) The Servicer will indemnify the Issuer, the Owner Trustee and the Indenture Trustee (including
in its capacity as Note Paying Agent), and their officers, directors, employees and agents (each, an
"Indemnified Person") for all fees, expenses, losses, claims, actions, suits, damages and
liabilities (including reasonable legal fees and expenses) resulting from the Servicer's (including
in its capacity as Custodian) willful misconduct, bad faith or gross negligence in performing its
obligations under the Transaction Documents (including such amounts incurred by such parties in
defending themselves against any loss, damage or liability and any fees and expenses incurred in
connection with any proceedings brought by the Indemnified Person to enforce the Servicer's
indemnification or other obligations under this Agreement).

(ii) The Marketing Agent will indemnify the Indemnified Persons for all fees, expenses, losses,
claims, actions, suits, damages and liabilities (including reasonable legal fees and expenses)
resulting from the Marketing Agent's willful misconduct, bad faith or gross negligence in performing
its obligations under the Transaction Documents (including such amounts incurred by such parties in
defending themselves against any loss, damage or liability and any fees and expenses incurred in
connection with any proceedings brought by the Indemnified Person to enforce the Marketing Agent's
indemnification or other obligations under this Agreement).

(b) Proceedings. If an Indemnified Person receives notice of a Proceeding against it, the
Indemnified Person will, if a claim for indemnity will be made against the Servicer or the Marketing
Agent, as applicable, under this Section 6.3, promptly notify the Servicer or the Marketing Agent,
as applicable, of the Proceeding; provided, that the failure to give such notice shall not affect
the right of an Indemnified Person to indemnification hereunder to the extent that such failure does
not prejudice the rights of the Servicer, the Marketing Agent or the Indemnified Person in such
Proceeding. The Servicer or the Marketing Agent, as applicable, may participate in and assume the
defense and settlement of a Proceeding at its expense. If the Servicer or the Marketing Agent, as
applicable, notifies the Indemnified Person of its intention to assume the defense of the
Proceeding, the Servicer or the Marketing Agent, as applicable, will assume such defense with
counsel reasonably satisfactory to the Indemnified Person, and in a manner reasonably satisfactory
to the Indemnified Person, and the Servicer or the Marketing Agent, as applicable, and will not be
liable for fees and expenses of separate counsel to the Indemnified Person unless there is a
conflict between the interests of the Servicer or the Marketing Agent, as applicable, and the
Indemnified Person. If there is a conflict or if the parties cannot reasonably agree as to the
selection of counsel, the Servicer or the Marketing Agent, as applicable, will pay the reasonable
fees and expenses of separate counsel to the Indemnified Person. No settlement of the Proceeding in
which a claim is brought against the Servicer or the Marketing Agent may be settled in the name of,
on behalf of, or in any manner in which the Servicer or the Marketing Agent, as applicable, is
understood to acknowledge the validity of any claim without the approval of the Servicer or the
Marketing Agent, respectively, and the Indemnified Person, which approvals will not be unreasonably
withheld.

(c) Survival of Obligations. Each of the Servicer's and the Marketing Agent's obligations under this
Section 6.3, for the period it was the Servicer or the Marketing Agent,

30

Source: VERIZON ABS LLC, 8-K, 1/23/2020
<!-- page 35 -->
respectively, will survive the Servicer's or the Marketing Agent's, as applicable, resignation or
termination, the termination of this Agreement, the resignation or removal of the Owner Trustee or
the Indenture Trustee and the termination of the Issuer.

(d) Repayment. If the Servicer or the Marketing Agent makes a payment to an Indemnified Person under
this Section 6.3 and the Indemnified Person later collects from others any amounts for which the
payment was made, the Indemnified Person will promptly repay those amounts to the Servicer or the
Marketing Agent, as applicable.

Section 6.4 Delegation and Contracting. If Cellco is not the Servicer or the Custodian, the Servicer
or the Custodian, as applicable, may not delegate to any Person its obligations under this Agreement
without the consent of the Issuer. However, no notice or consent will be required for any delegation
if Cellco is the Servicer or the Custodian. No notice or consent will be required for any delegation
by the Marketing Agent of its obligations under this Agreement. Any of the Servicer, the Custodian
or the Marketing Agent may contract with other Persons to perform its obligations under this
Agreement. No delegation or contracting will relieve the Servicer, the Custodian or the Marketing
Agent, as applicable, of its responsibilities, and the Servicer, the Custodian or the Marketing
Agent, respectively, will remain responsible for those obligations. Each of the Servicer, the
Custodian and the Marketing Agent will be responsible for the fees of its delegates and contractors,
as applicable.

Section 6.5 Servicer May Own Notes. The Servicer and any Affiliate of the Servicer, may, in its
individual or any other capacity, become the owner or pledgee of Notes with the same rights as it
would have if it were not the Servicer or an Affiliate of the Servicer, except as otherwise stated
in any Transaction Document.

Section 6.6 Annual Statement as to Compliance. Within ninety (90) days after the end of each fiscal
year for which a report on Form 10-K is required to be filed with the Commission by or on behalf of
the Issuer (commencing with the fiscal year ended December 31, 2020), the Servicer will deliver an
Officer's Certificate to the Administrator, the Depositor, the Owner Trustee and the Indenture
Trustee to the effect that (A) a review of the Servicer's activities during the prior fiscal year
(or since the Closing Date in the case of the first such Officer's Certificate) and of its
performance under this Agreement has been made under the supervision of the officer executing such
Officer's Certificate and (B) to the best of his or her knowledge, based on the review, the Servicer
has fulfilled in all material respects its obligations under this Agreement, or, if there has been a
failure to fulfill any such obligation in any material respect, specifying each such failure known
to such officer and the nature and status of the failure.

Section 6.7 Assessment of Compliance and Accountants' Attestation.

(a) Within ninety (90) days after the end of each fiscal year for which a report on Form 10-K is
required to be filed with the Commission by or on behalf of the Issuer (commencing with the fiscal
year ended December 31, 2020), the Servicer will:

(i) deliver to the Issuer, the Depositor, the Administrator, the Owner Trustee, the Indenture
Trustee and the Rating Agencies a report regarding the Servicer's assessment of compliance with the
Servicing Criteria during the immediately preceding

31

Source: VERIZON ABS LLC, 8-K, 1/23/2020
<!-- page 36 -->
calendar year, including disclosure of any material instance of non-compliance identified by the
Servicer, as required under Rules 13a-18 and 15d-18 of the Exchange Act and Item 1122 of Regulation
AB. Such report shall be addressed to the Issuer and signed by an authorized officer of the
Servicer, and shall address each of the Servicing Criteria applicable to the Servicer;

(ii) deliver to the Issuer, the Depositor, the Administrator, the Owner Trustee, the Indenture
Trustee and the Rating Agencies a report of a registered public accounting firm reasonably
acceptable to the Issuer and the Administrator that attests to, and reports on, the assessment of
compliance made by the Servicer and delivered pursuant to the preceding paragraph. This attestation
shall be delivered in accordance with Rules 1-02(a)(3) and 2-02(g) of Regulation S‑X under the
Securities Act and the Exchange Act;

(iii) cause each Subservicer and each Subcontractor, if any, determined by the Servicer to be
"participating in the servicing function" within the meaning of Item 1122 of Regulation AB, to
deliver to the Issuer, the Depositor, the Administrator, the Owner Trustee and the Indenture Trustee
an assessment of compliance and accountants' attestation as and when provided in paragraphs (i) and
(ii) of this Section; and

(iv) if requested by the Administrator, acting on behalf of the Issuer, deliver to the Issuer, the
Depositor and the Administrator and any other Person that will be responsible for signing the
certification (a "Sarbanes Certification") required by Rules 13a-14(d) and 15d- 14(d) under the
Exchange Act (pursuant to Section 302 of the Sarbanes-Oxley Act of 2002) on behalf of an
asset-backed issuer with respect to a securitization transaction a certification in the form
attached hereto as Exhibit B.

The Servicer acknowledges that the parties identified in clause (a)(iv) above may rely on the
certification provided by the Servicer pursuant to such clause in signing a Sarbanes Certification
and filing such with the Commission. The Administrator, acting on behalf of the Issuer, will not
request delivery of a certification under clause (a)(iv) above unless the Depositor is required
under the Exchange Act to file an annual report on Form 10‑K with respect to an asset-backed issuer
whose asset pool includes receivables.

(b) Each assessment of compliance provided by a Subservicer pursuant to Section 6.7(a)(iii) shall
address each of the Servicing Criteria specified on a certification to be delivered by such
Subservicer to the Servicer, the Issuer, the Depositor and the Administrator on or prior to the date
of such appointment. An assessment of compliance provided by a Subcontractor pursuant to Section
6.7(a)(iii) need not address any elements of the Servicing Criteria other than those specified by
the Servicer and the Issuer on the date of such appointment.

ARTICLE VII SERVICER RESIGNATION AND TERMINATION; SUCCESSOR SERVICER

Section 7.1 No Resignation. The Servicer will not resign as Servicer under this Agreement unless it
determines it is legally unable to perform its obligations under this Agreement. The Servicer will
notify the Issuer, the Parent Support Provider, the Owner Trustee and the Indenture Trustee of its
resignation as soon as practicable after it determines it is required to resign, together with an
Opinion of Counsel supporting its determination. The Issuer will

32

Source: VERIZON ABS LLC, 8-K, 1/23/2020
<!-- page 37 -->
promptly notify the Rating Agencies of any resignation of the Servicer. Notwithstanding anything to
the contrary in this Agreement or in any other Transaction Document, immediately upon the
resignation of Cellco as Servicer pursuant to this Section 7.1, Cellco, in its individual capacity,
will be required to assume the obligations of the Servicer to acquire Receivables as set forth in
Sections 3.4 and 4.7 of the Master Trust Receivables Transfer Agreement and Sections 2.5 and 2.6 of
this Agreement without further action.

Section 7.2 Servicer Termination Events.

(a) Servicer Termination Events. The following events will each be a "Servicer Termination Event":

(i) (x) the Servicer fails to deposit, or deliver to the Owner Trustee or the Indenture Trustee for
deposit, any Collections required to be delivered under this Agreement; (y) so long as Cellco is the
Servicer, the Marketing Agent fails to deposit, or to cause the related Originators to deposit, into
the Collection Account any Upgrade Payments required to be delivered under this Agreement, or (z) so
long as Cellco is the Servicer, the Parent Support Provider fails to make any payments with respect
to the items set forth in clause (x) or clause (y) above, to the extent the Servicer, or the
Marketing Agent or any related Originator, respectively, fails to do so, and, in each case, which
such failure continues for five (5) Business Days after the Servicer, the Marketing Agent or the
Parent Support Provider, as applicable, receives written notice of the failure from the Owner
Trustee or the Indenture Trustee, or a Responsible Person of the Servicer, the Marketing Agent or
the Parent Support Provider, as applicable, obtains actual knowledge of the failure; or

(ii) the Servicer (including in its capacity as Custodian) fails to observe or to perform any
obligation under this Agreement, other than as set forth in clause (i) or (iii), which failure has a
material adverse effect on the Noteholders and continues for ninety (90) days after the Servicer
receives written notice of the failure from the Owner Trustee, the Indenture Trustee or the
Noteholders of at least a majority of the Note Balance of the Controlling Class; or

(iii) so long as Cellco is the Servicer, the failure by (x) the Marketing Agent to make, or to cause
the related Originators to make, (i) any payments required to be paid by the Marketing Agent,
including without limitation Credit Payments or (ii) payments relating to the acquisition by the
Marketing Agent or the related Originators of Receivables that are subject to certain transfers, but
not including Upgrade Payments, or (y) the Parent Support Provider to make any payments set forth in
clause (x) above, to the extent that the Marketing Agent or any related Originator fails to do so,
and in either case, that continues for ten (10) Business Days after the Marketing Agent or Parent
Support Provider, as applicable, receives written notice of the failure from the Owner Trustee or
the Indenture Trustee, or a Responsible Person of the Marketing Agent or the Parent Support
Provider, as applicable, obtains actual knowledge of the failure; or

(iv) an Insolvency Event of the Servicer occurs;

33

Source: VERIZON ABS LLC, 8-K, 1/23/2020
<!-- page 38 -->
provided, however, that a delay or failure of performance referred to in clauses (i), (ii) or (iii)
above for an additional period of sixty (60) days will not constitute a Servicer Termination Event
if such delay or failure was caused by force majeure or other similar occurrence, as further
described in Section 6.2(d).

(b) Notice of Servicer Termination Event. The Servicer will notify the Issuer, the Owner Trustee and
the Indenture Trustee of any Servicer Termination Event or any event that with the giving of notice
or passage of time, or both, would become a Servicer Termination Event, no later than five (5)
Business Days after a Responsible Person of the Servicer has received written notice of or has
actual knowledge of the event. If a Servicer Termination Event occurs, the Issuer will promptly
notify the Rating Agencies and the Asset Representations Reviewer.

(c) Removal. If a Servicer Termination Event occurs and is continuing, the Indenture Trustee may
and, if directed by the Noteholders of a majority of the Note Balance of the Controlling Class, must
remove the Servicer and terminate its rights and obligations under this Agreement by notifying the
Servicer, the Issuer, the Parent Support Provider, the Owner Trustee, and the Secured Parties. The
notice of termination will state the date the termination will be effective. On receipt of the
notice, the Issuer will promptly notify the Rating Agencies, and the Owner Trustee will promptly
notify the Certificateholders. Notwithstanding anything to the contrary in this Agreement or in any
other Transaction Document, immediately upon the removal of Cellco as Servicer pursuant to this
Section 7.2, Cellco, in its individual capacity, shall assume the obligations of the Servicer to
acquire Receivables as set forth in Sections 3.4 and 4.7 of the Master Trust Receivables Transfer
Agreement and Sections 2.5 and 2.6 of this Agreement without further action.

(d) Waiver of Servicer Termination Events. The Noteholders of a majority of the Note Balance of the
Controlling Class or, if no Notes are Outstanding, the Owner Trustee, at the direction of the Class
A Certificateholder, may direct the Indenture Trustee to waive a Servicer Termination Event, except
with respect to a failure to make required deposits to or payment from any of the Bank Accounts, and
the consequences thereof. Upon the waiver, the Servicer Termination Event will be deemed not to have
occurred. No waiver will extend to any other Servicer Termination Event or impair a right relating
to any other Servicer Termination Event. The Issuer will promptly notify the Rating Agencies of any
waiver.

Section 7.3 Continue to Perform. If the Servicer resigns under Section 7.1, it will continue to
perform its obligations as Servicer under this Agreement until the earlier to occur of (a) a
Successor Servicer accepting its engagement as Servicer under Section 7.4 or (b) the date the
Servicer is legally unable to act as Servicer. If the Servicer is terminated under this Agreement,
it will continue to perform its obligations as Servicer under this Agreement until the date stated
in the notice of termination. If Cellco is the resigning or removed Servicer, Cellco shall (x) remit
any amounts due on the Receivables that are remitted to Cellco in error, rather than to the
Successor Servicer as set forth in the notice sent to Obligors under Section 3.13, and provide the
Successor Servicer with any necessary information regarding the amount remitted to the Successor
Servicer by Cellco and the Receivable for which such amount was remitted and (y) continue to perform
its remittance obligations set forth in Section 3.12(b) for as long as any

34

Source: VERIZON ABS LLC, 8-K, 1/23/2020
<!-- page 39 -->
Receivable continues to have a Principal Balance or until this Agreement is terminated as set forth
in Section 8.3.

Section 7.4 Successor Servicer.

(a) Engagement of Successor Servicer; Indenture Trustee to Act.

(i) If the Servicer resigns or is terminated under this Agreement, the Indenture Trustee will
promptly engage an institution having a net worth of not less than $50,000,000 whose regular
business and operations includes the servicing of consumer receivables and can accommodate the
servicing of device payment plan agreements, as the successor to the Servicer under this Agreement
(the "Successor Servicer") and successor to the Administrator under Section 3.4 of the
Administration Agreement.

(ii) If no Person has accepted the engagement as Successor Servicer when the Servicer stops
performing its obligations, the Indenture Trustee, without further action, will be automatically
appointed the Successor Servicer to perform the obligations of the Servicer (other than any
obligations specifically excluded) until such time as another Successor Servicer shall accept
engagement as Successor Servicer. If the Indenture Trustee becomes the Successor Servicer, it (A)
will do so in its individual capacity and not in its capacity as Indenture Trustee and, accordingly,
Article VI of the Indenture will be inapplicable to the Indenture Trustee solely in its capacity as
Successor Servicer and (B) may appoint as Servicer any one of its Affiliates, but the Indenture
Trustee, in its capacity as Successor Servicer, will be liable for the actions and omissions of such
Affiliate. If the Indenture Trustee is unwilling or legally unable to act as Successor Servicer, it
will appoint, or petition a court of competent jurisdiction to appoint, an institution having a net
worth of not less than $50,000,000 whose regular business and operations includes the servicing of
consumer receivables and can accommodate the servicing of device payment plan agreements, as
successor to the Servicer under this Agreement. The Indenture Trustee will be released from its
obligations as Successor Servicer on the date that a new Servicer accepts its engagement as
Successor Servicer.

(b) Acceptance of Engagement. The Successor Servicer will accept its engagement by assuming the
Servicer's obligations under this Agreement or entering into an amendment to this Agreement or a new
servicing agreement on substantially the same terms as this Agreement, in a form acceptable to the
Owner Trustee and the Indenture Trustee. The Successor Servicer will deliver a copy of the
assumption, amendment or new servicing agreement to the other parties and the Indenture Trustee. The
Successor Servicer (other than the Indenture Trustee as Successor Servicer) will accept its
engagement as Administrator according to Section 3.5 of the Administration Agreement. Promptly
following a Successor Servicer's acceptance of its engagement, the Indenture Trustee will notify the
Issuer, the Owner Trustee and the Secured Parties of the engagement. On receipt of a notice of
engagement, the Issuer will promptly notify the Rating Agencies and the Asset Representations
Reviewer, and the Owner Trustee will promptly notify the Certificateholders. Any Successor Servicer
will agree to provide to Cellco any information relating to payments received from Obligors
(including any payments received on a Receivable that was the subject of an upgrade for which none
of the Marketing Agent, the related Originator or the Parent Support Provider deposited a required
Upgrade Payment),

35

Source: VERIZON ABS LLC, 8-K, 1/23/2020
<!-- page 40 -->
delinquencies in payments by Obligors, any Written-Off Receivables and any other information related
to the Obligors and the Receivables required by Cellco to service the accounts of which any
Receivables are a part, including, but not limited to, granting and applying credits to any account
for which none of the Marketing Agent, the related Originator or the Parent Support Provider
remitted an Upgrade Payment, as set forth in Section 3.12(b). Any Successor Servicer will agree to
be bound by the terms and conditions of the legal, regulatory, privacy and data protection policies
set forth in Exhibit A attached hereto to the extent such Successor Servicer receives information
from Cellco or any of its Affiliates relating to the Receivables. For the avoidance of doubt, no
Successor Servicer will be required to assume or undertake the obligations of Cellco, as Servicer,
under Sections 3.4 and 4.7 of the Master Trust Receivables Transfer Agreement or Sections 2.5 and
2.6 of this Agreement. No Successor Servicer shall have any liability for the acts or omissions of
any predecessor Servicer.

(c) Compensation of Successor Servicer. The Indenture Trustee may make arrangements for the
compensation of the Successor Servicer out of Collections as it and the Successor Servicer may
agree. In addition to the Servicing Fee, on the date of its appointment as Successor Servicer, such
Successor Servicer will receive a fee of $150,000 payable pursuant to Section 8.2(c) or 8.2(e) of
the Indenture, as applicable, and thereafter, will be entitled to the Additional Successor Servicer
Fee, which will be paid in accordance with the priorities set forth in Section 8.2(c) or 8.2(e) of
the Indenture, as applicable.

(d) Transfer of Authority. On the effective date of the Servicer's resignation or termination or the
later date that the Servicer stops performing its obligations, and solely to the extent the
Successor Servicer is an entity other than the Indenture Trustee, all rights and obligations of the
Servicer under this Agreement and of the Administrator under the Administration Agreement will
become the rights and obligations of the Successor Servicer, including as successor Administrator.
For the avoidance of doubt, (x) the resignation or removal of Cellco as Servicer will not result in
the termination of Cellco's duties as Marketing Agent and (y) if the Indenture Trustee is the
Successor Servicer, Cellco will continue to act as Administrator under the Administration Agreement,
to the extent it is able to continue to perform thereunder pursuant to the terms of the
Administration Agreement.

(e) Authority of Issuer and Indenture Trustee. The Issuer and the Indenture Trustee are authorized
to execute and deliver, on behalf of the Servicer, as attorney-in-fact or otherwise, all documents,
and to do all other acts or things necessary or advisable to effect the termination and replacement
of the Servicer.

Section 7.5 Transition of Servicing.

(a) Cooperation on Termination. On its resignation or termination, the Servicer will cooperate with
the Issuer, the Owner Trustee, the Indenture Trustee and the Successor Servicer in effecting (i) the
termination of its rights and obligations under this Agreement and (ii) an orderly transition of
such rights and obligations to the Successor Servicer.

(b) Transfer of Cash, Receivable Files and Records. As soon as practicable after the effective date
of its resignation or termination, the predecessor Servicer will (i) transfer to the Successor
Servicer all funds relating to the Receivables that are held or later received by the

36

Source: VERIZON ABS LLC, 8-K, 1/23/2020
<!-- page 41 -->
predecessor Servicer and (ii) deliver to the Successor Servicer the Receivable Files and the
accounts and records maintained by the Servicer. The Servicer will not be obligated to provide,
license or assign its processes, procedures, models, servicing software or other applications to any
Successor Servicer or any third party, or provide anything covered by a restriction on transfer or
assignment or a confidentiality agreement or otherwise restricted by legal, regulatory, privacy or
data protection policies.

(c) Expenses of Servicing Transition. All reasonable expenses incurred by the Issuer, the Owner
Trustee, the Indenture Trustee and the Successor Servicer in connection with (i) the transition of
servicing rights and obligations to the Successor Servicer and (ii) amending this Agreement or
entering into an assumption agreement or new agreement to reflect a succession of the Servicer will
be paid by the resigning or terminated Servicer on receipt of an invoice in reasonable detail.

Section 7.6 Merger, Consolidation, Succession or Assignment. Any Person (a) into which the Servicer
is merged or consolidated, (b) resulting from a merger or consolidation to which the Servicer is a
party, (c) succeeding to the Servicer's business or (d) that is an Affiliate of the Servicer to whom
the Servicer has assigned this Agreement, will be the successor to the Servicer under this
Agreement. Within fifteen (15) Business Days after the merger, consolidation, succession or
assignment, such Person will (i) execute an agreement to assume the Servicer's obligations under
this Agreement and each Transaction Document to which the Servicer is a party (unless the assumption
happens by operation of Law), (ii) deliver to the Issuer, the Owner Trustee and the Indenture
Trustee an Officer's Certificate and an Opinion of Counsel each stating that the merger,
consolidation, succession or assignment and the assumption agreement comply with this Section 7.6
and (iii) notify the Rating Agencies of the merger, consolidation, succession or assignment.

ARTICLE VIII TERMINATION

Section 8.1 Optional Acquisition of Receivables; Clean-Up Redemption of Notes.

(a) Optional Acquisition. On each Payment Date following the last day of a Collection Period as of
which the aggregate Principal Balance of the Receivables shall be equal to or less than 10% of the
aggregate Principal Balance of the Receivables as of the Closing Date, the Class A Certificateholder
(for as long as the Class A Certificateholder is an Originator or an Affiliate of the Originators),
with the consent of the Administrator, on behalf of the Issuer, shall have the option to acquire, as
of the end of the immediately preceding Collection Period, any Receivables remaining in the Trust
Property on such date by transferring to the Issuer an amount equal to the Optional Acquisition
Amount (the "Optional Acquisition"), and to redeem the Notes, in whole but not in part (the
"Clean-Up Redemption") without any Make-Whole Payment (other than any Make-Whole Payments already
due and payable on such date).

(b) Exercise of Optional Acquisition and Clean-Up Redemption of Notes. The Class A Certificateholder
may exercise its option set forth in Section 8.1(a) by notifying the Issuer, the Servicer, the
Indenture Trustee, the Owner Trustee and the Rating Agencies, in writing, at least ten (10) days
before the Payment Date on which the Optional Acquisition is to be exercised,

37

Source: VERIZON ABS LLC, 8-K, 1/23/2020
<!-- page 42 -->
After receiving such notice, the Indenture Trustee will promptly notify the Noteholders of the
resulting Clean-Up Redemption and provide instructions for surrender of the Notes for final payment
including all accrued and unpaid interest and any applicable Make-Whole Payments already due and
payable on the Notes, as set forth in Section 10.1(a) of the Indenture.

On the Payment Date related to the Collection Period in which the Optional Acquisition is exercised,
the Class A Certificateholder will deposit into the Collection Account the acquisition amount for
such remaining Receivables as set forth in Section 8.1(a) equal to the fair market value of such
Receivables as of the last day of the Collection Period immediately preceding such Payment Date as
agreed upon by the Class A Certificateholder and the Issuer (the "Optional Acquisition Amount");
provided that the transfer may only occur if the Optional Acquisition Amount, together with any
amounts on deposit in the Bank Accounts, is greater than or equal to the sum of (A) the Note Balance
of the Notes, any accrued but unpaid interest and any unpaid Make-Whole Payments and (B) all other
amounts payable by the Issuer under the Transaction Documents including, but not limited to, all
fees, expenses and indemnities owed to the Indenture Trustee and the Owner Trustee under the
Transaction Documents as of such date. For the avoidance of doubt, if the Class A Certificateholder
and the Issuer cannot agree on the Optional Acquisition Amount, the Class A Certificateholder will
not be permitted to exercise its option set forth in Section 8.1(a). On the Payment Date on which
the Optional Acquisition is to be exercised, the Indenture Trustee shall transfer any amounts on
deposit in the Reserve Account, the Acquisition Account and the Negative Carry Account into the
Collection Account. Upon the exercise of the Optional Acquisition, the Notes will be redeemed and
paid in full.

Section 8.2 Optional Redemption of Notes.

(a) Optional Redemption. On any Payment Date on and after the Payment Date in February 2021, the
Class A Certificateholder (for as long as the Class A Certificateholder is an Originator or an
Affiliate of the Originators), with the consent of the Administrator, on behalf of the Issuer, shall
have the option to redeem the Notes, in whole but not in part (the "Optional Redemption"), with a
required Make-Whole Payment.

(b) Exercise of Optional Redemption. The Class A Certificateholder may exercise its option set forth
in Section 8.2(a) by notifying the Issuer, the Servicer, the Indenture Trustee, the Owner Trustee
and the Rating Agencies, in writing, at least ten (10) days before the Payment Date on which the
Optional Redemption is to be exercised. After receiving such notice, the Indenture Trustee will
promptly notify the Noteholders of the Optional Redemption and provide instructions for surrender of
the Notes for final payment including all accrued and unpaid interest and any applicable Make-Whole
Payments due and payable on the Notes, as set forth in Section 10.1(a) of the Indenture.

On the Payment Date on which the Optional Redemption is to be exercised, the Issuer shall transfer
the entire pool of Receivables to another Verizon special purpose entity or a third-party purchaser
and the party receiving the Receivables shall cause the acquisition amount received by the Issuer
for the Receivables to be deposited by the Issuer (or the Servicer, on its behalf) into the
Collection Account, which amount shall be equal to the fair market value of such Receivables as of
the last day of the Collection Period immediately preceding such Payment Date as agreed upon by the
Class A Certificateholder and the Issuer; provided that the transfer

38

Source: VERIZON ABS LLC, 8-K, 1/23/2020
<!-- page 43 -->
may only occur if the amount received in connection with any such transfer, together with any
amounts on deposit in the Bank Accounts, is greater than or equal to the sum of (A) the Note Balance
of the Notes, any accrued but unpaid interest and any unpaid Make-Whole Payments and (B) all other
amounts payable by the Issuer under the Transaction Documents including, but not limited to, all
fees, expenses and indemnities owed to the Indenture Trustee and the Owner Trustee under the
Transaction Documents as of such date. On the Payment Date on which the Optional Redemption is to be
exercised, the Indenture Trustee shall transfer any amounts on deposit in the Reserve Account, the
Acquisition Account and the Negative Carry Account into the Collection Account. Upon the exercise of
the Optional Redemption, the Notes will be redeemed and paid in full.

Section 8.3 Termination. This Agreement will terminate on the earlier to occur of (a) the date upon
which the last remaining Receivable is paid in full, settled, sold or written off and any amounts
received are applied and (b) the Issuer is terminated under Section 8.1 of the Trust Agreement.

ARTICLE IX OTHER AGREEMENTS

Section 9.1 Financing Statements.

(a) Filing of Financing Statements. The Depositor will file financing and continuation statements,
and amendments to the statements, in the jurisdictions and with the filing offices necessary to
perfect the Issuer's interest in the Depositor Transferred Property. The Depositor will promptly
deliver to the Issuer and the Indenture Trustee file-stamped copies of, or filing receipts for, any
financing statement, continuation statement and amendment to a previously filed financing statement.

(b) Issuer and Indenture Trustee Authorized to File Financing Statements. The Depositor authorizes
the Issuer and the Indenture Trustee (but the Indenture Trustee will not be required to do so) to
file financing and continuation statements, and amendments to the statements, in the jurisdictions
and with the filing offices as the Issuer or the Indenture Trustee may determine are necessary or
advisable to perfect the Issuer's interest in the Depositor Transferred Property. The financing and
continuation statements may describe the Depositor Transferred Property as the Issuer or the
Indenture Trustee may reasonably determine to perfect the Issuer's interest in the Depositor
Transferred Property. The Issuer or the Indenture Trustee (with respect to the Indenture Trustee,
solely to the extent it has elected to make such filing) will promptly deliver to the Depositor
file-stamped copies of, or filing receipts for, any financing statement, continuation statement and
amendment to a previously filed financing statement. The permissive right of the Indenture Trustee
to file any financing statement shall not be construed as a duty or obligation.

(c) Relocation of Depositor. The Depositor will notify the Owner Trustee and the Indenture Trustee
at least ten (10) days before a relocation of its chief executive office or change in its corporate
structure, form of organization or jurisdiction of organization if it could require the filing of a
new financing statement or an amendment to a previously filed financing statement under Section
9-307 of the UCC. If required, the Depositor will promptly file new

39

Source: VERIZON ABS LLC, 8-K, 1/23/2020
<!-- page 44 -->
financing statements or amendments to all previously filed financing statements. The Depositor will
maintain its chief executive office within the United States and will maintain its jurisdiction of
organization in only one State.

(d) Change of Depositor's Name. The Depositor will notify the Owner Trustee and the Indenture
Trustee at least ten (10) days before any change in the Depositor's name that could make a financing
statement filed under this Section 9.1 seriously misleading under Section 9-506 of the UCC. If
required, the Depositor will promptly file amendments to all previously filed financing statements.

Section 9.2 No Transfer or Lien by Depositor. Except for the transfer and assignment under this
Agreement, the Depositor will not transfer or assign any Depositor Transferred Property to another
Person or Grant or allow a Lien, other than a Permitted Lien, on an interest in any Depositor
Transferred Property. The Depositor will defend the Issuer's interest in the Depositor Transferred
Property against claims of third parties claiming through the Depositor.

Section 9.3 Expenses. The Depositor will pay the expenses to perform its obligations under this
Agreement and the Issuer's and the Indenture Trustee's reasonable expenses to perfect the Issuer's
interest in the Depositor Transferred Property and to enforce the Depositor's obligations under this
Agreement.

Section 9.4 Receivables Information.

(a) Servicer's Receivables Systems. On and after the Closing Date or Acquisition Date, as
applicable, until a Receivable has been paid in full, acquired or sold to a third party under
Section 3.4, the Servicer will mark its receivables systems to indicate clearly that the Receivable
is owned by the Issuer and has been pledged to the Indenture Trustee under the Indenture.

(b) List of Receivables. If requested by the Owner Trustee or the Indenture Trustee, the Servicer
will furnish a list of Receivables (by loan number) to the Owner Trustee and the Indenture Trustee.

Section 9.5 No Petition. The parties agree that, before the date that is one year and one day (or,
if longer, any applicable preference period) after the payment in full of (a) all securities issued
by the Depositor or by a trust for which the Depositor was a depositor or (b) the Notes, it will not
start or pursue against, or join any other Person in starting or pursuing against, (i) the Depositor
or (ii) the Issuer, respectively, any bankruptcy, reorganization, arrangement, insolvency or
liquidation proceedings or other proceedings under any bankruptcy or similar Law. This Section 9.5
will survive the termination of this Agreement.

Section 9.6 Limited Recourse. Each party agrees that any claim that it may seek to enforce against
the Depositor or the Issuer under this Agreement is limited to the Depositor Transferred Property
only and is not a claim against the Depositor's or the Issuer's assets as a whole or against assets
other than the Depositor Transferred Property.

40

Source: VERIZON ABS LLC, 8-K, 1/23/2020

Section 9.7 Limitation of Liability.
<!-- page 45 -->
(a) Owner Trustee. This Agreement has been signed on behalf of the Issuer by Wilmington Trust,
National Association not in its individual capacity but solely in its capacity as Owner Trustee of
the Issuer. In no event will Wilmington Trust, National Association in its individual capacity or as
a beneficial owner of the Issuer be liable for the representations, warranties, covenants,
agreements or other obligations of the Issuer under this Agreement. For all purposes under this
Agreement, the Owner Trustee is subject to, and entitled to the benefits of, the Trust Agreement.
Neither the Issuer nor the Owner Trustee will have any liability for any act or failure to act of
the Servicer, including any action taken under a power of attorney given under this Agreement.

(b) Indenture Trustee. This Agreement has been signed by U.S. Bank National Association not in its
individual capacity but solely in its capacity as Indenture Trustee. In performing its obligations
under this Agreement, the Indenture Trustee is subject to, and entitled to the benefits of, the
Indenture. The Indenture Trustee will not have any liability for any act or failure to act of the
Servicer, the Custodian, the Marketing Agent, the Issuer or any other Person.

Section 9.8 Tax Treatment of Notes. Each of the Depositor and the Servicer agree to treat the Notes
as indebtedness for U.S. federal, State and local income and franchise tax purposes.

Section 9.9 Regulation RR Risk Retention. Cellco, as Sponsor, agrees that (i) each of the Sponsor,
the Master Trust, each Originator and the nominee of the Originators is under the common control of
Verizon and therefore, the nominee of the Originators (which nominee is also the sole equityholder
of the Master Trust) is a "majority-owned affiliate" of the Sponsor as defined in the U.S. Credit
Risk Retention Rules, (ii) the Sponsor will cause the nominee of the Originators to, and the nominee
of the Originators will, retain the Residual Interest on the Closing Date and (iii) the Sponsor will
not, and will not permit the Master Trust, the Originators or the nominee of the Originators to,
sell, transfer, finance or hedge the Residual Interest except as permitted by the U.S. Credit Risk
Retention Rules.

Section 9.10 Cap Collateral Account. If the Cap Counterparty is required to post collateral under
the terms of the Cap Agreement, upon written direction and notification of such requirement, the
Servicer shall establish a segregated account (the "Cap Collateral Account") at a Qualified
Institution that (i) is not affiliated with the Cap Counterparty and (ii) has total assets of at
least $10,000,000,000 (the "Cap Custodian"), titled as an account of the Cap Counterparty as
depositor and entitlement holder. In the event that the Cap Custodian no longer satisfies the
requirements set forth in the immediately preceding sentence, the Issuer, the Servicer and the Cap
Counterparty shall use their reasonable best efforts to move the Cap Collateral Account and any
collateral posted therein to another financial institution satisfying the requirements set forth in
the immediately preceding sentence within sixty (60) calendar days. The Cap Collateral Account shall
be subject to a tri-party account control agreement to be entered into among the Cap Counterparty,
the Issuer and the Cap Custodian (the "Control Agreement"). The Control Agreement shall provide,
among other customary matters, that (x) the Cap Counterparty shall be entitled to originate
entitlement orders and instructions, and receive interest and distributions, with respect to the Cap
Collateral Account so long as the Issuer has not delivered a notice to the

41

Source: VERIZON ABS LLC, 8-K, 1/23/2020
<!-- page 46 -->
Cap Custodian and the Cap Counterparty to the effect that the Issuer shall have exclusive control
over the Cap Collateral Account, (y) following delivery of such notice of exclusive control the Cap
Custodian shall comply with instructions and entitlement orders originated by the Issuer without
further consent by the Cap Counterparty, and (z) the Control Agreement shall terminate on the fifth
Business Day following delivery of a notice from the Cap Counterparty to the Cap Custodian and the
Issuer that the Cap Counterparty has designated an "Early Termination Date" (as defined in the Cap
Agreement) in respect of all "Transactions" (as defined in the Cap Agreement) for the reason that
the Issuer is the "Defaulting Party" (as defined in the Cap Agreement) or the sole "Affected Party"
(as defined in the Cap Agreement) with respect to a "Termination Event" (as defined in the Cap
Agreement), unless such notice is contested by the Issuer within such period of five (5) Business
Days. The Issuer agrees that it shall not assert exclusive control over, or originate entitlement
orders or instructions for the disposition of funds with respect to, the Cap Collateral Account
unless the conditions for the exercise of its rights and remedies pursuant to the Cap Agreement are
met and such assertion of exclusive control or origination of instructions or entitlement orders is
for the purpose of exercising such rights and remedies. The only permitted withdrawal from or
application of funds on deposit in, or otherwise to the credit of, the Cap Collateral Account shall
be (i) for application to obligations of the Cap Counterparty to the Issuer under the Cap Agreement
in accordance with the terms of the Cap Agreement or (ii) to return collateral to the Cap
Counterparty when and as required by the Cap Agreement or applicable law. Investment earnings on the
Cap Collateral Account, if any, will be distributed to the Cap Counterparty.

ARTICLE X MISCELLANEOUS

Section 10.1 Amendments.

(a) Amendments to Clarify and Correct Errors and Defects. The parties may amend this Agreement
(including Appendix A) to clarify an ambiguity, correct an error or correct or supplement any term
of this Agreement that may be defective or inconsistent with the other terms of this Agreement, or
to make Benchmark Replacement Conforming Changes, in each case, without the consent of the
Noteholders, the Certificateholders or any other Person. The parties may amend any term or provision
of this Agreement (including Appendix A) from time to time for the purpose of conforming the terms
of this Agreement (including Appendix A) to the description thereof in the Prospectus, without the
consent of Noteholders, the Certificateholders or any other Person. The Administrator may amend any
term or provision of this Agreement (including Appendix A) from time to time for the purpose of
making Benchmark Replacement Conforming Changes, without the consent of Noteholders, the
Certificateholders, any party to this Agreement or any other Person. Notice of the occurrence of a
Benchmark Transition Event and its related Benchmark Replacement Date, the determination of a
Benchmark Replacement and the making of any Benchmark Replacement Conforming Changes will be
delivered in writing by the Administrator to the Issuer, the Owner Trustee, a Responsible Person of
the Indenture Trustee, the Parent Support Provider, the Sponsor, the Depositor and the Servicer and
included in the Monthly Investor Report. Notwithstanding anything in the Transaction Documents to
the contrary, upon the delivery of notice to a Responsible Person of the Indenture Trustee and the
inclusion of such information in the Monthly Investor Report, the relevant Transaction Documents
will be deemed to have been amended to reflect the new Unadjusted

42

Source: VERIZON ABS LLC, 8-K, 1/23/2020
<!-- page 47 -->
Benchmark Replacement, Benchmark Replacement Adjustment and/or Benchmark Replacement Conforming
Changes without further compliance with the amendment provisions of the relevant Transaction
Documents.

(b) Other Amendments. Other than as set forth in Section 10.1(c), the parties may amend this
Agreement (including Appendix A) to add any provisions to, or change in any manner or eliminate any
provisions of, this Agreement or for the purpose of modifying in any manner the rights of the
Noteholders under this Agreement, with the consent of the Certificateholders, either (1) without the
consent of the Noteholders if (x) the Issuer or the Administrator delivers an Officer's Certificate
to the Indenture Trustee and the Owner Trustee stating that the amendment will not have a material
adverse effect on the Noteholders, or (y) the Rating Agency Condition is satisfied with respect to
such amendment or (2) if the interests of the Noteholders are materially and adversely affected,
with the consent of the holders of a majority of the Note Balance of the Controlling Class.

(c) Amendments Requiring Consent of all Affected Noteholders and Certificateholders. No amendment to
this Agreement (including Appendix A) may, without the consent of all adversely affected Noteholders
and Certificateholders, (i) change the applicable Final Maturity Date on a Note or change the
principal amount of or interest rate or Make-Whole Payment on a Note; (ii) modify the percentage of
the Note Balance of the Notes or the Controlling Class required for any action; (iii) modify or
alter the definition of "Outstanding," "Controlling Class" or "Amortization Events", or (iv) change
the Required Reserve Amount, the Required Acquisition Deposit Amount or the Required Negative Carry
Amount.

(d) Consent of Indenture Trustee and Owner Trustee. The consent of the Indenture Trustee will be
required for any amendment under Sections 10.1(b) or (c) that has a material adverse effect on the
rights, obligations, immunities or indemnities of the Indenture Trustee. The consent of the Owner
Trustee will be required for any amendment under Sections 10.1(b) or (c) that has a material adverse
effect on the rights, obligations, immunities or indemnities of the Owner Trustee, which consent
will not be unreasonably withheld.

(e) Opinion of Counsel. Before executing any amendment to this Agreement, the Owner Trustee and the
Indenture Trustee shall be entitled to receive and conclusively rely upon, and the Depositor will
deliver, an Opinion of Counsel stating that the execution of the amendment is permitted by this
Agreement and all conditions precedent thereto have been satisfied.

(f) Notice of Amendments. Promptly after the execution of an amendment, the Depositor will deliver,
or will cause the Administrator to deliver, a copy of the amendment to the Indenture Trustee and the
Rating Agencies, and the Indenture Trustee will notify the Noteholders of the substance of the
amendment.

(g) Noteholder Consent. For any amendment to this Agreement (or Appendix A) requiring the consent of
any Noteholders, the Indenture Trustee will, when directed by Issuer Order, notify the Noteholders
to request consent and follow its reasonable procedures to obtain consent. It shall not be necessary
for the consent of the Noteholders to approve the particular form of any proposed amendment or
consent, but it shall be sufficient if such consent shall

43

Source: VERIZON ABS LLC, 8-K, 1/23/2020
<!-- page 48 -->
approve the substance thereof. For the avoidance of doubt, any Noteholder consenting to any
amendment shall be deemed to agree that such amendment does not have a material adverse effect on
such Noteholder.

Section 10.2 Assignment; Benefit of Agreement; Third-Party Beneficiary.

(a) Assignment. Except as stated in Sections 5.3, 7.4 and 7.6, this Agreement may not be assigned by
the Depositor or the Servicer without the consent of the Owner Trustee, the Indenture Trustee, the
Certificateholders and the Noteholders of at least 66-2/3% of the Note Balance of the Controlling
Class.

(b) Benefit of Agreement; Third-Party Beneficiaries. This Agreement is for the benefit of and will
be binding on the parties and their permitted successors and assigns. The Owner Trustee and the
Indenture Trustee, for the benefit of the Secured Parties, will be third-party beneficiaries of this
Agreement and may enforce this Agreement against the Depositor and the Servicer. No other Person
will have any right or obligation under this Agreement.

Section 10.3 Notices.

(a) Notices to Parties. All notices, requests, directions, consents, waivers or other communications
to or from the parties must be in writing and will be considered received by the recipient:

(i) for personally delivered, express or certified mail or courier, when received;

(ii) for a fax, when receipt is confirmed by telephone, reply email or reply fax from the recipient;

(iii) for an email, when receipt is confirmed by telephone or reply email from the recipient; and

(iv) for an electronic posting to a password-protected website to which the recipient has access, on
delivery of an email (without the requirement of confirmation of receipt) stating that the
electronic posting has been made.

(b) Notice Addresses. A notice, request, direction, consent, waiver or other communication must be
addressed to the recipient at its address stated in Schedule B, which address the party may change
at any time by notifying the other parties.

(c) Notices to Noteholders. Notices to a Noteholder will be considered received by the Noteholder:

(i) for Definitive Notes, for overnight mail, on delivery or, for registered first class mail,
postage prepaid, three (3) days after deposit in the mail properly addressed to the Noteholder at
its address in the Note Register; or

44

Source: VERIZON ABS LLC, 8-K, 1/23/2020
<!-- page 49 -->
(ii) for Book-Entry Notes, when delivered under the procedures of the Clearing Agency, whether or
not the Noteholder actually receives the notice.

Section 10.4 Agent for Service.

(a) Depositor. The agent for service of the Depositor for this Agreement will be the person holding
the office of Secretary of the Depositor at the following address:

Verizon ABS LLC One Verizon Way Basking Ridge, New Jersey 07920

(b) Servicer. The agent for service of the Servicer for this Agreement will be the person holding
the office of Secretary of the Servicer at the following address:

Cellco Partnership d/b/a Verizon Wireless One Verizon Way Basking Ridge, New Jersey 07920

(c) Marketing Agent. The agent for service of the Marketing Agent for this Agreement will be the
person holding the office of Secretary of the Marketing Agent at the following address:

Cellco Partnership d/b/a Verizon Wireless One Verizon Way Basking Ridge, New Jersey 07920

Section 10.5 GOVERNING LAW. THIS AGREEMENT, INCLUDING THE RIGHTS AND DUTIES OF THE PARTIES HERETO,
SHALL BE GOVERNED BY, AND CONSTRUED IN ACCORDANCE WITH, THE INTERNAL LAWS OF THE STATE OF NEW YORK
(INCLUDING SECTIONS 5-1401 AND 5-1402 OF THE GENERAL OBLIGATIONS LAW OF THE STATE OF NEW YORK, BUT
WITHOUT REGARD TO ANY OTHERWISE APPLICABLE CONFLICTS OF LAW PRINCIPLES). FOR PURPOSES OF THE UCC,
NEW YORK SHALL BE DEEMED TO BE THE SECURITIES INTERMEDIARY'S JURISDICTION, AND THE LAW OF THE STATE
OF NEW YORK SHALL GOVERN ALL ISSUES SPECIFIED IN ARTICLE 2(1) OF THE HAGUE SECURITIES CONVENTION.
NOTWITHSTANDING SECTION 10.1 OF THIS AGREEMENT, THE PARTIES WILL NOT AGREE TO AMEND THIS AGREEMENT
TO CHANGE THE GOVERNING LAW TO ANY LAW OTHER THAN THE LAWS OF THE STATE OF NEW YORK.

Section 10.6 Submission to Jurisdiction. Each party submits to the nonexclusive jurisdiction of the
United States District Court for the Southern District of New York and of any New York State Court
sitting in New York, New York for legal proceedings relating to this Agreement. Each party
irrevocably waives, to the fullest extent permitted by Law, any objection that it may now or in the
future have to the venue of a proceeding brought in such a court and any claim that the proceeding
was brought in an inconvenient forum.

45

Source: VERIZON ABS LLC, 8-K, 1/23/2020
<!-- page 50 -->
Section 10.7 WAIVER OF JURY TRIAL. TO THE EXTENT PERMITTED BY APPLICABLE LAW, EACH PARTY HERETO
IRREVOCABLY WAIVES ALL RIGHT OF TRIAL BY JURY IN ANY ACTION, PROCEEDING OR COUNTERCLAIM ARISING OUT
OF, OR IN CONNECTION WITH, THIS AGREEMENT OR ANY MATTER ARISING THEREUNDER WHETHER SOUNDING IN
CONTRACT, TORT OR OTHERWISE.

Section 10.8 No Waiver; Remedies. No party's failure or delay in exercising a power, right or remedy
under this Agreement will operate as a waiver. No single or partial exercise of a power, right or
remedy will preclude any other or further exercise of the power, right or remedy or the exercise of
any other power, right or remedy. The powers, rights and remedies under this Agreement are in
addition to any powers, rights and remedies under Law.

Section 10.9 Severability. If a part of this Agreement is held invalid, illegal or unenforceable,
then it will be deemed severable from the remaining Agreement and will not affect the validity,
legality or enforceability of the remaining Agreement.

Section 10.10 Headings. The headings in this Agreement are included for convenience and will not
affect the meaning or interpretation of this Agreement.

Section 10.11 Counterparts. This Agreement may be executed in multiple counterparts. Each
counterpart will be an original and all counterparts will together be one document.

Section 10.12 Limitation of Rights of the Cap Counterparty. All of the rights of the Cap
Counterparty in, to and under this Agreement or any other Transaction Document, other than the Cap
Agreement (including, but not limited to, the Cap Counterparty's rights to receive notice of any
action hereunder or under any other Transaction Document and to give or withhold consent to any
action hereunder or under any other Transaction Document), shall terminate upon the termination of
the Cap Agreement in accordance with the terms thereof.

Section 10.13 Intent of the Parties; Reasonableness. The Depositor, the Servicer and the Issuer
acknowledge and agree that the purpose of Sections 6.6 and 6.7 of this Agreement is to facilitate
compliance by the Issuer and the Depositor with the provisions of Regulation AB and related rules
and regulations of the Commission. None of the Depositor, the Administrator nor the Issuer shall
exercise its right to request delivery of information or other performance under these provisions
other than in good faith, or for purposes other than compliance with the Securities Act, the
Exchange Act and the rules and regulations of the Commission thereunder. The Servicer acknowledges
that interpretations of the requirements of Regulation AB may change over time, whether due to
interpretive guidance provided by the Commission or its staff, consensus among participants in the
asset-backed securities markets, advice of counsel, or otherwise, and agrees to comply with requests
made by the Issuer or the Administrator in good faith for delivery of information under these
provisions on the basis of evolving interpretations of Regulation AB. In connection with this
transaction, the Servicer shall cooperate fully with the Administrator and the Issuer to deliver to
the Administrator or Issuer, as applicable (including any of its assignees or designees), any and
all statements, reports, certifications, records and any other information necessary in the good
faith determination of the Issuer or the Administrator to permit the Issuer or Administrator (acting
on behalf of the Issuer) to comply with the provisions of Regulation AB, together with such
disclosures relating to the Servicer, any Subservicer and

46

Source: VERIZON ABS LLC, 8-K, 1/23/2020
<!-- page 51 -->
the Receivables, or the servicing of the Receivables, reasonably believed by the Issuer or the
Administrator to be necessary in order to effect such compliance.

ARTICLE XI

ASSET REPRESENTATIONS REVIEW; DISPUTE RESOLUTION

Section 11.1 Asset Representations Review.

(a) Upon the occurrence of a Delinquency Trigger with respect to any Collection Period, the Servicer
will promptly send to the Administrator, the Indenture Trustee and each Noteholder (and to each
applicable Clearing Agency for distribution to Note Owners in accordance with the rules of such
Clearing Agency) as of the most recent Record Date a notice describing (i) the occurrence of the
Delinquency Trigger, and including reasonably detailed calculations thereof, and (ii) the rights of
the Noteholders and Note Owners regarding an Asset Representations Review (including a description
of the method by which Noteholders and Note Owners may contact the Indenture Trustee in order to
request a Noteholder vote in respect of an Asset Representations Review). In connection with the
foregoing, upon request from the Servicer, the Indenture Trustee shall provide a list of the
Noteholders of record as of the most recent Record Date. The notice provided under this Section 11.1
(a) and the related 10-D that is filed are the only notices that will be provided to Noteholders
concerning whether the Delinquency Trigger has occurred.

(b) If the Indenture Trustee notifies the Servicer pursuant to 14.2 of the Indenture that sufficient
Noteholders have voted within the required time to initiate an Asset Representations Review of all
60-Day Delinquent Receivables by the Asset Representations Reviewer pursuant to the Asset
Representations Review Agreement, then the Servicer shall:

(i) promptly notify the Asset Representations Reviewer and the Indenture Trustee of the number of
60-Day Delinquent Receivables;

(ii) within sixty (60) days after receipt by the Servicer of that notice from the Indenture Trustee,
render reasonable assistance, including granting access to copies of any underlying documents and
Receivable Files and all other relevant documents, to the Asset Representations Reviewer to
facilitate the performance of a review of all 60-Day Delinquent Receivables, pursuant to Section
3.3(a) of the Asset Representations Review Agreement, in order to verify compliance with the
representations and warranties made to the Issuer by the Depositor; provided, that the Servicer
shall use its best efforts to redact any materials provided to the Asset Representations Reviewer in
order to remove any Personally Identifiable Information without changing the meaning or usefulness
of the Review Materials; and

(iii) provide such other reasonable assistance to the Asset Representations Reviewer as it requests
in order to facilitate its Asset Representations Review of the 60-Day Delinquent Receivables
pursuant to the Asset Representations Review Agreement.

Section 11.2 Dispute Resolution.

47

Source: VERIZON ABS LLC, 8-K, 1/23/2020
<!-- page 52 -->
(a) If (i) the Issuer or the Indenture Trustee (acting on behalf of the Noteholders) or (ii) any
Noteholder or Verified Note Owner requests, by written notice to (x) the Indenture Trustee (which
will be forwarded to the related Originator or the Servicer as applicable) or (y) the related
Originator or the Servicer (in the case of Receivables transferred by the Master Trust) (any such
party making a request, the "Requesting Party"), that a Receivable be reacquired or acquired due to
an alleged breach of the Eligibility Representation with respect to that Receivable as set forth in
Section 3.3 of the Originator Receivables Transfer Agreement or Section 3.3 of the Master Trust
Receivables Transfer Agreement, respectively, and the request has not been fulfilled or otherwise
resolved to the reasonable satisfaction of the Requesting Party within one-hundred eighty (180) days
of the receipt of such request by the related Originator or the Servicer (in the case of Receivables
transferred by the Master Trust), then the Requesting Party will have the right to refer the matter,
at its discretion, to either mediation (including non-binding arbitration) or third-party binding
arbitration pursuant to this Section 11.2. Dispute resolution to resolve reacquisition or
acquisition requests will be available regardless of whether Noteholders and Note Owners voted to
direct an Asset Representations Review or whether the Delinquency Trigger occurred. The Depositor
will provide written direction to the Indenture Trustee instructing it to notify the Requesting
Party (directly if the Requesting Party is a Noteholder and through the applicable Clearing Agency
for distribution to such Requesting Party, if the Requesting Party is a Note Owner, in accordance
with the rules of such Clearing Agency) no later than five (5) Business Days after the end of the
180-day period of the date when the 180-day period ends without resolution by the appropriate party,
which written direction will specify the identity of the Requesting Party and the date as of which
that 180-day period shall have ended; provided, that the Indenture Trustee shall have no other
obligation whatsoever to participate in any dispute resolution, mediation or arbitration to
determine if a reacquisition or acquisition request has been resolved within the applicable 180-day
period. The Requesting Party must provide notice of its intention to refer the matter to mediation,
to refer the matter to arbitration, or to institute a legal proceeding, to the Depositor within
thirty (30) days after the delivery of notice of the end of the 180-day period. The Depositor will
participate in the resolution method selected by the Requesting Party. For the avoidance of doubt,
the Owner Trustee shall have no obligation whatsoever to participate in any dispute resolution,
mediation or arbitration to determine if a reacquisition or acquisition request has been resolved
within the applicable 180-day period. For the avoidance of doubt, if the Indenture Trustee does not
agree to pursue or otherwise be involved in resolving any reacquisition or acquisition request or
dispute resolution proceeding, the related Noteholders or Verified Note Owners may independently
pursue dispute resolution in respect of such reacquisition or acquisition. If the Indenture Trustee
brings a dispute resolution action based on Noteholder direction to do so, the "Requesting Party"
shall be deemed to be the requesting Note Owners (or the party to the arbitration) for purposes of
the dispute resolution proceeding, including allocation of fees and expenses. The Indenture Trustee
shall not be liable for any costs, expenses and/or liabilities allocated to a Requesting Party as
part of the dispute resolution proceeding. Further, the Indenture Trustee shall be under no
obligation under this Agreement, any other Transaction Document or otherwise to monitor
reacquisition or acquisition activity or to independently determine which reacquisition or
acquisition requests remain unresolved after one-hundred eighty (180) days.

(b) If the Requesting Party selects mediation (including non-binding arbitration) as the resolution
method, the following provisions will apply:

48

Source: VERIZON ABS LLC, 8-K, 1/23/2020
<!-- page 53 -->
(i) The mediation will be administered by JAMS pursuant to its Mediation Procedures in effect on the
date the arbitration is filed.

(ii) The mediator will be impartial, knowledgeable about and experienced with the laws of the State
of New York and an attorney specializing in commercial litigation with at least 15 years of
experience and who will be appointed from a list of neutrals maintained by JAMS. Upon being supplied
a list of at least 10 potential mediators by JAMS each party will have the right to exercise two
peremptory challenges within fourteen (14) days and to rank the remaining potential mediators in
order of preference JAMS will select the mediator from the remaining attorneys on the list
respecting the preference choices of the parties to the extent possible.

(iii) The parties will use commercially reasonable efforts to begin the mediation within thirty (30)
days of the selection of the mediator and to conclude the mediation within sixty (60) days of the
start of the mediation.

(iv) The fees and expenses of the mediation will be allocated as mutually agreed by the parties as
part of the mediation.

(c) If the Requesting Party selects binding arbitration as the resolution method, the following
provisions will apply:

(i) The arbitration will be administered by the AAA pursuant its Arbitration Rules in effect on the
date the arbitration is filed.

(ii) The arbitral panel will consist of three members, (i) one to be appointed by the Requesting
Party within five (5) Business Days of providing notice to the Depositor of its selection of
arbitration, (ii) one to be appointed by the Depositor within five (5) Business Days of that
appointment and (iii) the third, who will preside over the panel, to be chosen by the two
party-appointed arbitrators within five (5) Business Days of the second appointment. If any party
fails to appoint an arbitrator or the two party-appointed arbitrators fail to appoint the third
within the stated time periods, then the appointments will be made by AAA pursuant to the
Arbitration Rules. In each such case, each arbitrator will be impartial, knowledgeable about and
experienced with the laws of the State of New York and an attorney specializing in commercial
litigation with at least 15 years of experience.

(iii) Each arbitrator will be independent and will abide by the Code of Ethics for Arbitrators in
Commercial Disputes in effect as of the date of this Agreement. Prior to accepting an appointment,
each arbitrator must promptly disclose any circumstances likely to create a reasonable inference of
bias or conflict of interest or likely to preclude completion of the hearings within the prescribed
time schedule. Any arbitrator may be removed by AAA for cause consisting of actual bias, conflict of
interest or other serious potential for conflict.

(iv) After consulting with the parties, the arbitral panel will devise procedures and deadlines for
the arbitration, to the extent not already agreed to by the parties, with the goal of expediting the
proceeding and completing the arbitration within ninety (90)

49

Source: VERIZON ABS LLC, 8-K, 1/23/2020
<!-- page 54 -->
days after appointment. The arbitral panel will have the authority to schedule, hear, and determine
any and all motions, including dispositive and discovery motions, in accordance with then-prevailing
New York law (including prehearing and post hearing motions), and will do so on the motion of any
party to the arbitration.

(v) Notwithstanding whatever other discovery may be available under the Rules, unless otherwise
agreed by the parties, each party to the arbitration will be presumptively limited to the following
discovery in the arbitration: (A) four witness depositions not to exceed five hours, and (B) one set
of interrogations, document requests, and requests for admissions; provided that the arbitral panel
will have the ability to grant the parties, or either of them, additional discovery to the extent
that the arbitral panel determines good cause is shown that such additional discovery is reasonable
and necessary.

(vi) The arbitral panel will make its final determination no later than ninety (90) days after
appointment. The arbitral panel will resolve the dispute in accordance with the terms of this
Agreement, and may not modify or change this Agreement in any way. The arbitral panel will not have
the power to award punitive damages or consequential damages in any arbitration conducted by them.
In its final determination, the arbitral panel will determine and award the costs of the arbitration
(including the fees of the arbitral panel, cost of any record or transcript of the arbitration, and
administrative fees) and reasonable attorneys' fees to the parties as determined by the arbitral
panel in its reasonable discretion. The determination in any binding arbitration of the arbitral
panel will be in writing and counterpart copies will be promptly delivered to the parties. The
determination will be final and non-appealable and may be enforced in any court of competent
jurisdiction.

(vii) By selecting binding arbitration, the selecting party is giving up the right to sue in court,
including the right to a trial by jury.

(viii) No person may bring class or collective claims in arbitration even if the Arbitration Rules
would allow them. Notwithstanding anything herein to the contrary, the arbitral panel may award
money or injunctive relief in favor of the individual party seeking relief and only to the extent
necessary to provide relief warranted by that party's individual claim.

(d) The following provisions will apply to both mediations and arbitrations:

(i) Any mediation or arbitration will be held in New York, New York; and

(ii) The details and/or existence of any unfulfilled reacquisition or acquisition request, any
informal meetings, mediations or arbitration proceedings conducted under this Section 11.2,
including all offers, promises, conduct and statements, whether oral or written, made in the course
of the parties' attempt to informally resolve an unfulfilled reacquisition or acquisition request,
and any discovery taken in connection with any arbitration, will be confidential, privileged and
inadmissible for any purpose, including impeachment, in any mediation, arbitration or litigation, or
other proceeding (including

50

Source: VERIZON ABS LLC, 8-K, 1/23/2020
<!-- page 55 -->
any proceeding under this Section 11.2). This information will be kept strictly confidential and
will not be disclosed or discussed with any third party (excluding a party's attorneys, experts,
accountants and other agents and representatives, as reasonably required in connection with any
resolution procedure under this Section 11.2), except as otherwise required by law, regulatory
requirement or court order. If any party to a resolution procedure receives a subpoena or other
request for information from a third party (other than a governmental regulatory body) for such
confidential information, the recipient will promptly notify the other party to the resolution
procedure and will provide the other party with the opportunity to object to the production of its
confidential information.

[Remainder of Page Left Blank]

51

Source: VERIZON ABS LLC, 8-K, 1/23/2020
<!-- page 56 -->
IN WITNESS WHEREOF, the undersigned has caused this Agreement to be executed by its duly authorized
officer as of the date and year first above written.

VERIZON ABS LLC, as Depositor

By: Name: Title:

VERIZON OWNER TRUST 2020-A, as Issuer

By: Wilmington Trust, National Association, not in its individual capacity but solely as Owner
Trustee of Verizon Owner Trust 2020-A

By: Name: Title:

CELLCO PARTNERSHIP d/b/a VERIZON WIRELESS, as Servicer, Marketing Agent and Custodian

By: Name: Title:

Source: VERIZON ABS LLC, 8-K, 1/23/2020
<!-- page 57 -->
AGREED AND ACCEPTED BY:

U.S. BANK NATIONAL ASSOCIATION, not in its individual capacity but solely as Indenture Trustee

By: Name: Title:

Solely with respect to Section 4.1(f):

U.S. BANK NATIONAL ASSOCIATION, not in its individual capacity but solely as Securities Intermediary

By: Name: Title:

WILMINGTON TRUST, NATIONAL ASSOCIATION, not in its individual capacity but solely as Owner Trustee

By: Name: Title:

CELLCO PARTNERSHIP d/b/a VERIZON WIRELESS, solely with respect to the obligations set forth in
Section 7.1, in its individual capacity

By: Name: Title:

Source: VERIZON ABS LLC, 8-K, 1/23/2020
<!-- page 58 -->
CELLCO PARTNERSHIP d/b/a VERIZON WIRELESS, as Sponsor, solely with respect to the obligations set
forth in Section 3.5(a)(ii) and Section 9.9

By: Name: Title:

Source: VERIZON ABS LLC, 8-K, 1/23/2020

Schedule A

Schedule of Initial Receivables
<!-- page 59 -->
Delivered Electronically to Indenture Trustee at Closing

SA-1

Source: VERIZON ABS LLC, 8-K, 1/23/2020

Schedule B
<!-- page 60 -->
Notice Addresses

1. If to Cellco, in its individual capacity or as Servicer, Marketing Agent, Custodian or
Administrator:

Cellco Partnership One Verizon Way Basking Ridge, New Jersey 07920 Attention: Assistant Treasurer
Telephone: 908-559-5870 Email: kee.chan.sin@verizon.com

2. If to the Depositor:

Verizon ABS LLC One Verizon Way Basking Ridge, New Jersey 07920 Attention: Chief Financial Officer
Telephone: 908-559-5870 Email: kee.chan.sin@verizon.com

With a copy to:

Cellco Partnership One Verizon Way Basking Ridge, New Jersey 07920 Attention: Assistant Treasurer
Telephone: 908-559-5870 Email: kee.chan.sin@verizon.com

3. If to the Issuer:

c/o the Owner Trustee at the Corporate Trust Office of the Owner Trustee

With copies to:

Cellco Partnership One Verizon Way Basking Ridge, New Jersey 07920 Attention: Assistant Treasurer
Telephone: 908-559-5870 Email: kee.chan.sin@verizon.com

SB-1

Source: VERIZON ABS LLC, 8-K, 1/23/2020
<!-- page 61 -->
4. If to the Parent Support Provider:

Verizon Communications Inc. 1095 Avenue of the Americas New York, New York 10036 Attn: Assistant
Treasurer Telephone: 908-559-5870 Email: kee.chan.sin@verizon.com

5. If to the Owner Trustee, at the Corporate Trust Office of the Owner Trustee

6. If to the Indenture Trustee, at the Corporate Trust Office of the Indenture Trustee

7. If to S&P:

S&P Global Ratings 55 Water Street New York, New York 10041 Attention: Asset Backed Surveillance
Department Telephone: (212) 438-1000 Fax: (212) 438-2649

8. If to Moody's:

Moody's Investors Service, Inc. ABS Monitoring Department 7 World Trade Center 250 Greenwich Street
New York, New York 10007 Email: abssurveillance@moodys.com

9. If to the Cap Counterparty:

Bank of America Merrill Lynch 1133 Avenue of the Americas 42nd Floor, NY1-533-42-01 New York, NY
10036-6710 Attention: Agreements & Documentation Facsimile No.: (212) 548-8622

With a copy to: dg.dg_gmg_cid_fax_notices@bofasecurities.com

10. If to the Asset Representations Reviewer:

Pentalpha Surveillance LLC 375 N French Rd Suite 100 Amherst NY 14228

SB-2

Source: VERIZON ABS LLC, 8-K, 1/23/2020
<!-- page 62 -->
Attention: VZOT 2020-A Transaction Manager Telephone: (716) 418-1634 Fax: (716) 204-5902 Email:
notices@pentalphasurveillance.com (with VZOT 2020-A in the subject line)

SB-3

Source: VERIZON ABS LLC, 8-K, 1/23/2020

Appendix A
<!-- page 63 -->
Usage and Definitions

Verizon Owner Trust 2020-A

Usage

The following usage rules apply to this Appendix, any document that incorporates this Appendix and
any document delivered under any such document:

(a) The term "document" includes any document, agreement, instrument, certificate, notice, report,
statement or other writing, whether in electronic or physical form.

(b) Accounting terms not defined or not completely defined in this Appendix will have the meanings
given to them under generally accepted accounting principles, international financial reporting
standards or other applicable accounting principles in effect in the United States on the date of
the document that incorporates this Appendix.

(c) References to "Article," "Section," "Exhibit," "Schedule," "Appendix" or another subdivision of
or to an attachment are, unless otherwise stated, to an article, section, exhibit, schedule,
appendix or subdivision of or an attachment to the document in which the reference appears.

(d) Any document defined or referred to in this Appendix or in any document that incorporates this
Appendix means the document as amended, modified, supplemented, restated or replaced, including by
waiver or consent, and includes all attachments to and instruments incorporated in the document.

(e) Any statute defined or referred to in this Appendix or in any document that incorporates this
Appendix means the statute as amended, modified, supplemented, restated or replaced, including by
succession of comparable successor statute, and includes any rules and regulations under the statute
and any judicial and administrative interpretations of the statute.

(f) References to "law" or "applicable law" in this Appendix or in any document that incorporates
this Appendix include all rules and regulations enacted under such law.

(g) The calculation of any amount as of a Cutoff Date or any other day, unless otherwise stated,
will be determined as of the end of that calendar day after the application or processing of any
funds, payments and other transactions on that day.

(h) References to deposits, transfers and payments of any funds refer to deposits, transfers or
payments of such funds in immediately available funds.

(i) The terms defined in this Appendix apply to the singular and plural forms of those terms.

A-1

Source: VERIZON ABS LLC, 8-K, 1/23/2020
<!-- page 64 -->
(j) The term "including" means "including without limitation."

(k) References to a Person are also to its permitted successors and assigns, whether in its
individual or representative capacity.

(l) In the computation of periods of time from one date to or through a later date, the word "from"
means "from and including," the word "to" means "to but excluding," and the word "through" means "to
and including."

(m) Except where "not less than zero" or similar language is indicated, amounts determined by
reference to a mathematical formula may be positive or negative.

(n) References to a month, quarter or year are, unless otherwise stated, to a calendar month,
calendar quarter or calendar year.

(o) No Person will be deemed to have "knowledge" of a particular event or occurrence for purposes of
any document that incorporates this Appendix, unless either (i) a Responsible Person of the Person
has actual knowledge of the event or occurrence or (ii) the Person has received notice of the event
or occurrence according to any Transaction Document.

Definitions

"60-Day Delinquent Receivable" means, for any date of determination, a Receivable for which there
are unpaid charges remaining on the account sixty (60) days after the bill's date due; provided that
a Written-Off Receivable is not considered a 60-Day Delinquent Receivable.

"AAA" means the American Arbitration Association.

"Account Control Agreement" means the Account Control Agreement, dated as of the Closing Date, among
the Issuer, as grantor, the Indenture Trustee, as secured party, and U.S. Bank National Association,
in its capacity as both a "securities intermediary" as defined in Section 8- 102 of the UCC and a
"bank" as defined in Section 9-102 of the UCC, as amended, restated, supplemented or modified from
time to time.

"Accrued Note Interest" means, for a Class and a Payment Date, the sum of the Note Monthly Interest
and the Note Interest Shortfall.

"Acquired Receivable" means, for a Collection Period, a Receivable (a) acquired by the Servicer
under Section 3.3 of the Transfer and Servicing Agreement, (b) acquired by the Marketing Agent under
Section 4.3(i) of the Transfer and Servicing Agreement, (c) reacquired by an Originator under
Section 3.4 or 4.6 of the Originator Receivables Transfer Agreement, or (d) acquired by the Servicer
under Section 3.4 or 4.7 of the Master Trust Receivables Transfer Agreement and for which, in each
case, the acquisition or reacquisition is effective during the Collection Period and the Acquisition
Amount is included in Available Funds for the related Payment Date.

A-2

Source: VERIZON ABS LLC, 8-K, 1/23/2020
<!-- page 65 -->
"Acquisition Account" means the subaccount of the Collection Account established under Section
4.1(a) of the Transfer and Servicing Agreement.

"Acquisition Amount" means, for an Acquired Receivable for which the Acquisition Amount is to be
included in Available Funds for a Payment Date, the excess of (i) the present value of the Principal
Balance of the Receivable as of the last day of the Collection Period immediately preceding the
related Collection Period (calculated using the Discount Rate on the basis of a 360-day year of
twelve 30-day months and assuming each amount is received at the end of the Collection Period in
which the amount is scheduled to be received) over (ii) all cash collections and any other cash
proceeds received by the Issuer on the related Receivable from (but excluding) the last day of the
Collection Period immediately preceding the related Collection Period to the day on which such
Receivable becomes an Acquired Receivable.

"Acquisition Date" means each date during the Revolving Period on which the Issuer acquires
Additional Receivables under Section 2.1(b) of the Transfer and Servicing Agreement and the
Depositor acquires Additional Receivables under Section 2.1(b) of the Originator Receivables
Transfer Agreement or Section 2.1(a) of the Master Trust Receivables Transfer Agreement; provided
that there shall be no more than five (5) Acquisition Dates in any calendar month.

"Acquisition Date Supplement" means, for any Collection Period that includes an Acquisition Date,
the supplement (which may be incorporated into the Monthly Investor Report) delivered by the
Servicer setting forth (a) the aggregate Principal Balance as of the Cutoff Date for the Additional
Receivables transferred by the Issuer, (b) the Additional Receivables Transfer Amount for such
Acquisition Date, (c) the amount in the Acquisition Account on such Acquisition Date, (d) the Yield
Supplement Overcollateralization Amount for such Acquisition Date and (e) the results of the Credit
Enhancement Test, the Pool Composition Tests and the Floor Credit Enhancement Composition Tests as
of such Acquisition Date.

"Acquisition Deposit Amount" means, for any Payment Date during the Revolving Period, an amount
equal to (a) the Required Acquisition Deposit Amount minus (b) the amount on deposit in the
Acquisition Account on such Payment Date (before payments under Section 8.2(c) of the Indenture on
that Payment Date).

"Additional Originator" has the meaning stated in Section 6.11 of the Originator Receivables
Transfer Agreement.

"Additional Receivable" means any device payment plan agreement acquired by the Issuer on an
Acquisition Date and listed on the Schedule of Receivables attached to a Transfer Notice delivered
to the Issuer and the Indenture Trustee in connection with such Acquisition Date.

"Additional Receivables Cash Transfer Amount" means, for an Acquisition Date, the lesser of (x) the
Additional Receivables Transfer Amount and (y) the amount on deposit in the Acquisition Account on
such Acquisition Date.

A-3

Source: VERIZON ABS LLC, 8-K, 1/23/2020
<!-- page 66 -->
"Additional Receivables Transfer Amount" means, for an Acquisition Date, an amount equal to the
discounted present value of the remaining payments (after the end of the calendar day on the related
Cutoff Date) for the remaining term of such Additional Receivable discounted using the Discount
Rate.

"Additional Successor Servicer Fee" means, for any Payment Date, the excess, if any, of (x) $425,000
over (y) the Servicing Fee.

"Additional Trust Property" means, for any Acquisition Date, (a) the Depositor Transferred Property
for that Acquisition Date, (b) all present and future claims, demands, causes of action and choses
in action for any of the foregoing, and (c) all payments on or under and all proceeds for any of the
foregoing.

"Adjusted Pool Balance" means, on the Closing Date, an amount equal to:

(a) the Initial Pool Balance; minus (b) the Yield Supplement Overcollateralization Amount for the
Closing Date;

and means, on a Payment Date or Acquisition Date, an amount (not less than zero) equal to:

(a) the Pool Balance as of the last day of the Collection Period immediately preceding such Payment
Date or Acquisition Date; minus (b) the Yield Supplement Overcollateralization Amount for such
Payment Date or Acquisition Date.

"Administration Agreement" means the Administration Agreement, dated as of the Closing Date, between
the Administrator and the Issuer, as amended, restated, supplemented or modified from time to time.

"Administrator" means Cellco, in its capacity as administrator under the Administration Agreement.

"Adverse Claim" means any Lien other than a Permitted Lien.

"Affiliate" means, for a specified Person (other than a natural Person), (a) another Person
controlling, controlled by or under common control with the specified Person, (b) any other Person
beneficially owning or controlling more than fifty percent (50%) of the outstanding voting
securities or rights of or interest in the capital, distributions or profits of the specified Person
or (c) any controlling shareholder of, or partner in, the specified Person. For the purposes of this
definition, "control" when used with respect to any Person means the direct or indirect possession
of the power to direct or cause the direction of the management or policies of the Person, whether
through ownership, by contract, arrangement or understanding, or otherwise.

"Amortization Event" means the occurrence of any of the following:

A-4

Source: VERIZON ABS LLC, 8-K, 1/23/2020
<!-- page 67 -->
(a) the Issuer fails on a Payment Date during the Revolving Period to (i) pay the Accrued Note
Interest on the Notes, (ii) have the Required Reserve Amount on deposit in the Reserve Account or
(iii) have the Required Negative Carry Amount on deposit in the Negative Carry Account;

(b) for any Payment Date, the sum of the fractions, expressed as percentages for each of the three
Collection Periods immediately preceding such Payment Date, calculated by dividing the aggregate
Principal Balance of Written-Off Receivables during each of those Collection Periods by the Pool
Balance as of the first day of each of those Collection Periods, multiplied by four, exceeds 10.00%,
as determined by the Servicer at least two (2) Business Days before each Payment Date;

(c) for any Payment Date, the sum of the fractions, expressed as percentages for each of the three
Collection Periods immediately preceding such Payment Date, calculated by dividing the aggregate
Principal Balance of all Receivables that are ninety-one (91) days or more Delinquent at the end of
each of those Collection Periods by the Pool Balance as of the last day of each of those Collection
Periods, divided by three, exceeds 2.00%, as determined by the Servicer at least two (2) Business
Days before each Payment Date;

(d) the Adjusted Pool Balance is less than 50.00% of the aggregate Note Balance of the Notes;

(e) on any Payment Date, after giving effect to all payments to be made on such Payment Date
pursuant to Section 8.2 of the Indenture and the acquisition of Additional Receivables on that date,
the amount of Overcollateralization for the Notes is not at least equal to the Overcollateralization
Target Amount; provided, that if the Overcollateralization Target Amount is not reached on any
Payment Date solely due to a change in the percentage used to calculate such Overcollateralization
Target Amount, such an event will not constitute an "Amortization Event" unless the
Overcollateralization Target Amount is not reached by the end of the third month after the related
Payment Date;

(f) a Servicer Termination Event has occurred and is continuing; or

(g) an Event of Default has occurred and is continuing.

"Amortization Period" means the Payment Date beginning on the earlier of (i) the Payment Date in
February 2022 or (ii) the Payment Date on or immediately following the date on which an Amortization
Event occurs and ending on the earlier of (a) the Payment Date on which each Class of Notes have
been paid in full and (b) the Final Maturity Date.

"Amount Financed" means, for a Receivable, the amount of credit provided to the Obligor for the
purchase of the related Device.

A-5

Source: VERIZON ABS LLC, 8-K, 1/23/2020
<!-- page 68 -->
"Annual Percentage Rate" or "APR" of a Receivable means the annual rate of finance charges stated in
the Receivable or in any federal Truth-in-Lending Act correction notice related to the Receivable.

"Annual Upgrade Offer" means the annual upgrade offer extended by Verizon Wireless as of the date
hereof to an existing Obligor under which such Obligor can upgrade certain specified Devices that
are the subject of a device payment plan agreement if the following terms and conditions specified
in such offer are satisfied:

• The customer may be able to upgrade an eligible device for a new qualifying device after thirty
(30) days provided that such customer has paid at least 50% of the retail price of the eligible
device under the related device payment plan agreement and returns such eligible device to Verizon
Wireless in good working condition with no significant damage as determined by Verizon Wireless;

• The customer is required to purchase a new qualifying device under a new device payment plan
agreement. New device purchases are subject to then-available offers and any associated wireless
service requirements;

• A customer's account must be in good standing and such customer must satisfy Verizon Wireless'
eligibility requirements for a new device payment plan agreement;

• Upon entering into a device payment plan agreement for a new qualifying device, and after
returning the eligible device to Verizon Wireless within fourteen (14) days, Verizon Wireless will
agree, for the benefit of such customer and for the express benefit of any assignee of such
customer's original device payment plan agreement, to acquire such customer's eligible device for
the remaining balance of the related customer's original device payment plan agreement and pay off
and settle that remaining balance. After Verizon Wireless does that, such customer's only remaining
obligations will be under the new device payment plan agreement and for associated wireless service;

• If a customer does not return an eligible device when upgrading, or if it is not returned to
Verizon Wireless in good working condition, in each case the remaining balance under such customer's
original device payment plan agreement will be due on such customer's next bill. Good working
condition requires, among other things, that the customer's returned device powers on and off, does
not have a cracked screen, has no significant damage as determined by Verizon Wireless, and has all
password-protected security features (e.g., Find My iPhone) turned off;

• The Annual Upgrade Offer and the related terms and conditions may be modified or terminated by
Verizon Wireless at any time. A customer's upgrade eligibility will be determined in the sole
discretion of Verizon Wireless. If the Annual Upgrade Offer is terminated or the related terms and
conditions are not satisfied, a customer will remain responsible for the remaining balance due under
the original device payment plan agreement.

A-6

Source: VERIZON ABS LLC, 8-K, 1/23/2020
<!-- page 69 -->
"Applicable Anti-Money Laundering Law" has the meaning stated in Section 6.8 of the Trust Agreement.

"Arbitration Rules" means the AAA's Commercial Arbitration Rules and Mediation Procedures.

"Asset Representations Review" means, following the occurrence of a Delinquency Trigger, the review
of 60-Day Delinquent Receivables to be undertaken by the Asset Representations Reviewer pursuant to
the terms of the Asset Representations Review Agreement.

"Asset Representations Review Agreement" means the Asset Representations Review Agreement, dated as
of the Closing Date, among the Asset Representations Reviewer, the Issuer, the Servicer and the
Administrator.

"Asset Representations Reviewer" means Pentalpha Surveillance LLC, or any successor Asset
Representations Reviewer under the Asset Representations Review Agreement.

"Asset Representations Reviewer Fee" means (i) a monthly fee equal to $416.67 per month, payable on
each Payment Date, and (ii) the amount of any fee payable to the Asset Representations Reviewer in
connection with its review of 60-Day Delinquent Receivables in accordance with the terms of the
Asset Representations Review Agreement.

"Assumed Amortization Schedule" means, for each class of Notes, an amortization that results in the
Note Balance for such class on any future Payment Date being equal to the percentage of the initial
Note Balance of such class shown in the decrement table for such class set forth under "Maturity and
Prepayment Considerations-Weighted Average Life" in the Prospectus, using a prepayment assumption
percentage of 100% and assuming exercise of the Optional Acquisition on the earliest applicable
Payment Date.

"Authenticating Agent" has the meaning stated in Section 2.14(a) of the Indenture.

"Available Funds" means, for a Payment Date, the sum of the following amounts for the Payment Date
(without duplication):

(a) Collections on the Receivables (other than Temporarily Excluded Receivables) for the related
Collection Period in the Collection Account; plus

(b) Acquisition Amounts received on Receivables that became Acquired Receivables during the related
Collection Period and any amounts in respect of Acquisition Amounts paid by the Parent Support
Provider; plus

(c) Credit Payments received on Receivables from the Marketing Agent or the related Originators
during the related Collection Period and any amounts in respect of Credit Payments paid by the
Parent Support Provider; plus

A-7

Source: VERIZON ABS LLC, 8-K, 1/23/2020
<!-- page 70 -->
(d) Upgrade Payments received from the Marketing Agent or the related Originators on Receivables
subject to an Upgrade Offer during the related Collection Period and any amounts in respect of
Upgrade Payments paid by the Parent Support Provider; plus

(e) any amounts deposited by the Class A Certificateholder to acquire the Receivables on the Payment
Date under Section 8.1 of the Transfer and Servicing Agreement or any amounts received by the Issuer
from a transferee of the Receivables under Section 8.2 of the Transfer and Servicing Agreement; plus

(f) the Negative Carry Account Draw Amount, if any; plus

(g) the Reserve Account Draw Amount, if any, and, after withdrawing the Reserve Account Draw Amount
from the Reserve Account, any amount in excess of the Required Reserve Amount remaining on deposit
in the Reserve Account; plus

(h) the amount, if any, deposited into the Collection Account from the Negative Carry Account and,
on the first Payment Date during the Amortization Period, the entire amount on deposit in the
Negative Carry Account and the Acquisition Account; plus

(i) any Cap Payment paid by the Cap Counterparty to the Issuer under the Cap Agreement and deposited
into the Collection Account.

"Bank Accounts" means the Collection Account, the Reserve Account, the Acquisition Account and the
Negative Carry Account.

"Bankruptcy Action" has the meaning stated in Section 5.5 of the Trust Agreement.

"Bankruptcy Code" means the United States Bankruptcy Code, 11 U.S.C. 101 et seq.

"Bankruptcy Surrendered Receivable" means any Receivable that is secured by the related Device and
is not a Written-Off Receivable for which (i) the related Obligor has entered into a bankruptcy
proceeding and (ii) the Servicer has accepted the surrender of the related Device in satisfaction of
the Receivable.

"Benchmark" means, initially, One-Month LIBOR; provided that if a Benchmark Transition Event and its
related Benchmark Replacement Date have occurred with respect to One-Month LIBOR or the then-current
Benchmark, then "Benchmark" means the applicable Benchmark Replacement.

"Benchmark Administrator" means, (1) with respect to One-Month LIBOR, the ICE Benchmark
Administration Limited, (2) with respect to SOFR, the Federal Reserve Bank of New York and (3) with
respect to any other Benchmark, the entity responsible for administration of such Benchmark (or in
each case, any successor administrator).

A-8

Source: VERIZON ABS LLC, 8-K, 1/23/2020
<!-- page 71 -->
"Benchmark Replacement" means the first alternative set forth in the order below that can be
determined by the Administrator as of the Benchmark Replacement Date:

(1) the sum of (a) Term SOFR and (b) the Benchmark Replacement Adjustment, provided that there has
been no official public statement or publication of information by the Benchmark Administrator or
the regulatory supervisor for the Benchmark Administrator announcing that Term SOFR is not yet
representative that has not been either withdrawn or superseded by a similar official public
statement or publication that Term SOFR has become representative,

(2) the sum of (a) Compounded SOFR and (b) the Benchmark Replacement Adjustment,

(3) the sum of (a) the ISDA Fallback Rate and (b) the Benchmark Replacement Adjustment,

(4) the sum of (a) the alternate rate of interest that has been selected or recommended by the
Relevant Governmental Body as the replacement for the then-current Benchmark for the applicable
Corresponding Tenor and (b) the Benchmark Replacement Adjustment, and

(5) the sum of (a) the alternate rate of interest that has been selected by the Administrator in its
reasonable discretion as the replacement for the then-current Benchmark for the applicable
Corresponding Tenor and (b) the Benchmark Replacement Adjustment.

"Benchmark Replacement Adjustment" means the first alternative set forth in the order below that can
be determined by the Administrator as of the Benchmark Replacement Date:

(1) the spread adjustment, or method for calculating or determining such spread adjustment (which
may be a positive or negative value or zero), that has been selected or recommended by the Relevant
Governmental Body for the applicable Unadjusted Benchmark Replacement,

(2) if the applicable Unadjusted Benchmark Replacement is equivalent to the ISDA Fallback Rate, then
the ISDA Fallback Adjustment, and

(3) the spread adjustment (which may be a positive or negative value or zero) that has been selected
by the Administrator in its reasonable discretion for the replacement of the then-current Benchmark
with the applicable Unadjusted Benchmark Replacement.

"Benchmark Replacement Conforming Changes" means, with respect to any Benchmark Replacement, any
technical, administrative or operational changes (including changes to the timing and frequency of
determining rates and making payments of interest, and other administrative matters) that the
Administrator decides in its reasonable discretion may be appropriate to reflect the adoption of
such Benchmark Replacement in a manner substantially consistent with market practice (or, if the
Administrator decides that adoption of any portion of such market practice is not administratively
feasible or if the Administrator determines that no

A-9

Source: VERIZON ABS LLC, 8-K, 1/23/2020
<!-- page 72 -->
market practice for use of the Benchmark Replacement exists, in such other manner as the
Administrator determines in its reasonable discretion is reasonably necessary).

"Benchmark Replacement Date" means:

(1) in the case of clause (1) or (2) of the definition of "Benchmark Transition Event", the later of
(a) the date of the related official public statement or publication of information referenced
therein and (b) the date on which the applicable Benchmark Administrator permanently or indefinitely
ceases to provide the Benchmark, or

(2) in the case of clause (3) of the definition of "Benchmark Transition Event", the date of the
official public statement or publication of information.

For the avoidance of doubt, if the event giving rise to the Benchmark Replacement Date occurs on the
same day as, but earlier than, the Reference Time in respect of any determination, the Benchmark
Replacement Date shall be deemed to have occurred prior to the Reference Time for such
determination.

"Benchmark Transition Event" means the occurrence of one or more of the following events with
respect to the then-current Benchmark:

(1) an official public statement or publication of information by or on behalf of the Benchmark
Administrator announcing that such Benchmark Administrator has ceased or will cease to provide the
Benchmark, permanently or indefinitely; provided, that, at the time of such statement or
publication, there is no successor Benchmark Administrator that will continue to provide the
Benchmark,

(2) an official public statement or publication of information by the regulatory supervisor for the
Benchmark Administrator, the central bank for the currency of the Benchmark, an insolvency official
with jurisdiction over the Benchmark Administrator, a resolution authority with jurisdiction over
the Benchmark Administrator or a court or an entity with similar insolvency or resolution authority
over the Benchmark Administrator, which states that the Benchmark Administrator has ceased or will
cease to provide the Benchmark permanently or indefinitely; provided, that, at the time of such
statement or publication, there is no successor Benchmark Administrator that will continue to
provide the Benchmark, or

(3) an official public statement or publication of information by the regulatory supervisor for the
Benchmark Administrator announcing that the Benchmark is no longer representative.

"Beneficiary" has the meaning stated in the Parent Support Agreement.

"Benefit Plan" means an "employee benefit plan" as defined in Section 3(3) of ERISA, which is
subject to the provisions of Title I of ERISA, a "plan" described in and subject to

A-10

Source: VERIZON ABS LLC, 8-K, 1/23/2020
<!-- page 73 -->
Section 4975 of the Code, an entity whose underlying assets include "plan assets" by reason of an
employee benefit plan's or plan's investment in the entity or any other employee benefit plan that
is subject to any Similar Law.

"Book-Entry Note" means any of the Notes issued in book-entry form under Section 2.12 of the
Indenture.

"Business Day" means any day other than (a) a Saturday, Sunday or other day on which banks in New
York, New York or any jurisdiction in which the Corporate Trust Office of the Indenture Trustee or
the Owner Trustee is located are authorized or required to close or (b) a holiday on the Federal
Reserve calendar.

"Cap Agreement" means the interest rate cap agreement relating to the Class A-1b Notes consisting of
the 2002 ISDA Master Agreement (Multicurrency Cross-Border), schedule and credit support annex, each
dated as of January 24, 2020, and the confirmation, dated on or about January 23, 2020, in each
case, between the Issuer and the Cap Counterparty, as such agreement may be amended and supplemented
from time to time in accordance with its terms.

"Cap Collateral Account" means the account or accounts, if any, established under Section 9.10 of
the Transfer and Servicing Agreement as required by the terms of the Cap Agreement.

"Cap Counterparty" means Bank of America, N.A., or any Eligible Replacement Cap Counterparty, to the
extent such Eligible Replacement Cap Counterparty replaces the existing Cap Counterparty under the
Cap Agreement or any replacement interest rate cap agreement.

"Cap Custodian" has the meaning stated in Section 9.10 of the Transfer and Servicing Agreement.

"Cap Payment" means, for any Interest Period in which One-Month LIBOR (calculated in accordance with
the Cap Agreement) exceeds 3.00%, an amount equal to the product of (x) the excess, if any, of
One-Month LIBOR (calculated in accordance with the Cap Agreement) for the related Payment Date over
3.00%, (y) the notional amount of the cap for such Payment Date, as set forth in the Cap Agreement,
and (z) a fraction, the numerator of which is the actual number of days elapsed in such Interest
Period and the denominator of which is 360, which payment shall be deposited into the Collection
Account by the Cap Counterparty on or before the second Business Day preceding the related Payment
Date.

"Cellco" means Cellco Partnership d/b/a Verizon Wireless, a Delaware general partnership, doing
business as Verizon Wireless.

"Certificate" means either the Class A Certificate or the Class B Certificate, as the context
requires.

"Certificate Distribution Account" means the account established and maintained as such pursuant to
Section 4.1 of the Trust Agreement.

A-11

Source: VERIZON ABS LLC, 8-K, 1/23/2020
<!-- page 74 -->
"Certificate of Trust" means the Certificate of Trust of Verizon Owner Trust 2020-A.

"Certificate Paying Agent" means initially the Owner Trustee and any other Person appointed as
Certificate Paying Agent under Section 3.11 of the Trust Agreement.

"Certificateholder" means the registered holder of a Certificate.

"Class" means the Class A-1a Notes, the Class A-1b Notes, the Class B Notes and the Class C Notes,
as applicable.

"Class A Certificate" means the Class A Certificate executed by the Issuer and authenticated by the
Owner Trustee, evidencing a portion of the Equity Interest in the Issuer, substantially in the form
attached as Exhibit B-1 to the Trust Agreement.

"Class A Certificateholder" means collectively, the Originators or their designee.

"Class A Notes" means, collectively, the Class A-1a Notes and the Class A-1b Notes.

"Class A-1a Notes" means the $1,325,700,000 Class A-1a 1.85% Asset Backed Notes issued by the
Issuer, substantially in the form of Exhibit A to the Indenture.

"Class A-1b Notes" means the $100,000,000 Class A-1b One-Month LIBOR (or, upon the occurrence of a
Benchmark Transition Event, the appropriate Benchmark Replacement) + 0.27% Asset Backed Notes issued
by the Issuer, substantially in the form of Exhibit A to the Indenture.

"Class B Certificate" means the variable funding certificate executed by the Issuer and
authenticated by the Owner Trustee, substantially in the form attached as Exhibit B-2 to the Trust
Agreement.

"Class B Certificate Principal Balance" means (i) on the Closing Date, $0, (ii) on any Acquisition
Date, an amount equal to the excess, if any, of the Additional Receivables Transfer Amount for the
Additional Receivables to be acquired by the Issuer on such Acquisition Date over the Additional
Receivables Cash Transfer Amount for such Additional Receivables, and (iii) during the Amortization
Period, $0; provided, that, with respect to clause (ii), immediately following the acquisition by
the Depositor of Additional Receivables from the Originators on any Acquisition Date, and upon
distribution by the Depositor to the Originators of the amounts set forth in Section 2.2(b) of the
Originator Receivables Transfer Agreement, the Class B Certificate Principal Balance will be
decreased to zero for such date.

"Class B Certificateholder" means the Depositor or its designee.

"Class B Notes" means the $98,300,000 Class B 1.98% Asset Backed Notes issued by the Issuer,
substantially in the form of Exhibit A to the Indenture.

"Class C Notes" means the $76,000,000 Class C 2.06% Asset Backed Notes issued by the Issuer,
substantially in the form of Exhibit A to the Indenture.

A-12

Source: VERIZON ABS LLC, 8-K, 1/23/2020
<!-- page 75 -->
"Clean-Up Redemption" has the meaning stated in Section 8.1(a) of the Transfer and Servicing
Agreement.

"Clearing Agency" means an organization registered as a "clearing agency" under Section 17A of the
Exchange Act.

"Closing Date" means January 29, 2020.

"Code" means the Internal Revenue Code of 1986, as amended.

"Collateral" means (a) the Trust Property, (b) all present and future claims, demands, causes of
action and choses in action relating to the Trust Property and (c) all payments on or under and all
proceeds of the Trust Property.

"Collection Account" means the account or accounts established under Section 4.1(a) of the Transfer
and Servicing Agreement.

"Collection Period" means each calendar month. For a Payment Date, the related Collection Period
means (i) for any Payment Date other than the initial Payment Date, the Collection Period
immediately preceding the month in which the Payment Date occurs, or (ii) for the initial Payment
Date, the period from the end of the calendar day on the Initial Cutoff Date and ending on and
including the last day of the month immediately preceding the initial Payment Date. For purposes of
determining the Principal Balance, Pool Balance or Note Pool Factor, the related Collection Period
is the month in which the Principal Balance, Pool Balance or Note Pool Factor is determined.

"Collections" means, for a Collection Period, all cash collections received from Obligors and any
other cash proceeds (whether in the form of cash, wire transfer or check) in respect of the
Receivables received and applied by the Servicer to the payment of the Receivables during that
Collection Period, but excluding:

(i) the Supplemental Servicing Fee;

(ii) amounts on any Receivable for which the Acquisition Amount is included in the Available Funds
for the related Payment Date; and

(iii) any Recoveries or cash collections received with respect to Written-Off Receivables that were
written-off before or during such Collection Period.

"Commission" means the U.S. Securities and Exchange Commission, and any successor thereto.

"Comparable Treasury Issue" means the United States Treasury security selected by the Independent
Investment Banker as having a maturity comparable to the remaining term, referred to as the
Remaining Life, of the Notes to be redeemed that would be utilized, at the time of

A-13

Source: VERIZON ABS LLC, 8-K, 1/23/2020
<!-- page 76 -->
selection and in accordance with customary financial practice, in pricing new issues of corporate
debt securities of comparable maturity to the remaining term of the Notes.

"Comparable Treasury Price" means (1) the average of three Reference Treasury Dealer Quotations for
that date of redemption, or (2) if the Independent Investment Banker is unable to obtain three
Reference Treasury Dealer Quotations, the average of all quotations obtained.

"Compounded SOFR" means the compounded average of SOFRs for the applicable Corresponding Tenor, with
the rate, or methodology of this rate, and conventions of this rate (which, for example, may be
compounded in arrears with a lookback and/or suspension period as a mechanism to determine the
interest amount payable prior to the end of each Collection Period or compounded in advance) being
established by the Administrator in accordance with:

(1) the rate, or methodology of this rate, and conventions of this rate selected or recommended by
the Relevant Governmental Body for determining compounded SOFR; provided that

(2) if, and to the extent that, the Administrator determines that Compounded SOFR cannot be
determined in accordance with clause (1) above, then the rate, or methodology of this rate, and
conventions of this rate that have been selected by the Administrator in its reasonable discretion.

"Control Agreement" has the meaning stated in Section 9.10 of the Transfer and Servicing Agreement.

"Controlling Class" means (a) the Outstanding Class A Notes, voting together as a single class, (b)
if no Class A Notes are Outstanding, the Outstanding Class B Notes and (c) if no Class B Notes are
Outstanding, the Outstanding Class C Notes.

"Corporate Trust Office" means,

(a) for the Owner Trustee:

Rodney Square North, 1100 North Market Street Wilmington, Delaware 19890-1600 Attn: Corporate Trust
Administration Telephone: 302-636-6704 Fax: 302-636-4141

or at another address in the State of Delaware as the Owner Trustee may notify the Indenture
Trustee, the Administrator and the Depositor,

(b) for the Indenture Trustee, the office of the Indenture Trustee at which at any particular time
its corporate trust business shall be administered which office on the date of the execution of the
Indenture is located at:

A-14

Source: VERIZON ABS LLC, 8-K, 1/23/2020
<!-- page 77 -->
(i) solely for the purposes of transfer, surrender, exchange or presentation for final payment:

EP-MN-WS2N 111 Fillmore Avenue East St. Paul, MN 55107, Attn: Bondholder Services/VZOT 2020-A

and (ii) for all other purposes:

MK-IL-SL7C 190 South LaSalle Street Chicago, Illinois 60603 Attention: Global Structured
Finance/VZOT 2020-A Fax: (312) 332-7992

or at such other address as the Indenture Trustee may designate from time to time by notice to the
Noteholders, the Servicer, and the Owner Trustee, or the principal corporate trust office of any
successor Indenture Trustee (the address of which the successor Indenture Trustee will notify the
Noteholders, the Servicer and the Owner Trustee), and

(c) for the Master Trust Owner Trustee:

Rodney Square North, 1100 North Market Street Wilmington, Delaware 19890-1600 Attn: Corporate Trust
Administration Telephone: 302-636-6704 Fax: 302-636-4141

or at another address in the State of Delaware as the Master Trust Owner Trustee may notify the
Indenture Trustee, the Administrator, the Owner Trustee and the Depositor.

"Corresponding Tenor" means a tenor (including overnight) having approximately the same length
(disregarding business day adjustment) as the applicable tenor for the then-current Benchmark.

"Covered Entity" and "Covered Entities" have the meanings stated in Section 1(a) of the Parent
Support Agreement.

"Credit" means any payment credit (including one-time upfront credits and contingent, recurring
credits), including the application of a returned security deposit, allocated to the account of an
Obligor that is applied by the Servicer against amounts due on the Obligor's related invoice.

"Credit Enhancement Test" means the test that will be satisfied on the Closing Date and on each
Acquisition Date, after giving effect to all payments required to be made under Section 8.2(c) of
the Indenture and the acquisition of Additional Receivables on the Acquisition Date, if

A-15

Source: VERIZON ABS LLC, 8-K, 1/23/2020
<!-- page 78 -->
(a) (i) the Adjusted Pool Balance as of the end of the Collection Period immediately preceding the
Closing Date or such Acquisition Date, as applicable, plus (ii) any amounts on deposit in the
Acquisition Account minus (iii) the Overcollateralization Target Amount, is equal to or greater than
(b) the aggregate Note Balance on that date.

"Credit Payment" means, with respect to any Collection Period, an amount equal to the reduction in
the amount owed by an Obligor under a Receivable due to the application of any Credits to such
Obligor's account that would have otherwise constituted Collections during such Collection Period.

"Custodian" means Cellco, in its capacity as custodian of the Receivable Files.

"Customer Tenure" means the number of months an Obligor has had a Verizon Wireless account based on
the oldest active account establishment date for such Obligor, inclusive of any periods of up to
fifty (50) days of disconnected service, up to ninety (90) days of suspended service or longer
service suspensions in connection with the Servicemembers Civil Relief Act, as amended.

"Cutoff Date" means (a) for the Initial Receivables, the Initial Cutoff Date and (b) for any
Additional Receivables, the end of the calendar day on the last day of the month immediately
preceding the month in which such Acquisition Date occurs.

"Default" means any event that with notice or the passage of time or both would become an Event of
Default.

"Definitive Notes" has the meaning stated in Section 2.13 of the Indenture.

"Delaware Statutory Trust Act" means Chapter 38 of Title 12 of the Delaware Code.

"Delinquent" means an account on which an Obligor has unpaid charges remaining on the related
account on the day immediately following the related date due as indicated on the Obligor's bill.

"Delinquency Trigger" means, with respect to a Collection Period, the aggregate Principal Balance of
60-Day Delinquent Receivables as a percentage of the aggregate Principal Balance of Receivables as
of the end of such Collection Period exceeds the Delinquency Trigger Percentage for such Collection
Period.

"Delinquency Trigger Percentage" equals (i) during the Revolving Period, 5.0% and (ii) during the
Amortization Period, 5.5%.

"Depositor" means Verizon ABS LLC, a Delaware limited liability company.

"Depositor Transferred Property" means, for the Closing Date and any Acquisition Date, (a) the
Originator Transferred Property, (b) the Master Trust Transferred Property, (c) the Depositor's
rights under the Receivables Transfer Agreements, (d) all present and future claims,

A-16

Source: VERIZON ABS LLC, 8-K, 1/23/2020

demands, causes of action and choses in action relating to any of the property described above and
(e) all payments on or under and all proceeds of the property described above.
<!-- page 79 -->
"Depository Agreement" means the letter of representations for the Notes, dated January 29, 2020, by
the Issuer in favor of The Depository Trust Company.

"Device" means the wireless device that is the subject of a device payment plan agreement that is a
Receivable.

"Discount Rate" means, with respect to a Receivable, the greater of (i) the APR with respect to such
Receivable, and (ii) 7.65%.

"Eligibility Representation" has the meaning stated in Section 3.3 of the related Receivables
Transfer Agreement.

"Eligible Receivable" means a Receivable that satisfies the characteristics set forth in Section 3.3
of the related Receivables Transfer Agreement.

"Eligible Replacement Cap Counterparty" means a counterparty that meets the eligibility requirements
set forth in the Cap Agreement.

"Equity Interest" means a beneficial ownership interest in the Issuer, as recorded on the Trust
Register.

"ERISA" means the Employee Retirement Income Security Act of 1974, as amended.

"Event of Default" has the meaning stated in Section 5.1(a) of the Indenture.

"Exchange Act" means the Securities Exchange Act of 1934, as amended.

"FATCA Information" has the meaning stated in Section 3.3(e) of the Indenture.

"FATCA Withholding Tax" has the meaning stated in Section 3.3(e) of the Indenture.

"FICO® Score 8" means the FICO® Score 8 calculated on or about the date on which such Receivable was
originated.

"Final Maturity Date" means, for (i) the Class A-1a Notes, the Payment Date in July, 2024, (ii) the
Class A-1b Notes, the Payment Date in July, 2024, (iii) the Class B Notes, the Payment Date in July,
2024, and (iv) the Class C Notes, the Payment Date in July, 2024.

"First Priority Principal Payment" means, for a Payment Date, the greater of:

(a) an amount (not less than zero) equal to the aggregate Note Balance of the Class A Notes as of
the immediately preceding Payment Date (or, for the initial Payment Date, as of the Closing Date)
minus the Adjusted Pool Balance; and

A-17

Source: VERIZON ABS LLC, 8-K, 1/23/2020
<!-- page 80 -->
(b) on and after the Final Maturity Date for the Class A Notes, the aggregate Note Balance of the
Class A Notes until paid in full.

"Floor Credit Enhancement Composition Tests" means, for any Payment Date and the pool of Receivables
(excluding any Temporarily Excluded Receivables) held by the Issuer as of such date, each of the
following tests calculated as of the end of the month preceding the month in which such date occurs:

(a) the weighted average FICO® Score 8 of the Obligors with respect to the Receivables is at least
700 (excluding Receivables with Obligors for whom FICO® Score 8s are not available),

(b) Receivables with Obligors for whom FICO® Score 8s are not available represent no more than 4.50%
of the Pool Balance,

(c) Receivables with Obligors that have less than 12 months of Customer Tenure with Verizon Wireless
represent no more than 22.00% of the Pool Balance,

(d) Receivables with Obligors that have 7 months or more, but less than 24 months of Customer Tenure
with Verizon Wireless represent no more than 12.00% of the Pool Balance,

(e) Receivables with Obligors that have 60 months or more of Customer Tenure with Verizon Wireless
represent at least 55.00% of the Pool Balance,

(f) Receivables with Obligors that have less than 12 months of Customer Tenure with Verizon Wireless
and (i) for whom FICO® Score 8s are not available or (ii) that have FICO® Score 8s below 650,
represent no more than 10.00% of the Pool Balance,

(g) Receivables with Obligors that have 12 months or more, but less than 60 months of Customer
Tenure with Verizon Wireless and (i) for whom FICO® Score 8s are not available or (ii) that have
FICO® Score 8s below 650, represent no more than 50.00% of the aggregate Principal Balance of all
Receivables with Obligors that have 12 months or more, but less than 60 months of Customer Tenure
with Verizon Wireless, and

(h) Receivables with Obligors that have 60 months or more of Customer Tenure with Verizon Wireless
and (i) for whom FICO® Score 8s are not available or (ii) that have FICO® Score 8s below 650,
represent no more than 27.50% of the aggregate Principal Balance of all Receivables with Obligors
that have 60 months or more of Customer Tenure with Verizon Wireless.

"Governmental Authority" means any government or political subdivision or any agency, authority,
bureau, regulatory body, central bank, commission, department or instrumentality of any such
government or political subdivision, or any other entity exercising executive, legislative,
judicial, regulatory or administrative functions of or pertaining to government or any

A-18

Source: VERIZON ABS LLC, 8-K, 1/23/2020
<!-- page 81 -->
court, tribunal, grand jury or arbitrator, or any accounting board or authority (whether or not part
of a government) which is responsible for the establishment or interpretation of national or
international accounting principles, in each case whether foreign or domestic.

"Grant" means to mortgage, pledge, assign and to grant a lien on and a security interest in the
relevant property.

"Guaranteed Obligations" has the meaning stated in Section 1(a) of the Parent Support Agreement.

"Hague Securities Convention" means The Convention on the Law Applicable to Certain Rights in
Respect of Securities Held with an Intermediary (Concluded 5 July 2006), which became effective in
the United States of America on April 1, 2017.

"Indemnified Person" has the meaning stated in Section 6.7(b) of the Indenture, Section 6.3(a) of
the Transfer and Servicing Agreement and Section 7.2(a) of the Trust Agreement, as applicable.

"Indenture" means the Indenture, dated as of the Closing Date, between the Issuer and the Indenture
Trustee.

"Indenture Trustee" means U.S. Bank National Association, a national banking association, not in its
individual capacity but solely as Indenture Trustee under the Indenture.

"Indenture Trustee Fee" means a monthly fee equal to 1/12th of $12,000, payable on each Payment
Date.

"Independent" means that the relevant Person (a) is independent of the Issuer, the Depositor and
their Affiliates, (b) does not have any direct financial interest or any material indirect financial
interest in the Issuer, the Depositor or their Affiliates and (c) is not an officer, employee,
underwriter, trustee, partner, director or person performing similar functions of or for the Issuer,
the Depositor or their Affiliates.

"Independent Certificate" means a certificate or opinion to be delivered to the Indenture Trustee
under the circumstances described in Section 11.3 of the Indenture, made by an Independent
appraiser, a firm of certified public accountants of national reputation or other expert appointed
by an Issuer Order and approved by the Indenture Trustee in the exercise of reasonable care, and
such opinion or certificate shall state that the signer has read the definition of "Independent" in
this Indenture and that the signer is Independent within the meaning thereof.

"Independent Investment Banker" means an independent investment banking or commercial banking
institution of national standing appointed by Verizon.

"Initial Cutoff Date" means the end of the calendar day on December 31, 2019.

A-19

Source: VERIZON ABS LLC, 8-K, 1/23/2020
<!-- page 82 -->
"Initial Pool Balance" means $1,917,450,478.10 which is the aggregate Principal Balance of the
Initial Receivables as of the Initial Cutoff Date.

"Initial Receivable" means any device payment plan agreement acquired by the Issuer on the Closing
Date and listed on the Schedule of Receivables delivered on the Closing Date.

"Initial Trust Property" means (a) the Depositor Transferred Property for the Closing Date, (b) the
Issuer's rights under the Transfer and Servicing Agreement, (c) the Issuer's rights under the Cap
Agreement, (d) all security entitlements relating to the Bank Accounts and the property deposited in
or credited to any of the Bank Accounts, (e) all present and future claims, demands, causes of
action and choses in action for any of the foregoing and (f) all payments on or under and all
proceeds for any of the foregoing.

"Insolvency Event" means, for a Person, that (1) (a) such Person admits in writing its inability to
pay its debts generally as they become due, or makes a general assignment for the benefit of
creditors, or (b) any proceeding is instituted by or against such Person seeking to adjudicate it
bankrupt or insolvent, or seeking the liquidation, winding up, reorganization, arrangement,
adjustment, protection, relief or composition of it or its debts under any law relating to
bankruptcy, insolvency or reorganization or relief of debtors, or seeking the entry of an order for
relief or the appointment of a receiver, trustee or other similar official for it or any substantial
part of its property, or (c) such Person generally does not pay its debts as such debts become due
and, in the case of any proceeding instituted against such Person, such proceeding remains unstayed
for more than sixty (60) days or an order or decree approving or ordering any of the foregoing shall
be entered or (2) such person takes any corporate action to authorize any such action.

"Interest Period" means for any Payment Date and (a) the Class A-1a Notes, Class B Notes and Class C
Notes, the period from and including the 20th day of the calendar month immediately preceding the
Payment Date to but excluding the 20th day of the month in which the Payment Date occurs (or from
and including the Closing Date to but excluding March 20, 2020 for the first Payment Date) or (b)
the Class A-1b Notes, the period from and including the Payment Date immediately preceding the
current Payment Date to but excluding the current Payment Date (or from and including the Closing
Date to but excluding March 20, 2020 for the first Payment Date).

"Investment Company Act" means the Investment Company Act of 1940, as amended.

"ISDA Definitions" means the 2006 ISDA Definitions published by the International Swaps and
Derivatives Association, Inc. or any successor thereto, as amended or supplemented from time to
time, or any successor definitional booklet for interest rate derivatives published from time to
time.

"ISDA Fallback Adjustment" means the spread adjustment (which may be a positive or negative value or
zero) that would apply for derivatives transactions referencing the ISDA Definitions to be
determined upon the occurrence of an index cessation event with respect to the Benchmark for the
applicable tenor.

A-20

Source: VERIZON ABS LLC, 8-K, 1/23/2020
<!-- page 83 -->
"ISDA Fallback Rate" means the rate that would apply for derivatives transactions referencing the
ISDA Definitions to be effective upon the occurrence of an index cessation date with respect to the
Benchmark for the applicable tenor excluding the applicable ISDA Fallback Adjustment.

"Issuer" means Verizon Owner Trust 2020-A, a Delaware statutory trust.

"Issuer Order" and "Issuer Request" has the meaning stated in Section 11.3(a) of the Indenture.

"Law" means any law (including common law), constitution, statute, treaty, regulation, rule,
ordinance, executive order, order, court order, injunction, writ, decree, directive, judgment,
injunction, award or similar item of or by a Governmental Authority or any interpretation,
implementation or application thereof.

"LIBOR Determination Date" means, (i) with respect to the first Payment Date, the second London
Business Day prior to the Closing Date and (ii) with respect to each subsequent Payment Date, the
second London Business Day prior to the immediately preceding Payment Date.

"Lien" means a security interest, lien, charge, pledge or encumbrance.

"London Business Day" means any day other than a Saturday, Sunday or day on which banking
institutions in London, England are authorized or obligated by law or government decree to be
closed.

"Make-Whole Payment" means, for any payment of principal of the Notes on any Payment Date:

(a) for any Make-Whole Payment due, other than with respect to an Optional Redemption,

(i) for each Class of Notes other than the Class A-1b Notes, the excess of (a) the present value of
(i) the amount of all future interest payments that would otherwise accrue on the principal payment
until the Payment Date in February 2022 and (ii) the principal payment, each such payment discounted
from the Payment Date in February 2022 to such Payment Date monthly on a 30/360 day basis at 0.15%
plus the higher of (1) zero and (2) the then-current maturity matched Treasury Rate to such payment
over (b) the principal payment; or

(ii) for the Class A-1b Notes, the excess of (a) the present value of (i) the amount of all future
interest payments that would otherwise accrue on the principal payment at an interest rate of
One-Month LIBOR applicable to such Payment Date plus 0.27% until the Payment Date in February 2022
and (ii) the principal payment, each such payment discounted from the Payment Date in February 2022
to such Payment Date monthly on an actual/360 day basis at One-

A-21

Source: VERIZON ABS LLC, 8-K, 1/23/2020
<!-- page 84 -->
Month LIBOR applicable to such Payment Date over (b) the principal payment; and

(b) for any Make-Whole Payment due with respect to an Optional Redemption,

(i) for each Class of Notes other than the Class A-1b Notes, the excess of (a) the present value of
(i) the amount of all future interest payments that would otherwise accrue on such Class of Notes
assuming principal payments on such Class are made based on the Assumed Amortization Schedule for
such Class and (ii) the amount of all future principal payments that would otherwise be paid on such
Class of Notes assuming principal payments on such Class are paid based on the Assumed Amortization
Schedule for such Class, each such amount discounted from the Payment Date on which such payment
would be made in accordance with the Assumed Amortization Schedule to the Payment Date on which the
Optional Redemption occurs, monthly on a 30/360 day basis at 0.15% plus the higher of (1) zero and
(2) the then-current maturity matched Treasury Rate to such payment over (b) the Note Balance of
such Class of Notes immediately prior to the Optional Redemption; or

(ii) for the Class A-1b Notes, the excess of (a) the present value of (i) the amount of all future
interest payments that would otherwise accrue on the Class A-1b Notes at an interest rate of
One-Month LIBOR applicable to such Payment Date plus 0.27% assuming principal payments on the Class
A-1b Notes are made based on the Assumed Amortization Schedule for the Class A-1b Notes and (ii) the
amount of all future principal payments that would otherwise be paid on the Class A-1b Notes
assuming principal payments on the Class A-1b Notes are paid based on the Assumed Amortization
Schedule for the Class A-1b Notes, each such amount discounted from the Payment Date on which such
payment would be made in accordance with the Assumed Amortization Schedule to the Payment Date on
which the Optional Redemption occurs, monthly on an actual/360 day basis at One-Month LIBOR
applicable to such Payment Date over (b) the Note Balance of the Class A-1b Notes immediately prior
to the Optional Redemption;

provided, that, upon the occurrence of a Benchmark Transition Event, One-Month LIBOR used in the
calculation of Make-Whole Payments will be replaced by the appropriate Benchmark Replacement as set
forth in Section 2.16 of the Indenture.

"Marketing Agent" means Cellco.

"Marketing Agent Agency Agreement" means the Amended and Restated Marketing Agent Agency Agreement,
dated as of September 27, 2016, between the Marketing Agent and the Verizon Originators, as amended,
restated, supplemented or modified from time to time.

A-22

Source: VERIZON ABS LLC, 8-K, 1/23/2020
<!-- page 85 -->
"Marketing Agent Remittance Obligation" has the meaning stated in the Parent Support Agreement.

"Master Collateral Agency Agreement" means the Amended and Restated Master Collateral Agency and
Intercreditor Agreement, dated as of May 8, 2019, among the Master Trust, U.S. Bank National
Association, as master collateral agent, Cellco, as servicer, and each creditor representative from
time to time party thereto, as amended, restated, supplemented or modified from time to time.

"Master Trust" means Verizon DPPA Master Trust, a Delaware statutory trust, created and existing
pursuant to the Master Trust Agreement.

"Master Trust Administrator" means Cellco.

"Master Trust Agreement" means the Second Amended and Restated Trust Agreement, dated as of May 8,
2019, between Verizon ABS II LLC, as depositor, and the Master Trust Owner Trustee, as amended,
restated, supplemented or modified from time to time.

"Master Trust Owner Trustee" means Wilmington Trust, National Association, a national banking
association, not in its individual capacity but solely as Master Trust Owner Trustee under the
Master Trust Agreement.

"Master Trust Receivables Transfer Agreement" means the Master Trust Receivables Transfer Agreement,
dated as of the Closing Date, among the Master Trust, the Servicer and the Depositor, as amended,
restated, supplemented or modified from time to time.

"Master Trust Transferred Property" means, for the Closing Date and any Acquisition Date, (a) the
Initial Receivables or the Additional Receivables, as applicable, transferred by the Master Trust,
(b) all amounts received and applied on such Receivables after the end of the calendar day on the
related Cutoff Date, (c) all present and future claims, demands, causes of action and choses in
action relating to any of the property described above and (d) all payments on or under and all
proceeds of the property described above.

"Material Adverse Effect" means, with respect to any event or circumstance, a material adverse
effect on the ability of the applicable Person to perform its obligations under any Transaction
Document.

"Monthly Deposit Required Ratings" has the meaning stated in Section 4.3(b)(i) of the Transfer and
Servicing Agreement.

"Monthly Investor Report" has the meaning stated in Section 3.5(a)(i) of the Transfer and Servicing
Agreement.

"Moody's" means Moody's Investors Service, Inc.

"Negative Carry Account" means the account or accounts established under Section 4.1(a) of the
Transfer and Servicing Agreement.

A-23

Source: VERIZON ABS LLC, 8-K, 1/23/2020
<!-- page 86 -->
"Negative Carry Deposit Amount" means, for a Payment Date during the Revolving Period on which
amounts are in the Acquisition Account, an amount equal to (a) the Required Negative Carry Amount
for that Payment Date minus (b) the amount in the Negative Carry Account on that Payment Date
(before payments under Section 8.2(c) of the Indenture on that Payment Date).

"Negative Carry Account Draw Amount" means, for a Payment Date during the Revolving Period:

(a) if that Payment Date is not an Acquisition Date, the lesser of:

(i) an amount (not less than zero) equal to the Total Required Payment, plus the Reserve Deposit
Amount, plus the Acquisition Deposit Amount, minus the Available Funds determined without regard to
the Negative Carry Account Draw Amount or the Reserve Account Draw Amount; and

(ii) the amount in the Negative Carry Account; and

(b) if the Payment Date is an Acquisition Date, the amount in the Negative Carry Account in excess
of the Required Negative Carry Amount.

"New Upgrade DPP" has the meaning stated in Section 4.3(g) of the Transfer and Servicing Agreement.

"Note Balance" means, for a Note or Class, the initial aggregate principal balance of the Note or
Class minus all amounts distributed on the Note or Class that is applied to principal.

"Note Interest Rate" means a per annum rate equal to, for: (i) the Class A-1a Notes, 1.85% (computed
on the basis of a 360 day year consisting of twelve 30 day months), (ii) the Class A-1b Notes,
One-Month LIBOR (or, upon the occurrence of a Benchmark Transition Event, the appropriate Benchmark
Replacement) + 0.27% (computed on the basis of the actual number of days elapsed during the relevant
Interest Period and a 360 day year), (iii) the Class B Notes, 1.98% (computed on the basis of a 360
day year consisting of twelve 30 day months), and (iv) the Class C Notes, 2.06% (computed on the
basis of a 360 day year consisting of twelve 30 day months).

"Note Interest Shortfall" means, for a Class and a Payment Date, an amount equal to the excess, if
any, of the Accrued Note Interest for the Payment Date immediately preceding such Payment Date for
the Class over the amount of interest that was paid to the Noteholders of that Class on the Payment
Date immediately preceding such Payment Date, together with interest on the excess amount, to the
extent lawful, at the Note Interest Rate for the Class for that Interest Period.

A-24

Source: VERIZON ABS LLC, 8-K, 1/23/2020
<!-- page 87 -->
"Note Monthly Interest" means, for a Class and a Payment Date, the aggregate amount of interest
accrued on the Note Balance of the Class at the Note Interest Rate for the Class for the related
Interest Period.

"Note Owner" means, for a Book-Entry Note, the Person who is the beneficial owner of a Book-Entry
Note as reflected on the books of the Clearing Agency or on the books of a Person maintaining an
account with the Clearing Agency (as a direct participant or as an indirect participant, in each
case according to the rules of the Clearing Agency).

"Note Paying Agent" means initially the Indenture Trustee and any other Person appointed as Note
Paying Agent under Section 2.15 of the Indenture.

"Note Pool Factor" means, for a Class and a Payment Date, a seven-digit decimal figure equal to the
Note Balance of the Class after giving effect to any payments of principal of the Class on that
Payment Date divided by the initial Note Balance of the Class.

"Note Register" and "Note Registrar" have the meanings stated in Section 2.4 of the Indenture.

"Noteholder" means the Person in whose name a Note is registered on the Note Register.

"Noteholder Tax Identification Information" means properly completed and signed tax certifications
(generally with respect to U.S. Federal Income Tax, IRS Form W-9 (or applicable successor form) in
the case of a person that is a "United States Person" within the meaning of Section 7701(a)(30) of
the Code or the appropriate IRS Form W-8 (or applicable successor form) in the case of a person that
is not a "United States Person" within the meaning of Section 7701(a)(30) of the Code).

"Notes" or "Note" means, collectively or individually, as the context may require, the Class A-1a
Notes, the Class A-1b Notes, the Class B Notes and the Class C Notes.

"Obligor" means the Person that has signed the account agreement of which the device payment plan
agreement that constitutes the Receivable is a part and who owes payments under the Receivable.

"Officer's Certificate" means (a) for the Issuer, a certificate signed by a Responsible Person of
the Issuer, (b) for the Depositor, the Administrator, the Marketing Agent, the Parent Support
Provider, any Originator or the Servicer, a certificate signed by any officer of such entity, as
applicable, (c) for the Master Trust, a certificate signed by a Responsible Person of the Master
Trust and (d) for the Indenture Trustee, a certificate signed by a Responsible Person of the
Indenture Trustee.

"One-Month LIBOR" means, with respect to any Interest Period for which One-Month LIBOR is the
Benchmark, the London interbank offered rate for deposits in U.S. Dollars having a maturity of one
month commencing on the related LIBOR Determination Date which appears on the Reuters Screen LIBOR01
Page as of 11:00 a.m., London time, on such LIBOR

A-25

Source: VERIZON ABS LLC, 8-K, 1/23/2020
<!-- page 88 -->
Determination Date; provided, however, that for the first Interest Period, One-Month LIBOR shall
mean an interpolated rate for deposits based on London interbank offered rates for deposits in U.S.
Dollars for a period that corresponds to the actual number of days in the first Interest Period. If
the rates used to determine One-Month LIBOR do not appear on the Reuters Screen LIBOR01 Page, the
rates for that day will be determined on the basis of the rates at which deposits in U.S. Dollars,
having a maturity of one month and in a principal balance of not less than U.S. $1,000,000 are
offered at approximately 11:00 a.m., London time, on such LIBOR Determination Date to prime banks in
the London interbank market by the Reference Banks. The Administrator will request the principal
London office of each Reference Bank to provide a quotation of its rate to the Administrator and the
Indenture Trustee. If at least two such quotations are provided, the Indenture Trustee will
calculate the rate for that day as the arithmetic mean of such quoted rates to the nearest 1/100,000
of 1.00% (0.0000001), with five one-millionths of a percentage point rounded upward, of all such
quotations. If fewer than two such quotations are provided, the Indenture Trustee will calculate the
rate for that day as the arithmetic mean to the nearest 1/100,000 of 1.00% (0.0000001), with five
one-millionths of a percentage point rounded upward, of the offered per annum rates that one or more
major banks in New York City, selected by the Administrator, are quoting as of approximately 11:00
a.m., New York City time, on such LIBOR Determination Date to leading European banks for United
States Dollar deposits for that maturity; provided that if the Administrator is not able to identify
any major banks in New York City that are quoting as described in this sentence and for the
avoidance of doubt, regardless of whether others in similar transactions are using a different
index, it shall direct the Indenture Trustee to use One-Month LIBOR in effect for the applicable
Interest Period which will be One-Month LIBOR in effect for the previous Interest Period, and any
such direction will be deemed to apply to all subsequent LIBOR Determination Dates unless otherwise
directed by the Administrator. In no event shall the Indenture Trustee be responsible for
determining One-Month LIBOR or any substitute for One-Month LIBOR if such rate does not appear on
Reuters Screen LIBOR01 Page.

"Opinion of Counsel" means a written opinion of counsel (which may be internal counsel) which
counsel is reasonably acceptable to the Indenture Trustee, the Owner Trustee and the Rating
Agencies, as applicable.

"Optional Acquisition" has the meaning stated in Section 8.1(a) of the Transfer and Servicing
Agreement.

"Optional Acquisition Amount" has the meaning stated in Section 8.1(b) of the Transfer and Servicing
Agreement.

"Optional Redemption" has the meaning stated in Section 8.2(a) of the Transfer and Servicing
Agreement.

"Originator" means (i) with respect to the Initial Receivables or the Additional Receivables, any of
Cellco or certain Affiliates of Verizon listed on Schedule B to the Originator Receivables Transfer
Agreement and (ii) with respect to the Additional Receivables transferred to the Depositor pursuant
to the Originator Receivables Transfer Agreement, any additional Affiliate of Verizon not listed on
Schedule B to the Originator Receivables Transfer Agreement

A-26

Source: VERIZON ABS LLC, 8-K, 1/23/2020
<!-- page 89 -->
that executes an Additional Originator Joinder Agreement substantially in the form of Exhibit B to
the Originator Receivables Transfer Agreement; provided, that with respect to any amounts remitted
by, or caused to be remitted by, the Marketing Agent pursuant to Sections 4.3(g), (h) and (i) of the
Transfer and Servicing Agreement, the term "Originator" shall also mean, with respect to the
Additional Receivables transferred to the Depositor pursuant to the Master Trust Receivables
Transfer Agreement, any additional Affiliate of Verizon not listed on Schedule B to the Originator
Receivables Transfer Agreement that originated any such Receivables.

"Originator Reacquisition Obligation" has the meaning stated in the Parent Support Agreement.

"Originator Receivables Transfer Agreement" means the Originator Receivables Transfer Agreement,
dated as of the Closing Date, between the Originators party thereto and the Depositor, as amended,
restated, supplemented or modified from time to time.

"Originator Transferred Property" means, for the Closing Date and any Acquisition Date, (a) the
Initial Receivables or the Additional Receivables, as applicable, transferred by the Originators,
(b) all amounts received and applied on such Receivables after the end of the calendar day on the
related Cutoff Date, (c) all present and future claims, demands, causes of action and choses in
action relating to any of the property described above and (d) all payments on or under and all
proceeds of the property described above.

"Other Assets" means any assets (other than the Trust Property) sold, assigned or conveyed or
intended to be sold, assigned or conveyed by the Depositor to any Person other than the Issuer,
whether by way of a sale, capital contribution, pledge or otherwise.

"Outstanding" means, as of a date, all Notes authenticated and delivered under the Indenture on or
before that date except (a) Notes that have been cancelled by the Note Registrar or delivered to the
Note Registrar for cancellation, (b) Notes to the extent the amount necessary to pay the Notes has
been deposited with the Indenture Trustee or Note Paying Agent in trust for the Noteholders and, if
those Notes are to be redeemed, notice of the redemption has been given under the Indenture, and (c)
Notes in exchange for or in place of which other Notes have been authenticated and delivered under
the Indenture unless proof satisfactory to the Indenture Trustee is presented that the Notes are
held by a bona fide purchaser. In determining whether Noteholders of the required Note Balance have
made or given a request, demand, authorization, direction, notice, consent or waiver under any
Transaction Document, Notes owned by the Issuer, the Depositor, the Servicer or their Affiliates
will not be considered to be Outstanding. However, Notes owned by the Issuer, the Depositor, the
Servicer or their Affiliates will be considered to be Outstanding if (A) no other Notes remain
Outstanding, or (B) the Notes have been pledged in good faith and the pledgee establishes to the
reasonable satisfaction of the Indenture Trustee the pledgee's right to act for the Notes and that
the pledgee is not the Issuer, the Depositor, the Servicer or their Affiliates.

"Overcollateralization" means, for any date of determination other than the Closing Date, the amount
by which (x) the sum of (i) the Adjusted Pool Balance as of the last day of the related

A-27

Source: VERIZON ABS LLC, 8-K, 1/23/2020
<!-- page 90 -->
Collection Period, and (ii) the amount on deposit in the Acquisition Account after giving effect to
the acquisition of Receivables on that date exceeds (y) the aggregate Note Balance.

"Overcollateralization Target Amount" means an amount equal to:

(i) on the Closing Date, 10.50% of the Adjusted Pool Balance as of the Initial Cutoff Date;

(ii) for any date of determination (other than the Closing Date), prior to the Amortization Period,
on which the pool of Receivables meets all of the Floor Credit Enhancement Composition Tests, the
greater of (x) the result of (a)(i) the aggregate Note Balance, divided by (ii) 1 minus 0.1050,
minus (b) the aggregate Note Balance, and (y) 1.00% of the Adjusted Pool Balance as of the Closing
Date;

(iii) for any date of determination (other than the Closing Date), prior to the Amortization Period,
on which the pool of Receivables does not meet all of the Floor Credit Enhancement Composition
Tests, the greater of (x) the result of (a)(i) the aggregate Note Balance, divided by (ii) 1 minus
0.1350, minus (b) the aggregate Note Balance, and (y) 1.00% of the Adjusted Pool Balance as of the
Closing Date;

(iv) for any date of determination, during the Amortization Period, on which the pool of Receivables
meets all of the Floor Credit Enhancement Composition Tests, the greater of (x) 14.50% of the
Adjusted Pool Balance as of the end of the calendar month immediately preceding such date of
determination, and (y) 1.00% of the Adjusted Pool Balance as of the Closing Date; or

(v) for any date of determination, during the Amortization Period, on which the pool of Receivables
does not meet all of the Floor Credit Enhancement Composition Tests, the greater of (x) 17.50% of
the Adjusted Pool Balance as of the end of the calendar month immediately preceding such date of
determination, and (y) 1.00% of the Adjusted Pool Balance as of the Closing Date.

"Owner Trustee" means Wilmington Trust, National Association, a national banking association, not in
its individual capacity but solely as Owner Trustee under the Trust Agreement.

"Owner Trustee Fee" means a monthly fee equal to 1/12th of $15,000, payable on each Payment Date.

"Parent Support Agreement" means the guaranty, dated as of the Closing Date, among the Parent
Support Provider, the Depositor, the Issuer and the Indenture Trustee, as amended, restated,
supplemented or modified from time to time.

"Parent Support Provider" means Verizon.

A-28

Source: VERIZON ABS LLC, 8-K, 1/23/2020
<!-- page 91 -->
"Payment Date" means the 20th day of each month or, if not a Business Day, the next Business Day,
starting in March 2020. For a Collection Period, the related Payment Date means the Payment Date
following the end of the Collection Period.

"Percentage Interest" shall mean, with respect to each Certificate, the percentage interest in the
Issuer represented by such Certificate.

"Permitted Activities" has the meaning stated in Section 2.3(a) of the Trust Agreement.

"Permitted Investments" means book-entry securities, negotiable instruments or securities
represented by instruments in bearer or registered form that evidence:

(a) (x) direct or fully guaranteed United States treasury obligations, (y) U.S. Department of
Housing and Urban Development public agency bonds, Federal Housing Administration debentures,
Government National Mortgage Association guaranteed mortgage-backed securities or participation
certificates, RefCorp debt obligations, SBA-guaranteed participation certificates and guaranteed
pool certificates or (z) Farm Credit System consolidated systemwide bonds and notes, Federal Home
Loan Banks' consolidated debt obligations, Federal Home Loan Mortgage Corp. debt obligations and
Federal National Mortgage Association debt obligations, if, with respect to the investments listed
in clause (z), they meet the criteria of S&P for collateral for securities having ratings equivalent
to the respective ratings of the Notes in effect at the Closing Date;

(b) demand deposits, time deposits, certificates of deposit or bankers' acceptances of any
depository institution or trust company (i) incorporated under the laws of the United States or any
State or any United States branch or agency of a foreign bank, (ii) subject to supervision and
examination by federal or State banking or depository institution authorities and (iii) where the
commercial paper or other short-term unsecured debt obligations (other than obligations with a
rating based on the credit of a Person other than the depository institution or trust company) of
such depository institution or trust company have the Required Rating;

(c) commercial paper, including asset-backed commercial paper, having the Required Rating;

(d) investments in money market funds having a rating in the highest investment grade category from
each of S&P and Moody's (including funds for which the Indenture Trustee or the Owner Trustee or any
of their Affiliates is investment manager or advisor); and

(e) any other investment that is acceptable to each Rating Agency.

"Permitted Lien" means a Lien that attaches by operation of law, or any security interest of the
Depositor in the Originator Transferred Property and the Master Trust Transferred Property under the
related Receivables Transfer Agreement, the Issuer in the Depositor

A-29

Source: VERIZON ABS LLC, 8-K, 1/23/2020
<!-- page 92 -->
Transferred Property under the Transfer and Servicing Agreement or the Indenture Trustee in the
Collateral under the Indenture.

"Person" means a legal person, including a corporation, natural person, joint venture, limited
liability company, partnership, trust, business trust, association, government, a department or
agency of a government or any other entity.

"Personally Identifiable Information" has the meaning stated in the Asset Representations Review
Agreement.

"Pool Balance" means, for any Collection Period, an amount equal to (i) the aggregate Principal
Balance of the Receivables on the last day of the Collection Period immediately preceding such
Collection Period (excluding Acquired Receivables), plus the aggregate Principal Balance on the
related Cutoff Date of any Additional Receivables transferred during the Collection Period less (ii)
the aggregate Principal Balance of any Temporarily Excluded Receivables as of the last day of the
Collection Period immediately preceding such Collection Period.

"Pool Composition Tests" means, for the Closing Date, each Payment Date and any Acquisition Date and
with respect to the pool of Receivables held by the Issuer as of the related Cutoff Date, including
any Additional Receivables acquired by the Issuer on an Acquisition Date, each of the following
tests calculated as of the end of the month preceding the month in which such date occurs:

(a) the weighted average FICO® Score 8 of the Obligors with respect to the Receivables is at least
685 (excluding Receivables with Obligors for whom FICO® Score 8s are not available),

(b) Receivables with Obligors for whom FICO® Score 8s are not available represent no more than 5.00%
of the Pool Balance,

(c) Receivables with Obligors that have less than 12 months of Customer Tenure with Verizon Wireless
represent no more than 28.00% of the Pool Balance,

(d) Receivables with Obligors that have 7 months or more, but less than 24 months of Customer Tenure
with Verizon Wireless represent no more than 15.00% of the Pool Balance,

(e) Receivables with Obligors that have 60 months or more of Customer Tenure with Verizon Wireless
represent at least 50.00% of the Pool Balance,

(f) Receivables with Obligors that have less than 12 months of Customer Tenure with Verizon Wireless
and (i) for whom FICO® Score 8s are not available or (ii) that have FICO® Score 8s below 650,
represent no more than 10.00% of the Pool Balance,

A-30

Source: VERIZON ABS LLC, 8-K, 1/23/2020

(g) Receivables with Obligors that have 12 months or more, but less than 60 months of Customer
Tenure with Verizon Wireless and (i) for whom FICO® Score 8s are not available or (ii) that have
FICO® Score 8s below 650, represent no more than 55.00% of the aggregate Principal Balance of all
Receivables with Obligors that have 12 months or more, but less than 60 months of Customer Tenure
with Verizon Wireless, and
<!-- page 93 -->
(h) Receivables with Obligors that have 60 months or more of Customer Tenure with Verizon Wireless
and (i) for whom FICO® Score 8s are not available or (ii) that have FICO® Score 8s below 650,
represent no more than 30.00% of the aggregate Principal Balance of all Receivables with Obligors
that have 60 months or more of Customer Tenure with Verizon Wireless.

"Principal Balance" means, for a Receivable as of the last day of a month, an amount (not less than
zero) equal to, without duplication:

(a) the Amount Financed; minus

(b) the portion of the amounts paid by the related Obligor applied on or before that date allocable
to principal; minus

(c) any Credits allocated to such Receivable;

provided that, the Principal Balance for any Written-Off Receivable will be deemed to be zero.

"Proceeding" means a suit in equity, action at law or other judicial or administrative proceeding,
or governmental investigation.

"Prospectus" means the prospectus dated as of January 21, 2020, relating to the offering of the
Notes.

"Qualified Institution" means U.S. Bank National Association, Wilmington Trust, National
Association, or a trust company or a bank or depository institution organized under the laws of the
United States or any State or any United States branch or agency of a foreign bank or depository
institution that (i) is subject to supervision and examination by federal or State banking
authorities, (ii) has a short-term deposit rating of "P-1" from Moody's, if rated by Moody's, and
"A-1+" from S&P, if rated by S&P, (iii) if the institution holds any Bank Accounts, has a long-term
unsecured debt rating or issuer rating of at least "Aa3" from Moody's, if rated by Moody's, and at
least "A" from S&P, if rated by S&P and (iv) if the institution is organized under the laws of the
United States, whose deposits are insured by the Federal Deposit Insurance Corporation.

"Rating Agency" means each of Moody's and S&P.

"Rating Agency Condition" means, for an action or request and with respect to a Rating Agency, that,
according to the then-current policies of the relevant Rating Agency for that action

A-31

Source: VERIZON ABS LLC, 8-K, 1/23/2020
<!-- page 94 -->
or request, the Rating Agency has notified the Depositor, the Servicer, the Owner Trustee and the
Indenture Trustee that the proposed action or request will not result in a downgrade or withdrawal
of its then-current rating on any of the Notes.

"Receivable" means, for a Collection Period, an Initial Receivable or an Additional Receivable,
excluding any device payment plan agreement that became an Acquired Receivable during a prior
Collection Period or was a Written-Off Receivable sold under Section 3.4 of the Transfer and
Servicing Agreement during a prior Collection Period.

"Receivable File" has the meaning stated in Section 3.10(b) of the Transfer and Servicing Agreement.

"Receivables Transfer Agreements" or "Receivables Transfer Agreement" means, collectively or
individually, the Originator Receivables Transfer Agreement and the Master Trust Receivables
Transfer Agreement, as the context may require.

"Record Date" means, for a Payment Date and a Book-Entry Note, the close of business on the day
before the Payment Date and, for a Payment Date and a Definitive Note, the last day of the calendar
month immediately preceding the month in which the Payment Date occurs and with respect to any
notice, vote or consent, the most recently occurring Record Date for a Payment Date.

"Recoveries" means, for any Written-Off Receivable and a Collection Period, an amount equal to:

(a) all amounts received and applied by the Servicer during the Collection Period for the Receivable
after the date on which it became a Written-Off Receivable, including any proceeds from the sale of
a Device securing any Receivable; minus

(b) any amounts paid by the Servicer for the account of the related Obligor, including collection
expenses and other amounts paid to third parties, if any, in connection with collections on the
Written-Off Receivable; minus

(c) amounts, if any, required by Law or under the Servicing Procedures to be paid to the Obligor.

"Redemption Date" has the meaning stated in Section 10.1 of the Indenture.

"Reference Banks" means, for any LIBOR Determination Date, the four major banks in the London
interbank market selected by the Administrator.

"Reference Time" with respect to any determination of the Benchmark means (1) if the Benchmark is
One-Month LIBOR, 11:00 a.m. (London time) on the day that is two (2) London banking days preceding
the date of such determination, and (2) if the Benchmark is not One- Month LIBOR, the time
determined by the Administrator in accordance with the Benchmark Replacement Conforming Changes.

A-32

Source: VERIZON ABS LLC, 8-K, 1/23/2020
<!-- page 95 -->
"Reference Treasury Dealer" means (1) any independent investment banking or commercial banking
institution of national standing and any of its successors appointed by Verizon; provided, however,
that if any of the foregoing shall cease to be a primary U.S. Government securities dealer in the
United States, referred to as a "Primary Treasury Dealer," another Primary Treasury Dealer
substituted therefor, and (2) any other Primary Treasury Dealer selected by an Independent
Investment Banker and approved in writing by Verizon.

"Reference Treasury Dealer Quotations" means, with respect to each Reference Treasury Dealer and any
date of determination, the average, as determined by the Independent Investment Banker, of the bid
and asked prices for the Comparable Treasury Issue (expressed in each case as a percentage of its
principal amount) quoted in writing to the Independent Investment Banker at 3:30 p.m., New York City
time, on the third Business Day preceding the date of determination.

"Regular Priority Principal Payment" means, for a Payment Date, an amount equal to the greater of
(A) an amount (not less than zero) equal to the excess, if any, of (a) the aggregate Note Balance of
the Class A Notes, the Class B Notes and the Class C Notes as of the immediately preceding Payment
Date (or, for the initial Payment Date, as of the Closing Date), minus the sum of the First Priority
Principal Payment, the Second Priority Principal Payment and the Third Priority Principal Payment
for the current Payment Date, over (b) the Adjusted Pool Balance as of the last day of the related
Collection Period minus the Overcollateralization Target Amount, and (B) on and after the Final
Maturity Date for any Class of Notes, the amount that is necessary to reduce the principal amount of
each such Class, as applicable, to zero (after the application of any First Priority Principal
Payment, Second Priority Principal Payment and Third Priority Principal Payment).

"Regulation AB" means Subpart 229.1100 - Asset Backed Securities (Regulation AB), 17 C.F.R.
§§229.1100-229.1125, as such may be amended from time to time, and subject to such clarification and
interpretation as have been provided by the Commission in the adopting releases (Asset-Backed
Securities, Securities Act Release No. 33-8518, 70 Fed. Reg. 1,506, 1,531 (Jan. 7, 2005) and
Asset-Backed Securities Disclosure and Registration, Securities Act Release No. 33-9638, 79 Fed.
Reg. 57,184 (Sept. 24, 2014)) or by the staff of the Commission, or as may be provided by the
Commission or its staff from time to time.

"Relevant Governmental Body" means the Federal Reserve Board and/or the Federal Reserve Bank of New
York, or a committee officially endorsed or convened by the Federal Reserve Board and/or the Federal
Reserve Bank of New York, or any successor thereto.

"Requesting Noteholders" has the meaning stated in Section 14.1 of the Indenture.

"Requesting Party" has the meaning stated in Section 11.2 of the Transfer and Servicing Agreement.

"Required Acquisition Deposit Amount" means, for any Payment Date during the Revolving Period, an
amount equal to the excess, if any, of (x) the aggregate Note Balance of the Notes over (y) (i) the
Adjusted Pool Balance as of the end of the related Collection Period minus

A-33

Source: VERIZON ABS LLC, 8-K, 1/23/2020
<!-- page 96 -->
(ii) the Overcollateralization Target Amount, after giving effect to any acquisition of Additional
Receivables on such date.

"Required Negative Carry Amount" means, for any Payment Date during the Revolving Period, an amount
equal to the product of (i) the amount in the Acquisition Account on the Payment Date (after giving
effect to all payments under Section 8.2(c) of the Indenture and the acquisition of Additional
Receivables, if any, on the Payment Date), (ii) the weighted average Note Interest Rate and (iii)
1/12.

"Required Rating" means, for short-term unsecured debt obligations, a rating of (a) "P-1" from
Moody's and (b) "A-1+" from S&P.

"Required Reserve Amount" means $17,877,097.97, or approximately 1% of the Adjusted Pool Balance as
of the Initial Cutoff Date.

"Reserve Account" means the account established under Section 4.1(a) of the Transfer and Servicing
Agreement.

"Reserve Account Draw Amount" means:

(a) for each Payment Date before the Amortization Period, the lesser of:

(i) an amount (not less than zero) equal to the Total Required Payment minus the Available Funds
determined without regard to the Reserve Account Draw Amount; and

(ii) the amount in the Reserve Account; and

(b) for each Payment Date during the Amortization Period, an amount equal to the amount in the
Reserve Account, if that amount together with Available Funds for that Payment Date is sufficient to
pay the entire Note Balance of the Notes, all accrued and unpaid interest and any unpaid Make-Whole
Payments and all other amounts to be distributed to the Secured Parties under the Indenture and the
Transfer and Servicing Agreement in full.

"Reserve Deposit Amount" means, for a Payment Date, an amount equal to (a) the Required Reserve
Amount minus (b) the amount in the Reserve Account on the Payment Date (before payments under
Section 8.2(c) of the Indenture on that Payment Date).

"Residual Interest" means an "eligible horizontal residual interest" (as defined in the U.S. Credit
Risk Retention Rules) equal to at least 5% of the fair value of all of the "ABS interests" (as
defined in the U.S. Credit Risk Retention Rules) in the Issuer issued as part of the transactions
contemplated by the Transaction Documents, determined as of the Closing Date using a fair value
measurement framework under United States generally accepted accounting principles.

A-34

Source: VERIZON ABS LLC, 8-K, 1/23/2020
<!-- page 97 -->
"Responsible Person" means:

(a) for the Administrator, the Depositor, the Sponsor, the Servicer, the Marketing Agent, the Parent
Support Provider or any Originator, a Person designated in an Officer's Certificate of the Person or
other notice signed by an officer of the Person authorized to act for the Person or any treasurer,
assistant treasurer or corporate secretary of such Person that has responsibility for the matter;

(b) for the Issuer, an officer in the Corporate Trust Office of the Owner Trustee, any officer of
the Owner Trustee to whom any matter is referred because of the officer's knowledge of and
familiarity with the matter, and a Responsible Person of the Administrator;

(c) for the Master Trust, an officer in the Corporate Trust Office of the Master Trust Owner
Trustee, any officer of the Master Trust Owner Trustee to whom any matter is referred because of the
officer's knowledge of and familiarity with the matter, and a Responsible Person of the Master Trust
Administrator; and

(d) for the Indenture Trustee or the Owner Trustee, an officer in the Corporate Trust Office of the
Indenture Trustee or the Owner Trustee, as applicable, including each vice president, assistant vice
president, secretary, assistant secretary or other officer customarily performing functions similar
to those performed by those officers listed above, and any officer of the Indenture Trustee or the
Owner Trustee, as applicable, to whom any matter is referred because of the officer's knowledge of
and familiarity with the matter, and in each case, having direct responsibility for the
administration of the Transaction Documents.

"Review" has the meaning stated in the Asset Representations Review Agreement.

"Review Materials" has the meaning stated in the Asset Representations Review Agreement.

"Review Notice" has the meaning stated in the Asset Representations Review Agreement.

"Review Receivable" has the meaning stated in the Asset Representations Review Agreement.

"Review Report" means, for an Asset Representations Review, the report of the Asset Representations
Reviewer described in Section 3.5 of the Asset Representations Review Agreement.

"Revolving Period" means the period from the Closing Date to the start of the Amortization Period.

"S&P" means S&P Global Ratings.

A-35

Source: VERIZON ABS LLC, 8-K, 1/23/2020
<!-- page 98 -->
"Sarbanes Certification" has the meaning stated in Section 6.7(a)(iv) of the Transfer and Servicing
Agreement.

"Schedule of Receivables" means (a) the schedule identifying the Initial Receivables attached as
Schedule A to each Receivables Transfer Agreement and Schedule A to each of the Transfer and
Servicing Agreement and the Indenture or the electronic file with respect thereto delivered on the
Closing Date, and (b) each schedule identifying any Additional Receivables attached as Schedule A to
any Transfer Notice or the electronic file with respect thereto delivered by the Depositor, or the
Administrator on its behalf, to the Issuer and the Indenture Trustee for an Acquisition Date.

"Second Priority Principal Payment" means, for a Payment Date, the greater of:

(a) an amount (not less than zero) equal to:

(i) the aggregate Note Balances of the Class A Notes and the Class B Notes as of the immediately
preceding Payment Date (or, for the initial Payment Date, as of the Closing Date); minus

(ii) the Adjusted Pool Balance; minus

(iii) the First Priority Principal Payment; and

(b) on and after the Final Maturity Date for the Class B Notes, the Note Balance of the Class B
Notes until paid in full.

"Secured Parties" means the Indenture Trustee, for the benefit of the Noteholders.

"Securities Account" means each Bank Account subject to the terms of the Account Control Agreement.

"Securities Act" means the Securities Act of 1933, as amended.

"Securities Intermediary" means U.S. Bank National Association.

"Servicer" means Cellco or any Successor Servicer engaged under Section 7.4 of the Transfer and
Servicing Agreement.

"Servicer Acquisition Obligation" has the meaning stated in the Parent Support Agreement.

"Servicer Deposit Obligation" has the meaning stated in the Parent Support Agreement.

"Servicer Representation Obligation" has the meaning stated in the Parent Support Agreement.

A-36

Source: VERIZON ABS LLC, 8-K, 1/23/2020
<!-- page 99 -->
"Servicer Termination Event" has the meaning stated in Section 7.2 of the Transfer and Servicing
Agreement.

"Servicer's Certificate" means an Officer's Certificate of the Servicer delivered pursuant to
Section 6.6 of the Transfer and Servicing Agreement.

"Servicing Criteria" means the "servicing criteria" set forth in Item 1122(d) of Regulation AB, as
such may be amended from time to time.

"Servicing Fee" means, for a Collection Period, the fee payable to the Servicer in an amount equal
to the product of:

(a) one-twelfth of the Servicing Fee Rate; times

(b) the Adjusted Pool Balance at the beginning of the full calendar month immediately preceding such
Payment Date;

provided, that the Servicing Fee for the initial Payment Date will equal the product of (i) a
fraction, the numerator of which is the number of days from and including the Closing Date to and
including the last day of the first Collection Period and the denominator of which is 360, and (ii)
the Servicing Fee Rate times the Adjusted Pool Balance as of the Closing Date.

"Servicing Fee Rate" means 0.75%.

"Servicing Procedures" means the servicing procedures of Cellco relating to device payment plan
agreements originated by the Originators, as amended or modified from time to time.

"Similar Law" means any federal, State, local or non-U.S. law or regulation that is substantially
similar to Title I of ERISA or Section 4975 of the Code.

"SOFR" with respect to any day means the secured overnight financing rate published for such day by
the Federal Reserve Bank of New York, as the Benchmark Administrator for SOFR (or a successor
Benchmark Administrator).

"Solvent" means, with respect to any Person and as of any particular date, that (i) the present fair
market value (or present fair saleable value) of the assets of such Person is not less than the
total amount required to pay the probable liabilities of such Person on its total existing debts and
liabilities (including contingent liabilities) as they become absolute and matured, (ii) such Person
is able to realize upon its assets and pay its debts and other liabilities, contingent obligations
and commitments as they mature and become due in the normal course of business and (iii) such Person
is not incurring debts or liabilities beyond its ability to pay such debts and liabilities as they
mature.

"Sponsor" means Cellco.

A-37

Source: VERIZON ABS LLC, 8-K, 1/23/2020
<!-- page 100 -->
"State" means a state or commonwealth of the United States of America, or the District of Columbia.

"Subcontractor" means any vendor, subcontractor or other Person that is not responsible for the
overall servicing (as "servicing" is commonly understood by participants in the asset-backed
securities market) of the Receivables but performs one or more discrete functions identified in the
Servicing Criteria with respect to the Receivables under the direction or authority of the Servicer
or a Subservicer.

"Subservicer" means any Person that services Receivables on behalf of the Servicer or any
Subservicer and is responsible for the performance (whether directly or through Subservicers or
Subcontractors) of a substantial portion of the material servicing functions required to be
performed by the Servicer under this Agreement that are identified in the Servicing Criteria.

"Successor Servicer" has the meaning stated in Section 7.4(a)(i) of the Transfer and Servicing
Agreement.

"Supplemental Servicing Fee" means, for a Collection Period, all net Recoveries, late fees,
prepayment charges, extension fees and other administrative fees or similar charges on the
Receivables.

"Temporarily Excluded Receivables" means any Receivable deemed to be temporarily excluded by the
Administrator from any calculation required to be made by the Administrator or the Servicer pursuant
to and in accordance with the terms of the Transaction Documents.

"Temporarily Excluded Receivables Servicing Fee" means, for a Collection Period, the fee payable to
the Servicer in an amount equal to the product of:

(a) one-twelfth of the Servicing Fee Rate; times

(b) the aggregate Principal Balance of all Temporarily Excluded Receivables at the beginning of the
calendar month immediately preceding such Collection Period.

"Term SOFR" means the forward-looking term rate for the applicable Corresponding Tenor based on SOFR
that has been selected or recommended by the Relevant Governmental Body.

"Third Priority Principal Payment" means, for a Payment Date, the greater of:

(a) an amount (not less than zero) equal to:

(i) the aggregate Note Balances of the Class A Notes, the Class B Notes and the Class C Notes as of
the immediately preceding Payment Date (or, for the initial Payment Date, as of the Closing Date);
minus

(ii) the Adjusted Pool Balance; minus

A-38

Source: VERIZON ABS LLC, 8-K, 1/23/2020
<!-- page 101 -->
(iii) the First Priority Principal Payment; minus

(iv) the Second Priority Principal Payment; and

(b) on and after the Final Maturity Date for the Class C Notes, the Note Balance of the Class C
Notes until paid in full.

"Total Required Payment" means,

(a) for a Payment Date and the Reserve Account Draw Amount, the sum of the amounts set forth in
Sections 8.2(c)(i) through (viii) of the Indenture; and

(b) for a Payment Date and the Negative Carry Account Draw Amount, the sum of the amounts set forth
in Sections 8.2(c)(i) through (xiii) of the Indenture.

Following an Event of Default and an acceleration of the Notes or an Insolvency Event or dissolution
of the Depositor, until the Note Balances of each Class of Notes have been paid in full, the Total
Required Payment will also include the aggregate Note Balances of all Notes.

"Transaction Documents" means the Certificate of Trust, the Trust Agreement, the Receivables
Transfer Agreements, the Transfer and Servicing Agreement, the Indenture, the Administration
Agreement, the Asset Representations Review Agreement, the Parent Support Agreement, the
Underwriting Agreement, the Marketing Agent Agency Agreement, the Depository Agreement, the Cap
Agreement and the Account Control Agreement.

"Transfer and Servicing Agreement" means the Transfer and Servicing Agreement, dated as of the
Closing Date, among the Issuer, the Depositor and Cellco as Servicer, Marketing Agent and Custodian,
as amended, restated, supplemented or modified from time to time.

"Transfer Notice" means the notice to the Issuer, the Depositor and the Indenture Trustee regarding
the acquisition of Additional Receivables under Section 2.1(d) of each of the Receivables Transfer
Agreements, substantially in the form of Exhibit A to each such Receivables Transfer Agreement.

"Treasury Rate" means, for any Payment Date on which a Make-Whole Payment is to be made, the rate
determined on the third Business Day preceding such Payment Date equal to:

(i) the yield, under the heading which represents the average for the immediately preceding week,
appearing in the most recently published statistical release published by the Board of Governors of
the Federal Reserve System designated as "Statistical Release H. 15(519)" or any successor
publication which is published weekly by the Board of Governors of the Federal Reserve System and
which establishes yields on actively traded United States Treasury securities adjusted to constant
maturity under the caption "Treasury Constant Maturities," for the maturity corresponding to the
Comparable Treasury Issue (if no maturity is within three months before or after the Remaining Life
(as defined in the definition of Comparable Treasury Issue), yields for the two published

A-39

Source: VERIZON ABS LLC, 8-K, 1/23/2020
<!-- page 102 -->
maturities most closely corresponding to the Comparable Treasury Issue will be determined and the
Treasury Rate will be interpolated or extrapolated from those yields on a straightline basis,
rounding to the nearest month), or

(ii) if that release (or any successor release) is not published during the week preceding the
calculation date or does not contain those yields, the rate per annum equal to the semiannual
equivalent yield to maturity of the Comparable Treasury Issue, calculated using a price for the
Comparable Treasury Issue (expressed as a percentage of its principal amount) equal to the
Comparable Treasury Price for the date of redemption.

"Treasury Regulations" shall mean regulations, including proposed or temporary regulations,
promulgated under the Code. References herein to specific provisions of proposed or temporary
regulations shall include analogous provisions of final Treasury Regulations or other successor
Treasury Regulations.

"True Up Trust" means Verizon DPPA True Up Trust, a Delaware statutory trust, or its successors or
assigns.

"Trust Agreement" means the Amended and Restated Trust Agreement, dated as of the Closing Date,
between the Depositor and the Owner Trustee, as amended, restated, supplemented or modified from
time to time.

"Trust Indenture Act" or "TIA" means the Trust Indenture Act of 1939 as in force on the date hereof,
unless otherwise specifically provided.

"Trust Property" means the Initial Trust Property and any Additional Trust Property.

"Trust Register" has the meaning stated in Section 3.3(a) of the Trust Agreement.

"Trust Registrar" has the meaning stated in Section 3.3(a) of the Trust Agreement.

"U.S. Credit Risk Retention Rules" means Regulation RR, 17 C.F.R. §246.1, et seq.

"UCC" means the Uniform Commercial Code as in effect in any relevant jurisdiction.

"Unadjusted Benchmark Replacement" means the Benchmark Replacement excluding the Benchmark
Replacement Adjustment.

"Underwriting Agreement" means the Underwriting Agreement, dated as of January 21, 2020, by and
among the Depositor, Cellco and each of BofA Securities, Inc., Mizuho Securities USA LLC, MUFG
Securities Americas Inc. and Wells Fargo Securities, LLC, each on its own behalf and as a
representative of the several underwriters identified therein.

"Underwriting Procedures" means the underwriting procedures of the Originators, as established by
Cellco, relating to device payment plan agreements originated by the Originators, as such
underwriting procedures may be amended or modified from time to time.

A-40

Source: VERIZON ABS LLC, 8-K, 1/23/2020
<!-- page 103 -->
"Upgrade Contract" has the meaning stated in the Glossary of the Marketing Agent Agency Agreement.

"Upgrade Offer" means the Annual Upgrade Offer or any other upgrade offer extended by Verizon
Wireless to an existing Obligor under which such Obligor can upgrade a Device that is the subject of
a device payment plan agreement if the terms and conditions specified in such offer are satisfied.

"Upgrade Payment" means a prepayment amount equal to the remaining unpaid Principal Balance of the
related Receivable determined as of the date of the relevant upgrade, after giving effect to any
prepayment made by the related Obligor in connection with the related Upgrade Offer.

"Verified Note Owner" has the meaning stated in Section 14.1 of the Indenture.

"Verizon" means Verizon Communications Inc., a Delaware corporation.

"Verizon Originators" means the various subsidiaries and Affiliates of Cellco listed on Schedule I
to the Marketing Agent Agency Agreement.

"Verizon Wireless" means the wireless business of Verizon, operated by Cellco and various other
subsidiaries of Verizon, including the Originators, under the Verizon Wireless brand.

"Written-Off Receivable" means any Receivable that in accordance with the Servicing Procedures has
been charged off or written off by the Servicer.

"Yield Amount" means, for each Receivable on the Closing Date, on each Payment Date and on each
Acquisition Date other than a Payment Date, the amount by which (x) the Principal Balance as of the
last day of the related Collection Period or as of the applicable Cutoff Date, as applicable, for
such Receivable exceeds (y) the present value of the future scheduled payments on the Receivable as
of the last day of the related Collection Period (or as of the applicable Cutoff Date, for the first
Payment Date for the Receivables) calculated using the Discount Rate. For purposes of this
calculation, the future scheduled payments on each Receivable are the equal monthly payments that
would reduce the Receivable's Principal Balance as of the related Cutoff Date to zero on the
Receivable's final scheduled payment date, at an interest rate equal to the APR of the Receivable,
which payments are received at the end of each month without any delays, defaults or prepayments.

"Yield Supplement Overcollateralization Amount" means, for the Closing Date, for each Payment Date
and for each Acquisition Date other than a Payment Date, an amount calculated as the sum of the
Yield Amounts for all Receivables owned by the Issuer with an APR as stated in the related device
payment plan agreement of less than 7.65%.

A-41

Source: VERIZON ABS LLC, 8-K, 1/23/2020

Exhibit A

Custodian's Security Requirements
<!-- page 104 -->
(See Attached)

EA-1

Source: VERIZON ABS LLC, 8-K, 1/23/2020

Exhibit B

FORM OF ANNUAL CERTIFICATION
<!-- page 105 -->
Re: The Transfer and Servicing Agreement, dated as of January 29, 2020 (the "Agreement"), among
Verizon Owner Trust 2020-A (the "Issuer"), Verizon ABS LLC (the "Depositor"), and Cellco Partnership
d/b/a Verizon Wireless ("Cellco"), as servicer (in such capacity, the "Servicer"), as marketing
agent and as custodian.

I, ________________________________, the _____________of __________ [NAME OF COMPANY] (the
"Company"), certify to the Issuer, the Administrator and the Depositor, and their officers, with the
knowledge and intent that they will rely upon this certification, that:

(1) I have reviewed the servicer compliance statement of the Company provided in accordance with
Item 1123 of Regulation AB (the "Compliance Statement"), the report on assessment of the Company's
compliance with the servicing criteria set forth in Item 1122(d) of Regulation AB (the "Servicing
Criteria"), provided in accordance with Rules 13a-18 and 15d-18 under Securities Exchange Act of
1934, as amended (the "Exchange Act") and Item 1122 of Regulation AB (the "Servicing Assessment"),
the registered public accounting firm's attestation report provided in accordance with Rules 13a-18
and 15d-18 under the Exchange Act and Section 1122(b) of Regulation AB (the "Attestation Report"),
and all servicing reports, officer's certificates and other information relating to the servicing of
the Receivables by the Company during 20[__] that were delivered by the Company to the Issuer and
the Depositor pursuant to the Agreement (collectively, the "Company Servicing Information");

(2) Based on my knowledge, the Company Servicing Information, taken as a whole, does not contain any
untrue statement of a material fact or omit to state a material fact necessary to make the
statements made, in the light of the circumstances under which such statements were made, not
misleading with respect to the period of time covered by the Company Servicing Information;

(3) Based on my knowledge, all of the Company Servicing Information required to be provided by the
Company under the Agreement has been provided to the Issuer and the Depositor;

(4) I am responsible for reviewing the activities performed by the Company as Servicer under the
Agreement, and based on my knowledge and the compliance review conducted in preparing the Compliance
Statement [and except as disclosed in the Compliance Statement, the Servicing Assessment or the
Attestation Report,] the Company has fulfilled its obligations under the Agreement in all material
respects; and

(5) The Compliance Statement required to be delivered by the Company pursuant to the Agreement, and
each Servicing Assessment and Attestation Report required to be provided by the Company and by any
Subservicer or Subcontractor pursuant to the Agreement, have been provided to the Issuer, the
Administrator, the Depositor, the Indenture Trustee and the Owner Trustee. Any material instances of

EB-1

Source: VERIZON ABS LLC, 8-K, 1/23/2020
<!-- page 106 -->
noncompliance with the Servicing Criteria have been disclosed in such reports and have been
disclosed to the Issuer, the Administrator and the Depositor.

Capitalized terms used herein and not otherwise defined have the meaning given to such terms in the
Agreement.

Date: _________________________

By: ___________________________ Name: Title: EB-2

Source: VERIZON ABS LLC, 8-K, 1/23/2020
