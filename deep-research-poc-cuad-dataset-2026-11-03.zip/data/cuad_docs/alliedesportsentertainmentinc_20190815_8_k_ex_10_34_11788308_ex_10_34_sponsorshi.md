<!-- page 1 -->
# EVENT SPONSORSHIP AGREEMENT
| Field | Value |
|---|---|
| Document Type | Sponsorship Agreement |
| Agreement Date | 2019-02-01 |
| Parties | Newegg Inc. ("Newegg"); Allied Esports International, Inc. ("Allied")("Parties" and each as a "Party") |
| Source | CUAD v1 / AlliedEsportsEntertainmentInc_20190815_8-K_EX-10.34_11788308_EX-10.34_Sponsorship Agreement |

Exhibit 10.34 EVENT SPONSORSHIP AGREEMENT This Event Sponsorship Agreement ("Agreement") is made and
effective as of February 1, 2019 (the "Effective Date"), by and between Newegg Inc. ("Newegg"), a
Delaware corporation, and Allied Esports International, Inc., a Nevada corporation ("Allied").
Newegg and Allied are hereinafter referred to jointly as the "Parties" and each as a "Party."
BACKGROUND A. Newegg, an online retailer of items including computer hardware and consumer
electronics, is in the business of developing, marketing, selling and supporting gaming accessories
and memory products, and proposes to provide promotional and product support as a sponsor for the
HyperX Esports Arena Las Vegas ("the Arena"). B. Allied is an esports organization that owns and
controls the Commercial Rights (as hereinafter defined) to the Arena and wishes to grant rights to
Newegg in respect of Newegg's sponsorship of the Arena pursuant to this Agreement. C. Each of the
Parties undertakes obligations to the other Party as provided in this Agreement. For valuable
consideration received, including the Parties' respective covenants in this Agreement, the Parties
hereby agree as follows: 1. Scope of this Agreement. Newegg agrees to provide certain financial
sponsorship, including fees to Allied in connection with the Arena and Allied agrees to grant
certain rights to Newegg, all as described in this Agreement. 2. Certain Definitions. When used in
this Agreement, the following terms have the following meanings: 2.1 "Commercial Rights" means any
and all rights of a commercial nature connected with the Arena, including image rights, broadcasting
rights, new media rights, endorsement and official supplier rights, sponsorship rights,
merchandising rights, licensing rights, advertising rights, hospitality rights and all intellectual
property rights in and to the foregoing. 2.2 "Including," "Includes" and similar words means
"including but not limited to" and shall mean in all contexts "without limitation." 2.3
"Intellectual Property Rights" means rights protecting or governing intellectual property rights,
including all now known and hereafter existing: (i) copyright and related rights in original works
of authorship and all rights to use, commercialize, and exploit such rights; (ii) rights on
trademarks, service marks, trade names, logos, trade dress, indicia of origin, and other commercial
names; (iii) trade secret rights including, without limitation, all rights in confidential
information, trade secret, know-how and other proprietary and/or confidential materials and
information, whether arising by law or contract; (iv) patent rights, rights in patentable inventions
and processes, utility models, designs, algorithms and other industrial property rights; and (v)
other intellectual property rights and proprietary rights of every kind and nature throughout the
world, whether arising by operation of law, by contract, by license or otherwise in any form, media
or technology now known or later developed. 2.4 "Newegg Marks" means the Newegg trademarks and logos
set out in Schedule 1, together with any accompanying artwork, design, slogan, text and other
collateral marketing signs of Newegg. 2.5 "Allied Marks" means Allied's trademarks to be used for
all promotion, advertising and marketing of the Arena, as set out in Schedule 2, including the
texts, slogans, logos, trademarks, images, photographs, information, audio and video materials and
other materials owned (or licensed from a third party) by Allied and used in or in connection with
the Arena, and including Allied's name and the names used for any parts of the Arena.

1

Source: ALLIED ESPORTS ENTERTAINMENT, INC., 8-K, 8/15/2019
<!-- page 2 -->
2.6 "Sponsorship Benefits" means the benefits Newegg will provide Allied, including the license
granted in Section 6.1 and the fee stated in Schedule 3. 2.7 "Sponsorship Rights" means the bundle
of rights, services and deliverables Allied will provide to Newegg as set out in Schedule 4, which
includes the license of, and rights with respect to, Allied Marks granted in Section 5. 2.8
"Technology E-Commerce (or E-Tail)" means the Arena partnership category that Allied is granting to
Newegg and is defined as including technology-focused products in categories including computer
systems, components, electronics, gaming, networking, office solutions, software & services,
automotive and industrial, home and tools, health & sports, and hobbies and toys. For purposes of
clarity, this does not include apparel and accessories. 2.9 "Term" has the meaning given in Section
3 of this Agreement. 2.10 "Sponsorship Fee" has the meaning given in Schedule 3 of this Agreement.
2.11 "Venue" means the premises where events wi ll occur. 3. Term of this Agreement. This Agreement
shall be valid for five (5) years from February 1, 2019 through January 31, 2024 unless this
Agreement is terminated earlier pursuant to Section 14 (the "Term"). For the purpose of clarity, the
second year of this Agreement starts February 1, 2020, and the third year of this Agreement starts
February 1, 2021 the fourth year of this Agreement starts February 1, 2022, and the fifth and final
year of this Agreement starts February 1, 2023. 4. Allied Obligations and Newegg Sponsorship
Obligations 4.1 Allied shall provide, by the license granted in Section 5.1 and otherwise as
appropriate, to or for the benefit of Newegg, the Sponsorship Rights, including generally providing
advertising space in all of Allied's media and participation in Allied's marketing activities
relating to the Arena 4.2 Newegg shall provide to Allied the Sponsorship Benefits set out in
Schedule 3, including paying the Sponsorship Fee as provided in that Schedule. Any value-added,
goods and services, or similar tax or duty imposed by any government or tax authority on any
Sponsorship Benefit shall be borne solely by Allied. 4.3 During third-party event buyouts, Newegg's
sponsorship benefits will run at the discretion of the third-party and may not be included for
select events. Newegg's pass-through rights are limited to both Newegg and Allied-owned and operated
events. 5. Allied's License to Newegg 5.1 Allied grants Newegg a non-exclusive, royalty-free,
non-assignable, non-transferable, and non- sublicensable worldwide license to use, publicly display,
transmit, broadcast, stream, distribute and reproduce the Allied Marks in all approved forms and in
manners for the purposes of this Agreement during the Term. Allied acknowledges and agrees that
Newegg shall not pay any fees or royalties for the license of the Allied Marks, except the
Sponsorship Fee specified in Schedule 3. 5.2 Without limitation of any other provision of this
Agreement, failure by Allied to comply with the provisions of Sections 5.1 shall be deemed as a
material breach of this Agreement and Newegg has the right to terminate this Agreement subject first
to the cure provisions in Section 14.1 and be discharged from any further obligation to pay the
Sponsorship Fee. If any portion of the Sponsorship Fee shall have previously been paid for any
period following such termination by Newegg, the Sponsorship Fee shall be prorated and Allied shall
immediately refund the portion corresponding to the unused period of the Term.

2

Source: ALLIED ESPORTS ENTERTAINMENT, INC., 8-K, 8/15/2019
<!-- page 3 -->
6. Newegg's License to Allied; Allied's Obligations Regarding Newegg Marks and Products 6.1 Newegg
grants Allied a revocable, non-transferrable, non-assignable (whether voluntarily, or as a result of
a change of control, or by operation of law), non-sublicensable, non-exclusive and limited license
to use, during the Term, the Newegg Marks solely in connection with Allied's marketing and conduct
of the Arena. 6.2 Allied acknowledges and agrees that Newegg has valuable goodwill and reputation in
the Newegg Marks and that Newegg is and shall be at all times the sole and exclusive owner of
rights, including Intellectual Property Rights, in and related to the Newegg Marks. Allied does not
acquire any right, title, or interest in or to the Newegg Marks by virtue of the limited license
granted in Section 6.1, or through Allied's permitted use of the Newegg Marks, other than the right
to use such Newegg Marks in accordance with that license. Allied acknowledges that its use of the
Newegg Marks pursuant to this Agreement, and all goodwill associated with such use, shall inure
exclusively to the benefit of Newegg. Allied further acknowledges and agrees that Newegg shall have
sole control and final editorial say, in Newegg's sole discretion, over the marketing/promotion,
appearance, design, layout, placement, and presentation of Newegg's Products, including all
packaging, advertisements and other marketing and promotional materials relating to the Newegg
Products. 6.3 Allied shall use the Newegg Marks only in strict compliance with the terms and
conditions of this Agreement. Allied's use of the Newegg Marks (a) shall be subject to Newegg's
right of review and approval, and prior direction and control, to be exercised in Newegg's sole
discretion, and (b) shall, at all times, meet or exceed Newegg's trademark-usage guidelines and
quality standards which may be provided by Newegg from time to time ("Acceptable Quality
Standards"). Without limiting any other provision of this Section 6.3, if at any time Newegg
reasonably determines that Allied's use of the Newegg Marks fails to comply with this Agreement or
to conform to the Acceptable Quality Standards, Allied shall, within five (5) days of receipt of
notice from Newegg, correct its use of the Newegg Marks so that its use is in compliance with this
Agreement and the Acceptable Quality Standards or cease using, and remove, the Newegg Marks from all
of Allied's videos, streams and other publications in all media ("Allied's Correction Action").
Allied's obligation to take and complete Allied's Correction Action shall survive any expiration or
termination of this Agreement. 6.4 Allied shall not at any time do, or cause to be done, directly or
indirectly any act that may impair or tarnish any part of Newegg's goodwill and reputation in the
Newegg Marks and the Newegg Products. Without limiting the preceding sentence, Allied agrees not to
use the Newegg Marks in any advertising materials or conduct any activities in a manner that may be
seen to unreasonably modify, alter, detract from or impair the integrity, character, or dignity of
the Newegg Marks or reflect unfavorably upon Newegg or Newegg Products. 6.5 In exercise of the
rights granted in Section 6.1, Allied shall always use the Newegg Marks in a manner that
significantly distinguishes them from any surrounding text or other logo or source designation.
Except as may be expressly authorized in writing by Newegg, Allied shall not use the Newegg Marks as
a co-brand with any third-party mark. Allied agrees to use the Newegg Marks only in the form and
with only the content provided by Newegg. The Newegg Marks may not be altered in any manner. The
Newegg Marks must include a ™ or ® symbol as part of the Newegg Marks, as provided by Newegg. Where
practicable, the following trademark notice must appear in close proximity to the Newegg Marks and
the ownership of the Newegg Marks must be identified: "Newegg and the Newegg logo are trademarks of
Newegg Incorporated." 7. Exclusivity of Sponsorship Rights for Newegg 7.1 In all of Allied's actions
and publications (in all media and formats) in connection with the marketing and conducting of the
Events, where possible and appropriate, Allied shall where reasonably practicable communicate that
Newegg is the exclusive sponsor of the Arena for the technology e-commerce and online retailer
categories. 7.2 Allied shall not endorse, or permit the marketing of any other company whose
principal business is as an e-commerce provider at or in connection with the Arena. For purposes of
clarity, this is not meant to prohibit incidental third-party endorsements not controlled by Allied
such as individual player and team sponsorships of participants in events at the Arena.

3

Source: ALLIED ESPORTS ENTERTAINMENT, INC., 8-K, 8/15/2019
<!-- page 4 -->
8. Refund or Reduction of Sponsorship Fee 8.1 Without limitation of other rights of Newegg under
this Agreement, the Parties agree to negotiate a reasonable reduction and, where applicable, the
refund of the Sponsorship Fee to reflect any material restriction in the benefit or value of the
Sponsorship Rights to Newegg, including as a result of any change in any laws or regulatory
provisions which has an adverse impact on the value of the Sponsorship Rights. 8.2 If Allied fails
to perform or provide the Sponsorship Rights in accordance with the terms of this Agreement, Newegg
shall, without limiting its other rights or remedies, have one or more of the following rights: (a)
to refuse to accept any subsequent performance of the Sponsorship Rights which Allied attempts to
make; and (b) where Newegg has paid in advance for Sponsorship Rights that have not been provided by
Allied, to have such sums refunded by Allied. 9. Certain Material Covenants of Allied 9.1 Allied
shall organize and host events, both online and at the Venue, at its sole cost and expense in
accordance with the terms of this Agreement, and perform and cause to be performed the Sponsorship
Rights with reasonable skill and care and in accordance with generally recognized commercial
practices and standards. 9.2 Allied shall use its best endeavours to deliver or ensure the delivery
to Newegg of each and all of the Sponsorship Rights. Without limitation of the preceding sentence or
any other provision of this Agreement, Allied shall identify and name Newegg as a Founding Partner,
and as the exclusive Technology E-Commerce (or E-tail) Partner, of the Arena and in all of Allied's
marketing materials in connection with the Arena where reasonably practicable. 9.3 Allied shall
ensure that all relevant Newegg signage and advertising to be delivered as part of the Sponsorship
Rights is properly in place, and operational and not concealed or obscured from view. 9.4 Allied
confirms that, whenever possible, it will ensure that Newegg Marks will be present in accordance
with this Agreement and that Newegg Marks are incorporated into all promotional, advertising and
publicity material published in connection with the Arena where reasonably practicable. 9.5 Allied
shall comply with: (a) all applicable laws, rules, regulations, regulatory policies, guidelines or
codes applicable to the Arena and Allied's activities to be carried out in performing its
obligations in accordance with this Agreement, including all such guidelines and codes issued by
statutory, regulatory and industry bodies, and further, will not pay, deliver, or offer or promise
to pay or deliver, any funds or other item of value excluding the Products, either directly or
through any third party, to any state or federal governmental official for any reason whatsoever
other than the payment of statutory and administrative fees, charges and taxes that are due from
Allied as a result of its performance under this Agreement; (b) the terms and conditions, rules of
conduct and/or community guidelines of any other online platform (including any advertising
policies); and (c) any conditions attached to any licences or consents issued in connection with the
Arena including regarding health and safety and crowd security measures at the Arena. 9.6 Allied
accepts that, regardless of its obligations to promote the Arena within the terms of this Agreement,
Newegg shall be entitled to advertise, publicise, promote and otherwise commercially exploit its own
Products, goodwill and reputation through Newegg's association with the Arena on and subject to the
terms of this Agreement throughout and after the Term.

4

Source: ALLIED ESPORTS ENTERTAINMENT, INC., 8-K, 8/15/2019
<!-- page 5 -->
9.7 Allied shall make available to Newegg in connection with the Arena Allied's Marks in order for
Newegg to exploit and make best use of the Sponsorship Rights. 9.8 For the avoidance of doubt,
Allied shall be at all times responsible for its employees', agents' and sub- contractors'
compliance with the obligations set out in this Section 9. 10. Certain Material Covenants of Newegg
10.1 Newegg shall exercise the Sponsorship Rights in accordance with the terms of this Agreement.
For the avoidance of doubt, Newegg shall not be entitled to use or exploit any of the Commercial
Rights other than the Sponsorship Rights in any way except in accordance with this Agreement. 10.2
Newegg shall provide to Allied, at Newegg's cost and expense, all necessary materials including
artwork of Newegg Marks in a format and within print deadlines reasonably specified by Allied in
order for it to be reproduced under the control of Allied for the fulfilment of the Sponsorship
Rights. 11. Representations and Warranties 11.1 Each Party represents and warrants to the other
Party that it has, and will maintain throughout the Term, the right, power and authority to enter
into and perform this Agreement and to grant the licenses as provided in this Agreement; that it has
procured all rights, permissions and approvals necessary for the performance of its obligations,
including the grant of licenses, in this Agreement; and that it is not bound by any agreement with
any third party that adversely affects its performance of its obligations in, or that would preclude
it from fully complying with the provisions of, this Agreement. 11.2 Each Party covenants that it
shall not make, publish or communicate to any person or entity in any online or other public forum
any defamatory, misleading or disparaging remarks, comments or statements concerning (a) the other
Party or any of its affiliates, or any of such Party's or its affiliates' respective employees,
officers, directors, agents, officials, equity holders, investors or sponsors, or (b) any software,
products or services of the other Party or any affiliate. 11.3 Each Party represents and warrants
that it is not a government-owned entity and that neither its management personnel nor any of its
employees are government officials. 11.4 Newegg represents and warrants that it holds the necessary
rights to permit Allied to use Newegg's Marks in accordance with the license granted in Section 6.1;
and that to Newegg's actual knowledge the use, reproduction, distribution or transmission of
Newegg's Marks will not violate any criminal laws, or any rights of any third parties, including,
but not limited to, such violations as infringement or misappropriation of any copyright, patent,
trademark, trade secret, music, image, or other proprietary or property right, false advertising,
unfair competition, defamation, invasion of privacy or rights of celebrity, violation of any
anti-discrimination law or regulation, or any other right of any person or entity. 11.5 Allied
represents and warrants that it holds the necessary rights to permit Newegg to use Allied's Marks
and accept the Commercial Rights in accordance with the Sections 5.1 and 9.7; and that to Allied's
actual knowledge the use, reproduction, distribution or transmission of Allied's Marks will not
violate any criminal laws, or any rights of any third parties, including, but not limited to, such
violations as infringement or misappropriation of any copyright, patent, trademark, trade secret,
music, image, or other proprietary or property right, false advertising, unfair competition,
defamation, invasion of privacy or rights of celebrity, violation of any anti-discrimination law or
regulation, or any other right of any person or entity.

5

Source: ALLIED ESPORTS ENTERTAINMENT, INC., 8-K, 8/15/2019
<!-- page 6 -->
12. Indemnity and Liability 12.1 Each Party ("Indemnitor") will defend, indemnify and hold the other
Party (including associated officers, directors, shareholders, employees, agents and affiliates)
(cumulatively, "Indemnitee") harmless from and against any and all losses, damages, claims,
liabilities and expenses (including reasonable legal fees), suffered or incurred as a result of or
in connection with any claim, suit, action, demand, or proceeding brought against Indemnitee based
upon (a) a claim of a failure to perform, or a breach by Indemnitor of, any obligation, warranty,
representation or covenant in this Agreement; (b) a claim of personal injury or property damage
arising out of the fault or negligence of Indemnitor, its representatives, agents, or employees; or
(c) a claim of infringement or misappropriation of any patent, trademark, copyright or other
proprietary right held by any third party. 12.2 EXCEPTING ONLY CLAIMS MADE PURSUANT TO SECTION 12.1,
IN NO EVENT WILL EITHER PARTY BE LIABLE FOR ANY INDIRECT, SPECIAL, INCIDENTAL, EXEMPLARY, PUNITIVE
OR CONSEQUENTIAL DAMAGES OF ANY KIND, INCLUDING ANY LOST PROFITS, LOST REVENUES OR LOST SAVINGS,
ARISING OUT OF OR IN CONNECTION WITH THIS AGREEMENT AND/OR THE PRODUCTS, WHETHER IN CONTRACT, TORT,
STRICT LIABILITY OR OTHERWISE, EVEN IF THE PARTY HAS BEEN ADVISED, KNOWS OR SHOULD KNOW, OR IS
OTHERWISE AWARE OF THE POSSIBILITY OF SUCH DAMAGES. 13. Confidentiality 13.1 Confidential
Information. Each Party (the "Disclosing Party") may from time to time during the Term of this
Agreement disclose to the other Party (the "Receiving Party") certain information regarding the
Disclosing Party's business, including, without limitation, technical, marketing, financial,
employee, planning and other confidential or proprietary information, which information is either
marked as confidential or proprietary (or bears a similar legend) or which a reasonable person would
understand to be confidential given the circumstance and nature of the disclosure ("Confidential
Information"), whether disclosed orally or in writing. Without limiting the foregoing, Newegg's
Confidential Information shall include information and materials provided by Newegg in connection
with this Agreement. Confidential Information does not include information that: (i) is in the
Receiving Party's possession at the time of disclosure as shown by credible evidence; (ii) before or
after it has been disclosed to the Receiving Party, enters the public domain, not as a result of any
action or inaction of the Receiving Party; (iii) is approved for release by written authorization of
the Disclosing Party; (iv) is disclosed to the Receiving Party by a third party not in violation of
any obligation of confidentiality; or (v) is independently developed by the Receiving Party without
reference to Confidential Information of the Disclosing Party, as evidenced by such Party's written
records. 13.2 Protection of Confidential Information. The Receiving Party will not use, and will
cause its Representatives not to use, any Confidential Information of the Disclosing Party for any
purpose other than performing its obligations or exercising its rights under this Agreement, and
will not disclose the Confidential Information of the Disclosing Party to any party other than
Receiving Party's employees, agents, directors, officers, auditors, attorneys, other professional
advisors, regulators and contractors (collectively, the "Representatives") on a "need to know"
basis, provided such Representatives are under a contractual obligation with Receiving Party to
maintain the confidentiality of such Confidential Information, which obligation is consistent with,
and no less protective of Confidential Information, than the terms of this Section 13. The Receiving
Party will protect the Disclosing Party's Confidential Information from unauthorized use, access, or
disclosure in the same manner as the Receiving Party protects its own confidential or proprietary
information of a similar nature and with no less than reasonable care. 13.3 Confidentiality of
Agreement. Other than as permitted in this Agreement, neither Party will disclose any terms of this
Agreement except: (a) as required by law, or (b) pursuant to a mutually agreeable press release.
Press releases concerning Newegg's sponsorship of the Events will only be published after written
preapproval by both Parties, provided that if for any reason the Parties cannot agree about a
specific release, Newegg shall have the ultimate decision-making right concerning whether to issue
any press releases about this Agreement or Newegg's sponsorship of the Events. 13.4 Return of
Confidential Information. Upon any termination or expiration of this Agreement, Allied shall deliver
to Newegg all originals and copies of any material in any form containing or representing Newegg's
Marks and other Confidential Information of Newegg or, at Newegg's request, shall destroy the same
and provide Newegg a certification of the destruction. 13.5 Expiry or termination of this Agreement
shall not affect any accrued rights, liabilities or obligations dealing with protection of the
Confidential Information of either Party. The expiration or termination of this Agreement shall also
not affect the obligations of this Section 13 with respect to any of Newegg's Confidential
Information that is protected as a trade secret, which shall remain covered by this Section 13 for
the duration of the trade secret.

6

Source: ALLIED ESPORTS ENTERTAINMENT, INC., 8-K, 8/15/2019
<!-- page 7 -->
14. Expiry or Termination 14.1 Failure by Allied to perform and comply with any of its obligations
in sections 5, 6, 7, 9, 11, 12 and 13 of this Agreement shall be deemed a material breach of this
Agreement and Newegg shall have the right to terminate this Agreement immediately if Allied fails to
cure the breach within fifteen (15) days following Newegg's written notice of the breach. 14.2 Each
Party may also terminate the Agreement for convenience after Contract Year 2 (as defined in Section
14.4) by providing written notice to the other Party at least sixty (60) calendar days prior to the
effective date of such termination 14.3 Except as provided in (i) Section 5.2 for immediate
termination subject to cure provisions in Section 14.1 , (ii) Section 14.1 for termination following
notice, and (iii) Section 14.5 for immediate termination without notice, if either Party defaults in
the performance, or breaches any provision, of this Agreement, then the non- defaulting Party may
give written notice to the defaulting Party requiring the default or breach to be cured, and if the
default or breach is not cured within fifteen (15) days of the receipt of the notice, this Agreement
shall, without prejudice to any accrued right, automatically terminate at the end of the fifteen
(15) day period. 14.4 During the first two (2) contract years of Term (i.e., February 1, 2019
through January 31, 2020 ("Contract Year 1") and February 1, 2020 through January 31, 2021
("Contract Year 2")) and notwithstanding any other provisions of this Agreement, if Newegg defaults
on or breaches any its obligations under the Agreement for any reason and fails to cure such default
or breach within fifteen (15) days following receipt of Allied's written notice of such default or
breach, the Parties acknowledge and agree that (i) Newegg shall remain responsible and/or liable for
the full payment or, if applicable, the remaining portion of the Sponsorship Fee for Contract Year 1
and Contract Year 2, and (ii) Allied shall have the right to pursue any additional legal and
equitable remedies in connection with the Agreement. 14.5 This Agreement shall terminate
immediately, without any requirement of notice, (i) upon the institution against or the filing by
either Party of insolvency, receivership or bankruptcy proceedings; or (ii) upon either Party making
an assignment for the benefit of its creditors. 14.6 Upon termination for any reason, Newegg shall,
without prejudice to its other rights, be immediately discharged of all obligations to pay any
further Sponsorship Fees not yet rendered or to provide any further Sponsorship Benefits that have
not already been delivered to Allied. Further, if Sponsorship Fees have been paid in advance, the
Sponsorship Fee shall be prorated through the date of termination and Allied shall refund the
portion corresponding to the unused period of the Term. 14.7 Notwithstanding the expiry or
termination of this Agreement, both Parties shall not, and shall ensure that its Representatives
shall not, do any of the following: (a) make any form of representation (whether express or implied)
that Allied remains under the sponsorship of or in public association with Newegg; or (b) commit any
act that would reasonably be seen as disparaging (whether expressly or implicitly) the Newegg and
Allied brand names, reputations or any of their respective products or offerings. 14.8 Upon expiry
or termination of this Agreement, Newegg's license granted to Allied in Section 6.1 and all other
rights granted to Allied in this Agreement shall terminate and Allied shall cease any and all uses
of Newegg's Marks. 14.9 All provisions of this Agreement that by their nature extend beyond expiry
or termination of this Agreement shall remain in full force and effect notwithstanding the expiry or
termination of this Agreement.

7

Source: ALLIED ESPORTS ENTERTAINMENT, INC., 8-K, 8/15/2019
<!-- page 8 -->
15. Miscellaneous 15.1 Relationship. The relationship of the Parties is solely that of independent
contractors, and each Party will represent itself to any third parties only as such. Neither Party
has the power to bind, represent or act for the other Party. The Parties have no agency,
partnership, joint venture or fiduciary duties to each other. 15.2 Publicity. The Parties shall
co-operate in good faith on all announcements and press releases regarding this Agreement and
Newegg's sponsorship arrangement with Allied and Newegg shall determine in its sole discretion
whether any such announcement or press release shall be published. Press releases concerning
Newegg's sponsorship of the Arena will only be published after written preapproval by both Parties
and Newegg shall have the final decision making right concerning any press releases regarding
Newegg's sponsorship arrangement with Allied. 15.3 Expenses. Each Party shall be responsible for its
own costs and expenses in connection with all matters relating to the negotiation and performance of
this Agreement, unless otherwise agreed in writing by the Parties. 15.4 Assignment. Neither Newegg
nor Allied shall have the right or power to assign or transfer any part of its rights or obligations
under this Agreement without the prior consent in writing of the other Party. 15.5 Injunctive
Relief. Each Party agrees that money damages for a breach of its obligations under the provisions of
this Agreement protecting Confidential Information and those governing Intellectual Property Rights
may be an inadequate remedy for the loss suffered by the other Party and the other Party shall have
the right to obtain injunctive relief from any court of competent jurisdiction in order to prevent
the breach, or further breach as the case may be, of any such obligation, without limiting the other
Party's right to pursue any and all remedies provided in such event by law or equity. 15.6
Non-Waiver. All waivers must be in writing. No failure or delay by a Party in exercising any right,
power or privilege under this Agreement shall operate as a waiver thereof, nor shall any single or
partial exercise of any right, power or privilege preclude further exercise thereof or of any other
right, power or privilege. 15.7 Severability. If any provision of this Agreement is found by a court
of competent jurisdiction to be invalid, illegal, void or unenforceable, the provision shall be
modified as necessary to conform to such laws or, if such modification would be inconsistent with
the intent of the Parties, the provision shall be severed from this Agreement, and this Agreement
shall be interpreted without reference to the severed provision with the remaining provisions
continuing with full force and effect. 15.8 Entire Agreement. This Agreement, including the attached
Schedules, which are incorporated herein in their entirety, constitutes the entire agreement of the
Parties with respect to the subject matter hereof, and supersedes all prior agreements,
representations, understandings, written or oral. No amendment or modification of any provision of
this Agreement shall be binding upon the Parties unless made by a written instrument signed by a
duly authorized representative of each Party. 15.9 Notice. Any notice required under this Agreement
shall be given in writing, in the English language and sent to the address or e-mail address of the
other Party as set out below its signature of this Agreement, or such other address or email address
as shall have been notified to the other Party in accordance with this provision. Notices shall be
sent by registered post or equivalent, facsimile, courier or by electronic transmission. If posted,
the notice shall be deemed to have been received five (5) working days after the date of posting or,
in the case of a notice to an addressee not in the country of the sender, ten (10) working days
after the date of posting. If sent by facsimile or electronic transmission, notice shall be deemed
received upon confirmation of complete receipt being given by the intended receiving Party. If
couriered, notice will be deemed to have been received on delivery.

8

Source: ALLIED ESPORTS ENTERTAINMENT, INC., 8-K, 8/15/2019
<!-- page 9 -->
15.10 Governing Law and Jurisdiction. Without reference to choice or conflict of law principles,
this Agreement shall be governed by and construed in accordance with the laws of the State of
California, USA. The Parties unconditionally submit to exclusive jurisdiction of and accept as the
exclusive venue for any legal proceeding involving this Agreement the state and federal courts
located in the County of Los Angeles, California. Before any Party (the "Complaining Party") may
bring any legal proceeding against the other (the "Non Complaining Party"), the Complaining Party
shall first make a reasonable and good faith attempt to resolve all disputes privately by notifying
and providing to the Non Complaining Party of the Complaining Party's complaints, reasons and
supporting evidence for the complaints, and the reasonable steps Complaining Party would like the
Non Complaining Party to take in order to address the complaints. If for any reason the
Non-Complaining Party disagrees with either the complaint or the steps suggested to address the
complaints, the Parties shall discuss and work on an amicable solution for at least thirty (30) days
before the Complaining Party may bring any legal proceeding to resolve the complaints. Any dispute,
claim or controversy arising out of or relating to this Agreement or the breach, termination,
enforcement, interpretation, or validity thereof, including the determination of the scope and
applicability of this agreement to arbitrate, shall be determined by arbitration in Los Angeles
County, California, by an arbitrator of JAMS, in accordance with its arbitration rules and
procedures then in effect. Judgment on the arbitrator's award may be entered in any court having
jurisdiction. The prevailing Party in any dispute involving this Agreement shall be entitled to
recover from the other Party its costs, expenses, and reasonable attorneys' fees (including any fees
for expert witnesses, paralegals, or other legal service providers). This Section 15.10 shall not
preclude or place any condition on any Party from seeking injunctive relief from a court of
appropriate jurisdiction. 15.11 Third Party Rights. This Agreement does not confer any rights or
remedies on any third party. 15.12 Counterparts. This Agreement may be executed in any number of
counterparts, each of which when executed and delivered shall be deemed to be an original and all of
which counterparts taken together shall constitute one and the same instrument. 15.13 Headings. All
section headings contained in this Agreement are for convenience or reference only, do not form a
part hereof and shall not in any way affect the meaning or interpretation of this Agreement. 15.14
Force Majeure. Neither Party will be liable for any delays in the performance of any of its
obligations hereunder due to causes beyond its reasonable control, including earthquake, fire,
strike, war, riots, acts of any civil or military authority, acts of God, judicial action,
unavailability or shortages of labor, materials or equipment, terrorism or threat thereof, outbreak
of disease or other public health hazard, failure or delay in delivery by suppliers or delays in
transportation. In such event the Party unable to meet its obligations will use all best efforts to
remedy its delayed performance and will promptly notify the other Party in writing of the
circumstances affecting its timely performance.

9

Source: ALLIED ESPORTS ENTERTAINMENT, INC., 8-K, 8/15/2019
<!-- page 10 -->
IN WITNESS WHEREOF, the Parties have executed this Agreement acting through their duly authorized
representatives as of the Effective Date. "Newegg" "Allied" Newegg Inc. Allied Esports
International, Inc. By /s/ Mitesh Patel By: /s/ Judson Hannigan Name: Mitesh Patel Name: Judson
Hannigan Title: VP, Marketing Title: CEO Newegg Inc. Allied Esports International, Inc. Address:
Newegg Inc. 17560 Rowland St. City of Industry, CA 91745 USA

Address: Allied Esports International, Inc. 4000 McArthur Blvd, 6t h Floor Newport Beach, California
92660 Contact: +1 (714) 435-2600 Contact: +1 714-265-7323 Email: Email: jud@esportsallied.com
Attention: Legal Department By Newegg Legal at 11:40 am, Feb 25, 2019 Attention: Judson Hannigan

10

Source: ALLIED ESPORTS ENTERTAINMENT, INC., 8-K, 8/15/2019
