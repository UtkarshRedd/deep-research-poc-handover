<!-- page 1 -->
# COOPERATION AGREEMENT
| Field | Value |
|---|---|
| Document Type | Collaboration Agreement |
| Agreement Date | 2014-03-13 |
| Parties | JANA Partners LLC ("JANA"); URS Corporation ("Company") |
| Source | CUAD v1 / URSCORPNEW_03_17_2014-EX-99-COOPERATION AGREEMENT |

EXHIBIT B

COOPERATION AGREEMENT

This Agreement dated March 13, 2014 is by and between JANA Partners LLC ("JANA") and URS Corporation
(the "Company"). In consideration of and reliance upon the mutual covenants and agreements contained
herein, and for other good and valuable consideration, the receipt and sufficiency of which is
hereby acknowledged, the parties hereto agree as follows:

1. Representations and Warranties of the Company. The Company represents and warrants to JANA that
this Agreement has been duly authorized, executed and delivered by the Company, and is a valid and
binding obligation of the Company, enforceable against the Company in accordance with its terms.

2. Representations and Warranties of JANA. JANA represents and warrants to the Company that this
Agreement has been duly authorized, executed and delivered by JANA, and is a valid and binding
obligation of JANA, enforceable against JANA in accordance with its terms. As of the date of this
Agreement, JANA beneficially owns 6,745,623 shares of the Company's common stock and has voting
authority over such shares.

3. Board Nomination and Other Company Matters.

(a) In accordance with the Company's By­Laws and Delaware law, the Company agrees that, effective as
of the next meeting (the "March Board Meeting") of the Board of Directors of the Company (the
"Board"), which shall be held not later than March 27, 2014, and prior to taking any other formal
action at such meeting, the Board will:

(1) increase the size of the Board to fourteen (14) members; and

(2) appoint Diane C. Creel, William H. Schumann, III, David N. Siegel and V. Paul Unruh (together,
the "JANA Nominees") (other than in the case of the refusal or inability of any such person to
serve, in which case, the Board shall appoint his/her substitute chosen in accordance with Section
3(c)) as Company directors to fill the vacancies created thereby and to have the same rights of
participation in all other matters undertaken at the March Board Meeting as the other Company
directors; provided, however, that as a condition to the appointment of each JANA Nominee, such JANA
Nominee shall have completed and executed the Company's 2014 Questionnaire for Potential Director
Nominees and the Director Nominee Representation and Agreement, provided that such documents have
not been amended in any material respect from the versions provided to JANA prior to the date of
this Agreement, and have agreed to comply with all policies, codes of conduct, confidentiality
obligations and codes of ethics applicable to all of the Company's directors, including the
Company's Code of Business Conduct, to provide the information regarding themselves that is required
to be disclosed for candidates for directors and directors in a proxy statement under the federal
securities laws of the United States of America and/or applicable New York Stock Exchange rules and
regulations, and to provide such other customary information as reasonably requested by the Company;
and provided, further that any JANA Nominee may participate in the March Board Meeting
telephonically if unable to attend in person.

(b) The Company agrees that:
<!-- page 2 -->
(1) the Board will not approve any material new transactions prior to the March Board Meeting;

(2) at the 2014 annual meeting of the Company's shareholders (the "2014 Annual Meeting"), the Board
will nominate the JANA Nominees (other than in the case of the resignation, refusal or inability of
any such person to serve, in which case, the Board shall nominate his/her substitute chosen in
accordance with Section 3(c)), together with the other persons included in the Company's slate of
nominees for election as director at the 2014 Annual Meeting in accordance with Section 3(d), as
directors of the Company, in each case with a term expiring at the 2015 annual meeting of the
Company's shareholders (the "2015 Annual Meeting");

(3) the Board will recommend that the shareholders of the Company vote to elect the JANA Nominees as
directors of the Company at the 2014 Annual Meeting;

(4) the Company shall use its reasonable best efforts (which shall include the solicitation of
proxies) to obtain the election of the JANA Nominees at the 2014 Annual Meeting (it being understood
that such efforts shall be not less than the efforts used by the Company to obtain the election of
any other independent (as determined under Section 303A of the New York Stock Exchange's Listed
Company Manual) director nominee nominated by it to serve as a director on the Board at the 2014
Annual Meeting); and

(5) two individuals who are Company directors as of the date of this Agreement (other than Martin M.
Koffel, or in addition to Mr. Koffel if applicable under Section 4(b) of this Agreement) will not
seek re-election to the Board at the 2014 Annual Meeting, and the Company shall not seek to fill
such vacancies.

(c) The Company agrees that if any of the JANA Nominees resigns as a director or otherwise refuses
to or is unable to serve as a director at any time prior to the 2015 Annual Meeting, including as a
result of death or disability, JANA shall be entitled to designate a replacement director who shall
be independent of JANA, would be considered an independent director of the Company under Section
303A of the New York Stock Exchange's Listed Company Manual, is reasonably acceptable to the Board
as a replacement director and has a comparable amount of business experience, although such
experience need not be in the same industry or industries, and is in equally good standing in all
material respects, as the JANA Nominee being replaced. For the avoidance of doubt, the substitute
director shall thereafter be deemed a JANA Nominee for purposes of this Agreement and be entitled to
the same rights and subject to the same requirements under this Agreement applicable to the
resigning JANA Nominee prior to his or her resignation, and such person shall be appointed to the
Board to serve the unexpired term, if any, of such JANA Nominee.

(d) Other than the JANA Nominees, the Board will only nominate eight (8) individuals for election at
the 2014 Annual Meeting, including Mr. Koffel subject to Section 4(b) of this Agreement.

(e) Promptly following the 2014 Annual Meeting, the Board will decrease the size of the Board to
twelve (12) members. Until the 2015 Annual Meeting, the Company shall not increase the size of the
Board in excess of twelve (12) members, and shall not decrease the size of the Board if such
decrease would require the resignation of one or more of the JANA Nominees. Other than for vacancies
filled pursuant to Section 3(c) or arising as a result of a breach of this Agreement by the Company,
nothing in this Agreement shall prevent the Company from filling all vacancies in accordance with
the By-Laws of the Company.
<!-- page 3 -->
(f) The Company will take appropriate action so that, prior to the 2015 Annual Meeting, its director
change of position policy does not require a JANA Nominee to resign by reason of any material change
in his or her primary job responsibility or position held at the time such JANA Nominee was
appointed to the Board.

4. CEO Succession.

(a) At the March Board Meeting, the Company shall appoint two JANA Nominees chosen by JANA to the
CEO Succession Committee of the Board (the "CEO Succession Committee") and shall appoint such JANA
Nominees to any other committee currently or in the future designated to review or oversee the
selection process for a successor to Mr. Koffel as chief executive officer or substantially similar
position (the "New CEO"), and shall not otherwise increase the size of the CEO Succession Committee
or any such other committee. In the event of the replacement as set forth in Section 3(c) of any
JANA Nominee appointed to the CEO Succession Committee pursuant to this Section 5, his or her
successor shall be promptly appointed to the committee seat vacated by such former director to serve
until the 2015 Annual Meeting. The CEO Succession Committee and any other committee currently or in
the future designated to review or oversee the selection process for the New CEO shall not take any
material action prior to the March Board Meeting.

(b) In order to ensure an orderly transition, Mr. Koffel may in his sole discretion continue
(including, for the avoidance of doubt, after the 2014 Annual Meeting) as the Chief Executive
Officer, Chairman of the Board and a director of the Company during the selection process for the
New CEO until the Board shall appoint the New CEO, which shall not be later than the earlier of
December 31, 2014, or Mr. Koffel's voluntary resignation from such positions; provided that Mr.
Koffel will resign as a director of the Company and the Chairman of the Board upon the effectiveness
of the Board's appointment of the New CEO; provided, further, that nothing contained herein is
intended to modify any employment agreement, equity award, retirement plan or other pre-existing
obligation of the Company to Martin Koffel or to impose any additional obligations on Martin Koffel
(beyond the obligation to resign as provided in this Section 4(b)). The Board shall appoint the New
CEO as a director of the Company with a term expiring at the Company's next annual meeting after his
or her appointment.

5. Compensation Committee. At the March Board Meeting, the Company shall appoint one JANA Nominee
chosen by JANA (provided that such JANA Nominee must have prior experience serving on the
Compensation Committee of a public company incorporated in the United States and listed for trading
on the New York Stock Exchange or NASDAQ) to the Compensation Committee of the Board (the
"Compensation Committee"), and shall not otherwise increase the size of the Compensation Committee
until the 2015 Annual Meeting. In the event of the replacement as set forth in Section 3(c) of any
JANA Nominee appointed to the Compensation Committee pursuant to this Section 5, his or her
successor shall be promptly appointed to the committee seat vacated by such former director to serve
until the 2015 Annual Meeting. The Compensation Committee and any other committee currently or in
the future designated to review or oversee compensation shall not take any material action prior to
the March Board Meeting.

6. Value Creation Committee and Other Matters.

(a) At the March Board Meeting, the Board shall establish a new committee of the Board (the "Value
Creation Committee"), whose purpose will be to evaluate all options for enhancing shareholder value,
including by (i) engaging Bank of America Merrill Lynch, or if Bank of America Merrill Lynch is
unavailable or the Company is unable to reach acceptable terms with Merrill Lynch Bank of America
despite using reasonable best efforts to do so, another investment bank mutually agreeable to the
Company and JANA, as promptly as practicable, to review all options for enhancing value, including
by conducting a strategic review of the Company's business, operations and capital
<!-- page 4 -->
structure; (ii) engaging a cost consultant, mutually agreeable to the Company and JANA, to conduct a
cost review commencing with the completion of the investment banker review described in clause (ii)
above; and (iii) reviewing the Company's management compensation structure to enhance alignment with
shareholder value creation. There shall be four (4) members of the Value Creation Committee, two (2)
of whom shall be JANA Nominees chosen by JANA, and the Board shall not increase the size of the
Value Creation Committee until the 2015 Annual Meeting, if still in existence at such time. In the
event of the replacement as set forth in Section 3(c) of any JANA Nominee appointed to the Value
Creation Committee pursuant to this Section 5, his or her successor shall be promptly appointed to
the committee seat vacated by such former director to serve until the 2015 Annual Meeting

(b) The Company hereby agrees that it will not make any acquisitions during the Cooperation Period,
except for ordinary course acquisitions individually under $10 million (not to exceed $30 million in
the aggregate) or acquisitions that a majority of the JANA Nominees have recommended.

7. Cooperation.

(a) JANA agrees that, from the date of this Agreement until the earliest of (i) the date that is
thirty (30) calendar days prior to any applicable deadline by which a shareholder must give notice
to the Company of its intention to nominate a director for election at or bring other business
before the 2015 Annual Meeting under the Company's By­Laws and (ii) any material breach of this
Agreement by the Company (provided that the Company shall have three (3) business days following
written notice from JANA of material breach to remedy such material breach if capable of remedy)
(such period, the "Cooperation Period"), neither it nor any of its Affiliates or Associates will in
any manner, directly or indirectly, make, or cause to be made, or in any way encourage any other
person to make or cause to be made, any statement or announcement that relates to and constitutes an
ad hominem attack on, or relates to and otherwise disparages, the Company, any of its officers or
directors or any person who has served as an officer or director of the Company, including: (i) in
any document or report filed with or furnished to the Securities and Exchange Commission (the "SEC")
or any other governmental agency, (ii) in any press release or other publicly available format or
(iii) to any journalist or member of the media (including without limitation, in a television,
radio, newspaper or magazine interview), or otherwise; provided, that if the Company makes any
material announcement prior to the March Board Meeting, JANA will be permitted to make objective
statements that solely reflect JANA's view, as a shareholder, with respect to such announcement.

(b) The Company agrees that, from the date of this Agreement until the earliest of (i) the date that
is thirty (30) calendar days prior to any applicable deadline by which a shareholder must give
notice to the Company of its intention to nominate a director for election at or bring other
business before the 2015 Annual Meeting under the Company's By­Laws and (ii) any material breach of
this Agreement by JANA (provided that JANA shall have three (3) business days following written
notice from the Company of material breach to remedy such material breach if capable of remedy),
neither it nor any of its Affiliates or Associates will in any manner, directly or indirectly make,
or cause to be made, or in any way encourage any other person to make or cause to be made, any
statement or announcement that relates to and constitutes an ad hominem attack on, or relates to and
otherwise disparages, JANA, any of its members, officers or directors or any person who has served
as a member, officer or director of JANA, including: (i) in any document or report filed with or
furnished to the SEC or any other governmental agency, (ii) in any press release or other publicly
available format or (iii) to any journalist or member of the media (including without limitation, in
a television, radio, newspaper or magazine interview), or otherwise.
<!-- page 5 -->
(c) The limitations set forth in Sections 7(a) and 7(b) shall not prevent either party from
responding to any public statement made by the other party of the nature described in Sections 7(a)
and 7(b) if such statement by the other party was made in breach of this Agreement.

(d) During the Cooperation Period, JANA shall cause all shares of the Company's capital stock
("Shares") beneficially owned, directly or indirectly, by it, or by any of its Affiliates or
Associates (including without limitation all Shares beneficially owned as of the respective record
dates for the 2014 Annual Meeting and as of the record dates for any special meeting of
shareholders) over which it exercises or has voting authority, to be present for quorum purposes and
to be voted, at such meetings or at any adjournments or postponements thereof, in favor of the
current members of the Board (including the JANA Nominees) that will be up for election at such
meetings, and not to submit any proposal for consideration at, or bring any other business before,
the 2014 Annual Meeting or initiate, encourage or participate in any "withhold" or similar campaign
with respect to the election of directors at the 2014 Annual Meeting and shall not permit any of its
Affiliates or Associates to do any of the foregoing or publicly or privately encourage or support
any other stockholder to take any such actions.

(e) During the Cooperation Period, JANA will not, and shall cause its Affiliates and Associates to
not, directly or indirectly, without the prior written consent of the Company: (i) acquire, seek or
propose (publicly or otherwise) to acquire, beneficial ownership, directly or indirectly, of any
additional Shares or rights or options to acquire any additional Shares if such acquisition would
cause JANA's beneficial ownership to exceed 14.9% of the Company's common stock; (ii) publicly seek
or propose to influence or control the management or policies of the Company, seek or propose
(publicly or otherwise) to obtain representation on the Board (except as set forth herein), or
solicit, or participate in the solicitation of, any proxies or consents with respect to any
securities of the Company, or publicly request permission to do any of the foregoing, or take any
action which would, or would reasonably be expected to, require public disclosure regarding any of
the types of matters set forth in this clause (ii); (iii) submit (publicly or otherwise) a proposal
for, or offer of (with or without conditions) any extraordinary transaction (including a tender
offer, exchange offer, merger, acquisition or consolidation) involving the Company or its securities
or assets or take any action which would, or would reasonably be expected to, require public
disclosure regarding any of the types of matters set forth in this clause (iii); (iv) request
(publicly or otherwise) a special meeting of the Company's shareholders or submit, or participate
in, any shareholder proposal to the Company or any "shareholder access" proposal that may be adopted
by the SEC; or (v) encourage, assist or enter into any discussions, negotiations, arrangements or
understandings with any third party with respect to any of the foregoing, or otherwise form, join or
in any way participate in a "group" (as defined in Section 13(d)(3) of the Exchange Act) in
connection with any of the foregoing. JANA also agrees not to, and to cause its Affiliates and
Associates not to, request during the Cooperation Period that the Company (or its directors,
officers, employees or agents), directly or indirectly, amend or waive any provision of this Section
(including this sentence), publicly or in a manner that would require public disclosure of such
request.

(f) Nothing in this Agreement shall be deemed to limit JANA's ability to provide its views privately
to the Board on any matter or to privately request a waiver of any provision of this Agreement,
provided that such actions are not reasonably expected to require public disclosure of such actions.

8. Public Announcement and SEC Filing.

(a) JANA and the Company shall announce this Agreement and the material terms hereof including the
terms of Section 6 by means of a joint press release in the form attached hereto as Exhibit A (the
"Press Release") as soon as practicable but in no event later than 9:00 a.m., New York City time, on
March 17, 2014.
<!-- page 6 -->
(b) JANA shall promptly prepare and file an amendment (the "13D Amendment") to its Schedule 13D with
respect to the Company filed with the SEC on February 27, 2014 reporting the entry into this
Agreement and amending applicable items to conform to its obligations hereunder. The 13D Amendment
shall be consistent with the Press Release and the terms of this Agreement. JANA shall provide the
Company with reasonable opportunity to review and comment upon the 13D Amendment prior to filing,
and shall consider in good faith any changes proposed by the Company necessary to cause such 13D
Amendment to comply with this Agreement.

9. Definitions. For purposes of this Agreement:

(a) the terms "Affiliate" and "Associate" shall have the respective meanings set forth in Rule 12b­2
promulgated by the SEC under the Securities Exchange Act of 1934, as amended (the "Exchange Act");

(b) the terms "beneficial owner" and "beneficially own" shall have the same meanings as set forth in
Rule 13d­3 promulgated by the SEC under the Exchange Act except that a person shall also be deemed
to be the beneficial owner of all Shares which such person has the right to acquire (whether such
right is exercisable immediately or only after the passage of time) pursuant to the exercise of any
rights in connection with any securities or any agreement, arrangement or understanding (whether or
not in writing), regardless of when such rights may be exercised and whether they are conditional,
and all Shares which such person or any of such person's Affiliates or Associates has or shares the
right to vote or dispose; and

(c) the terms "person" or "persons" shall mean any individual, corporation (including
not­for­profit), general or limited partnership, limited liability or unlimited liability company,
joint venture, estate, trust, association, organization or other entity of any kind or nature.

10. Notices. All notices, consents, requests, instructions, approvals and other communications
provided for herein and all legal process in regard hereto shall be in writing and shall be deemed
validly given, made or served, if (a) given by telecopy and email, when such telecopy is transmitted
to the telecopy number set forth below and sent to the email address set forth below and the
appropriate confirmation is received or (b) if given by any other means, when actually received
during normal business hours at the address specified in this Section:

if to the Company: URS Corporation 600 Montgomery Street, 26th Floor San Francisco, California 94111
Attention: General Counsel Facsimile: (415) 834-1506 Email: joseph.masters@urs.com with a copy to:
Wachtell, Lipton, Rosen & Katz 51 W. 52nd Street New York, NY 10019 Attention: David E. Shapiro
Facsimile: (212) 403-2000 Email: DEShapiro@wlrk.com
<!-- page 7 -->
if to JANA: JANA Partners LLC 767 Fifth Avenue, 8th Floor New York, New York 10153 Attention:
General Counsel Facsimile: (212) 455-0901 Email: jennifer.fanjiang@janapartners.com with a copy to:
Schulte Roth & Zabel 919 Third Avenue New York, NY 10022 Attention: Marc Weingarten Facsimile: (212)
593-5955 Email: marc.weingarten@srz.com

11. Specific Performance; Remedies.

(a) In furtherance and not in limitation of Section 11(b), the parties hereto shall be entitled to
seek an injunction or injunctions to prevent breaches of this Agreement and to enforce specifically
the terms and provisions of this Agreement, in addition to any other remedy to which they are
entitled at law or in equity. FURTHERMORE, EACH OF THE PARTIES HERETO (A) IRREVOCABLY WAIVES THE
RIGHT TO TRIAL BY JURY AND (B) AGREES TO WAIVE ANY BONDING REQUIREMENT UNDER ANY APPLICABLE LAW, IN
THE CASE ANY OTHER PARTY SEEKS TO ENFORCE THE TERMS BY WAY OF EQUITABLE RELIEF. THIS AGREEMENT SHALL
BE GOVERNED IN ALL RESPECTS, INCLUDING VALIDITY, INTERPRETATION AND EFFECT, BY THE LAWS OF THE STATE
OF DELAWARE WITHOUT GIVING EFFECT TO THE CHOICE OF LAW PRINCIPLES OF SUCH STATE.

(b) Notwithstanding any other Section in this Agreement and without limiting any other remedies the
Company may have in law or equity, in the event that JANA (or any Affiliate or Associate of JANA)
fails to perform or otherwise fulfill its obligations set forth in Section 7 in any material
respect, and shall not have remedied such failure or non-fulfillment if capable of being remedied or
fulfilled within three (3) business days following written notice from the Company of such failure
or non-fulfillment, the Company shall not be required to perform or fulfill its obligations set
forth in Sections 3, 4, 5 or 7 and the JANA Nominees shall each promptly tender their resignation as
a member of the Board effective immediately upon its acceptance by the Company. As a condition to
nomination and/or appointment to the Board pursuant to this Agreement, each JANA Nominee shall have
executed an irrevocable letter agreement with the Company in which each such JANA Nominee shall
agree to resign if required in accordance with the immediately preceding sentence.

12. Severability. If at any time subsequent to the date hereof, any provision of this Agreement
shall be held by any court of competent jurisdiction to be illegal, void or unenforceable, such
provision shall be of no force and effect, but the illegality or unenforceability of such provision
shall have no effect upon the legality or enforceability of any other provision of this Agreement.

13. Termination. This Agreement shall terminate on the expiry of the Cooperation Period.

14. Counterparts. This Agreement may be executed in two (2) or more counterparts which together
shall constitute a single agreement.

15. No Third Party Beneficiaries. This Agreement is solely for the benefit of the parties hereto and
is not enforceable by any other persons.
<!-- page 8 -->
16. No Waiver. No failure or delay by either party in exercising any right or remedy hereunder shall
operate as a waiver thereof, nor shall any single or partial waiver thereof preclude any other or
further exercise thereof or the exercise of any other right or remedy hereunder.

17. Entire Understanding. This Agreement contains the entire understanding of the parties with
respect to the subject matter hereof and may be amended only by an agreement in writing executed by
the parties hereto.

18. Interpretation and Construction.

(a) The Company acknowledges that its Board is bound by the obligations of the Company hereunder.

(b) Each of the parties hereto acknowledges that it has been represented by counsel of its choice
throughout all negotiations that have preceded the execution of this Agreement, and that it has
executed the same with the advice of said counsel. Each party and its counsel cooperated and
participated in the drafting and preparation of this Agreement and the documents referred to herein,
and any and all drafts relating thereto exchanged among the parties shall be deemed the work product
of all of the parties and may not be construed against any party by reason of its drafting or
preparation. Accordingly, any rule of law or any legal decision that would require interpretation of
any ambiguities in this Agreement against any party that drafted or prepared it is of no application
and is hereby expressly waived by each of the parties hereto, and any controversy over
interpretations of this Agreement shall be decided without regard to events of drafting or
preparation.
<!-- page 9 -->
IN WITNESS WHEREOF, this Agreement has been duly executed and delivered by the duly authorized
signatories of the parties as of the date hereof.

URS CORPORATION By: /s/ Martin M. Koffel Name: Martin M. Koffel Title: Chairman of the Board and
Chief Executive Officer

JANA PARTNERS LLC By: /s/ Barry Rosenstein Name: Barry Rosenstein Title: Managing Partner
<!-- page 10 -->
EXHIBIT A

URS CORPORATION ADDS FOUR NEW INDEPENDENT DIRECTORS TO BOARD JANA Partners Agrees to Support All
Nominees at 2014 Annual Meeting Board to Establish Value Creation Committee

SAN FRANCISCO, CA - March [XX], 2014 - URS Corporation (NYSE: URS) today announced that it will add
four new independent directors to its Board of Directors, effective March 27, 2014. These four
directors will be on URS' slate of directors nominated for election to the Board of Directors at the
Company's 2014 Annual Meeting, along with eight incumbents, pursuant to an agreement with JANA
Partners LLC. The four new directors will be: Diane C. Creel, William H. Schumann, III,

David N. Siegel and V. Paul Unruh. Biographical information on the new directors is provided below.

Current directors [A] and [B] have advised the Company that they do not plan to stand for
re-election at the 2014

Annual Meeting. Therefore, from March 27, 2014 until the Annual Meeting, the Board will increase to
fourteen members from the

current ten, but will be comprised of twelve directors following the 2014 Annual Meeting.

Under the agreement with JANA, URS will also form a Value Creation Committee of the Board that will
evaluate all

options for enhancing shareholder value, including by engaging an investment bank to conduct a
strategic review of the

Company's business segments, operations and capital structure, and reviewing the Company's
management compensation structure to enhance alignment with shareholder value creation. The
Committee will be comprised of four members, two of whom

will be new directors.

Martin M. Koffel, Chairman and Chief Executive Officer of URS, stated: "[A] and [B] are superb
directors and have contributed much to our success, but each has decided for his own reasons not to
stand for re-election. I and their fellow board

members look forward to continuing to work with them until the Annual Meeting but will take this
opportunity to express our

gratitude for their service, sound counsel and friendship." Koffel continued: "With [A]'s and [B]'s
decisions to stand down and the expansion of our Board, we are adding four new, highly qualified
independent directors to the Board on March 27 and we will nominate these directors for election at
the

2014 Annual Meeting. All are accomplished business leaders with experience
<!-- page 11 -->
relevant to the URS enterprise, and we are confident that they will prove to be valuable additions
as we continue working to build

value for our stockholders." As previously disclosed, the URS Board has been engaged in succession
planning for the Company's Chief Executive Officer position and has appointed a CEO Succession
Committee comprised of independent directors. Two of the new directors

will promptly be appointed to this Committee. One of the new directors will also be appointed to the
Compensation Committee.

Said Koffel, "Having led URS for more than 25 years, I had previously communicated to the Board that
it was important to have my successor in place in 2014, and our goal is to do just that. The Board
has asked me to remain as Chairman and Chief

Executive Officer until a successor is named, which I expect to do unless circumstances change."
Barry Rosenstein, Managing Partner of JANA Partners, said, "We have appreciated our constructive
dialogue with Martin Koffel and his team. We share their view that the Company is significantly
undervalued, particularly given its strong cash

flows and the valuable work Martin and his team have done over many years to ensure that URS is
well-positioned to meet the

needs of its clients. I am confident that the addition of four highly-qualified directors and the
formation of the Value Creation

Committee will help unlock this value for all shareholders." JANA Partners currently owns
approximately 9.7 percent of the Company's common shares outstanding. URS' incumbent directors
expected to be nominated for re­election at the 2014 Annual Meeting are: [C]; [D]; [E]; [F]; [G];
[H]; [I]; and [J].

The director nominations will be included in the Company's 2014 proxy statement and submitted for
stockholder approval at the Company's 2014 Annual Meeting, [to be held on [date]]. The Company
expects to file its proxy materials for the

2014 Annual Meeting [in the near future] and encourages stockholders to review the proxy materials
when they become available.

The agreement between URS and JANA Partners will be filed on Form 8-K with the Securities and
Exchange

Commission. The agreement includes certain standstill restrictions that will be in effect until 30
days prior to the deadline by which

a shareholder must give notice to the Company of its intention to nominate a director at or bring
other business before the 2015

Annual Meeting. JANA Partners has committed to
<!-- page 12 -->
vote the shares that it controls in support of URS' twelve director nominees at the Company's 2014
Annual Meeting. Wachtell, Lipton, Rosen & Katz and Cooley LLP are serving as legal advisors to URS.

Biographical Information on New Director Nominees

Diane Creel, 65

Ms. Diane Creel retired as Chairman, Chief Executive Officer and President of Ecovation, Inc., a
subsidiary of Ecolab

Inc. and a waste stream technology company using patented technologies, in September 2008. Ms. Creel
had held such positions

since 2003. Previously, Ms. Creel served as Chief Executive Officer and President of Earth Tech, an
international consulting

engineering firm, which is now part of AECOM, from 1992 to 2003. Ms. Creel has served on the ATI
Board of Directors since

1996 and as Lead Independent Director since the position was established in September 2011. Ms.
Creel is also a member of

the Boards of Directors of The Timken Company (since 2012) and Enpro Industries, Inc. (since 2009).
She also served on the

Board of Directors of Goodrich Corporation from 1997 to 2012 and Foster Wheeler Ltd. until 2008.

William H. Schumann, III, 63

Mr. William H. Schumann, III, has served as the non-executive Chairman of the Board of Directors of
Avnet, Inc., a

distributor of electronic components, since November 2012 and has been on the board since 2010. He
retired in August 2012 as

Executive Vice President of FMC Technologies, Inc., a provider of technology solutions for the
energy industry. He served as

Chief Financial Officer of FMC Technologies from 2001 to 2011 and Chief Financial Officer of FMC
Corporation (the

predecessor to FMC Technologies) from 1999 to 2001. Mr. Schumann served on the board of UAP
Holdings, an agricultural

chemical distributor, from 2005 to 2008 and Great Lakes Advisors, a registered investment advisor,
from 1992 to 2011. Mr.

Schumann has been a director of AMCOL International Corporation, a producer of specialty materials
and related products and

services for industrial and consumer markets, since 2012 and McDermott International, Inc., an
engineering and construction

company, since 2012.
<!-- page 13 -->
David N. Siegel, 52

David N. Siegel is President & CEO of Frontier Airlines and serves on its board of directors. He was
a Director of

Republic Airways, from October 2009 to December 2013, including serving as Lead Independent Director
from May 2011 until

January 2012 when he was appointed President & CEO of Frontier, at the time a wholly-owned
subsidiary of Republic. Prior to

joining Frontier, Mr. Siegel was Chairman & CEO of XOJET, a private aviation company, controlled by
TPG Capital. From June

2004 to May 2008, Mr. Siegel was Chairman and Chief Executive Officer, and from June 2008 to April
2009 Chairman, of

gategroup Holding AG, the world's largest independent airline catering, hospitality and logistics
company. Prior to that, Mr. Siegel

served as President, Chief Executive Officer and member of the Board of US Airways Group, Inc., and
US Airways, Inc., the

airline operating unit. Prior to US Airways, Mr. Siegel was Chairman and Chief Executive Officer of
Avis Rent A Car System,

Inc., a subsidiary of Cendant Corp. Mr. Siegel also spent seven years at Continental Airlines in
various senior management roles,

including President of its Continental Express subsidiary. Mr. Siegel is currently a member of the
board of directors of gategroup

Holding AG, having served since June 2004.

V. Paul Unruh, 65

Mr. V. Paul Unruh retired as vice chairman of Bechtel Group, Inc. in June 2003. During his 25-year
tenure he held a

number of management positions including treasurer, controller, and chief financial officer. He also
served as president of Bechtel

Enterprises, the finance, development, and ownership arm, from 1997 to 2001. Unruh is also a
certified public accountant. Mr.

Unruh is currently a member of the board of directors of Symantec Corporation, a provider of
security, backup and availability

solutions, Move, Inc., a provider of real estate media and technology solutions, and Heidrick &
Struggles International, Inc., a

provider of executive search and leadership consulting services. He also serves on the boards of two
private companies.

URS Corporation (NYSE: URS) is a leading provider of engineering, construction, and technical
services for public

agencies and private sector companies around the world. The Company offers a full range of program
management; planning,

design and engineering;
<!-- page 14 -->
systems engineering and technical assistance; construction and construction management; operations
and maintenance; information

technology; and decommissioning and closure services. URS provides services for federal, oil and
gas, infrastructure, power, and

industrial projects and programs. Headquartered in San Francisco, URS Corporation has more than
50,000 employees in a

network of offices in nearly 50 countries (www.urs.com).

[add FLS Tag]

# # #
