<!-- page 1 -->
# MAINTENANCE AGREEMENT
| Field | Value |
|---|---|
| Document Type | Maintenance Agreement |
| Agreement Date | 2003-07-23 |
| Parties | Universal Access, Inc. ("Company"); CityNet Telecommunications, Inc.("Provider") |
| Source | CUAD v1 / UAGHINC_04_14_2004-EX-10.18-MAINTENANCE AGREEMENT |

Exhibit 10.18 MAINTENANCE AGREEMENT MAINTENANCE AGREEMENT (this "Agreement"), dated as of July 23,
2003, made by Universal Access, Inc., a corporation organized and existing under the laws of the
State of Delaware (the "Company"), and CityNet Telecommunications, Inc., a corporation organized and
existing under the laws of the State of Delaware (the "Provider"). All capitalized terms used herein
and not otherwise defined shall have the meaning set forth in the Purchase Agreement (as defined
below). WITNESSETH: WHEREAS, the Provider and the Company entered into that certain Stock Purchase
Agreement (the "Purchase Agreement") by and between the Provider and the Company dated as of April
7, 2003; WHEREAS, pursuant to the Purchase Agreement, the Provider will transfer the Fiber Ring
Assets to the Company upon the Closing; WHEREAS, as a condition to the Closing, the Provider and the
Company agreed to enter into this Agreement; NOW, THEREFORE, in consideration of the mutual
agreements set forth herein and other good and valuable consideration, the receipt and sufficiency
of which is hereby acknowledged, the parties hereby agree as follows: SECTION 1 TERM OF AGREEMENT
1.1. Initial Term. This Agreement commences on the date first above written, and will remain in
effect for the period of five (5) years, except as otherwise provided herein. 1.2. Extension of
Term. This Agreement will extend automatically for monthly periods unless either party to this
Agreement notifies the other party in writing at least thirty (30) days before the expiration of the
then current term. 1.3 Termination of Term. Notwithstanding the foregoing, either party may
terminate this Agreement at any time without liability by providing one hundred eighty (180) days
written notice to the other party. SECTION 2 DESCRIPTION OF SERVICES AND FEES 2.1. Services. (a) The
Provider or its affiliate will provide the Company, with respect to the Fiber Ring Assets, all
maintenance services (including but not limited to jetwashing and related ancillary services)
required under the Provider's license agreements with the municipalities in which the Fiber Ring
Assets are located (each a "City Rights Agreement"), and monitoring, emergency response and
emergency splicing (collectively, the "Services"). If a
<!-- page 2 -->
service call is required to restore the Fiber Ring Assets to good operating condition, the Company
will notify the Provider promptly after it becomes aware of the service affecting problem. (b) The
Services shall not include any of the following: (i) remedial or preventive maintenance service
performed outside that expressly defined in this Section 2.1; (ii) repair of damage or loss
resulting from accident, neglect, misuse or abuse or causes other than ordinary use by the Company
for the purpose for which any of the Fiber Ring Assets was designed (collectively, "Repairs");
provided that Services do include Repairs if the damage or loss is caused by the Provider; (iii)
making specification or field engineering changes; (iv) unless authorized in writing by the
Provider, services resulting from, or which are impractical for the Provider to render because of,
any adjustment, repair, maintenance, modification or alteration of the Fiber Ring Assets by any
person other than the Provider; and (v) service calls required to restore any of the Fiber Ring
Assets to good operating condition, if the Company fails to notify the Provider of a need for
service within one (1) day of the Company's knowledge of such need, and such delay has made the
provision of the Services more costly. 2.2. Availability of the Services and Repairs. The Provider
will be available to provide the Services 24 hours per day, seven (7) days per week. Periodically
during the term of this Agreement, the Provider will provide to the Company contact information and
reasonable protocols to be followed in order to schedule performance of the Services. 2.3. Fees. In
each of the first twelve months of this Agreement, the Company shall pay to the Provider $40,000 per
month in exchange for the Services (the "Service Fee"). Upon each anniversary of the commencement of
this Agreement, the Service Fee shall be increased by a percentage that reflects the actual
increases in the Provider's cost of providing the Services, if any. All materials and labor required
to provide any Repairs or any other services or other work not specified in Section 2.1(a) hereof
requested by the Company shall be billed to the Company, in addition to the Service Fee as adjusted,
at a rate equal to the Provider's actual cost plus 10% service/overhead fee. SECTION 3 COVENANTS OF
THE COMPANY As a condition to receiving the Services under this Agreement, the Company hereby agrees
and covenants as follows:
<!-- page 3 -->
3.1. Access to the Fiber Ring Assets. The Company will provide full and free access to the equipment
in which to perform service on a 24/7 basis. 3.2. Operation of the Fiber Ring Assets. The Company
shall take any and all actions, and refrain from taking any action, within the control of the
Company, to ensure that the Provider remains in compliance with, and does not breach or violate the
terms of, a City Rights Agreement or any other agreement related to the Fiber Ring Assets to which
the Provider is a party. This obligation shall include operating the Fiber Ring Assets in such a
manner, and performing certain of the obligations of the operator of the Fiber Ring Assets, so as to
remain in compliance with such agreements. The Company acknowledges that it has received and
reviewed each of the City Rights Agreements set forth on Schedule 3.2 hereto. The obligations under
this Section 3.2 shall survive termination of this Agreement for the life of any applicable City
Rights Agreement or similar license. In any sale of a fiber ring, any transferee must agree to
assume these obligations from Buyer. 3.3. Transfer of the Fiber Ring Assets. The Company shall not
sell, transfer or otherwise attempt to convey or dispose of any part of the Fiber Ring Assets, other
than sales and leases of capacity or of individual fiber strands in the ordinary and usual course of
business unless the Provider consents to such transaction, which consent will not be withheld if,
(a) the proposed transferee consents in writing to the assumption of all obligations of the Company
under this Agreement, including those obligations to be undertaken under other agreements pursuant
to Section 3.3, and (b) all governmental approvals (under City Rights Agreements or otherwise) have
been obtained, with the Provider having the right (if it elects) to coordinate such efforts if it is
the counterparty under such agreements requiring approval (with the Company to pay the reasonable
costs of doing so). SECTION 4 COVENANTS OF THE PROVIDER As a condition to receiving the Service Fee
and any other fees payable to the Provider under this Agreement, the Company hereby agrees and
covenants as follows: 4.1. Commercially Reasonable Efforts. The Provider shall undertake
commercially reasonable efforts to provide the Services and Repairs. The Provider shall provide the
Services and Repairs in a professional and workmanlike manner. 4.2. Access to Information. The
Provider shall make available any and all information held by it that is necessary and reasonable
for the Company to fulfill its obligations under Section 3.3 of this Agreement. 4.3 Maintenance of
Insurance. The Provider will obtain and maintain appropriate liability insurance in an amount of not
less than $1,000,000 combined single limit for accidents or occurrences which cause bodily injury,
death or property damage related to the performance of the Services. The insurance policy willname
the Company as an additional insured. The Provider will provide the Company with a certificate of
insurance issued to evidence such coverage. Such certificate will provide that there shall be no
cancellation, non-renewal, or modification of such coverage without thirty days' prior written
notice to the Company.
<!-- page 4 -->
4.4 Operation of the Fiber Ring Assets. The Provider shall take any and all actions, and refrain
from taking any action, within the control of the Provider, to ensure that the Company remains in
compliance with, and does not breach or violate the terms of a City Rights Agreement. SECTION 5
MISCELLANEOUS 5.1. Excused Non-Performance. The Provider shall not be liable nor deemed to be in
default for any delay or failure in performance under this Agreement resulting, directly or
indirectly, from causes beyond the reasonable control of the Provider, provided that the Provider
shall refund to the Company a pro rata portion of the Service Fee for any period in excess of two
(2) weeks during which the Provider fails to or is unable for any reason to provide the Services or
Repairs called for under this Agreement. Service provided under this Agreement does not assure
uninterrupted operation of equipment. 5.2. Limited Warranty. The Provider shall provide maintenance
under this Agreement for the fixed rate without regard to the number of legitimate service requests
by the Company. 5.3 Limitation of Liability. EXCEPT AS STATED ABOVE, THE PROVIDER'S OBLIGATIONS
UNDER THIS AGREEMENT ARE IN LIEU OF ALL OTHER WARRANTIES, EXPRESSED OR IMPLIED. ALL IMPLIED
WARRANTIES ARE LIMITED TO THE DURATION OF THIS AGREEMENT. A PARTY'S TOTAL LIABILITY TO THE OTHER
PARTY IN CONNECTION WITH THIS AGREEMENT, FOR ANY AND ALL CAUSES OF ACTIONS AND CLAIMS, INCLUDING,
WITHOUT LIMITATION, BREACH OF CONTRACT, BREACH OF WARRANTY, NEGLIGENCE, STRICT LIABILITY,
MISREPRESENTATION AND OTHER TORTS, SHALL BE: (a) FOR BODILY INJURY OR DEATH TO ANY PERSON
PROXIMATELY CAUSED BY A PARTY'S NEGLIGENCE, THE AMOUNT OF DIRECT DAMAGES PROVEN; (b) FOR LOSS OR
DAMAGE TO REAL PROPERTY OR TANGIBLE PERSONAL PROPERTY PROXIMATELY CAUSED BY A PARTY'S NEGLIGENCE,
THE AMOUNT OF DIRECT DAMAGES PROVEN; (c) FOR ANY DAMAGES ARISING OUT OF THE WILLFUL OR INTENTIONAL
MISCONDUCT OF A PARTY, THE AMOUNT OF DIRECT DAMAGES PROVEN; (d) FOR ALL OTHER DAMAGES OTHER THAN
THOSE SET FORTH ABOVE AND NOT EXCLUDED UNDER THIS AGREEMENT, EACH PARTY'S LIABILITY TO THE OTHER
PARTY DURING ANY TWELVE (12) MONTH PERIOD SHALL BE LIMITED TO THE LESSOR OF (i) DIRECT DAMAGES
PROVEN BY THE PARTY, OR (ii) THE AMOUNT PAID BY THE COMPANY TO THE PROVIDER UNDER THIS AGREEMENT FOR
THE TWELVE (12) MONTH PERIOD PRIOR TO THE CLAIM. The foregoing limitations do not apply to the
Company's obligation to pay the Service Fees.
<!-- page 5 -->
THE PROVIDER SHALL NOT BE LIABLE FOR ANY INCIDENTAL OR CONSEQUENTIAL DAMAGES, INCLUDING BUT NOT
LIMITED TO LOSS OF REVENUES OR LOSS OF PROFIT, ARISING OUT OF THE PROVISION OF THE SERVICES OR
REPAIRS, NOTWITHSTANDING ADVANCE NOTICE FROM THE COMPANY THAT THE POSSIBILITY OF SUCH DAMAGE OR LOSS
EXISTS. 5.3. Notices. Any notice, request, demand or other communication required or permitted
hereunder shall be deemed to have been given if delivered by facsimile transmission, upon receipt,
if by hand delivery, upon receipt, if sent by nationally recognized overnight courier service, one
day after deposit with such, or if sent by registered or certified mail, upon the sooner of the date
on which receipt is acknowledged or the expiration of three days after deposit in United States post
office facilities properly addressed with postage prepaid. All notices to a party will be sent to
the addresses set forth below or to such other address or person as such party may designate by
notice to each other party hereunder: TO THE PROVIDER:

CityNet Telecommunications, Inc. 8405 Colesville Road 6th Floor Silver Spring, Maryland 20910
Attention: General Counsel Facsimile: 301-608-8121 TO THE COMPANY:

Universal Access Global Holdings Inc. 233 S. Wacker Drive, Suite 600 Chicago, IL 60606 Attention:
General Counsel Facsimile: 312-660-1290 If notice is sent by facsimile transmission, in order to be
effective, such notice must also be sent by one of the other means of delivery identified above. Any
notice given hereunder may be given on behalf of any party by his counsel or other authorized
representatives. 5.4. Amendments. Any term, covenant, agreement or condition of this Agreement may
be amended only in a writing signed by the Company and the Provider. 5.5. Assignment; Successors or
Assigns. This Agreement and the rights and obligations hereunder may be assigned by the Provider
upon written notice to the Company. All rights and obligations under this Agreement shall be binding
upon any and all successors or assigns. 5.6. Survival. All covenants, representations and warranties
made herein by the Company shall survive and not be waived by the execution and delivery of this
Agreement.
<!-- page 6 -->
5.7. Counterparts. This Agreement may be executed in any number of counterparts, each of which when
so executed and delivered shall be an original, but all of which shall constitute one and the same
instrument. It shall not be necessary in making proof of this Agreement to produce or account for
more than one such counterpart. 5.8. Headings. The headings of the sections and subsections hereof
are provided for convenience only and shall not in any way affect the meaning or construction of any
provision of this Agreement. 5.9. Governing Law; Submission To Jurisdiction; Venue. (a) THIS
AGREEMENT AND THE RIGHTS AND OBLIGATIONS OF THE PARTIES HEREUNDER SHALL BE CONSTRUED ACCORDING TO
AND GOVERNED BY THE SUBSTANTIVE LAWS OF THE STATE OF DELAWARE, EXCLUDING ITS CONFLICTS OF LAWS
PRINCIPLES TO THE EXTENT SUCH PRINCIPLES WOULD LEAD TO THE APPLICATION OF A SUBSTANTIVE LAW OTHER
THAN THE LAW OF THE STATE OF DELAWARE. (b) ANY LEGAL ACTION OR PROCEEDING WITH RESPECT TO THIS
AGREEMENT MAY BE BROUGHT IN THE COURTS OF THE STATE OF DELAWARE OR IN ANY UNITED STATES DISTRICT
COURT SITTING WITHIN THE STATE OF DELAWARE, AND BY EXECUTION AND DELIVERY OF THIS AGREEMENT, EACH OF
THE COMPANY AND THE PROVIDER CONSENTS, FOR ITSELF AND IN RESPECT OF ITS PROPERTY, TO THE
NON-EXCLUSIVE JURISDICTION OF THOSE COURTS. EACH OF THE COMPANY AND THE PROVIDER IRREVOCABLY WAIVES
ANY OBJECTION, INCLUDING ANY OBJECTION TO THE LAYING OF VENUE OR BASED ON THE GROUNDS OF FORUM NON
CONVENIENS, THAT IT MAY NOW OR HEREAFTER HAVE TO THE BRINGING OF ANY ACTION OR PROCEEDING IN SUCH
JURISDICTION IN RESPECT OF THIS AGREEMENT. EACH OF THE COMPANY AND THE PROVIDER WAIVES PERSONAL
SERVICE OF ANY SUMMONS, COMPLAINT OR OTHER PROCESS, THAT MAY BE MADE BY ANY OTHER MEANS PERMITTED BY
THE LAW OF SUCH STATE. (c) EACH PARTY TO THIS AGREEMENT HEREBY EXPRESSLY WAIVES ANY RIGHT TO TRIAL
BY JURY OF ANY CLAIM, DEMAND, ACTION OR CAUSE OF ACTION ARISING UNDER THIS AGREEMENT OR IN ANY WAY
CONNECTED WITH OR RELATED OR INCIDENTAL TO THE DEALINGS OF THE PARTIES HERETO OR ANY OF THEM WITH
RESPECT TO THIS AGREEMENT, OR THE TRANSACTIONS RELATED THERETO, IN EACH CASE WHETHER NOW EXISTING OR
HEREAFTER ARISING, AND WHETHER FOUNDED IN CONTRACT OR TORT OR OTHERWISE; AND EACH PARTY HEREBY
AGREES AND CONSENTS THAT ANY SUCH CLAIM, DEMAND, ACTION OR CAUSE OF ACTION SHALL BE DECIDED BY COURT
TRIAL WITHOUT A JURY, AND THAT ANY PARTY TO THIS AGREEMENT MAY FILE AN ORIGINAL COUNTERPART OR A
COPY OF THIS SECTION WITH ANY COURT AS WRITTEN EVIDENCE OF THE CONSENT OF THE SIGNATORIES HERETO TO
THE WAIVER OF THEIR RIGHT TO TRIAL BY JURY.
<!-- page 7 -->
5.10. Severability. If any provision of this Agreement is determined to be illegal, invalid or
unenforceable, such provision shall be fully severable and the remaining provisions shall remain in
full force and effect and shall be construed without giving effect to the illegal, invalid or
unenforceable provisions. 5.11. Entirety. This Agreement represents the entire agreement of the
parties hereto, and supersedes all prior agreements and understandings, oral or written, if any,
relating to the transactions contemplated herein.
<!-- page 8 -->
IN WITNESS WHEREOF, the parties hereto have caused this Maintenance Agreement to be executed by
their duly elected officers duly authorized as of the date first above written.

UNIVERSAL ACCESS, INC.

By:

Name:

Title:

CITYNET TELECOMMUNICATIONS, INC.

By:

Name:

Title:
<!-- page 9 -->
SCHEDULE 3.2 City Rights Agreements (1) Access and License Agreement dated December 8, 2000, between
the Consolidated City of Indianapolis, Marion County, Indiana and the Department of Capital Asset
Management (jointly as "Licensor") and CityNet Telecommunications, Inc. as "Licensee," as amended by
the Amendment to the Access and License Agreement dated as of June 25, 2003, by and between
Licensor, Licensee and Universal Access, Inc. (2) License Agreement dated November 8, 2000, between
the City of Albuquerque, New Mexico and CityNet Telecommunications, Inc.
