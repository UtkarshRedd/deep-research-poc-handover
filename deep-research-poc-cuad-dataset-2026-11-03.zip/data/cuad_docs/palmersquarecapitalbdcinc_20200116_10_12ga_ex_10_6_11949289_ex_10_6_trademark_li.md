<!-- page 1 -->
# TRADEMARK LICENSE AGREEMENT
| Field | Value |
|---|---|
| Document Type | License Agreement |
| SEC Filing Date | 2020-01-16 |
| Parties | Palmer Square Capital Management LLC ("Licensor"); Palmer Square Capital BDC Inc. ("Licensee") |
| Source | CUAD v1 / PalmerSquareCapitalBdcInc_20200116_10-12GA_EX-10.6_11949289_EX-10.6_Trademark License Agreement |

Exhibit 10.6 TRADEMARK LICENSE AGREEMENT This TRADEMARK LICENSE AGREEMENT (this "Agreement") is made
and effective as of [ ] day of [ ], 2020 ("Effective Date"), by and between Palmer Square Capital
Management LLC, a Delaware limited liability company (the "Licensor"), and Palmer Square Capital BDC
Inc., a corporation organized under the laws of the State of Maryland (the "Licensee") (each a
"party," and collectively, the "parties"). RECITALS WHEREAS, Licensee is a newly organized,
externally managed, closed-end, non-diversified management investment company that intends to elect
to be regulated as a business development company under the Investment Company Act of 1940, as
amended (the "1940 Act"); WHEREAS, Licensor, together with its affiliates, provides investment
management, investment consultation and investment advisory services; WHEREAS, Licensor and its
affiliates, including Palmer Square BDC Advisor LLC, a Delaware limited liability company
("Investment Advisor"), have used the marks "Palmer Square", "Palmer Square Capital" and derivations
thereof (the "Licensed Mark") in the United States of America and certain other jurisdictions
(collectively, the "Territory") in connection with the investment management, investment
consultation and investment advisory services they provide; WHEREAS, the Licensee is entering into
an investment advisory agreement with Investment Advisor (the "Advisory Agreement"), wherein
Licensee shall engage Investment Advisor to act as the investment adviser to the Licensee; WHEREAS,
it is intended that Investment Advisor be a third party beneficiary of this Agreement; and WHEREAS,
the Licensee desires to use the Licensed Mark as part of its corporate name and in connection with
the operation of its business, and Licensor is willing to grant Licensee a license to use the
Licensed Mark, subject to the terms and conditions of this Agreement. NOW, THEREFORE, in
consideration of the mutual covenants and agreements set forth herein, and for other good and
valuable consideration, the receipt and sufficiency of which are hereby acknowledged, the parties
agree as follows: ARTICLE 1. LICENSE GRANT 1.1. License. Subject to the terms and conditions of this
Agreement, Licensor hereby grants to Licensee, and Licensee hereby accepts from Licensor, a
personal, non-exclusive, royalty-free right and license to use the Licensed Mark solely and
exclusively as a component of Licensee's own corporate name and in connection with marketing the
investment management, investment consultation and investment advisory services that Investment
Advisor may provide to Licensee. During the term of this Agreement, Licensee shall use the Licensed
Mark only to the extent permitted under this License, and except as provided above, neither Licensee
nor any affiliate, owner, director, officer, employee or agent thereof shall otherwise use the
Licensed Mark or any derivative thereof in the Territory without the prior express written consent
of Licensor in its sole and absolute discretion and shall not use the Licensed Mark for any purpose
outside the Territory. All rights not expressly granted to Licensee hereunder shall remain the
exclusive property of the Licensor. 1.2. Nothing in this Agreement shall preclude Licensor or any of
its successors or assigns from using or permitting other entities to use the Licensed Mark, whether
or not such entity directly or indirectly competes or conflicts with Licensee's business in any
manner.

Source: PALMER SQUARE CAPITAL BDC INC., 10-12G/A, 1/16/2020
<!-- page 2 -->
ARTICLE 2. COMPLIANCE 2.1. Quality Control. In order to preserve the inherent value of the Licensed
Mark, Licensee agrees to use reasonable efforts to ensure that it maintains the quality of the
Licensee's business and the operation thereof equal to the standards prevailing in the operation of
Licensee's business as of the Effective Date. The Licensee further agrees to use the Licensed Mark
in accordance with such quality standards as may be reasonably established by Licensor and
communicated to the Licensee from time to time in writing, or as may be agreed to by Licensor and
the Licensee from time to time in writing. 2.2. Compliance With Laws. Licensee agrees that the
business operated by it in connection with the Licensed Mark shall comply with all laws, rules,
regulations and requirements of any governmental body in the Territory or elsewhere as may be
applicable to the operation, marketing, and promotion of the business and shall notify Licensor of
any action that must be taken by Licensee to comply with such law, rules, regulations or
requirements. 2.3. Notification of Infringement. Each party shall immediately notify the other party
and provide to the other party all relevant background facts upon becoming aware of (a) any
registrations of, or applications for registration of, marks in the Territory that do or may
conflict with the Licensor's rights in the Licensed Mark or the rights granted to the Licensee under
this Agreement, (b) any infringements or misuse of the Licensed Mark in the Territory by any third
party ("Third Party Infringement"), or (c) any claim that Licensee's use of the Licensed Mark
infringes the intellectual property rights of any third party in the Territory ("Third Party
Claim"). Licensor shall have the exclusive right, but not the obligation, to prosecute, defend
and/or settle in its sole discretion, all actions, proceedings and claims involving any Third Party
Infringement or Third Party Claim, and to take any other action that it deems necessary or proper
for the protection and preservation of its rights in the Licensed Mark. Licensee shall cooperate
with Licensor in the prosecution, defense or settlement of such actions, proceedings or claims.

- 2 -

Source: PALMER SQUARE CAPITAL BDC INC., 10-12G/A, 1/16/2020
<!-- page 3 -->
ARTICLE 3. REPRESENTATIONS AND WARRANTIES 3.1. Licensee accepts this license on an "as is" basis.
Licensee acknowledges that Licensor makes no explicit or implicit representation or warranty as to
the registrability, validity, enforceability, ownership of the Licensed Mark, or as to Licensee's
ability to use the Licensed Mark without infringing or otherwise violating the rights of others, and
Licensor has no obligation to indemnify Licensee with respect to any claims arising from Licensee's
use of the Licensed Mark, including without limitation any Third Party Claim. 3.2. Mutual
Representations. Each party hereby represents and warrants to the other party as follows: (a) Due
Authorization. Such party is a limited liability company duly formed or a corporation duly
incorporated, as applicable, and is in good standing as of the Effective Date, and the execution,
delivery and performance of this Agreement by such party have been duly authorized by all necessary
action on the part of such party. (b) Due Execution. This Agreement has been duly executed and
delivered by such party and, upon due authorization, execution and delivery of this Agreement by the
other party, constitutes a legal, valid and binding obligation of such party, enforceable against
such party in accordance with its terms. (c) No Conflict. Such party's execution, delivery and
performance of this Agreement do not: (i) violate, conflict with or result in the breach of any
provision of the operating agreement, charter or bylaws (or similar organizational documents) of
such party; (ii) conflict with or violate any governmental order applicable to such party or any of
its assets, properties or businesses; or (iii) conflict with, result in any breach of, constitute a
default (or event which with the giving of notice or lapse of time, or both, would become a default)
under, require any consent under, or give to others any rights of termination, amendment,
acceleration, suspension, revocation or cancellation of any contract, agreement, lease, sublease,
license, permit, franchise or other instrument or arrangement to which it is a party. ARTICLE 4.
TERM AND TERMINATION 4.1. Term. This Agreement shall expire if the Investment Advisor or one of its
affiliates ceases to serve as investment adviser to the Licensee. This Agreement shall be terminable
by Licensor at any time and in its sole discretion in the event that Licensor or Licensee receives
notice of any Third Party Claim arising out of Licensee's use of the Licensed Mark; by Licensor or
Licensee upon sixty (60) days' written notice to the other party; or by Licensee at any time in the
event Licensee assigns or attempts to assign or sublicense this Agreement or any of Licensee's
rights or duties hereunder without the prior written consent of Licensor.

- 3 -

Source: PALMER SQUARE CAPITAL BDC INC., 10-12G/A, 1/16/2020
<!-- page 4 -->
4.2. Upon Termination. Upon expiration or termination of this Agreement, all rights granted to
Licensee under this Agreement with respect to the Licensed Mark shall cease, and Licensee shall
immediately delete the term "Palmer Square" from its corporate name and shall discontinue all other
use of the Licensed Mark. For twenty-four (24) months following termination of this Agreement,
Licensee shall specify on all public-facing materials in a prominent place and in prominent typeface
that Licensee is no longer operating under the Licensed Mark, is no longer associated with Licensor,
or such other notice as may be deemed necessary by Licensor in its sole discretion in its
prosecution, defense, and/or settlement of any Third Party Claim. ARTICLE 5. MISCELLANEOUS 5.1.
Third Party Beneficiaries. The parties agree that Investment Advisor shall be a third party
beneficiary of this Agreement, and shall have the rights and protections provided to Licensee under
this Agreement. Nothing in this Agreement, either express or implied, is intended to or shall confer
upon any third party other than Investment Advisor any legal or equitable right, benefit or remedy
of any nature whatsoever under or by reason of this Agreement. 5.2. Assignment. Licensee shall not
sublicense, assign, pledge, grant or otherwise encumber or transfer to any third party all or any
part of its rights or duties under this Agreement, in whole or in part, without the prior written
consent of the Licensor, which consent Licensor may grant or withhold in its sole and absolute
discretion. Any purported transfer without such consent shall be void ab initio. 5.3. Independent
Contractor. Neither party shall have, or shall represent that it has, any power, right or authority
to bind the other party to any obligation or liability, or to assume or create any obligation or
liability on behalf of the other party. 5.4. Notices. All notices, requests, claims, demands and
other communications hereunder shall be in writing and shall be given or made (and shall be deemed
to have been duly given or made upon receipt) by delivery in person, by overnight courier service
(with signature required), by facsimile or by registered or certified mail (postage prepaid, return
receipt requested) to the respective parties at the following addresses (or such other address as
the parties may provide to each other by written Notice): If to Licensor: Palmer Square Capital
Management LLC 1900 Shawnee Mission Parkway, Suite 315 Mission Woods, Kansas 66205 Tel. No.: (816)
994-3200 Fax No.: (913) 647-9733 Attn: Member

- 4 -

Source: PALMER SQUARE CAPITAL BDC INC., 10-12G/A, 1/16/2020
<!-- page 5 -->
If to Licensee: Palmer Square Capital BDC Inc. 1900 Shawnee Mission Parkway, Suite 315 Mission
Woods, Kansas 66205 Tel. No.: (816) 994-3200 Fax No.: (913) 647-9733 Attn: Chief Executive Officer
5.5. Governing Law. This Agreement shall be governed by, and construed in accordance with, the laws
of the State of New York. The parties unconditionally and irrevocably consent to the exclusive
jurisdiction of the courts located in the State of New York and waive any objection with respect
thereto, for the purpose of any action, suit or proceeding arising out of or relating to this
Agreement or the transactions contemplated hereby. 5.6. Amendment. This Agreement may not be amended
or modified except by an instrument in writing signed by each party hereto. 5.7. No Waiver. The
failure of either party to enforce at any time for any period the provisions of or any rights
deriving from this Agreement shall not be construed to be a waiver of such provisions or rights or
the right of such party thereafter to enforce such provisions, and no waiver shall be binding unless
executed in writing by all parties hereto. 5.8. Severability. If any term or other provision of this
Agreement is invalid, illegal or incapable of being enforced by any law or public policy, all other
terms and provisions of this Agreement shall nevertheless remain in full force and effect so long as
the economic or legal substance of the transactions contemplated hereby is not affected in any
manner materially adverse to any party. Upon such determination that any term or other provision is
invalid, illegal or incapable of being enforced, the parties hereto shall negotiate in good faith to
modify this Agreement so as to effect the original intent of the parties as closely as possible in
an acceptable manner in order that the transactions contemplated hereby are consummated as
originally contemplated to the greatest extent possible. 5.9. Headings. The descriptive headings
contained in this Agreement are for convenience of reference only and shall not affect in any way
the meaning or interpretation of this Agreement. 5.10. Counterparts. This Agreement may be executed
in one or more counterparts, each of which when executed shall be deemed to be an original
instrument and all of which taken together shall constitute one and the same agreement. Facsimile or
portable document format (PDF) counterpart signatures to this Agreement shall be acceptable and
binding. 5.11. Entire Agreement. This Agreement constitutes the entire agreement of the parties with
respect to the subject matter hereof and supersedes all prior agreements and undertakings, both
written and oral, between the parties with respect to such subject matter. [Remainder of Page
Intentionally Left Blank]

- 5 -

Source: PALMER SQUARE CAPITAL BDC INC., 10-12G/A, 1/16/2020
<!-- page 6 -->
IN WITNESS WHEREOF, each party has caused this Agreement to be executed on the date first set forth
above by its duly authorized officer. LICENSOR: PALMER SQUARE CAPITAL MANAGEMENT LLC By: Name:
Jeffrey D. Fox Title: Managing Director LICENSEE: PALMER SQUARE CAPITAL BDC INC. By: Name: Scott A.
Betz Title: Chief Compliance Officer ACKNOWLEDGED AND AGREED TO PALMER SQUARE BDC ADVISOR LLC By:
Name: Jeffrey D. Fox Title: Chief Financial Officer [Signature Page to Trademark License Agreement]

Source: PALMER SQUARE CAPITAL BDC INC., 10-12G/A, 1/16/2020
