"""Pydantic contracts shared by every stage. Keep schemas FLAT: small models call tools
more reliably when arguments are scalars and short lists.
"""
from __future__ import annotations

import hashlib
from enum import Enum
from typing import Literal

from pydantic import BaseModel, Field

# --------------------------------------------------------------------------- documents


class DocRecord(BaseModel):
    """One input document: parsed markdown + metadata. Produced by dr.ingest.load."""

    doc_id: str
    title: str
    text: str = Field(description="Markdown body with '<!-- page N -->' markers on their own lines")
    source_path: str | None = None
    metadata: dict[str, str] = Field(default_factory=dict)

    @staticmethod
    def make_id(source_path: str, text: str) -> str:
        h = hashlib.sha1()
        h.update(source_path.encode("utf-8"))
        h.update(b"\x00")
        h.update(text.encode("utf-8"))
        return h.hexdigest()[:16]


class ManifestEntry(BaseModel):
    """Compact per-document row the agent sees via list_docs. No body text."""

    doc_id: str
    title: str
    doc_type: str | None = None
    date: str | None = None
    parties: list[str] = Field(default_factory=list)
    n_pages: int
    n_lines: int
    headings: list[str] = Field(default_factory=list, description="top-level headings, capped")
    extra: dict[str, str] = Field(default_factory=dict)


# --------------------------------------------------------------------------- tool I/O


class GrepMatch(BaseModel):
    doc_id: str
    line: int
    page: int | None
    text: str
    before: list[str] = Field(default_factory=list)
    after: list[str] = Field(default_factory=list)


class GrepResult(BaseModel):
    pattern: str
    total_matches: int
    docs_with_matches: int
    per_doc_counts: list[tuple[str, int]] = Field(description="(doc_id, count), descending, capped")
    per_doc_counts_truncated: bool = False
    matches: list[GrepMatch]
    matches_truncated: bool = False
    elapsed_ms: int = 0


class ReadResult(BaseModel):
    doc_id: str
    start_line: int
    end_line: int
    total_lines: int
    page_start: int | None
    page_end: int | None
    text: str = Field(description="line-numbered text; empty if already_read")
    already_read: bool = False
    note: str | None = None


class OutlineItem(BaseModel):
    level: int
    heading: str
    line: int
    page: int | None


class OutlineResult(BaseModel):
    doc_id: str
    title: str
    n_pages: int
    n_lines: int
    items: list[OutlineItem]
    truncated: bool = False


class SearchHit(BaseModel):
    """Compact hit from the ephemeral BM25 tool (Approach 1)."""

    rank: int
    doc_id: str
    start_line: int
    end_line: int
    page: int | None
    score: float
    snippet: str


class SearchResult(BaseModel):
    query: str
    total_ranked: int
    page: int
    page_size: int
    hits: list[SearchHit]
    has_more: bool


# --------------------------------------------------------------------------- evidence


class EvidenceItem(BaseModel):
    """A verbatim quote with provenance. The writer sees ONLY these."""

    id: str = Field(description="e<n>")
    doc_id: str
    page: int | None
    start_line: int
    end_line: int
    quote: str = Field(description="verbatim text copied from the document window")
    note: str = Field(default="", description="one line: why this matters / what it shows")
    sub_question: str | None = None
    created_by: str = Field(default="researcher", description="researcher|fanout:<i>|extract|first_move")
    tier1_status: Literal["unchecked", "keep", "truncate", "drop"] = "unchecked"
    tier1_score: float | None = None


class Finding(BaseModel):
    """Structured return of a researcher (single or fan-out). Schema-validated on hand-off."""

    sub_question: str
    answer: str = Field(description="short, cites evidence ids inline like [e12]")
    evidence_ids: list[str]
    confidence: Literal["high", "medium", "low"] = "medium"
    not_in_corpus: bool = False
    calls_used: int = 0


# --------------------------------------------------------------------------- planning


class Clue(BaseModel):
    text: str = Field(description="entity, identifier, date, or phrasing to look for")
    grep_patterns: list[str] = Field(default_factory=list, description="1-3 regexes")
    bm25_query: str | None = None


class FirstMoveResult(BaseModel):
    clues: list[Clue]
    opening_observation: str = Field(description="compact, line-cited summary of top hits")
    candidate_doc_ids: list[str] = Field(description="union of docs surfaced, ranked")
    clues_hit: dict[str, int] = Field(default_factory=dict, description="doc_id -> number of clues that hit it")
    estimated_candidate_tokens: int = 0
    decomposed_by: str = Field(default="model", description="model | fallback")
    elapsed_ms: int = 0


class RouteMode(str, Enum):
    single = "single"
    breadth = "breadth"
    long_context = "long_context"


class RouteDecision(BaseModel):
    mode: RouteMode
    rationale: str
    sub_questions: list[str] = Field(default_factory=list)
    doc_batches: list[list[str]] = Field(default_factory=list)
    estimated_evidence_tokens: int | None = None


# --------------------------------------------------------------------------- writing / verifying


class OutlineSection(BaseModel):
    section_id: str
    title: str
    intent: str = Field(description="what this section must answer")
    evidence_ids: list[str] = Field(default_factory=list)
    draft: str | None = None


class Claim(BaseModel):
    claim_id: str
    section_id: str
    text: str
    evidence_ids: list[str]
    is_gap: bool = False


class VerifyResult(BaseModel):
    claim_id: str
    tier1: Literal["keep", "truncate", "drop", "gap"]
    tier1_score: float | None
    tier2: Literal["supported", "partially", "unsupported", "skipped"] = "skipped"
    source_clusters: int | None = None
    note: str | None = None


class Report(BaseModel):
    """Writer output. `markdown` is rendered from `claims` (never from free text), first by the
    writer and again by verify/report.py once tier-1 results and the appendix are known."""

    question: str
    title: str
    sections: list[OutlineSection]
    claims: list[Claim]
    markdown: str = ""
    partial: bool = False
    gaps: list[str] = Field(default_factory=list, description="[GAP] lines and uncited sentences")
    notes: list[str] = Field(default_factory=list, description="writer-side events, e.g. revision skipped")
