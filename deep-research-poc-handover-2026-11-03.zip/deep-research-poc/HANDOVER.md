# Handover — Deep Research Feature over Pre-Filtered Document Sets

*Prepared 2026-11-02 for the next Claude Code session on a machine with no prior context. Everything needed
to continue is in this file or in files it points to inside this folder. The folder is **not a git
repository**. Reviewed by a second model on 2026-11-02; its corrections are folded in.*

**Moving to the new machine.** A ready-made archive, `deep-research-poc-handover-2026-11-03.zip` (≈ 9 MB,
749 files, unpacks to a `deep-research-poc/` folder), was built from this folder on 2026-11-03 with every exclusion
below already applied; its SHA-256 is in the `.sha256` file beside it. Unzip it anywhere and follow §7 (a fresh
venv from `requirements.lock` plus the test suite was verified from that archive on the build day). If you copy
by hand instead, copy everything EXCEPT: `.venv/`, `data/raw/`, `data/cuad_docs/` (rebuilt by §7), `.env` (holds
a key that was once leaked into a transcript — rotate it and put only the new key in the new machine's `.env`),
caches (`__pycache__/`, `.pytest_cache/`, `.ruff_cache/`, `src/*.egg-info/`), and the per-run corpus copies
`eval/results/runs/*/*/docs/`, `.../tool_out/`, `.runs/*/docs/` and `.runs/*/tool_out/` (3 GB of duplicated
documents; keep each run's `report.md`, `verify.json`, `trace.jsonl`, `evidence.jsonl`, `manifest.json`, which the
archive does). `requirements.lock` pins the exact package versions that produced every number here.

---

## 0. Start here

### 0.1 Your first hour
1. Read §0.2 (which documents to trust), §0.3 (terms), §1 (problem and constraints). Ten minutes.
2. Read §2 (what was built), §3 (repository), §4 (phase status), §5 (what was measured and the caveats),
   §6 (models and the operational lessons). Twenty minutes.
3. Do §7 (setup). It ends with a health check of the model endpoint.
4. If the endpoint is healthy, do §8 item 1 (the 12-question smoke eval). If it is throttled, do §9.1
   (the offline, model-free retrieval benchmark), which is the most useful thing that needs no endpoint.
5. Before any design change, read `CLAUDE.md` (binding invariants) and the relevant part of
   `docs/findings.md`. Appendix A holds the research record behind every design decision; consult it
   instead of re-deriving arguments.

Working rules that held throughout: run everything with the venv interpreter; `pytest -q` before a change is
considered done; append to `docs/findings.md` after every live run or eval; never print the API key; prompts
live in `prompts/*.md`, budgets in `src/dr/config.py`, model ids only in `.env` / `src/dr/llm.py`.

### 0.2 Which documents to trust
This file and `docs/findings.md` are current. On 2026-11-02 a review found stale status text in the files below;
each was corrected the same day, so they should now agree with this file. If you still find a disagreement,
**this file wins** and the other file is the one to fix.
| File | What was stale (now corrected) | Where the truth is |
|---|---|---|
| `docs/findings.md` §1–§3, §9 | phase table said Phase 7 "not started"; "87 tests"; "keep eval concurrency at 2"; the 6-question slice given as `--limit 6` | §4 here; 116 tests; concurrency 1 on the free tier; the slice is `--qids cq001,cq037,cq061,cq077,cq089,cq097` |
| `PLAN.md` | side notes beside Phase 0–4 and 6 (probe "not run", pages.py "not built", only the example golden set, "not yet run against a real endpoint", "A3 arrives with Phase 5"); a `metadata_extract.md` prompt that was never written | §4 here; checkbox states and the Phase 5, 7, 8 notes were always current |
| `eval/README.md` | header said every run had thinking on | only the first table did; the A/B and later runs had thinking off |
| `prompts/README.md` | "drafted, untested against a model" | every prompt has been used live (§5) |
| `.env.example` | "intended catalog ids"; "writer/judge have no code yet" | the ids are free-tier stand-ins (§6); every role has code |
| `src/dr/graph.py` docstring | marked A1 and A3 as future phases | all variants in §2.2 are implemented |
| `README.md`, `docs/architecture.md` | status blocks from 2026-11-01 | refreshed 2026-11-02 |
`CLAUDE.md` is auto-loaded by Claude Code, is accurate, and now points here; it names the *intended* production
models, not the stand-ins used so far (§6).

### 0.3 Terms used in this document
- **Super** = `nvidia/nemotron-3.5-super-vl-120b-a12b`; **Lightning** = `nvidia/nemotron-3.5-lightning-30b-a3b`
  (the two models actually used; "the 120B model" means Super).
- **A1 / A2 / A3** = Approach 1 / 2 / 3 (§2.2); `A1_deep_list` etc. are the eval variant names.
- **First move** — one planner call decomposes the question into clues; the harness runs grep + BM25 per clue
  in parallel and writes an *opening observation* (top hits and candidate documents) into the agent's first turn.
- **Deep list** — the cached 1,000-deep BM25 ranking the agent pages through with `page_results`.
- **Unit** — one context-isolated fan-out researcher (a scoped research loop with its own call budget);
  **hand-off** — the unit returning its schema-checked `Finding`; **gap round** — a second, targeted set of
  units for what the first set missed; **TOC briefing** — the document's heading outline placed in a unit's
  first message.
- **Width schedule 3/2/1** — the agent is told to make 3 parallel tool calls per turn early, then 2, then 1.
- **Min-calls floor / forced submit / repeat short-circuit / constrained fallback** — loop guards: a submit
  before 6 tool calls is refused; past the deadline (or after 2 text-only turns) the harness demands a final
  answer; a repeated identical tool call is answered from cache; after 2 malformed turns the model is asked for
  one tool call as plain JSON.
- **Evidence bank** — harness-owned JSONL of verbatim quotes with doc_id, page and line range; the writer's only
  input. **Claim** — one report sentence bound to evidence ids at construction.
- **Tier 1** — deterministic 5-gram alignment of each quote against its cited page: `keep` / `truncate` / `drop`.
  **Tier 2** — grouped model review of claims in context: `supported` / `partially` / `unsupported` / `skipped`.
  **Provenance gate** — MinHash clustering so near-duplicate documents count as one source.
- **`research_done`** (eval rows, traces) ∈ `submitted` (normal), `forced_submit` (harness demanded the answer),
  `deadline`, `stalled` (no tool calls), `model_error` (endpoint failures exhausted retries).
- **Eval columns:** *candidate recall* = gold docs ∩ first-move candidate set (saturated on CUAD, see §5.3);
  *opened-or-cited recall* = gold docs the agent actually read or cited; *gold page cited*; *support* = tier-1
  support rate (cited claims kept or truncated ÷ cited claims); *gate fail* = at least one tier-1 drop or tier-2
  unsupported claim; *tokens / correct* = total tokens ÷ judge-correct answers; *abstain ok* = correct
  not-in-corpus behaviour.
- **Question types** (golden sets): `single`, `temporal`, `identifier`, `coverage`, `multihop`, `not_in_corpus`.
  "Coverage" questions are what the router calls **breadth** (enumeration across documents) and what A3 is for.
  `cq###` = CUAD question id; a *slice* = one question type.

---

## 1. Problem, constraints, and environment

**Goal.** A *deep research* feature: given a user question and a set of documents, produce a cited research
report in **≤ 5 minutes wall-clock**. The eventual corpus is **millions of PDFs**; an upstream **metadata
filtering stage already exists** and returns **500–1,000+ documents per query**. This project owns everything
*after* that filter.

**Inputs the production system will have.** Parsed markdown per document (plus the raw PDFs); document
metadata in the first ~2 pages of each markdown; page markers `<!-- page N -->` required for page-level
citations (derived from the PDFs by `src/dr/ingest/pages.py` when missing — this is how the CUAD corpus was
built).

**Inputs this prototype uses** (none are the production documents):
| Corpus | Size | Purpose |
|---|---|---|
| `data/sample_docs/` | 3 tiny synthetic credit-agreement docs | unit tests |
| `data/golden_docs/` + `data/golden/questions.jsonl` | 31 synthetic financial-legal docs, 42 questions, correct by construction (`scripts/make_golden_corpus.py`) | fast deterministic end-to-end checks |
| `data/cuad_docs/` + `data/golden/cuad_questions.jsonl` | **CUAD v1**: 510 real commercial contracts from SEC filings (CC BY 4.0), 9,348 pages, 112 questions derived from expert clause annotations; built by scripts (§7.4) | the real-document eval |
| `data/golden/cuad_smoke.jsonl` | 12 CUAD questions, 2 per type | quick evaluation (~20 min for A1 + A2 at concurrency 1) |

**Hard constraints (business / environment).**
| Constraint | Consequence for design |
|---|---|
| **No knowledge graphs, no GraphRAG frameworks** | Excluded entirely, including as optional layers |
| **No persistent index** over the filtered set | Filesystem-style tools (grep/read) are primary; an *ephemeral in-memory BM25 built per query* (3 s for 510 docs) is treated as a tool, not infrastructure — decided for the prototype in `CLAUDE.md`; **still to be confirmed by the team** (PLAN open decision 3) |
| **No model training** (no RL / SFT) | Training-free harness over API models only |
| **Only three LLM endpoints in production:** Gemma, Nemotron Nano, GPT-OSS; **no embedding endpoint** | Small/open models; no frontier API; dense retrieval only if a local embedder or an embedding endpoint is approved (§9.2) |
| ≤ 5 minutes per answer | Hard wall-clock deadline that forces synthesis from whatever evidence exists |
| Regulated domain (commercial banking) | Every claim must trace to a verbatim span; unverifiable claims are dropped or flagged, never silently kept; audit trail per run; **production documents must never be sent to a hosted third-party endpoint** |
| Prototype in a **Jupyter notebook** | Code lives in `src/dr`; notebooks only orchestrate (four written, none executed yet) |
| Frameworks: LangChain, possibly LlamaIndex, an internal Agent Development Kit | Used: **LangGraph + langchain-core + langchain-openai**; LlamaIndex not used; the internal SDK is an adapter target for `src/dr/tools/registry.py` |

**Models: intended vs actually used.** The intended production mapping (GPT-OSS 120B for planner / router /
researcher, Nemotron Nano for extractor / verifier, Gemma for writer / judge) could not be tested: none of those
catalog ids serve on the NVIDIA Build free tier used for development. Every number in this document was produced
with the stand-ins in §6. Only `src/dr/llm.py` and `.env` know model ids, so switching is configuration, but every
prompt and budget was tuned against Nemotron 3.5 and must be re-measured on the production models (§7.8).

**The evidence behind the design, in five lines** (Appendix A has the full record with sources):
1. At this corpus size the strongest same-model results come from agents using grep/read over a materialized
   working set (DCI 80 % vs 69 % with a dense tool; RISE 81–83 % at 1M docs), not from a single long-context pass
   (accuracy falls with input length; topically similar documents are the worst distractors).
2. A deep candidate list the agent pages through beats a reranked top-20 (Pi-Serini: depth 5 → 1,000 raised
   surfaced recall 70.5 → 95.8 %), and a one-shot "first move" decomposition adds +5.5–10.9 points.
3. Multi-agent fan-out helps breadth questions but costs 3–10× tokens and fails silently at hand-offs; a single
   agent with parallel tool calls is the default.
4. Report quality comes from the writing protocol: evidence bank + outline-first, fact-bound sections
   (claim-level hallucination 15.9 → 5.0 per 100 claims), with deterministic citation alignment
   (hallucinated citations 18–31 % → 0 %) and grouped model verification on top.
5. Harness engineering beats training for small open models (FinanceHarness: +7.1 from the harness, +0.4 from
   RL), and knowledge graphs under-perform plain retrieval on every benchmark found (GraphRAG 10.3 vs hybrid 20.6
   on HERB).

---

## 2. What was built

All three approaches run end to end on the 510-contract CUAD corpus. Everything below is implemented, unit-tested
with scripted models (no endpoint needed) and live-tested at least once.

### 2.1 The pipeline (`src/dr/graph.py::Pipeline`)
One line: documents are written to a per-query workspace, a lexical "first move" seeds the agent, one research
loop (or a fan-out for breadth) fills an evidence bank with verbatim quotes, the writer drafts sections bound to
that evidence, and two verification tiers plus a provenance gate decide what survives.

| Stage | Runs for | Typical time | Module | What it does |
|---|---|---|---|---|
| Materialize | all | 0.5 s / 510 docs | `workspace.py`, `ingest/load.py` | `docs/<doc_id>.md` (line-addressable, `<!-- page N -->` markers) + `manifest.json` (title, type, date, parties, pages); metadata from a `.meta.json` sidecar or the in-body block |
| First move | A1, A3 | 6–30 s | `agents/first_move.py`, `tools/bm25.py` | ephemeral BM25 (own tokenizer keeps ids like `FAC-2024-0117` whole; 15,155 chunks in 3 s); planner → ≤10 clues (regex fallback if the call fails); grep + BM25 per clue in a thread pool; pseudo-relevance expansion; union → opening observation (top 10 hits, top 15 docs) + cached 1,000-deep ranking |
| Route | A1, A3 | 1–16 s | `agents/router.py` | `single` / `breadth` / `long_context` with code guards (A2 skips the first move and the router) |
| Research: single | all | 7–150 s | `agents/researcher.py::ResearchLoop` | one LangGraph ReAct loop, ≤6 tools, width 3/2/1, 6–25 calls, offload of tool results > 8K tokens, compaction above 60K context, min-calls floor, forced submit, repeat short-circuit, constrained fallback, one retry on model errors. A2 tools: grep · read · outline · list_docs · add_evidence · submit. A1 tools: grep · read · search · page_results · add_evidence · submit |
| Research: breadth | A3 when routed | 30–180 s | `agents/fanout.py::run_breadth`, `tools/extract.py` | router writes one sub-question per named document (≤8 units); each unit = scoped `ResearchLoop` (≤12 calls, injected doc_ids, TOC briefing for ≤3-doc units) in a pool of 4, returning a schema-checked `Finding` ≤1.5K tokens (one retry); extract grid (Lightning, 4-way) over the named docs or the top-40 candidates; one gap round (≤3 units) |
| Write | all | 4–70 s | `agents/writer.py` | outline from the question alone (≤6 sections) → one revision + evidence assignment (or one section per fan-out finding) → sections drafted in parallel from ONLY their evidence with `{{CITE:e<n>}}` → claims; sentences without evidence become `[GAP]` lines |
| Verify | all | < 3 s + tier 2 | `verify/report.py::finalize_report` | **tier 1** (deterministic): 5-gram alignment of each quote vs its cited page → keep / truncate / drop; a dropped claim is replaced in the report by a visible `[DROPPED: claim e… could not be verified…]` marker (never silently removed); relocation records where a misattributed quote was actually found (it does not re-cite). **Provenance gate**: MinHash (64 perms, word 5-grams) clusters near-duplicate cited documents; a claim's source count = distinct clusters (0.95 any pair; 0.8 when parties match). **Tier 2** (model): flagged claims always + 20 % of clean ones, groups of 8, claim + quote + 12 lines of context → `supported` / `partially` / `unsupported`; an unsupported sentence stays in the report flagged `[unsupported by review]` and fails the gate; tier 2 never overrides a tier-1 drop |
| Output | all | — | run folder | `report.md` with `[doc_id p.N]` citations + verification appendix; `verify.json`; `trace.jsonl`; `evidence.jsonl` (§7.10 explains how to read them) |

Deadline: 300 s total; stage budgets in `config.StageBudgetsS`; every model call is capped by its stage deadline;
on the deadline the pipeline writes from whatever the bank holds and marks the report partial.

### 2.2 The three approaches and their state
One line: A1 (first move + deep list) is the strongest single-agent variant measured; A2 is the simpler baseline;
A3 is A1 plus a router-selected fan-out for breadth questions, and is the likely production shape.

| Approach | Variants (`graph.py::VARIANTS`) | State | Best measured result |
|---|---|---|---|
| **2 — materialized working set + filesystem agent** | `A2_fs_agent`; ablation `A2_grep_only` | done, live-tested | 3/6 on the CUAD slice with thinking on; one of the three misses was a transient connection error (since retried), so the A2 baseline is weaker evidence than it looks and has not been re-run with thinking off |
| **1 — deep-list search loop + first move** | `A1_deep_list`; ablations `A1_no_first_move`, `A1_bm25_only` | done, live-tested | **5/6** on the CUAD slice with planner + researcher thinking off |
| **3 — planner-selected fan-out + extract grid** | `A3_fanout` (= A1 + breadth branch), `A3_grid_only` | done; four live iterations on one coverage question; structurally sound; judge not yet passing | v4: 111 s, 436k tokens, 0 failed hand-offs, 33 claims at support 0.95; grid-only 28 s / 104k |
| Long-context router branch | `LC_small` | **not implemented** (router can select it; the graph falls back to single) | — |

### 2.3 Shared machinery
Evidence bank (`evidence.py`: verbatim guard + overlap dedupe) · outline-first fact-bound writer · tier 1
(`verify/tier1.py`) · provenance gate (`verify/provenance.py`) · tier-2 grouped review (`verify/tier2.py`) ·
deadline graph · trace (`trace.py`, one JSONL per run, no document bodies) · structured output with one JSON
repair (`structured.py::ModelCaller`) · client-side pacing and 429 retries (`ratelimit.py`,
`structured.py::invoke_with_backoff`) · eval runner, metrics and rubric judge (`eval/`) · a local cross-encoder
rerank hook that already exists (`tools/rerank.py`: MiniLM-L6 over the top 50 question-level hits, scoring the
240-character snippet, **off by default, untested live**, model id hard-coded there — see §9.2).

### 2.4 Why these choices (evidence → decision)
| Decision | Evidence |
|---|---|
| Filesystem tools over the subset, not an index | DCI/RISE (Appendix A.3.1); constraint |
| Lexical + agent reformulation here; hybrid only if an index exists upstream | ViDoRe V3 BM25 weakness on PDFs; the "BM25 climbs inside an agentic loop" claim (BRIGHT-Pro) was **refuted 0–3** by the 2026-11-02 research check — see §9.0; fusion with dense is now the recommended next step |
| Agent pages a deep list and reads full docs; no rerank-to-20 in the hot path | Pi-Serini k 5 → 1,000: recall 70.5 → 95.8; `get_doc` +15–19 |
| First move before the loop | Question's Gambit; measured here: the gold document was in the candidate set on every CUAD question (but see §5.3: the candidate sets are large) |
| Single agent + parallel tool calls by default | W&D width scheduling; leaderboard 90.5 % at 11.5–34 calls vs 95.2 % at 209; Anthropic 3–10× |
| Fan-out only for breadth | InfoSeeker; InfiAgent; hand-off failure study; measured here: 4× the tokens of a single run |
| Counts in grep, read tracker, ≤ 6 tools, flat schemas | INDEXACT ablations (counts vs booleans +12); A-RAG; small-model reliability |
| Evidence bank in harness state; writer never sees the transcript | WebWeaver; Scroll (lossy ingest 73 → 20) |
| Outline from question first; fact-bound sections | ClaimWriter 15.9 → 5.0 /100; ScaffoldAgent |
| Deterministic tier 1, grouped tier 2, provenance gate | EvidenT; DeepFact; CiteAudit; evidence laundering; measured here: seeded check 10/10 |
| 300 s deadline with forced write | Pi-Serini; General-AgentBench (an agent benchmark finding that extra turns do not reliably help) |
| No graphs | constraint; GraphRAG 10.31 HERB, 0.36 Librarian table, 47.95 vs BM25 63.66 |
| No training | FinanceHarness +7.1 harness vs +0.4 RL; untrained models hold BC+ ranks 1–18 |
| Thinking off for every role | measured here (§5.2): no accuracy gain, 66–110 s spikes that blew stage budgets |

### 2.5 Explicitly not doing (and why) — see also `CLAUDE.md`
Single long-context pass over the subset (router branch only) · rerank-to-top-20 as the agent's view ·
pre-summarizing documents into context · multi-agent by default · Librarian-style offline curation (needs RL;
~31 queries/partition break-even) · knowledge graphs · persistent index · model training · BM25 k1/b tuning on
the eval corpus (overfits; needs a held-out split; the published "+18 % from tuning" claim was refuted 0–3 in the 2026-11-02 research check). *Parallel rollouts + aggregator* were deferred "until a
verifier exists" (`TODO.md` 8); tier 2 now exists, so they are back on the experiment list (§9.5).

### 2.6 Budgets as configured (`src/dr/config.py`)
| Group | Values |
|---|---|
| Stage seconds (`StageBudgetsS`) | total 300 · materialize 10 · first move 30 · research 150 (gap round ≤ 45 inside it) · write 45 · verify 30 · reserve 30 (never scheduled); validated at import |
| Agent (`AgentBudgets`) | 6–25 calls · width 3/2/1 · 60K context cap · 2 malformed turns → constrained step · 2 no-tool turns → forced submit · 15 s grace past the deadline · 2 model errors → give up · outline ≤ 6 sections, 2 iterations · 4 sections drafted in parallel · long-context only below 100K tokens |
| Fan-out | width 4 · ≤ 8 units · 2–12 calls per unit · findings ≤ 1.5K tokens · batches of 40 docs · 1 gap round of ≤ 3 units · extract grid 4-way, 12K tokens per doc (header + 6 BM25 chunks) |
| Tools (`ToolCaps`) | grep 40 matches + complete per-doc counts (50 rows) + 1 context line · read ≤ 120 lines (default 60) · outline ≤ 80 headings · list_docs ≤ 60 rows · first move ≤ 10 clues, 200 BM25 hits per clue, 3 feedback docs, 5 expansion terms · offload above 8K tokens with a 40-line preview |
| Verify (`VerifyParams`) | 5-gram · align 0.70 / truncate 0.40 · tier-2 groups of 8, 20 % clean sample, 12 context lines · MinHash 64 perms, near-dup 0.95 / 0.8 same parties |
| Rate limiting (`Config`) | `DR_RPM_LIMIT` pacing (30 in `.env`; off when unset) · 429 retries 2 / 4 / 8 / 16 / 30 s, capped by the stage deadline |
| Feature flags (`Config`) | `ENABLE_BASH_TOOL=False` (team decision pending) · `ENABLE_LOCAL_RERANK=False` |

Known limits that are **not** in config (exceptions to invariant 10, worth moving): fan-out's "≤ 3 docs gets a
TOC briefing" and `docs_named_in(limit=8, min_score=2)`; the first-move thread pool `min(8, …)`; rerank `top_n=50`
and its model id; the judge's `max_report_chars=12_000`; the extract grid's 15-line header; the 90 s timeout and
1 retry defaults in `llm.py`.

---

## 3. Repository state (2026-11-02)

`(gi)` = gitignored, i.e. not under version control if the folder is ever put in git, but present on disk.

```
deep-research-poc/
  CLAUDE.md                     invariants (binding); points here for a cold start
  HANDOVER.md                   this file
  PLAN.md                       phased backlog with acceptance criteria; side notes corrected 2026-11-02
  TODO.md                       10 deferred approaches, each with what / why / measure / refs
  README.md                     quick start; status block refreshed 2026-11-02
  requirements.lock             pip freeze of the venv that produced every number here
  pyproject.toml                deps; extras dev / ingest / rerank / provenance / deepagents
  .env.example                  endpoint, model ids, thinking switches, DR_RPM_LIMIT, dated calibration comments
  .env (gi)                     the real key; do not copy; rotate
  docs/findings.md              experiment log, §1-§13 — the primary record (status table corrected 2026-11-02)
  docs/architecture.md          one-page Mermaid diagram + stage/model tables
  docs/endpoints.md (gi)        probe tables + dated endpoint notes incl. the 429 diagnosis; present on disk
  docs/diagrams/pipeline_and_researcher.html   rendered diagram
  docs/research/                the two full research reports (Appendix A summarizes them)
  eval/README.md                all eval tables
  eval/results/ (gi)            <variant>-<ts>.jsonl rows + .summary.md; runs/<tag>/<qid>/ report.md, verify.json, trace.jsonl, evidence.jsonl, manifest.json, docs/ (corpus copy, 27 MB each)
  prompts/                      21 prompt files + README.md inventory: researcher, research_task, width_turn, width_phase_hints, nudge_no_tools,
                                nudge_min_calls, force_submit, force_reasons, constrained_call, tool_help, json_repair, first_move, router,
                                outline, outline_revise, writer_section, fanout_researcher, extract, gap_check, judge, verifier_tier2
  scripts/                      probe_endpoints.py · make_golden_corpus.py · fetch_cuad.py · make_cuad_corpus.py · make_cuad_golden.py
  notebooks/                    01_approach2_filesystem_agent · 02_end_to_end_a2 · 03_approach1_deep_list · 04_approach3_fanout (written, unexecuted)
  data/sample_docs/             3 synthetic docs (tests)
  data/golden_docs/             31 synthetic docs;  data/golden/questions.jsonl (42 q), questions.example.jsonl, README.md
  data/golden/cuad_questions.jsonl   112 CUAD questions;  data/golden/cuad_smoke.jsonl  12 questions
  data/cuad_docs/ (gi)          510 .md + .meta.json + _alignment.json (page-anchoring artefact the tests and golden generator need); rebuilt by scripts
  data/raw/cuad/ (gi)           the Zenodo download + SOURCE.md (licence/attribution)
  .runs/ (gi)                   scratch workspaces from live runs; safe to delete
  src/deep_research_poc.egg-info/   from `pip install -e`
  src/dr/   (5,415 lines)
    config.py 139               ToolCaps, AgentBudgets, StageBudgetsS, VerifyParams, Config
    models.py 221               pydantic contracts (DocRecord, ManifestEntry, tool results, EvidenceItem, Finding, Clue, RouteDecision, OutlineSection, Claim, Report, VerifyResult)
    workspace.py 151            materialize / load, line→page map, path-escape guard
    evidence.py 140             EvidenceBank
    trace.py 47                 structured audit events
    llm.py 186                  get_llm(role), .env loader, EndpointConfig (timeout, retries, max_tokens, thinking), ScriptedChatModel for tests
    structured.py 138           extract_json, is_rate_limit, invoke_with_backoff, ModelCaller
    ratelimit.py 69             sliding-window pacer per endpoint
    prompts.py 58               load(name, **fields), load_sections
    tools/grep.py 148           ripgrep accel + pure-Python fallback (Windows path fix)
    tools/read.py 76            capped windows, ReadTracker
    tools/outline.py 43 · tools/manifest.py 49 (list_docs with doc_type / date_from / date_to / party_contains filters)
    tools/bm25.py 189           BM25Index: tokenizer, chunking (chunks are indexed as "title | heading\nbody"), cached deep ranking, paging, expand_query
    tools/extract.py 165        extract grid (document_context already uses the first move's expanded query to pick chunks)
    tools/offload.py 46 · tools/rerank.py 26 (MiniLM cross-encoder, off by default) · tools/registry.py 173 (ToolSpecs, ≤6 assert, LangChain adapters)
    agents/researcher.py 661 · first_move.py 221 · router.py 83 · writer.py 338 · fanout.py 245
    verify/tier1.py 104 · provenance.py 134 · tier2.py 204 (incl. seeded_check) · report.py 113 (finalize_report, appendix)
    ingest/load.py 56 · metadata.py 76 (LLM fallback is a stub) · pages.py 277 (PDF page anchoring; built CUAD)
    eval/golden.py 86 · metrics.py 181 · run.py 219 (CLI below)
    graph.py 309                VARIANTS, Pipeline nodes, build_graph, run(question, docs, variant, root)
  tests/   116 tests, ~20 s, no model calls; 8 of test_cuad's 10 skip until data/cuad_docs exists (108 passed + 8 skipped without it)
           test_tools 14 · test_perf 1 · test_config 2 · test_llm 2 · test_structured 5 · test_researcher 17 · test_writer 10 · test_graph 3
           test_approach1 9 · test_eval 8 · test_fanout 15 · test_verify2 9 · test_golden 11 · test_cuad 10
```
Eval CLI (`python -m dr.eval.run`): `--variant --golden --docs [--limit N] [--qids a,b] [--types t1,t2] [--no-judge]
[--concurrency N, default 2] [--stop-after-errors N, default 5] [--resume <jsonl>] [--dry]`.
Lint: `ruff` is unpinned in `pyproject.toml` and selects no rule set, so its findings vary by version (0.17.3 reports
26 across src, tests and scripts); none affect behaviour. Pin it before relying on it.

---

## 4. Phase status (`PLAN.md` has the acceptance criteria)

One line: everything through Phase 7 is built and live-tested; the Phase 6 *measurements* and the Phase 8
hardening are what remain, and several acceptance criteria were never measured.

| Phase | Deliverable | Built | Acceptance measured? | Evidence |
|---|---|---|---|---|
| 0 | endpoints probed, corpus loading with page markers + manifest, golden set v1 | yes (sandboxed-bash decision open; metadata kept in the body **and** written as a sidecar) | partly: 1,000 docs load < 10 s yes; `docs/endpoints.md` filled | `docs/endpoints.md`, `data/golden/README.md` |
| 1 | workspace + tools + evidence bank | yes | yes: grep < 1 s / 1,000 docs; no path escapes | `tests/test_tools.py`, `test_perf.py` |
| 2 | Approach 2 single agent | yes, live-tested | partly: opened-or-cited recall 0.80 on the 6-question slice (target ≥ 0.8); calls within [6, 25]; **malformed-call rate < 5 % never measured** | `tests/test_researcher.py`; findings §4 |
| 3 | writer + tier 1 + deadline graph | yes, live-tested | yes on the slice: 100 % of claims have evidence or a gap flag; support 0.93–1.00; p95 ≤ 300 s | `tests/test_writer.py`, `test_graph.py`; findings §5 |
| 4 | Approach 1: BM25 deep list + paging + first move + router | yes, live-tested | partly: first move < 30 s p50 yes; candidate recall ≥ 0.9 yes (but saturated, §5.3); **router agreement ≥ 0.85 against hand labels never measured — there are no hand labels** | `tests/test_approach1.py`; findings §6 |
| 5 | Approach 3: fan-out + extract grid + gap round | yes; 4 live iterations on cq077; judge not yet passing | **no**: "item recall ≥ 1.5× single agent" cannot be measured until the item-recall metric is fixed (§5.3); zero unvalidated hand-offs yes (v4); "grid ≤ 90 s for 1,000 docs" not measured | `tests/test_fanout.py`; findings §8b; eval/README |
| 6 | three-way eval + ablations | runner, metrics, judge, 7 variants yes; **the measurements no** (free endpoint throttling, §5.5) | no | `tests/test_eval.py`; eval/README |
| 7 | tier-2 verification + provenance gate | yes | yes: seeded check 10/10 ≥ 80 %; near-duplicates clustered | `tests/test_verify2.py`; findings §12 |
| 8 | hardening | partly: per-role timeouts/retries, thinking switch, model-error retry, 429 pacing/backoff, resume | no: **tripwires with tests, budget tuning from traces, prompt-cache prefix, audit export, ablations notebook not started** | findings §7, §11, §13 |

---

## 5. What was measured (condensed from `docs/findings.md`; all 2026-11-01/02, NVIDIA Build free tier)

### 5.1 Scale and mechanics (no model)
load 510 docs 0.2 s · materialize 0.5 s · BM25 build 3.0 s for 15,155 chunks (synthetic worst case of 1,000 dense
docs / 17k chunks: 2.7 s idle, 4.2 s under CPU contention; the test allows 4 s and may fail on a slower machine) ·
grep < 1 s over 1,000 docs · tier 1 ≈ 2 ms per report · provenance signatures cached per workspace.

### 5.2 Phase 2–4 live runs (synthetic corpora) and the thinking discovery
- Researcher alone on the 3-doc sample: correct in 39 s, 5 turns, 8 tool calls; the verbatim guard rejected one
  paraphrased quote and the model retried with the exact line.
- Nemotron 3.5 "thinks" ~5K tokens (88 s) per writer call; capping `max_tokens` truncates the thinking and returns
  nothing; `reasoning_effort` is ignored by the endpoint. Full graph on the sample question: 142 s before the
  thinking switch (write stage 130 s), 48–76 s after.
- A1 on the 31-doc synthetic corpus, temporal question (which amendment governs on a date): first move 24–28 s,
  7 clues, gold doc rank 2; router `single` with correct reasoning about a not-yet-effective amendment; 61–76 s
  total, every claim verified. After clue expansion + outline bound: 61 s and 43 s, still correct.

### 5.3 CUAD slice, one question per type (6 questions, 510 real contracts)
One line: turning thinking off for the planner and researcher took the slice from 3/6 to 5/6 at the lowest tokens
per correct answer; n = 1 per type, so single flips are within noise.

| variant | judge | opened/cited | gold page | support | gate fail | wall p50 | calls p50 | tokens p50 | tokens / correct |
|---|---|---|---|---|---|---|---|---|---|
| A1, thinking on | 3/6 | 0.96 | 0.88 | 0.94 | 1/6 | 65 s | 10 | 96k | 297k |
| A2, thinking on | 3/6 | 0.80 | 0.72 | 0.93 | 1/6 | 33 s | 11.5 | 111k | — |
| A1, planner thinking off (+ abstention prompt) | 3/6 | 0.96 | 0.88 | 0.96 | 1/6 | 50 s | 11.5 | 98k | 288k |
| A1, researcher thinking off | 5/6 | 0.96 | 0.80 | 1.00 | 0/6 | 50 s | 16.5 | 243k | 294k |
| **A1, planner + researcher off (adopted)** | **5/6** | **1.00** | **0.96** | **1.00** | **0/6** | 53 s | 13 | 164k | **212k** |

Reproduce: `python -m dr.eval.run --variant A1_deep_list --golden data/golden/cuad_questions.jsonl --docs data/cuad_docs --qids cq001,cq037,cq061,cq077,cq089,cq097 --concurrency 1`
(not `--limit 6`: the file is sorted by type, so that would run six `single` questions).

Per-question lessons: the multihop miss was *localization between sibling agreements with overlapping parties*
(fixed by the "confirm the document identity" prompt rule); the not-in-corpus miss was a noncircumvention clause
presented as a non-compete (fixed by the abstention rule); the coverage question (8 agreements) fails on every
single-agent variant: 25 calls exhausted, 1–2 of 5 listed, router chose `single` → Phase 5.

**Three measurement caveats found in review (2026-11-02), each a pending fix (§8.2):**
1. *Candidate recall is saturated on CUAD.* The first-move candidate sets held 277–427 of the 510 documents
   (54–84 % of the corpus), so "candidate recall 1.0" says almost nothing. Report the candidate-set size, the gold
   document's rank in the first-move ranking, and whether it was among the 15 documents shown in the opening
   observation.
2. *Item recall on CUAD coverage questions is inflated.* `metrics.item_recall` searches the whole report text,
   and the report begins with the question, which lists the contracts by party name — the very strings used as
   gold items. Every cq077 run scored item recall 1.0, including grid-only runs that found nothing. In 3 of the
   12 CUAD coverage questions every gold item appears in the question; in 7 more, at least 60 % do. Score each
   listed contract as a classification (positive only with a cited clause page in that document) and exclude
   the title and question lines.
3. *The judge reads only the first 12,000 characters* (`metrics.py`); A3 v2–v4 reports were 13.7–15.3K
   characters, so long breadth reports were graded on a prefix. Raise the cap or judge the claim list.

### 5.4 Phase 5 fan-out on the coverage question cq077 (8 named agreements, non-compete)
One line: four iterations removed every harness failure (compressed findings, unscoped units, a unit out of calls,
grid over 320 documents); what remains is a model-level miss inside a document the system already had.

| attempt | change | result | wall | tokens |
|---|---|---|---|---|
| A1/A2 reference | single agent | 1–2 of 5 | 81–177 s | 224–334k |
| A3 v1 | 8 sub-questions, 8 units over 418 candidates | writer compressed 8 findings into 2 sections | 68 s | 778k |
| A3 v2 | one outline section per finding | 2/3 rubric; one unit never submitted | 82 s | 887k |
| A3 v3 | units scoped to the agreement they name (`docs_named_in`) | one unit out of calls on a long doc | 177 s | 655k |
| A3 v4 | TOC briefing; forced submit without evidence = low-confidence finding; timeout cap | 33 claims, support 0.95, 0 failed hand-offs; 2 agreements still missed | 111 s | 436k |
| A3_grid_only v4 | grid over the 40 named docs, extractor thinking off | 1 verified quote | 28 s | 104k |

Of the two v4 misses, one unit greps for "non-compete" and never finds "shall not sell competing products"; the
other was a judgment call (the Sponsorship agreement was excluded). The extract grid picks chunks with the first
move's expanded query, not only the question's words (built, untested live). Caveat from the golden-set README:
CUAD negatives are expert labels, so a clause the annotators missed makes a coverage or not-in-corpus question
unfair to a correct system. **This is one observed failure consistent with vocabulary mismatch inside a known
document; no paraphrase slice has been measured yet** (§9.1 builds one).

### 5.5 Phase 7
- Provenance calibration on the synthetic corpus: conformed copies ≥ 0.97 similarity, template-built agreements
  for *different* borrowers 0.92–0.94 (shared boilerplate), amendments < 0.2 → thresholds 0.95, or 0.8 when both
  documents list the same parties. Not yet calibrated on CUAD (SEC exhibits reuse boilerplate; §9.5).
- Seeded tier-2 check (10 true + 10 planted claims, Lightning verifier, groups of 8): first attempt flagged 1/10
  because the perturbation changed section labels; after targeting substantive values (ratios, %, $, dates, day
  counts) **10/10 flagged, 0 false flags**, 2 true claims skipped (the verifier omitted their ids).
- The hazard that motivated the gate was seen live: the writer counted a conformed copy as a second source.

### 5.6 The full and smoke CUAD passes (not yet a measurement)
- Full A1 pass at concurrency 2: 14 questions answered, then every call returned 429 for 28 questions, each
  "completing" in ~10 s as a report of gaps (graceful degradation hid the outage). Fixes: 429 backoff,
  `model_error` counted by `--stop-after-errors`, `--resume`. **12 clean, judge-correct A1 rows** survive in
  `eval/results/A1_deep_list-20261101-231543.jsonl` — all of type `single` (cq001–cq012), so this is not an
  accuracy result. They are valid for `--resume` only while the code, prompts and models match that run
  (2026-11-01 23:15).
- Smoke set (12 questions): three attempts were dominated by the endpoint. Probe with nothing else running: the
  120B endpoint rejected 3 of 10 one-word calls (HTTP 429, body `Too Many Requests`, no retry-after); under two
  workers ~65–70 % of calls were rejected in chains of 4–5. Clean rows: cq001 correct 58 s, cq002 correct 91 s;
  cq037 reached the right answer but ended on a 429 (`model_error`, so resume would re-run it). Partial table in
  `eval/README.md`. Retrieval metrics were clean on every row; the losses were rejected model calls.

---

## 6. Models and endpoints actually used, and the operational lessons

**Endpoint:** NVIDIA Build free tier, OpenAI-compatible, `https://integrate.api.nvidia.com/v1` (`.env`).
One line: two Nemotron 3.5 models stand in for the three intended production models; thinking is disabled for
every role; the free tier throttles hard, so evals run one request at a time.

| Role | Model id | Thinking | Notes |
|---|---|---|---|
| planner, router, researcher, writer, judge | `nvidia/nemotron-3.5-super-vl-120b-a12b` (Super) | off | tools, parallel tool calls (2 per turn observed), JSON all pass; sub-second small calls when accepted |
| extractor, verifier | `nvidia/nemotron-3.5-lightning-30b-a3b` (Lightning) | off | tools + JSON pass; one tool call per turn; occasional 10–17 s queueing |
| documented fallback | `openai/gpt-oss-20b` | — | works but 50–70 s per call, one tool call per turn |
| not usable on this tier | `openai/gpt-oss-120b` is not in the catalog; `nvidia/nemotron-nano-3-30b-a3b`, `google/gemma-3-12b-it`, `nvidia/nemotron-3-super-120b-a12b`, `llama-3.1-nemotron-*` are listed but 404 on chat; `google/gemma-4-31b-it` timed out | | re-probe on a new day with `--list`; the catalog changes |

Operational lessons, each of which cost real time:
1. **Thinking mode.** `DR_THINKING_<ROLE>=0` sends `chat_template_kwargs.enable_thinking=false` (a vLLM/NIM field).
   Thinking off everywhere: write 130 s → 4 s, slice 3/6 → 5/6. GPT-OSS uses `DR_EFFORT_<ROLE>` instead (§7.8).
2. **Timeouts.** Per-role `DR_TIMEOUT_<ROLE>` (90 s) and `DR_RETRIES_<ROLE>` (1) replaced the client defaults
   (120 s × 3: a dead endpoint cost 361 s per call). Every call is also capped by its stage deadline.
3. **Transient errors** cost a turn, not the run (`MODEL_ERRORS_MAX=2`).
4. **Rate limiting.** The free tier throttles on bursts *and* sheds load per request on busy nights. Pacer
   `DR_RPM_LIMIT=30`; retries 2/4/8/16/30 s capped by the deadline; **the runner's default is `--concurrency 2`;
   pass 1 on this tier**. Traces record `rate_limit_wait` events so throttled runs are identifiable.
5. **Judge** appends its calls to the run's `trace.jsonl` through a fresh handle (the pipeline closes its own).
6. **Windows.** ripgrep emits backslash paths (fixed in `grep.py`). Unicode in prompts and reports raises
   `cp1252` errors in PowerShell: set `$env:PYTHONIOENCODING='utf-8'`, and when running the data scripts with
   `python -I` (which ignores `PYTHON*` variables) use `python -I -X utf8 …`.
7. **doc_id depends on the path string.** `DocRecord.make_id(str(path), text)` hashes the path exactly as passed
   (`data\cuad_docs\x.md` on Windows). On Linux/macOS, or with a different `--docs` spelling, every doc_id changes
   and the ids in old reports, evidence files and README citations will not match new runs (resume still works;
   it is keyed by qid). Consider hashing the path relative to the docs directory.
8. **Security.** The NVIDIA key was once pasted into `.env.example` and echoed into a transcript. Rotate it; never
   print `.env` values; never send production documents to a hosted endpoint.

---

## 7. Setting up on a new machine

1. Python 3.11+ (developed on 3.12, Windows 11). From the folder root:
   ```
   python -m venv .venv
   .venv\Scripts\activate                       (or: source .venv/bin/activate)
   pip install -e ".[dev,ingest]" -c requirements.lock
   ```
   (`ingest` adds pymupdf, needed only to build the CUAD corpus.) `requirements.lock` pins what produced every
   number here (langgraph 1.2.19, langchain-core 1.7.3, openai 3.42.1, bm25s 0.3.16, pymupdf 2.0, pydantic 2.14.2);
   it is a `pip freeze` with the project's own editable line removed, because pip rejects editable lines in a
   constraints file (this was caught by a fresh install from the archive on 2026-11-03). ripgrep is optional (the
   pure-Python fallback is tested). `datasketch` and `sentence-transformers` are not needed: the provenance gate is
   pure Python and the reranker hook is off by default.
2. `copy .env.example .env` and put a **new** key in `DR_API_KEY_DEFAULT`. Check the catalog with
   `python scripts/probe_endpoints.py --list` only. **Do not run the full probe casually**: it rewrites
   `docs/endpoints.md` keeping only the table rows (the dated notes section, including the 429 diagnosis, would be
   lost) and it sends an 8-way burst. If you need the full probe, first copy `docs/endpoints.md` to
   `docs/endpoints_notes_2026-11.md`.
3. `python -m pytest -q` → 108 passed + 8 skipped without the CUAD corpus; 116 passed with it. Two timing tests
   (`test_approach1` BM25 build < 4 s; `test_perf` grep < 1 s) may fail on a slower or busy machine; that is not a
   regression unless `bm25.py` or `grep.py` changed.
4. Build the real corpus (deterministic; only the questions file is checked in):
   ```
   python -I -X utf8 scripts/fetch_cuad.py              106 MB from Zenodo, md5-verified
   python -I -X utf8 scripts/make_cuad_corpus.py        510 PDFs -> data/cuad_docs/*.md + *.meta.json + _alignment.json (~2 min)
   python -I -X utf8 scripts/make_cuad_golden.py --check    exits 1 if the regenerated questions differ from the checked-in file
   python -m dr.eval.run --dry --golden data/golden/cuad_questions.jsonl --docs data/cuad_docs
   ```
   Use `--check`, not a bare run: a bare run **overwrites** `cuad_questions.jsonl`, and if page anchoring differs on
   the new machine the gold pages would change silently and every earlier result would stop being comparable.
   If `--check` fails, investigate `_alignment.json` differences before regenerating.
5. **Health check before any eval** (the free tier sheds load on busy nights; §5.6). Ten one-word calls, one
   request in flight, 1 s apart; go when ≥ 9/10 are accepted, otherwise wait:
   ```python
   import time
   from dr.llm import get_llm
   llm = get_llm("researcher"); ok = 0
   for i in range(10):
       try:
           llm.invoke("Say OK.", max_tokens=5); ok += 1
       except Exception as e:
           print(type(e).__name__)
       time.sleep(1)
   print(f"{ok}/10 accepted")
   ```
6. One live question (≈1 min when healthy):
   ```
   python -m dr.eval.run --variant A1_deep_list --golden data/golden/cuad_smoke.jsonl --docs data/cuad_docs --qids cq001 --concurrency 1
   ```
   From Python (what the notebooks do):
   ```python
   from pathlib import Path
   from dr.ingest.load import load_dir
   from dr.graph import run
   docs = load_dir(Path("data/cuad_docs"))
   state = run("Which jurisdiction's law governs the Endorsement Agreement between Teardrop Putter Corporation and Consolidated Artists Inc.?",
               docs, variant="A1_deep_list", root=Path(".runs/try1"))
   print(sorted(state))                      # RunState keys; report.md and verify.json are in .runs/try1/
   ```
7. The smoke eval (§8 item 1): the two commands in §8.1. Healthy: 40–90 s per question. Rows showing
   `model_error` / `deadline` with traces full of `rate_limit_wait` mean the endpoint is shedding load; stop and
   retry later rather than reading the numbers.
8. **If you have the production or a paid endpoint instead of the free tier:** set `DR_ENDPOINT_*` / `DR_MODEL_*`
   per role in `.env`; for GPT-OSS roles remove `DR_THINKING_*` (it is a vLLM/NIM field) and set
   `DR_EFFORT_<ROLE>=medium`; set `DR_TOOLS_WRITER=0` if Gemma rejects the `tools` parameter;
   `DR_PARALLEL_TOOLS_<ROLE>=0` if the probe shows one tool call per turn; raise or unset `DR_RPM_LIMIT` and use
   `--concurrency 2–4`. Old result rows and `--resume` files are then **not comparable**; start fresh result files.
9. Two more recipes the measurements relied on:
   ```python
   # seeded tier-2 check: needs a finished run whose bank holds >= 10 non-dropped evidence items
   from pathlib import Path
   from dr.workspace import Workspace
   from dr.evidence import EvidenceBank
   from dr.llm import get_llm
   from dr.verify.tier2 import seeded_check
   ws = Workspace.load(Path(".runs/try1")); bank = EvidenceBank(ws)
   print(seeded_check(ws, bank, get_llm("verifier")))        # planted, flagged, flag_rate, false_flags, skipped
   # provenance clusters over a whole workspace (corpus statistics; not on the query path)
   from collections import Counter
   from dr.verify.provenance import cluster_all
   sizes = Counter(cluster_all(ws).values()); print(sorted(s for s in sizes.values() if s > 1))
   ```
10. **Reading a run folder** (`eval/results/runs/<tag>/<qid>/` or `.runs/<name>/`):
    - `report.md`: the report, then a verification appendix (claim / section / tier 1 / score / tier 2 / clusters /
      sources / note, then the evidence list). Markers inside the text: `[GAP]` (no evidence for that sentence),
      `[DROPPED: claim e… could not be verified…]` (tier-1 drop), `[uncited]`, `[partially supported by review]`,
      `[unsupported by review]` (tier 2).
    - `verify.json`: one object per claim: `claim_id`, `tier1` ∈ keep/truncate/drop/gap, `tier1_score`, `tier2` ∈
      supported/partially/unsupported/skipped, `source_clusters`, `note`.
    - `trace.jsonl`: one event per line with `kind` ∈ `stage` (start/end with fields such as `done`, `turns`,
      `calls_used`, `n_evidence`, `elapsed_ms`), `model` (role, model, tokens, ms), `tool` (name, args hash and
      preview, result chars, ms), `rate_limit_wait`, `model_error`, `tool_offload`, `tool_repeat`, `compaction`,
      `force_skip`, `model_skip`, `json_invalid`, `submit`, `fanout_unit`, `bm25_index`. The judge's events are
      appended at the end.
    - `evidence.jsonl`: the bank; each item has `id`, `doc_id`, `page`, `start_line`, `end_line`, `quote`, `note`,
      `tier1_status`, `tier1_score`.
    - The eval row (`eval/results/<variant>-<ts>.jsonl`) carries `research_done`, `wall_s`, `stage_ms`, call and
      token counts, every metric in §0.3, `judge_verdict` / `judge_reason`, `errors` and `run_root`.

---

## 8. Pending work, in priority order

1. **Get a clean smoke measurement** when the endpoint passes the health check, or on a paid / self-hosted
   endpoint: `A1_deep_list`, `A2_fs_agent` **and `A3_fanout`** (A3 = A1 plus the breadth branch; it is the
   likely production shape and has never been run on a mixed slice):
   ```
   python -m dr.eval.run --variant A1_deep_list --golden data/golden/cuad_smoke.jsonl --docs data/cuad_docs --concurrency 1
   python -m dr.eval.run --variant A2_fs_agent  --golden data/golden/cuad_smoke.jsonl --docs data/cuad_docs --concurrency 1
   python -m dr.eval.run --variant A3_fanout    --golden data/golden/cuad_smoke.jsonl --docs data/cuad_docs --concurrency 1
   ```
   Record in `eval/README.md` and `docs/findings.md`. Until then every comparison rests on 6 questions.
2. **Fix the three measurement defects in §5.3 first** (item recall counting the question text; candidate-set
   size and gold rank instead of saturated candidate recall; the judge's 12K-character cap), then re-score the
   existing cq077 rows. Without this the Phase 5 acceptance criterion cannot be evaluated.
3. **Full CUAD pass** (112 questions): A1 with `--resume eval/results/A1_deep_list-20261101-231543.jsonl` (valid only
   if code, prompts and models are unchanged since that run), then A2, then A3 on `--types coverage` (12 questions)
   against A1/A2 on the same slice. On the free tier at concurrency 1 this is roughly 2–6 hours per variant. Then
   write the Phase 6 deliverable: results per variant per slice and the production default with numbers.
4. **Enumeration and paraphrase, next levers (from the 2026-11-02 research, §9.0):** a result-set tool with counts
   and set operations plus no text previews in `search` (R2), and a structured planner rewrite per clue in place of
   pseudo-relevance expansion (R1). Then the whole coverage slice instead of one question, and the fan-out
   re-measured once the set tool exists. Remember the CUAD annotation caveat (§5.4).
5. **Phase 8 hardening:** stage budgets tuned from traces (`stage_ms` is in every eval row); tripwires with tests
   (under-fill: workspace < expected docs; duplicate flood; loop stall); prompt-cache the stable prefix; audit export
   (trace + bank + appendix, redaction hook); `notebooks/05_ablations.ipynb`; the never-measured acceptance
   criteria in §4 (malformed-call rate, router agreement against hand labels, grid time at 1,000 docs, the
   "spot-check one evidence id per Finding" mitigation).
6. **Long-context router branch** (`LC_small`): implement and compare on holistic questions with small candidate
   sets; find the break-even candidate size.
7. **Re-measure on the production models** (§7.8) once reachable.
8. **Open team decisions** (`PLAN.md`): #1 confirm production model ids, endpoints and `tools` support (the most
   important); #2 sandboxed `bash` tool; #3 is the ephemeral per-query BM25 acceptable under "no index"; #4 local
   embedder / reranker or an embedding endpoint (§9.2); #5 metadata in the body or a sidecar (both exist today);
   #6 report format (markdown + appendix today); #7 real analyst questions for the golden set.
9. Smaller items: the metadata LLM fallback (`ingest/metadata.py` stub) and its prompt; model-swap ablations;
   the `deepagents` spike for Approach 3; execute the notebooks (notebook 04 passes the runner's default
   concurrency 2 — change to 1 on the free tier); pin `ruff`; move the hard-coded limits listed in §2.6 into config;
   hash doc_ids relative to the docs directory (§6.7).
10. Housekeeping: rotate the NVIDIA key. Result files: delete `A1_deep_list-20261101-230745.*` (throttled, and its
    1.5 GB run folder), `-233218.*` (duplicate of the same 12 clean rows) and `-20261102-000043.*` (one throttled
    row); **keep** `-231543` (the 12 clean rows), `-234746` and `-20261102-000700` (cited by the README smoke
    table), `cuad6-*` and `cuad-cq077-*`. `.runs/` can be deleted.

---

## 9. Experiments to improve the system

Two deep-research reports were commissioned on 2026-11-02 and are in `docs/research/`:
`Architecture check against late-2026 evidence (Nov 2026).md` (is our approach the best way; in-constraint and
constraint-relaxing improvements; verification; novelty) and `Retrieval for paraphrased and reasoning-intensive
clauses (Nov 2026).md` (dense / hybrid retrieval, rerankers, negation, versions, with an embedding endpoint assumed
obtainable). Each ran 5 search angles over ~25 sources, extracted ~120 claims, adversarially verified the top 25 with a
3-vote panel and kept only survivors (17 and 15). Their conclusions are merged in §9.0; the per-claim evidence,
caveats and the lists of **refuted claims not to cite** are in the reports.

### 9.0 What the two research reports found (2026-11-02)
**Verdict on the design.** The architecture family is the best-evidenced one for deep research over a fixed document
set as of late 2026: materialized bounded workspace, grep/read agent, 1,000-deep BM25 list, clue-decomposition first
move. Same-model evidence: DCI 80.0 % vs 69.0 % with a dense tool; RISE matches DCI at a quarter of the cost; Pi-Serini
83.1 % with BM25 alone; Question's Gambit's first move 83.1 → 90.5 %. With the backbone fixed, the *interface* moves
accuracy more than the retriever (IndexAct: BM25 tool agent 30.5 %, dense tool agent 48.2 %, interface-centric agents
53–73.5 %). Every number is a single author-reported preprint on closed frontier models over a web corpus.

**In-constraint changes, ranked by expected gain per cost (architecture report):**
1. **Result sets with counts instead of passage text** (IndexAct, Oct 2026): search returns a handle, a count and
   per-doc counts; one flat-schema `set_op` tool does INTERSECT / UNION / DIFFERENCE / COUNT (keeps us at six tools);
   `read` is the only way text enters context. 73.5 % vs 62.7 % for the deep-list paging agent on the same nano model at
   ~14K live-context tokens; ablations: no set composition −12, binary feedback instead of counts −12, **auto-preview
   of text in search results cuts evidence coverage 63.9 → 52.5** (our `search` tool returns 240-character
   snippets). This is the in-constraint answer to enumeration without the 4× cost of fan-out; invariant 8 is
   supported. Open: an ephemeral per-query version over our BM25/grep hit sets with small models is untested.
2. **Replace the first move's pseudo-relevance expansion with one structured planner rewrite per clue** (defined
   terms, operative phrasing, party roles, synonyms), Rocchio-weighted, keeping only corpus-attested terms. In legal
   statutory retrieval one-shot rewriting with gpt-oss-120b lifted BM25 Recall@100 0.36 → 0.60 while TF-IDF PRF
   gave +0.01; HyDE + Rocchio with gpt-oss-20b beat naive concatenation by ~2 points. **Our current `expand_query`
   PRF is the heuristic that measured +0.01.**
3. **Two or three bounded rewriting rounds** inside the deadline (rounds 2–3 reached 0.52–0.55; ten rounds 0.67 at
   ~1,600 s, far outside the budget).
4. **Rerank the fused / expanded first-move top-100 listwise** with the planner model (window 20, step 10), or
   pointwise with reasoning off; never pointwise chain-of-thought (7B: 31.0 without vs 27.8 with). Zero-shot listwise
   reranking with our models is untested anywhere.
5. **Negation and conditions by reading, not ranking** (NevIR: only LLM rerankers reach 65–77 %; bi-encoders and
   most cross-encoders near random): retrieve the positive clause type per contract, let the extract grid decide
   present / absent with an explicit "not found after reading sections X–Y", compare thresholds in code.
6. **Enumeration retrieval per named contract** (fused top-k per contract), never one global top-k.
7. **Versions resolved in code**: TIDE shows dense RAG trailing gold-context reading by 4.4–12.4 points and models
   detecting a non-governing version only 26.7 % of the time even with gold text; build the amendment chain
   (effective date, supersedes, amends sections) at materialize time.
8. BM25 k1/b only on a held-out split; the Pi-Serini "+18 % from tuning" claim was refuted 0–3.

**Constraint-relaxing changes (both reports):**
- **Dense retrieval fused with BM25, never replacing it.** Zero-shot legal: tuned BM25 still wins top-rank precision
  (R@10 0.367 vs 0.325) while dense wins deep recall (R@500 0.734 vs 0.672); fusion helped in 82 % of 88
  configurations; a naive dense swap into RISE's search tool *lost* 9 points. Use dense as a recall expander for the
  deep list and as a grep scan-order prior (RARG++: 84 % vs 78 %, n = 100). Expected value +5–10 points on
  paraphrase-heavy retrieval, extrapolated from off-domain closed-model results.
- **Embedders:** best open-weight on the one surviving contract benchmark (MLEB Contractual, vendor-built, no BM25
  baseline) is **Qwen3-Embedding-4B 84.19 nDCG@10** (Voyage 3 Large 86.05; text-embedding-3-large 79.70; BGE-M3
  73.04). NVIDIA NIM embedders were evaluated nowhere.
- **Embed scoped subsets**: all chunks of the top-N BM25 documents plus all chunks of contracts named in the question,
  not 15,000 × 300 ≈ 4.5M tokens per query. A cross-query vector cache is a persistent index by another name and
  needs an explicit decision. Reranker latency on an A100 for 128 passages: MiniLM 44 ms, bge-reranker-v2-m3 410 ms.

**What the research could not answer** (nothing survived verification): citation verification and trust beyond the
four systems we built on, abstention, audit requirements; embedding cost and latency at ~15k chunks; contract
chunking and contextual prefixes; HyDE / Query2doc / per-query SPLADE; hosted rerankers on legal text; zero-shot CUAD
clause classification; production systems (Harvey, Hebbia, Bloomberg); FinanceHarness; IterResearch-style context
rebuilding; advisor patterns; long-context routing. The §9.1 offline benchmark and the experiments below are the only
way to know for our corpus.

**Claims in our own research record that the adversarial check refuted:** "inside an agentic loop BM25 becomes
competitive with dense" (BRIGHT-Pro, Appendix A.3.1, 0–3) and Pi-Serini's tuning/depth ablation (0–3). Do not lean on
them. Full refuted lists are in both reports.

**Novelty that survived scrutiny:** a per-query *ephemeral* set-algebra tool with small open models, a verbatim
evidence bank and contract enumeration (IndexAct exists only on a persistent Lucene index); the first move under 300 s
with small models and no hosted reranker; **expansion from corpus-attested terms seeded by evidence-bank spans or
structured clue fields rather than BM25's own top-k** (the closest published results are negative for BM25-seeded
expansion); dense-on-demand triggered by a deterministic recall signal. Not assessable from the literature found:
defect-driven self-correction with leftover time (§9.4), provenance-aware corroboration for amended contracts,
evidence-sufficiency stopping, grid + single-agent hybrids.

**Merged experiment list** (≥ 3 seeds each; the source papers' n = 100 gaps are within noise):
- **R1 paraphrase slice (offline, §9.1):** BM25 vs BM25 + PRF vs one-shot structured rewrite vs Rocchio-weighted rewrite
  vs 3-round rewrite vs dense vs fused — recall@100 / @500, gold-chunk rank, latency.
- **R2 set/count tool + no previews vs fan-out** on the 12 CUAD coverage questions — fixed item recall (§5.3),
  tokens, live context, calls.
- **R3 embedding latency and cost:** full corpus vs lexically scoped, endpoint vs local; seconds and dollars per query;
  recall lost by scoping.
- **R4 first-move reranker:** none vs listwise planner (low vs high effort) vs pointwise no-CoT vs local
  cross-encoder on the top-100 — gold-chunk recall@20, nDCG@10, seconds.
- **R5 negation / condition slice:** retrieval-only vs positive retrieval + per-contract grid — contract-set
  precision and recall, calls.
- **R6 enumeration and versions:** global vs per-contract top-k; code-resolved vs retrieval-only versions — item
  recall, version-resolution accuracy.
- **R7 BM25 k1/b sweep** on a held-out split of long contracts.
Track cost per correct answer across all of them.

### 9.1 First: an offline, model-free retrieval benchmark on CUAD
This needs no endpoint and answers the embedding question before any model is wired in.
- CUAD ships ~13k expert spans in 41 clause categories. For each annotated (contract, category) pair: query = the
  category name or its description (and, for the 112 golden questions, the question text); gold = the chunk(s)
  of `bm25.chunk_document` overlapping the span (offsets come from `data/cuad_docs/_alignment.json` and the
  generator in `scripts/make_cuad_golden.py`).
- Measure recall@k and MRR, **within a document** (what fan-out units and the extract grid need: is the gold
  chunk among the top 6 of that document?) and **corpus-wide** (what the first move needs), for: BM25 as built;
  BM25 + pseudo-relevance expansion; BM25 + a static synonym list per category; dense re-scoring of BM25
  candidates; RRF fusion; cross-encoder rerank.
- The paraphrase slice falls out by construction: spans that contain none of the category's keywords.
- Deterministic, minutes on CPU, run as a script under `scripts/` with a table written to `eval/README.md`.

**Decision rule** (write the numbers before running): adopt fused or dense retrieval for a stage only if
within-document recall@6 on paraphrase spans rises by an agreed margin (suggest ≥ 10 points), identifier spans
lose ≤ 1 point, and — once online — first-move p50 stays ≤ 30 s, CUAD coverage per-contract F1 improves,
identifier and temporal slices do not regress, and cost per correct answer is no more than ~20 % worse.

### 9.2 Dense retrieval and reranking (the embedding piece)
**Why.** The one observed retrieval failure (cq077) is consistent with vocabulary mismatch inside a known
document, and clause-category questions are expected to hit the same wall; a paraphrase slice has not been
measured yet (§9.1 does that). The research record puts a strong dense retriever at +14 points over BM25 on
BrowseComp-Plus single-shot and a textual reranker at +13.2 nDCG on visually rich PDFs (ViDoRe V3), but also finds
that *inside an agentic loop* retriever quality shows up mostly as fewer rounds and lower cost rather than final
accuracy (BRIGHT-Pro). Expect fewer tool calls, fewer forced submits and better coverage recall; measure cost per
correct answer, not only accuracy.

**Constraints and data rules.** Production has no embedding endpoint today, so this means a local model
(sentence-transformers; the `rerank` extra exists) or a newly provisioned endpoint, and the team's approval
(PLAN open decision 4; `TODO.md` 4). Settle: whether a per-query in-memory dense index is "an index" under the
no-index rule (same status as the ephemeral BM25); and that **per-document vectors kept across queries are a
persistent index** (cached model weights are fine; cached vectors are not, unless the team decides otherwise).
Hosted embedding models (NVIDIA Build lists `nvidia/nemotron-3.5-embed-1b`, `nvidia/nemotron-3.5-embed-8b`,
`nvidia/llama-nemotron-embed-vl-1b-v2`, `nvidia/nemotron-3-embed-1b`; they 404 on chat because they are embedding
models — probe `/v1/embeddings` and the reranker ids) may be used **only on public data (CUAD, synthetic)**; never
send production documents to a hosted endpoint.

**Where it plugs in** (existing seams; no framework classes change):
1. `tools/bm25.py` already chunks every document and exposes `ranking()` / `search()` / `expand_query()`. Add
   `tools/dense.py` with a `DenseIndex` over the *same* `Chunk` list (hits keep doc_id, lines, page) and
   `fuse(bm25_hits, dense_hits)` by reciprocal rank fusion. Numeric knobs in `ToolCaps` (`DENSE_TOP_K`, `RRF_K`);
   **model ids only via `llm.py`** (`get_embedder()` / `get_reranker()` reading `DR_EMBED_MODEL` /
   `DR_RERANK_MODEL`), which also fixes `rerank.py`'s hard-coded id (invariant 11).
2. First move: per clue, run the dense query alongside grep + BM25 in the same thread pool; fuse before the
   union; the opening observation and the cached deep ranking come from the fused list. The existing rerank hook
   runs only on the question-level ranking (`first_move.py:175`) and scores 240-character snippets — move it to
   the fused per-clue pools and score full chunks.
3. The `search` tool returns fused hits; `page_results` pages the fused ranking. Units already run with six
   tools and `registry.py` asserts ≤ 6, so **do not add a tool** — change what `search` returns.
4. Extract grid (`tools/extract.py::document_context`): choose the 6 chunks per document by fused score — the
   cheapest place to fix the cq077-type miss.
5. Fan-out briefings: a "search with the clause's synonyms" line in `prompts/fanout_researcher.md`.

**Budget reality.** CUAD is 15,155 chunks; first-move pools can reach 10 clues × (200 + 200 expanded) = 4,000
chunks; the first-move stage has 30 s in total and the planner call alone took 6–30 s. The throughput figures
below are **estimates, not measurements — benchmark on the target machine first** and give dense work its own
line in `StageBudgetsS`:
- *Dense re-scoring of lexical candidates*: embed only the BM25 top-k chunks per clue. Cheap, keeps the no-index
  property, catches paraphrases that share at least one anchor term with a clue. A base bi-encoder on CPU is
  thought to manage on the order of 100 chunks/s; a GPU makes this trivial.
- *Cross-encoder rerank* of the same candidates (start with the MiniLM-L6 already in `rerank.py` or
  `bge-reranker-base`; `bge-reranker-v2-m3` is ~568M parameters and likely single-digit pairs/s on CPU).
- *Full per-query dense index* only with a GPU or a sub-100-document candidate set; the one option that catches
  paraphrases sharing no term with any clue.
Candidate local models (verify licences and sizes): `Qwen3-Embedding-4B` (best open-weight on MLEB Contractual, §9.0), `Qwen3-Embedding-0.6B`, `BAAI/bge-base-en-v1.5`, `BAAI/bge-m3` (73.04 on MLEB Contractual, well behind Qwen3);
rerankers `BAAI/bge-reranker-base`, `BAAI/bge-reranker-v2-m3`, `Qwen3-Reranker-0.6B`. No fine-tuning (constraint).

**Variants to add** to `graph.py::VARIANTS`: `A1_hybrid` (fused search + first move), `A1_rerank` (cross-encoder in
the first move only), `A3_grid_dense` (dense chunk selection in the grid). Online metrics already in the runner,
plus the §9.1 offline table and the fixed coverage metric (§5.3).

### 9.3 Cheaper lexical experiments to run first (no approval needed)
- **Vocabulary expansion per clause category**: a static phrase list per CUAD category (non-compete: "shall not
  sell competing", "exclusive", "refrain from" …) used by clue decomposition, unit briefings and the grid.
- **Richer chunk prefixes**: chunks are already indexed as `title | heading` + body; add `doc_type`, parties and
  date (metadata is in the manifest). Zero model calls.
- **Metadata clue hints**: `list_docs` already filters by `doc_type`, `date_from`, `date_to`, `party_contains`
  (`TODO.md` 9); feed parties and dates from the question into first-move clues.
- **Structured planner rewrite per clue** instead of pseudo-relevance expansion (see §9.0 item 2): the PRF heuristic we
  run measured +0.01 Recall@100 in the one legal study that tested it; one-shot LLM rewriting measured +0.24.
- **BM25 parameters on a held-out split only** (Pi-Serini's k1 = 25, b = 1 is for web text, and the claim that tuning
  gave +18 % was refuted; do not copy blindly).

### 9.4 Self-correction round with leftover time (`TODO.md` 10)
Single-answer questions finish in 50–90 s of the 300 s budget, and after verification the report carries
deterministic defect signals: `[GAP]` lines, tier-1 drops, tier-2 unsupported / partially, forced or
low-confidence submits. If `deadline − now − RESERVE` exceeds a threshold (say 60 s), turn each defect into a
repair task ("find evidence for <gap>", "find the correct source for <dropped claim>", "confirm <term> is
absent"), run them as scoped researcher units (the fan-out `run_units` machinery: small call budget, injected
doc_ids = first-move candidates or the cited documents, deadline = remaining time), append to the same bank,
redraft only the affected sections, re-verify. One round, bounded; the pre-correction report is kept if the
rewrite fails or adds nothing. Cheaper variant: run the repair tasks *before* drafting when the outline
assignment leaves sections empty (the breadth branch's `gap_check` + gap round is already this shape).
Why it is safe here: the defect signals are deterministic or already paid for, which is what unconstrained
reflect-retry loops lack (Glean "not yet reliable"; General-AgentBench: more turns do not help without a
verifier). Plug-in: `graph.py` node `correct` after `verify` (or before `write`); config
`CORRECT_MIN_REMAINING_S`, `CORRECT_MAX_TASKS`, `CORRECT_CALLS_PER_TASK`, `CORRECT_ROUNDS_MAX=1`; `draft_section`
already drafts one section. Measure on the smoke set: judge pass, gap rate, support, gate failures before vs
after; extra wall-clock and tokens; how often the round fires and how often it changes the verdict. Guard rails:
never past the deadline; tier 1 still gates every new claim; a round that adds no evidence leaves the report
untouched.

### 9.5 Other experiments, each with a measurement
- **Markov researcher context** (`A2_markov`): rebuild the researcher's context each turn from question +
  evidence summary + last tool result (IterResearch, Stateless Language Agents). Measure tokens per correct and
  drift; the 60K compaction cap and 164k tokens p50 say the transcript is the cost driver.
- **Tool-result projection** (`TODO.md` 2): keep large grep/read outputs as files and show counts, previews and
  pointers (Scroll); partly built as offload — measure tokens per question with a lower `OFFLOAD_TOKENS`.
- **Advisor pattern** (`A2_advisor`): Lightning as the executor consulting Super ≤ 3 times. Accuracy and cost
  against the Super-only loop; also a way around the 120B endpoint's throttling.
- **INDEXACT-style counts and set algebra** (`TODO.md` 3) over the ephemeral index for corpus-wide questions.
- **Search-as-Code** (`TODO.md` 5): the agent writes a short retrieval script over grep/BM25/filter primitives;
  needs the sandboxed-bash decision.
- **Parallel rollouts + aggregator** (`TODO.md` 8): now eligible since tier 2 exists; K independent runs merged
  by an aggregator with tier 1/2 as the selector.
- **`deepagents` as the Approach 3 runtime** (`TODO.md` 1): validate the `task` hand-off with these models first.
- **Long-context branch** (`LC_small`, `TODO.md` 7).
- **Budgets from traces:** tune `StageBudgetsS` and the 6–25 call range per question type.
- **Tier-2 sampling rate and verifier model:** 0 / 20 / 100 % of clean claims; Super vs Lightning on the seeded
  check.
- **Provenance thresholds on real documents:** run `cluster_all` over CUAD (§7.9) and inspect clusters before
  trusting 0.95 / 0.8 there.
- **Judge reliability:** spot-check 20 verdicts against gold spans; raise the 12K cap (§5.3).
- **Scale test to 1,000+ documents:** duplicate CUAD with perturbed metadata or extend the synthetic generator.
- **Real analyst questions:** the golden sets are developer-written ("too easy" per the research record).
- **Per-endpoint in-flight semaphore** instead of eval `--concurrency 1` on the free tier.

---

## 10. Documents to keep in sync
`docs/findings.md` (append after every run) ·
`eval/README.md` (tables) · `PLAN.md` (checkboxes and side notes) · `prompts/README.md` ·
`docs/architecture.md` (status block) · `docs/endpoints.md` (dated notes; back it up before running the probe) ·
`.env.example` (dated calibration comments; never the key) · `README.md` (status block) · this file.

---

## Appendix A — Research record (October 2026)

Unchanged from the original handover apart from two decision-trail rows; renumbered. These are the sources and
numbers behind every design decision in §2. Consult them instead of re-deriving arguments.

## A.1 How we got here — decision trail

| Date | Question asked | Outcome |
|---|---|---|
| Oct 21 | *"Metadata filter + vector search to a subset, then pass all docs to an agent — good approach?"* | Deep research (5 threads, 120+ sources) → **report 1**. Verdict: the narrowing stage is right and is the binding constraint; handing the whole subset to one long-context pass is the weak half (context rot, similar-document distractors, no iteration, cost). Recommend hybrid+rerank narrowing → iterative tool-calling agent with search/fetch/grep tools, context-isolated sub-agents, two-tier citation verification. |
| Oct 25 | *"Suggest POC approaches given LangChain/LlamaIndex/ADK, a few thousand PDFs, Jupyter, 500–1,000 filtered docs, 5-min budget"* | Five approaches sketched (single agent; plan→parallel researchers; corpus map; materialized working set + grep; long-context router). |
| Oct 25 | *"Will sub-agents help?"* | Yes for context isolation and breadth; the gain is from isolation + parallelism, not the agent abstraction; hand-offs are the new failure point; 3–10× tokens; use as a planner-selected branch. |
| Oct 25 | *"Recent research like Librarian Agents?"* | Assessed arXiv 2610.22273: promising for *stable, repeatedly-queried partitions*; needs RL (prompted builder scores below flat retrieval); no update mechanism; small-corpus eval. Deferred (TODO). |
| Oct 25 | *"What's SOTA, and is it different from what you suggested?"* | Second research pass (3 threads, 76 sources) → **report 2**. SOTA is a *training-free harness over a frontier model*, simpler and more retrieval-heavy than my first recommendation: deep candidate list + full-document reads + single loop + first-move decomposition + outline-first fact-bound writing + two-tier verification. Nine concrete changes; explicit keep list. |
| Oct 27 | *"Top-3 architectures for a meeting"*; *"What are RISE/DCI/materialized working set?"*; *"Do we need to index the 500–1,000 docs?"*; *"What if we have no index and don't want one?"*; *"Compare and pick"* | Index-free design *is* the strongest-evidence regime at this set size. **Chosen: Approach 2 (materialized working set + filesystem agent) as the tool layer, Approach 1's loop (deep list + first move) on top, Approach 3 (fan-out) as a planner-selected breadth branch.** |
| Nov 1 | *"Start an implementation plan in Claude Code; only Gemma/Nemotron Nano/GPT-OSS; markdown + metadata exist; implement the 3 approaches one by one; which frameworks?; add deepagents + harness engineering to TODO"* | This repository: `CLAUDE.md`, `PLAN.md`, `TODO.md`, tested foundation, stubs. Frameworks: LangGraph + langchain-core suffice; LlamaIndex optional. |
| Nov 1 | Implementation: Phases 0-7 built and live-tested on NVIDIA Build free-tier substitutes for the intended models; synthetic golden set (31 docs / 42 q) and CUAD (510 contracts / 112 q); eval runner with 7 variants; thinking disabled for every role after an A/B (3/6 -> 5/6); fan-out iterated 4x on one coverage question; tier 2 + provenance gate with a 10/10 seeded check. | §6-§9 of this file; `docs/findings.md` |
| Nov 1-2 | *"Full CUAD run"*, *"keep a small working test set"* | Free endpoint throttling (HTTP 429, then per-request load shedding) stopped the full pass after 14 questions and three smoke-set attempts; pacing, short exponential retries and resume added; evals now run at concurrency 1; the three-way measurement is the first pending item (§8). | §5.6, §6 |

---

## A.2 Research record, part A — agentic retrieval at million-document scale (report 1, Oct 21 2026)

Full text: `docs/research/Agentic retrieval at million doc scale.md`.

### A.2.1 The retriever, not the reasoner, sets the ceiling at scale
- **BrowseComp-Plus** (fixed 100,195-doc corpus, ACL 2026): swapping BM25 → Qwen3-Embed-8B moved GPT-5 **55.9 → 70.1%**, o3 49.3 → 63.5, and more than doubled Claude Sonnet 4 / Opus 4 (14–16 → 36–37%). Oracle (gold docs given) GPT-4.1 **93.5%** vs 14.6% with BM25 top-5. Reranking top-20 moved GPT-4.1 35.4 → 47.1.
- Scale amplifies it: growing the corpus ~100× to 9.77M docs cut evidence recall@5 14.5 → 11.6; projecting the same questions onto **553M docs** collapsed evidence recall **84.3 → 21.4%** and raised search calls 63% ("projection shifts the difficulty onto retrieval").
- Enterprise corroboration: Salesforce **HERB** — same model 76.55 with product-scoped long context vs 41.86 scoped RAG vs 32.96 full-corpus ReAct; "retrieval is the main bottleneck". Exa **ATLAS**: search backend alone shifts scores up to 16%.

### A.2.2 Why "hand the whole subset to one pass" fails
- **Context rot.** NoLiMa (ICML 2025): at 32K tokens GPT-4o 99.3 → 69.7%, Claude 3.5 Sonnet 87.6 → 29.8%; effective length (≥85% of baseline) 8K / 4K. Chroma (18 models incl. Opus 4, GPT-4.1, Gemini 2.5 Pro): performance declines with length in every experiment; a ~300-token focused prompt beat the ~113K full prompt for every model. Databricks (2,000 runs): retrieval recall rose 0.47@2K → 0.95@128K but Claude 3.5 Sonnet answer quality *peaked at 32K* (0.748) and fell to 0.706 at 125K.
- **Multi-hop is the fragile case and topically-similar docs are the worst distractors.** Padding a 256-token window to 2,048 dropped GPT-4.1 HotpotQA EM 0.575 → 0.305 while SQuAD fell only 0.635 → 0.570 (small sample). Separating two gold docs among 20 cost up to 15 points on MuSiQue (56.2 vs 41.2). NoisyBench: hard negatives cut Gemini-2.5-Pro ~38% vs ~9% for random docs; *agentic workflows did worse than base models under noise*. A vector-search subset is by construction a pile of topically similar documents.
- **One retrieval forfeits the lever that moves accuracy most.** Same retriever and corpus: Search-R1 0.304 → 0.384 EM; FrugalRAG HotpotQA 51.0 → 64.2 with 2.76 searches; FLARE 2Wiki 39.4 → 51.0; IRCoT up to +15. Frontier agents that succeed on BC+ make ~22 calls; raising gpt-oss-120b reasoning effort low → high: 24.9 → 42.9% as calls went 2 → 18. Anthropic: token usage explained 80% of BrowseComp variance.
- **Economics.** 1M-token uncached prompt ≈ $2 (Sonnet 5.5), $4 (Opus 5.5), $10 (Fable 5.1), $4 (Gemini 3.1 Pro, 2× above 200K). Prompt caching does not help a per-query-varying subset. Anthropic's compaction defaults (150K trigger, 100K tool clearing) assume you don't run there; compaction preserved 3/3 high-level facts but **0/3 obscure table values**.

### A.2.3 Where a long-context pass still wins (kept as a router branch)
- LC vs RAG (13,628 questions, ≤ ~67K tokens): LC **56.3 vs 49.0%** on dense self-contained sources; ~9.5% of questions RAG-only. Self-Route: LC ahead by 7.6–13.1% but routing to LC only when RAG says "unanswerable" cut cost 39–65% at ≤ 2.2-pt loss. SurfSense (30 long PDFs): LC 59.6% / $0.19 / 6.8 s vs agentic RAG 53.2% / $0.08 / 52.8 s. Anthropic: knowledge bases < ~200K tokens should skip RAG.
- Rule: pre-load only when the filtered evidence is **tens of thousands of tokens (< ~128K), clean, and the question is holistic**. None of the pro-LC results covers hundreds of docs at 500K–1M.

### A.2.4 The narrowing stack (applies to the *upstream* filter and to any future index)
- **Hybrid > dense-only.** Elastic: RRF(BM25+ELSER) +18% nDCG@10 over BM25, +1.4% over ELSER; Waterloo SIGIR 2026 on BRIGHT: fusion +1.1 Recall@100 (recall is what a narrowing stage needs). Lexical is non-negotiable for identifiers (embedders fragment "AB-4471-X"); inside an agentic loop BM25 rose from last to 51.5 α-nDCG@15 (BRIGHT-Pro) because follow-up queries carry keywords. Learned sparse (SPLADE-v3, ELSER, BGE-M3) beats BM25 where supported (MIRACL 31.9 vs 53.9–74.0).
- **Filtered ANN is a silent recall hazard** — the most important fact about a metadata-filter stage over a vector index. Qdrant (1M vectors): plain HNSW recall@10 at 20% pass → 62.9%; 10% → 20.6%; **1% → 0.1%**; AND filter at 4% → 0.1%; **latency unchanged at 1.6 ms**, so no error signal. Fixes: payload indexes on every filterable field; partition on hard constraints; ACORN-style traversal (95.2% at 3–7× latency); **exact search below ~1–5% selectivity** (99.9–100%, 1.3 ms over a 0.012% subset). pgvector < 0.8 returned ~4 of 10 rows at 10% selectivity. *Measure recall against exact search per selectivity band.*
- **Rerank a wide pool to a narrow one.** Anthropic contextual retrieval: top-20 failure 5.7% → 3.7% (contextual embeddings) → 2.9% (+contextual BM25) → **1.9%** (+rerank top-150 → 20). BC+: rerank top-100 lifted recall@5 14.5 → 29.5–35.0. A weak reranker can hurt a strong first stage (−1.2). Hosted cross-encoders ≈ $2–2.5 / 1,000 searches of 100 docs, 130–200 ms.
- **Recall ceiling:** E[NDCG@k] ≤ Recall@|window|; first-stage pool 100–1,000, agent-facing k 20–30; per-call plateau at k≈8 (SMTL 43.8 → 47.0 for k 4 → 8, flat after). Widen the pool, not the agent-facing k.
- **Chunking:** 300–500-token chunks with document title / section prefix (contextual retrieval ≈ $1.02 / 1M doc tokens one-time); 64–128 tokens for factoids, 512–1,024 for dispersed answers; 4-bit quantization costs ~2 pts for 8× memory; multi-vector needed for AND-of-OR queries.

### A.2.5 The reasoning stage: tools, loops, isolation
- Every production deep-research system (Anthropic, OpenAI, Google, Microsoft) is an iterative tool-calling loop; none pre-loads a fixed subset. OpenAI's deep research API accepts private corpora only via MCP `search` + `fetch` with `max_tool_calls` as the cost lever. Azure agentic retrieval = LLM query planning → parallel filtered hybrid sub-queries → semantic rerank → merge, `auto` effort escalates only when grounding is insufficient. Databricks IR-1: trained retriever matches Sonnet 4.5 (81.0 vs 80.1) but >3× faster — latency motivation, reproducible by prompting.
- **Tool surface:** `search(query, filters, k)` → compact hits with stable IDs; `fetch(id, section)`; exact-match `grep`; list/metadata tools; hard caps (Claude Code caps tool results at 25K tokens). Interact-RAG primitives +9.7 EM over black-box search; **A-RAG** (`keyword_search` + sentence `semantic_search` + `chunk_read` with a read tracker) lifted GPT-5-mini MuSiQue 52.8 → 74.1, 2Wiki 50.2 → 89.7 at ~same tokens — *multi-granularity tools exposed to an agent gain +13–40; multi-granularity indexes queried once gain ~0* (LlamaIndex auto-merging 52.5% preference).
- **Isolation and parallelism:** Anthropic multi-agent **+90.2%** over single Opus 4 at ~15× tokens (Jan 2026 guidance: typical 3–10×, often slower; justified for context pressure, 15–20+ tools, or parallel subtasks). Sub-agents return 1–2K-token distillations; the orchestrator never sees raw docs. IterResearch's Markovian workspace **+12.6 pts** with 40K vs 64K context; turns 2 → 2,048 within 40K: 3.5 → 42.5%. SMTL single agent ~3.5 parallel calls/step: 44.6% in 60 steps vs 41.2% in 206. **InfiAgent** file-workspace + "external attention" sub-agents: 80.0 coverage on an 80-paper review vs 29.1 for Claude Code; compressed long context collapsed to 3.2–27.7 — the closest analogue to "read many documents for research" and it argues *against* a single compressed context.
- **Bound the loop:** Glean's unconstrained reflect-retry loop was "not yet reliable"; LangGraph's tutorial shipped an infinite loop; gains plateau ~3 searches on simple QA (54.5 → 71.1) but frontier deep research needs 20+. Tool-result clearing cut 128.7K → 43.1K losslessly; programmatic tool calling −37% tokens.
- **Sub-agent hand-offs fail silently:** the one controlled study (repo QA, 720 q × 4 models): deep-agentic 46.2% vs retrieval-first 65.2%, 2.3× cost, **41.8% of failures at the planner→sub-agent hand-off, 91% of those fluent and confident**. Schema-validate returns; spot-check.
- Anthropic's endorsed hybrid for "legal or finance work": small stable context up front (corpus map, schema, summaries index) + just-in-time retrieval. LongRAG grouping to ~4K-token units: NQ AR@1 52 → 72%. Do **not** pre-summarize for a frontier reader (−16.6 pts) but *do* use summaries as a retrieval index (RAPTOR-style 38.5 vs ~21%).

### A.2.6 Non-graph index layers (measured gains and costs)
| Layer | Gain | Cost | Verdict |
|---|---|---|---|
| Contextual chunk prefixes | failure 5.7 → 2.9% (1.9 w/ rerank) | ≈$1.02/M doc tokens | cheapest proven win (needs an index) |
| Late chunking | nDCG up on every BEIR set tested | one long-context embed pass | alternative to above |
| Precomputed fact index (Elastic) | calls 33 → 9, tokens −71%, 213 → 64 s | ~636K tokens precompute | vendor, one task |
| Cluster → skill navigation (Corpus2Skill) | F1 0.460 vs 0.363 dense | $5–10 build; **21× query cost**; 38/62 failures = wrong branch | optional |
| LLM-navigated tree (LATTICE) | BRIGHT 46.7 ≈ fine-tuned ensembles | ~6 h/100K docs; $0.003–0.38/q; −9–13 on dynamic corpora | not for us |
| RAPTOR | beats flat per-doc; **"drops sharply" at corpus scale** (36.7 vs 62.8) | | no |
| PageIndex | 98.7% FinanceBench *vendor, single-doc*; "works best with a small number of documents" | ~24.6K tokens/q | per-doc navigation only |
| **Filesystem grep over materialized working set (RISE)** | **83% at 1M docs, flat vs 100K** | $0.05–1.25/q | **chosen** |
| Raw grep over whole corpus (DCI) | 68.5 vs 47.0 nDCG@10; 80% BC+ at 100K | −13.6 at 200K; 37.5% at 400K | needs the pre-filter we already have |

### A.2.7 Evaluation and failure modes
- **Three recalls:** candidate recall@N (ceiling), post-rerank recall@k, **agent-trajectory recall** (gold ∩ docs actually opened/cited). DCI's diagnostic: dense had 2× coverage (56.7 vs 28.0) yet −28 accuracy because localization was half (21.7 vs 48.4) — *coverage alone misleads*.
- **Filtered-ANN recall vs exact** per selectivity band; filter precision 1.0; fill rate; cross-tenant 0. LLM filter generation F1 0.99 easy → 0.37–0.45 hard, with silent fallback to unfiltered.
- **Golden set:** real user questions (developer-written are "too easy"); include exact-identifier, multi-source, conflicting, **not-in-corpus ≥ 10–15%**, temporal; label at doc + page; κ ≥ 0.60. Anthropic started with ~20 real queries. DRBench: agents avoid distractors (93–97%) but recall only 37–42% of injected insights.
- **Citations:** 21% (OpenAI) – 27% (Gemini) of deep-research statements unsupported (ReportBench); 3–13% of URLs never existed; FINDER taxonomy 38.8% generation / 33.1% retrieval / 28.1% reasoning, "strategic fabrication" 19%. Two tiers: structural on 100% + semantic on a sample (0.98 vs 0.71 gap). **Bloomberg EvidenT** (extract verbatim → n-gram align → generate from verified only): hallucinated citations 18–31% → **0%**, groundedness 73 → 93%.
- **Cost anchors:** BC+ $0.43–2.46/q at 9–26 calls; enterprise agentic 107 s / 764K tokens vs 0.67 s single-shot for +8.7 nDCG; ATLAS best $8.92 / 18 min; multi-agent 3–15× tokens.
- **Silent failures to design against:** filtered ANN under-fill; filter fallback to unfiltered; near-duplicate flood ("top-5 was secretly a top-2 for a month"); sub-agent hand-offs; ~60% of hallucinations in three FS deployments traced to unhandled errors / empty results surfacing as confident answers. Loop pathologies: over-search 20–28% of steps; under-search 34–63%; forgetting is the strongest predictor of low scores (coef −0.843). Temporal: models detected a non-governing version only **26.7%** of the time (TIDE); 68.5% even with gold docs. Calibration error 91% for Deep Research; give judges an "Unknown" option.

---

## A.3 Research record, part B — state of the art for deep research over private corpora (report 2, Oct 25 2026)

Full text: `docs/research/Deep research SOTA for private corpora.md`.

### A.3.1 Leaderboard SOTA (fixed corpus): training-free harnesses over untrained models
**BrowseComp-Plus official leaderboard (86 entries, fetched Oct 25 2026):** ranks 1–18 are all training-free.
| Entry | Acc. | Calls/q | Notes |
|---|---|---|---|
| GPT-5 + AI21 hybrid dense/late-interaction + **8-agent** scaffold | **95.18** | **209** | no cost published |
| GLM-5.1 (open weights) + hybrid BM25+Qwen3-Embed-8B swarm | 90.72 | 12.5 | |
| GPT-5 + Mixedbread Search v3 + `get_document` | 90.48 | 11.5 | |
| GPT-5.5 + tuned BM25 + **Question's Gambit** | 90.48 | 33.7 | highest recall 96.58 |
| Best RL-trained specialist (Tongyi-DR-30B) | 68.07 | | level with untrained gpt-oss-120b on same retriever |
| Claude Sonnet 4 / Opus 4 (Aug 2025 rows) | ~37 | | no Claude 4.6+ / Gemini 3.x entries exist |

Decomposition: GPT-5 57.6% (BM25 top-5 snippets) → 71.7% (Qwen3-Embed-8B) → 86–90% (any modern retriever **+ get_doc**) → 95.2% (+8 agents). Retriever +14, full-document access +15–19, fan-out +4.7 at ~17× calls.

**The recipe behind the single-agent frontier:**
- **Pi-Serini** (Waterloo, May 2026): Anserini BM25 tuned **k1 = 25, b = 1**, **depth 1,000** cached, `search` shows top 5, `read_search_results` pages, line-chunked `read_document`; plain ReAct, **300 s timeout**, 82–90% prefix-cached. gpt-5.5: **83.1%**, 94.7% surfaced recall, 19.3 calls, ≈ **$0.35/q**. BM25 tuning alone 64 → 82 (subset); **k 5 → 100 → 1,000 lifted surfaced recall 70.5 → 86.2 → 95.8%**. Claude Opus 4.7: 69.8% using only **9 calls** (under-search, not reading failure).
- **Question's Gambit** (Sept 2026): one-shot first move — decompose into ~9.6 clues → per-clue BM25 → 3-doc feedback expansion → top-1,000 each → union ~2,500 → **Cohere Rerank 4 Pro on full text** → top-5 opening observation. gpt-5.5 83.1 → **90.5%**; gpt-5.4-mini 68.1 → 79.0; gold recall → **98.1%**; calibration error 15.7 → 7.58; ≈ **$0.05 and 28.5 s**.
- **DCI — Direct Corpus Interaction** (May 2026, NeurIPS spotlight): Claude Sonnet 4.6 in Claude Code with grep/read/bash over raw text, no index: **80.0% ($1,016 total) vs 69.0% ($1,440)** for the same model with a dense tool. "Open bash" 73 vs "read + grep" 61. Does not scale: −13.6 pts and 2× calls 100K → 200K docs; 37.5% at 400K.
- **RISE** (June 2026): BM25 materializes the **top-1,000 docs per sub-query into a per-query working directory**; agent greps/reads by line range; offline **$0.0014/doc** LLM table-of-contents. gpt-5.4-mini **78% at $0.28/q** (DCI 78% at $1.10); gpt-5.4 82%; **at 1M docs 81–83%**, flat vs 100K, while pure DCI fell to 60%. K from 100 to 10,000 barely matters; TOC worth +1–4.
- **INDEXACT** (Oct 2026): set algebra over a Lucene inverted index (FILTER / INTERSECT / UNION / **COUNT** / RANK / TOPK); text enters only via READ; `submit` requires evidence IDs. GPT-5.4-**nano**: **73.5%** at ~14K live tokens; **70–74% flat from 100K → 800K docs**. Ablations: binary instead of count feedback **−12**; no persistent state **−8**; no set composition **−12**; auto-attached snippets **−4**.
- **BRIGHT / BRIGHT-Pro:** static leaderboard led by undisclosed trained retrievers (66.9, 63.4); but inside an agentic loop BM25 rises 40.3 → 51.5 α-nDCG@15 and final-answer quality spans only 4.12–4.31/5 across retrievers — *retriever quality shows up as rounds/cost, not final answer, when the agent can iterate*. DCI 68.5 vs ReasonRank-32B 47.0 is the top training-free number.
- **Librarian Agents** (arXiv 2610.22273, Oct 15 2026) — builder agent organizes a corpus into a hierarchical filesystem of synthetic summary files before queries arrive; answering agent navigates it. **Caveats:** 0.75–0.77 "BrowseComp-Plus" is on *small per-task doc sets with 4B / Flash-Lite answerers*, not the 100K corpus; **prompted (no-RL) builder scores 0.28, below a plain reranker's 0.44**; GraphRAG baseline 0.36; break-even ≈ 31 queries per corpus; no update mechanism; flattened filesystem (57.70) beat the learned hierarchy (55.86) — *semantic placement matters, depth does not*. Deferred to TODO.

### A.3.2 Report-quality SOTA: writing protocol and grounding, not orchestration
- DeepResearch Bench leaderboard is unreliable for us (undisclosed vendors on top, FACT columns blank, a vendor self-report disagreeing with the official CSV). Disclosed training-free pipelines all land ~50 (WebWeaver/Sonnet 4 50.58, RhinoInsight 50.92, Enterprise DR 49.86) — tied with an RL-trained 8B. FutureSearch's independent harness (June 2026): Claude Opus 4.6 0.553 ($0.53, ~3 min), Sonnet 4.6 0.549, GPT-5.5 0.540 ($0.36), Gemini 3.1 Pro 0.478. Rubric recall is where differentiation lives (DRB II: < 50% rubrics satisfied by the best).
- **WebWeaver** (ICLR 2026, training-free): evidence bank keyed by ID; outline sections tagged with the IDs they draw on; write section-by-section retrieving only that section's evidence, then prune. vs whole-bank writing: **citation accuracy 86.7 → 93.4%**, support 91.0 → 98.7, insight 42.7 → 50.0.
- **ScaffoldAgent** (Jun/Aug 2026): outline as a decision process with Expansion / Contraction / Revision ops, utility-gated; **+3.4–4.8 RACE over WebWeaver at 26.3K tokens / 8.2 calls / 116.7 s** per report (vs 37.2K / 15.9 / 148.5 s); expansion-only never terminates (−6.5); editing the outline for follow-ups 72.6 vs 59.7 for a rewrite.
- **ClaimWriter** (Salesforce, Aug 2026, GPT-5.5 writer): outline **from the query alone before seeing evidence**; extract self-contained facts; assign each to one section; draft with `{{CITE:fN}}` markers; resolve at assembly. **Claim-level hallucination 15.89 → 5.02 per 100 claims**, misattribution 18.94 → 5.43, necessary-fact recall 36.83 → 45.85, RACE cost ≤ 1.8.

### A.3.3 Enterprise benchmarks: harness > training; retrieval/grounding is the ceiling
- **DRBench** (ICLR 2026, enterprise files + apps + distractors): best = OpenAI Deep Research on GPT-5: insight recall **41.96**, factuality 83.64, HM 70.35; no system > 42% insight recall; GPT-4o → GPT-5 backbone swap nearly doubled HM (34.8 → 63.8) vs +4.9 for the best planning variant; browser-only agent 1.1%.
- **FinanceHarness** (Google Cloud / UCLA, Aug 2026; 100M+ articles, FAISS, date filters): layered training-free harness took Qwen3.6-27B **25.3 → 32.4**, within 1.7 of Claude Opus 4.7 (34.1), ahead of GPT-5.5 (31.8), deepagents (28.1), MiroThinker (21.2); **GRPO fine-tuning added +0.4**.
- **BigFinanceBench** (Rogo, 928 expert items): best 58.8% rubric / 41–44% final answer; failures concentrated in *choosing the right filing, period, or accounting treatment* — retrieval, not arithmetic.
- **Harvey LAB-AA v1.1** (Oct 2026, hallucination-gated, 120 private legal tasks): best all-pass **13.1%**; Claude Opus 5.5 4.2%. **Vals Finance Agent v2** (Oct 20 2026): Gemini 4 Argon 65.4%, Claude Fable 5.1 58.9%.

### A.3.4 Verification SOTA
- **EvidenT** (Sept 2026, ~500 real enterprise queries): deterministic gate — LLM extracts verbatim passages → 5-gram alignment at 0.7 keeps / truncates / drops against the cited doc → zero-overlap passages trigger a search of other retrieved docs → generate only from verified passages. Gold-source hit **73 → 93%**; citations to non-retrieved sources 18–54% → **≤ 0.6%**; ~2 s overhead. (Validated on LLaMA 8B/70B — relevant to our small models.)
- **DeepFact-Eval**: agentic claim verifier **83.4% (GPT-4.1) / 87.2% (GPT-5) vs 58.5%** for the best traditional checker; $1.16/claim, or **$0.21–0.30 when 5–10 related claims are verified together** (−5–7 pts); unassisted PhD experts 60.8%.
- **Sauron** (Oct 2026): per-criterion evidence receipts against environment state; F1 0.96, 23% cheaper, 97% injected-failure detection, 2% false flags.
- **CiteAudit**: LLM-only citation audits are unreliable (F1 0.33–0.57 for GPT-5.2 / Claude / Gemini vs 0.84 tool-grounded). **Evidence laundering** (EMNLP 2026): agents treat paraphrased, correlated sources as independent confirmation; a structural provenance gate "substantially reduces" it. Near-duplicate drafts/amendments make this *the* characteristic hazard of a document corpus.

### A.3.5 Production SOTA (finance/legal vendors and hyperscalers)
- **Hebbia Matrix:** orchestrator that "never directly invokes any tools" dispatching to sub-agents (read-matrix, retrieval, output); the product is a **grid** running the model over every selected document (rows × columns), "processes full documents rather than excerpts"; 92% vs 68% out-of-box RAG (vendor-run).
- **Harvey:** ReAct loop with a completeness check; early versions made 1–2 calls regardless of complexity and were tuned to **3–10 retrieval operations**, tool-selection precision ~0 → 0.8–0.9; source onboarding **auto-rejects hallucinated citations**.
- **Hyperscalers:** Azure agentic retrieval (planning → parallel hybrid sub-queries → rerank; answer synthesis still *preview* in Sept 2026), AWS Bedrock Managed Knowledge Base GA (June 2026), Databricks IR-1 — all push iteration into a bounded retrieval call. **Perplexity Search-as-Code** (June 2026): the model writes a short script composing retrieve/fan-out/filter/dedupe/rerank primitives; ~85% fewer tokens (vendor). Vespa: "agents should write YQL". INDEXACT is the academic version with numbers.
- **Frontier harness features now commodity:** Anthropic server-side compaction (`compact-2026-09-04`), context editing, memory tool, `effort` parameter; **advisor pattern** (Haiku executor consulting Opus ≤ 3×): BrowseComp 19.7 → 41.2% at −85% cost vs Sonnet solo. OpenAI: Responses compaction, deep research via MCP `search`+`fetch`, Agents API (Sept 10 2026) with isolated sub-agents.
- **Context management research (Jul–Oct 2026):** **Scroll** — append-only event log + persistent Python kernel; only printed projections enter context; BEAM-10M 73.1 vs 68.0 best; **lossy summarization at ingest collapsed it to 19.9**. **Stateless Language Agents** — harness rebuilds a fresh role-specific context per call; matches best baseline with **84–93% fewer tokens**; removing worker isolation −43–75% progress (code tasks only). **W&D**: a single agent told to issue 3 parallel calls/turn: 66 → 68% at **−35.9% cost, −40.6% wall-clock**; 74% with a wide-then-narrow schedule; the width instruction works better as a per-turn user message. **InfoSeeker**: hierarchy lifts WideSearch Item-F1 35.74 → 70.27 (breadth), success only 6.0 → 8.4%. Anthropic (Jan 2026): multi-agent 3–10× tokens, "coordination costs typically exceed the benefits" outside parallelizable work.

### A.3.6 Verdict on the first recommendation (report 2, §4) — condensed
| Element | Verdict |
|---|---|
| Filter → 500–1,000 candidates; hybrid lexical+dense; filter-aware ANN; search/fetch/grep tools; one gap round; wall-clock deadline; sub-agent contract; eval recalls; Librarian deferred | **Matches SOTA** |
| Rerank to 20–30 as the agent's view | **Behind** → page a 1,000-deep list + `read_document`; reranker moves to the first move |
| No first-move decomposition | **Behind** → Question's Gambit (+5.5–10.9) |
| Notes → report | **Behind** → outline-first, fact-bound writing |
| String-match verification only | **Partially behind** → keep as tier 1; add grouped agentic tier 2 + provenance gate |
| 100–150K working context + compaction | **Partially behind** → harness-owned state; compaction as safety net |
| RISE-style materialized directory "optional" | **Behind** → primary |
| Plan → parallel sub-agents as default | **Over-built** → single agent with parallel tool calls by default; fan-out for breadth only |
| Filter-aware ANN safeguards; document cards / cluster map optional; LC router optional | **Ahead / more conservative — keep** |

### A.3.7 Evidence-quality caveats (carry these into any decision)
Vendor-run: Hebbia 68 → 92, Harvey 0.2% hallucination, IR-1 parity, Perplexity SaC, Kimi swarm, Elastic context engine, AI21 95.18 (no cost). Internal/unreplicated: Anthropic +90.2% / +29% / +39%. Non-comparable: Librarian BC+ numbers (per-task sets); DRB top-10 (undisclosed). Not run on PDFs or enterprise documents: **DCI, RISE, INDEXACT, Pi-Serini** — all on clean web text; ViDoRe V3 puts BM25 alone at 20.3 vs 59.8 nDCG@10 on visually rich finance/energy/pharma PDFs with a textual reranker worth +13.2, so **extraction quality may matter more here than in the papers**. Small-model results exist (INDEXACT nano 73.5; RISE gpt-5.4-mini 78; FinanceHarness 27B 32.4; EvidenT 8B/70B) but none with Gemma / Nemotron Nano / GPT-OSS specifically. No system combines all of the changes end-to-end on a private PDF corpus.

---

## A.4 SOTA methods catalog — reference table

| Method (source, date) | What it is | Key number | Training-free? | Our use |
|---|---|---|---|---|
| **Pi-Serini** (Waterloo, May 2026) | tuned BM25 depth-1,000 + paging + `read_document`, plain ReAct, 300 s cap | 83.1% BC+, $0.35/q | yes | Approach 1 loop shape; k1/b tuning; paging tool |
| **Question's Gambit** (Sept 2026) | one-shot clue decomposition → per-clue retrieval → union → full-text rerank → opening observation | +5.5–10.9; recall 98.1% | yes | Approach 1 first move (harness runs clues in parallel) |
| **DCI** (May 2026) | grep/read/bash over raw text, no index | 80 vs 69 same model; collapses > 200K docs | yes | Approach 2 tool semantics; bash optional |
| **RISE** (June 2026) | BM25 pre-filter → materialized per-query working dir + TOC → grep/read | 81–83% at 1M docs, $0.25/q | yes | **Approach 2 — chosen tool layer** (our filter replaces BM25 pre-filter) |
| **INDEXACT** (Oct 2026) | set algebra + COUNT over inverted index; READ-only text ingress | 73.5% nano; flat to 800K | yes | counts-not-booleans rule; TODO item 3 |
| **A-RAG** (2026) | keyword + sentence-semantic + chunk_read tools, read tracker | +13–40 over naive RAG; tokens 56K → 5.7K | yes | read tracker (implemented) |
| **Interact-RAG** (ICLR 2026) | corpus-interaction primitives (exact/semantic/fusion/include/exclude) | +9.7 EM | yes | tool design |
| **W&D width scheduling** (2026) | per-turn parallel-call width, wide → narrow | −36% cost, −41% time, +2–8 | yes | `prompts/width_turn.md` |
| **IterResearch** (2025) | Markovian rebuilt-per-turn workspace | +12.6 with less context | yes (prompting) | TODO harness item |
| **InfiAgent** (ACL 2026) | file-workspace state + "external attention" sub-agents | 80.0 vs 29.1 coverage | yes | fan-out contract (Approach 3) |
| **Anthropic multi-agent** (2025/26) | orchestrator + parallel isolated sub-agents returning 1–2K distillations | +90.2% at 15× tokens; 3–10× typical | yes | Approach 3 shape, breadth only |
| **InfoSeeker** (2026) | hierarchical agents for wide collection | Item-F1 35.7 → 70.3 | yes | justification for breadth branch |
| **WebWeaver** (ICLR 2026) | evidence bank + outline-tagged, section-wise retrieve-write-prune | citation acc 86.7 → 93.4 | yes | writer |
| **ScaffoldAgent** (2026) | outline ops (expand/contract/revise), utility-gated | +3.4–4.8 RACE; 117 s | yes | writer outline loop |
| **ClaimWriter** (Aug 2026) | outline from query first; fact binding `{{CITE}}` | hallucination 15.9 → 5.0 /100 | yes | writer (core protocol) |
| **EvidenT** (Sept 2026) | verbatim extract → n-gram align → generate from verified | non-retrieved cites → ≤ 0.6% | yes | **tier-1 verifier (implemented)** |
| **DeepFact-Eval** (2026) | agentic claim verifier, grouped | 83–87% vs 58.5%; $0.21–0.30 grouped | yes | tier-2 verifier (Phase 7) |
| **Sauron** (Oct 2026) | evidence receipts vs environment state | F1 0.96 | yes | tier-2 design |
| **Evidence laundering gate** (EMNLP 2026) | provenance clustering before counting corroboration | "substantially reduces" | yes | provenance gate (Phase 7) |
| **Scroll** (Aug 2026) | event log + Python kernel; projections only | lossy summarization 73 → 20 | yes | harness-owned state (TODO) |
| **Stateless Language Agents** (Oct 2026) | fresh context per call, harness holds state | −84–93% tokens | yes | TODO harness item |
| **FinanceHarness** (Aug 2026) | layered harness over fixed small model | +7.1 harness vs +0.4 RL | yes | thesis for our model set |
| **Advisor pattern** (Anthropic 2026) | cheap executor consults strong model ≤ 3× | 19.7 → 41.2 at −85% cost | yes | TODO (Nemotron ↔ GPT-OSS) |
| **Hebbia grid** (production) | run model over every doc as rows × columns | vendor 92 vs 68 | yes | `extract` tool (Approach 3) |
| **Harvey loop** (production) | bounded ReAct 3–10 ops + completeness check + auto-reject bad citations | vendor | yes | our default loop + tier 1 |
| **Azure/AWS/Databricks agentic retrieval** | planning → parallel filtered hybrid → rerank in one call | IR-1 ≈ Sonnet 4.5, 3× faster | n/a | upstream filter stage design |
| **Search-as-Code / YQL** (Perplexity, Vespa) | agent writes retrieval pipeline code | ~85% fewer tokens (vendor) | yes | TODO item 5 |
| **Contextual retrieval** (Anthropic 2024) | LLM-written chunk context before embedding/BM25 | failure 5.7 → 1.9% | yes | upstream index (not this project) |
| **Filtered-ANN safeguards** (Qdrant/Weaviate/Lucene 2025–26) | payload indexes, ACORN, exact fallback < 1–5% | 0.1% → 99.9% recall | n/a | upstream filter stage |
| **Librarian Agents** (Oct 2026) | RL-trained builder pre-organizes corpus into filesystem | 0.75 (per-task sets); no-RL 0.28 | **no** | deferred (TODO 6) |
| **LATTICE / Corpus2Skill / RAPTOR / PageIndex** | tree / cluster / summary navigation | see §A.2.6 | mostly yes | not adopted (cost, scale, or evidence) |
| **GraphRAG / HippoRAG / LightRAG** | knowledge-graph RAG | GraphRAG 10.31 on HERB; 0.36 in Librarian table | — | **excluded by constraint** (and under-performs) |

---

## B. Glossary
**Materialized working set** — the filtered documents written to disk as line-numbered text files for a single query, so the agent can grep/read them. **First move** — a one-shot decomposition-and-retrieval step before the agent loop. **Deep list** — a cached ranking to depth ~1,000 the agent pages through, instead of a reranked top-20. **Evidence bank** — harness-owned store of verbatim quotes with provenance; the writer's only input. **Fact-bound writing** — every sentence carries evidence IDs at construction time. **Tier 1 / tier 2** — deterministic n-gram alignment / agentic grouped re-check. **Provenance gate** — near-duplicate clustering so copies don't count as independent corroboration. **Opened-or-cited recall** — fraction of gold docs the agent actually read or cited (localization, not just coverage). **Breadth question** — enumeration across many documents ("list every X"). **Context rot** — accuracy decline as input length grows, steepest for multi-hop with similar distractors. **Filtered-ANN collapse** — HNSW recall falling to ~0 under selective metadata filters with no latency signal.

---


## C. Key sources (full lists in the two reports)

- BrowseComp-Plus — arxiv.org/pdf/2508.06600, aclanthology.org/2026.acl-long.1023.pdf; leaderboard — tevatron-browsecomp-plus.hf.space/data/leaderboard.json
- Pi-Serini — arxiv.org/pdf/2605.10848
- Question's Gambit — arxiv.org/html/2609.14412
- DCI — arxiv.org/pdf/2605.05242
- RISE — arxiv.org/html/2606.06880
- INDEXACT — arxiv.org/html/2610.07960v1
- A-RAG — arxiv.org/pdf/2602.03442
- Interact-RAG — arxiv.org/pdf/2510.27566
- IterResearch — arxiv.org/pdf/2511.07327
- SMTL — arxiv.org/pdf/2602.22675v2
- InfiAgent — aclanthology.org/2026.findings-acl.1787.pdf
- W&D — arxiv.org/pdf/2602.07359
- InfoSeeker — arxiv.org/pdf/2604.02971
- Librarian Agents — arxiv.org/abs/2610.22273
- WebWeaver — arxiv.org/html/2509.13312v3
- ScaffoldAgent — arxiv.org/html/2606.20122v2
- ClaimWriter — arxiv.org/html/2608.28643v1
- EvidenT — arxiv.org/html/2609.22537v1
- DeepFact — arxiv.org/html/2603.05912v1
- Sauron — arxiv.org/abs/2610.17724
- CiteAudit — arxiv.org/html/2602.23452
- Evidence laundering — aclanthology.org/2026.emnlp-main.509
- Scroll — arxiv.org/html/2608.21690v1
- Stateless Language Agents — arxiv.org/html/2610.07625v1
- FinanceHarness — arxiv.org/pdf/2607.27853
- DRBench — ICLR 2026 proceedings
- BigFinanceBench — arxiv.org/abs/2606.03829
- HERB — arxiv.org/pdf/2506.23139
- TIDE — arxiv.org/pdf/2608.08512
- NoLiMa — arxiv.org/pdf/2502.05167
- Chroma context rot — trychroma.com/research/context-rot
- LC vs RAG — arxiv.org/pdf/2501.01880v1
- Self-Route — arxiv.org/pdf/2407.16833
- Qdrant filtered search — qdrant.tech/articles/filtered-vector-search-acorn
- Anthropic contextual retrieval — anthropic.com/news/contextual-retrieval
- Anthropic multi-agent — anthropic.com/engineering/multi-agent-research-system
- Anthropic context engineering — anthropic.com/engineering/effective-context-engineering-for-ai-agents
- Anthropic multi-agent guidance (Jan 2026) — claude.com/blog/building-multi-agent-systems-when-and-how-to-use-them
- Anthropic advisor — claude.com/blog/the-advisor-strategy
- Claude cookbook compaction — platform.claude.com/cookbook/tool-use-context-engineering-context-engineering-tools
- OpenAI deep research guide — developers.openai.com/api/docs/guides/deep-research.md
- Azure agentic retrieval — learn.microsoft.com/azure/search/agentic-retrieval-overview
- Databricks IR-1 — databricks.com/blog/3x-faster-search-parallel-test-time-scaling-instructed-retriever-1
- Hebbia multi-agent — hebbia.com/blog/divide-and-conquer-hebbias-multi-agent-redesign
- Harvey agentic search — harvey.ai/blog/how-agentic-search-unlocks-legal-research-intelligence
- LangChain Deep Agents — docs.langchain.com/labs/deep-agents/overview
- LanceDB hybrid search — docs.lancedb.com/search/hybrid-search.md
