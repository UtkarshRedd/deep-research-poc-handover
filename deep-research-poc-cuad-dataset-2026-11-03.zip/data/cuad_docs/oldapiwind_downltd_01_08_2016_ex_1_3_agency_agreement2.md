<!-- page 1 -->
# AGENTS' CERTIFICATE
| Field | Value |
|---|---|
| Document Type | Agency Agreement |
| SEC Filing Date | 2016-01-08 |
| Parties | Tribute Pharmaceuticals Inc. ("Corporation"); [] ("Agent"); [] ("U.S. Affiliate"); U.S. registered broker-dealer affiliate of the Agent |
| Source | CUAD v1 / OLDAPIWIND-DOWNLTD_01_08_2016-EX-1.3-AGENCY AGREEMENT2 |

EXHIBIT I TO SCHEDULE A (COMPLIANCE WITH UNITED STATES SECURITIES LAWS) AGENTS' CERTIFICATE In
connection with the offer and sale in the United States of common shares (the "Securities") of
Tribute Pharmaceuticals Inc. (the "Corporation") to Accredited Investors pursuant to a Subscription
Agreement dated as of May 22, 2015, and pursuant to an agency agreement (the "Agency Agreement")
dated as of May 22, 2015 between the Corporation and the agents named therein, [ ] (the "Agent") and
[ ] (the "U.S. Affiliate"), the U.S. registered broker-dealer affiliate of the Agent, hereby certify
as follows: (i) on the date hereof and on the date of each offer of Securities by us in the United
States and each subsequent sale to such offerees by the Corporation, the U.S. Affiliate is and was:
(A) a duly registered as a broker-dealer under the U.S. Exchange Act and duly registered as a
broker-dealer under the laws of each state where it made offers of Securities (unless exempt from
such registration requirements); and (B) a member of and in good standing with the Financial
Industry Regulatory Authority, Inc.; (ii) all offers of Securities by us in the United States have
been effected by the U.S. Affiliate in accordance with all applicable U.S. federal and state
broker-dealer requirements; (iii) immediately prior to offering the Securities to persons in the
United States, we had reasonable grounds to believe and did believe that each such person was an
Accredited Investor, based upon a pre-existing relationship, and, on the date hereof, we continue to
believe that each such offeree purchasing Securities from the Corporation is an Accredited Investor;
(iv) no form of Directed Selling Efforts, General Solicitation or General Advertising was used by us
in connection with the offer of the Securities by us in the United States, and we have not acted in
any manner involving public offering within the meaning of Section 4(a) (2) of the U.S. Securities
Act in connection with the offer of the Securities by us in the United States; (v) in connection
with arranging each sale by the Corporation of Securities to U.S. Subscribers solicited by us, we
caused each such U.S. Subscriber to duly complete and execute a Subscription Agreement to be used
for U.S Subscribers; (vi) the Agent represents and warrants that with respect to Offered Shares to
be sold in reliance on Rule 506(b) of Regulation D, none of it, the U.S. Affiliate, any of its or
the U.S. Affiliate's directors, executive officers, general partners, managing members or other
officers participating in the Offering, or any other person associated with the Agent who will
receive, directly or indirectly, remuneration for solicitation of Subscribers of Offered Shares
pursuant to Rule 506(b) of Regulation D (each, a "Dealer Covered Person" and, together, "Dealer
Covered Persons"), is subject to any Disqualification Event except for a Disqualification Event (i)
covered by Rule 506(d)(2)(i) of Regulation D and (ii) a description of which has been furnished in
writing to the Corporation prior to the date hereof;
<!-- page 2 -->
(vii) the Agent represents that it is not aware of any person (other than any Dealer Covered Person)
that has been or will be paid (directly or indirectly) remuneration for solicitation of Subscribers
in connection with the sale of any Offered Shares pursuant to Rule 506(b) of Regulation D; and
(viii) the offering of the Securities in the United States has been conducted by us in accordance
with the terms of the Agency Agreement, including Schedule A attached hereto. [REMAINDER OF PAGE
INTENTIONALLY LEFT BLANK]
<!-- page 3 -->
Terms used in this certificate have the meanings given to them in the Agency Agreement, including
Schedule A attached hereto, unless otherwise defined herein. Dated this day of , 2015. [INSERT NAME
OF AGENT] [INSERT NAME OF U.S. AFFILIATE] By: By: Name: Name: Title: Title:
