<!-- page 1 -->
# SERVICING AGREEMENT
| Field | Value |
|---|---|
| Document Type | Service Agreement |
| SEC Filing Date | 2020-04-24 |
| Parties | Nationwide Fund Management LLC ("Nationwide"); American United Life Insurance Company and OneAmerica Securities, Inc. (collectively referred to as "Servicing Agent", "you", or "your") |
| Source | CUAD v1 / AULAMERICANUNITTRUST_04_24_2020-EX-99.8.77-SERVICING AGREEMENT |

Exhibit 8.77 SERVICING AGREEMENT NATIONWIDE MUTUAL FUNDS Agreement, made as of this day of , 20
between Nationwide Fund Management LLC ("Nationwide"), on behalf of Nationwide Mutual Funds or its
surviving entity ("the Trust"), and American United Life Insurance Company, and OneAmerica
Securities, Inc., a registered Broker Dealer (collectively referred to as "Servicing Agent," "you"
or "your"), whereby you agree to provide certain administrative support services to your customers
who may from time to time be the record or beneficial owners of shares (such shares referred to
herein as the "Shares") of the funds listed in Appendix A (each a "Fund") subject to the following
terms and conditions: 1. Administrative Support Services You agree to provide administrative support
services, directly or through an affiliate/designee, to your customers who may from time to time own
of record or beneficially a Fund's Shares. Services provided may include, but are not limited to,
some or all of the following: (i) processing dividend and distribution payments from the Fund on
behalf of customers; (ii) providing periodic statements to your customers showing their positions in
the Shares or share equivalents; (iii) arranging for bank wires; (iv) responding to routine customer
inquiries relating to services performed by you; (v) providing sub-accounting or sub-transfer agency
services with respect to the Shares beneficially owned by your customers or the information
necessary for sub-accounting or sub-transfer agency services; (vi) if required by law, forwarding
shareholder communications from the Fund (such as proxies, shareholder reports, annual and
semi-annual financial statements and dividend, distribution and tax notices) to your customers;
(vii) forwarding to customers proxy statements and proxies containing any proposals regarding this
Agreement or the Administrative Services Plan related hereto; (viii) aggregating and processing
purchase, exchange, and redemption requests from customers and placing net purchase, exchange, and
redemption orders for your customers; (ix) providing customers with a service that invests the
assets of their accounts in the Shares pursuant to specific or preauthorized instructions; (x)
establishing and maintaining customer accounts and records related to customer accounts and/or
transactions in the Shares; (xi) assisting customers in changing dividend or distribution options,
account designations and addresses; or (xii) other similar services if requested by the Funds. In
providing administrative support services, you agree to follow any written guidelines or standards
relating to the processing of purchase, exchange and redemption orders for your customers as we may
provide to you including the provisions outlined in Appendix B. All purchase and redemption orders
will be executed at net asset value, plus or minus any applicable sales charges, in accordance with
the terms and conditions of a Fund's then current prospectus and Statement of Additional
Information. You represent and warrant that your internal controls for accepting, processing and
transmitting purchase, exchange and redemption orders are reasonably designed to ensure that you
comply with Section 22(c) of the Investment Company Act of 1940 (the "1940 Act") and Rule 22c-1
thereunder. 2. Office Space You will provide such office space and equipment, telephone facilities
and personnel (which may be any part of the space, equipment and facilities currently used in your
business, or any personnel employed by you) as may be reasonably necessary or beneficial in order to
provide the aforementioned services to customers. March 2015
<!-- page 2 -->
3. Representations About the Funds and Shares Neither you nor any of your officers, employees or
agents are authorized to make any representations concerning the Funds or their Shares except those
contained in the then-current prospectuses or then-current Statements of Additional Information for
such shares, copies of which will be supplied by the Fund's distributor (the "Distributor") to you,
or in such supplemental literature or advertising as may be authorized by the Distributor in
writing. 4. Independent Contractor and Limited Agency You will be deemed to be an independent
contractor, and will have no authority to act as agent for either Nationwide or the Funds in any
matter or in any respect. Notwithstanding the foregoing, Nationwide, on behalf of each Fund,
appoints you as each Fund's agent for the limited purpose of accepting orders for purchase,
redemption and exchange of Shares, and receipt of such orders by you therefore shall constitute
receipt by the applicable Fund of such orders for purposes of determining the price per Share at
which such orders will be executed, in accordance with Rule 22c-1 under the 1940 Act. Except as
specifically set forth herein, nothing in this Agreement will be deemed or construed to make you a
partner, employee, representative or agent of Nationwide or any Fund or to create a partnership,
joint venture, syndicate or association between you and us. 5. Indemnification By your written
acceptance of this Agreement, you agree to and do release, indemnify and hold Nationwide and the
Funds harmless from and against any and all direct or indirect liabilities or losses resulting from
requests, directions, actions or inactions of or by you or your officers, employees or agents
regarding your responsibilities hereunder or the purchase, redemption, transfer or registration of
the Shares by or on behalf of customers. In turn, Nationwide, on behalf of the Funds, agrees to and
does release, indemnify and hold you and your affiliates harmless from and against any and all
direct or indirect liabilities or losses resulting from directions, actions or inactions of or by
Nationwide, the Funds, or their respective officers, employees or agents regarding their
responsibilities pursuant to this Agreement. 6. Compensation In consideration for the services and
facilities provided by you hereunder, Nationwide (on behalf of the Funds) will pay to you, and you
will accept as full payment therefore, a fee at the annual rate designated in Appendix A of the
average daily net assets of a Fund's Shares owned of record or beneficially by your customers from
time to time for which you provide administrative support services hereunder. Such fee will be
computed daily and payable monthly by Nationwide within thirty (30) days of receipt from you of a
valid invoice (in excel format) that identifies, for each CUSIP of each Fund, the number of
sub-accounts, participants or beneficial shareholders serviced by you and such other information as
may be necessary to validate the fee payable. The fee rate stated above may be prospectively
increased or decreased by the Funds and/or Nationwide, in their sole discretion, at any time upon
notice to you. Further, Nationwide or a Fund may, in its sole discretion and without notice, suspend
or withdraw the sale of such Shares, including the sale of such Shares to you for the account of any
customer(s). Nationwide, in its sole discretion, may arrange for the payment to you of the fees
under this Agreement directly by the Funds rather than through Nationwide. Quarterly and Other
Reports 2
<!-- page 3 -->
You agree to provide all such information as is reasonably necessary for the Board of Trustees of
the Trust to review, at least quarterly, a written report of the amounts of compensation received by
you hereunder and the services provided for which you received such compensation. In addition, you
will furnish Nationwide with such information as Nationwide or the Funds may reasonably request
(including, without limitation, periodic certifications confirming the provision to customers of
some or all of the services described herein), and will otherwise cooperate with Nationwide and the
Funds (including, without limitation, any auditors designated by the Funds), in connection with the
preparation of reports to the Trust's Board of Trustees concerning this Agreement and the monies
paid or payable by Nationwide on behalf of the Funds pursuant hereto, as well as any other reports
or filings that may be required by law. You agree, upon the reasonable request of Nationwide, to
provide access during normal business hours to your facilities and records related to the services
provided and the compensation payable hereunder, and to permit Nationwide to review the quality of
such services provided and to respond to requests of the Trust's Board of Trustees. Nationwide
agrees that all records obtained in connection with access to your facilities is your property and
to maintain the confidentiality thereof. In particular, Nationwide agrees that no person having
access to such records may use such records or information to solicit, directly or indirectly, any
of your customers for any purpose. 7. Non-Exclusivity Both parties may enter into other similar
Servicing Agreements with any other person or persons without the other's consent. 8.
Representations and Warranties By your written acceptance of this Agreement, you represent, warrant
and agree that: (i) all compensation payable to you hereunder is for administrative support services
only; (ii) in no event will any of the compensation payable by Nationwide or the services provided
by you hereunder be primarily intended to result in the sale of any Shares issued by a Fund; (iii)
the compensation payable to you hereunder, together with any other compensation you receive from
customers for services contemplated by this Agreement, will to the extent required be disclosed to
your customers, and will not be excessive or unreasonable under the laws and instruments governing
your relationships with your customers; and (iv) if you are subject to laws governing, among other
things, the conduct of activities by federally chartered and supervised banks and other affiliated
banking organizations, you will perform only those activities which are consistent with your
statutory and regulatory obligations. 9. Termination This Agreement will become effective on the
date a fully executed copy of this Agreement is received by Nationwide. This Agreement may be
terminated as to the payments made on behalf of the Funds at any time, without the payment of any
penalty, by the vote of a majority of the members of the Board of Trustees and who have no direct or
indirect financial interest in the operation of the Administrative Services Plan or in any related
agreements to the Administrative Services Plan ("Disinterested Trustees") or by a majority of the
outstanding voting securities of a Fund, on at least sixty (60) days written notice to the parties
to this Agreement. In addition, either you or Nationwide may terminate this Agreement (i) upon the
material breach of this Agreement by the other or (ii) for any reason on at least ninety (90) days
written notice to the other party. 3
<!-- page 4 -->
In the event this Agreement is terminated as described herein, the indemnification provisions
contained in this Agreement shall continue until the possibilities for damages or loss have expired.
10. Notices All notices and other communications to either you or Nationwide will be duly given if
mailed, telegraphed, telexed or transmitted by similar telecommunications device to the address
contained in the "Acceptance of Agreement" (Section 19) portion of this Agreement. 11. Choice of Law
This Agreement will be construed in accordance with the laws of the State of Delaware and is
assignable only upon the written consent by all the parties hereto. Amendments will be made only
upon written consent by both parties. 12. Board Approval The Administrative Services Plan that
relates to this Agreement has been approved by vote of a majority of (i) the Board of Trustees and
(ii) the Disinterested Trustees, cast in person at a meeting called for the purpose of voting on
such approval. 13. Trust Disclosure The term "Nationwide Mutual Funds" refers to the Trust created
by, and the terms "Board of Trustees" and "Trustees" refer to the Trustees, as trustees but not
individually or personally, acting from time to time under, the Amended and Restated Agreement and
Declaration of Trust made and dated as of October 28, 2004, as has been or may be amended and/or
restated from time to time ("Agreement and Declaration of Trust"), and to which reference is hereby
made. Nothing herein contained shall be deemed to require the Trust to take any action contrary to
the Trust's Agreement and Declaration of Trust or By-Laws, or any applicable statutory or regulatory
requirement to which the Trust is subject or by which the Trust is bound, or to relieve or deprive
the Trust's Board of Trustees of the Board's responsibility for and control of the conduct of the
affairs of the Trust. 14. Complete Agreement This Agreement supersedes and cancels any prior
Servicing Agreement with respect to the Shares of a Fund listed in Exhibit A, and may be amended at
any time and from time to time by written agreement of the parties hereto. Notwithstanding the
foregoing, Nationwide may amend or modify the Exhibits incorporated herein, as provided throughout
this Agreement, by providing new exhibits to you. However, such amendment shall only become
effective and part of this Agreement and be considered binding upon the first transaction placed by
you following receipt of the new exhibits. 15. Privacy Program Each party to this Agreement agrees
to protect Customer Information (defined below) and to comply as may be necessary with requirements
of the Gramm-Leach-Bliley Act, the relevant state and federal regulations pursuant thereto,
including Regulation S-P, and state privacy laws (all the foregoing referred to as "Privacy Law"). 4
<!-- page 5 -->
Customer Information means any information contained on an application of a customer ("Customer") of
a Fund or other form and all nonpublic personal information about a Customer that a party receives
from the other party. Customer Information includes, by way of example and not limitation, name,
address, telephone number, social security number, date of birth and personal financial information.
The parties shall establish and maintain safeguards against the unauthorized access, destruction,
loss or alteration of Customer Information in their control, which are no less rigorous than those
maintained by a party for its own information of a similar nature. In the event of any improper
disclosure of any Customer Information, the party responsible for the disclosure will immediately
notify the other party. The Servicing Agent represents that it has implemented and maintains a
comprehensive written information security program that contains appropriate security measures to
safeguard Customer Information that the Servicing Agent receives, stores, maintains, processes or
otherwise accesses in connection with the provision of services hereunder, including protecting such
Customer Information against cyber attack. The provisions of this Privacy Program section shall
survive the termination of the Agreement. 16. Anti-Money Laundering Program Nationwide and the Funds
will rely upon you to establish a written Anti-Money Laundering Program (the "Program") to include
policies, procedures, and controls that comply with the Uniting and Strengthening America by
Providing Appropriate Tools Required to Intercept and Obstruct Terrorism Act (USA Patriot Act) of
2001, ("the ACT") and the Bank Secrecy Act of 1970 ("BSA"). Each party to this Agreement
acknowledges, represents, and warrants that it has adopted and implemented an Anti-Money Laundering
Program that complies and will continue to comply with all aspects and requirements of the ACT, the
BSA, and all other applicable anti-money laundering laws and regulations. Upon request, you shall
promptly certify to having such Program that complies with and continues to comply with all aspects
and requirements of the ACT, the BSA, and all other applicable federal, state and local anti-money
laundering laws and regulations. Your Program shall include, and Nationwide and the Funds shall rely
upon, your policies, procedures and controls to, among other things, (i) verify the identity (due
diligence) of your customers, (ii) maintain records of the information used to identify your
customers, (iii) determine if your customer appears on lists of known or suspected terrorists or
associated with known or suspected terrorist organizations (said customer hereinafter referred to as
a "Prohibited Customer"), and (iv) to ensure that Prohibited Customers and foreign shell banks do
not maintain investments in any Fund. Your Program shall also comply with the Customer
Identification Program ("CIP") for customers who open accounts on or after October 1, 2003, and as
such, shall among other matters provide for the release of customer information to law enforcement
agencies, and the filing of Suspicious Activity Reports ("SARs"), as and if applicable, and in
accordance with the ACT. In addition, your Program also shall include procedures for fulfilling the
currency reporting requirements of the ACT and the BSA, as and if applicable. The provisions of this
Anti-Money Laundering section shall survive the termination of the Agreement. 5
<!-- page 6 -->
18. Shareholder Information 18.1 Agreement to Provide Information. You agree to provide the Funds,
upon written request, the taxpayer identification number ("TIN"), if known, of any or all
Shareholder(s) of an account and the amount, date, name or other identifier of any registered
representative(s) associated with the Shareholder(s) or account (if known), and transaction type
(purchase, redemption, transfer, or exchange) of every purchase, redemption, transfer, or exchange
of Shares held through an account maintained by you during the period covered by the request. 18.1.1
Period Covered by Request. Requests must set forth a specific period, not to exceed 12 months from
the date of the request, for which transaction information is sought. A Fund may request transaction
information older than 12 months from the date of the request as it deems necessary to investigate
compliance with policies established by the Funds for the purpose of eliminating or reducing any
dilution of the value of the outstanding shares issued by a Fund. 18.1.2 Form and Timing of
Response. You agree to transmit the requested information that is on your books and records to the
Fund or its designee promptly, but in any event not later than five (5) business days, after receipt
of a request. If the requested information is not on your books and records, you agree to: (i)
provide or arrange to provide the requested information from Shareholders who hold an account with
an indirect intermediary; or (ii) if directed by the Fund, block further purchases of Fund Shares
from such indirect intermediary. In such instance, you agree to inform the Fund whether you plan to
perform (i) or (ii). Responses required by this paragraph must be communicated in writing and in a
format mutually agreed upon by the parties. To the extent practicable, the format for any
transaction information provided to a Fund should be consistent with the NSCC Standardized Data
Reporting Format. For purposes of this provision, an "indirect intermediary" has the same meaning as
in SEC Rule 22c-2 under the 1940 Act. 18.1.3 Limitations on Use of Information. The Funds agree not
to use the information received for marketing or any other similar purpose without your prior
written consent. 18.2 Agreement to Restrict Trading. You agree to promptly and fully cooperate with
any reasonable request made by the Fund to address market timing or excessive trading strategies
identified by Nationwide in accordance with the applicable provisions of Rule 22c-2 and agree to
restrict or prohibit further purchases or exchanges of Shares by a Shareholder that has been
identified by such Fund as having engaged in transactions of the Fund's Shares (directly or
indirectly through your account) that violate policies established by the Fund for the purpose of
eliminating or reducing any dilution of the value of the outstanding Shares issued by the Fund.
18.2.1 Form of Instructions. Instructions must include the TIN, if known, and the specific
restriction(s) to be executed. If the TIN is not known, the instructions must include an equivalent
identifying number of the Shareholder(s) or account(s) or other agreed upon information to which the
instruction relates. 18.2.2 Timing of Response. You agree to execute instructions as soon as
reasonably practicable, but not later than five business days after your receipt of the
instructions. 6
<!-- page 7 -->
18.2.3 Confirmation by You. You must provide written confirmation to the Fund that instructions have
been executed. You agree to provide confirmation as soon as reasonably practicable, but not later
than ten business days after the instructions have been executed. 18.3 Definitions. For purposes of
this paragraph 18: 18.3.1 The term "Fund" includes a Fund's distributor and a Fund's transfer agent.
The term not does include any "excepted funds" as defined in SEC Rule 22c-2(b) under the 1940 Act.
18.3.2 The term "Shares" means the interest of Shareholders corresponding to the redeemable
securities of record issued by a Fund under the 1940 Act that are held by you. 18.3.3 The term
"Shareholder" means the beneficial owner of Shares, whether the Shares are held directly or by you
in nominee name. 18.3.4 The term "written" includes electronic writings and facsimile transmissions.
[The remainder of this page is intentionally left blank.] 7
<!-- page 8 -->
19. Acceptance of Agreement If you agree to be legally bound by the provisions of this Agreement,
please sign a copy of this Agreement where indicated below and promptly return it to Nationwide at
the address below: Nationwide Fund Management LLC Attention: Fund Administration 1000 Continental
Drive, Suite 400 King of Prussia, PA 19406 This Agreement will become effective on the date a fully
executed copy of this Agreement is received by Nationwide. Accepted by: Name Title Nationwide Fund
Management LLC Date: Accepted and Agreed to: By: Name: Title: Company: Date: 8
<!-- page 9 -->
APPENDIX A TO SERVICING AGREEMENT Nationwide Mutual Funds Funds of Nationwide Mutual Funds Class R6
and Institutional Service Class shares of all Funds of Nationwide Mutual Funds as offered in the
Fund's current prospectus. Administrative Services Fees Share Class Rate (Bps) Institutional Service
Class 25 Class R6 0 (no fee) Acknowledgement: Servicing Agent: Nationwide Fund Management LLC 1000
Continental Drive Suite 400 King of Prussia, PA 19406 x x By: By:
<!-- page 10 -->
APPENDIX B FUND/SERV PROCESSING PROCEDURES AND MANUAL PROCESSING PROCEDURES The purchase, redemption
and settlement of Shares of a Fund will normally follow the Fund/SERV-Defined Contribution Clearance
and Settlement Service ("DCCS") Processing Procedures below and the rules and procedures of the SCC
Division of the National Securities Clearing Corporation ("NSCC") shall govern the purchase,
redemption and settlement of Shares of the Funds through NSCC by the Servicing Agent. In the event
of equipment failure or technical malfunctions or the parties' inability to otherwise perform
transactions pursuant to the FUND/SERV Processing Procedures, or the parties' mutual consent to use
manual processing, the Manual Processing Procedures below will apply. It is understood and agreed
that, in the context of Section 22 of the 1940 Act and the rules and public interpretations
thereunder by the staff of the Securities and Exchange Commission (SEC Staff), receipt by the
Servicing Agent of any Instructions from the Client-shareholder prior to the Close of Trade on any
Business Day shall be deemed to be receipt by the Funds of such Instructions solely for pricing
purposes and shall cause purchases and sales to be deemed to occur at the Share Price for such
Business Day, except as provided in 4(c) of the Manual Processing Procedures. Each Instruction shall
be deemed to be accompanied by a representation by the Servicing Agent that it has received proper
authorization from each Client-shareholder whose purchase, redemption, account transfer or exchange
transaction is effected as a result of such Instruction. Fund/SERV-DCCS Processing Procedures 1. On
each business day that the New York Stock Exchange (the "Exchange") is open for business on which
the Funds determine their net asset values ("Business Day"), Nationwide shall accept, and effect
changes in its records upon receipt of purchase, redemption, exchange, account transfer and
registration instructions from the Servicing Agent electronically through Fund/SERV ("Instructions")
without supporting documentation from the Client-shareholder. On each Business Day, Nationwide shall
accept for processing any Instructions from the Servicing Agent and shall process such Instructions
in a timely manner. 2. Nationwide shall perform any and all duties, functions, procedures and
responsibilities assigned to it under this Agreement and as otherwise established by the NSCC.
Nationwide shall conduct each of the foregoing activities in a competent manner and in compliance
with (a) all applicable laws, rules and regulations, including NSCC Fund/SERV-DCCS rules and
procedures relating to Fund/SERV; (b) the then-current Prospectus of a Fund; and (c) any provision
relating to Fund/SERV in any other agreement of Nationwide that would affect its duties and
obligations pursuant to this Agreement. 3. Confirmed trades and any other information provided by
Nationwide to the Servicing Agent through Fund/SERV and pursuant to this Agreement shall be
accurate, complete, and in the format prescribed by the NSCC. 4. Trade, registration, and
broker/dealer information provided by the Servicing Agent to Nationwide through Fund/SERV and
pursuant to this Agreement shall be accurate, complete and, in the
<!-- page 11 -->
format prescribed by the NSCC. All Instructions by the Servicing Agent regarding each Fund/SERV
Account shall be true and correct and will have been duly authorized by the registered holder. 5.
For each Fund/SERV transaction, including transactions establishing a Client-shareholder account
with Nationwide, the Servicing Agent shall provide the Funds and Nationwide with all information
necessary or appropriate to establish and maintain each Fund/SERV transaction (and any subsequent
changes to such information), which the Servicing Agent hereby certifies is and shall remain true
and correct. The Servicing Agent shall maintain documents required by the Funds to effect Fund/SERV
transactions. The Servicing Agent certifies that all Instructions delivered to Nationwide on any
Business Day shall have been received by the Servicing Agent from the Client-shareholder by the
close of trading (generally 4:00 p.m. Eastern Time ("ET")) on the Exchange (the "Close of Trading")
on such Business Day and that any Instructions received by it after the Close of Trading on any
given Business Day will be transmitted to Nationwide on the next Business Day. Manual Processing
Procedures 1. On each Business Day, the Servicing Agent may receive Instructions from the
Client-shareholder for the purchase or redemption of shares of the Funds based solely upon receipt
of such Instructions prior to the Close of Trading on that Business Day. Instructions in good order
received by the Servicing Agent prior to the close of trading on any given Business Day (generally,
4:00 p.m. ET (the "Trade Date") and transmitted to Nationwide by no later than 9:30 a.m. ET the
Business Day following the Trade Date ("Trade Date plus One" or "TD+1"), will be executed at the
NAV-based public offering price ("Share Price") of each applicable Fund, determined as of the Close
of Trading on the Trade Date. 2. By no later than 6:00 p.m. ET on each Trade Date ("Price
Communication Time"), Nationwide will use its best efforts to communicate to the Servicing Agent via
electronic transmission acceptable to both parties, the Share Price of each applicable Fund, as well
as dividend and capital gain information and, in the case of Funds that credit a daily dividend, the
daily accrual for interest rate factor (mil rate), determined at the Close of Trading on that Trade
Date. 3. As noted in Paragraph 1 above, by 9:30 a.m. ET on TD+1 ("Instruction Cutoff Time") and
after the Servicing Agent has processed all approved transactions, the Servicing Agent will transmit
to Nationwide via facsimile, telefax or electronic transmission or system-to-system, or by a method
acceptable to the Servicing Agent and Nationwide, a report (the "Instruction Report") detailing the
Instructions that were received by the Servicing Agent prior to the Funds' daily determination of
Share Price for each Fund (i.e., the Close of Trading) on Trade Date. (a) It is understood by the
parties that all Instructions from the Client-shareholder shall be received and processed by the
Servicing Agent in accordance with its standard transaction processing procedures. The Servicing
Agent or its designees shall maintain records sufficient to identify the date and time of receipt of
all Client-shareholder transactions involving the Funds and shall make or cause to be made such
records available upon reasonable request for examination by the Funds or its designated
representative or, at the request of the Funds, by appropriate governmental authorities. Under no
circumstances shall the Servicing Agent change, alter or modify any Instructions received by it in
good order.
<!-- page 12 -->
(b) Following the completion of the transmission of any Instructions by the Servicing Agent to
Nationwide by the Instruction Cutoff Time, the Servicing Agent will verify that the Instruction was
received by Nationwide and trades are pending by utilizing a remote terminal or such other method
acceptable to Nationwide. (c) In the event that an Instruction transmitted by the Servicing Agent on
any Business Day is not received by Nationwide by the Instruction Cutoff Time, due to mechanical
difficulties or for any other reason beyond the Servicing Agent's reasonable control, such
Instruction shall nonetheless be treated by Nationwide as if it had been received by the Instruction
Cutoff Time, provided that the Servicing Agent retransmits such Instruction electronically (by
facsimile transmission or other means mutually agreed upon) to Nationwide and such Instruction is
received by Nationwide's (or the Distributor's) financial control representative no later than 9:30
a.m. ET on TD+1. In addition, the Servicing Agent will place a phone call to a financial control
representative of Nationwide (or the Distributor) prior to 9:00 a.m. ET on TD+1 to advise Nationwide
(or the Distributor) that a facsimile transmission concerning the Instruction is being sent. (d)
With respect to all Instructions, Nationwide (or the Distributor's financial control representative)
will manually adjust a Fund's records for the Trade Date to reflect any Instructions sent by the
Servicing Agent. (e) By no later than 4:00 p.m. on TD+1, and based on the information transmitted to
Nationwide (or the Distributor's financial control representative) pursuant to Paragraph 3(c) above,
the Servicing Agent will use its best efforts to verify that all Instructions provided to Nationwide
(or the Distributor's financial control representative) on TD+1 were accurately received and that
the trades for each Account were accurately completed and the Servicing Agent will use its best
efforts to notify Nationwide of any discrepancies. 4. As set forth below, upon the timely receipt
from the Servicing Agent of the Instructions, the Fund will execute the purchase or redemption
transactions (as the case may be) at the Share Price for each Fund computed as of the Close of
Trading on the Trade Date. (a) Except as otherwise provided herein, all purchase and redemption
transactions will settle on TD+1. Settlements will be through net Federal Wire transfers to an
account designated by a Fund. In the case of Instructions which constitute a net purchase order, the
Servicing Agent shall, by 1:00 p.m. ET on TD+1, remit funds to the Fund's custodian in the amount
necessary to cover such net purchase order. In the case of Instructions which constitute a net
redemption order, Nationwide shall, by 1:00 p.m. ET on TD+1, remit funds to the Servicing Agent in
the amount necessary to cover such net redemption order, provided that the Fund reserves the right
to (i) delay settlement of redemptions for up to seven (7) Business Days after receiving a net
redemption order in accordance with Section 22 of the 1940 Act and Rule 22c-1 thereunder, or (iii)
suspend redemptions pursuant to the 1940 Act or as otherwise required by law. Settlements shall be
in U.S. dollars and a Fund may pay redemption proceeds in whole or in part by a distribution in-kind
of readily marketable securities that it holds in lieu of cash in conformity with applicable law or
regulations.
<!-- page 13 -->
(b) The Servicing Agent or such other party as may be designated, as record owner of each account
("Record Owner") will be provided with all written confirmations required under federal and state
securities laws. (c) On any Business Day when the Federal Reserve Wire Transfer System is closed,
all communication and processing rules will be suspended for the settlement of Instructions.
Instructions will be settled on the next Business Day on which the Federal Reserve Wire Transfer
System is open. The original TD+1 Settlement Date will not apply. Rather, for purposes of this
Paragraph 4(c) only, the Settlement Date will be the date on which the Instruction settles. (d) The
Servicing Agent shall, upon receipt of any confirmation or statement concerning the accounts,
promptly verify by use of the terminal or by such other method acceptable to Nationwide and the
Servicing Agent the accuracy of the information contained therein against the information contained
in the Servicing Agent's internal record-keeping system and shall promptly, but in no event not more
than seven days, advise Nationwide in writing of any discrepancies between such information.
Nationwide and the Servicing Agent shall cooperate to resolve any such discrepancies as soon as
reasonably practicable. Indemnification In the event of any error or delay with respect to both the
Fund/SERV Processing Procedures and the Manual Processing Procedures outlined in Exhibit B herein:
(i) which is caused by the Funds or Nationwide, Nationwide shall make any adjustments on the Funds'
accounting system necessary to correct such error or delay and the responsible party or parties
shall reimburse the Client-shareholder and the Servicing Agent, as appropriate, for any losses or
reasonable costs incurred directly as a result of the error or delay but specifically excluding any
and all consequential punitive or other indirect damages or (ii) which is caused by the Servicing
Agent or by any Client-shareholder, Nationwide shall make any adjustment on the Funds' accounting
system necessary to correct such error or delay and the affected party or parties shall be
reimbursed by the Servicing Agent for any losses or reasonable costs incurred directly as a result
of the error or delay, but specifically excluding any and all consequential punitive or other
indirect damages. In the event of any such adjustments on the Funds' accounting system, the
Servicing Agent shall make the corresponding adjustments on its internal record-keeping system. In
the event that errors or delays with respect to the Procedures are contributed to by more than one
party hereto, each party shall be responsible for that portion of the loss or reasonable cost which
results from its error or delay. All parties agree to provide the other parties prompt notice of any
errors or delays of the type referred to herein and to use reasonable efforts to take such action as
may be appropriate to avoid or mitigate any such costs or losses.
