<!-- page 1 -->
# COLLABORATION AGREEMENT
| Field | Value |
|---|---|
| Document Type | Collaboration Agreement |
| Agreement Date | 2002-11-14 |
| Parties | Theravance, Inc. ("Theravance"); Glaxo Group Limited ("GSK"); (Theravance and GSK, a “Party” or together, the “Parties”) |
| Source | CUAD v1 / INNOVIVA,INC_08_07_2014-EX-10.1-COLLABORATION AGREEMENT |

Exhibit 10.1 COLLABORATION AGREEMENT by and between THERAVANCE, INC. and GLAXO GROUP LIMITED Dated:
November 14, 2002
<!-- page 2 -->
TABLE OF CONTENTS ARTICLE 1 DEFINITIONS 1 ARTICLE 2 RIGHTS AND OBLIGATIONS 11 2.1 License Grants
from Theravance to GSK 11 2.1.1 Development License 11 2.1.2 Commercialization License 11 2.1.3
Manufacturing License 11 2.2 Sublicensing and Subcontracting 11 2.3 Trademarks and Housemarks 12
2.3.1 Trademarks 12 2.3.2 Housemarks 12 2.3.3 Ownership of Inventions 12 ARTICLE 3 GOVERNANCE OF
DEVELOPMENT AND COMMERCIALIZATION OF PRODUCTS 13 3.1 Joint Steering Committee 13 3.1.1 Purpose 13
3.1.2 Members; Officers 13 3.1.3 Responsibilities 13 3.1.4 Meetings 14 3.1.5 Decision-Making 14 3.2
Joint Project Committee 15 3.2.1 Purpose 15 3.2.2 Members; Officers 15 3.2.3 Responsibilities 15
3.2.4 Meetings 16 3.2.5 Decision-Making 16 3.3 Minutes of Committee Meetings 16 3.3.1 Distribution
of Minutes 16 3.3.2 Review of Minutes 16 3.3.3 Discussion of Comments 16 3.4 Expenses 17
<!-- page 3 -->
3.5 General Guidelines and Initial Coordination Efforts 17 ARTICLE 4 DEVELOPMENT OF PRODUCTS 17 4.1
Pooling of Compounds 17 4.2 Obligations for Development 17 4.2.1 General; GSK 17 4.2.2 GSK's Funding
Responsibility 18 4.2.3 Decisions with Respect to Products 18 4.2.4 Development Timelines 18 4.3
Replacement Compounds 19 4.4 Transfer of Data 19 4.5 LABA Activity Inside and Outside of the
Collaboration 19 i
<!-- page 4 -->
ARTICLE 5 COMMERCIALIZATION 20 5.1 Global Marketing Plans 20 5.1.1 General 20 5.1.2 Contents of Each
Marketing Plan 20 5.2 Obligations for Commercialization 20 5.3 Commercialization 20 5.3.1 GSK
Responsibility 20 5.3.2 Semi-Annual Reports 21 5.3.3 Exports to the United States 21 ARTICLE 6
FINANCIAL PROVISIONS 21 6.1 Signing Payment; Equity Investment; One-Time Fee 21 6.1.1 Signing
Payment 21 6.1.2 Stock Purchase 21 6.1.3 One-Time Fee for AMI-15471 21 6.1.4 One-Time Fee for Each
Theravance New Compound 22 6.2 Milestone Payments 22 6.2.1 General 22 6.2.2 GSK to Theravance 22
6.2.3 Theravance to GSK 23 6.2.4 Notification and Payment 24 6.3 Payment of Royalties on Net Sales
24 6.3.1 Royalty on Single-Agent Collaboration Products and LABA/ICS Combination Products 24 6.3.2
Royalty Adjustment 25 6.3.3 Royalties on Other Collaboration Products Launched After the LABA/ICS
Combination Product 25 6.4 Royalty Responsibilities; Net Sales Reports 26 6.4.1 Payments to Third
Parties 26 6.4.2 Net Sales Report 26 6.5 GAAP 26 6.6 Currencies 26 6.7 Manner of Payments 26 6.8
Interest on Late Payments 27
<!-- page 5 -->
6.9 Tax Withholding 27 6.10 Financial Records; Audits 27 ARTICLE 7 PROMOTIONAL MATERIALS AND SAMPLES
28 7.1 Promotional Materials 28 7.1.1 Review of Core Promotional Materials 28 7.1.2 Markings of
Promotional Materials 28 7.2 Samples 28 7.3 Statements Consistent with Labeling 28 7.4 Implications
of Change in Control in Theravance 28 ii
<!-- page 6 -->
ARTICLE 8 REGULATORY MATTERS 29 8.1 Governmental Authorities 29 8.2 Filings 29 8.3 Exchange of Drug
Safety Information 29 8.4 Recalls or Other Corrective Action 29 8.5 Events Affecting Integrity or
Reputation 29 ARTICLE 9 ORDERS; SUPPLY AND RETURNS 30 9.1 Orders and Terms of Sale 30 9.2 Supply of
API Compound and Formulated Collaboration Product for Development 30 9.2.1 Supply of API Compound
for Development 30 9.2.2 Supply of Formulated Collaboration Products for Development 30 9.3 Supply
of API Compound for Commercial Requirements 30 9.4 Supply of Collaboration Products for
Commercialization 30 9.5 Inventories 31 ARTICLE 10 CONFIDENTIAL INFORMATION 31 10.1 Confidential
Information 31 10.2 Permitted Disclosure and Use 31 10.3 Publications 31 10.4 Public Announcements
32 10.5 Confidentiality of This Agreement 32 10.6 Termination of Prior Confidentiality Agreements 32
10.7 Survival 32 ARTICLE 11 REPRESENTATIONS AND WARRANTIES; COVENANTS 33 11.1 Mutual Representations
and Warranties 33 11.2 Additional GSK Representations and Warranties 34 11.3 Additional Theravance
Representations and Warranties 34 11.4 Covenants 35 11.5 Disclaimer of Warranty 35
<!-- page 7 -->
ARTICLE 12 INDEMNIFICATION 35 12.1 Indemnification by GSK 35 12.2 Indemnification by Theravance 35
12.3 Procedure for Indemnification 36 12.3.1 Notice 36 12.3.2 Defense of Claim 36 12.4 Assumption of
Defense 37 12.5 Insurance 37 iii
<!-- page 8 -->
ARTICLE 13 PATENTS 37 13.1 Prosecution and Maintenance of Patents 37 13.1.1 Prosecution and
Maintenance of Theravance Patents 37 13.1.2 Prosecution and Maintenance of Patents Covering Joint
Inventions 38 13.1.3 Prosecution and Maintenance of GSK Patents 39 13.1.4 GSK Step-In Rights 39
13.1.5 Theravance Step-In Rights 40 13.1.6 Execution of Documents by Agents 40 13.1.7 Patent Term
Extensions 40 13.2 Patent Infringement 40 13.2.1 Infringement Claims 40 13.2.2 Infringement of
Theravance Patents 40 13.2.3 Infringement of GSK Patents 41 13.3 Notice of Certification 41 13.3.1
Notice 41 13.3.2 Option 41 13.3.3 Name of Party 41 13.4 Assistance 41 13.5 Settlement 41 ARTICLE 14
TERM AND TERMINATION 42 14.1 Term and Expiration of Term 42 14.2 Termination for Material Breach 42
14.3 GSK Right to Terminate Development of a Collaboration Product 42 14.4 GSK Right to Terminate
Commercialization of a Collaboration Product Following First Commercial Sale 42 14.5 Termination of
the Agreement Due to Discontinuation of Development of All Collaboration Products and All Pooled
Compounds 43 14.6 Effects of Termination 43 14.6.1 Effect of Termination for Material Breach 43
14.6.2 Effect of Termination by GSK of Certain Terminated Development Collaboration Product(s) 44
14.6.3 Effect of Termination by GSK of a Terminated Commercialized Collaboration Product 45 14.6.4
Effect of Termination of the Agreement Due to Discontinuation of Development Prior to First
Commercial Sale of All Collaboration Products and All Pooled Compounds 46
<!-- page 9 -->
14.7 License Rights 47 14.8 Milestone Payments 47 14.9 Subsequent Royalties 47 14.10 Accrued Rights;
Surviving Obligations 47 ARTICLE 15 LIMITATIONS RELATING TO THERAVANCE EQUITY SECURITIES 48 15.1
Purchases of Equity Securities 48 15.2 Exceptions for Purchasing Securities of Theravance 48 15.3
Voting 49 15.4 Theravance Voting Securities Transfer Restrictions 50 15.5 Termination of Purchase
Restrictions 50 iv
<!-- page 10 -->
ARTICLE 16 MISCELLANEOUS 50 16.1 Relationship of the Parties 50 16.2 Registration and Filing of This
Agreement 51 16.3 Force Majeure 51 16.4 Governing Law 51 16.5 Attorneys' Fees and Related Costs 51
16.6 Assignment 52 16.7 Notices 52 16.8 Severability 52 16.9 Headings 53 16.10 Waiver 53 16.11
Entire Agreement 53 16.12 No License 53 16.13 Third Party Beneficiaries 53 16.14 Counterparts 53
16.15 Single Closing Condition 54 Schedules 1.19 Criteria for Theravance New Compounds and
Replacement Compounds 6.1.2 Preferred Stock Purchase Agreement v
<!-- page 11 -->
COLLABORATION AGREEMENT This COLLABORATION AGREEMENT ("Agreement") dated November 14, 2002, is made
by and between THERAVANCE, INC., a Delaware corporation, and having its principal office at 901
Gateway Boulevard, South San Francisco, California 94080 ("Theravance"), and GLAXO GROUP LIMITED, a
United Kingdom corporation, and having its principal office at Glaxo Wellcome House, Berkeley
Avenue, Greenford, Middlesex, UB6 0NN, United Kingdom ("GSK"). Theravance and GSK may be referred to
as a "Party" or together, the "Parties". RECITALS WHEREAS, Theravance is currently developing
Long-Acting β2 Adrenoceptor Agonists such as but not limited to TD-3327 and AMI- 15471 for the
treatment and/or prophylaxis of asthma and other respiratory diseases; WHEREAS, GSK is also
currently developing Long-Acting β2 Adrenoceptor Agonists such as but not limited to GW 597901, GW
678007, GW 642444 and GW 774419, as well as other anti-inflammatory compounds, for the treatment
and/or prophylaxis of respiratory disease; WHEREAS, GSK and Theravance desire to pool certain of
their respective development compounds on an exclusive, worldwide basis to commercialize at least
one Long-Acting β2 Adrenoceptor Agonist that can be used as a single agent and/or in combination
with a Long-Acting Inhaled Corticosteroid and potentially other compounds for treatment and/or
prophylaxis of respiratory disease; WHEREAS, GSK and Theravance are willing to undertake research
and development activities and investment and to coordinate such activities and investment as
provided by this Agreement with respect to the Collaboration Products; and WHEREAS, GSK and
Theravance believe that a collaboration pursuant to this Agreement for the development and
commercialization of Collaboration Products would be desirable and compatible with their respective
business objectives. NOW, THEREFORE, in consideration of the foregoing premises and the
representations, covenants and agreements contained herein, Theravance and GSK, intending to be
legally bound, hereby agree as follows: ARTICLE 1 DEFINITIONS For purposes of this Agreement, the
following initially capitalized terms, whether used in the singular or plural, shall have the
following meanings: 1
<!-- page 12 -->
1.1 "AMI-15471" means the Long-Acting β2 Adrenoceptor Agonist designated as such by Theravance and
all pharmaceutically acceptable salts and solvates thereof. 1.2 "Adverse Drug Experience" means any
of: an "adverse drug experience," a "life-threatening adverse drug experience," a "serious adverse
drug experience," or an "unexpected adverse drug experience," as those terms are defined at either
21 C.F.R.(S)312.32 or 21 C.F.R.(S)314.80. 1.3 "Affiliate" of a Party means any Person, whether de
jure or de facto, which directly or indirectly controls, is controlled by, or is under common
control with such Person for so long as such control exists, where "control" means the
decision-making authority as to such Person and, further, where such control shall be presumed to
exist where a Person owns more than fifty percent (50%) of the equity (or such lesser percentage
which is the maximum allowed to be owned by a foreign corporation in a particular jurisdiction)
having the power to vote on or direct the affairs of the entity. 1.4 "API Compound" means bulk
quantities of active pharmaceutical ingredient compound prior to the commencement of secondary
manufacturing resulting in a Collaboration Product. 1.5 "Breaching Party" shall have the meaning set
forth in Section 14.2. 1.6 "Business Day" means any day on which banking institutions in both New
York City, New York, United States and London, England are open for business. 1.7 "Calendar Month"
means for each Calendar Year, each of the one-month periods. 1.8 "Calendar Quarter" means for each
Calendar Year, each of the three month periods ending March 31, June 30, September 30 and December
31; provided, however, that the first calendar quarter for the first Calendar Year shall extend from
the Effective Date to the end of the first complete calendar quarter thereafter. 1.9 "Calendar Year"
means, for the first calendar year, the period commencing on the Effective Date and ending on
December 31 of the calendar year during which the Effective Date occurs, and each successive period
beginning on January 1 and ending twelve (12) consecutive calendar months later on December 31. 1.10
"Change in Control" means, with respect to a Party, any transaction or series of related
transactions following which continuing stockholders of such Party hold less than 50% of the
outstanding voting securities of either such Party or the entity surviving such transaction. 1.11
"Claim" means all charges, complaints, actions, suits, proceedings, hearings, investigations, claims
and demands. 1.12 "Collaboration Product" means any of the Long-Acting β2 Adrenoceptor Agonists
identified in Section 4.1 as Pooled Compounds (including any Theravance New Compounds and
Replacement Compounds, as applicable) which may become Developed and Commercialized subject to and
in accordance with the terms of this Agreement, which such Collaboration Product can be used as a
single agent and/or in combination with other therapeutically active components, including but not
limited to a Long-Acting Inhaled Corticosteroid, for the treatment and prophylaxis of respiratory
diseases. The term 2
<!-- page 13 -->
"Collaboration Product" shall also include any formulation of excipients, stabilizers, propellants,
or other components necessary to prepare and deliver a pharmaceutically effective dose of the Pooled
Compound and any other therapeutically active component together with any delivery device. 1.13
"Commercial Conflict" means a situation where Theravance determines that GSK's decision related to
Development or Commercialization of a Collaboration Product is likely to result in a materially
reduced financial return to Theravance from such Collaboration Product, and that such decision is
not based on the technical profile of the Collaboration Product but primarily on commercial factors
whereby GSK is likely to achieve an increased financial return from a Competing Product owned by
GSK. 1.14 "Commercial Failure" means failure of a Collaboration Product for reasons other than
Technical Failure, based on the determination that such product will result in a net present value
that is materially worse than the net present value for GSK's other prescription pharmaceutical
products, based on GSK's normal and customary procedures for determining net present value for its
own portfolio products. The net present value of a Collaboration Product will be based on forecasted
cash flow from such product not taking into account the cannibalization of sales or profit from any
other GSK product. 1.15 "Commercialization" means any and all activities directed to marketing,
promoting, distributing, offering for sale and selling a Collaboration Product, importing a
Collaboration Product (to the extent applicable) and conducting Phase IV Studies. When used as a
verb, "Commercialize" means to engage in Commercialization. 1.16 "Competing Product" means a product
that is intended for the treatment and/or prophylaxis of respiratory diseases. 1.17 "Confidential
Information" means all secret, confidential or proprietary information, data or Know-How (including
GSK Know-How and Theravance Know-How) whether provided in written, oral, graphic, video, computer or
other form, provided by one Party (the "Disclosing Party") to the other Party (the "Receiving
Party") pursuant to this Agreement or generated pursuant to this Agreement, including but not
limited to, information relating to the Disclosing Party's existing or proposed research,
development efforts, patent applications, business or products, the terms of this Agreement and any
other materials that have not been made available by the Disclosing Party to the general public.
Confidential Information shall not include any information or materials that the Receiving Party can
document with competent written proof: 1.17.1 were already known to the Receiving Party (other than
under an obligation of confidentiality), at the time of disclosure by the Disclosing Party; 1.17.2
were generally available to the public or otherwise part of the public domain at the time of its
disclosure to the Receiving Party; 1.17.3 became generally available to the public or otherwise part
of the public domain after its disclosure or development, as the case may be, and other than through
any act or omission of a Party in breach of such Party's confidentiality obligations under this
Agreement; 3
<!-- page 14 -->
1.17.4 were disclosed to a Party, other than under an obligation of confidentiality, by a Third
Party who had no obligation to the Disclosing Party not to disclose such information to others; or
1.17.5 were independently discovered or developed by or on behalf of the Receiving Party without the
use of the Confidential Information belonging to the other Party. 1.18 "Country" means any generally
recognized sovereign entity. 1.19 "Criteria" means the requirements set forth in Schedule 1.19 that
the Replacement Compounds and Theravance New Compounds must meet to become a Pooled Compound. These
requirements may be amended after the Effective Date by written agreement of the Parties (such
agreement not to be unreasonably withheld by either Party) to take account of any newly established
data or knowledge that has or have arisen since the Effective Date that affect or is likely to
affect same. 1.20 "Designated Foreign Filing" shall have the meaning set forth in Section 13.1.2(b).
1.21 "Development" or "Develop" means preclinical and clinical drug development activities,
including, among other things: test method development and stability testing, toxicology,
formulation, process development, manufacturing scale-up, development-stage manufacturing, current
Good Manufacturing Practices audits, current Good Clinical Practices audits, current Good Laboratory
Practices audits, analytical method validation, manufacturing process validation, cleaning
validation, scale-up and post approval changes, quality assurance/quality control development,
statistical analysis and report writing, preclinical and clinical studies, regulatory filing
submission and approval, and regulatory affairs related to the foregoing. When used as a verb,
"Develop" means to engage in Development. 1.22 "Development Expenses" means the cost of all studies
or activities performed by or on behalf of GSK or any of its Affiliates pursuant to this Agreement.
1.23 "Development Milestone" shall have the meaning set forth in Section 6.2.1. 1.24 "Development
Plan" means the outline plan for each Collaboration Product designed to achieve the Development for
such Collaboration Product, including, without limitation, the nature, number and schedule of
Development activities as well as the estimated resources necessary to implement such activities as
such may be amended in accordance with the terms of this Agreement. 1.25 "Diligent Efforts" means
the carrying out of obligations in a sustained manner consistent with the efforts a Party devotes to
a product of similar market potential, profit potential or strategic value resulting from its own
research efforts, based on conditions then prevailing and as if there were no Competing Product
owned by such Party, with the objective of launching a single agent Collaboration Product and a
combination agent Collaboration Product in accordance with the Development principles more
specifically outlined in Section 4.2.4. Diligent Efforts requires that: (i) each Party promptly
assign responsibility for such obligations to specific employee(s) who are held accountable for
progress and monitor such progress on an on-going basis, (ii) each Party set and consistently seek
to achieve specific and meaningful objectives for carrying out such obligations, and (iii) each
Party consistently make and implement decisions and allocate resources designed to advance progress
with respect to such objectives. 4
<!-- page 15 -->
1.26 "Disclosing Party" shall have the meaning set forth in Section 1.17. 1.27 "Effective Date"
means the first business day following the date on which the last of the conditions contained in
Section 16.15 of this Agreement has been satisfied. 1.28 "Exchange Act" shall have the meaning set
forth in Section 15.1.1. 1.29 "FDA" means the United States Food and Drug Administration and any
successor agency thereto. 1.30 "Field" means human pharmaceutical use of Long-Acting β2 Adrenoceptor
Agonists for the treatment and/or prophylaxis of respiratory diseases. 1.31 "First Commercial Sale"
means the first shipment of commercial quantities of any Collaboration Product sold to a Third Party
by a Party or its sublicensees in any Country after receipt of Marketing Authorization Approval for
such Collaboration Product in such Country. Sales for test marketing, sampling and promotional uses,
clinical trial purposes or compassionate or similar uses shall not be considered to constitute a
First Commercial Sale. 1.32 "Force Majeure Event" shall have the meaning set forth in Section 16.3.
1.33 "Governmental Authority" means any court, tribunal, arbitrator, agency, legislative body,
commission, official or other instrumentality of (i) any government of any Country, (ii) a federal,
state, province, county, city or other political subdivision thereof or (iii) any supranational
body, including without limitation the European Agency for the Evaluation of Medicinal Products.
1.34 "GSK Compound" means a GSK Initially Pooled Compound, any Replacement Compound offered up to
the collaboration by GSK or a GSK non-LABA Compound utilised by GSK for Development purposes in
relation to combination product activity under this Agreement currently owned or subsequently
discovered by GSK and/or its predecessors in title or in-licensed from a Third Party by GSK and/or
its predecessors in title. 1.35 "GSK Initially Pooled Compound" shall mean the chemical entities
individually identified as GW 597901, GW 678007, GW 642444 and GW 774419 and all pharmaceutically
acceptable salts and solvates thereof. 1.36 "GSK Invention" means an Invention that is invented by
an employee or agent of GSK solely or jointly with a Third Party. 1.37 "GSK Know-How" means all
present and future information directly relating to the Collaboration Products, a GSK Compound or
the GSK Inventions, including without limitation all data, records, and regulatory filings relating
to Collaboration Products, that is required for Theravance to perform its obligations or exercise it
rights under this Agreement, and which during the Term are in GSK's or any of its Affiliates'
possession or control and are or become owned by, or otherwise may be licensed to (provided there is
no restriction on GSK thereof), GSK. GSK Know-How does not include any GSK Patents. 5
<!-- page 16 -->
1.38 "GSK non-LABA Compound" means any other compound contributed to the collaboration by GSK
pursuant to Section 4.2.1 for the purpose of developing a combination product. 1.39 "GSK Patents"
means all present and future patents and patent applications including United States provisional
applications and any continuations, continuations-in-part, divisionals, registrations,
confirmations, revalidations, reissues, Patent Cooperation Treaty applications, certificates of
addition, utility models, design patents, petty patents as well as all other intellectual property
related to the application or patent including extensions or restorations of terms thereof,
pediatric use extensions, supplementary protection certificates or any other such right covering the
Pooled Compounds, Collaboration Products, a GSK Compound or the GSK Inventions which are or become
owned by GSK or GSK's Affiliates, or as to which GSK or GSK's Affiliates otherwise are or become
licensed, now or in the future, where GSK has the right to grant the sublicense rights granted to
Theravance under this Agreement, which such patent rights cover the making, having made, use, offer
for sale, sale or importation of the Collaboration Products. 1.40 "Hatch-Waxman Certification" shall
have the meaning set forth in Section 13.3. 1.41 "Hostile Tender Offer" shall have the meaning set
forth in Section 15.2.6. 1.42 "Indemnified Party" shall have the meaning set forth in Section
12.3.1. 1.43 "Indemnifying Party" shall have the meaning set forth in Section 12.3.1. 1.44
"Invention" means any discovery (whether patentable or not) invented during the Term as a result of
research, Development or manufacturing activities and specifically related to a Pooled Compound or
Collaboration Product hereunder. 1.45 "Investigational Authorization" means, with respect to a
Country, the regulatory authorization required to investigate a Collaboration Product in such
Country as granted by the relevant Governmental Authority. 1.46 "Joint Invention" means an Invention
that is invented jointly by employees and/or agents of both Theravance and GSK hereunder and the
patent rights in such Invention. 1.47 "Joint Project Committee" shall have the meaning set forth in
Section 3.2. 1.48 "Joint Steering Committee" shall have the meaning set forth in Section 3.1. 1.49
"LABA/ICS Combination Product" means a product that contains a Pooled Compound and a Long-Acting
Inhaled Corticosteroid for the treatment and/or prophylaxis of respiratory diseases. A LABA/ICS
Combination Product shall also be considered a Collaboration Product. 1.50 "Laws" means all laws,
statutes, rules, regulations (including, without limitation, current Good Manufacturing Practice
Regulations as specified in 21 C.F.R. (S)(S) 210 and 211; Investigational New Drug Application
regulations at 21 C.F.R. (S) 312; NDA regulations at 21 C.F.R. (S) 314, relevant provisions of the
Federal Food, Drug and Cosmetic Act, and other laws and regulations enforced by the FDA), ordinances
and other pronouncements having the binding effect of law of any Governmental Authority. 6
<!-- page 17 -->
1.51 "Litigation Condition" shall have the meaning set forth in Section 12.3.2. 1.52 "Long-Acting β
Adrenoceptor Agonist" or "LABA" means a chemical entity that (i) selectively binds to human β
adrenoceptors and activates human β adrenoceptors at concentrations less than 100 nanomolar and (ii)
has significantly longer activity than salmeterol after inhalation dosing as determined in a guinea
pig acetylcholine bronchoprotection model or similar animal model. 1.53 "Long-Acting Inhaled
Corticosteroid" or "ICS" means a corticosteroid that has duration of action of at least 24 hours
demonstrated in clinical testing. 1.54 "Losses" means any and all damages (including all incidental,
consequential, statutory an treble damages), awards, deficiencies, settlement amounts, defaults,
assessments, fines, dues, penalties, costs, fees, liabilities, obligations, taxes, liens, losses,
lost profits and expenses (including without limitation court costs, interest and reasonable fees of
attorneys, accountants and other experts) incurred by or awarded to Third Parties and required to be
paid to Third Parties with respect to a Claim by reason of any judgment, order, decree, stipulation
or injunction, or any settlement entered into in accordance with the provisions of this Agreement,
together with all documented out-of-pocket costs and expenses incurred in complying with any
judgments, orders, decrees, stipulations and injunctions that arise from or relate to a Claim of a
Third Party. 1.55 "Major Market Country" means each of the United States, Canada, Japan, France,
United Kingdom, Italy, Germany and Spain. 1.56 "Marketing Authorization" means, with respect to a
Country, the regulatory authorization required to market and sell a Collaboration Product in such
Country as granted by the relevant Governmental Authority. 1.57 "Marketing Authorization Approval"
shall mean approval by a Governmental Authority for sale of a Collaboration Product, including any
applicable pricing, final labeling or reimbursement approvals. 1.58 "Marketing Plan" means for each
relevant Collaboration Product the global plan prepared by GSK identifying the core strategic,
commercial and promotional claims and objectives for the specific Collaboration Product as reviewed
and approved under Section 5.1.1. 1.59 "NDA" means a new drug application or supplemental new drug
application or any amendments thereto submitted to the FDA in the United States. 1.60 "NDA
Acceptance" shall mean the written notification by the FDA that the NDA has met all the criteria for
filing acceptance pursuant to 21 C.F.R.(S)314.101. 1.61 "Net Sales" means the gross sales price of a
Collaboration Product sold by GSK, its Affiliates or their licensees (or such licensees' Affiliates)
to a Third Party, less the following to the extent borne by the seller and not taken into account in
determining gross sales price: (a) deduction of cash, trade and quantity discounts actually given;
(b) discounts, refunds, rebates, chargebacks, retroactive price adjustments, and any other
allowances actually given which effectively reduce the net selling price, including institutional
rebate or discount such as Medicare or Medicaid provided in the United States or any similar
organization elsewhere in the world; and 7

2 2

2
<!-- page 18 -->
(c) credits and allowances for product returns actually made. Net Sales shall exclude Samples
distributed in the usual course of business. 1.62 "Net Sales Report" shall have the meaning set
forth in Section 6.4.2. 1.63 "Officers" shall have the meaning set forth in Section 3.1.5(b). 1.64
"Other Combination Product" means any product developed pursuant to this Agreement for the treatment
and/or prophylaxis of respiratory disease that contains a Long-Acting β Adrenoceptor Agonist and
another active agent which is a GSK Compound other than a Long- Acting Inhaled Corticosteroid. 1.65
"Patent Infringement Claim" shall have the meaning set forth in Section 13.2.1. 1.66 "Patent
Infringement Notice" shall have the meaning set forth in Section 13.2.2. 1.67 "Person" means any
natural person, corporation, general partnership, limited partnership, limited liability company,
joint venture, proprietorship or other business organization. 1.68 "Phase I Studies" means that
portion of the Development Plan or Development relating to each Collaboration Product which provides
for the first introduction into humans of such Collaboration Product including small scale clinical
studies conducted in normal volunteers to obtain information on such Collaboration Product's safety,
tolerability, pharmacological activity, pharmacokinetics, drug metabolism and mechanism of action,
as well as early evidence of effectiveness, as more fully defined in 21 C.F.R. (S) 312.21(a). 1.69
"Phase II Studies" means, subject to Section 6.2.2, that portion of the Development Plan or
Development relating to each Collaboration Product which provides for well controlled clinical
trials of such Collaboration Product in patients, including clinical studies conducted in patients
with the condition, and designed to evaluate clinical efficacy and safety for such Collaboration
Product for one or more indications, as well as to obtain an indication of the dosage regimen
required, as more fully defined in 21 C.F.R. (S) 312.21(b). 1.70 "Phase III Studies" means that
portion of the Development Plan or Development relating to each Collaboration Product which provides
for large scale, pivotal, clinical studies conducted in a sufficient number of patients and whose
primary objective is to obtain a definitive evaluation of the therapeutic efficacy and safety of the
Collaboration Product in patients for the particular indication in question that is needed to
evaluate the overall risk-benefit profile of the Collaboration Product and to provide adequate basis
for obtaining requisite regulatory approval(s) and product labeling, as more fully defined in 21
C.F.R. (S) 312.21(c). 1.71 "Phase IV Studies" means a study for a Collaboration Product that is
initiated after receipt of a Marketing Authorization for a Collaboration Product and is principally
intended to support the marketing and Commercialization of such Collaboration Product, including
without limitation investigator initiated trials, clinical experience trials and studies conducted
to fulfill local commitments made as a condition of any Marketing Authorization. 1.72 "Pooled
Compounds" means (i) the four Long-Acting Beta-2 Adrenoceptor Agonists provided by GSK as of the
Effective Date (identified as GW 597901, GW 678007, GW 642444 and GW 774419), (ii) the two
Long-Acting Beta-2 Adrenoceptor Agonists provided by 8

2
<!-- page 19 -->
Theravance as of the Effective Date (identified as TD-3327 and AMI-15471), (iii) the Theravance New
Compounds provided by Theravance pursuant to Section 4.1, and any Replacement Compounds provided by
Theravance or GSK. 1.73 "Product Supplier" means any manufacturer, packager or processor of a
Collaboration Product for development, marketing and sale. 1.74 "Promotional Materials" means the
core written, printed, video or graphic advertising, promotional, educational and communication
materials (other than Collaboration Product labeling) for marketing, advertising and promotion of
the Collaboration Products. 1.75 "Receiving Party" shall have the meaning set forth in Section 1.17.
1.76 "Replacement Compound" means a Long-Acting β2 Adrenoceptor Agonist that meets the Criteria and
is provided by Theravance or GSK, as applicable, (and "GSK Replacement Compound" and "Theravance
Replacement Compound" shall be interpreted accordingly) after the Effective Date to replace a Pooled
Compound for which Development has been discontinued due to Technical Failure. 1.77 "ROW" means
Countries other than the Major Market Countries. 1.78 "Samples" means Collaboration Product packaged
and distributed as a complimentary trial for use by patients in the Territory. 1.79 "SEC" shall have
the meaning set forth in Section 15.1.2. 1.80 "Selectively" means the chemical entity binds human β
adrenoceptors (a) with more than 100 fold greater affinity than it binds other protein targets in
the human body as determined by receptor binding, radioligand displacement or functional in vitro
assays, and (b) more than 5 fold greater than the other human β adrenoceptor subtypes. 1.81
"TD-3327" means the Long-Acting β2 Adrenoceptor Agonist so designated by Theravance and all
pharmaceutically acceptable salts and solvates thereof contributed to the collaboration by
Theravance. 1.82 "Taxes" shall have the meaning set forth in Section 6.9.1. 1.83 "Technical Failure"
means the discontinuation of Development of a Collaboration Product for technical, scientific,
medical or regulatory reasons, such as but not limited to unacceptable preclinical toxicity, or the
inability to demonstrate sufficient Long-Acting β Adrenoceptor Agonist effect in humans, or
demonstration of a side effect profile significantly worse than currently marketed products, or
inability to manufacture API in an acceptable purity or crystalline form, or inability to produce a
metered dose inhaler or dry powder inhaler formulation with acceptable aerosol performance and
stability. 1.84 "Term" means, on a Country-by-Country and Collaboration Product-by-Collaboration
Product basis, the period from the Effective Date until the later of (a) the expiration or
termination of the last Valid Claim of a Patent Right covering the Pooled Compound in such
Collaboration Product in such Country, and (b) fifteen (15) years from First Commercial Sale in such
Country, unless this Agreement is terminated earlier in accordance with Article 14. 9

2

2
<!-- page 20 -->
1.85 "Terminated Collaboration Product" shall mean a Terminated Development Collaboration Product or
a Terminated Commercialized Collaboration Product. 1.86 "Terminated Commercialized Collaboration
Product" shall have the meaning set forth in Section 14.4. 1.87 "Terminated Development
Collaboration Product" shall have the meaning set forth in Section 14.3. 1.88 "Territory" means
worldwide. 1.89 "Theravance Compound" means TD-3327 and AMI-15471, (together the "Theravance
Initially Pooled Compounds"), the two Theravance New Compounds and any Replacement Compound that is
offered up to the collaboration by Theravance. 1.90 "Theravance New Compound" means each of the two
chemical entities meeting the Criteria and provided by Theravance to the collaboration as Pooled
Compounds after the Effective Date pursuant to Section 4.1. 1.91 "Housemark" means the name and logo
of GSK or Theravance or any of their respective Affiliates as identified by one Party to the other
from time to time. 1.92 "Theravance Invention" means an Invention that is invented by an employee or
agent of Theravance solely or jointly with a Third Party. 1.93 "Theravance Know-How" means all
present and future information directly relating to the Collaboration Products, a Theravance
Compound or the Theravance Inventions that is required for GSK to perform its obligations or
exercise its rights under this Agreement, and which during the Term are in Theravance's or any of
its Affiliates' possession or control and are or become owned by, or otherwise may be licensed
(provided there are no restrictions on Theravance thereof) by, Theravance. Theravance Know-How does
not include any Theravance Patents. 1.94 "Theravance Patents" means all present and future patents
and patent applications including United States provisional applications and any continuations,
continuations-in-part, divisionals, registrations, confirmations, revalidations, reissues, Patent
Cooperation Treaty applications, certificates of addition, utility models, design patents, petty
patents as well as all other intellectual property related to the application or patent including
extensions or restorations of terms thereof, pediatric use extensions, supplementary protection
certificates or any other such right covering the Pooled Compounds, the Collaboration Products, a
Theravance Compound or the Theravance Inventions which are or become owned by Theravance or
Theravance's Affiliates, or as to which Theravance or Theravance's Affiliates are or become
licensed, now or in the future, with the right to grant the sublicense rights granted to GSK under
this Agreement, which patent rights cover the making, having made, use, offer for sale, sale or
importation of Collaboration Products. 1.95 "Third Party" means a Person who is not a Party or an
Affiliate of a Party. 1.96 "Third Party Claim" shall have the meaning set forth in Section 12.3.1.
1.97 "United States" means the United States, its territories and possessions. 10
<!-- page 21 -->
1.98 "Valid Claim" means any claim(s) pending in a patent application or in an unexpired patent
which has not been held unenforceable, unpatentable or invalid by a decision of a court or other
governmental agency of competent jurisdiction, unappealable or unappealed within the time allowed
for appeal, and which has not has been admitted to be invalid or unenforceable through reissue or
disclaimer. If in any country there should be two or more such decisions conflicting with respect to
the validity of the same claim, the decision of the higher or highest tribunal shall thereafter
control; however, should the tribunals be of equal rank, then the decision or decisions upholding
the claim shall prevail when the decisions are equal in number, and the majority of decisions shall
prevail when the conflicting decisions are unequal in number. 1.99 "Withholding Party" shall have
the meaning set forth in Section 6.9.1. ARTICLE 2 RIGHTS AND OBLIGATIONS 2.1 License Grants from
Theravance to GSK. 2.1.1 Development License. Subject to the terms of this Agreement, including
without limitation Section 2.2, Theravance grants to GSK, and GSK accepts, an exclusive (except as
to Theravance and its Affiliates) license in the Field under the Theravance Patents, Theravance
Know-How and Theravance's rights in the Joint Inventions to make, have made, use and Develop
Collaboration Products for Commercialization in the Territory. 2.1.2 Commercialization License.
Subject to the terms of this Agreement, including without limitation Section 2.2, Theravance hereby
grants to GSK, and GSK accepts, an exclusive license in the Field under the Theravance Patents,
Theravance Know-How and Theravance's rights in the Joint Inventions to make, have made use, sell,
offer for sale and import Collaboration Products in the Territory. 2.1.3 Manufacturing License.
Subject to the terms of this Agreement, including without limitation Section 2.2, Theravance grants
to GSK an exclusive license in the Field under the Theravance Patents, Theravance Know-How and
Theravance's rights in the Joint Inventions to make and have made API Compound or formulated
Collaboration Product in the Territory. 2.2 Sublicensing and Subcontracting. GSK may sublicense or
subcontract its rights to Develop, Manufacture or Commercialize the Collaboration Products in whole
or in part to one or more of its Affiliates, provided that the rights sublicensed or subcontracted
to such Affiliate shall automatically terminate upon a change of control of such Affiliate in
connection with which such Affiliate ceases to be an Affiliate of GSK. GSK may also sublicense or
subcontract any of GSK's rights to Develop or Manufacture the Collaboration Products, in whole or in
part, to one or more Third Parties. In the event GSK wishes to sublicense or subcontract any of
GSK's rights to Commercialize the Collaboration Products, in whole or in part, to one or more Third
Parties, GSK shall obtain the prior written consent of Theravance, such consent not to be
unreasonably withheld, provided always that no such restriction shall apply in respect of those
countries of the Territory wherein GSK is or has been required under applicable local laws to
appoint a Third Party as its distributor or marketing partner. GSK shall secure all appropriate
covenants, obligations and rights from any such sublicensee or subcontractor granted by it under
this Agreement, including, but not limited to, intellectual property rights and confidentiality
obligations in any such agreement or other relationship, to ensure that such sublicensee can 11
<!-- page 22 -->
comply with all of GSK's covenants and obligations to Theravance under this Agreement. GSK's rights
to sublicense, subcontract or otherwise transfer its rights granted under Section 2.1 are limited to
those expressly set forth in this Section 2.2. 2.3 Trademarks and Housemarks. 2.3.1 Trademarks. The
Collaboration Products shall be Commercialized under trademarks (the "Trademarks") and trade dress
selected by the Joint Project Committee and approved by the Joint Steering Committee. Prior to any
such proposed Trademark(s) being submitted to the Joint Project Committee, GSK shall be responsible
for undertaking their preliminary selection. GSK shall exclusively own all Trademarks, and shall be
responsible for the procurement, filing and maintenance of trademark registrations for such
Trademarks and all costs and expenses related thereto. GSK shall also exclusively own all trade
dress and copyrights associated with the Collaboration Products. Nothing herein shall create any
ownership rights of Theravance in and to the Trademarks or the copyrights and trade dress associated
with the Collaboration Products. 2.3.2 Housemarks. Each Party acknowledges the goodwill and
reputation that has been associated with the other Party's Housemarks over the years, and shall use
such Housemarks in a manner that maintains and promotes such goodwill and reputation and is
consistent with trademark guidelines. Each Party shall take all reasonable precautions and actions
to protect the goodwill and reputation that has inured to the other Party's Housemarks, shall
refrain from doing any act that is reasonably likely to impair the reputation of such Housemarks,
and shall cooperate fully to protect such Housemarks. 2.3.3 Ownership of Inventions. Each Party
shall promptly disclose to the other Party all Inventions made by it during the Term; provided that
GSK will be allowed a reasonable time to file patent applications covering GSK Inventions prior to
disclosing the GSK Invention to Theravance, and Theravance will be allowed a reasonable time to file
patent applications covering Theravance Inventions prior to disclosing the Theravance Invention to
GSK. Theravance shall own all Theravance Inventions and GSK shall own all GSK Inventions. All Joint
Inventions shall be owned jointly by Theravance and GSK, and each Party hereby consents to the
assignment or license or other disposition by the other Party of its joint interests in Joint
Inventions without the need to seek the consent of the other Party to such assignment or license or
other disposition; provided that any such assignment, license or other disposition shall at all
times be subject to the grant of rights and accompanying conditions under Sections 2.1 and 2.2 and
Article 14. The determination of inventorship for Inventions shall be made in accordance with
applicable laws relating to inventorship set forth in the patent laws of the United States (Title
35, United States Code). 12
<!-- page 23 -->
ARTICLE 3 GOVERNANCE OF DEVELOPMENT AND COMMERCIALIZATION OF PRODUCTS 3.1 Joint Steering Committee.
3.1.1 Purpose. The purposes of the Joint Steering Committee shall be (i) to determine the overall
strategy for this collaboration between the Parties and (ii) to coordinate the Parties' activities
hereunder. The Parties intend that their respective organizations will work together and will use
Diligent Efforts to assure success of the collaboration. 3.1.2 Members; Officers. Within thirty (30)
days after the Effective Date, the Parties shall establish a joint steering committee (the "Joint
Steering Committee"), which shall consist of four (4) members, two (2) of whom shall be designated
by each of GSK and Theravance and shall have appropriate expertise, with at least one (1) member
from each Party being at least at a vice president level or higher. Each of GSK and Theravance may
replace any or all of its representatives on the Joint Steering Committee at any time upon written
notice to the other Party. A Party may designate a substitute to temporarily attend and perform the
functions of such Party's designee at any meeting of the Joint Steering Committee. GSK and
Theravance each may, on advance written notice to the other Party, invite non-member representatives
of such Party to attend meetings of the Joint Steering Committee. The Joint Steering Committee shall
be chaired on an annual rotating basis by a representative of either Theravance or GSK, as
applicable, on the Joint Steering Committee, with Theravance providing the first such chairperson.
The chairperson shall appoint a secretary of the Joint Steering Committee, who shall be a
representative of the other Party and who shall serve for the same annual term as such chairperson.
3.1.3 Responsibilities. The Joint Steering Committee shall perform the following functions: (a)
Manage and oversee the Development and Commercialization of the Collaboration Products pursuant to
the terms of this Agreement; (b) Review and approve the Development Plans and the Marketing Plans
for Collaboration Products and any material amendments to the Development Plans and Marketing Plans;
(c) At each meeting of the Joint Steering Committee, review Net Sales for the year-to-date as
available; (d) Review and approve the progress of the Joint Project Committee; (e) Review and
approve the Trademarks selected under Section 2.3; (f) Review and approve "go/no-go" decisions and
other matters referred to the Joint Steering Committee, including, without limitation, the continued
Development of a particular Collaboration Product or the inclusion of Replacement Compounds; (g)
Life cycle management of, and intellectual property protection for, the Collaboration Products; 13
<!-- page 24 -->
(h) In accordance with the procedures established in Section 3.1.5, resolve disputes, disagreements
and deadlocks unresolved by the Joint Project Committee; and (i) Have such other responsibilities as
may be assigned to the Joint Steering Committee pursuant to this Agreement or as may be mutually
agreed upon by the Parties from time to time. 3.1.4 Meetings. The Joint Steering Committee shall
meet in person at least once during every Calendar Year, and more frequently (i) as mutually agreed
by the Parties or (ii) as required to resolve disputes, disagreements or deadlocks in the Joint
Project Committee, on such dates, and at such places and times, as such Parties shall agree;
provided that the Parties shall endeavor to have the first meeting of the Joint Steering Committee
within thirty (30) days after the establishment of the Joint Steering Committee. The Joint Steering
Committee shall arrange to meet in person or convene otherwise to assess and approve any Development
Plans or Marketing Plans, if any, submitted to the Joint Steering Committee in each Calendar Year so
that such plans will be reviewed and approved within thirty (30) days following submission to the
Joint Steering Committee. To the extent any such Development Plans or Marketing Plans are not
approved and need to be reformulated by the Joint Project Committee, such plans shall be reviewed by
the Joint Steering Committee as soon as reasonably practicable after resubmission of same. Meetings
of the Joint Steering Committee that are held in person shall alternate between offices of GSK and
Theravance, or such other place as the Parties may agree. In addition to the annual face to face
meetings the Joint Steering Committee may also be held by means of telecommunications or, video
conferences as deemed appropriate by the Parties. 3.1.5 Decision-Making. (a) The Joint Steering
Committee may make decisions with respect to any subject matter that is subject to the Joint
Steering Committee's decision-making authority and functions as set forth in Section 3.1.3. Except
as specified in Section 3.1.5(b), all decisions of the Joint Steering Committee shall be made by
consensus, with the representatives from each Party presenting a unified position on behalf of such
Party. The Joint Steering Committee shall use Diligent Efforts to resolve the matters within its
roles and functions or otherwise referred to it. (b) With respect to any issue, if the Joint
Steering Committee cannot reach consensus within ten (10) Business Days after the matter has been
brought to the Joint Steering Committee's attention, then such issue shall be referred to the Chief
Executive Officer of Theravance and the Chairman of R&D of GSK (collectively, the "Officers") for
resolution. The Parties accept that the use of the Officers for resolution of any unresolved issues
will be on an exceptional basis. In the event that the use of the Officers occurs on more than two
occasions in any consecutive twelve (12) month period and such disputes are not related to
Commercial Conflict issues, then GSK will from then on retain the final vote within the Joint
Steering Committee for all issues other than Commercial Conflict. If the Officers are unable to
reach consensus within thirty (30) days after the matter has been referred to them, the final
decision on such disputed issue will reside with GSK; provided, however, that if the disputed issue
involves a Commercial Conflict, then the final decision will be made by a mutually acceptable Third
Party mediator. Either Party can initiate such mediation on 30 days written notice to the other
Party. The Parties will use best efforts to agree on a mediator within such 30-day period. Such
mediation will occur as promptly as practicable following selection of the mediator and will be held
in New York, New York. The decision of the mediator will be final and binding on the Parties;
provided that either party shall retain all rights to bring an action against the other for damages
and other monetary relief related to or arising out of the issue decided by the mediator. 14
<!-- page 25 -->
3.2 Joint Project Committee. 3.2.1 Purpose. The purposes of the Joint Project Committee shall be to
manage the Parties' day-to-day activities hereunder. 3.2.2 Members; Officers. Within thirty (30)
days after the Effective Date, the Parties shall establish a Project Committee (the "Joint Project
Committee"), and GSK and Theravance shall designate an equal number of representatives, up to a
maximum total of eight (8) members on such Joint Project Committee, with a maximum of four (4) from
each Party. Each of GSK and Theravance may replace any or all of its representatives on the Joint
Project Committee at any time upon written notice to the other Party. Such representatives shall
include individuals who have the relevant experience and expertise for the next twelve months as
included in the Development Plan for the Collaboration Products. A Party may designate a substitute
to temporarily attend and perform the functions of such Party's designee at any meeting of the Joint
Project Committee. GSK and Theravance each may, on advance written notice to the other Party, invite
non-member representatives of such Party to attend meetings of the Joint Project Committee. The
Joint Project Committee shall be chaired by a representative of GSK. The chairperson shall appoint a
secretary of the Joint Project Committee, who shall be a representative of Theravance. 3.2.3
Responsibilities. The Joint Project Committee shall perform the following functions: (a) Review the
Development Plans as prepared by GSK; (b) On an annual rolling basis beginning within six months of
the Effective Date, update and amend any initial Development Plan and review the Development Plan
for each Collaboration Product for the following Calendar Year so that it can immediately thereafter
submit such proposed Development Plan to the Joint Steering Committee for review and approval; (c)
At each meeting of the Joint Project Committee, review the Development strategy for the
Collaboration Products in the Territory; (d) At each meeting of the Joint Project Committee, review
and recommend to the Joint Steering Committee any material amendments or modifications to the
Development Plans; (e) Coordinate and monitor regulatory strategy and activities for the
Collaboration Products in accordance with Article 8; (f) Review and recommend to the Joint Steering
Committee "go/no-go" decisions for the Development of Collaboration Products; (g) Review the
Marketing Plans where appropriate; (h) Review and recommend to the Joint Steering Committee any
material amendments or modifications to the Marketing Plans; 15
<!-- page 26 -->
(j) Discuss the state of the markets for Collaboration Products and opportunities and issues
concerning the Commercialization of the Collaboration Products, including consideration of marketing
and promotional strategy, marketing research plans, labeling, Collaboration Product positioning and
Collaboration Product profile issues; (k) At each meeting of the Joint Project Committee, review the
status of all Studies conducted on Collaboration Products and any results therefrom; (l) At each
meeting of the Joint Project Committee, review Net Sales for the year-to-date, as available; and (m)
Have such other responsibilities as may be assigned to the Joint Project Committee pursuant to this
Agreement or as may be mutually agreed upon by the Parties through the Joint Steering Committee from
time to time. 3.2.4 Meetings. The Joint Project Committee shall meet at least once during every
Calendar Quarter, and more frequently as GSK and Theravance mutually agree on such dates, and at
such places and times, as such Parties shall agree; provided that the Parties shall endeavor to have
the first meeting of the Joint Project Committee as a face to face meeting within thirty (30) days
after the establishment of the Joint Project Committee. Meetings of the Joint Project Committee that
are held in person shall alternate between the offices of GSK and Theravance, or such other place as
the Parties may agree and such face to face meetings shall occur no less than twice a year. The
remaining meetings may be held by means of telecommunications or video conferences as deemed
appropriate. Following Commercialization of a Collaboration Product in the first Major Market, the
Joint Project Committee shall meet twice a year with only one annual face to face meeting required.
3.2.5 Decision-Making. The Joint Project Committee may make decisions with respect to any subject
matter that is subject to the Joint Project Committee's decision-making authority and functions as
set forth in Section 3.2.3. All decisions of the Joint Project Committee shall be made by consensus,
with the representatives from each Party presenting a unified position on behalf of such Party. If
the Joint Project Committee cannot reach consensus within ten (10) Business Days after it has first
met and attempted to reach such consensus, the matter shall be referred on the eleventh (11 )
Business Day to the Joint Steering Committee for resolution. 3.3 Minutes of Committee Meetings.
Definitive minutes of all committee meetings shall be finalized no later than thirty (30) days after
the meeting to which the minutes pertain as follows: 3.3.1 Distribution of Minutes. Within ten (10)
days after a committee meeting, the secretary of such committee shall prepare and distribute to all
members of such committee draft minutes of the meeting. Such minutes shall provide a list of any
issues yet to be resolved, either within such committee or through the relevant resolution process.
3.3.2 Review of Minutes. The Party members of each committee shall have ten (10) days after
receiving such draft minutes to collect comments thereon and provide them to the secretary of such
committee. 3.3.3 Discussion of Comments. Upon the expiration of such second ten (10) day period, the
Parties shall have an additional ten (10) days to discuss each other's comments and finalize the
minutes. The secretary and chairperson(s) of such committee shall each sign and date 16

th
<!-- page 27 -->
the final minutes. The signature of such chairperson(s) and secretary upon the final minutes shall
indicate each Party's assent to the minutes. 3.4 Expenses. Each Party shall be responsible for all
travel and related costs and expenses for its members and other representatives to attend meetings
of, and otherwise participate on, a committee. 3.5 General Guidelines and Initial Coordination
Efforts. In all matters related to the collaboration established by this Agreement, the Parties
shall strive to balance as best they can the legitimate interests and concerns of the Parties and to
realize the economic potential of Collaboration Products. In all matters relating to this Agreement,
the Parties shall seek to comply with good pharmaceutical and environmental practices. The Parties
intend, following the Effective Date, to organize meetings of internal staff to communicate and
explain the provisions of this Agreement to ensure the efficient and timely Development and
Commercialization of the Collaboration Products. ARTICLE 4 DEVELOPMENT OF PRODUCTS 4.1. Pooling of
Compounds. Subject to and consistent with the further Development principles outlined herein, each
Party will offer a minimum of four (4) identified LABA compounds to this collaboration, with the
intention of commercializing at least one Long-Acting β2 Adrenoceptor Agonist as a single agent
and/or as a LABA/ICS Combination Product. Upon commencement of the collaboration pursuant to this
Agreement, GSK and Theravance will contribute the following LABA compounds as Pooled Compounds to
the collaboration: GSK Compounds GW 597901, GW 678007, GW 642444 and GW 774419 and Theravance
Compounds TD-3327 and AMI-15471. For the avoidance of doubt, it is agreed and hereby acknowledged by
both Parties that the compounds GW 597901, GW 678007, GW 642444 and GW 774419, TD-3327 and AMI-15471
are hereby accepted as Pooled Compounds. Theravance will provide two (2) Theravance New Compounds to
the collaboration within eighteen (18) months of the Effective Date in order to meet the requirement
that Theravance contribute a total of four (4) LABA compounds to the Pooled Compounds. Without
prejudice to the foregoing, GSK will endeavor to provide Theravance, upon Theravance's request and
at GSK's expense and discretion, such assistance as may be reasonably required by Theravance to
achieve this objective, including providing directly or through GSK's vendors, assistance in (i)
chemical process development, (ii) salt selection, (iii) pharmaceutical formulation, (iv)
toxicological evaluation, and (v) API preparation. 4.2 Obligations for Development. 4.2.1 General;
GSK. Under the direction of the Joint Project Committee, specific Pooled Compounds will be
identified from time to time and, as applicable, selected for Development as a Collaboration
Product. The Joint Project Committee will determine the number and extent of Development of the
Pooled Compounds and the criteria to be used for selecting among the eight Pooled Compounds and,
subject to the other terms of this Agreement, will endeavor to move one or more such Collaboration
Products forward in Development. In 17
<!-- page 28 -->
relation to the foregoing, GSK shall have the overall responsibility for, and use Diligent Efforts
in, the performance of all such Development activities which shall include, where applicable,
relevant regulatory filings (as contemplated under Article 8) for any such Collaboration Product
moved forward in Development. Further, GSK shall use Diligent Efforts to advance such Collaboration
Product through Development in accordance with the Go/No-Go checkpoints identified in the then
current Development Plan for such Collaboration Product. GSK shall also use Diligent Efforts to
contribute at least one ICS and/or other non-LABA compound to the collaboration for the purpose of
developing a combination product and Diligent Efforts to develop an optimal inhaled formulation of
Collaboration Product in a device which may be either/or a dry powder inhaler formulation and/or a
metered dose inhaler formulation of the Collaboration Compound and Development activities of such
may continue in parallel. 4.2.2 GSK Funding Responsibility. GSK shall bear all costs and expenses
associated with the Development of Collaboration Products for Commercialization including those
incurred by Theravance (or to which it has become obligated) after the signature date of this
Agreement and which previously have been discussed with and agreed to by GSK and, so far as the
aforementioned Theravance costs are concerned, for the avoidance of doubt, the maximum amount shall
not exceed U.S. $2,940,000. 4.2.3 Decisions with Respect to Products. (a) GSK shall have the sole
discretion with respect to Development decisions for Collaboration Products subject to and in
accordance with Sections 3.1.5, 3.2.5, and 4.3 . (b) Notwithstanding the foregoing, the Parties
acknowledge that Theravance is about to initiate a Phase I Study in two parts, on TD-3327. The
initiation of this study will be approved via the Joint Project Committee in accordance with all
other Development activities. Theravance shall be responsible for the routine monitoring of this
study and will transfer remaining clinical development responsibility for TD-3327 to the Joint
Project Committee on completion of the TD-3327 Phase Ia and Phase Ib Studies. (c) GSK shall provide
the Joint Project Committee with an update report within thirty days of (i) the initiation (i.e.,
first person dosed) of any Study involving a Collaboration Product, and (ii) the last person
dosed/last visit in any Study relating to a Collaboration Product. GSK will provide the Joint
Project Committee with a reasonably detailed "top line results" report within sixty days following
the last person dosed/last visit in any Study involving a Collaboration Product. 4.2.4 Development
Timelines. It is hereby acknowledged that GSK's strategic objective is to move one or more of the
Collaboration Products into Development at the earliest opportunity. GSK will consult with the Joint
Project Committee and will share, modify and further develop all applicable Development Plans and
timelines in that forum. It is recognised that success can be optimised by pursuing a number of
Collaboration Products through various phases of clinical Development up to the point of Technical
or Commercial Failure, and/or until the first Collaboration Product for both single agent and
combination therapy achieves regulatory agency approval. At a strategic level, GSK is committed to
this objective. However, at an operational level it is recognised that internal and external
resources will be constrained from time to time, resulting in the need to prioritise individual
studies and activities relating to Collaboration Products. GSK will use Diligent Efforts to secure
the necessary resource and will keep the Joint Project Committee informed on the progress of
individual studies and activities relating to Collaboration Products as part of any changes to
Development Plans and timelines. 18
<!-- page 29 -->
The current objective of the Collaboration is to achieve Marketing Authorization Approval in the US
and other Major Markets for a Collaboration Product from one of the eight Pooled Compounds which can
be used as a single agent and/or in combination with other therapeutically active components
(including but not limited to a Long Acting Inhaled Corticosteroid) for the treatment and/or
prophylaxis of one or more respiratory diseases by end 2009 for the single agent and 2010 for the
first combination product and Development Plans and timelines will be developed and/or refined in an
effort to achieve this objective. 4.3 Replacement Compounds. If within two years after the Effective
Date, the Development of Collaboration Products containing any two of the Pooled Compounds
contributed by a Party is discontinued due to Technical Failure, it will be the option of the Party
who contributed the discontinued compounds to discover and offer up to the collaboration two
Replacement Compounds as replacements for the discontinued compounds within twelve months following
the discontinuation of the second failed compound. For the avoidance of doubt, any such new compound
that satisfies the Criteria will automatically be accepted as a Pooled Compound in place of the
relevant Party's discontinued compound, subject to Joint Steering Committee approval pursuant to
Section 3.1.3(f). Nothing in the foregoing shall preclude either Party from having the option of
offering up a Replacement Compound for a Pooled Compound at any time during the period referred to
in Section 14.5 (subject to the Criteria being met and Joint Steering Committee approval pursuant to
Section 3.1.3(f)). 4.4 Transfer of Data. As soon as practicable but in no event more than thirty
(30) days after the Effective Date, the Parties shall determine what data and materials relating to
TD-3327 and AMI-15471 are necessary for GSK's Development obligations pursuant to this Article 4,
including any technology transfer required for API Compound manufacturing activities contemplated by
Article 9, and establish a process for transferring copies of such data and material to GSK
(including, to the extent available, in appropriate electronic format) or provide means of access
thereto reasonably acceptable to GSK. 4.5 LABA Activity Inside and Outside of the Collaboration.
4.5.1 The intent of the Parties in respect of the Pooled Compounds is that such Pooled Compounds
remain exclusive to this Collaboration and, subject to Sections 4.5.2 — 4.5.4 and Article 14 below,
no activity in respect of such Pooled Compounds shall be permitted outside of this Agreement. 4.5.2
Subject to Article 14 and to Section 4.5.4, if prior to First Commercial Sale of a GSK Initially
Pooled Compound or a GSK Replacement Compound, Development of such compound is discontinued under
this Agreement ("GSK Discontinued Compound"), all rights in respect of such GSK Discontinued
Compound shall revert in full to GSK and such GSK Discontinued Compound shall automatically fall
outside of this Agreement except that (i) GSK shall thereafter be prohibited from carrying out any
further clinical Development work or clinical activity in respect of such GSK Discontinued Compound
inside the Field for at least four (4) years after the termination of this Agreement, and (ii) for
the avoidance of doubt, GSK shall pay to Theravance a royalty on Net Sales of any such GSK
Discontinued Compound in accordance with Section 14.9. 4.5.3 Subject to Article 14 and Section
4.5.4, if prior to First Commercial Sale of a Theravance Compound, Development of such compound is
discontinued under this Agreement ("Theravance Discontinued Compound"), all rights in respect of
such Theravance Discontinued Compound shall revert in full to Theravance and such Theravance
Discontinued Compound shall 19
<!-- page 30 -->
automatically fall outside of this Agreement except that (i) Theravance thereafter shall be
prohibited from carrying out any further clinical Development work or clinical activity in respect
of such Theravance Discontinued Compound inside the Field until after the termination of this
Agreement, and (ii) for the avoidance of doubt, Theravance shall pay to GSK a royalty on Net Sales
of any such Theravance Discontinued Compound in accordance with Section 14.9. 4.5.4 Notwithstanding
Sections 4.5.2 and 4.5.3, for so long as there is one Collaboration Product being Developed under
this Agreement, neither Party shall carry out clinical Development inside the Field with any Long
Acting B2 Adrenoceptor Agonist that is not a Pooled Compound under this Agreement; provided,
however, that this restriction shall not apply to any compound or product (including new product
line extensions and/or re-formulation work) where the original compound or product is, as of the
date of signature of this Agreement, already Commercialized. ARTICLE 5 COMMERCIALIZATION 5.1 Global
Marketing Plans. 5.1.1 General. The Joint Project Committee shall be responsible for reviewing and
approving a Global Marketing Plan for each Collaboration Product ("Marketing Plan"). Each Marketing
Plan shall define the goals and objectives for Commercializing the Collaboration Products in the
pertinent Calendar Year consistent with the applicable Development Plan. 5.1.2 Contents of Each
Marketing Plan. The Marketing Plan for each Collaboration Product shall be prepared during the
Calendar Year wherein, and where applicable, Phase III Studies for such Collaboration Product have
commenced and shall be a rolling, three year plan, updated annually and shall contain at a minimum
and as appropriate to current knowledge: (a) Results of market research and strategy, including
market size, dynamics, growth, customer segmentation, customer targeting, competitive analysis and
global Collaboration Product positioning; (b) Annual sales forecasts for Major Market Countries; (c)
For each major Market Country (as available): sales plans which will include target number of sales
representatives, detail order and target number of details (d) Core, global advertising and
promotion programs and strategies, including literature, media plans, symposia and speaker programs;
and (e) Core Phase III/Phase IV Studies to be conducted 5.2 Obligations for Commercialization. GSK
shall use Diligent Efforts to Commercialize the Collaboration Products. 5.3 Commercialization. 5.3.1
GSK Responsibility. GSK shall have the sole right and responsibility for Commercialization of
Collaboration Products for distribution and sale. GSK shall bear all costs 20
<!-- page 31 -->
and expenses associated with the Commercialization of Collaboration Products for sale or
distribution. (a) GSK shall have the sole right and responsibility to distribute, sell, record sales
and collect payments for Collaboration Products. (b) GSK shall have the sole right and
responsibility for establishing and modifying the terms and conditions with respect to the sale of
Collaboration Products, including, without limitation, the price or prices at which the
Collaboration Products will be sold, any discount applicable to payments or receivables, and similar
matters. (c) GSK will be responsible for storage, order receipt, order fulfillment, shipping and
invoicing of Collaboration Products. 5.3.2 Semi-Annual Reports. GSK shall provide the Joint Project
Committee reports semi-annually. Such reports shall set forth in summary form the results of GSK's
Commercialization activities performed during such semi-annual period in the Major Markets. 5.3.3
Exports to the United States. To the extent permitted by Law, the Parties shall use Diligent Efforts
to prevent the Collaboration Products distributed for sale in a particular Country other than the
United States from being exported to the United States for sale. ARTICLE 6 FINANCIAL PROVISIONS 6.1
Signing Payment; Equity Investment; One-Time Fee. 6.1.1 Signing Payment. In partial consideration
for the acquisition of license rights under the Theravance Patents and the Theravance Know-How by
GSK under this Agreement, GSK shall on the Effective Date, pay to Theravance a non-creditable,
non-refundable amount of Ten Million United States Dollars (U.S. $10,000,000). 6.1.2 Stock Purchase.
On the Effective Date, GSK will purchase 4,000,000 shares of Theravance Series E Preferred Stock at
a price of U.S.$10.00 per share for total consideration of Forty Million United States Dollars (U.S.
$40,000,000). Such purchase will be made pursuant to the Preferred Stock Purchase Agreement attached
hereto as Schedule 6.1.2. 6.1.3 One-Time Fee for AMI-15471. Within thirty days following receipt by
GSK of Theravance's written notification of the decision by Theravance to nominate AMI-15471 as a
"development candidate," and in further partial consideration for the acquisition of license rights
under the Theravance Patents and the Theravance Know-How by GSK under this Agreement, GSK shall pay
to Theravance a non-creditable, non-refundable amount of Five Million United States Dollars
(U.S.$5,000,000). AMI-15471 will be declared a development candidate when Theravance (a) completes a
study demonstrating lack of activity in the hERG assay (as per the Criteria in Schedule 1.19), and
(b) establishes AMI- 15471 in a stable crystalline form. 21
<!-- page 32 -->
6.1.4 One-Time Fee for Each Theravance New Compound. Within thirty days following the acceptance by
the Joint Project Committee or the Joint Steering Committee of each of the two Theravance New
Compounds to be contributed to the collaboration pursuant to Section 4.1, and in further partial
consideration for the acquisition of license rights under the Theravance Patents and the Theravance
Know-How by GSK under this Agreement, GSK shall pay to Theravance a non-creditable, non-refundable
amount of Five Million United States Dollars (U.S.$5,000,000) for each such Theravance New Compound.
6.2 Milestone Payments. 6.2.1 General. In further consideration of the covenants and agreements
contained herein, the Parties shall also pay to each other the payments set forth below for each
such Development milestone referred to therein (each, a "Development Milestone"); provided always
that each such payment shall be made only one time for each Collaboration Product regardless of how
many times such Development Milestones are achieved for such Collaboration Product, and no payment
shall be owed for a Development Milestone which is not reached (except that, upon achievement of a
Development Milestone for a particular Collaboration Product, any previous Development Milestone for
that Collaboration Product for which payment was not made shall be deemed achieved and payment
therefore shall be made); provided further that, in the event that more than one Development
Milestone is achieved with respect to the same Collaboration Product at one time, then all
applicable payments under Section 6.2 shall be made. For example, if TD-3327 as a single-agent
Collaboration Product and a LABA/ICS Combination Product that contains TD- 3327 are approved in the
same Marketing Authorization Approval, then in addition to the relevant milestone for the
single-agent TD-3327 Collaboration Product, the relevant milestone for the LABA/ICS Combination
Product shall be paid simultaneously. In the event of termination of development of a particular
Collaboration Product and an alternative Collaboration Product replaces such Terminated
Collaboration Product then milestone payments for such replacement compound shall not be paid in
respect of milestones already achieved by the Terminated Collaboration Product. For example, if
development of TD-3327 is terminated and TD-3327 is replaced by a another Collaboration Product
which contains a Theravance compound, milestone payments for such replacement compound will only
commence for milestones achieved that have not already been achieved by TD-3327. 6.2.2 GSK to
Theravance. GSK shall make the following milestone payments to Theravance upon the achievement of
the indicated Development Milestone for the first Collaboration Product in which the Long-Acting β2
Adrenoceptor Agonist is a Theravance Compound, and for the first LABA/ICS Combination Product in
which the Long-Acting β2 Adrenoceptor Agonist is a Theravance Compound: Milestone

Amount Initiation of Phase I *

U.S.$10 Million Initiation of Phase IIa**

U.S.$10 Million Initiation of Phase IIb**

U.S.$5 Million Initiation of Phase III

U.S.$25 Million 22

Milestone

Amount Registration

U.S.

U.S.$30 Million Europe

U.S.$15 Million Japan

U.S.$10 Million Launch

U.S.

U.S.$30 Million Europe
<!-- page 33 -->
U.S.$15 Million Japan

U.S.$10 Million Annual Worldwide Net Sales over U.S.$500 Million for single agent Collaboration
Product

U.S.$10 Million per year for first five years for single agent Collaboration Product

Annual Worldwide Net Sales over U.S.$500 Million for LABA/ICS Combination Product

U.S.$20 Million per year for first five years for LABA/ICS Combination Product

* GSK will make a Phase I milestone payment for both TD-3327 and AMI-15471. The Phase I milestone
for TD-3327 is defined as initiation of the methacholine challenge portion of the Phase I Study in
normal volunteers and will trigger a payment of U.S. $10 Million. The Phase I milestone for
AMI-15471 is defined as initiation of the first Phase I Study in normal volunteers and will trigger
a payment of U.S. $10 Million. **Phase IIa is defined as initiation of the first single dose study
in patients where such study is statistically powered for efficacy based on FEV . Phase IIb is
defined as initiation of the first four (4) week dosing, safety and efficacy study in patients.
Other Combination Products that contain a Long-Acting β2 Adrenoceptor Agonist that is a Theravance
Compound are not subject to milestone payments by GSK only if all milestone payments through launch
have otherwise been made to Theravance from any Collaboration Product as both a single-agent and as
a combination product. The Parties intend that if the collaboration is successful in launching at
least two Collaboration Products that contain a Theravance Compound, Theravance be paid the
applicable milestones through launch for two products. If GSK, either individually or as a member of
the Joint Steering Committee or Joint Project Committee, discontinues the Development of a single
agent Collaboration Product that is a Theravance Compound for reasons other than Technical Failure,
and such compound is the LABA in a LABA/ICS Combination Product or in an Other Combination Product,
it will compensate Theravance for the unpaid milestone payments otherwise due to Theravance under
Section 6.2.2 by adding the unpaid milestone amounts for such discontinued single agent product onto
the corresponding milestone payments for the relevant Combination Product. 6.2.3 Theravance to GSK.
Theravance shall make the following milestone payments to GSK upon the achievement of the indicated
Development Milestone for the first Collaboration Product in which the Long-Acting β2 Adrenoceptor
Agonist is a GSK Compound 23

1

and for the first LABA/ICS Combination Product in which the Long-Acting β2 Adrenoceptor Agonist is a
GSK Compound: Milestone

Amount Registration

US

U.S.$30 Million Europe

U.S.$15 Million Japan

U.S.$10 Million Launch

US

U.S.$30 Million Europe
<!-- page 34 -->
U.S.$15 Million Japan

U.S.$10 Million Other Combination Products that contain a Long-Acting β2 Adrenoceptor Agonist that
is a GSK Compound are not subject to milestone payments by Theravance only if all milestone payments
through launch have otherwise been made to GSK from any Collaboration Product as both a single-agent
and as a combination product. The Parties intend that if the collaboration is successful in
launching at least two Collaboration Products that contain a GSK Compound, GSK be paid the
applicable milestones through launch for two products. 6.2.4 Notification and Payment. In the event
a Party achieves a Development Milestone, such Party shall promptly, but in no event more than ten
(10) days after the achievement of each such Development Milestone, notify the other Party in
writing of the achievement of same. For all Development Milestones achieved, each Party shall
promptly, but in no event more than thirty (30) days after notification of the achievement of each
such Development Milestone, remit payment to the other Party for such Development Milestone. 6.3
Payment of Royalties on Net Sales. 6.3.1 Royalty on Single-Agent Collaboration Products and LABA/ICS
Combination Products. Within twenty (20) days after the end of each Calendar Quarter , GSK shall pay
Theravance royalty payments based on Net Sales in such Calendar Quarter during the Term as follows:
On total Annual Worldwide Net Sales up to and including U.S. $3 Billion:

15 % On total Annual Worldwide Net Sales greater than U.S. $3 Billion:

5 % it being understood that Net Sales of a single agent Collaboration Product will be combined with
Net Sales of a LABA/ICS Combination Product for purposes of the foregoing royalty calculation. The
quarterly royalty payments made under this Section 6.3.1 may be based on estimated Net Sales. Within
thirty (30) days after the end of each Calendar Quarter, GSK shall calculate the actual amount of
Net Sales for the previous Calendar Quarter and either credit or debit the difference between such
actual and projected amount on the succeeding Calendar Quarter's royalty payment to Theravance. As
soon as practical following the end of each Calendar Month, but in no event later than the 10
business day of the following month, GSK will provide Theravance with an estimate of Net Sales for
such Calendar Month. 24

th
<!-- page 35 -->
The royalties payable under this Section 6.3 shall be paid on a Country-by-Country basis from the
date of first commercial sale of each Collaboration Product in a particular Country for the Term of
the Collaboration. 6.3.2 Royalty Adjustment. The 15% royalty payable on the first U.S. $3 Billion of
total annual worldwide Net Sales under this Section 6.3 shall be reduced to 12% if all of the
following occur: (i) all Theravance Compounds are discontinued by the collaboration for Technical
Failure; (ii) Theravance only contributes one Theravance New Compound to the collaboration within 18
months following the Effective Date; and (iii) the Collaboration Product upon which the royalty is
payable contains a LABA that is one of the GSK Initially Pooled Compounds. The 15% royalty payable
on the first U.S. $3 Billion of total annual worldwide Net Sales under this Section 6.3 shall be
reduced to 10% if all of the following occur: (i) all Theravance Compounds are discontinued by the
collaboration for Technical Failure; (ii) Theravance fails to contribute any Theravance New Compound
to the collaboration within 18 months following the Effective Date; and (iii) the Collaboration
Product upon which the royalty is payable contains a LABA that is one of the GSK Initially Pooled
Compounds. Nothing in the foregoing shall affect other royalties owed under this Agreement. 6.3.3
Royalties on Other Collaboration Products Launched After the LABA/ICS Combination Product. For any
Other Collaboration Product launched after the LABA/ICS Combination Product, GSK shall within twenty
(20) days after the end of each Calendar Quarter, pay Theravance royalty payments based on Net Sales
in such Calendar Quarter during the Term as follows:

Annual Net Sales

Percentage Royalty

Up to U.S.$750 Million

6.5 % Additional Net Sales up to U.S.$1.25 Billion

8.0 % Additional Net Sales up to U.S.$2.25 Billion

9.0 % Net Sales exceeding U.S.$2.25 Billion

10.0 % For the avoidance of doubt, the Parties agree that the royalty set forth in this Section
6.3.3 shall only be effective if GSK has launched and is selling a LABA/ICS Combination Product that
is subject to the royalties under Section 6.3.1. If GSK is not selling a LABA/ICS Combination
Product, then the royalty set forth in Section 6.3.1 shall apply to the first Other Combination
Product launched by GSK, provided such Other Combination Product does not contain a product
in-licensed by GSK; if such Other Combination Product contains a product in-licensed by GSK, then
the royalty payable to Theravance will be reduced by 50% of any running royalties paid to a Third
Party, provided that in no case will the royalty payable to Theravance be less than set forth in
this Section 6.3.3. 25
<!-- page 36 -->
6.4 Royalty Responsibilities; Net Sales Reports. 6.4.1 Payments to Third Parties. (a) If, as a
result of a settlement approved by both Parties or as a result of a final non-appealable judgment,
GSK is required to pay any amounts to a Third Party directly because using or selling a Theravance
Compound is found to infringe the rights of such Third Party, GSK shall deduct fifty percent (50%)
of any such amount paid to such Third Party from the royalties otherwise due Theravance for the
Collaboration Product containing such Theravance Compound, provided in no event shall such reduction
reduce the royalties otherwise payable to Theravance during any Calendar Year by more than fifty
percent (50%); provided, further, that any excess deduction shall be carried over into subsequent
years of this Agreement until the full deduction is taken. (b) GSK shall pay any amounts owed to a
Third Party as a result of the use of GSK Patents or GSK Know-How with respect to sales of
Collaboration Products and shall not deduct any of such amounts from the royalties due Theravance.
The foregoing is subject to Section 6.3.3. 6.4.2 Net Sales Report. Within thirty (30) days after the
end of each Calendar Quarter, GSK shall submit to Theravance a written report setting forth Net
Sales in the Territory on a Country-by-Country and Collaboration Product-by-Collaboration Product
basis during such Calendar Quarter, total royalty payments due Theravance, relevant market share
data and any payments made to any Third Party pursuant to Section 6.4.1(a) (each a "Net Sales
Report"). 6.5 GAAP. All financial terms and standards defined or used in this Agreement for sales or
activities occurring in the United States shall be governed by and determined in accordance with
United States generally accepted accounting principles, consistently applied. Except as otherwise
set forth herein, all financial terms and standards defined or used in this Agreement for sales or
activities occurring outside the United States shall be governed by and determined in accordance
with United Kingdom generally accepted accounting principles, consistently applied. 6.6 Currencies.
Monetary conversion from the currency of a foreign country in which Collaboration Product is sold
into US Dollars shall be calculated in accordance with either (a) the methodology referred to in
GSK's then current Corporate Finance Reporting Policy or (b) as otherwise may be mutually agreed by
the Parties. The following summarizes GSK's current methodology applied in accordance with its
current Corporate Finance Reporting System: the cumulative year-to-date Average Rates are calculated
by determining the average of (i) the preceding 31st December Spot Rate plus (ii) the Closing Spot
Rates of the relevant months to date using the exact figures provided by the Reuters 2000 download.
(By way of example, the Average Rate for the five months from January, 2002 to May, 2002 would be
computed by taking the sum of the Spot Rates for the preceding 31st December, 2001, plus the
month-end Spot Rates for the five months to May, 2002, divided by six). 6.7 Manner of Payments. All
sums due to either Party under this Section 6 shall be payable in United States Dollars by bank wire
transfer in immediately available funds to such bank account(s) as each of GSK and Theravance shall
designate. GSK shall notify Theravance as to the date and amount of any such wire transfer to
Theravance at least five (5) Business Days prior to such transfer. Theravance shall notify GSK as to
the date and amount of any such wire transfer to GSK at least five (5) Business Days prior to such
transfer. 26
<!-- page 37 -->
6.8 Interest on Late Payments. If either Theravance or GSK shall fail to make a timely payment
pursuant to this Article 6, any such payment that is not paid on or before the date such payment is
due under this Agreement shall bear interest, to the extent permitted by applicable law, at the
average one-month London Inter-Bank Offering Rate (LIBOR) for the United States Dollar as reported
from time to time in The Wall Street Journal, effective for the first date on which payment was
delinquent and calculated on the number of days such payment is overdue or, if such rate is not
regularly published, as published in such source as the Joint Steering Committee agrees. 6.9 Tax
Withholding. 6.9.1 Any taxes, levies or other duties ("Taxes") paid or required to be withheld under
the appropriate local tax laws by one of the Parties ("Withholding Party") on account of monies
payable to the other Party under this Agreement shall, subject to Sections 6.9.2 and 6.9.3, be
deducted from the amount of monies otherwise payable to the other Party under this Agreement. The
Withholding Party shall secure and send to the other Party within a reasonable period of time proof
of any such Taxes paid or required to be withheld by Withholding Party for the benefit of the other
Party. 6.9.2 If GSK or any GSK Affiliate is or becomes liable to withhold any taxes from payments
made to Theravance under Sections 6.1 and 6.2 of this Agreement, then GSK shall pay to Theravance an
amount equal to the amount GSK or the applicable GSK Affiliate owes to the relevant tax authority
provided always that if Theravance is able to obtain credit for any taxes withheld ("Creditable
Taxes") against any liability to tax either in the year in which the receipt is taxable or any
preceding years, Theravance shall reimburse to GSK an amount equivalent to the Creditable Taxes.
Theravance shall provide GSK with such reasonable evidence as GSK may reasonably request to
determine whether the taxes are creditable against taxes payable by Theravance. 6.9.3 If GSK or any
GSK Affiliate is or becomes liable to withhold any taxes from payments made to Theravance under
Section 6.3, then such taxes may be withheld by GSK or the applicable GSK Affiliate up to a limit of
five percent (5%) of the relevant payment. GSK shall pay to Theravance an amount equal to the amount
GSK owes to the relevant tax authority in excess of such five percent (5%) provided always that if
Theravance is able to obtain credit for any taxes withheld ("Creditable Taxes") against any
liability to tax either in the year in which the receipt is taxable or any preceding years,
Theravance shall reimburse to GSK an amount equivalent to the Creditable Taxes. Theravance shall
provide GSK with such reasonable evidence as GSK may reasonably request to determine whether the
taxes are creditable against taxes payable by Theravance. 6.10 Financial Records; Audits. GSK shall
keep, and shall cause its Affiliates and sublicensees to keep, such accurate and complete records of
Net Sales as are necessary to determine the amounts due to Theravance under this Agreement and such
records shall be retained by GSK or any of its Affiliates or sublicensees (in such capacity, the
"Recording Party") for at least the three preceding Calendar Years to which the Net Sales relate.
During normal business hours and with reasonable advance notice to the Recording Party, such records
shall be made available for inspection, review and audit, at the request and expense of Theravance,
by an independent certified public accountant, or the local equivalent, appointed by Theravance and
reasonably acceptable to the Recording Party for the sole purpose of verifying the accuracy of the
Recording Party's accounting reports and payments made or to be made pursuant to this 27
<!-- page 38 -->
Agreement; provided, however that such audits may not be performed by Theravance more than once per
Calendar Year. Such accountants shall be instructed not to reveal to Theravance the details of its
review, except for (i) such information as is required to be disclosed under this Agreement and (ii)
such information presented in a summary fashion as is necessary to report the accountants'
conclusions to Theravance, and all such information shall be deemed Confidential Information of the
Recording Party; provided, however, that in any event such information may be presented to
Theravance in a summary fashion as is necessary to report the accountants' conclusions. All costs
and expenses incurred in connection with performing any such audit shall be paid by Theravance
unless the audit discloses at least a five percent (5%) shortfall, in which case the Recording Party
will bear the full cost of the audit for such Calendar Year. Theravance will be entitled to recover
any shortfall in payments due to it as determined by such audit, plus interest thereon calculated in
accordance with Section 6.8, or alternatively shall have the right to offset and deduct any such
shortfall in payments due to it against payments Theravance is otherwise required to make to the
Reporting Party under this Agreement. The documents from which were calculated the sums due under
this Article 6 shall be retained by the relevant Party during the Term. ARTICLE 7 PROMOTIONAL
MATERIALS AND SAMPLES 7.1 Promotional Materials. 7.1.1 Review of Core Promotional Materials. Subject
to applicable Law, in accordance with the direction of the Joint Project Committee, the Parties will
jointly, through consultation and with the assistance of each other, review the core Promotional
Materials. The relevant legal or regulatory personnel of each Party shall have the opportunity to
review and comment on all such core Promotional Materials prior to use and such comments shall be
considered by the Joint Project Committee in the review of such core Promotional Materials. 7.1.2
Markings of Promotional Materials. To the extent required by applicable Law, and further to the
extent reasonably practicable, all Promotional Materials will indicate the contribution of the
license from Theravance for the Collaboration Products. Subject to the foregoing, the Theravance
Housemark and the GSK Housemark shall both be given exposure and prominence on all promotional
materials, labelling, package inserts or outserts and packaging for the Collaboration Products. 7.2
Samples. Packaging, package inserts and outserts, Sample labels and labeling shall each contain
reference to Theravance and GSK indicating, in the case of Theravance, the contribution of the
license from Theravance for the Collaboration Products, if appropriate, and as may be required under
applicable FDA rules and regulations. 7.3 Statements Consistent with Labeling. GSK shall ensure that
its sales representatives detail the Collaboration Products in a fair and balanced manner and
consistent with the requirements of the Federal Food, Drug and Cosmetic Act of the United States, as
amended, including, but not limited to, the regulations at 21 C.F.R. (S) 202 in the United States.
7.4 Implications of Change in Control in Theravance. In the event that there is a Change in Control
of Theravance and the references contemplated in Sections 7.1.2 and 7.2 are no longer made to
"Theravance,", then other than to the extent required by applicable Law, GSK 28
<!-- page 39 -->
shall have the right, not to be unreasonably exercised, to terminate its obligations under Sections
7.1 and 7.2. ARTICLE 8 REGULATORY MATTERS 8.1 Governmental Authorities. GSK shall be solely
responsible for communicating with Governmental Authorities and will keep Theravance informed,
through the Joint Project Committee and Joint Steering Committee, of any significant issue or issues
arising therefrom. 8.2 Filings. GSK shall also be solely responsible for filing drug approval
applications for Collaboration Products and will use Diligent Efforts in seeking appropriate
approvals in those Countries of the Territory for Collaboration Products as GSK reasonably
determines and sees fit. Such regulatory documents for each filing shall be centralized and held at
the offices of GSK. Theravance shall provide such reasonable assistance as may be required by GSK
where liaison between the Parties is, or may be, necessary to enable GSK to fulfill its
responsibilities hereunder. GSK shall be responsible for maintaining the Approvals obtained under
this Section and shall solely own all such Approvals in the Territory. GSK shall be fully
responsible for bearing all costs and expense associated with undertaking and completing said
registration activities in the Territory, including but not limited to the costs of preparing and
prosecuting applications for such Approvals and fees payable to regulatory agencies in obtaining and
maintaining same. 8.3 Exchange of Drug Safety Information. Subject to the second sentence of this
Section 8.3, GSK shall be responsible for recording, investigating, summarizing, notifying,
reporting and reviewing all Adverse Drug Experiences in accordance with Law and shall require that
its Affiliates (i) adhere to all requirements of applicable Laws which relate to the reporting and
investigation of Adverse Drug Experiences, and (ii) keep the Joint Project Committee apprised on a
regular basis of such matters arising therefrom. The foregoing shall be subject to any of
Theravance's own clinical safety obligations mandated by Law as a result of its ongoing Development
activity related to TD-3327 (as such activity is more specifically referred to in Article 4) and, in
acknowledgement of this, it is thereby contemplated that the Parties' respective clinical safety
groups may need to discuss and agree, at the appropriate time after the Effective Date, appropriate
safety data exchange procedures related to same. 8.4 Recalls or Other Corrective Action. Each Party
shall, as soon as practicable, notify the other Party of any recall information received by it in
sufficient detail to allow the Parties to comply with any and all applicable Laws. GSK shall
promptly notify Theravance of any material actions to be taken by GSK with respect to any recall or
market withdrawal or other corrective action related to a Collaboration Product prior to such action
to permit Theravance a reasonable opportunity to consult with GSK with respect thereto. All costs
and expenses with respect to a recall, market withdrawal or other corrective action shall be borne
by GSK unless such recall, market withdrawal or other corrective action was due solely to the
negligence, willful misconduct or breach of this Agreement by Theravance. GSK shall have sole
responsibility for and shall make all decisions with respect to any recall, market withdrawals or
any other corrective action related to the Collaboration Products. 8.5 Events Affecting Integrity or
Reputation. During the Term, the Parties shall notify each other immediately of any circumstances of
which they are aware and which could impair the integrity and reputation of the Collaboration
Products or if a Party is threatened by the 29
<!-- page 40 -->
unlawful activity of any Third Party in relation to the Collaboration Products, which circumstances
shall include, by way of illustration, deliberate tampering with or contamination of the
Collaboration Products by any Third Party as a means of extorting payment from the Parties or
another Third Party. In any such circumstances, the Parties shall use Diligent Efforts to limit any
damage to the Parties and/or to the Collaboration Products. The Parties shall promptly call a Joint
Steering Committee meeting to discuss and resolve such circumstances. ARTICLE 9 ORDERS; SUPPLY AND
RETURNS 9.1 Orders and Terms of Sale. Except as otherwise expressly stated in this Agreement, GSK
shall have the sole right to (i) receive, accept and fill orders for the Collaboration Products,
(ii) control invoicing, order processing and collection of accounts receivable for the Collaboration
Products sales, (iii) record the Collaboration Products sales in its books of account, and (iv)
establish and modify the commercial terms and conditions with respect to the sale and distribution
of the Collaboration Products, including without limitation matters such as the price at which the
Collaboration Products will be sold and whether any discounts, rebates or other deductions should be
made, paid or allowed. 9.2 Supply of API Compound and Formulated Collaboration Product for
Development. 9.2.1 Supply of API Compound for Development. Subject to the terms and conditions of
this Agreement, GSK shall conduct or have conducted any chemical process development required to
develop a commercially acceptable process for making API Compound and obtain supply for worldwide
requirements of API Compound. Notwithstanding the foregoing, Theravance may transfer to GSK, at
cost, whatever supply it has on hand of TD-3327 API and/or AMI-15471 API and/or intermediate
materials for API manufacture, within specification as of the Effective Date, such cost not to
exceed U.S. $1,230,000. API Compound requirements for Development activities shall be set forth in
the relevant Development Plan and shall be periodically updated by the Joint Project Committee.
9.2.2 Supply of Formulated Collaboration Products for Development. Subject to the terms and
conditions of this Agreement, GSK shall obtain supply for worldwide requirements of formulated
Collaboration Products. Notwithstanding the foregoing, Theravance agrees to transfer to GSK whatever
supply it has on hand of formulated TD-3327, within specification, at cost as of the Effective Date,
such cost not to exceed U.S. $175,000. Formulated Collaboration Product requirements for Development
activities shall be set forth in the relevant Development Plan and shall be periodically updated by
the Joint Project Committee. 9.3 Supply of API Compound for Commercial Requirements. Subject to the
terms and conditions of this Agreement, GSK shall obtain supply of API Compound. A forecast for API
Compound requirements for Commercialization of the Collaboration Products shall be prepared and
periodically updated by the Joint Project Committee and coordinated with the applicable Marketing
Plans for Collaboration Products. 9.4 Supply of Collaboration Products for Commercialization.
Subject to the terms and conditions of this Agreement, GSK shall obtain supply of the commercial
requirements of formulated, packaged and labeled Collaboration Products. Such formulated, packaged
and labeled Collaboration Products shall be manufactured and supplied in accordance with all 30
<!-- page 41 -->
applicable Laws and current Good Manufacturing Practices. GSK shall be solely responsible for
secondary manufacture, packaging and labeling of the Collaboration Product. 9.5 Inventories. GSK and
its Product Suppliers shall maintain an inventory of API Compound and Collaboration Products in
accordance with their normal practices and so as to ensure fulfillment of its respective supply
obligations herein. ARTICLE 10 CONFIDENTIAL INFORMATION 10.1 Confidential Information. Each of GSK
and Theravance shall keep all Confidential Information received from the other Party with the same
degree of care it maintains the confidentiality of its own Confidential Information. Neither Party
shall use such Confidential Information for any purpose other than in performance of this Agreement
or disclose the same to any other Person other than to such of its agents who have a need to know
such Confidential Information to implement the terms of this Agreement or enforce its rights under
this Agreement. A Receiving Party shall advise any agent who receives such Confidential Information
of the confidential nature thereof and of the obligations contained in this Agreement relating
thereto, and the Receiving Party shall ensure that all such agents comply with such obligations as
if they had been a Party hereto. Upon termination of this Agreement, the Receiving Party shall
return or destroy all documents, tapes or other media containing Confidential Information of the
Disclosing Party that remain in the Receiving Party's or its agents' possession, except that the
Receiving Party may keep one copy of the Confidential Information in the legal department files of
the Receiving Party, solely for archival purposes. Such archival copy shall be deemed to be the
property of the Disclosing Party, and shall continue to be subject to the provisions of this Article
10. Notwithstanding anything to the contrary in this Agreement, the Receiving Party shall have the
right to disclose this Agreement or Confidential Information provided hereunder if, in the
reasonable opinion of the Receiving Party's legal counsel, such disclosure is necessary to comply
with the terms of this Agreement, or the requirements of any Law. Where possible, the Receiving
Party shall notify the Disclosing Party of the Receiving Party's intent to make such disclosure
pursuant to the provision of the preceding sentence sufficiently prior to making such disclosure so
as to allow the Disclosing Party adequate time to take whatever action the Disclosing Party may deem
to be appropriate to protect the confidentiality of the information. The Receiving Party will
cooperate reasonably with the Disclosing Party's efforts to protect the confidentiality of the
information. Each Party will be liable for breach of this Article 10 by any of its Affiliates. 10.2
Permitted Disclosure and Use. Notwithstanding Section 10.1, a Party may disclose Confidential
Information belonging to the other Party only to the extent such disclosure is reasonably necessary
to: (a) obtain Marketing Authorization of a Collaboration Product; (b) enforce the provisions of
this Agreement; or (c) comply with Laws. If a Party deems it necessary to disclose Confidential
Information of the other Party pursuant to this Section 10.2, such Party shall give reasonable
advance notice of such disclosure to the other Party to permit such other Party sufficient
opportunity to object to such disclosure or to take measures to ensure confidential treatment of
such information. The Receiving Party will cooperate reasonably with the Disclosing Party's efforts
to protect the confidentiality of the information. 10.3 Publications. Subject to any Third Party
rights existing as of the Effective Date, each Party shall submit to the Joint Project Committee for
review and approval all proposed academic, scientific and medical publications and public
presentations relating to a Collaboration Product or any research or Development activities under
this Agreement for review in connection 31
<!-- page 42 -->
with preservation of Patent Rights, and trade secrets and/or to determine whether Confidential
Information should be modified or deleted from the proposed publication or public presentation.
Written copies of such proposed publications and presentations shall be submitted to the Joint
Project Committee no later than sixty (60) days before submission for publication or presentation
and the Joint Project Committee shall provide its comments with respect to such publications and
presentations within ten (10) Business Days of its receipt of such written copy. The review period
may be extended for an additional sixty (60) days if a representative of the non-publishing Party on
the Joint Project Committee can demonstrate a reasonable need for such extension including, but not
limited to, the preparation and filing of patent applications. By mutual agreement of the Parties,
this period may be further extended. The Parties will each comply with standard academic practice
regarding authorship of scientific publications and recognition of contribution of other parties in
any publications relating to the Collaboration Products or any research or Development activities
under this Agreement. 10.4 Public Announcements. Except as may be expressly permitted under Section
10.3 or required by applicable Laws and subject to the final two sentences of this Section 10.4,
neither Party will make any public announcement of any information regarding this Agreement, the
Collaboration Products or any research or Development activities under this Agreement without the
prior written approval of the other Party, which approval shall not be withheld unreasonably. Once
any statement is approved for disclosure by the Parties or information is otherwise made public in
accordance with the preceding sentence, either Party may make a subsequent public disclosure of the
contents of such statement without further approval of the other Party. Notwithstanding the
foregoing, within sixty (60) days following the Effective Date, appropriate representatives of the
Parties will meet and agree upon a process and principles for reaching timely consensus on how the
Parties will make public disclosure concerning this Agreement, the Collaboration Products or any
research and Development activities under this Agreement. 10.5 Confidentiality of This Agreement.
The terms of this Agreement shall be Confidential Information of each Party and, as such, shall be
subject to the provisions of this Article 10. Either party may disclose the terms of this Agreement
if, in the opinion of its counsel, such disclosure is required by Law. In such event, the disclosing
Party will seek appropriate confidentiality of those portions of the Agreement for which
confidential treatment is typically permitted by the relevant Governmental Authority. 10.6
Termination of Prior Confidentiality Agreements. Except as expressly provided in this Section 10.6,
this Agreement supercedes the Mutual Confidential Disclosure Agreement (the "MCDA") between the
Parties dated April 10, 2002. Except as expressly provided in this Section 10.6 and in Paragraph 8
of the Confidentiality Agreement between the Parties dated October 2, 2002 (the "Patent CDA"), this
Agreement supersedes the Patent CDA. Except as set forth in Paragraph 8 of the Patent CDA, all
information disclosed pursuant to the MCDA and the Patent CDA shall be subject to the provisions of
this Article 10. 10.7 Survival. The obligations and prohibitions contained in this Article 10 shall
survive the expiration or termination of this Agreement for a period of ten (10) years. 32
<!-- page 43 -->
ARTICLE 11 REPRESENTATIONS AND WARRANTIES; COVENANTS 11.1 Mutual Representations and Warranties.
Theravance and GSK each represents and warrants to the other as of the Effective Date that: 11.1.1
Such Party (a) is a company duly organized, validly existing, and in good standing under the Laws of
its incorporation; (b) is duly qualified as a corporation and in good standing under the Laws of
each jurisdiction where its ownership or lease of property or the conduct of its business requires
such qualification, where the failure to be so qualified would have a material adverse effect on its
financial condition or its ability to perform its obligations hereunder; (c) has the requisite
corporate power and authority and the legal right to conduct its business as now conducted and
hereafter contemplated to be conducted; (d) has or will obtain all necessary licenses, permits,
consents, or approvals from or by, and has made or will make all necessary notices to, all
Governmental Authorities having jurisdiction over such Party, to the extent required for the
ownership and operation of its business, where the failure to obtain such licenses, permits,
consents or approvals, or to make such notices, would have a material adverse effect on its
financial condition or its ability to perform its obligations hereunder; and (e) is in compliance
with its charter documents; 11.1.2 The execution, delivery and performance of this Agreement by such
Party and all instruments and documents to be delivered by such Party hereunder (a) are within the
corporate power of such Party; (b) have been duly authorized by all necessary or proper corporate
action; (c) do not conflict with any provision of the charter documents of such Party; (d) will not,
to the best of such Party's knowledge, violate any law or regulation or any order or decree of any
court of governmental instrumentality; (e) will not violate or conflict with any terms of any
indenture, mortgage, deed of trust, lease, agreement, or other instrument to which such Party is a
party, or by which such Party or any of its property is bound, which violation would have a material
adverse effect on its financial condition or on its ability to perform its obligations hereunder;
11.1.3 This Agreement has been duly executed and delivered by such Party and constitutes a legal,
valid and binding obligation of such Party, enforceable against such Party in accordance with its
terms, except as such enforceability may be limited by applicable insolvency and other Laws
affecting creditors' rights generally, or by the availability of equitable remedies; and 11.1.4 All
of its employees, officers, and consultants have executed agreements or have existing obligations
under law requiring assignment to such Party of all Inventions made by such individuals during the
course of and as the result of their association with such Party, and obligating such individuals to
maintain as confidential such Party's Confidential Information. 11.1.5 Nothing contained in this
Agreement shall give a Party the right to use the Confidential Information received from the other
Party in connection with any activity other than Development and Commercialization of a Pooled
Compound or Collaboration Product consistent with this Agreement. 11.1.6 As soon as practicably
possible after the Effective Date, the Parties will each deliver to each other a schedule listing
(i) in the case of GSK, GSK Patents as of the date of signature of this Agreement and (ii) in the
case of Theravance, Theravance Patents as of the date of signature of this Agreement. 33
<!-- page 44 -->
11.2 Additional GSK Representations and Warranties. GSK further represents, warrants and covenants
to Theravance that: 11.2.1 It has utilized its own scientific, marketing and distribution expertise
and experience to analyze and evaluate both the scientific and commercial value of this
collaboration and has solely relied on such analysis and evaluations in deciding to enter into this
Agreement; 11.2.2 Neither GSK nor any of its Affiliates is a party to or otherwise bound by any oral
or written contract or agreement that will result in any Person obtaining any interest in, or that
would give to any Person any right to assert any claim in or with respect to, any of GSK's rights
granted under this Agreement; 11.2.3 There is no claim or demand of any person or entity pertaining
to, or any proceeding which is pending or, to the knowledge of GSK, threatened, that challenges the
rights of Theravance in respect of any GSK Know-How or GSK Patents, or that claims that any default
exists under any license with respect to any GSK Know-How or GSK Patents to which GSK is a party,
except where such claim, demand or proceeding would not materially and adversely affect the ability
of GSK to carry out its obligations under this Agreement; and 11.2.4 Having carried out and
completed diligent searches in relation to the GSK Patents, and other than as disclosed to
Theravance's counsel by GSK's counsel, GSK is not aware, nor has been made aware, of any conflict or
likely future conflict with the intellectual property rights of any Third Party with respect to GSK
Patents. 11.3 Additional Theravance Representations and Warranties. Theravance further represents
and warrants to GSK as of the Effective Date that: 11.3.1 Having carried out and completed diligent
searches in relation to the Theravance Patents, and other than as disclosed to GSK's counsel by
Theravance's counsel, Theravance is not aware, nor has been made aware, of any conflict or likely
future conflict with the intellectual property rights of any Third Party with respect to Theravance
Patents. Theravance has not received notice from any Third Party of a claim that an issued patent of
such Third Party would be infringed by the manufacture, distribution, marketing or sale of the
Collaboration Products under this Agreement; 11.3.2 To Theravance's knowledge, the Theravance
Patents are not subject to any pending or any threatened re-examination, opposition, interference or
litigation proceedings; 11.3.3 Theravance has not received notice from any Third Party of a claim
asserting the invalidity, misuse, unregisterability or unenforceability of any of the Theravance
Patents, or challenging its right to use or ownership of any of the Theravance Patents or the
Theravance Know-How, or making any adverse claim of ownership thereof; 11.3.4 Theravance has not
received notice from any Third Party that any trade secrets or other intellectual property rights of
such Third Party would be misappropriated by the development and reduction to practice of the
Theravance Patents and Theravance Know-How; and 34
<!-- page 45 -->
11.3.5 Theravance has, up to and including the Effective Date, furnished GSK with all material
information requested by GSK concerning the quality, toxicity, safety and/or efficacy concerns that
may materially impair the utility and/or safety of the Compound or Collaboration Products. 11.4
Covenants. Each Party hereby covenants and agrees during the Term that it shall carry out its
obligations or activities hereunder in accordance with (i) the terms of this Agreement and (ii) all
applicable Laws. 11.5 Disclaimer of Warranty. Subject to the specific warranties and representations
given under Sections 11.1 through and including 11.3, nothing in this Agreement shall be construed
as a warranty or representation by either Party (i) that any Collaboration Product made, used, sold
or otherwise disposed of under this Agreement is or will be free from infringement of patents,
copyrights, trademarks, industrial design or other intellectual property rights of any Third Party,
(ii) regarding the effectiveness, value, safety, non-toxicity, patentability, or non-infringement of
any patent technology, the Collaboration Products or any information or results provided by either
Party pursuant to this Agreement or (iii) that any Collaboration Product will obtain Marketing
Authorization or appropriate pricing approval. Each Party explicitly accepts all of the same as
experimental and for development purposes, and without any express or implied warranty from the
other Party. EXCEPT AS OTHERWISE EXPRESSLY SET FORTH IN THIS AGREEMENT, EACH PARTY EXPRESSLY
DISCLAIMS, WAIVES, RELEASES, AND RENOUNCES ANY WARRANTY, EXPRESS OR IMPLIED, INCLUDING, WITHOUT
LIMITATION, ANY WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE. ARTICLE 12
INDEMNIFICATION 12.1 Indemnification by GSK. Subject to Sections 12.4 and 13.2, GSK shall defend,
indemnify and hold harmless Theravance and its Affiliates and each of their officers, directors,
shareholders, employees, successors and assigns from and against all Claims of Third Parties, and
all associated Losses, to the extent arising out of (a) GSK's negligence or willful misconduct in
performing any of its obligations under this Agreement, (b) a breach by GSK of any of its
representations, warranties, covenants or agreements under this Agreement, or (c) the manufacture,
use, handling, storage, marketing, sale, distribution or other disposition of Collaboration Products
by GSK, its Affiliates, agents or sublicensees, except to the extent such losses result from the
negligence or willful misconduct of Theravance. 12.2 Indemnification by Theravance. Subject to
Sections 12.4 and 13.2, Theravance shall defend, indemnify and hold harmless GSK and its Affiliates
and each of their officers, directors, shareholders, employees, successors and assigns from and
against all Claims of Third Parties, and all associated Losses, to the extent arising out of (a)
Theravance's negligence or willful misconduct in performing any of its obligations under this
Agreement, or (b) a breach by Theravance of any of its representations, warranties, covenants or
agreements under this Agreement. 35
<!-- page 46 -->
12.3 Procedure for Indemnification. 12.3.1 Notice. Each Party will notify promptly the other in
writing if it becomes aware of a Claim (actual or potential) by any Third Party (a "Third Party
Claim") for which indemnification may be sought by that Party and will give such information with
respect thereto as the other Party shall reasonably request. If any proceeding (including any
governmental investigation) is instituted involving any Party for which such Party may seek an
indemnity under Section 12.1 or 12.2, as the case may be (the "Indemnified Party"), the Indemnified
Party shall not make any admission or statement concerning such Third Party Claim, but shall
promptly notify the other Party (the "Indemnifying Party") orally and in writing and the
Indemnifying Party and Indemnified Party shall meet to discuss how to respond to any Third Party
Claims that are the subject matter of such proceeding. The Indemnifying Party shall not be obligated
to indemnify the Indemnified Party to the extent any admission or statement made by the Indemnified
Party or any failure by such Party to notify the Indemnifying Party of the claim materially
prejudices the defense of such claim. 12.3.2 Defense of Claim. If the Indemnifying Party elects to
defend or, if local procedural rules or laws do not permit the same, elects to control the defense
of a Third Party Claim, it shall be entitled to do so provided it gives notice to the Indemnified
Party of its intention to do so within forty-five (45) days after the receipt of the written notice
from the Indemnified Party of the potentially indemnifiable Third Party Claim (the "Litigation
Condition"). The Indemnifying Party expressly agrees the Indemnifying Party shall be responsible for
satisfying and discharging any award made to or settlement reached with the Third Party pursuant to
the terms of this Agreement without prejudice to any provision in this Agreement or right at law
which will allow the Indemnifying Party subsequently to recover any amount from the Indemnified
Party to the extent the liability under such settlement or award was attributable to the Indemnified
Party. Subject to compliance with the Litigation Condition, the Indemnifying Party shall retain
counsel reasonably acceptable to the Indemnified Party (such acceptance not to be unreasonably
withheld, refused, conditioned or delayed) to represent the Indemnified Party and shall pay the
reasonable fees and expenses of such counsel related to such proceeding. In any such proceeding, the
Indemnified Party shall have the right to retain its own counsel, but the fees and expenses of such
counsel shall be at the expense of the Indemnified Party. The Indemnified Party shall not settle any
claim for which it is seeking indemnification without the prior written consent of the Indemnifying
Party which consent shall not be unreasonably withheld, refused, conditioned or delayed. The
Indemnified Party shall, if requested by the Indemnifying Party, cooperate in all reasonable
respects in the defense of such claim that is being managed and/or controlled by the Indemnifying
Party. The Indemnifying Party shall not, without the written consent of the Indemnified Party (which
consent shall not be unreasonably withheld, refused, conditioned or delayed), effect any settlement
of any pending or threatened proceeding in which the Indemnified Party is, or based on the same set
of facts could have been, a party and indemnity could have been sought hereunder by the Indemnified
Party, unless such settlement includes an unconditional release of the Indemnified Party from all
liability on claims that are the subject matter of such proceeding. If the Litigation Condition is
not met, then neither Party shall have the right to control the defense of such Third Party Claim
and the Parties shall cooperate in and be consulted on the material aspects of such defense at each
Party's own expense; provided that if the Indemnifying Party does not satisfy the Litigation
Condition, the Indemnifying Party may at any subsequent time during the pendency of the relevant
Third Party Claim irrevocably elect, if permitted by local procedural rules or laws, to defend
and/or to control the defense of the relevant Third Party Claim so long as the Indemnifying Party
also agrees to pay the reasonable fees and costs incurred by the Indemnified Party in relation to
the defense of such Third Party Claim from 36
<!-- page 47 -->
the inception of the Third Party Claim until the date the Indemnifying Party assumes the defense or
control thereof. 12.4 Assumption of Defense. Notwithstanding anything to the contrary contained
herein, an Indemnified Party shall be entitled to assume the defense of any Third Party Claim with
respect to the Indemnified Party, upon written notice to the Indemnifying Party pursuant to this
Section 12.4, in which case the Indemnifying Party shall be relieved of liability under Section 12.1
or 12.2, as applicable, solely for such Third Party Claim and related Losses. 12.5 Insurance. During
the Term of this Agreement and for a period of one (1) year after the termination or expiration of
this Agreement, GSK shall obtain and/or maintain at its sole cost and expense, product liability
insurance (including any self-insured arrangements) in amounts which are reasonable and customary in
the U.S. pharmaceutical industry for companies of comparable size and activities. Such product
liability insurance or self-insured arrangements shall insure against all liability, including
without limitation personal injury, physical injury, or property damage arising out of the
manufacture, sale, distribution, or marketing of the Collaboration Products. GSK shall provide
written proof of the existence of such insurance to Theravance upon request. ARTICLE 13 PATENTS 13.1
Prosecution and Maintenance of Patents. 13.1.1 Prosecution and Maintenance of Theravance Patents.
Theravance shall have the exclusive right and the obligation to (subject to Theravance's election
not to file, prosecute, or maintain pursuant to Section 13.1.4) or to cause its licensors to,
prepare, file, prosecute in a diligent manner (including without limitation by conducting
interferences, oppositions and reexaminations or other similar proceedings), maintain (by timely
paying all maintenance fees, renewal fees, and other such fees and costs required under applicable
Laws) and extend all Theravance Patents and related applications. Theravance shall consult with GSK
prior to abandoning any Theravance Patents or related applications that are material to the matters
contemplated in this Agreement. Theravance shall regularly advise GSK of the status of all pending
applications, including with respect to any hearings or other proceedings before any Governmental
Authority, and, at GSK's request, shall provide GSK with copies of all documentation concerning such
applications, including all correspondence to and from any Governmental Authority. Subject to
Section 2.3.3, Theravance shall solicit GSK's advice and review of the nature and text of such
patent applications and important prosecution matters related thereto in reasonably sufficient time
prior to filing thereof, and Theravance shall take into account GSK's reasonable comments related
thereto; provided, however, Theravance shall have the final decision authority with respect to any
action relating to any Theravance Patent. Within the priority period, Theravance shall agree with
GSK regarding the countries outside the United States in which corresponding applications should be
filed ("OUS Filings"). It is presumed that a corresponding Patent Cooperation Treaty ("PCT")
application will be filed unless otherwise agreed by the Parties. Theravance shall effect filing of
all such applications within the priority period. Subject to Section 13.1.4, Theravance shall be
responsible for all costs incurred in the United States in connection with procuring Theravance
Patents, including applications preparation, filing fees, prosecution, maintenance and all costs
associated with reexamination and 37
<!-- page 48 -->
interference proceedings in the United States Patent and Trademark Office and United States Courts.
GSK shall be responsible for all out-of-pocket costs and expenses incurred by Theravance after the
Effective Date that are associated with procuring corresponding OUS patents, including without
limitation PCT and individual country filing fees, translations, maintenance, annuities, and protest
proceedings. For all such OUS patent applications, Theravance will invoice GSK on a quarterly basis
beginning April 1, 2003, setting forth all such expenses incurred. Reimbursement will be made to
Theravance in United States Dollars within thirty (30) days of receipt of the invoice by GSK. GSK
will within thirty (30) days following the Effective Date identify the GSK representative that
should receive such invoices from Theravance. GSK's obligations hereunder are in addition to any
obligations of GSK under Section 13.1.2(b) 13.1.2 Prosecution and Maintenance of Patents Covering
Joint Inventions. (a) For Patents covering Joint Inventions, the Parties shall agree, without
prejudice to ownership, which Party shall have the right to prepare and file a priority patent
application, and prosecute such application(s) and maintain any patents derived therefrom, with the
Parties equally sharing the reasonable out-of-pocket costs for the preparation, filing, prosecution
and maintenance of such priority patent application. The Parties will reasonably cooperate to obtain
any export licenses that might be required for such activities. Should the agreed upon Party elect
not to prepare and/or file any such priority patent application, it shall (i) provide the other
Party with written notice as soon as reasonably possible after making such election but in any event
no later than sixty (60) days before the other Party would be faced with a possible loss of rights,
(ii) give the other Party the right, at the other Party's discretion and sole expense, to prepare
and file the priority application(s), and (iii) offer reasonable assistance in connection with such
preparation and filing at no cost to the other Party except for reimbursement of reasonable
out-of-pocket expenses incurred by the agreed upon Party in rendering such assistance. The other
Party, at its discretion and cost, shall prosecute such application(s) and maintain sole ownership
of any patents derived therefrom. (b) Within nine (9) months after the filing date of a priority
application directed to an Invention, the Party filing the priority application shall request that
the other Party identify those non-priority, non-PCT ("foreign") Countries in which the other Party
desires that the Party filing the priority application file corresponding patent applications.
Within thirty (30) days after receipt by the other Party of such request from the Party filing the
priority application, the other Party shall provide to the Party filing the priority application a
written list of such foreign countries in which the other Party wishes to effect corresponding
foreign patent applications filings. The Parties will then attempt to agree on the particular
countries in which such applications will be filed, provided that in the event agreement is not
reached, the application will be filed in the disputed as well as the non-disputed countries (all
such filings referred to hereinafter as "Designated Foreign Filings"). Thereafter, within twelve
(12) months after the filing date of the priority application, the Party filing the priority
application shall effect all such Designated Foreign Filings. It is presumed unless otherwise agreed
in writing by the Parties, that a corresponding PCT application will be filed designating all PCT
member countries. As to each Designated Foreign Filing and PCT application, GSK shall bear the costs
for the filing and prosecutions of such Designated Foreign Filing and PCT application (including
entering national phase in all agreed countries). Should the Party filing the priority application
not agree to file or cause to be filed a Designated Foreign Filing, the other Party will have the
right to effect such Designated Foreign Filing in its name. 38
<!-- page 49 -->
(c) Should the filing Party pursuant to Section 13.1.2(a) or 13.1.2(b) no longer wish to prosecute
and/or maintain any patent application or patent resulting from such application, the filing Party
shall (i) provide the non-filing Party with written notice of its wish no later than sixty (60) days
before the patent or patent applications would otherwise become abandoned, (ii) give the non-filing
Party the right, at the non-filing Party's election and sole expense, to prosecute and/or maintain
such patent or patent application, and (iii) offer reasonable assistance to the non- filing Party in
connection with such prosecution and/or maintenance at no cost to the non-filing Party except for
reimbursement of the filing Party's reasonable out-of-pocket expenses incurred by the filing Party
in rendering such assistance. (d) Should the non-filing Party pursuant to Section 13.1.2(c) not wish
to incur its share of preparation, filing, prosecution and/or maintenance costs for a patent
application filed pursuant to Section 13.1.2(a) or 13.1.2(b) or patents derived therefrom, it shall
(i) provide the filing Party with written notice of its wish, and (ii) continue to offer reasonable
assistance to the filing Party in connection with such prosecution or maintenance at no cost to the
filing Party except for reimbursement of the non-filing Party's reasonable out-of-pocket expenses
incurred by the non-filing Party in rendering such assistance. (e) The Parties agree to cooperate in
the preparation and prosecution of all patent applications filed under Section 13.1.2(a) and
13.1.2(b), including obtaining and executing necessary powers of attorney and assignments by the
named inventors, providing relevant technical reports to the filing Party concerning the invention
disclosed in such patent application, obtaining execution of such other documents which shall be
needed in the filing and prosecution of such patent applications, and, as requested, updating each
other regarding the status of such patent applications. 13.1.3 Prosecution and Maintenance of GSK
Patents. GSK shall have the exclusive right and obligation to (subject to GSK's election not to
file, prosecute or maintain pursuant to Section 13.1.5) or to cause its licensors to, prepare, file
and prosecute in a diligent manner (including without limitation by conducting interferences,
oppositions and reexaminations or other similar proceedings), maintain (by timely paying all
maintenance fees, renewal fees, and other such fees and costs required under applicable Laws) and
extend all GSK Patents and related applications. Consistent with Section 2.3.3, GSK will consult
with Theravance within the priority period for any patent application that is material to this
Agreement concerning Countries in which corresponding applications will be filed. In the event the
Parties can not agree, GSK shall make the final decision. GSK shall consult with Theravance prior to
abandoning any GSK Patents or related applications that are material to the matters contemplated in
this Agreement. GSK shall regularly advise Theravance of the status of all pending applications,
including with respect to any hearings or other proceedings before any Governmental Authority, and,
at Theravance's request, shall provide Theravance with copies of documentation relating to such
applications, including all correspondence to and from any Governmental Authority. Subject to
Section 2.3.3, GSK shall solicit Theravance's advice and review of the nature and text of such
patent applications and important prosecution matters related thereto in reasonably sufficient time
prior to filing thereof, and GSK shall take into account Theravance's reasonable comments relating
thereto; provided that GSK shall have the final decision authority with respect to any action
relating to a GSK Patent. 13.1.4 GSK Step-In Rights. If Theravance elects not to file, prosecute or
maintain the Theravance Patents or claims encompassed by such Theravance Patents necessary for GSK
to exercise its rights hereunder in any Country, Theravance shall give GSK notice thereof within a
reasonable period prior to allowing such Theravance Patents, or such claims encompassed by 39
<!-- page 50 -->
such Theravance Patents, to lapse or become abandoned or unenforceable, and GSK shall thereafter
have the right, at its sole expense, to prepare, file, prosecute and maintain such Theravance
Patents in such Country. 13.1.5 Theravance Step-In Rights. If GSK elects not to file, prosecute or
maintain the GSK Patents or claims encompassed by such GSK Patents necessary for Theravance to
exercise its license rights hereunder in any Country, GSK shall give Theravance notice thereof
within a reasonable period prior to allowing such GSK Patents, or such claims encompassed by such
GSK Patents, to lapse or become abandoned or unenforceable, and Theravance shall thereafter have the
right, at its sole expense, to prepare, file, prosecute and maintain such GSK Patents in such
Country. In the event that GSK elects not to file, prosecute or maintain GSK Patents or claims that
would affect the royalty owed Theravance pursuant to Section 6.3, GSK shall reimburse Theravance for
all out-of-pocket expenses incurred by Theravance in connection with Theravance exercising its
Step-In Rights under this Section. 13.1.6 Execution of Documents by Agents. Each of the Parties
shall execute or have executed by its appropriate agents such documents as may be necessary to
obtain, perfect or maintain any Patent Rights filed or to be filed pursuant to this Agreement, and
shall cooperate with the other Party so far as reasonably necessary with respect to furnishing all
information and data in its possession reasonably necessary to obtain or maintain such Patent
Rights. 13.1.7 Patent Term Extensions. The Parties shall cooperate with each other in gaining patent
term extension where applicable to Collaboration Products. The Joint Steering Committee shall
determine which patents the Parties shall endeavor to have extended. All filings for such extension
will be made by the Party to whom the patent is assigned after consultation with the other Party. In
the event the Joint Steering Committee can not agree, the Party who is assigned the compound patent
covering the LABA in the Collaboration Product will make the decision. 13.2 Patent Infringement.
13.2.1 Infringement Claims. With respect to any and all Claims instituted by Third Parties against
Theravance or GSK or any of their respective Affiliates for patent infringement involving the
manufacture, use, license, marketing or sale of a Collaboration Product in the United States during
the Term (each, a "Patent Infringement Claim") as applicable, Theravance and GSK will assist one
another and cooperate in the defense and settlement of such Patent Infringement Claims at the other
Party's request. 13.2.2 Infringement of Theravance Patents. In the event that Theravance or GSK
becomes aware of actual or threatened infringement of a Theravance Patent during the Term, that
Party will promptly notify the other Party in writing (a "Patent Infringement Notice"). Theravance
will have the right but not the obligation to bring an infringement action against any Third Party.
If Theravance elects to pursue such infringement action, Theravance shall be solely responsible for
the costs and expenses associated with such action and retain all recoveries. During the Term, in
the event that Theravance does not undertake such an infringement action, upon Theravance's written
consent, which shall not be unreasonably withheld, refused, conditioned or delayed, GSK shall be
permitted to do so in Theravance's or the relevant Theravance Affiliate's name and on Theravance's
or the relevant Theravance Affiliate's behalf. If Theravance has consented to an infringement action
but GSK is not recognized by the applicable court or other relevant body as having the requisite
standing to pursue such action, then GSK may join Theravance as party-plaintiff. If GSK elects to
pursue such infringement action, Theravance may be represented in 40
<!-- page 51 -->
such action by attorneys of its own choice and its own expense with GSK taking the lead in such
action. 13.2.3 Infringement of GSK Patents. In the event that GSK or Theravance becomes aware of
actual or threatened infringement of a GSK Patent during the Term, that Party will promptly notify
the other Party in writing. GSK will have the right but not the obligation to bring an infringement
action against any Third Party. If GSK elects to pursue such infringement action, GSK shall be
solely responsible for the costs and expenses associated with such action and retain all recoveries.
During the Term, in the event that GSK does not undertake such an infringement action, upon GSK's
written consent, which shall not be unreasonably withheld, refused, conditioned or delayed,
Theravance shall be permitted to do so in GSK's or the relevant GSK Affiliate's name and on GSK's or
the relevant GSK Affiliate's behalf. If GSK has consented to an infringement action but Theravance
is not recognized by the applicable court or other relevant body as having the requisite standing to
pursue such action, then Theravance may join GSK as a party-plaintiff. If Theravance elects to
pursue such infringement action, GSK may be represented in such action by attorneys of its own
choice and at its own expense, with Theravance taking the lead in such action. 13.3 Notice of
Certification. GSK and Theravance each shall immediately give notice to the other of any
certification filed under the "U.S. Drug Price Competition and Patent Term Restoration Act of 1984"
(or its foreign equivalent) claiming that a GSK Patent or a Theravance Patent is invalid or that
infringement will not arise from the manufacture, use or sale of any Collaboration Product by a
Third Party ("Hatch-Waxman Certification"). 13.3.1 Notice. If a Party decides not to bring
infringement proceedings against the entity making such a certification, such Party shall give
notice to the other Party of its decision not to bring suit within twenty-one (21) days after
receipt of notice of such certification. 13.3.2 Option. Such other Party then may, but is not
required to, bring suit against the entity that filed the certification. 13.3.3 Name of Party. Any
suit by Theravance or GSK shall either be in the name of Theravance or in the name of GSK, (or any
Affiliate) or jointly in the name of Theravance and GSK (or any Affiliate) , as may be required by
law. 13.4 Assistance. For purposes of this Article 13, the Party not bringing suit shall execute
such legal papers necessary for the prosecution of such suit as may be reasonably requested by the
Party bringing suit. The out-of-pocket costs and expenses of the Party bringing suit shall be
reimbursed first out of any damages or other monetary awards recovered in favor of GSK or
Theravance. The documented out-of-pocket costs and expenses of the other Party shall then be
reimbursed out of any remaining damages or other monetary awards. The Party initiating and
prosecuting the action to completion will retain any remaining damages or other monetary awards
following such reimbursements. 13.5 Settlement. No settlement or consent judgment or other voluntary
final disposition of a suit under this Article may be entered into without the joint written consent
of GSK and Theravance (which consent will not be withheld unreasonably). 41
<!-- page 52 -->
ARTICLE 14 TERM AND TERMINATION 14.1 Term and Expiration of Term. Unless otherwise mutually agreed
to by the Parties, this Agreement shall commence on the Effective Date and shall end upon expiration
of the Term, unless terminated early as contemplated hereunder. Unless terminated early under this
Article 14, the licenses granted by Theravance to GSK pursuant to Section 2.1 with respect to the
Collaboration Products shall be considered fully-paid and shall become non-exclusive upon expiration
of the Term. 14.2 Termination for Material Breach. Either Party may, without prejudice to any other
remedies available to it at law or in equity, terminate this Agreement subject to Section 14.10 in
the event that the other Party (as used in this subsection, the "Breaching Party") shall have
materially breached or defaulted in the performance of any of its obligations. The Breaching Party
shall, if such breach can be cured, have sixty (60) days after written notice thereof was provided
to the Breaching Party by the non-breaching Party to remedy such default (or, if such default cannot
be cured within such 60-day period, the Breaching Party must commence and diligently continue
actions to cure such default during such 60-day period). Any such termination shall become effective
at the end of such 60-day period unless the Breaching Party has cured any such breach or default
prior to the expiration of such 60-day period (or, if such default is capable of being cured but
cannot be cured within such 60-day period, the Breaching Party has commenced and diligently
continued actions to cure such default provided always that, in such instance, such cure must have
occurred within one hundred twenty (120) days after written notice thereof was provided to the
Breaching Party by the non-breaching Party to remedy such default). 14.3 GSK Right to Terminate
Development of a Collaboration Product. On a Collaboration Product-by-Collaboration Product basis,
and at any time during Development and prior to First Commercial Sale of the applicable
Collaboration Product, GSK shall have the right to terminate Development of such Collaboration
Product (upon the provision of ninety (90) days written notice) for reasons of Technical Failure or
Commercial Failure following communication to, and assessment of such proposed termination by, the
Joint Project Committee and Joint Steering Committee (in which case such Collaboration Product shall
be referred to as a "Terminated Development Collaboration Product"). For the avoidance of doubt, a
"Terminated Development Collaboration Product" can be any of the following: (i) a Pooled Compound
and/or (ii) a Replacement Compound and/or (iii) a single agent LABA Collaboration Product and/or
(iv) a LABA/ICS Combination Product and/or (v) an Other Combination Product. 14.4 GSK Right to
Terminate Commercialization of a Collaboration Product Following First Commercial Sale. On a
Collaboration Product-by- Collaboration Product basis, and on a Country-by-Country basis, at any
time after First Commercial Sale of the applicable Collaboration Product in such country, GSK shall
have the right to terminate Commercialization of such Collaboration Product (upon the provision of
one hundred and eighty (180) days written notice) for reasons of Commercial Failure or Technical
Failure and following communication to, and assessment of such proposed termination by, the Joint
Project Committee and Joint Steering Committee (in which case, such Collaboration Product shall be
referred to as a "Terminated Commercialized Collaboration Product"). For the avoidance of doubt, a
Terminated Commercialized Collaboration Product can be any of the following: (i) a single agent LABA
Collaboration Product and/or (ii) a LABA/ICS Combination Product and/or (iii) an Other Combination
Product. 42
<!-- page 53 -->
14.5 Termination of the Agreement Due to Discontinuation of Development of All Collaboration
Products and All Pooled Compounds . Any time following the third anniversary of the Effective Date,
either Party may terminate this Agreement, subject to Section 14.10, upon the provision of ninety
(90) days written notice if Development of all Collaboration Products and all Pooled Compounds have
been discontinued for Technical Failure and/or Commercial Failure. Notwithstanding the foregoing, in
the event that (i) Development of all Collaboration Products and all Pooled Compounds (including any
Replacement Compounds) has ceased for at least three (3) months, (ii) all such termination and/or
discontinuance decisions have been validly approved by the Joint Steering Committee, and (iii) both
parties have provided written notice to the other that such party does not intend to contribute any
additional Replacement Compounds to the collaboration, then either Party shall be entitled to
terminate this Agreement, subject to Section 14.10, upon the provision of ninety (90) days written
notice. 14.6 Effects of Termination. 14.6.1 Effect of Termination for Material Breach. (a) Material
Breach by Theravance. In the event this Agreement is terminated by GSK pursuant to Section 14.2 for
material breach by Theravance, all licenses granted by Theravance to GSK under this Agreement shall
survive, subject to GSK's continued obligation to pay milestones and royalties to Theravance
hereunder. In such event, GSK shall retain all of its rights to bring an action against Theravance
for damages and any other available remedies in law or equity, and shall be entitled to set-off
against any monies payable to Theravance hereunder all amounts GSK reasonably believes constitute
its damages incurred by such breach, subject to final judicial resolution or settlement. Also,
Theravance shall, at its sole expense, promptly transfer to GSK copies of all data, reports, records
and materials in its possession or control that relate to the Collaboration Products that contain a
GSK Compound and return to GSK, or destroy at GSK's request, all relevant records and materials in
its possession or control containing Confidential Information of GSK (provided that Theravance may
keep one copy of such Confidential Information of GSK for archival purposes only in accordance with
Section 10.1). (b) Material Breach By GSK. In the event that this Agreement is terminated by
Theravance pursuant to Section 14.2 for material breach by GSK: (i) GSK shall, at its sole expense,
promptly transfer to Theravance copies of all data, reports, records and materials in its possession
or control that relate to the Theravance Compounds and return to Theravance, or destroy at
Theravance's request, all relevant records and materials in its possession or control containing
Confidential Information of Theravance (provided that GSK may keep one copy of such Confidential
Information of Theravance for archival purposes only in accordance with Section 10.1). (ii) GSK
shall, at its sole expense, transfer to Theravance, or shall cause its designee(s) to transfer to
Theravance, ownership of all regulatory filings made or filed for any Collaboration Product that
contains a LABA as a single agent (to the extent that any are held in GSK's or such designee(s)'s
name), and such transfer to be as permitted by applicable Laws and regulations; otherwise GSK shall
cooperate as necessary to permit Theravance to exercise its rights hereunder. (iii) Theravance shall
have the non-exclusive right to access, use and cite in any regulatory filing any data relating to
formulation of a LABA/ICS Combination Product or Other Combination Product. 43
<!-- page 54 -->
(iv) All of the provisions of Section 14.6.2 shall apply for the benefit of Theravance for any
Collaboration Product for which the first Phase III Study has been initiated at the effective date
of such termination, subject to the limitations set forth in Section 14.6.2. (v) All the provisions
of Section 14.6.3 shall apply for any Collaboration Product that has been Commercialized at the
effective date of such termination. (vi) All licenses granted by Theravance to GSK with respect to
the applicable Theravance Compounds under this Agreement shall terminate. (vii) Theravance shall
retain all of its rights to bring an action against GSK for damages and any other available remedies
in law or equity, and shall be entitled to set-off against any monies payable to GSK hereunder all
amounts Theravance reasonably believes constitute its damages incurred by such breach, subject to
final judicial resolution or settlement. 14.6.2 Effect of Termination by GSK of Certain Terminated
Development Collaboration Product(s). If GSK terminates a Collaboration Product at any time after
initiation of the first Phase III Study concerning such Collaboration Product, and Development of
all other Collaboration Products and Pooled Compounds have been discontinued for Technical Failure
and/or Commercial Failure, then at the sole election of Theravance, the following shall apply: (a)
GSK shall, at its sole expense, promptly transfer to Theravance copies of all data, reports, records
and materials in its possession or control that relate to the Theravance Compounds and return to
Theravance, or destroy at Theravance's request, all relevant records and materials in its possession
or control containing Confidential Information of Theravance (provided that GSK may keep one copy of
such Confidential Information of Theravance for archival purposes only in accordance with Section
10.1). (b) GSK shall, at its sole expense, transfer to Theravance, or shall cause its designee(s) to
transfer to Theravance, ownership of all regulatory filings made or filed for the Terminated
Development Collaboration Product that contains a LABA as a single agent (to the extent that any are
held in GSK's or such designee(s)'s name), such transfer to be as permitted by any Third Party
licenses or other such prior rights and applicable Laws and regulations, otherwise GSK shall
cooperate as necessary to permit Theravance to exercise its rights hereunder. (c) Theravance shall
have the non-exclusive right to access, use and cite in any regulatory filing any data relating to
formulation of a LABA/ICS Combination Product or Other Combination Product. (d) For such Terminated
Development Collaboration Product (excluding the non-LABA component of a LABA/ICS Combination
Product and/or Other Combination Product and GSK's Diskus delivery device and any information
directed thereto), GSK shall grant to Theravance the appropriate licenses in the Territory under the
GSK Patents, GSK Inventions and GSK Know- How related to the LABA compound, dry powder inhaler
formulation, metered dose inhaler formulation, and metered dose inhaler device, as applicable, to
enable Theravance to Develop and Commercialize the Terminated Development Collaboration Product in
the Field. 44
<!-- page 55 -->
(e) In the event of a Change in Control of Theravance prior to termination by GSK under Section
14.3, none of the provisions under this Section 14.6.2 shall survive as they pertain to any
Collaboration Product other than a Theravance compound as a single agent LABA. 14.6.3 Effect of
Termination by GSK of a Terminated Commercialized Collaboration Product. The provisions of this
Section 14.6.3 shall apply only where a Terminated Commercialised Collaboration Product is not being
or has not been replaced by an alternative Collaboration Product under this Agreement and provided
that, in GSK's reasonable good faith judgment, exercise by Theravance alone or with a Third Party of
any of the rights or activities contemplated by this Section 14.6.3 (which such rights or activities
shall include access to a GSK compound and/or GSK proprietary formulations or devices including
Diskus, (collectively "GSK Property")) will not materially damage GSK's continued development,
regulatory or commercial use of such GSK Property. GSK will use reasonable efforts to assist
Theravance in locating a mutually acceptable Third Party to carry out the rights and activities
contemplated by this Section 14.6.3. Subject to the foregoing: (a) If GSK terminates a Collaboration
Product after First Commercial Sale of such Collaboration Product in one or more of the Major Market
Countries, Theravance shall have the right in its sole discretion and at its sole expense, for its
own benefit or together with a Third Party, to commercialize such Terminated Commercialized
Collaboration Product in any of such Major Market Countries where it has been terminated. (b) If GSK
terminates Commercialization of a Collaboration Product in all Countries of the Territory following
the first commercial sale in any Country of the Territory, Theravance shall have the right in its
sole discretion and at it sole expense, for its own benefit or together with a Third Party, to
Commercialise such Terminated Commercialized Collaboration Product in the Territory. (c) Subject to
Section 14.6.3(a), GSK shall grant to Theravance the appropriate licenses in the Territory (or in
the case of a Country-by-Country termination, in the relevant Countries) under the GSK Patents, GSK
Inventions and GSK Know-How to enable Theravance by itself and/or through one or more Third Party
sublicensees, to Commercialize the Terminated Commercialized Collaboration Product. GSK shall also
provide Theravance with all such information and data which GSK, or its sublicensees reasonably have
available in such Country, for example access to drug master file, clinical data and the like, and
shall execute such instruments as Theravance reasonably requests, to enable Theravance to obtain the
appropriate regulatory approvals to market such Terminated Commercialized Collaboration Product in
such Country and for any other lawful purpose related to Commercialization of such Terminated
Commercialized Collaboration Product in such Country. (d) In the event Theravance exercises its
rights under Section 14.6.3(a) and (b) above, the Parties shall negotiate in good faith a separate
commercialization and supply agreement for such Terminated Commercialized Collaboration Product
which shall ensure that, based on commercially reasonable terms 45
<!-- page 56 -->
(recognizing the Commercialized status of the Terminated Commercialized Collaboration Product),
Theravance has a continuous and uninterrupted supply of such Terminated Commercialized Collaboration
Product, for a suitable period of time to enable Theravance to secure Third Party supply. (e) In the
event of a Change in Control of Theravance, prior to termination by GSK under Section 14.4, none of
the provisions under this Section 14.6.3 shall survive as they pertain to any Collaboration Product
other than to a single agent LABA, its dry powder inhaler formulation, metered dose inhaler
formulation, and metered dose inhaler device, as applicable; and the Parties will meet in good faith
to explore other potential commercial options e.g. use of one or more Third Parties for possible
continued Commercialisation of such Terminated Commercialised Collaboration Product if it is a
LABA/ICS Combination Product or Other Combination Product. (f) If GSK, in the exercise of its
reasonable good faith judgment, determines that exercise by Theravance alone or with a Third Party
of any of the rights or activities contemplated by this Section 14.6.3 will materially damage GSK's
continued development, regulatory or commercial use of GSK Property, then GSK shall grant to
Theravance, for such Terminated Commercialized Collaboration Product (excluding the non-LABA
component of a Combination Product and/or Other Combination Product and GSK's Diskus delivery device
and any information directed thereto), the appropriate licenses in the Territory under the GSK
Patents, GSK Inventions and GSK Know-How related to the LABA compound, dry powder inhaler
formulation, metered dose inhaler formulation, and metered dose inhaler device, as applicable, to
enable Theravance to Commercialize a product containing the LABA Compound in the Field. 14.6.4
Effect of Termination of the Agreement Due to Discontinuation of Development Prior to First
Commercial Sale of All Collaboration Products and All Pooled Compounds. In the event that the
Agreement is terminated pursuant to Section 14.5, the following shall occur: (i) Return of
Materials. GSK shall, at its sole expense, promptly transfer to Theravance copies of all data,
reports, records and materials in its possession or control that relate to the Theravance Compounds
and return to Theravance, or destroy at Theravance's request, all relevant records and materials in
its possession or control containing Confidential Information of Theravance (provided that GSK may
keep one copy of such Confidential Information of Theravance for archival purposes only in
accordance with Section 10.1). Theravance shall, at its sole expense, promptly transfer to GSK
copies of all data, reports, records and materials in its possession or control that relate to the
GSK Compounds and return to GSK, or destroy at GSK's request, all relevant records and materials in
its possession or control containing Confidential Information of GSK (provided that Theravance may
keep one copy of such Confidential Information of GSK for archival purposes only in accordance with
Section 10.1). (ii) Transfer of Regulatory Filings. GSK shall, at its sole expense, transfer to
Theravance, or shall cause its designee(s) to transfer to Theravance, ownership of all regulatory
filings made or filed for any Terminated Development Collaboration Product (to the extent that any
are held in GSK's or such designee(s)'s name), but only where the Terminated Collaboration Product
contains a Theravance Compound as a single agent and such transfer to be as permitted 46
<!-- page 57 -->
by applicable Laws and regulations. GSK, at its sole discretion, shall also give due consideration
to transferring to Theravance any additional regulatory filings for a Terminated Development
Collaboration Product which contains a Theravance Compound as a Combination Product. (iii) License
Rights. All licenses granted by Theravance to GSK with respect to the Collaboration Products under
this Agreement shall terminate. (iv) Stock Return. GSK shall return to Theravance all available
formulated and API stocks that contain a Theravance Compound and which are then held by GSK or cause
such API stocks to be provided to Theravance if held by a vendor or other Third Party on behalf of
GSK. (v) Limitations on Further Development by GSK. GSK shall not be permitted to continue or
re-initiate clinical Development of any GSK Compound that is both a Terminated Collaboration Product
and a LABA in the Field for a period of four (4) years after the date of such termination. 14.7
License Rights. Except as otherwise provided herein in, all licenses granted hereunder relating to
Terminated Collaboration Products shall terminate. Also the Parties accept that nothing provided for
in this Article 14 or elsewhere in this Agreement, grants any licenses (whether exclusive,
semi-exclusive or otherwise) from GSK to Theravance for any (i) GSK Compound (ii) GSK Invention (ii)
GSK Know How and (iv) GSK Patents, except for those rights essential and specific to enable
Theravance to exercise those rights and carry out those activities contemplated under Section 14.6
above. 14.8 Milestone Payments. Neither Party shall be obligated to make a Development Milestone
payment under Section 6.2 which is triggered by an event occurring after the effective date of
termination of this Agreement with respect to a Collaboration Product. 14.9 Subsequent Royalties. If
after termination of this Agreement either Party subsequently Develops and Commercializes any Long-
Acting β2 Adrenoceptor Agonist for the treatment / prophylaxis of respiratory diseases which (i) was
never a Pooled Compound or Collaboration Product or (ii) was a GSK Discontinued Compound or a
Theravance Discontinued Compound, it will pay to the other Party a royalty on Net Sales of any such
products at the rate of 3% for a single-agent product and 2% for the first combination product for a
period of 15 years from the date of launch on a Country-by-Country basis; provided, however, that
this royalty shall not apply to any compound or product (including new product line extensions
and/or re-formulation work) where the original compound or product is, as of the date of signature
of this Agreement, already Commercialized. 14.10 Accrued Rights; Surviving Obligations. Termination,
relinquishment or expiration of this Agreement for any reason shall be without prejudice to any
rights that shall have accrued to the benefit of any Party prior to such termination, relinquishment
or expiration. Such termination, relinquishment or expiration shall not relieve any Party from
obligations which are expressly or by implication intended to survive termination, relinquishment or
expiration of this Agreement, including without limitation Article 10, and shall not affect or
prejudice any provision of this Agreement which is expressly or by implication provided to come into
effect on, or continue in effect after, such termination, relinquishment or expiration. 47
<!-- page 58 -->
ARTICLE 15 LIMITATIONS RELATING TO THERAVANCE EQUITY SECURITIES 15.1 Purchases of Equity Securities.
So long as this Agreement remains in effect and for a period of one (1) year thereafter, except as
permitted by Section 15.2, or as otherwise agreed in writing by Theravance, GSK and its Affiliates
will not (and will not assist or encourage others to) directly or indirectly in any manner: 15.1.1
acquire, or agree to acquire, directly or indirectly, alone or in concert with others, by purchase,
gift or otherwise, any direct or indirect beneficial ownership (within the meaning of Rule l3d-3
under the Securities Exchange Act of 1934, as amended (the "Exchange Act")) or interest in any
securities or direct or indirect rights, warrants or options to acquire, or securities convertible
into or exchangeable for, any securities of Theravance; 15.1.2 make, or in any way participate in,
directly or indirectly, alone or in concert with others, any "solicitation" of "proxies" to vote (as
such terms are used in the proxy rules of the Securities and Exchange Commission (the "SEC")
promulgated pursuant to Section 14 of the Exchange Act); provided, however, that the prohibition in
this Section 15.1.2 shall not apply to solicitations exempted from the proxy solicitation rules by
Rule 14a-2 under the Exchange Act as such Rule 14a-2 is in effect as of the date hereof; 15.1.3
form, join or in any way participate in a "group" within the meaning of Section 13(d)(3) of the
Exchange Act with respect to any voting securities of Theravance; 15.1.4 acquire or agree to
acquire, directly or indirectly, alone or in concert with others, by purchase, exchange or
otherwise, (i) any of the assets, tangible or intangible, of Theravance or (ii) direct or indirect
rights, warrants or options to acquire any assets of Theravance, except for such assets as are then
being offered for sale by Theravance; 15.1.5 enter into any arrangement or understanding with others
to do any of the actions restricted or prohibited under Sections 15.1.1, 15.1.2, 15.1.3, or 15.1.4.
15.1.6 otherwise act in concert with others, to seek to offer to Theravance or any of its
stockholders any business combination, restructuring, recapitalization or similar transaction to or
with Theravance or otherwise seek in concert with others, to control, change or influence the
management, board of directors or policies of Theravance or nominate any person as a director of
Theravance who is not nominated by the then incumbent directors, or propose any matter to be voted
upon by the stockholders of Theravance. 15.2 Exceptions for Purchasing Securities of Theravance.
Nothing herein shall prevent GSK or its Affiliates (or in the case of Section 15.2.4, their
employees) from: 15.2.1 purchasing the Series E Preferred Stock of Theravance on the Effective Date
as contemplated herein. 15.2.2 purchasing additional equity securities of Theravance after the
Effective Date if after such purchase GSK and its Affiliates would own in the aggregate no greater
percent of the total voting power of all voting securities of Theravance then outstanding than GSK
together with its Affiliates owned immediately after purchase of the Series E Preferred Stock on the
Effective Date. 48
<!-- page 59 -->
15.2.3 acquiring securities of Theravance issued in connection with stock splits or
recapitalizations or on exercise of pre-emptive rights afforded to Theravance stockholders
generally. 15.2.4 purchasing securities of Theravance pursuant to (i) a pension plan established for
the benefit of GSK's employees, (ii) any employee benefit plan of GSK, (iii) any stock portfolios
not controlled by GSK or any of its Affiliates that invest in Theravance among other companies, or
(iv) following an initial public offering of Theravance common stock, for the account of a GSK
employee in such employee's personal capacity. 15.2.5 acquiring securities of another biotechnology
or pharmaceutical company that beneficially owns any of Theravance's securities. 15.2.6 acquiring
equity securities of Theravance without any limitation following initiation by a third party of an
unsolicited tender offer to purchase twenty percent (20%) or more of any class or service of
Theravance's publicly traded voting securities (a "Hostile Tender Offer"); provided that the
exception provided by this Section 15.2.6 shall be limited to the classes or series of Theravance's
securities that are the subject of the Hostile Tender Offer; provided, further, that, in the event
that either (a) such Hostile Tender Offer is terminated or expires without the purchase of at least
ten percent (10%) of any class or series of Theravance's publicly traded voting securities by such
third party, or (b) the Theravance Board of Directors subsequently recommends that such offer be
accepted, then following the date of such termination, expiration or recommendation the acquisitions
by GSK and/or its Affiliates under this Section 15.2.6 prior to the events described in clauses (a)
and (b) above shall not be considered a breach by GSK of the provisions of Section 15.2 as long as
GSK, at its option, either: (i) divests (or cause to be divested) in one or more open-market
transactions such number of shares of Theravance's securities acquired by it and its Affiliates
pursuant to this Section 15.2.6 such that after such divestiture GSK and its Affiliates would own in
the aggregate no greater percent of the total voting power of all voting securities of Theravance
then outstanding than GSK together with its Affiliates owned immediately prior to the commencement
of such Hostile Tender Offer, any such divestiture to be completed as expeditiously as possible
consistent with applicable securities laws and regulations and in a manner intended to shield GSK
and its Affiliates from liability for recovery of short swing profits under Section 16 of the
Exchange Act and the rules promulgated thereunder; or (ii) enters into a voting agreement, proxy or
similar arrangement pursuant to which (A) all Theravance voting securities acquired pursuant to this
Section 15.2.6 are voted on all matters to be voted on by holders of Theravance voting securities,
including, but not limited to, in favor of any transaction involving a proposed Change in Control
(as defined below) of Theravance in the same proportion as the outstanding Theravance voting
securities not held by GSK or any GSK Affiliate are voted, (B) no Theravance voting securities
beneficially owned by GSK and/or any Affiliate abstain from such a vote, and (C) no dissenter or
appraisal or similar rights are exercised with respect to any vote relating to a Change in Control
of Theravance. 15.3 Voting. Until the date of an initial public offering of Theravance common stock,
GSK shall ensure that all outstanding Theravance voting securities beneficially owned by GSK and/or
any GSK Affiliate are voted for management's nominees to the Board of Directors of Theravance to the
extent not inconsistent with Section 2.8 of the Investors' Rights Agreement. 49
<!-- page 60 -->
15.4 Theravance Voting Securities Transfer Restrictions. 15.4.1 So long as this Agreement remains in
effect and for a period of one (1) year thereafter, neither GSK nor any of its Affiliates shall
dispose of beneficial ownership of Theravance voting securities except (i) pursuant to a bona fide
public offering registered under the Securities Act of either Theravance voting securities or
securities exchangeable or exercisable for Theravance voting securities (in which the securities are
broadly distributed and GSK does not select the purchasers); or (ii) pursuant to Rule 144 under the
Securities Act (provided that if Rule 144(k) is available, such transfer nevertheless is within the
volume limits and manner of sale requirements applicable to non-144(k) transfers under Rule 144); or
(iii) in transactions that to the knowledge of GSK do not, directly or indirectly, result in any
person or group owning or having the right to acquire or intent to acquire beneficial ownership of
Theravance voting securities with aggregate voting power of five percent or more of the aggregate
voting power of all outstanding Theravance voting securities. 15.4.2 Notwithstanding the foregoing,
the restrictions on disposition under Section 15.4.1 shall not apply if, as a result of such
disposition, (A) no filing by any Person (including, but not limited to GSK or any of its
Affiliates) shall be required under any Law (including but not limited to the Exchange Act) that
would identify GSK or any of its Affiliates as the seller of the securities, and (B) neither GSK nor
any of its Affiliates (or any transferee thereof) would be required by Law (including without
limitation the disclosure requirements of the Securities Act of 1933, as amended (the "Securities
Act"), and the Exchange Act) to make any public announcement of the transfer or disposition. 15.4.3
So long as this Agreement remains in effect and for a period of one (1) year thereafter, neither GSK
nor any of its Affiliates may make any public disclosure of any holdings of or disposition of
beneficial ownership of Theravance voting securities unless such disclosure is approved in advance
in writing by Theravance, such approval not to be unreasonably withheld or delayed. Notwithstanding
the foregoing, no consent of Theravance shall be required for any filing that GSK or any of its
Affiliates is required to make under applicable Law in any jurisdiction, including without
limitation any Form 144 under the Securities Act, any Form 4 under the Exchange Act, or any Schedule
13D or 13G or any amendments thereto under the Exchange Act; provided that, prior to making any such
filings, GSK shall use reasonable efforts to (i) to provide Theravance notice and a copy of such
proposed filings and (ii) consult with Theravance on the content of such filings. 15.5 Termination
of Purchase Restrictions. The limitations on purchase of equity securities set forth in Section 15.1
shall terminate immediately upon a transaction or series of related transactions following a Change
in Control of Theravance. ARTICLE 16 MISCELLANEOUS 16.1 Relationship of the Parties. Each Party
shall bear its own costs incurred in the performance of its obligations hereunder without charge or
expense to the other except as expressly provided in this Agreement. Neither Party shall have any
responsibility for the hiring, termination or compensation of the other Party's employees or for any
employee benefits of such employee. No employee or representative of a Party shall have any
authority to bind or obligate the other Party to this Agreement for any sum or in any manner
whatsoever, or to create or impose any contractual or other liability on the other Party without
said Party's approval. For all purposes, and notwithstanding any other provision of this Agreement
to the contrary, GSK's legal 50
<!-- page 61 -->
relationship under this Agreement to Theravance shall be that of independent contractor. This
Agreement is not a partnership agreement and nothing in this Agreement shall be construed to
establish a relationship of co-partners or joint venturers between the Parties. 16.2 Registration
and Filing of This Agreement. To the extent, if any, that either Party concludes in good faith that
it or the other Party is required to file or register this Agreement or a notification thereof with
any Governmental Authority, including without limitation the U.S. Securities and Exchange
Commission, the Competition Directorate of the Commission of the European Communities or the U.S.
Federal Trade Commission, in accordance with Law, such Party shall inform the other Party thereof.
Should both Parties jointly agree that either of them is required to submit or obtain any such
filing, registration or notification, they shall cooperate, each at its own expense, in such filing,
registration or notification and shall execute all documents reasonably required in connection
therewith. In such filing, registration or notification, the Parties shall request confidential
treatment of sensitive provisions of this Agreement, to the extent permitted by Law. The Parties
shall promptly inform each other as to the activities or inquiries of any such Governmental
Authority relating to this Agreement, and shall reasonably cooperate to respond to any request for
further information there from on a timely basis. 16.3 Force Majeure. The occurrence of an event
which materially interferes with the ability of a Party to perform its obligations or duties
hereunder which is not within the reasonable control of the Party affected or any of its Affiliates,
not due to malfeasance by such Party or its Affiliates, and which could not with the exercise of due
diligence have been avoided (each, a "Force Majeure Event"), including, but not limited to, an
injunction, order or action by a Governmental Authority, fire, accident, labor difficulty, strike,
riot, civil commotion, act of God, inability to obtain raw materials, delay or errors by shipping
companies or change in law, shall not excuse such Party from the performance of its obligations or
duties under this Agreement, but shall merely suspend such performance during the continuation of
the Force Majeure. The Party prevented from performing its obligations or duties because of a Force
Majeure Event shall promptly notify the other Party of the occurrence and particulars of such Force
Majeure and shall provide the other Party, from time to time, with its best estimate of the duration
of such Force Majeure Event and with notice of the termination thereof. The Party so affected shall
use Diligent Efforts to avoid or remove such causes of nonperformance as soon as is reasonably
practicable. Upon termination of the Force Majeure Event, the performance of any suspended
obligation or duty shall promptly recommence. The Party subject to the Force Majeure Event shall not
be liable to the other Party for any direct, indirect, consequential, incidental, special, punitive,
exemplary or other damages arising out of or relating to the suspension or termination of any of its
obligations or duties under this Agreement by reason of the occurrence of a Force Majeure Event,
provided such Party complies in all material respects with its obligations under this Section 16.3.
16.4 Governing Law. This Agreement shall be construed, and the respective rights of the Parties
determined, according to the substantive law of the State of Delaware notwithstanding the provisions
governing conflict of laws under such Delaware law to the contrary, except matters of intellectual
property law which shall be determined in accordance with the intellectual property laws relevant to
the intellectual property in question. 16.5 Attorneys' Fees and Related Costs. In the event that any
legal proceeding is brought to enforce or interpret any of the provisions of this Agreement, the
prevailing party shall be entitled to recover its reasonable attorneys' fees, court costs and
expenses of litigation whether or not the action or proceeding proceeds to final judgment. 51
<!-- page 62 -->
16.6 Assignment. This Agreement may not be assigned by either Party without the prior written
consent of the other Party; provided, however that either Party may assign this Agreement, in whole
or in part, to any of its Affiliates if such Party guarantees the performance of this Agreement by
such Affiliate; and provided further that either Party may assign this Agreement to a successor to
all or substantially all of the assets of such Party whether by merger, sale of stock, sale of
assets or other similar transaction. This Agreement shall be binding upon, and subject to the terms
of the foregoing sentence, inure to the benefit of the Parties hereto, their permitted successors,
legal representatives and assigns. 16.7 Notices. All demands, notices, consents, approvals, reports,
requests and other communications hereunder must be in writing and will be deemed to have been duly
given only if delivered personally, by facsimile with confirmation of receipt, by mail (first class,
postage prepaid), or by overnight delivery using a globally-recognized carrier, to the Parties at
the following addresses: Theravance: Theravance, Inc. 901 Gateway Boulevard South San Francisco, CA
94080 Facsimile: 650-827-8683 Attn: Senior Vice President, Commercial Development GSK: Glaxo Group
Limited Glaxo Wellcome House Berkeley Avenue Greenford Middlesex UB6 0NN United Kingdom Attn:
Company Secretary Facsimile: 011 44 208-047-6912 With a copy to: GlaxoSmithKline plc 980 Great West
Road Brentford Middlesex TW8 9GS United Kingdom Attn: Corporate Law Facsimile: 011 44 208-047-6912
and with a copy to: Brentford Middlesex TW8 9GS United Kingdom Attn: Vice President, Worldwide
Business Development Facsimile: 011 44 208-990-8142 or to such other address as the addressee shall
have last furnished in writing in accord with this provision to the addressor. All notices shall be
deemed effective upon receipt by the addressee. 16.8 Severability. In the event of the invalidity of
any provisions of this Agreement or if this Agreement contains any gaps, the Parties agree that such
invalidity or gap shall not affect 52
<!-- page 63 -->
the validity of the remaining provisions of this Agreement. The Parties will replace an invalid
provision or fill any gap with valid provisions which most closely approximate the purpose and
economic effect of the invalid provision or, in case of a gap, the Parties' presumed intentions. In
the event that the terms and conditions of this Agreement are materially altered as a result of the
preceding sentences, the Parties shall renegotiate the terms and conditions of this Agreement in
order to resolve any inequities. Nothing in this Agreement shall be interpreted so as to require
either Party to violate any applicable laws, rules or regulations. 16.9 Headings. The headings used
in this Agreement have been inserted for convenience of reference only and do not define or limit
the provisions hereof. 16.10 Waiver. Any term or condition of this Agreement may be waived at any
time by the Party that is entitled to the benefit thereof, but no such waiver shall be effective
unless set forth in a written instrument duly executed by or on behalf of the Party waiving such
term or condition. No waiver by any Party of any term or condition of this Agreement, in any one or
more instances, shall be deemed to be or construed as a waiver of the same or any other term or
condition of this Agreement on any future occasion. Except as expressly set forth in this Agreement,
all rights and remedies available to a Party, whether under this Agreement or afforded by law or
otherwise, will be cumulative and not in the alternative to any other rights or remedies that may be
available to such Party. 16.11 Entire Agreement. This Agreement (including the exhibits and
schedules hereto) constitutes the entire agreement between the Parties hereto with respect to the
within subject matter and supersedes all previous agreements and understandings between the Parties,
whether written or oral. This Agreement may be altered, amended or changed only by a writing making
specific reference to this Agreement and signed by duly authorized representatives of Theravance and
GSK. 16.12 No License. Nothing in this Agreement shall be deemed to constitute the grant of any
license or other right in either Party, to or in respect of any Collaboration Product, patent,
trademark, Confidential Information, trade secret or other data or any other intellectual property
of the other Party, except as expressly set forth herein. 16.13 Third Party Beneficiaries. None of
the provisions of this Agreement shall be for the benefit of or enforceable by any Third Party,
including without limitation any creditor of either Party hereto. No such Third Party shall obtain
any right under any provision of this Agreement or shall by reasons of any such provision make any
Claim in respect of any debt, liability or obligation (or otherwise) against either Party hereto.
16.14 Counterparts. This Agreement may be executed in any two counterparts, each of which, when
executed, shall be deemed to be an original and both of which together shall constitute one and the
same document. 53
<!-- page 64 -->
16.15 Single Closing Condition. The obligation of each Party to consummate the transaction
contemplated hereby is subject to the satisfaction of the following condition (the "Closing
Condition"): All filings under the Hart-Scott-Rodino Antitrust Improvements Act of 1976 and any
other similar competition or merger control laws that are necessary in any jurisdiction with respect
to the transaction contemplated hereby shall have been made and any required waiting period under
such laws shall have expired or been terminated and any Governmental Authority that has power under
or authority to enforce such laws shall have, if applicable, approved, cleared or decided neither to
initiate proceedings or otherwise intervene in respect of the transaction contemplated hereby nor to
refer the transaction to any other competent Governmental Authority. Each Party shall use good faith
efforts to take, or cause to be taken, all actions, and to do, or cause to be done, and to assist
and cooperate with the other party in doing, all things necessary, proper or advisable to consummate
and make effective the transaction contemplated by this Agreement, including, but not limited to
satisfaction of the Closing Condition and each Party shall keep the other Party reasonably apprised
of the status of matters relating to the completion of same. In connection with the foregoing, the
Parties hereby agree to negotiate in good faith to make as soon as practicable any modification or
amendment to this Agreement or any agreement related hereto that is required by the United States
Federal Trade Commission, Department of Justice or equivalent Governmental Authority, provided that
no Party shall be required to agree to any modification or amendment that, in the reasonable opinion
of such Party's external legal or financial counsel, would be adverse to such Party. This Agreement
may be terminated by either Party upon written notice any time after June 1, 2003 if the
transactions contemplated by this Agreement shall not have been consummated by June 1, 2003 due to
failure to satisfy the Closing Condition; provided, however, that the terminating Party shall not
have breached in any material respect its obligations under this Agreement in any manner that shall
have been the proximate cause of, or resulted in, the failure to satisfy the Closing Condition or
otherwise to consummate the transactions contemplated by this Agreement by such date. 54
<!-- page 65 -->
IN WITNESS WHEREOF, Theravance and GSK, by their duly authorized officers, have executed this
Agreement on November 14, 2002. THERAVANCE, INC.

GLAXO GROUP LIMITED By: /s/ Rick E Winningham

By: /s/ Jean-Pierre Garnier

Rick E Winningham

Jean-Pierre Garnier

Chief Executive Officer

Chief Executive Officer 55
<!-- page 66 -->
Schedule 1.19 Criteria for Theravance New Compounds and Replacement Compounds 1. Single optical
isomer, which is patentable. 2. Potency in vitro and in vivo compatible with potential to develop in
a DPI device. 3. Intrinsic agonist activity not less than that of salmeterol. 4. Selectivity at β
adrenoceptors, relative to β and β adrenoceptors, similar or superior to that of formoterol,
assessed in assays determining equi- potent molar ratios relative to that of isoprenaline
(isoproterenol). 5. Selectivity at non-β adrenoceptors >100. 6. No significant inhibition of the
hERG potassium channel at a concentration at least 30 fold greater than the anticipated therapeutic
maximum concentration in plasma. 7. Duration of agonist activity in vivo to be clearly longer than
that of salmeterol. This would be at least 72 hours in the Theravance model. The exact duration
criterion for either the GSK or the Theravance model might be modified in the light of forthcoming
clinical data from the program. 8. Stable compound suitable for formulation to pursue FTIM studies,
with crystalline form identified. 9. Oral bioavailability to be less than 10% in the rat and less
than 25% in the dog. 10. No significant generation of markedly active metabolite(s) in vitro. 11.
Irritation to the respiratory tract no worse than salmeterol in a non-GLP 7-day inhaled rat study.
56

2 1 3

2
