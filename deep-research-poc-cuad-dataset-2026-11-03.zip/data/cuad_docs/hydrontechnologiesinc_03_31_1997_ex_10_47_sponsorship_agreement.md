<!-- page 1 -->
# SPONSORSHIP AGREEMENT
| Field | Value |
|---|---|
| Document Type | Sponsorship Agreement |
| Agreement Date | 1997-01-01 |
| Parties | HYDRON TECHNOLOGIES, INC. ("Hydron"); MIAMI DOLPHINS, LTD. ("Dolphins") |
| Source | CUAD v1 / HYDRONTECHNOLOGIESINC_03_31_1997-EX-10.47-SPONSORSHIP AGREEMENT |

SPONSORSHIP AGREEMENT

THIS SPONSORSHIP AGREEMENT ("Agreement") is made and entered into as of this 1st day of January,
1997, by and between HYDRON TECHNOLOGIES, INC., a New York corporation with its principal offices
located at 1001 Yamato Road, Suite 403, Boca Raton, Florida 33431, ("Hydron") and MIAMI DOLPHINS,
LTD., a Florida limited partnership with its principal offices located at 7500 Southwest 30th
Street, Davie, Florida 33314 ("Dolphins").

WHEREAS, the Dolphins own and operate the Miami Dolphins, a professional football team and member of
the National Football League, which presently is scheduled to play its home games at Pro Player
Stadium in Miami, Florida (the "Stadium"); and Hydron desires to be a sponsor of the Miami Dolphins
for certain entertainment and promotional purposes in connection with the Miami Dolphins including
its home games during the term of this Agreement; and

NOW THEREFORE, for good and valuable consideration, the receipt of which is hereby acknowledged,
Hydron and the Dolphins hereby agree as follows:

1. TERM OF AGREEMENT

1.1 The term of this Agreement shall commence on the date hereof and terminate upon the conclusion
of the week following the conclusion of the Dolphins 2000 regular season or post season, if
applicable (the "Term" or "Initial Term"). However, this Agreement may be earlier terminated in
accordance with the provisions hereof.

1.2 Hydron shall have the right to terminate this Agreement upon written notice to Dolphins at any
time between November 1, 1997 and December 15, 1997, in which event this Agreement shall be
terminated following the Dolphins last 1997 regular or post-season game, if any. If Hydron does not
timely exercise its right to terminate this Agreement, then Hydron agrees that this Agreement shall
continue for the entire four (4) year term unless earlier terminated pursuant to Section 8 of this
Agreement.

2. SPONSORSHIP RIGHTS

2.1 For the Term of this Agreement, the Dolphins will provide Hydron with certain advertising and
promotional benefits as are set forth in and in accordance with Exhibit "A" attached hereto and made
a part hereof (the "Sponsorship Rights").

2.2 For the Term of this Agreement, Hydron shall be designated as a sponsor of the Dolphins in the
Sunscreen/Skin Care Category (as defined below) and a licensee of the Marks (as defined below) in
the Sunscreen/Skin Category by the Dolphins. For purposes of this Agreement, the term
"Sunscreen/Skin Care Category" means the product category consisting of sunscreen, sun protection
and similar skin care products.

2.3 The Sponsorship Rights granted by the Dolphins to Hydron are subject to

termination in whole or in part at any time upon written notice to Hydron if such Sponsorship Rights
conflict with any exclusive advertising rights granted by NFL Properties, Inc. to one of its
advertisers or sponsors. In the event of any such termination of exclusivity, the non-terminated
Sponsorship Rights granted to Hydron by the Dolphins shall nonetheless continue for the remainder of
the Term and the provisions of Section 8.2 shall apply. As of the date hereof, the Dolphins have no
knowledge of any claim by NFL Properties that the Sponsorship Rights violate or conflict with
exclusive rights granted by NFL Properties.

3. CONSIDERATION

3.1 In consideration of the Sponsorship Rights granted to Hydron hereunder:

(a) Hydron shall pay to the Dolphins an aggregate amount of $96,000 (plus any applicable sales and
other taxes) as follows: Hydron shall pay Dolphins the sum of $24,000 (plus any applicable sales and
other taxes) on July 1, 1997, July 1, 1998, July 1, 1999 and July 1, 2000.

3.2 In the event that the consideration is not paid by Hydron on or before the applicable payment
due date, said failure to pay shall be considered a material breach by Hydron, and the Dolphins may
elect to charge Hydron a late fee of 1.5% per month of the payment then due and owing until it is
paid in full. The Dolphins agree to provide written notice to Hydron of the failure to receive any
payment, and Hydron shall have a five (5) business day period following delivery of written notice
in which to cure the payment default before the Dolphins may elect to terminate this Agreement and
pursue applicable remedies. It is agreed by Hydron that any such election of remedies does not waive
any other remedies for breach of contract available to the Dolphins.

3.3 Except as otherwise specifically provided in this Agreement, including Exhibit "A", each of the
parties shall pay its own expenses of performing its obligations under this Agreement.
<!-- page 2 -->
4. USE OF MARKS

4.1 Hydron and the Dolphins may use the name, logos, colors, trademarks, service marks, or other
identifying features ("Marks") of the other, as specifically contemplated in connection with the
Sponsorship Rights, subject to any limitations set forth in this Agreement.

4.2 All advertising material and any use of the other parties' Marks by a party is subject to the
prior written approval of the Mark owner. Either party shall submit all such materials or proposed
usage of a Mark to the other party at least two weeks prior to its intended use. The Mark owner
shall have the right to inspect and require changes or deletions (including the right to disapprove
of such advertisement or use of Marks in their entirety) of advertising and promotional copy or
material that the Mark owner may deem to be contrary to its policies or best interests. Such
requirements will not be unreasonably imposed, and the foregoing approvals and

2

requirements will be consistently given and imposed on all sponsors or users of the Marks, as the
case may be.

4.3 Any and all public announcements or press releases by or on behalf of the other party regarding
the Sponsorship Rights or the details of this Agreement shall be subject to the consent of the other
party, and each party shall have the right to approve in advance the contents and timing thereof.
Notwithstanding the foregoing, the Dolphins acknowledge that Hydron, as a publicly held company, has
disclosure obligations pursuant to the federal securities laws. Hydron agrees to take the comments
of the Dolphins into account in preparing and disseminating such disclosure, but notwithstanding
comments from the Dolphins, Hydron shall make such disclosure as may be required by law.

4.4 For purposes of this Agreement, the Dolphins and Hydron expressly recognize that the Marks are
the unique, valid and exclusive property of the respective owner of the Mark. The Dolphins and
Hydron agree that they shall not, either during the term of this Agreement or thereafter, directly
or indirectly, contest the validity of the other's Marks or any of the registrations pertaining
thereto, in the United States or elsewhere, nor adopt the other's Marks or any term, word, mark or
designation which is in any aspect confusingly similar to the other's Marks. The Dolphins and Hydron
specifically acknowledges that any use of the Marks pursuant to this Agreement shall not create for
the Dolphins or Hydron any right, title or interest in the other's Marks. The Dolphins and Hydron
further agree that they will not at any time do or cause to be done any act or thing, directly or
indirectly, which contests or in any way impairs or tends to impair any part of the right, title and
interest of the other in its Marks; and the Dolphins and Hydron shall not, in any manner, represent
that it has any ownership interest in the other's Marks or the registrations therefor. Upon
termination of this Agreement, the Dolphins and Hydron shall immediately terminate all use of the
other's Marks.

4.5 Hydron expressly recognizes that the Dolphins have previously granted the exclusive rights to
license and sublicense its Marks to NFL Properties, Inc., and that the grant to Hydron of the right
to use the Marks is subject to the prior approval of NFL Properties, Inc. In the event that such
approval is not so given by NFL Properties, Inc., then such usage rights of Hydron shall immediately
terminate. The Dolphins represent that they will use reasonable efforts to obtain the consent of NFL
Properties, Inc. to the execution and performance of this Agreement prior to their execution hereof.
In any such event, the provisions of Section 8.2 will apply.

5. STADIUM POLICY; GOVERNING LEAGUE POLICIES

5.1 Hydron and the Dolphins agree that this Agreement shall be performed in accordance with rules
and policies of the Stadium as may be applicable to this Agreement, if any. The Dolphins will advise
Hydron of any development of or changes in these rules and policies that might adversely affect the
terms of this Agreement.

5.2 The parties agree that this Agreement shall automatically be subject to any new or amended
National Football League (the "NFL") rules or regulations applicable to advertising or promotional
benefits provided by NFL member teams to its sponsors effective as

3

of the date such regulation shall take effect and that this Agreement shall incorporate and be
subject to the Constitution, By-Laws, rules and regulations, the duly authorized resolutions of the
governing body, the decrees and rulings of the commissioner and the terms and conditions of any and
all agreements to which the NFL is a party and as to which the NFL has bound its member clubs
(collectively all of such regulations, resolutions, decrees and agreements are referred to as the
"Governing League Policies"). The Dolphins shall advise Hydron of any changes therein which may
materially and adversely affect the Sponsorship Rights. As of the date hereof, the Dolphins have no
knowledge of any claim by the NFL that the Sponsorship Rights violate any Governing League Rules.

5.3 Without limiting any other potential uses of the Dolphins' Marks, Hydron agrees that the
Dolphins may allow or authorize any League Sponsor (as defined below) to engage in advertising and
promotional activities in the Dolphins' local market (including, without limitation, the Stadium),
or
<!-- page 3 -->
otherwise provide benefits to such League Sponsor, if such League Sponsor is entitled to engage in
such activities or receive such benefits pursuant to any sponsorship or promotional licensing
arrangement now or hereafter entered into between such League Sponsor and the NFL or any of its
affiliates (including, without limitation, NFL Properties, Inc., NFL Enterprises, Inc. and NFL
Films, Inc.). For purposes of this Agreement the term, "League Sponsor" shall mean any person or
entity which currently is, or at any time becomes a sponsor or promotional licensee of or with
respect to any NFL event or program now or hereafter in existence. By way of illustration only and
without limiting the generality of the foregoing, League Sponsors may place advertising and
promotional materials (including displays) in the Stadium, in connection with a League event, such
as the Super Bowl.

5.4 If any rule or regulation of the Stadium, or any Governing League Policy as described in
Sections 5.1, 5.2 or 5.3 requires the termination or revision of any Sponsorship Right, such
Sponsorship Right shall be revised or terminated upon written notice to Hydron and the provisions of
Section 8.2 shall apply to such termination or revisions.

6. REPRESENTATIONS AND WARRANTIES

6.1 Hydron represents and warrants to the Dolphins the following, all of which representations and
warranties shall apply during the Term of this Agreement.

(a) Hydron is a corporation in good standing under the laws of the state of New York and is duly
authorized to transact business in Florida, with full power and authority to enter into and fully
perform its obligations under this Agreement. The execution and delivery of this Agreement on behalf
of Hydron has been duly authorized by Hydron and this Agreement

constitutes a valid, binding and enforceable obligation of Hydron.

(b) Neither this Agreement nor anything required to be done hereunder by Hydron violates or shall
violate any corporate charter, contract or other document to which Hydron is a party or by which it
is otherwise bound.

6.2 The Dolphins represents and warrants to Hydron the following, all of

4

which representations and warranties shall apply during the Term of this Agreement

(a) The Dolphins is a Florida limited partnership in good standing under the laws of the State of
Florida and the Dolphins is duly authorized to transact business in Florida, with full power and
authority to enter into and fully perform its obligations under this Agreement. The execution and
delivery of this Agreement on behalf of the Dolphins has been duly authorized by the Dolphins and
this Agreement constitutes a valid, binding and enforceable obligation thereof.

(b) Neither this Agreement nor anything required to be done hereunder by the Dolphins violates or
shall violate any partnership agreement, corporate charter, contract or other document to which the
Dolphins is a party or by which it is otherwise bound.

7. HOLD HARMLESS AND INDEMNIFICATION

7.1 Each of the parties shall indemnify and hold harmless the other, and their respective partners,
shareholders, officers, employees, agents and representatives (collectively, the "Indemnitees") from
and against any and all claims, orders, damages, liabilities, costs and expenses, including
reasonable attorney's fees, arising out of the other party's negligent actions or omissions with
respect to this Agreement, or such party's wilful misconduct or breach of any representation,
warranty or agreement in this Agreement applicable to it. Neither party shall have an obligation to
indemnify or hold harmless an Indemnitees from any claim arising from or related to the Indemnitees
negligence or misconduct. Each party hereto shall promptly notify the other of any claim or
litigation to which the indemnity set forth in this paragraph applies. Each of the parties agree to
defend all actions to which such indemnity applies and to conduct the defense thereof at its expense
and by qualified counsel, which counsel shall be reasonably satisfactory to the Indemnitees. Each of
the parties agree that the foregoing indemnities also apply for the benefit of the NFL (and its
affiliates), South Florida Stadium Corporation, the owner and operator of Pro Player Stadium and
their respective officials, officers, partners, agents and employees, who shall be deemed third
party beneficiaries of this Agreement for the purpose of enforcing these indemnity obligations.
These indemnity obligations shall survive the termination or expiration of this Agreement.

7.2 Insurance. The Dolphins shall, at its own expense, maintain in effect throughout the term of
this Agreement, comprehensive general liability insurance policies with carriers of recognized
standing, with limits of liability of at least One Million Dollars ($1,000,000), governing any and
all property damage and person injury (including death) arising out of activities covered by this
Agreement. Hydron shall, at its own expense, maintain in effect throughout the term of this
Agreement, comprehensive general liability insurance policies with carriers of recognized standing,
with limits of liability of at least One Million Dollars ($1,000,000), covering any and all property
damage and personal injury (including death) arising out of activities covered by this
<!-- page 4 -->
Agreement and shall obtain and maintain such additional insurance coverage as the Dolphins shall
reasonably require with respect to any Sponsored Events or similar activities.

5

8. TERMINATION

8.1(a) Without prejudice to any other rights, the Dolphins shall have the right to terminate this
Agreement upon written notice to Hydron if Hydron fails to perform or comply with any term or
condition of this Agreement within five (5) business days following delivery of written notice for a
payment default or within thirty (30) days following written notice of any other breach of this
Agreement sent to Hydron stating such failure or failures; provided that any such failure remains
uncured at the end of such period.

(b) Without notice to any rights, Hydron shall have the right to terminate this Agreement upon
written notice to Dolphins, if Dolphins fail to perform or comply with any material terms or
conditions of this Agreement within thirty (30) days following delivery of written notice to
Dolphins stating such failure or failures; provided that any failure remains uncured at the end of
such period.

8.2 This Agreement may be terminated by the Dolphins or modified to reduce or eliminate certain
promotional benefits (such as use of Marks or Sponsorship Rights), as described in Sections 2.3, 4.5
and 5.4 hereof. Upon any such termination or modification, the Dolphins will in good faith attempt
to substitute a promotional benefit of equivalent promotional value for any benefits that the
Dolphins was forced to eliminate; or, if the Dolphins is unable to substitute a promotional benefit
of similar magnitude, then the Dolphins and Hydron shall attempt, in good faith, to agree upon an
adjustment in the amount of fees payable by Hydron to the Dolphins under this Agreement. If the
Dolphins and Hydron cannot agree upon an adjustment in the amount of fees payable hereunder, then
Dolphins and Hydron agree to arbitrate the adjustment in fees and to be bound by the decision of the
arbitrators. Any such arbitration shall be conducted in accordance with the rules of the American
Arbitration Association.

8.3 Upon termination of this Agreement, all rights and privileges granted to Hydron hereunder shall
automatically revert to the Dolphins. Upon termination of this Agreement by the Dolphins pursuant to
paragraph 8.1(a), any and all payments then or later due to the Dolphins shall

become due and payable in full immediately, and no portion of any prior payments made to the
Dolphins shall be refundable.

8.4 In the event that Hydron terminates this Agreement pursuant to the provisions of Section 8.1(b),
then the fees paid, if any, for the balance of the term of this Agreement shall be immediately
refunded to Hydron provided Hydron has not received sponsorship rights or benefits equal to such
fees.

9. MISCELLANEOUS

9.1 The parties hereto agree to maintain in confidence the terms and conditions of this Agreement,
except to the extent that a proposed disclosure by a party of any specifications or conditions
hereof is authorized in advance by the other party pursuant to Section 4.3 or is otherwise required
by law.

6

9.2 It is mutually understood and agreed that Hydron and the Dolphins, and their respective
partners, officers, employees, representatives and agents are, at all times, herein, acting and
performing separately and independently of each other and are in no way or manner to represent
themselves as agents or employees of the other party. As such, no party shall incur any expenses or
create any liens or encumbrances in another party's name or against another party's interests. This
Agreement shall not create a joint venture, partnership, or a relationship of principal and agent,
or of employer and employee, between the parties.

9.3 All notices required to be given hereunder shall be properly served if in writing and delivered
either by (i) personal delivery, (ii) certified or registered mail, postage prepaid, facsimile, or
(iii) by recognized overnight courier service which delivers only upon the signed receipt of the
addressee, which in any case shall be delivered to the respective addresses set forth at the
beginning of this Agreement or such other addresses as may be designated by written notice by such
party. Notice shall be deemed given on the date of delivery of such notice to the recipient or the
date of refusal to accept delivery of such notice by the addressee or its agent.

9.4 In connection with any action arising from or in connection with the enforcement of this
Agreement, the prevailing party shall be entitled to an award of its expenses, including reasonable
attorneys' fees and disbursements, incurred or paid before and at trial or any other proceeding
which may be instituted, at any tribunal level, and whether or not suit or any other proceeding is
instituted.

9.5 This Agreement shall be governed by and construed in accordance with the laws of the State of
Florida. Jurisdiction and venue for any legal proceedings arising out of this Agreement shall
exclusively lie in the
<!-- page 5 -->
state and federal courts situate in Broward County, Florida.

9.6 No party may assign any of its rights or obligations

hereunder without the prior written consent of the other party, except that Hydron may assign its
rights and obligations under this Agreement to its parent, its successor or to an affiliate (as such
term is defined under the rules and regulations promulgated under the federal securities laws of the
U.S.) upon the reasonable consent of the Dolphins that such affiliate assignee has the financial
means and corporate authority to perform such obligations and Hydron may not withhold its consent to
an assignment of this Agreement in the event of a merger or reorganization of the Dolphins, a sale
of all or substantially all of the Dolphins' assets or a consolidation of the Dolphins with any of
its affiliates or related parties.

9.7 In the event that the performance of this Agreement is prevented because of an act of nature or
force majeure or if the exhibition of any scheduled home games of the Dolphins is canceled because
of strike, lockout, labor dispute or other cause of similar nature beyond the reasonable control of
the Dolphins, the same shall not constitute a breach of this Agreement. The Dolphins hereby agree,
in good faith, to attempt to reschedule any aspect of the Sponsorship Rights which is prevented from
occurring as scheduled, at such date as may be

7

reasonably agreeable to the Dolphins and Hydron. If one or more events or benefits are unable to be
rescheduled during the Term of this Agreement, the provisions of Section 8.2 shall apply in the same
manner as if such failure to reschedule caused a termination of a Sponsorship Right. Nothing stated
in this Agreement grants Hydron any sponsorship, promotional or other rights with respect to any
Super Bowl, Pro Bowl or NFL conference championship or play-off games or any other football game(s)
which are not part of the preseason or regular season schedule of games to be played at home by the
Miami Dolphins.

9.8 This Agreement (including Exhibit "A") sets forth the entire understanding and agreement of the
parties hereto with respect to its subject matter and supersedes all prior under standings or
agreements between the parties relating to the same subject matter. Any amendments or modifications
to this Agreement shall be in writing, as mutually agreed upon by both parties.

IN WITNESS WHEREOF, the parties have caused this Agreement to be executed by their respective
authorized representatives, effective as of the date first shown above.

HYDRON TECHNOLOGIES, INC.

By: /s/ Harvey Tauman ------------------------------------- Harvey Tauman President and Chairman
Date: ------------------------------

MIAMI DOLPHINS, LTD., a Florida limited partnership

By: SOUTH FLORIDA FOOTBALL CORPORATION, its General Partner

By: /s/ Eddie Jones ------------------------------------- Eddie Jones, President Date:
------------------------------

8

EXHIBIT A

MIAMI DOLPHINS/HYDRON TECHNOLOGIES, INC.

SPONSORSHIP RIGHTS

Season-Long Merchandising

PRINT ADVERTISING

The Dolphins will provide to Hydron:

o One full page, four (4) color advertisement for Hydron in all ten (10) issues of GameDay Magazine,
the official publication of the National Football League and the Miami Dolphins distributed at Pro
Player Stadium during each year during the Term.

PROMOTIONAL MEDIA
<!-- page 6 -->
In connection with this Agreement, Dolphins will provide the following promotional media:

1996 BENEFITS PROVIDED TO HYDRON

o Executive Suite: 320A. Use of the executive suite for the December 8, 1996 game vs. the New York
Giants. The game will include twelve (12) tickets and two (2) parking passes.

o Stadium Signage: Hydron sign will be in place on the West Scoreboard - Secondary Tri-Vision Panel
for the December 8, 1996 game vs. the New York Giants and the December 16, 1996 game vs. the Buffalo
Bills.

o Product Sampling: Hydron will provide ten thousand (10,000) sunscreen samples which will be
distributed to club level patrons prior to and during the December 8, 1996 game vs. the New York
Giants. The Dolphins will permit Hydron to set up four (4) display booths which will be staffed by
Hydron employees to distribute the sunscreen.

1997-2000 BENEFITS TO HYDRON

o "Defensive Play of the Week" Promotion: Hydron will be the title sponsor of the 30-second Jumbtron
video "Defensive Player of the Week" promotion which will be displayed during each Miami Dolphins
home game.

9

o Product Sampling: The Dolphins will permit Hydron to distribute sunscreen product samples to fans
in attendance at one (1) home game during each contract year. Hydron will set up four (4) display
booths and will staff them with Hydron employees. The Dolphins will also permit Hydron to distribute
sunscreen product samples during the first two (2) weeks of training camp at the Dolphins training
facility in Davie during each contract year.

o Team Affiliation: Hydron will be permitted to advertise itself as a "Proud Sponsor of the Miami
Dolphins" in the skin care category.

o Easements: The Miami Dolphins will use reasonable efforts to provide endorsements of Hydron
sunscreen/skin protection products from its training staff.

10
