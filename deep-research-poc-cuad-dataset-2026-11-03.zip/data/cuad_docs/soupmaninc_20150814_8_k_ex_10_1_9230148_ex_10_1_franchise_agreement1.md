<!-- page 1 -->
# MASTER FRANCHISE AGREEMENT
| Field | Value |
|---|---|
| Document Type | Franchise Agreement |
| SEC Filing Date | 2015-08-14 |
| Parties | Kiosk Concepts Inc. ("we", "us", "our"); The Grilled Cheese Truck, Inc. ("you", "your", "Master Franchisee") |
| Source | CUAD v1 / SoupmanInc_20150814_8-K_EX-10.1_9230148_EX-10.1_Franchise Agreement1 |

Exhibit 10.1

KIOSK CONCEPTS, INC. MASTER FRANCHISE AGREEMENT THE GRILLED CHEESE TRUCK, INC. MASTER FRANCHISEE
DATE OF AGREEMENT

Source: SOUPMAN, INC., 8-K, 8/14/2015
<!-- page 2 -->
TABLE OF CONTENTS 1. GRANT OF FRANCHISE 1 1.1 Rights Granted to You 1 1.2 Non-Exclusive Grant 2 1.3
Our Reserved Rights 2 2. OPERATION OF THE FRANCHISED BUSINESS 2 2.1 Name of Franchised Business 2
2.2 Full Time, Attention and Best Efforts 2 2.3 Modifications to System and Manuals 3 3. INITIAL AND
EXTENDED TERMS 3 3.1 Initial Term 3 3.2 Options to Renew 3 3.3 Renewal of Existing Agreement 4 3.4
Continued Compliance 4 3.5 Termination at End of Term 4 4. PAYMENT OF FEES 4 4.1 Initial Franchise
Fee 4 4.2 Continuing Fees Payable to Us 4 4.3 Manner of Payment 5 4.4 Interest on Overdue Amounts 5
4.5 Late Fee; Insufficient Funds Fee 6 4.6 Unit Franchise Agreements and Revenue Reports 6 4.7
Security Interest 6 4.8 Reimbursement of Monies 7 4.9 Application of Fees 7 5. YOUR OBLIGATIONS 7
5.1 Sale of Unit Franchises; Minimum Development Quota 8 5.2 Initial Training and Services for Unit
Franchisees 9 5.3 Use of Proprietary Marks 10 5.4 Place of Business 10 5.5 Insurance 10 5.6 Computer
Hardware and Software 11 5.7 Payment of Taxes 12 5.8 Enforcement of Unit Franchise Agreements 12 5.9
Master Franchisee Training Program 12 5.10 Additional Training; Master Franchisee Meetings 13 5.11
Supplies and Equipment 13 5.12 Compliance with Governmental Regulations and Applicable Law 13 5.13
Office Location 13 5.14 Solicitation Advertising 14 5.15 Policies and Procedures 14 5.16 Changes to
the System 14 5.17 Developments are Our Property 15 5.18 Financial Statements and Updated Unit
Franchise Disclosure Document 15 5.19 Our Website 15

i

Source: SOUPMAN, INC., 8-K, 8/14/2015
<!-- page 3 -->
6. PROPRIETARY MARKS 17 6.1 Our Representations 17 6.2 Your Representations 17 6.3 Your
Acknowledgments 18 6.4 Changes in Law Affecting Proprietary Marks 19 7. NON-COMPETITION 20 7.1
Restrictions 20 7.2 Independent Covenants 20 7.3 Reduction of Scope 20 7.4 No Defense 20 7.5
Irreparable Injury 20 7.6 Additional Parties 20 8. MANUALS AND CONFIDENTIAL INFORMATION 21 8.1 Use
of Manuals 21 8.2 Confidentiality of Information 21 8.3 Irreparable Injury from Disclosure of
Confidential Information 21 8.4 Confidentiality Covenants from Individuals Associated with You 21 9.
OUR OBLIGATIONS 22 9.1 Manuals and Assistance 22 9.2 Training Program 22 9.3 Advice and Assistance
22 9.4 Proprietary Marks 22 9.5 Advice 22 10. DEFAULT AND TERMINATION 22 10.1 Termination in the
Event of Bankruptcy or Insolvency 22 10.2 Termination with Notice and Without Opportunity to Cure 23
10.3 Termination with Notice and Opportunity to Cure 24 10.4 Cross-Default 24 10.5 Our Right to
Discontinue Services to You 25 10.6 Termination of This Agreement by You 25 10.7 Without Prejudice
25 10.8 Amendment Pursuant to Applicable Law 25 11. OBLIGATIONS UPON TERMINATION OR EXPIRATION 26
11.1 Cessation of Business 26 11.2 Cessation of Use of Confidential Information and Proprietary
Marks 26 11.3 Cancellation of Assumed Name Registration 26 11.4 Payment of Monies Due; Liquidated
Damages 26 11.5 Costs to Secure Compliance 27 11.6 Return of Manuals and Other Confidential
Information 27 11.7 Irreparable Injury to Us 27 11.8 Compliance with Post-Term Covenants 27 12.
TRANSFER OF INTEREST 27 12.1 Transfer by Us 27 12.2 Transfer by You 28 12.3 Granting of a Security
Interest by You 28

ii

Source: SOUPMAN, INC., 8-K, 8/14/2015
<!-- page 4 -->
12.4 Transfer Upon Death or Disability 28 12.5 Non-waiver of Claims 29 12.6 Transfer by You in
Bankruptcy - Right of First Refusal 29 13. UNIT FRANCHISEES 29 13.1 Form of Unit Franchise
Disclosure Document and Unit Franchise Agreement 29 13.2 Unit Franchise Disclosure Document and Unit
Franchise Agreement Amendments 30 13.3 Use of Proprietary Marks 30 13.4 Effect of Termination of
This Agreement 30 13.5 Unit Franchise Refund Policy 30 14. INDEPENDENT CONTRACTOR AND
INDEMNIFICATION 30 14.1 No Fiduciary Relationship 30 14.2 Public Notice of Independent Status 31
14.3 Independent Contractor 31 14.4 Indemnification 31 15. APPROVALS, WAIVERS AND NOTICES 32 15.1
Obtaining Approvals 32 15.2 No Waiver 32 15.3 Notices 32 16. ENTIRE AGREEMENT; SEVERABILITY AND
CONSTRUCTION 33 16.1 Entire Agreement 33 16.2 Severability and Construction 33 16.3 Survival of
Obligations After Expiration or Termination of Agreement 34 16.4 Survival of Modified Provisions 34
16.5 Captions 34 16.6 Responsibility 34 16.7 Corporation, Partnership or Limited Liability Company
35 17. APPLICABLE LAW 35 17.1 Choice of Law 35 17.2 Non-Binding Mediation 36 17.3 Venue 36 17.4
Non-exclusivity of Remedy 36 17.5 Right to Injunctive Relief 36 17.6 Incorporation of Recitals 36
18. SECURITY INTEREST 37 18.1 Collateral 37 18.2 Indebtedness Secured 37 18.3 Additional Documents
37 18.4 Possession of Collateral 37 18.5 Our Remedies in Event of Default 37 18.6 Special Filing as
Financing Statement 38 19. ACKNOWLEDGMENTS 38 19.1 Recognition of Business Risks 38 19.2 Receipt of
Franchise Disclosure Document 38

iii

Source: SOUPMAN, INC., 8-K, 8/14/2015
<!-- page 5 -->
19.3 Review of Agreement 38 19.4 Attorneys' Fees 38 19.5 Atypical Arrangements 38 19.6 Limitation of
Adjudicative Proceedings 39 19.7 Trial by Jury 39 19.8 Punitive or Exemplary Damages 39 19.9
Additional Documents 39 19.10 Counterparts 39 ATTACHMENTS : A - Master Territory and Commencement
Date B - Guarantees of Master Franchise Agreement C - Multi-State Addendum D - Confidentiality and
Non-Competition Agreement E - Minimum Development Quota

iv

Source: SOUPMAN, INC., 8-K, 8/14/2015
<!-- page 6 -->
KIOSK CONCEPTS, INC. MASTER FRANCHISE AGREEMENT AGREEMENT made as of the _____ day of
__________________, 2015 (the "Effective Date") by and between Kiosk Concepts, Inc., a New York
corporation having its principal place of business at 1110 South Avenue, Staten Island, New York
10314 ("we", "us" or "our"), and The Grilled Cheese Truck, Inc., a Nevada corporation having its
principal address at 151 North Nob Hill Road, Suite 321, Fort Lauderdale, FL 33324 ("you" or
"your"), with reference to the following facts: A. We are in the business of franchising outlets
that sell proprietary gourmet soups, chilis, stews, desserts, wraps and non-proprietary products
like salads, sandwiches, specialty coffees, soft drinks and other beverages under the name and
trademark "The Original Soupman", together with any trademarks, trade names, service marks, slogans
and logos which may be authorized in writing by us from time to time (collectively the "Proprietary
Marks"). We have developed and used, and continue to use and control, the Proprietary Marks so as to
impart to the public superior standards of quality and service. B. You desire us to grant you a
license to use the methods, procedures and products developed by us and our parent (the "System") to
operate an independent business (the "Franchised Business") that sells and services The Original
Soupman franchises ("Unit Franchises") to qualified individuals and business entities ("Unit
Franchisees") who will sell proprietary gourmet soups, chilis, stews, desserts, wraps and non-
proprietary products like salads, sandwiches, specialty coffees, soft drinks and other beverages in
the territory described in Section 1 of this Agreement, and you agree that your operation of the
Franchised Business shall be governed by the terms, covenants and conditions contained in this
Agreement. Our System includes a method of offering and selling Unit Franchises, management methods,
marketing programs, financial reporting, Unit Franchisee performance reporting, and providing
services to Unit Franchisees, all of which we may modify and/or update from time to time during the
term of this Agreement. C. You represent and warrant to us, as an inducement to our execution of
this Agreement, that all statements made by you and all materials provided to us by you in
connection with the grant of this franchise to you are true, accurate and complete and that you have
made no misrepresentations or material omissions in connection with obtaining this franchise. We
grant this franchise in reliance upon each and all of your representations. NOW, THEREFORE, IT IS
AGREED: 1. GRANT OF FRANCHISE 1.1 Rights Granted to You We grant to you, upon the terms and
conditions contained in this Agreement, the exclusive right to establish and operate a Franchised
Business and a license to use the methods, procedures and products developed by us in the business
of selling and servicing Unit Franchises in the territory described on Attachment A attached to this
Agreement and incorporated into this Agreement by reference (the "Master Territory"). You shall
operate the Franchised Business at or from a location of your choice within the Master Territory
upon the terms and conditions set forth in this Agreement. The Proprietary Marks, any Internet
domain names, URLs, copyrights, toll-free "1-800", "1-888" and "1- 877" telephone numbers or other
like toll-free telephone numbers which may be utilized by us or our affiliates, and their mnemonics,
and other identifying marks constituting a part of the System, now or in the future, shall be used
by you only in connection with the operation of the Franchised Business. The rights granted herein
include the limited right to sublicense the use of the Proprietary Marks to Unit Franchisees in the
Master Territory.

Source: SOUPMAN, INC., 8-K, 8/14/2015
<!-- page 7 -->
1.2 Non-Exclusive Grant You acknowledge and agree that the franchise granted to you hereunder is
non-exclusive and is only for one (1) Master Territory; that you are not granted any area, market,
or protected territorial rights other than as expressly provided in Section 1.1 of this Agreement;
and that you shall not have the right to sublicense, sublease, subcontract or enter into any
management agreement providing for the right to operate the Franchised Business or to use the System
granted pursuant to this Agreement, except in the manner expressly provided for in Section 5.1 of
this Agreement. 1.3 Our Reserved Rights We and our affiliates retain the right, among others, in any
manner and on any terms and conditions that we deem advisable, and without granting you any rights
therein: 1.3.1 To own, acquire, establish, and/or operate, and license others to establish and
operate, other Franchised Businesses at any location outside of the Master Territory. 1.3.2 To own,
acquire, establish and/or operate, and license others to establish and operate, businesses under
other proprietary marks or other systems, whether such businesses are the same, similar, or
different from the Franchised Business, at any location within or outside of the Master Territory.
1.3.3 To license others to sell or distribute any products or services which bear any proprietary
marks, including the Proprietary Marks, at any location outside of the Master Territory. 2.
OPERATION OF THE FRANCHISED BUSINESS You acknowledge and agree that: 2.1 Name of Franchised Business
You shall operate the Franchised Business in the United States of America Territory using the
assumed trade name "The Original Soupman", "The Original Soupman of [City]" and/or any other trade
name we designate in conjunction with your formal business name. You shall not use the Proprietary
Marks, or any part thereof, as part of your corporate name or other legal name, nor shall your
corporate or other legal name include any other service name. The name of your corporate entity and
any trade or assumed names or other legal names used by you in the operation of the Franchised
Business shall be approved by us prior to any use by you. 2.2 Full Time, Attention and Best Efforts
You shall devote all of your time, attention and best efforts to the Franchised Business pursuant to
this Agreement and all work and services performed and/or supervised by you under this Agreement
shall be performed and/or supervised by you or by your authorized employees. You shall adhere to all
current established policies, practices and procedures of the System, and as the same may be amended
from time to time, and shall not deviate therefrom without our prior written consent.

2

Source: SOUPMAN, INC., 8-K, 8/14/2015
<!-- page 8 -->
2.3 Modifications to System and Manuals The System, our Operations Manual, and any other manuals
loaned to you by us pursuant to this Agreement (collectively the "Manuals"), and the products and
services offered by the Franchised Business may be modified by us at any time and from time to time,
including, without limitation, by the addition, deletion and/or modification of operating
procedures, products and services. You shall comply, at your expense, with all such additions,
deletions and/or modifications, including, without limitation, all requirements to implement the
addition, deletion and/or modification. You shall implement any System changes upon receipt of
notice thereof from us and shall complete their implementation within such time as we may specify.
You shall ensure that each Unit Franchisee in your Master Territory also complies with any System
changes, as such changes may affect the Unit Franchisees. 3. INITIAL AND EXTENDED TERMS 3.1 Initial
Term The initial term of this Agreement shall commence upon the Effective Date and shall expire ten
(10) years from the Effective Date, unless sooner terminated under the terms of this Agreement. You
shall have no right or option to extend or renew the term of this Agreement except as provided in
Section 3.2 of this Agreement. 3.2 Options to Renew You shall have the option to renew the term of
this Agreement, on the terms and conditions set forth in this Agreement, for four (4) additional ten
(10) year terms, upon written notice given by you to us not less than six (6) months nor more than
twelve (12) months prior to the scheduled expiration date of the term then in effect, provided that
each of the following conditions are satisfied: 3.2.1 You shall not be in default of any provision
of this Agreement, or any other agreement between you and us or our affiliates, or any standards set
forth in the Manuals, and you shall have complied with all the terms and conditions of this
Agreement, the Manuals and any other agreements during the term of this Agreement. 3.2.2 You shall
have satisfied all monetary obligations owed by you to us and our affiliates, and shall have timely
met those obligations throughout the term of this Agreement. 3.2.3 You shall, at our option, execute
our then-current form of Master Franchise Agreement and any addenda thereto for the renewal term,
which renewal agreement shall supersede this Agreement in all respects, and the terms of which,
including, without limitation, continuing fees payable to us, may differ materially and be less
advantageous to you than the terms of this Agreement. 3.2.4 You shall comply with our then-current
qualification and training requirements. 3.2.5 You shall pay us a renewal fee in the sum of Ten
Thousand Dollars ($10,000) for the right to renew this Agreement. 3.2.6 You shall execute a general
release, in a form prescribed by us, of any and all claims which you may have or believe to have
against us and/or our affiliates and our respective officers, directors, agents and employees,
whether the claims are known or unknown, which are based on, arise from or relate to this Agreement
or the Franchised Business, as well as claims, known or unknown, which are not based on, do not
arise from or do not relate to this Agreement or the Franchised Business, but which relate to other
franchise agreements, Franchised Businesses and other agreements between us or our affiliates and
you which arose on or before the date of the general release, including, without limitation, all
obligations, liabilities, demands, costs, expenses, damages, claims, actions and causes of action,
of whatever nature, character or description, arising under federal, state and local laws, rules and
ordinances (provided, however, that all rights enjoyed by you and any causes of action arising in
your favor from the provisions of Article 33 of the New York General Business Law ("GBL") and the
regulations issued thereunder shall remain in force; it being the intent of this provision that the
non-waiver provisions of GBL Sections 687.4 and 687.5 be satisfied).

3

Source: SOUPMAN, INC., 8-K, 8/14/2015
<!-- page 9 -->
3.3 Renewal of Existing Agreement If we are not offering new master franchises, are in the process
of revising, amending or renewing our form of Master Franchise Agreement or Master Franchise
Disclosure Document or are not lawfully able to offer our then-current form of Master Franchise
Agreement at the time you exercise an option to extend the term of this Agreement, we may offer to
renew this Agreement upon the terms and conditions set forth in this Agreement for the extended
term, or may offer to extend the term of this Agreement on a month-to-month basis following the
expiration of the term of this Agreement for as long as we deem necessary or appropriate so that we
may subsequently lawfully offer and utilize our then-current form of Master Franchise Agreement. 3.4
Continued Compliance Your right to extend the term of this Agreement shall be subject to your
continued compliance with the terms and conditions in this Agreement as well as your compliance with
the conditions set forth in Section 3.2 of this Agreement. 3.5 Termination at End of Term If you do
not elect to extend the term of this Agreement, this Agreement shall terminate at the end of the
term then in effect. 4. PAYMENT OF FEES 4.1 Continuing Fees Payable to Us You shall pay the
following continuing fees to us each month during the term of this Agreement: 4.2.1 You shall pay to
us a royalty fee based on revenue generated by Unit Franchisees (the "Unit Franchise Performance
Royalty Fee") equal to twenty-five percent (25%) of aggregate royalty fees paid to you by Unit
Franchisees in the Master Territory pursuant to their Unit Franchise Agreements. The Unit Franchise
Performance Royalty Fee shall be paid by you to us in the manner provided in Section 4.3 of this
Agreement by the fifteenth(15 th ) day of each calendar month based on royalty fees generated and
received during the previous calendar month. 4.2.2 You shall pay to us a franchise sales royalty fee
(the "Franchise Sales Royalty Fee") for each Unit Franchise you sell in the Master Territory as
follows: twenty-five percent (25%) of the initial franchise fee collected from each Unit Franchisee
upon execution of the Unit Franchisee's Franchise Agreement (a "Unit Franchise Agreement");
provided, however, that if you elect to discount or reduce an initial franchise fee for any reason,
the Franchise Sales Royalty Fee shall be payable to us as if the full initial franchise fee had been
paid. The Franchise Sales Royalty Fee shall be paid by you to us at the same time and in the same
manner as the Unit Franchise Performance Royalty Fee provided in Section 4.2.1 above. Any Royalty
Fee you collect from the Franchisee shall be immediately paid to Us, but no later than the fifteen
(15 th ) day of each calendar month. A Unit Franchise shall be deemed to be sold to a Unit
Franchisee on the date that you and the Unit Franchisee execute the Unit Franchise Agreement,
irrespective of when the Unit Franchise begins operation. Fees and Royalties cannot be increased or
decreased without our prior written consent.

4

Source: SOUPMAN, INC., 8-K, 8/14/2015
<!-- page 10 -->
4.2.3 In addition to the Unit Franchise Performance Royalty Fee and Franchise Sales Royalty Fee
described above, you shall collect from each Unit Franchisee in your Master Territory a "National
Advertising Fund Contribution" to be contributed to our "National Advertising Fund" pursuant to the
terms of the individual Unit Franchise Agreements. For each Unit Franchise you own and operate, you
shall pay the National Advertising Fund Contribution on the same basis as Unit Franchisees. The
National Advertising Fund Contribution shall be collected by you from each Unit Franchisee and spent
by you in accordance with the agreement on behalf of the franchisor and Franchisees. 4.3 Manner of
Payment You shall pay us all Unit Franchise Performance Royalty Fees and Franchise Sales Royalty
Fees, due under this Section 4 by electronic funds transfer by us against a bank account maintained
by you. You agree to execute the documents required by us, our bank and/or your bank in order to
permit us to conduct electronic funds transfers to and from your account, and you shall not close
your account without our prior consent. Your failure to comply with the terms of this Section 4.3
shall be deemed to be a breach of this Agreement. You hereby authorize us to initiate debit entries
and/or credit collection entries to your bank account for the payment of Unit Franchise Performance
Royalty Fees, Franchise Sales Royalty Fees, National Advertising Fund Contributions, and all other
sums that may become due to us or our affiliates from you. You shall make funds available for
withdrawal by us by electronic transfer on such dates of each month as we shall designate throughout
the term of this Agreement. If you fail to provide the revenue reports described in Section 4.6
below, then in addition to the late fee described in such Section, we may debit your account for one
hundred forty percent (140%) of the last Unit Franchise Performance Royalty Fee, Franchise Sales
Royalty Fee and/or National Advertising Fund Contribution (as applicable) that we debited. If the
Unit Franchise Performance Royalty Fee, Franchise Sales Royalty Fee and/or National Advertising Fund
Contribution we debit are less than the fees you actually owe us, once we have been able to
determine the true and correct revenue amounts, we will debit your account for the balance on a day
we specify. If the Unit Franchise Performance Royalty Fee, Franchise Sales Royalty Fee and/or
National Advertising Fund Contribution we debit are greater than the fees you actually owe us, we
will credit the excess against the amount we otherwise would debit from your account for the next
payment due. 4.4 Interest on Overdue Amounts Any payment not actually received by us on or before
the Fifteen (15 th ) day of each month (or the next business day if the Fifteen(15 th ) of any month
is not a business day) shall be deemed overdue and you shall pay to us, in addition to the overdue
payment, interest on such overdue amount at the rate of one and one-half percent (1.5%) per month or
the maximum rate permitted by law, whichever is less. Interest shall accrue from the original due
date until payment is received in full. Our right to such interest shall be in addition to any other
remedies we may have, including, without limitation, the right of set-off to withdraw or retain,
from time to time and without notice to you, any amounts due and unpaid by us to you. You shall not
be entitled to set-off any payments required to be made under this Section 4 against any monetary
claim you may have against us.

5

Source: SOUPMAN, INC., 8-K, 8/14/2015
<!-- page 11 -->
4.5 Late Fee; Insufficient Funds Fee In the event you fail to provide us with any report we require
on or before the date we require it, you agree to pay to us a late fee in the amount of Two Hundred
Fifty Dollars ($250). In addition, if, for any reason, any payment owed by you to us is denied by
your bank due to insufficient funds in your account, then you shall, in addition to applicable
interest as described in Section 4.4 above, pay us an insufficient funds fee in the amount of Two
Hundred Fifty Dollars ($250). If you incur three (3) late fees or insufficient funds fees within any
twelve (12) month period, we will have the right to terminate this Agreement without providing you
an opportunity to cure the default. 4.6 Unit Franchise Agreements and Revenue Reports You shall
submit to us copies of all Unit Franchise Agreements executed with Unit Franchisees within ten (10)
days of the date of their execution, together with a copy of all checks presented to you at closing.
You shall prepare and submit to us a monthly report, not later than the first (1 s t ) day of each
month, of Franchise Sales Revenue generated by you during the previous calendar month.
Contemporaneously with the submission of the Franchise Sales Revenue report, you shall prepare and
submit to us a monthly report, in such form and including such detail as we require, reflecting
royalty fees paid and owed to you by your Unit Franchisees for the previous calendar month. Any
report not actually received by us when due shall be deemed overdue and you shall pay us a late
charge as described above. 4.7 Security Interest In order to secure payment of all Unit Franchise
Performance Royalty Fees, Franchise Sales Royalty Fees, National Advertising Fund Contributions, and
all other sums that may become due to us or our affiliates from you under this Agreement, and to
secure your performance of all obligations of any kind, whenever and however incurred, in favor of
us or our affiliates: 4.7.1 You hereby grant us a security interest in and to all equipment,
furniture, fixtures, inventory, supplies and vehicles used in connection with the Franchised
Business, now or hereafter acquired by you, together with all accounts, payment intangibles,
attachments, accessories, additions, substitutions and replacements, all cash and non-cash proceeds
derived from insurance or the disposition of such assets, all of your rights to use the Proprietary
Marks, patents, copyrights and their registrations, trade secret information and other proprietary
rights, and all rights granted, owned or licensed to you under this Agreement for the use of the
Proprietary Marks, trade names, trade styles, patents, copyrights, trade secret information and
other proprietary rights. You hereby authorize us to prepare and file all Uniform Commercial Code
("UCC") financing statements and other documents necessary or desirable to evidence, perfect and
continue the priority of this security interest under the UCC. 4.7.2 If you are and remain in good
standing under this Agreement and all other agreements with us and our affiliates, we will consent
to your grant of an additional security interest in the Franchised Business or in any of the assets
of the Franchised Business if the conditions set forth in Section 12.4 of this Agreement are met.
4.7.3 If you are in default of any of the terms and conditions of this Agreement or any other
agreements between us and our affiliates and you, we may, in our sole and absolute discretion,
exercise our rights with respect to our security interest. In such event, you shall be and remain
liable for any deficiency remaining due to us and shall be entitled to recover any surplus which
results after application of the proceeds derived from the enforcement of our security interest.

6

Source: SOUPMAN, INC., 8-K, 8/14/2015
<!-- page 12 -->
4.8 Reimbursement of Monies You shall pay to us, within fifteen (15) days of any written request by
us accompanied by reasonable substantiating material, any monies which we have paid, or have become
obligated to pay, on your behalf by consent or otherwise under this Agreement. 4.9 Application of
Fees Notwithstanding any designation by you, we shall have the sole discretion to apply any payments
made by you to any past due indebtedness of yours for Unit Franchise Performance Royalty Fees,
Franchise Sales Royalty Fees, National Advertising Fund Contributions, or any other indebtedness, in
such amounts and in such order as we shall determine. 5. YOUR OBLIGATIONS You understand and
acknowledge that every detail of the System is essential to you and us in order to develop and
maintain quality operating standards, to increase the demand for the products and services sold by
all master franchisees operating under the System and to protect the Proprietary Marks and our
reputation and goodwill. You shall comply with our standards with respect to services, products and
operations and shall operate the Franchised Business in strict conformity with such methods,
standards, and specifications as we may from time to time prescribe in the Manuals or otherwise. You
shall refrain from deviating from such standards, specifications and procedures without our prior
written consent and from otherwise operating in any manner which reflects adversely on the
Proprietary Marks or the System. Without limiting the generality of the foregoing, you agree that:
(a) You shall only use and serve soups that are approved by us and must be purchased from suppliers
designated or approved in writing by us and you acknowledge that all soups approved shall not be
those of Al Yeganeh. We will use our best efforts to have all soups produced to Al Yeganeh's
standards. Any deviation from the above shall result in default of the Agreement and grounds for
immediate termination without opportunity to cure. (b) Soups shall be cost plus 25% FOB the
supplier. (c) You hereby agree that you shall serve three (3) soups daily, in any format approved in
writing by us, inside the kettles located in the front line of the restaurant. We prefer you serve
daily six (6) soups in any format, approved in writing by us. (d) In order to keep your exclusivity,
you agree to purchase a minimum of the following: $170,000.00 of soup from us in 2015 $1,600,00.00
of soup from us in 2016 $3,200,000.00 of soup from us in 2017 $5,000,000.00 of soup from us in 2018
and shall increase 10% each year thereafter. (e) We maintain the right to open and operate new
company units and to sell franchises to our existing franchisees.

7

Source: SOUPMAN, INC., 8-K, 8/14/2015
<!-- page 13 -->
(f) We shall be permitted to sell branded products to national accounts without any money due to you
or your parent company. Once you have units open and operating in the trade area where a National
Account is located, we will remit to you 25% of the profits derived from the sales in that specific
trade area. (g) We will continue to collect the royalties from franchisees and service existing
franchisee in the Master Territory. 5.1 Sale of Unit Franchises; Minimum Development Quota You shall
have the right and obligation to market and sell independent Unit Franchises to qualified Unit
Franchisees who shall operate a The Original Soupman business as granted in the Unit Franchise
Agreement. The rights granted to you hereunder do not include the right to sub-franchise others to
sell franchises. You may not grant any such right to a Unit Franchisee, and Unit Franchisees shall
not have the right to sub-franchise or sell Unit Franchises. You shall commence operation of the
Franchised Business no later than the "Commencement Date" set forth on Attachment A hereto. 5.1.1 In
addition to The Original Soupman business you must own and continuously operate, you must sell and
have open the minimum number of The Original Soupman businesses as set forth on Attachment E hereto
(the "Minimum Development Quota") by the dates set forth on such Attachment. We will not grant other
franchises nor establish our own Unit Franchises within the Master Territory during the term of this
Agreement unless you do not meet the Minimum Development Quota. If you do not meet the Minimum
Development Quota, we may cancel your exclusive right to market and sell Unit Franchises in your
Master Territory and may sell additional Master Franchises within your Master Territory, or we may
begin operations of our own in your Master Territory, or we may terminate this Agreement. 5.1.2 You
shall prepare and present to each applicant for the purchase of a Unit Franchise (an "Applicant") a
Franchise Disclosure Document and all other related documents in accordance with the requirements of
all federal and state regulatory agencies which now or hereafter may have jurisdiction over the sale
of franchises in the Master Territory (a "Unit Franchise Disclosure Document"). You may not present
a Unit Franchise Disclosure Document to any Applicant until such Unit Franchise Disclosure Document
has been submitted to and approved by us or our counsel in accordance with Section 13 of this
Agreement and, if applicable, the Unit Franchise Disclosure Document has been registered with the
appropriate state authority. You agree to make any changes to the Unit Franchise Disclosure Document
(including its exhibits) as may be requested by us or our counsel. We shall have no responsibility
whatsoever for the accuracy or legal compliance of your Unit Franchise Disclosure Document or your
compliance with the requirements of any regulatory agencies which now or hereafter may have
jurisdiction over the sale of franchises. You acknowledge and understand that you are solely and
exclusively responsible for complying with all federal and state franchise registration and
disclosure laws and the payment of all franchise registration and filing fees . To prepare your Unit
Franchise Disclosure Document and comply with applicable franchise registration and disclosure laws
as just discussed, you may require the services of a franchise attorney, who would be retained at
your expense. 5.1.3 You must charge your Unit Franchisees the initial franchise fee, royalty fee,
National Advertising Fund Contribution and any other continuing fees that we designate or require,
within the limits established by all regulatory agencies which now or hereafter may have
jurisdiction over the sale of franchises and the requirements imposed by this Agreement. Any
deviations from these amounts must be pre- approved by us.

8

Source: SOUPMAN, INC., 8-K, 8/14/2015
<!-- page 14 -->
5.1.4 You shall not make any misleading or untrue statements or any representations inconsistent
with the Unit Franchise Disclosure Document in connection with the sale of Unit Franchises within
the Master Territory. Further, you shall not provide any Applicant with any document or information
in connection with the sale of Unit Franchises within the Master Territory other than documents and
information included within the Unit Franchise Disclosure Document. You shall make no promises,
representations or commitments to any Applicant in connection with the sale of Unit Franchises
within the Master Territory, including representations concerning potential profit or income, other
than promises, representations or commitments specifically included within the Unit Franchise
Disclosure Document. 5.1.5 You shall defend at your expense (with legal counsel reasonably
satisfactory to us) and shall indemnify and hold harmless us and our affiliates, and our respective
officers, directors, shareholders, agents and employees, from and against any and all claims,
losses, damages, liabilities, costs and expenses (including, without limitation, actual attorneys',
accountants' and consultants' fees and other expenses, including any such expenses incurred in
connection with investigating, defending against or settling any such claims sustained or incurred
by us), however caused, resulting directly or indirectly from or pertaining to any acts, omissions
to act and/or performance by you of your obligations and responsibilities under this Section 5.1,
including, but not limited to, unauthorized disclosures to Applicants, any claims of Applicants or
Unit Franchisees whose Unit Franchises were sold by you and/or any claims of any regulatory agencies
which now or hereafter may have jurisdiction over the sale of franchises in connection with your
sales of Unit Franchises. 5.2 Initial Training and Services for Unit Franchisees 5.2.1 In order to
ensure that the integrity of the Proprietary Marks and our goodwill are preserved, you shall provide
a comprehensive initial training program for each Unit Franchisee in the Master Territory according
to our specifications, including classroom and on-site training and assistance. Each Unit Franchisee
must complete the initial training program satisfactorily, according to the parameters we specify.
5.2.2 You shall thereafter provide sessions of on-location assistance in operations and business
management. 5.2.3 You will further support and assist each Unit Franchisee by: (a) Making available
to each Unit Franchisee in the Master Territory all applicable Manuals, training aids and any
pertinent information concerning the System. (b) Providing assistance and guidance to each Unit
Franchisee in the Master Territory. (c) Having personnel available for each Unit Franchisee in the
Master Territory on an ongoing basis during normal business hours to provide technical assistance,
consultation, and advice on marketing and operations procedures and by providing training and
support for to each Unit Franchisee in the Master Territory at reasonable rates as established by
us.

9

Source: SOUPMAN, INC., 8-K, 8/14/2015
<!-- page 15 -->
5.2.4 You shall be solely responsible for ensuring that all The Original Soupman businesses in the
Master Territory, including such businesses owned and operated by you, shall (a) purchase all
proprietary products we require and maintain an inventory of such proprietary products as we specify
for The Original Soupman businesses; and (b) offer and sell the mix of products, including
proprietary products, that we designate for The Original Soupman businesses. 5.2.5 If you fail to
insure and/or enforce the proper performance of the obligations described in Section 5.2.4, and any
other obligations contained in a Unit Franchise Agreement and/or the Manuals, we shall have the
right, in our sole and absolute discretion, to enforce any provision of any Unit Franchise Agreement
if you fail to do so following receipt of a written request by us to enforce the terms of such Unit
Franchise Agreement. 5.2.6 You shall indemnify, defend and hold us, our parent and our affiliates,
and our respective officers, directors, shareholders, employees, agents and attorneys, and their
respective heirs, successors and assigns, and each of them, harmless from and against any and all
claims arising from any action or omissions to act by you or Unit Franchisees in the Master
Territory. 5.3 Use of Proprietary Marks You shall supervise the use of all Proprietary Marks by Unit
Franchisees in the Master Territory. If you fail to exercise the proper diligence in enforcing the
terms of any Unit Franchise Agreement to insure that the Proprietary Marks are being properly used
by Unit Franchisees, such failure shall constitute a default under the terms of this Agreement and
may result in termination of this Agreement. 5.4 Place of Business You shall maintain a safe and
reasonably clean place of business in compliance with all governmental and industry standards and
conduct the Franchised Business in a manner that generates goodwill and public approval of you and
us. 5.5 Insurance During the term of this Agreement, you shall maintain in force under policies of
insurance issued by licensed insurers approved by us insurance coverage as we from time to time
require. You must maintain insurance related to your operation of the Franchised Business. Such
insurance coverage will include: 5.5.1 As it relates to the operation of your Franchised Business:
broad form comprehensive general liability coverage against claims for employment practices
coverage, bodily and personal injury, death and property damage caused by or occurring in
conjunction with the conduct of business by you pursuant to this Agreement and broad form
contractual liability coverage, including errors and omissions coverage, under one or more policies
of insurance containing minimum liability coverage prescribed by us from time to time, but in no
event in an amount less than Two Million Dollars ($2,000,000) aggregate. Such insurance shall not
have a deductible or self-insured retention in excess of Five Thousand Dollars ($5,000); 5.5.2 As it
relates to the operation of your Franchised Business: automobile liability insurance coverage,
including owned and non-owned vehicles, with limits of not less than One Million Dollars
($1,000,000) per occurrence;

10

Source: SOUPMAN, INC., 8-K, 8/14/2015
<!-- page 16 -->
5.5.3 As it relates to the operation of your Franchised Business: worker's compensation and
employer's liability insurance in statutory amounts, unemployment insurance and state disability
insurance as required by governing law for your employees; 5.5.4 As it relates to the Unit
Franchisees' operation in the Master Territory, and if you elect to obtain such coverage: general
liability insurance, which insurance is in addition to any general liability insurance the Unit
Franchisees are required to maintain under their Unit Franchise Agreements. You shall also maintain
such additional insurance as is necessary to comply with all legal requirements concerning
insurance. We may periodically increase the amounts of coverage required under such insurance
policies and require different or additional kinds of insurance at any time including excess
liability insurance to reflect inflation, identification of new risks, changes in law or standards
of liability, higher damage awards, or other relevant changes in circumstances. The insurance
policies required herein shall: (a) name us as an additional named insured and contain a waiver of
all subrogation rights against us, our affiliates, and our and their successors and assigns; (b)
provide for thirty (30) days' prior written notice to us of any material modification, cancellation,
or expiration of such policy; (c) provide that the coverage applies separately to each insured
against whom a claim is brought as though a separate policy had been issued to each insured; (d)
contain no provision which in any way limits or reduces coverage for you in the event of a claim by
any one or more of the parties indemnified under this Agreement; (e) be primary to and without right
of contribution from any other insurance purchased by the parties indemnified under this Agreement;
and (f) extend to and provide indemnity for all obligations assumed by you hereunder and all other
items for which you are required to indemnify us under this Agreement. You shall provide us with
evidence of the insurance required hereunder not later than ten (10) days before you begin operating
as a Master Franchisee, and with a complete copy of each insurance policy no more than thirty (30)
days after delivery of the original proof of insurance. Thereafter, prior to the expiration of the
term of each insurance policy, you shall furnish us with a copy of each renewal or replacement
insurance policy to be maintained by you for the immediately following term and evidence of the
payment of the premium therefor. Should you, for any reason, fail to procure or maintain the
insurance required by this Agreement, as such requirements may be revised from time to time by us in
writing, we shall have the right and authority (without, however, any obligation to do so)
immediately to procure such insurance and to charge same to you, which charges shall be payable by
you immediately upon notice together with a ten percent (10%) administrative fee. The foregoing
remedies shall be in addition to any other remedies we may have at law or in equity. The maintenance
of sufficient insurance coverage shall be your responsibility. Your obligations to maintain
insurance coverage as herein described shall not be affected in any manner by reason of any separate
insurance maintained by us nor shall the maintenance of such insurance relieve you of any
indemnification obligations under this Agreement. 5.6 Computer Hardware and Software 5.6.1 You
shall, in accordance with any specifications that we may prescribe and from any suppliers we may
designate (which may include us or an affiliate), purchase, lease or license all computer hardware
and software designated by us for the Franchised Business, whether in this Agreement, the Manuals or
otherwise during the term of this Agreement. You shall likewise procure and install printers and
other computer-related accessories or peripheral equipment as we may require. You shall at all times
have a high speed internet connection for your computer system. All computer hardware and software
specified by us shall be purchased, leased or licensed by you and your sole expense. You shall
utilize all software programs that we may specify in connection with the operation of the Franchised
Business. We reserve the right to develop proprietary software programs and, if we elect to do so,
you shall execute our standard form of software license agreement for such proprietary software
programs upon demand by us, and shall input and maintain in your computer system all software
programs, data and information as we prescribe. You shall purchase, lease or license all software
programs and materials whenever we elect to use new or upgraded programs and materials, either from
us or from an approved distributor, if any, and, if from an approved distributor, upon terms
determined by such distributor. During the term of this Agreement, you shall maintain and update all
computer hardware and software as required by us.

11

Source: SOUPMAN, INC., 8-K, 8/14/2015
<!-- page 17 -->
5.6.2 You shall also purchase all computer-related services (including, without limitation, e-mail
services) from suppliers (which may include us or our affiliate) that we may require and designate
from time to time. 5.7 Payment of Taxes You shall pay all personal property, sales, excise, use, and
other taxes, regardless of type or nature, which may be imposed, levied, assessed or charged, on,
against, or in connection with the Franchised Business and any products, services or equipment sold
or furnished hereunder, whether those taxes are imposed by any federal, state, municipality, county
or parish, or other governmental unity or agency, which may have jurisdiction over such products,
services and equipment. It shall be your sole responsibility to insure that any Unit Franchisee
operating in the Master Territory shall also comply with this Section 5.7 as it may apply to the
operation of the Unit Franchisee's business. 5.8 Enforcement of Unit Franchise Agreements You shall
take all necessary steps to enforce the terms and condition of all Unit Franchise Agreements and
shall be bound by the terms thereof in all dealings with your Unit Franchisees and shall maintain
normal office hours, provide adequate communication and support and otherwise maintain and operate
your Franchised Business in a manner that will promote the efficiency and success of each Unit
Franchisee. You shall not terminate the Unit Franchise Agreement of any Unit Franchisee without our
prior written consent. 5.9 Master Franchisee Training Program Prior to the Commencement Date, you
(or, if you are a corporation, partnership, or limited liability company, a principal of yours
acceptable to us and who owns at least a twenty-five percent (25%) equity interest in you) and those
of your managers who are approved by us, shall attend and complete to our satisfaction the initial
training program (or segments thereof at our discretion) for master franchisees offered by us. We
shall provide such training, instructors, a training manual, and other materials without charge to
,five_(5) persons, but if you request to send additional attendees to our master franchisee training
program you shall pay our then-current training fee for each additional attendee sent to such
training program by you. Except as stated in the preceding sentence, you shall be responsible for
any and all other expenses incurred in connection with sending your managers to such training
including, without limitation, the costs of transportation, lodging, meals, and any wages. We shall,
in our sole discretion, select the time and location of the initial training program. We shall have
the right to terminate this Agreement if, at any time during the initial training program, we
conclude (in our sole judgment) that you or your principal do not appear to possess the skills
necessary to properly fulfill and discharge the demands and responsibilities required by the System
or this Agreement.

12

Source: SOUPMAN, INC., 8-K, 8/14/2015
<!-- page 18 -->
5.10 Additional Training; Master Franchisee Meetings 5.10.1 You and your employees shall also attend
such additional courses, seminars, and other training programs as we may reasonably require from
time to time. We shall not charge any fees for those attending these additional courses, seminars,
or other training programs, but you shall be responsible for any and all other expenses incurred in
connection with attending and sending your employees to such training programs including, without
limitation, the costs of transportation, lodging, meals, training materials and any wages. We shall,
in our sole discretion, select the time and location of all additional training programs. 5.10.2 If
you request that we provide additional training or assistance on-site at your Franchised Business,
you must pay our then-current per diem fee for each representative we send to you to provide
training or assistance, and you must reimburse each representative's travel, lodging and meals
expenses while providing the additional on-site training or assistance. 5.10.3 When we believe it is
beneficial to do so, we will hold an annual meeting of our master franchisees to conduct additional
training, announce new products and/or services or discuss any other matters of interest. The annual
meeting will be mandatory for all master franchisees, unless your absence is excused by us. You will
bear all costs related to attending the annual meeting, including travel, lodging, meals, wages and
a nominal fee for the meeting for each person attending such meeting. 5.11 Supplies and Equipment
You shall require your Unit Franchisees in the Master Territory to purchase supplies and equipment
used in the operation of its Unit Franchise business from only designated and approved suppliers to
insure quality and uniformity and to take advantage of quantity purchasing discounts, if any. We
shall provide you with a list of approved and designated suppliers for supplies and equipment prior
to the Commencement Date. 5.12 Compliance with Governmental Regulations and Applicable Law You
shall, as an independent business owner, timely obtain any and all permits, certificates, or
licenses necessary for the lawful operation of the Franchised Business including, without
limitation, licenses to do business, fictitious name registrations, sales tax permits, and the like.
You and your principals agree to comply, and to assist us to the fullest extent possible in our
efforts to comply, with Anti-Terrorism Laws (defined below). In connection with that compliance, you
and your principals certify, represent, and warrant that none of your property or interests is
subject to being blocked under, and that you and your principals otherwise are not in violation of,
any of the Anti-Terrorism Laws. "Anti-Terrorism Laws" mean Executive Order 13224 issued by the
President of the United States, the USA PATRIOT Act, and all other present and future federal,
state, and local laws, ordinances, regulations, policies, lists, and other requirements of any
governmental authority addressing or in any way relating to terrorist acts and acts of war. Any
violation of the Anti-Terrorism Laws by you or your principals, or any blocking of your or your
principals' assets under the Anti-Terrorism Laws, shall constitute good cause for immediate
termination of this Agreement. 5.13 Office Location You shall be solely responsible for any leases
of real or personal property in connection with the operation of your Franchised Business. We
reserve the right, but are not required to, approve your office location and any leasehold
improvements to such location to protect our image, reputation and goodwill. You may elect to
operate the Franchised Business from The Original Soupman business you must own and operate, once
such business is open and operating.

13

Source: SOUPMAN, INC., 8-K, 8/14/2015
<!-- page 19 -->
You shall at all times during the term of this Agreement maintain your office and all fixtures,
furnishing, signs and equipment located therein in good order and condition, and in conformity with
the System image as may be prescribed by us from time to time. You shall, within a reasonable time
specified by us, make all necessary reasonable additions, alterations, repairs and replacements to
your office as required by us to conform to our quality standards, but no others without our prior
written consent, including, without limitation, periodic repainting or replacement of signs,
furnishings, or equipment. No other business venture shall operate out of the premises utilized by
you for your Franchised Business without our prior written consent. 5.14 Solicitation Advertising
You shall conduct advertising to solicit Applicants for the purchase of Unit Franchisees in the
Master Territory ("Solicitation Advertising"). You shall expend not less than $5,000 each month on
such Solicitation Advertising. To protect the Proprietary Marks and our goodwill in the industry,
you must submit samples of all proposed Solicitation Advertising materials to us at least fifteen
(15) days before any use of the same. If we do not disapprove the proposed Solicitation Advertising
materials within fifteen (15) days after receipt of the same, you may use the proposed Solicitation
Advertising materials as submitted to us; provided, however, that if such Solicitation Advertising
is required to be submitted to a government agency, you shall so submit such materials to the
applicable government agency and shall not use such materials until the materials are approved or
disapproved or if the use of the materials otherwise become permissible under law, such as if notice
of disapproval is not received from a governmental agency within a stated period of time prescribed
by law. We may, at any time after you begin to use the Solicitation Advertising materials, prohibit
further use of the same, effective upon your receipt of written notice from us to do so. 5.15
Policies and Procedures You shall not have the right to establish policies and/or procedures
pertaining to the operation of the Franchised Business to protect the Proprietary Marks and our
goodwill in the industry outside of the policies and/or procedures that we designate. You and all
Unit Franchisees subject to the license granted under this Agreement shall be bound by our policies
and/or procedures upon receipt of the same. 5.16 Changes to the System You acknowledge and agree
that the System must continue to evolve in order to reflect the changing market and to meet new and
changing customer demands and that, accordingly, variations and additions to the System may be
required from time to time in order to preserve and enhance the public image of the System and to
insure the continuing operation efficiency of Unit Franchisees generally. Accordingly, you
acknowledge and agree that we may from time to time change the System, including, without
limitation, the adoption and use of new or modified trademarks, products, services, equipment and
furnishings and new techniques and methodologies relating to the preparation, sale, promotion and
marketing of services and supplies. You shall promptly accept, implement, use and display all such
additions, modifications and changes at your sole cost and expense, and you shall ensure that all
Unit Franchisees in your Master Territory promptly accept, implement, use and display all such
additions, modifications and changes. You further acknowledge and agree that we may inspect your
Franchised Business and any Unit Franchise in the Master Territory to verify that your Franchised
Business and/or such Unit Franchise is operating in compliance with our System, as it may be
modified from time to time.

14

Source: SOUPMAN, INC., 8-K, 8/14/2015
<!-- page 20 -->
5.17 Developments are Our Property You acknowledge and agree that, in consideration for the right to
use the System and our expertise in the field, if you, any of your employees or any Unit Franchisees
in the Master Territory develop any new concept, process or improvement in the operation or
promotion of the Franchised Business, you will promptly notify us and provide us with all necessary
information concerning same, without any compensation to you, your employee or Unit Franchisee. You
acknowledge and agree that any such concept, process or improvement shall become our property and we
may utilize or disclose such information to other master franchisees and unit franchisees as we
determine to be appropriate. 5.18 Financial Statements and Updated Unit Franchise Disclosure
Document You shall, at your sole cost and expense, prepare and submit to us within one hundred
twenty (120) days after each fiscal year end, a complete, audited financial statement for the
preceding fiscal year prepared by an independent certified public accountant in accordance with
generally accepted accounting principles. Each audited financial statement shall include a balance
sheet and a profit and loss statement. If you own, directly or beneficially, a controlling financial
interest in any other business, the financial statements required to be submitted by you must
reflect your financial condition and your other business operations on a consolidated basis. You
understand and acknowledge that the Federal Trade Commission's disclosure requirements for
franchising (16 CFR Part 436) require you to include audited financial statements each year after
your fiscal year end. You further understand and acknowledge that, as with your initial Unit
Franchise Disclosure Document, all annual updates to your Unit Franchise Disclosure Document shall
be submitted to us or our counsel for review within one hundred twenty (120) days after each fiscal
year end. Notwithstanding the foregoing, we reserve the right to inspect or examine your accounts,
books, records and tax returns, at any reasonable time, with or without prior notice to you. 5.19
Our Website We or one or more of our designees may establish a website or series of websites for the
System to advertise, market and promote The Original Soupman businesses and the products and
services they offer, the Unit Franchise and/or master franchise opportunity, and/or for any other
purposes that we determine are appropriate for The Original Soupman businesses (collectively, the
"System Website"). If we include information about your Franchised Business on the System Website,
you agree to give us the information and materials that we periodically request concerning the
Franchised Business and otherwise participate in the System Website in the manner that we
periodically specify. By posting or submitting to us information or materials for the System
Website, you are representing to us that the information and materials are accurate and not
misleading and do not infringe upon any third party's rights. We shall own all intellectual property
and other rights in the System Website and all information it contains, including the domain name or
uniform resource locator ("URL") for the System Website, the log of "hits" by visitors, and any
personal or business data that visitors (including you and your personnel) supply. We may implement
and periodically modify System standards relating to the System Website and, at our option, may
discontinue the System Website, or any services offered through the System Website, at any time. All
advertising, marketing and promotional materials that you develop for your Franchised Business must
contain notices of the URL of the System Website in the manner that we periodically designate. You
may not develop, maintain or authorize any other website, other online presence or other electronic
medium that mentions or describes the Franchised Business, the System or displays any of the Marks
without our prior approval. We do not restrict the use of internet or web page advertising within or
outside of your Master Territory, but the advertising content must be approved by us before it is
used.

15

Source: SOUPMAN, INC., 8-K, 8/14/2015
<!-- page 21 -->
Nothing in the Franchise Agreement shall limit our right to maintain websites other than the System
Website or to offer and sell products and services under the Marks from the System Website, another
website or otherwise over the Internet without payment or obligation of any kind to you. You are
strictly prohibited from establishing your own website related to the Proprietary Marks or our
System without our prior written consent, which we do not have to provide. You are also prohibited
from promoting your Franchised Business on social and networking websites, including Facebook,
LinkedIn, MySpace Twitter and/or other social media sites or platforms, without our prior written
consent. We will control all social media initiatives. You must comply with our System standards
regarding the use of social media in the operation of your Franchised Business, including
prohibitions on your and your employees posting or blogging comments about the Franchised Business
or the System, other than on a website established or authorized by us ("social media" includes
personal blogs, common social networks like Facebook and MySpace, professional networks like
LinkedIn, live-blogging tools like Twitter, virtual worlds, file, audio and video-sharing sites, and
other similar social networking or media sites or tools). We will provide access to branded social
media pages/handles/assets, and you must update these regularly. We reserve the right to conduct
collective/national campaigns via local social media on your behalf. We alone will be, and at all
times will remain, the sole owner of the copyrights to all material which appears on any System
Website we establish and maintain, including any and all material you may furnish to us as provided
above. 5.20 Our Intranet 5.20.1 We may, at our sole discretion and option, establish and maintain a
private method of communication for use only by employees and master franchisees of ours, as well as
Unit Franchisees in the System (an "Intranet"), through which we, master franchisees, our employees
and Unit Franchisees may communicate with each other, and through which we may disseminate the
Manuals, updates thereto and other confidential information. We shall have sole discretion and
control over all aspects of the Intranet, including the content and functionality thereof. We will
have no obligation to maintain the Intranet indefinitely, and may dismantle it at any time without
liability to you. 5.20.2 If we establish an Intranet, you shall have the privilege to use the
Intranet, subject to your strict compliance with the standards and specifications, protocols and
restrictions that we may establish from time to time. Such standards and specifications, protocols
and restrictions may relate to, among other things, (a) the use of abusive, slanderous or otherwise
offensive language in electronic communications; (b) communications between or among master
franchisees that endorse or encourage breach of any master franchisee's agreement with us; (c)
confidential treatment of materials that we transmit via the Intranet; (e) password protocols and
other security precautions; (f) grounds and procedures for our suspending or revoking a master
franchisee's access to the Intranet; and (g) a privacy policy governing our access to and use of
electronic communications that master franchisees post to the Intranet. We may establish similar
standards and protocols related to Unit Franchises. You acknowledge that, as administrator of the
Intranet, we can technically access and shall be entitled to view any communication that any person
posts on the Intranet. You further acknowledge that the Intranet facility and all communications
that are posted to it will become our property, free of any claims of privacy or privilege that you
or any other person may assert.

16

Source: SOUPMAN, INC., 8-K, 8/14/2015
<!-- page 22 -->
5.20.3 Upon receipt of notice from us that we have established the Intranet, you shall establish and
continually maintain (during all times that the Intranet shall be established and until the
termination of this Agreement) an electronic connection (the specifications of which shall be
specified in the Manuals) with the Intranet that allows us to send messages to and receive messages
from you, subject to our standards and specifications. 5.20.4 If you fail to pay when due any fees
or other amounts payable to us under this Agreement, or any other agreement with us or our
affiliates, or otherwise fail to perform your obligations under this Agreement or any other
agreement with us or our affiliates, we may, without prior notice and without any liability or
recourse as against us or our affiliates, temporarily disable or terminate your access to the
Intranet until such time as you pay and/or perform your outstanding obligation in full. 5.20.5 You
shall, at our option and request, and without any additional consideration, assign to us all rights
to all e-mail addresses, URLs, domain names, Internet listings, and Internet accounts related to the
Franchised Business following demand by us upon your misuse of the same and/or the termination or
expiration of this Agreement. Furthermore, you hereby appoint us as your attorney-in-fact with full
power and authority for the sole purpose of assigning these rights to us. This appointment shall be
deemed to be coupled with an interest and shall continue in full force and effect until and
following the termination or expiration of this Agreement. 6. PROPRIETARY MARKS 6.1 Our
Representations We represent with respect to the Proprietary Marks that: 6.1.1 We are the owner or
the licensee of the owner of the Proprietary Marks with a license to use, and to license others to
use, the Proprietary Marks. All references herein to our right, title and interest in and to the
Proprietary Marks shall include the owner's right, title and interest in and to the Proprietary
Marks. 6.1.2 All steps reasonably necessary to preserve and protect the validity of the Proprietary
Marks, and our right to use and license others to use, the Proprietary Marks will be taken. 6.1.3 We
will use and permit you and other master franchisees to use the Proprietary Marks only in accordance
with the System and the standards and specifications attendant thereto which underlie the goodwill
associated with and symbolized by the Proprietary Marks. 6.2 Your Representations You represent with
respect to the Proprietary Marks that: 6.2.1 You shall use only the Proprietary Marks designated by
us, and shall use them only in the manner authorized and permitted by us. 6.2.2 You shall use the
Proprietary Marks only for the operation of the Franchised Business, in connection with approved
advertising for the Franchised Business and with the authorized sub-license of the Proprietary Marks
to your Unit Franchisees. 6.2.3 You shall identify yourself as an independent franchisee-owner of
ours in conjunction with any use of the Proprietary Marks and the operation of the Franchised
Business, including, but not limited to, such use on invoices, order forms, receipts, business
stationery and contracts, as we may designate in writing. The form and content of the identification
of the Franchised Business as being independently owned and operated shall comply with standards set
forth in the Manuals.

17

Source: SOUPMAN, INC., 8-K, 8/14/2015
<!-- page 23 -->
6.2.4 Your right to use the Proprietary Marks is limited to such uses as are authorized under this
Agreement, and any unauthorized use thereof shall constitute an infringement. 6.2.5 You shall not
use the Proprietary Marks to incur any obligation or indebtedness on our behalf. 6.2.6 You shall
execute any documents deemed necessary by us or our affiliates to obtain protection for the
Proprietary Marks or to maintain their continued validity and enforceability. 6.2.7 You shall not
use the Proprietary Marks as part of your corporate or other legal name. 6.2.8 You shall promptly
notify us of any suspected unauthorized use of or any challenge to the validity of the Proprietary
Marks, or any challenge to our or our affiliate's ownership of, our license to use and to license
others to use, or your right to use, the Proprietary Marks licensed under this Agreement. You
acknowledge that we or our affiliate have the right to direct and control any administrative
proceeding or litigation, or other adjudicative proceeding involving the Proprietary Marks,
including any settlement thereof. We or our affiliate have the right, but not the obligation, to
take action against uses by others that may constitute infringement of the Proprietary Marks. We
shall defend you against any third-party claim, suit, or demand arising out of your use of the
Proprietary Marks; provided, however, that your use of the Proprietary Marks is in compliance with
this Agreement. If we, in our sole discretion, determine that you have used the Proprietary Marks in
accordance with this Agreement, the cost of such defense, including the cost of any judgment or
settlement, shall be borne by us. If we, in our sole discretion, determine that you have not used
the Proprietary Marks in accordance with this Agreement, the cost of such defense, including the
cost of any judgment or settlement, shall be borne by you. In the event of any litigation relating
to your use of the Proprietary Marks, you shall execute any and all documents and do such acts as
may, in our opinion, be necessary to carry out such defense or prosecution, including, but not
limited to, becoming a nominal party to any legal action. Except to the extent that such litigation
is the result of your use of the Proprietary Marks in a manner inconsistent with the terms of this
Agreement, we agree to reimburse you for your out-of-pocket litigation costs in doing such acts. 6.3
Your Acknowledgments You acknowledge and agree that: 6.3.1 As between you and us, we are the owner
of all right, title, and interest in and to the Proprietary Marks and the goodwill associated with
and symbolized by them and we have the right to use, and license others to use, the Proprietary
Marks. 6.3.2 The Proprietary Marks are valid and serve to identify the System and those who are
franchised under the System. 6.3.3 During the term of this Agreement and after its expiration or
termination, you shall not directly or indirectly contest the validity of, or our ownership of the
Proprietary Marks, nor take any other action which may tend to jeopardize our or our affiliate's
interest therein, or our right to use and to license others to use the Proprietary Marks.

18

Source: SOUPMAN, INC., 8-K, 8/14/2015
<!-- page 24 -->
6.3.4 Your use of the Proprietary Marks pursuant to this Agreement does not give you any ownership
interest or other interest in or to the Proprietary Marks other than the limited license granted by
this Agreement. 6.3.5 Any and all goodwill arising from your use of the Proprietary Marks shall
inure solely and exclusively to the benefit of us or our affiliate, and upon expiration or
termination of this Agreement and the license herein granted no monetary amount shall be assigned as
attributable to any goodwill associated with your use. 6.3.6 The right and license of the
Proprietary Marks granted under this Agreement to you is non-exclusive, and we and our affiliates
have and retain the rights described in Section 1.3 of this Agreement. 6.3.7 We reserve the right to
change, revise, or substitute different proprietary marks for use in identifying the System and the
Franchised Business, if the Proprietary Marks no longer can be used or if we, in our sole
discretion, determine that substitution of different proprietary marks will be beneficial to the
System. In such circumstances, the use of the substituted proprietary marks shall be governed by the
terms of this Agreement, and we shall not compensate you for such substitution. If our currently
licensed Proprietary Marks can no longer be used, you shall implement promptly any such substitution
at your expense. 6.3.8 We shall have the right, at all reasonable times, to inspect the products and
services on which the Proprietary Marks shall be used as we consider necessary to carry out the
purposes of inspection as part of appropriate quality control. Upon request, you shall submit to us
all packages, labels, advertising, advertising brochures and other materials bearing the Proprietary
Marks and you specifically undertake to amend to our satisfaction any such packages, labels,
advertising, advertising brochures and other materials which are not approved by us. 6.4 Changes in
Law Affecting Proprietary Marks If trademark law is amended so as to render inapplicable any of the
provisions of this Section 6, you shall execute any documents, and do such acts and things as in our
opinion may be necessary to effect the intent and purpose of the provisions of this Agreement.

19

Source: SOUPMAN, INC., 8-K, 8/14/2015
<!-- page 25 -->
7. NON-COMPETITION 7.1 Restrictions You acknowledge and agree that pursuant to this Agreement, you
and your principals and employees will receive valuable specialized training, trade secrets and
confidential information, including, without limitation, information regarding the operational,
sales, promotional and marketing methods and techniques of us and the System, over and above the
ordinary skills and experience possessed by you or your principals and employees prior to execution
of this Agreement. In consideration for such training, trade secrets and confidential information,
you and your principals agree that during the term of this Agreement, and for a continuous
uninterrupted period commencing upon expiration or termination of this Agreement, regardless of the
cause for termination, and continuing for a period of three (3) years thereafter, neither you nor
your principals shall, directly or indirectly, for themselves, or through, on behalf of, or in
conjunction with any person, persons, partnership, limited liability company or corporation: 7.1.1
Divert or attempt to divert any business or customer of the Franchised Business or any Unit
Franchisee anywhere, by direct or indirect inducement or otherwise, or do or perform, directly or
indirectly, any other act injurious or prejudicial to the goodwill associated with our Proprietary
Marks or the System. 7.1.2 Employ or seek to employ any person who is at that time employed by us or
by any other master franchisee or unit franchisee in the System, or otherwise directly or indirectly
induce such person to leave his or her employment without our written consent. 7.1.3 Own, maintain,
operate, engage in, or have any interest in any business which is the same as or similar to the
Franchised Business, or any other business which performs any type of child tutoring services,
anywhere. 7.2 Independent Covenants Each of the foregoing covenants shall be construed as
independent of any other covenant or provision of this Agreement. If all or any portion of any
covenant in this Section 7 is held unreasonable or unenforceable by a court having valid
jurisdiction in any unappealed final decision to which we are a party, you and your principals shall
be bound by any lesser covenant subsumed within the terms of such covenant that imposes the maximum
duty permitted by law, as if the resulting covenant were separately stated in and made a part of
this Section 7. 7.3 Reduction of Scope You acknowledge and agree that we shall have the right, in
our sole and absolute discretion, to reduce the scope of any covenant set forth in this Section 7,
or any portion thereof, without your consent, effective immediately upon written notice to you, and
you further acknowledge and agree that you shall comply forthwith with any covenant as so modified,
which shall be fully enforceable notwithstanding the provisions of any other provision of this
Agreement. 7.4 No Defense You acknowledge and agree that the existence of any claims you may have
against us, whether or not arising from this Agreement, shall not constitute a defense to our
enforcement of the covenants in this Section 7. You shall pay all costs and expenses (including
reasonable attorneys' fees) incurred by us in the enforcement of this Section 7. 7.5 Irreparable
Injury You acknowledge and agree that any violation of the terms of this Section 7 would result in
irreparable injury to us, for which no adequate remedy at law may be available, and you consent that
we may apply for the issuance of an injunction prohibiting any conduct by you in violation of this
Section 7, without the posting of any bond. 7.6 Additional Parties At our request, you shall require
and obtain execution of covenants similar to those set forth in this Section 7 (including covenants
applicable upon the termination of a person's relationship with you) from any or all principals of
yours and other personnel employed by you who have received or will receive training from us or from
you. Every covenant required by this Section 7.6 shall be in a form satisfactory to us, including,
without limitation, specific identification of us as a third party beneficiary of such covenants
with an independent right to enforce them. Your failure to obtain execution of any covenant required
by this Section 7 shall constitute a material default under the terms of this Agreement. 20

Source: SOUPMAN, INC., 8-K, 8/14/2015
<!-- page 26 -->
8. MANUALS AND CONFIDENTIAL INFORMATION 8.1 Use of Manuals We shall provide the Manuals to you, on
loan, for the term of this Agreement and any renewals hereof. You shall operate the Franchised
Business in accordance with the standards, methods, policies, and procedures specified in the
Manuals to ensure compliance with quality standards to protect the Proprietary Marks and our
goodwill in the industry. You shall treat the Manuals, any other manuals created for or approved for
use in the operation of the Franchised Business, and the information contained therein as
confidential, and shall maintain such information as secret and confidential. You shall not at any
time copy, duplicate, record, or otherwise reproduce the foregoing materials, in whole or in part,
or otherwise make the same available to any unauthorized person. The Manuals shall at all times
remain our sole property and shall be kept in a secure place at your office. You shall ensure that
your copy of the Manuals is kept current at all times, and in the event of any dispute as to the
contents of the Manuals, the terms of the master copy of the Manuals maintained by us shall be
controlling. If you require or request additional copies of any of the Manuals, you agree to pay our
then-current fee for each replacement volume of the Manuals required or requested. 8.2
Confidentiality of Information You shall not, during the term of this Agreement or thereafter,
communicate, divulge, or use for the benefit of anyone else, any confidential information,
knowledge, or know-how concerning the methods of operation of the Franchised Business which may be
communicated to you, or of which you may be apprised, by virtue of your operation under the terms of
this Agreement. You shall divulge such confidential information only to such of your employees as
must have access to it in order to perform their employment responsibilities. Any and all matters,
information, knowledge, know-how, techniques and other data which we designate as confidential shall
be deemed confidential for purposes of this Agreement. 8.3 Irreparable Injury from Disclosure of
Confidential Information You acknowledge that failure to comply with the requirements of this
Section 8 will result in irreparable injury to us for which no adequate remedy at law may be
available, and you consent to the issuance of, and agree to pay all court costs and reasonable
attorneys' fees incurred by us in obtaining, without the posting of any bond, an ex parte or other
order for injunctive or other legal or equitable relief with respect to the requirements of this
Section 8. 8.4 Confidentiality Covenants from Individuals Associated with You You shall require any
employee who may have access to any confidential information of ours to execute covenants that they
will maintain the confidentiality of information they receive in connection with their association
with you. Such covenants shall be in a form satisfactory to us, including, without limitation,
specific identification of us as a third party beneficiary of such covenants with the independent
right to enforce them.

21

Source: SOUPMAN, INC., 8-K, 8/14/2015
<!-- page 27 -->
9. OUR OBLIGATIONS During the term of this Agreement, we shall provide you with the following: 9.1
Manuals and Assistance We will make the Manuals, training aids, and other pertinent information
concerning our methods and practices available to you. You understand and acknowledge that such
materials are provided to you on loan, and that such materials remain our property at all times. 9.2
Training Program We will provide you or one of your principals and up to five (5) additional persons
with a comprehensive initial training program and additional training programs from time to time.
Any additional training shall be at your expense. The group of trainees must include management
level employees and the principal owner of at least 25% interest in the location, if it's a
franchisee or the franchisee is a corporate entity. 9.3 Advice and Assistance We will have personnel
available on an ongoing basis during normal business hours to provide technical assistance,
consultation, and advice on marketing and operations procedures for the Franchised Business by
telephone and e-mail. If you request additional on-site assistance and/or training at your
Franchised Business location, you agree to pay our then-current per diem fee for each representative
we send to your location, and you shall reimburse each representative's expenses while providing
such on-site training or assistance, including, but not limited to, travel, lodging and meals. 9.4
Proprietary Marks We will allow you to use the Proprietary Marks in the Master Territory, subject to
the limitations and restrictions set forth in this Agreement, and to use the processes, methods,
materials, equipment and promotional plans developed by us. 9.5 Advice We will advise you on all
appropriate facets of the System and all pertinent new developments in the operation of a The
Original Soupman business and/or master franchise business. 10. DEFAULT AND TERMINATION 10.1
Termination in the Event of Bankruptcy or Insolvency You shall be in default under this Agreement,
and all rights granted to you herein shall automatically terminate without notice to you, if you, or
any of your partners, if you are a partnership, or any of your officers, directors, shareholders, or
members, if you are a corporation or limited liability company, shall become insolvent or make a
general assignment for the benefit of creditors; if a petition in bankruptcy is filed by you or such
a petition is filed against and not opposed by you; if you are adjudicated a bankrupt or insolvent;
if a bill in equity or other proceeding for the appointment of a receiver or other custodian for you
or your business or assets is filed and consented to by you; if a receiver or other custodian
(permanent or temporary) of your assets or property, or any part thereof, is appointed by any court
of competent jurisdiction; if proceedings for a composition with creditors under any state or
federal law should be instituted by or against you; if a final judgment remains unsatisfied or of
record for thirty (30) days or longer (unless a supersedeas bond is filed); if you are dissolved; if
execution is levied against your business or property; if suit to foreclose any lien or mortgage
against the premises or equipment of the Franchised Business is instituted against you and not
dismissed within thirty (30) days; or if the real or personal property of the Franchised Business
shall be sold after levy thereupon by any sheriff, marshal, or constable.

22

Source: SOUPMAN, INC., 8-K, 8/14/2015
<!-- page 28 -->
10.2 Termination with Notice and without Opportunity to Cure You shall be in default under this
Agreement, and we may, at our option, terminate this Agreement and all rights granted under this
Agreement, without affording you any opportunity to cure the default, effective immediately upon
receipt of notice by you upon the occurrence of any of the following events: 10.2.1 If you at any
time cease to operate or otherwise abandon the Franchised Business without our consent, or otherwise
forfeit the right to do or transact business in the Master Territory. 10.2.2 If you (or an officer
or director of or a shareholder in you, if you are a corporation, or a general or limited partner of
you, if you are a partnership, or a member, if you are a limited liability company) are convicted of
a felony, a crime involving moral turpitude, a crime against a child, or any other crime or offense
that we believe is reasonably likely to have an adverse effect on the System, the Proprietary Marks,
the goodwill associated therewith, or our interest therein. 10.2.3 If any purported assignment or
transfer of any direct or indirect interest in this Agreement, in you, or in all or substantially
all of the assets of the Franchised Business is made to any third party without our prior written
consent, contrary to the terms of Section 12 of this Agreement. 10.2.4 If an approved transfer, as
required by Section 12.6 of this Agreement, is not effected within the time provided following a
death or permanent incapacity (mental or physical). 10.2.5 If you fail to comply with the covenants
in Section 7 of this Agreement or fail to deliver to us the executed covenants required under
Section 7.6 or Section 8.4 of this Agreement. 10.2.6 If, contrary to the terms of Section 8 of this
Agreement, you or any principal or employee of yours disclose or divulge the contents of the Manuals
or other confidential information provided to you by us. 10.2.7 If you or any principal of yours has
made any material misrepresentations in connection with your application to us for the franchise
granted herein. 10.2.8 If you, after curing a default pursuant to Section 10.3 of this Agreement,
commit the same, similar, or different default again, whether or not cured after notice, or if you
incur three (3) late fees or insufficient funds fees in any twelve (12) month period. 10.2.9 If you
lose, through revocation, forfeiture, failure to renew, or otherwise, any license required with
respect to the operation of the Franchised Business. 10.2.10 If you fail to successfully complete
our initial training program. 10.2.11 If you understate any payment to us by two percent (2%) or
more, or understate any such payment in any amount twice in any two (2) year period.

23

Source: SOUPMAN, INC., 8-K, 8/14/2015
<!-- page 29 -->
10.2.12 If you knowingly maintain false books or records or submit any false reports or statements
to us. 10.2.13 If you fail to obtain or maintain required insurance coverage and do not obtain such
coverage within ten (10) days after written notice from us. 10.2.14 If, within ten (10) days after
receipt of written notice from us that any required payment is overdue, you do not make such payment
to us, our affiliates, or to your suppliers or creditors unless, with respect to your suppliers or
creditors, you notify us of the existence on a bona fide dispute and takes immediate action to
resolve it. 10.2.15 If you fail to make timely payments of any obligation of yours upon which we
have advanced any funds for you or on your behalf. 10.2.16 If you (or any guarantor, officer or
director of or a shareholder in you, if you are a corporation, or a general or limited partner of
you, if you are a partnership, or a member, if you are a limited liability company) or any other
franchisee of ours which controls, is controlled by, or is under common control with you fail to
comply with any or all of the terms of this Agreement or any other agreement between us or our
affiliates and you within ten (10) days after receipt of written notice from us to do so. 10.2.17 If
you default in the repayment or performance of any obligation or financing transaction with third
parties under which any asset of the Franchised Business is pledged as security for your
performance. 10.2.18 If you fail to comply with all applicable laws and ordinances relating to the
Franchised Business, including Anti- Terrorism Laws, or if your or any of your owners' assets,
property, or interests are blocked under any law, ordinance, or regulation relating to terrorist
activities, or you or any of your owners otherwise violate any such law, ordinance, or regulation.
10.2.19 If you fail to register the Unit Franchise Disclosure Document with any registration state
applicable to the Master Territory or if you violate any requirements of applicable federal or state
law related to the disclosure and sale of franchises. 10.2.20 If you fail to comply with the Minimum
Development Quota. 10.3 Termination with Notice and Opportunity to Cure Except as otherwise provided
in Sections 10.1 and 10.2 of this Agreement, you shall have thirty (30) days after your receipt from
us of a written notice of default within which to remedy any default under this Agreement and to
provide evidence thereof to us. If any such default is not cured within the specified time, or such
longer period as applicable law may require, we shall have the right to terminate this Agreement by
providing written notice of termination to you. You shall be in default pursuant to this Section
10.3 for failure to substantially comply with any of the requirements imposed by this Agreement, as
it may from time to time reasonably be modified or supplemented by the Manuals, or your failure to
carry out the terms of this Agreement in good faith. 10.4 Cross-Default Any default by you (or any
person/company affiliated with you) under this Agreement may be regarded as a default under any
other agreement between us (or any of our affiliates) and you (or any of your affiliates). Any
default by you (or any person/company affiliated with you) under any other agreement, including, but
not limited to, any lease and/or sublease, between us (or any of our affiliates) and you (or any
person/company affiliated with you), and any default by you (or any person/company affiliated with
you) under any obligation to us (or any of our affiliates) may be regarded as a default under this
Agreement. Any default by you (or any person/company affiliated with you) under any lease, sublease,
loan agreement, security interest or otherwise, whether with us, any of our affiliates and/or any
third party may be regarded as a default under this Agreement and/or any other agreement between us
(or any of our affiliates) and you (or any of your affiliates).

24

Source: SOUPMAN, INC., 8-K, 8/14/2015
<!-- page 30 -->
In each of the foregoing cases, we (and any of our affiliates) will have all remedies allowed at
law, including termination of your rights (and/or those of any person/company affiliated with you)
and our (and/or our affiliates') obligations. No right or remedy which we may have (including
termination) is exclusive of any other right or remedy provided under law or equity and we may
pursue any rights and/or remedies available. 10.5 Our Right to Discontinue Services to You If you
are in breach of any obligation under this Agreement, and we deliver to you a notice of termination
as provided herein, we have the right to suspend our performance of any of our obligations under
this Agreement including, without limitation, the sale or supply of any services or products for
which we are an approved supplier to you and/or suspension of your webpage and/or listing on the
System Website, until such time as you correct the breach. 10.6 Termination of this Agreement by You
You shall have no right to terminate this Agreement. 10.7 Without Prejudice The termination of this
Agreement shall be without prejudice to any remedy or cause of action which we may have against you
for the recovery of any monies due us or any equipment or other property of ours, or any other right
of ours to recover damages for any breach hereof. 10.8 Amendment Pursuant to Applicable Law
Notwithstanding anything to the contrary contained in this Article, if any valid, applicable law or
regulation of a competent governmental authority having jurisdiction over this franchise and the
parties hereto shall limit our rights of termination under this Agreement or shall require longer
notice periods than those set forth above, this Agreement is deemed amended to satisfy the minimum
notice periods or restrictions upon such termination required by such laws and regulations;
provided, however, that such constructive amendment shall not be deemed a concession by us that the
grounds for termination set forth in this Agreement do not constitute "good cause" for termination
within the meaning ascribed to that term by any applicable law or regulation. We shall not be
precluded from contesting the validity, enforceability or application of such laws or regulations in
any action, hearing or proceeding relating to this Agreement or the termination of this Agreement.

25

Source: SOUPMAN, INC., 8-K, 8/14/2015
<!-- page 31 -->
11. OBLIGATIONS UPON TERMINATION OR EXPIRATION Upon termination or expiration of this Agreement, all
rights granted under this Agreement to you shall forthwith terminate and: 11.1 Cessation of Business
You shall immediately cease to operate the Franchised Business, and shall not thereafter, directly
or indirectly, represent to the public or hold yourself out as a present or former master franchisee
of ours. 11.2 Cessation of Use of Confidential Information and Proprietary Marks You shall
immediately and permanently cease to use, by advertising or in any other manner whatsoever, any
confidential methods, procedures, and techniques associated with the System, and all Proprietary
Marks and distinctive forms, slogans, signs, symbols, and devices associated with the System. 11.3
Cancellation of Assumed Name Registration You shall take such action as may be necessary to cancel
any assumed name registration or equivalent registration obtained by you which contains the
Proprietary Marks; and you shall furnish us with evidence satisfactory to us of compliance with this
obligation within thirty (30) days after termination or expiration of this Agreement. 11.4 Payment
of Monies Due; Liquidated Damages 11.4.1 You shall promptly pay all sums owing to us and our
affiliates. In the event of termination for any default of yours, such sums shall include all
damages, costs, and expenses, including reasonable attorneys' fees, incurred by us as a result of
the default, which obligation shall give rise to and remain, until paid in full, a lien in our favor
against any and all leasehold improvements, fixtures, furnishings and equipment, inventory, supplies
and vehicles located at or used in connection with the Franchised Business, together with all
accounts, payment intangibles, attachments, accessories, additions, substitutions and replacements,
all cash and non-cash proceeds derived from insurance or the disposition of such assets, all your
rights to use the Proprietary Marks, patents, copyrights and their registrations, trade secret
information and other proprietary rights, and all rights granted, owned or licensed to you under
this Agreement for the use of the Proprietary Marks, trade names, trade styles, patents, copyrights,
trade secret information and other proprietary rights. We shall have full power and authority to
file such documents as are necessary to obtain and perfect such lien. We shall have the right to set
off any amounts which we deem are payable to us by you. 11.4.2 In addition to the foregoing, upon
termination of this Agreement by us for cause as described in Section 10, you agree to pay to us
within fifteen (15) days after the effective date of this Agreement's termination, in addition to
the amounts owed hereunder, liquidated damages equal to the average monthly Unit Franchise
Performance Royalty Fee and Franchise Sales Royalty Fee you paid during the twelve (12) months of
operation preceding the effective date of termination multiplied by (a) twenty-four (24) (being the
number of months in two (2) full years), or (b) the number of months remaining in the Agreement had
it not been terminated, whichever is lower. 11.4.3 The parties hereto acknowledge and agree that it
would be impracticable to determine precisely the damages we would incur from this Agreement's
termination and the loss of cash flow from Royalty Fees due to, among other things, the
complications of determining what costs, if any, we might have saved and how much the Royalty Fees
would have grown over what would have been this Agreement's remaining term. The parties hereto
consider this liquidated damages provision to be a reasonable, good faith pre-estimate of those
damages. 11.4.4 The liquidated damages provision only covers our damages from the loss of cash flow
from the Royalty Fees. It does not cover any other damages, including damages to our reputation with
the public and landlords and damages arising from a violation of any provision of this Agreement
other than the Royalty Fee sections. You and each of your principals agree that the liquidated
damages provision does not give us an adequate remedy at law for any default under, or for the
enforcement of, any provision of this Agreement other than the Royalty Fee sections.

26

Source: SOUPMAN, INC., 8-K, 8/14/2015
<!-- page 32 -->
11.5 Costs to Secure Compliance You shall pay to us all damages, costs, and expenses, including
reasonable attorneys' fees, incurred by us prior or subsequent to the termination or expiration of
the franchise herein granted in obtaining injunctive or other relief for the enforcement of any
provisions of this Section 11. 11.6 Return of Manuals and Other Confidential Information You shall
immediately deliver to us the Manuals and all other records, correspondence, files, and any
instructions containing confidential information relating to the operation of the Franchised
Business which are in your possession, and all copies thereof, all of which are acknowledged to be
our property. 11.7 Irreparable Injury to Us You agree and acknowledge that your failure to comply
with the provisions of this Section 11 will result in irreparable harm to us and to the Proprietary
Marks, and you agree to pay all damages, expenses, court costs and reasonable attorneys' fees
incurred by us in obtaining specific performance of, or an injunction against violation of, and/or
damages resulting from a violation of, the requirements of this Section 11. 11.8 Compliance with
Post-Term Covenants All of your covenants, obligations, and agreements which by their terms or by
reasonable implication are to be performed, in whole or in part, after the termination or expiration
of this Agreement, shall survive such termination or expiration. 12. TRANSFER OF INTEREST 12.1
Transfer by Us We shall have the right to assign this Agreement and all of our attendant rights and
privileges to any person, firm, corporation or other entity provided that, with respect to any
assignment resulting in the subsequent performance by the assignee of our functions: (i) the
assignee shall, at the time of such assignment, be financially responsible and economically capable
of performing our obligations; and (ii) the assignee shall expressly assume and agree to perform
such obligations. You expressly affirm and agree that we may sell our assets, our rights to the
Proprietary Marks or to the System outright to a third party; may go public; may engage in a private
placement of some or all of our securities; may merge, acquire other corporations, or be acquired by
another corporation; may undertake a refinancing, recapitalization, leveraged buyout or other
economic or financial restructuring; and, with regard to any or all of the above sales, assignments
and dispositions, you expressly and specifically waive any claims, demands or damages arising from
or related to the loss of said Proprietary Marks (or any variation thereof) and/or the loss of
association with or identification of "Kiosk Concepts, Inc." as Franchisor. Nothing contained in
this Agreement shall require us to remain in the same business or to offer the same products and
services, whether or not bearing the Proprietary Marks, in the event that we exercise our right to
assign our rights in this Agreement.

27

Source: SOUPMAN, INC., 8-K, 8/14/2015
<!-- page 33 -->
12.2 Transfer by You You understand and acknowledge that the rights and duties set forth in this
Agreement are personal to you, and that we have granted this franchise in reliance on your (or, if
you are a corporation, partnership, or limited liability company, your principals') business skill,
financial capacity, and personal character. Accordingly, neither you nor any immediate or remote
successor to any part of your interest in this Agreement, nor any individual, partnership,
corporation, or other legal entity which directly or indirectly owns any interest in you shall not
sell, encumber, assign, transfer, convey, pledge, merge, or give away any direct or indirect
interest in this Agreement, in you, or in all or substantially all of the assets of the Franchised
Business. Any change in the control of you shall be deemed a transfer for purposes of this
Agreement. Any purported assignment or transfer shall be null and void and shall constitute a
material breach of this Agreement, for which we may immediately terminate without opportunity to
cure pursuant to Section 10.2.3 of this Agreement. 12.3 Granting of a Security Interest by You You
shall not grant a security interest in the Franchised Business or in any of the assets of the
Franchised Business without first obtaining our prior written consent. Our consent or refusal to
consent may be based upon whatever factors we, in our sole discretion, deem economically and
commercially reasonable in protecting our interests and security interest under this Agreement and
the relationship created under this Agreement; however, if you are in good standing under this
Agreement and all other agreements between us or our affiliates and you, we shall, upon your written
request, execute a written subordination of our security interest to lenders and/or lessors
providing financing for the Franchised Business. Under any circumstances however, we shall not
consent to any such granting of a security interest unless all of the following conditions are met:
12.3.1 Such security is granted only for the purpose of securing a loan in your favor, which loan
shall only be for the benefit of the Franchised Business. 12.3.2 In the event of any default by you
under any documents in any way relating to the security interest or the loan to which it relates, we
shall have the right at our sole option (but not the obligation) to cure any such default and/or to
be substituted as obligor to the lender whose interests are secured by such security interest.
12.3.3 In the event of any such default, and if we choose to be substituted as obligor, we shall be
so substituted in all respects on the same terms and conditions to which you were subject, except
that any acceleration of the obligations secured, due to your default, shall be void upon cure by
us. 12.3.4 Such other conditions and terms as we shall deem necessary and/or prudent to protect our
interests under this Agreement. 12.4 Transfer Upon Death or Disability Upon the death or permanent
disability (mental or physical) of any person with an interest in this Agreement, in you, or in all
or substantially all of the assets of the Franchised Business, the executor, administrator, or
personal representative of such person shall transfer such interest to a third party approved by us
within twelve (12) months after such death or disability. Such transfers, including, without
limitation, transfers by devise or inheritance, shall be subject to the same conditions as any inter
vivos transfer, except that the transfer fee shall be waived. In the case of transfer by devise or
inheritance, however, if the heirs or beneficiaries of any such person are unable to meet the
conditions of this Section 12, the executor, administrator, or personal representative of the
decedent shall transfer the decedent's interest to another party approved by us within twelve (12)
months, which disposition shall be subject to all the terms and conditions for transfers contained
in this Agreement. We may, at our option, assume management and control of the Franchised Business
during such twelve (12) month period and shall be paid a reasonable monthly management fee for our
services as determined by us. If the interest is not disposed of within such period, we may, at our
option, terminate this Agreement pursuant to Section 10.2.4 of this Agreement.

28

Source: SOUPMAN, INC., 8-K, 8/14/2015
<!-- page 34 -->
12.5 Non-Waiver of Claims Our consent to a transfer shall not constitute a waiver of any claims we
may have against the transferring party, nor shall it be deemed a waiver of our right to demand
exact compliance with any of the terms of this Agreement by the transferor or transferee. 12.6
Transfer by You in Bankruptcy - Right of First Refusal If, for any reason, this Agreement is not
terminated pursuant to Section 10.1 and this Agreement is assumed, or assignment of the same to any
person or entity who has made a bona fide offer to accept an assignment of this Agreement is
contemplated pursuant to the United States Bankruptcy Code, then notice of such proposed assignment
or assumption setting forth: (a) the name and address of the proposed assignee, and (b) all of the
terms and conditions of the proposed assignment and assumption shall be given to us within twenty
(20) days after receipt of such proposed assignee's offer to accept assignment of this Agreement,
and, in any event, within ten (10) days prior to the date application is made to a court of
competent jurisdiction for authority and approval to enter into such assignment and assumption, and
we shall thereupon have the prior right and option, to be exercised by notice given at any time
prior to the effective date of such proposed assignment and assumption, to accept an assignment of
this Agreement to us upon the same terms and conditions and for the same consideration, if any, as
in the bona fide offer made by the proposed assignee, less any brokerage commissions which may be
payable by you out of the consideration to be paid by such assignee for the assignment of this
Agreement. 13. UNIT FRANCHISEES 13.1 Form of Unit Franchise Disclosure Document and Unit Franchise
Agreement All Unit Franchise Disclosure Documents and Unit Franchise Agreements utilized by you with
Unit Franchisees in the Master Territory shall be in substantially the form of our then-current Unit
Franchise Disclosure Document and Unit Franchise Agreement, which shall be prepared by you in
accordance with the provisions of this Section and those of Section 5.1, and shall be reviewed and
approved by us or our counsel. You shall not use any Unit Franchise Disclosure Document or Unit
Franchise Agreement that we or our counsel have disapproved. You shall not use any Unit Franchise
Disclosure Document that has not been registered in any registration state applicable to the Master
Territory. You and we acknowledge and agree that we are a third-party beneficiary to all Unit
Franchise Agreements between you and Unit Franchisees in the Master Territory, and that we shall
have the right to assume any of your responsibilities, duties or functions under such Unit Franchise
Agreements in the event that this Agreement expires or is terminated for any reason. You shall
include in the standard Unit Franchise Agreement used by you a provision which states that we are a
third-party beneficiary to the Unit Franchise Agreement and are entitled to the rights granted in
this Section 13. We shall have the right, but not the obligation, to enforce any provision of any
Unit Franchise Agreement if you fail to properly and promptly do so. You shall not terminate any
Unit Franchisee without our prior written consent.

29

Source: SOUPMAN, INC., 8-K, 8/14/2015
<!-- page 35 -->
13.2 Unit Franchise Disclosure Document and Unit Franchise Agreement Amendments If you desire to
change, modify, adjust or amend the terms of our form of the Unit Franchise Disclosure Document
and/or Unit Franchise Agreement for the purpose of adapting the Unit Franchise Disclosure Document
and/or Unit Franchise Agreement to reflect any terms or conditions which are peculiar to your
circumstances or to reflect legal requirements which are peculiar to the Master Territory, or which
are required by federal or state law and including, but not limited to, your obligation to update
the Unit Franchise Disclosure Document annually as required by applicable law, you shall submit
copies of the revised Unit Franchise Disclosure Document and/or Unit Franchise Agreement which
include the requested changes to us and/or our counsel no less than thirty (30) days prior to the
date said change, modification, adjustment or amendment is to be implemented. We reserve the right
to deny the change, modification, adjustment or amendment and/or may recommend additional changes or
modifications. No such change shall materially affect the terms and condition of this Agreement. You
understand and acknowledge that you are solely responsible for ensuring that any material changes
you make to the Unit Franchise Disclosure Document, once approved by us or our counsel, shall be
submitted as an amendment to any registration state applicable to the Master Territory at your
expense. You further understand and acknowledge that you shall renew the Unit Franchise Disclosure
Document with such registration state(s) according to the rules of such registration state(s), but
not less frequently than annually, at your expense. 13.3 Use of Proprietary Marks You shall have the
responsibility and duty to properly supervise the use of the Proprietary Marks in the Master
Territory. Your failure to exercise the proper diligence in enforcing the terms of any Unit
Franchise Agreement and to insure the appropriate monitoring and use of the Proprietary Marks shall
constitute a default under the terms of this Agreement which may result in termination of this
Agreement. 13.4 Effect of Termination of this Agreement In the event this Agreement is terminated or
expires prior to the end of the term of this Agreement, those portions of this Agreement which
pertain to and apply to any Unit Franchise Agreement will continue in full force and effect, but
only with regard to those Unit Franchise Agreements which have been entered into and were in effect
prior to the date of termination or expiration of this Agreement. 13.5 Unit Franchise Refund Policy
You shall comply with our requirements related to a Unit Franchisee's right to terminate its Unit
Franchise Agreement according to the terms of such Unit Franchise Agreement, if any, as well as our
policy regarding refunds of initial franchise fees to Unit Franchisees, if any. 14. INDEPENDENT
CONTRACTOR AND INDEMNIFICATION 14.1 No Fiduciary Relationship This Agreement does not create a
fiduciary relationship between the parties hereto. You shall be an independent contractor; and
nothing in this Agreement is intended to constitute or appoint either party an agent, legal
representative, subsidiary, joint venturer, partner, employee, or servant of the other for any
purpose whatsoever.

30

Source: SOUPMAN, INC., 8-K, 8/14/2015
<!-- page 36 -->
14.2 Public Notice of Independent Status You shall conspicuously identify yourself and the
Franchised Business in all dealings with your customers, contractors, suppliers, public officials,
and others, as an independent master franchisee of ours, and shall place such notice of independent
ownership in your Franchised Business and on all forms. We shall have the right to specify the
language of any such notice. 14.3 Independent Contractor You acknowledge and agree that you are not
authorized to make any contract, agreement, warranty, or representation on our behalf, or to incur
any debt or other obligations in our name; and that we shall in no event assume liability for, or be
deemed liable under this Agreement as a result of, any such action; nor shall we be liable by reason
of any act or omission of yours in your conduct of the Franchised Business or for any claim or
judgment arising therefrom against you or us. 14.4 Indemnification You shall indemnify and hold
harmless to the fullest extent by law us, our affiliates and our respective directors, officers,
employees, shareholders, and agents, (collectively the "Indemnitees") from any and all losses and
expenses (as hereinafter defined) incurred in connection with any litigation or other form of
adjudicatory procedure, claim, demand, investigation, or formal or informal inquiry (regardless of
whether same is reduced to judgment) or any settlement thereof which arises directly or indirectly
from, as a result of, or in connection with your operation of the Franchised Business including, but
not limited to, claims arising as a result of the maintenance and operation of vehicles
(collectively an "event"), and regardless of whether same resulted from any strict or vicarious
liability imposed by law on the Indemnitees; provided, however, that this indemnity shall not apply
to any liability arising from the gross negligence of the Indemnitees (except to the extent that
joint liability is involved, in which event the indemnification provided herein shall extend to any
finding of comparative negligence or contributory negligence attributable to you). For the purpose
of this Section 14.4, the term "losses and expenses" shall be deemed to include compensatory,
exemplary, or punitive damages; fines and penalties; attorneys' fees; experts' fees; court costs;
costs associated with investigating and defending against claims; settlement amounts; judgments;
compensation for damages to our reputation and goodwill; and all other costs associated with any of
the foregoing losses and expenses. You shall give us prompt notice of any event of which you are
aware for which indemnification is required and, at your expense and risk, we may elect to assume
(but under no circumstance are obligated to undertake) the defense and/or settlement thereof,
provided that we will seek your advice and counsel. Any assumption of ours shall not modify your
indemnification obligation. We may, in our sole judgment, take such actions as we deem necessary and
appropriate to investigate, defend, or settle any event or take other remedial or corrective actions
with respect thereto as may be, in our sole judgment, necessary for the protection of the
Indemnitees or the System. You shall defend us and each of our affiliates, officers, directors,
shareholders, agents, and employees named in any lawsuit based on such loss or expenses and shall
pay all costs and reasonable attorneys' fees associated with such defense. If we wish to retain our
own counsel to defend any such action, you shall reimburse us for all reasonable costs and legal
fees incurred by us for such defense. Said reimbursement shall be made to us in a timely manner upon
demand as such fees are incurred by us and billed to you.

31

Source: SOUPMAN, INC., 8-K, 8/14/2015
<!-- page 37 -->
15. APPROVALS, WAIVERS AND NOTICES 15.1 Obtaining Approvals Whenever this Agreement requires our
prior approval or consent, you shall make a timely written request to us therefor, and such approval
or consent must be obtained in writing. We make no warranties or guarantees upon which you may rely,
and assume no liability or obligation to you by providing any waiver, approval, consent, or
suggestion to you in connection with this Agreement, or by reason of any neglect, delay, or denial
of any request therefor. 15.2 No Waiver No delay, waiver, omission, or forbearance on our part to
exercise any right, option, duty, or power arising out of any breach or default by you, or by any
other franchisee, of any of the terms, provisions, or covenants thereof, and no custom or practice
by the parties at variance with the terms of this Agreement, shall constitute our waiver to enforce
any such right, option, or power as against you, or as to a subsequent breach or default by you.
Subsequent acceptance by us of any payments due to us under this Agreement shall not be deemed to be
our waiver of any preceding or succeeding breach by you of any terms, covenants, or conditions of
this Agreement. 15.3 Notices All notices or demands shall be in writing and shall be served in
person, by Express Mail, by certified mail; by private overnight delivery; or by facsimile. Service
shall be deemed conclusively made (a) at the time of service, if personally served; (b) twenty-four
(24) hours (exclusive of weekends and national holidays) after deposit in the United States mail,
properly addressed and postage prepaid, if served by Express Mail; (c) upon the earlier of actual
receipt or three (3) calendar days after deposit in the United States mail, properly addressed and
postage prepaid, return receipt requested, if served by certified mail; (d) twenty-four (24) hours
after delivery by the party giving the notice, statement or demand if by private overnight delivery;
and (e) at the time of transmission by facsimile, if such transmission occurs prior to 5:00 p.m. on
a business day and a copy of such notice is mailed within twenty-four (24) hours after the
transmission. Notices and demands shall be given to the respective parties at the following
addresses, unless and until a different address has been designated by written notice to the other
party: To Franchisor: Kiosk Concepts, Inc. 1110 South Avenue Staten Island, New York 10314
Attention: President Fax: With a copy to: Harold L. Kestenbaum, Esq. 90 Merrick Avenue, Suite 601
East Meadow, New York 11554 Fax: (516) 745-0293 To Master Franchisee: The Grilled Cheese Truck, Inc.
151 North Nob Hill Road, Suite 321 Fort Lauderdale, FL. 33324 Fax: 32

Source: SOUPMAN, INC., 8-K, 8/14/2015
<!-- page 38 -->
With a copy to: Martin J. Brill, Esq. Levene, Neale, Bender, Yoo & Brill, LLP 10250 Constellation
Blvd., Suite 1700 Los Angeles, CA 90067 Fax: (310 229-1244 Either party may change its address for
the purpose of receiving notices, demands and other communications as herein provided by a written
notice given in the manner aforesaid to the other party. 16. ENTIRE AGREEMENT; SEVERABILITY AND
CONSTRUCTION 16.1 Entire Agreement This Agreement, any attachments hereto, and any ancillary
agreements between you and us or any affiliate which are executed contemporaneously with this
Agreement, constitute the entire and complete Agreement between us (and, if applicable, any
affiliate) and you concerning the subject matter thereof, and supersede all prior agreements. You
acknowledge that you are entering into this Agreement, and any ancillary agreements executed
contemporaneously herewith, as a result of your own independent investigation of the business
franchised hereby and not as a result of any representation made by us or persons associated with
us, or other franchisees, which are contrary to the terms herein set forth or which are contrary to
the terms of any Franchise Disclosure Document or other similar document required or permitted to be
given to you pursuant to applicable law. Except for those permitted under this Agreement to be made
unilaterally by us, no amendment, change, or variation from this Agreement shall be binding on
either party unless mutually agreed to by the parties and executed by their authorized officers or
agents in writing. Nothing in this Section 16.1 is intended to disclaim, or require you to waive
reliance on, any representation made in the Franchise Disclosure Document (the "FDD") that we have
provided to you, except with respect to specific contract terms and conditions set forth in the FDD
that you have voluntarily waived during the course of franchise-sale negotiations. 16.2 Severability
and Construction Except as expressly provided to the contrary herein, each section, paragraph, part,
term, and provision of this Agreement shall be considered severable; and if, for any reason, any
section, paragraph, part, term, provision, and/or covenant herein is determined to be invalid and
contrary to, or in conflict with, any existing or future law or regulation by a court or agency
having valid jurisdiction, such shall not impair the operation of, or have any other effect upon,
such other portions, sections, paragraphs, parts, terms, provisions, and/or covenants of this
Agreement as may remain otherwise intelligible; and the latter shall continue to be given full force
and effect and bind the parties hereto; and the invalid portions, sections, paragraphs, parts,
terms, provisions, and/or covenants shall be deemed not to be a part of this Agreement. Neither this
Agreement or any uncertainty or ambiguity in this Agreement shall be construed or resolved against
the drafter of this Agreement, whether under any rule of construction or otherwise. On the contrary,
this Agreement has been review by all parties and shall be construed and interpreted according to
the ordinary meaning of the words used to fairly accomplish the purposes and intentions of all
parties to this Agreement. We and you intend that if any provision of this Agreement is susceptible
to two or more constructions, one of which would render the provision enforceable and the other or
others of which would render the provision unenforceable, the provision shall be given the meaning
that renders it enforceable. 33

Source: SOUPMAN, INC., 8-K, 8/14/2015
<!-- page 39 -->
16.3 Survival of Obligations After Expiration or Termination of Agreement Any provision or covenant
of this Agreement which expressly or by its nature imposes obligations beyond the expiration or
termination of this Agreement shall survive such expiration or termination. 16.4 Survival of
Modified Provisions You expressly agree to be bound by any promise or covenant imposing the maximum
duty permitted by law which is subsumed within the terms of any provision of this Agreement, as
though it were separately articulated in and made a part of this Agreement, that may result from
striking from any of the provisions of this Agreement any portion or portions which a court or
agency having valid jurisdiction may hold to be unreasonable and unenforceable in an unappealed
final decision to which we are a party, or from reducing the scope of any promise or covenant to the
extent required to comply with such a court or agency order. 16.5 Captions All captions in this
Agreement are intended for the convenience of the parties, and none shall be deemed to affect the
meaning or construction of any provision of this Agreement. 16.6 Responsibility The term "Master
Franchisee" or "you" as used in this Agreement shall refer to each person executing this Agreement
as Master Franchisee/you, whether such person is one of the spouses, partners, shareholders,
members, trustees, trustors or beneficiaries or persons named as included in Master Franchisee/you,
and shall apply to each such person as if he were the only named Master Franchisee in this
Agreement. 16.6.1 If Master Franchisee is a married couple, both husband and wife executing this
Agreement shall be liable for all obligations and duties of Master Franchisee under this Agreement
as if such spouse were the sole Master Franchisee under this Agreement. 16.6.2 If Master Franchisee
is a partnership or if more than one person executes this Agreement as Master Franchisee, each
partner or person executing this Agreement shall be liable for all the obligations and duties of
Master Franchisee under this Agreement. 16.6.3 If Master Franchisee is a trust, each trustee,
trustor and beneficiary signing this Agreement shall be liable for all of the obligations and duties
of Master Franchisee under this Agreement. 16.6.4 If Master Franchisee is a corporation or limited
liability company, all shareholders or members executing this Agreement shall be liable for all
obligations and duties of Master Franchisee under this Agreement as if each such shareholder or
member were the sole Master Franchisee under this Agreement. 16.6.5 If you are in breach or default
under this Agreement, we may proceed directly against each such spouse, partner, signatory to this
Agreement, shareholder, member, trustee, trustor or beneficiary without first proceeding against you
and without proceeding against or naming in such suit any other Master Franchisee, partner,
signatory to this Agreement, shareholder, member, trustee, trustor or beneficiary. The obligations
of you and each such spouse, partner, person executing this Agreement, shareholder, member, trustee,
trustor and beneficiary shall be joint and several. 34

Source: SOUPMAN, INC., 8-K, 8/14/2015
<!-- page 40 -->
16.6.6 Notice to or demand upon one spouse, partner, person signing this Agreement, shareholder,
member, trustee, trustor or beneficiary shall be deemed notice to or demand upon you and all such
spouses, partners, persons signing this Agreement, shareholders, members, trustees, trustors and
beneficiaries, and no notice or demand need be made to or upon all such Master Franchisee's spouses,
partners, persons executing this Agreement, shareholders, members, trustees, trustors or
beneficiaries. 16.6.7 The cessation of or release from liability of you, or any such spouse,
partner, person executing this Agreement, shareholder, member, trustee, trustor or beneficiary shall
not relieve any other Master Franchisee, spouse, partner, person executing this Agreement,
shareholder, member, trustee, trustor or beneficiary from liability under this Agreement, except to
the extent that the breach or default has been remedied or monies owed have been paid. 16.7
Corporation, Partnership or Limited Liability Company 16.7.1 Except as otherwise approved in writing
by us, if you are a corporation, you shall: (a) confine your activities, and your governing
documents shall at all times provide that your activities are confined, exclusively to operating the
Franchised Business; (b) maintain stop transfer instructions on your records against the transfer of
any equity securities and shall only issue securities upon the face of which a legend, in a form
satisfactory to us, appears which references the transfer restrictions imposed by this Agreement;
(c) not issue any non-voting securities convertible into voting securities; (d) maintain a Schedule
of Principals with a current list of all owners of record and all beneficial owners of any class of
voting stock of you and furnish the list to us upon request. In addition, each present and future
shareholder of yours shall jointly and severally guarantee your performance of each and every
provision of this Agreement by executing a Guarantee in the form attached to this Agreement as
Attachment B. 16.7.2 If you are a partnership you shall: (a) furnish us with your partnership
agreement as well as such other documents as we may reasonably request, and any amendments thereto;
and (b) prepare and furnish to us a Schedule of Principals with a current list of all general and
limited partners in you. In addition, each present and future general partner of yours shall jointly
and severally guarantee your performance of each and every provision of this Agreement by executing
a Guarantee in the form attached to this Agreement as Attachment B. 16.7.3 If you are a limited
liability company, you shall: (a) furnish us with a copy of your articles of organization and
operating agreement, as well as such other documents as we may reasonably request, and any
amendments thereto; (b) prepare and furnish to us a Schedule of Principals with a current list of
all members and managers in you; and (c) maintain stop transfer instructions on your records against
the transfer of equity securities and shall only issue securities upon the face of which bear a
legend, in a form satisfactory to us. In addition, each present and future member of yours shall
jointly and severally guarantee your performance of each and every provision of this Agreement by
executing a Guarantee in the form attached to this Agreement as Attachment B. 17. APPLICABLE LAW
17.1 Choice of Law This Agreement shall be interpreted and construed under the laws of the State of
New York. In the event of any conflict of law, the laws of New York shall prevail, without regard to
the application of such state's conflict of law rules. If, however, any provision of this Agreement
would not be enforceable under the laws of New York, and if the Franchised Business is located
outside of New York and such provision would be enforceable under the laws of the state in which the
Franchised Business is located, then such provision shall be interpreted and construed under the
laws of that other state. Nothing in this Section 17.1 is intended by the parties to subject this
Agreement to laws, rules, or regulation of any state to which it would not otherwise be subject. 35

Source: SOUPMAN, INC., 8-K, 8/14/2015
<!-- page 41 -->
17.2 Non-Binding Mediation 17.2.1 Franchisor and Franchisee acknowledge that during the term of this
Agreement disputes may arise between the parties that may be resolvable through mediation. To
facilitate such resolution, Franchisor and Franchisee agree that each party shall submit the dispute
between them for non-binding mediation at a mutually agreeable location before commencing litigation
proceedings If Franchisor and Franchisee cannot agree on a location, the mediation will be conducted
in Staten Island, New York. The mediation will be conducted by one (1) mediator who is appointed
under the American Arbitration Association's Commercial Mediation Rules and who shall conduct the
mediation in accordance with such rules. Franchisor and Franchisee agree that statements made by
Franchisor, Franchisee or any other party in any such mediation proceeding will not be admissible in
any other legal proceeding. Each party shall bear its own costs and expenses of conducting the
mediation and share equally the costs of any third parties who are required to participate in the
mediation . 17.2.2 If any dispute between the parties cannot be resolved through mediation within
forty-five (45) days following the appointment of the mediator, the parties agree to resolve such
dispute pursuant to litigation in the County of New York, State of New York 17.3 Venue The parties
agree that any action brought by either party against the other in any court, whether federal or
state, shall be brought within the County of New York, State of New York at the time the action is
initiated, and the parties hereby waive all questions of personal jurisdiction or venue for the
purpose of carrying out this provision. 17.4 Non-exclusivity of Remedy No right or remedy conferred
upon or reserved to us or you by this Agreement is intended to be, nor shall be deemed, exclusive of
any other right or remedy herein or by law or equity provided or permitted, but each shall be
cumulative of every other right or remedy. 17.5 Right to Injunctive Relief Nothing herein contained
shall bar the right of either party to seek and obtain temporary and permanent injunctive relief
from a court of competent jurisdiction consistent with this Section 17 in accordance with applicable
law against threatened conduct that will in all probability cause loss or damage to you or us. 17.6
Incorporation of Recitals The recitals set forth in Paragraphs A through C of this Agreement are
true and correct and are hereby incorporated by reference into the body of this Agreement. 36

Source: SOUPMAN, INC., 8-K, 8/14/2015
<!-- page 42 -->
18. SECURITY INTEREST 18.1 Collateral You grant to us a security interest ("Security Interest") in
all of the furniture, fixtures, equipment, signage, and realty (including your interests under all
real property and personal property leases) of the Franchised Business, together with all similar
property now owned or hereafter acquired, additions, substitutions, replacements, proceeds, and
products thereof, wherever located, used in connection with the Franchised Business. All items in
which a security interest is granted are referred to as the "Collateral". 18.2 Indebtedness Secured
The Security Interest is to secure payment of the following (the "Indebtedness"): 18.2.1 All amounts
due under this Agreement or otherwise by you; 18.2.2 All sums which we may, at our option, expend or
advance for the maintenance, preservation, and protection of the Collateral, including, without
limitation, payment of rent, taxes, levies, assessments, insurance premiums, and discharge of liens,
together with interest, or any other property given as security for payment of the Indebtedness;
18.2.3 All expenses, including reasonable attorneys' fees, which we incur in connection with
collecting any or all Indebtedness secured hereby or in enforcing or protecting our rights under the
Security Interest and this Agreement; and 18.2.4 All other present or future, direct or indirect,
absolute or contingent, liabilities, obligations, and indebtedness of you to us or third parties
under this Agreement, however created, and specifically including all or part of any renewal or
extension of this Agreement, whether or not you execute any extension agreement or renewal
instruments. Our security interest, as described herein, shall be subordinated to any financing
related to your operation of the Franchised Business, including, but not limited to, a real property
mortgage and equipment leases. 18.3 Additional Documents You will from time to time as required by
us join with us in executing any additional documents and one or more financing statements pursuant
to the Uniform Commercial Code (and any assignments, extensions, or modifications thereof) in form
satisfactory to us. 18.4 Possession of Collateral Upon default and termination of your rights under
this Agreement, we shall have the immediate right to possession and use of the Collateral. 18.5 Our
Remedies in Event of Default You agree that, upon the occurrence of any default set forth above, the
full amount remaining unpaid on the Indebtedness secured shall, at our option and without notice,
become due and payable immediately, and we shall then have the rights, options, duties, and remedies
of a secured party under, and you shall have the rights and duties of a debtor under, the Uniform
Commercial Code of New York (or other applicable law), including, without limitation, our right to
take possession of the Collateral and without legal process to enter any premises where the
Collateral may be found. Any sale of the Collateral may be conducted by us in a commercially
reasonable manner. Reasonable notification of the time and place of any sale shall be satisfied by
mailing to you pursuant to the notice provisions set forth above. 37

Source: SOUPMAN, INC., 8-K, 8/14/2015
<!-- page 43 -->
18.6 Special Filing as Financing Statement This Agreement shall be deemed a Security Agreement and a
Financing Statement. This Agreement may be filed for record in the real estate records of each
county in which the Collateral, or any part thereof, is situated and may also be filed as a
Financing Statement in the counties or in the office of the Secretary of State, as appropriate, in
respect of those items of Collateral of a kind or character defined in or subject to the applicable
provisions of the Uniform Commercial Code as in effect in the appropriate jurisdiction. 19.
ACKNOWLEDGMENTS 19.1 Recognition of Business Risks You acknowledge that you have conducted an
independent investigation of the proposed franchise, and recognize that the business venture
contemplated by this Agreement involves business risks and that your success will be largely
dependent upon your ability as an independent business person. We expressly disclaim the making of,
and you acknowledge that you have not received, any warranty or guarantee, express or implied, as to
the potential sales, income, profits, or success of the business venture contemplated by this
Agreement, or of other Franchised Businesses. 19.2 Receipt of Franchise Disclosure Document You
acknowledge that you have received a copy of our complete FDD for Master Franchised Businesses at
least (14) calendar days prior to the date on which this Agreement was executed or any payment was
made to us or any of our affiliates. You acknowledge and agree that we have made no promises,
representations, warranties or assurances to you which are inconsistent with the terms of this
Agreement or our FDD concerning the profitability or likelihood of success of the Franchised
Business, that you have been informed by us that there can be no guaranty of success in the
Franchised Business, and that your business ability and aptitude is primary in determining your
success. 19.3 Review of Agreement You acknowledge that you have read and understood this Agreement,
the attachments hereto, and agreements relating thereto, if any, and that we have accorded you ample
time and opportunity to consult with advisors and counsel of your own choosing about the potential
benefits and risks of entering into this Agreement. 19.4 Attorneys' Fees If we become a party to any
legal proceedings concerning this Agreement or the Franchised Business by reason of any act or
omission of you or your authorized representatives, you shall be liable to us for the reasonable
attorneys' fees and court costs incurred by us in the legal proceedings. If either party commences a
legal action against the other party arising out of or in connection with this Agreement, the
prevailing party shall be entitled to have and recover from the other party its reasonable
attorneys' fees and costs of suit. 19.5 Atypical Arrangements You acknowledge and agree that we may
modify the offer of our franchises to other franchisees in any manner and at any time, which offers
have or may have terms, conditions, and obligations which may differ from the terms, conditions, and
obligations in this Agreement. You further acknowledge and agree that we have made no warranty or
representation that all Master Franchise Agreements previously issued or issued after this Master
Franchise Agreement by us do or will contain terms substantially similar to those contained in this
Master Franchise Agreement. We may, in our reasonable business judgment and our sole and absolute
discretion, due to local business conditions or otherwise, waive or modify comparable provisions of
other Master Franchise Agreements executed before or after the date of this Master Franchise
Agreement with other Master Franchisees in a non-uniform manner. 38

Source: SOUPMAN, INC., 8-K, 8/14/2015
<!-- page 44 -->
19.6 Limitation of Adjudicative Proceedings Any and all claims and actions arising out of or
relating to this Agreement, the relationship of you and us, or your operation of the Franchised
Business, brought by any party hereto against the other, shall be commenced within two (2) years
from the occurrence of the facts giving rise to such claim or action, or such claim or action shall
be barred. 19.7 Trial by Jury WE AND YOU EACH HEREBY WAIVE OUR RESPECTIVE RIGHT TO TRIAL BY JURY OF
ANY CAUSE OF ACTION, CLAIM, COUNTERCLAIM OR CROSS-COMPLAINT IN ANY ACTION, PROCEEDING AND/OR HEARING
BROUGHT BY EITHER US OR YOU ON ANY MATTER WHATSOEVER ARISING OUT OF, OR IN ANY WAY CONNECTED WITH,
THIS AGREEMENT, THE RELATIONSHIP OF THE PARTIES, THE USE OF THE PROPRIETARY MARKS OR SYSTEM BY YOU,
OR ANY CLAIM OF INJURY OR DAMAGE, OR THE ENFORCEMENT OF ANY REMEDY UNDER ANY LAW, STATUTE,
REGULATION, EMERGENCY OR OTHERWISE, NOW OR HEREAFTER IN EFFECT, TO THE FULLEST EXTENT PERMITTED
UNDER LAW. 19.8 Punitive or Exemplary Damages We and you, and our respective directors, officers,
shareholders and guarantors, as applicable, each hereby waive to the fullest extent permitted by
law, any right to, or claim for, punitive or exemplary damages against the other and agree that, in
the event of a dispute between them, each is limited to recovering only the actual damages proven to
have been sustained by it. 19.9 Additional Documents Each of the parties agrees to execute,
acknowledge and deliver to the other party and to procure the execution, acknowledgment and delivery
to the other party of any additional documents or instruments which either party may reasonably
require to fully effectuate and carry out the provisions of this Agreement. 19.10 Counterparts This
Agreement may be executed by the parties in one or more counterparts, each of which shall be deemed
to be an original, but all of which together shall constitute one and the same instrument. 39

Source: SOUPMAN, INC., 8-K, 8/14/2015
<!-- page 45 -->
IN WITNESS WHEREOF, the parties have executed this Agreement on the date first shown above. KIOSK
CONCEPTS, INC.: By: Witness Name: Title: MASTER FRANCHISEE : THE GRILLED CHEESE TRUCK, INC. By:
Witness Name: Title: 40

Source: SOUPMAN, INC., 8-K, 8/14/2015
<!-- page 46 -->
SCHEDULE OF PRINCIPALS (Not Applicable) ANY OTHER PERSON NOT LISTED IN THIS AGREEMENT WHO IS A
SPOUSE, PARTNER, AN OFFICER, DIRECTOR, SHAREHOLDER, GENERAL PARTNER OR MEMBER OF MASTER FRANCHISEE:
Name: Address: Telephone: Relationship: Name: Address: Telephone: Relationship: Name: Address:
Telephone: Relationship: Name: Address: Telephone: Relationship: Name: Address: Telephone:
Relationship: Name: Address: Telephone: Relationship:

Source: SOUPMAN, INC., 8-K, 8/14/2015
<!-- page 47 -->
Attachment A to Master Franchise Agreement MASTER TERRITORY AND COMMENCEMENT DATE MASTER TERRITORY:
North America COMMENCEMENT DATE: Upon approval of the State of New York. KIOSK CONCEPTS, INC. MASTER
FRANCHISEE THE GRILLED CHEESE TRUCK, INC. By: By: Name: Name: Title: Title:

Source: SOUPMAN, INC., 8-K, 8/14/2015
