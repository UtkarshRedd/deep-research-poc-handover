<!-- page 1 -->
# REAL ESTATE EDUCATION TRAINING PROGRAM DEVELOPMENT AGREEMENT
| Field | Value |
|---|---|
| Document Type | Development Agreement |
| Agreement Date | 2019-12-23 |
| Parties | T&B Seminars, Inc. ("T&B"); Legacy Education Alliance Holdings, Inc. ("LEA") |
| Source | CUAD v1 / LegacyEducationAllianceInc_20200330_10-K_EX-10.18_12090678_EX-10.18_Development Agreement |

Exhibit 10.18 Certain identified information has been excluded from this exhibit because it is both
(i) not material and (ii) would be competitively harmful if publicly disclosed. REAL ESTATE
EDUCATION TRAINING PROGRAM DEVELOPMENT AGREEMENT This Real Estate Education Training Program
Development Agreement (this "Agreement") by and between T&B Seminars, Inc., a California corporation
f/s/o Tarek El Moussa ("T&B") and Legacy Education Alliance Holdings, Inc., a Colorado corporation
("LEA"), is entered into as of 12-23-2019 , 2019 (the "Effective Date"). WHEREAS, LEA is in the
business of marketing, sales and distribution (including e-distribution) of any in-person product or
service offerings in real estate investing strategies and techniques, asset protection, and
entrepreneurship in any form of communication or media to one or more recipients, including, but not
limited to, workshops, seminars, webinars, coaching, and mentorships, and related product or
services; WHEREAS, T&B owns or has the right to license certain intellectual property associated
with Tarek El Moussa: WHEREAS, T&B and LEA wish to conduct business to develop and operate a
"Tarek's Real Estate 101" branded seminar style education business that uses, among other things,
the names, images, and likenesses of Tarek El Moussa to market and sell customers real estate
investing oriented education products. NOW, THEREFORE, in consideration of the mutual covenants and
promises herein contained, the parties hereby agree as follows: 1. Definitions. Capitalized words
and phrases used in this Agreement that are not otherwise defined herein shall have the meanings set
forth below: 1.2. The term "Affiliate" means an entity controlling, controlled, or under common
control with a party. For these purposes, "control" means: (a) the possession, directly or
indirectly, of the power to direct the management or policies of an entity, whether through the
ownership of voting securities, by contract or otherwise; or (b) the ownership, directly or
indirectly, of at least fifty percent (50%) of the voting securities or other ownership interest of
an entity. 1.2. The term "Business" means a branded real estate seminar style education business
that uses the Licensed Intellectual Property, including a to-be-determined trademark for the
Business, to market and sell customers Products through any form of communication or media. 1.3 The
term "Cash Sales" shall mean the gross cash proceeds actually received by LEA or T&B from the sale
of Products to persons responding to a Business-branded marketing campaign conducted by LEA that
uses any or any combination of Licensed Intellectual Property. Cash Sales shall exclude any merchant
fees, taxes, shipping, refunds (e.g., returns, right of rescission, NSF checks, and credit card
chargebacks), rebates, and bad debt

1

Source: LEGACY EDUCATION ALLIANCE, INC., 10-K, 3/30/2020
<!-- page 2 -->
Certain identified information has been excluded from this exhibit because it is both (i) not
material and (ii) would be competitively harmful if publicly disclosed. 1.4. The term "Confidential
Information" means any and all information which is not readily ascertainable by proper means and
which derives economic value, actual or potential from not being generally known and which has been
the subject of efforts that are reasonable under the circumstances to maintain its secrecy. All
information relating to the products or operations of a party, which is provided to the other party,
or to which the other party otherwise obtains access, pursuant to, or as a result of, this Agreement
shall be treated as Confidential Information hereunder, except such information which the other
party can clearly show: (a) at the time of this Agreement is publicly and openly known; (b) after
the date of this Agreement becomes publicly and openly known through no fault of the other party;
(c) comes into the other party's possession and lawfully obtained by the other party from a source
other than from the party or a source deriving from the party, and not subject to any obligation of
confidentiality or restrictions on use; or (d) is approved for release by written authorization of
the other party 1.5 The term "Customer Data" means documents and other media (whether in human or
machine-readable form) containing information, regarding customers and prospective customers.
Without limiting the generality of the foregoing, the term "Customer Data" shall include customer
lists and personally identifiable information about customers and prospective customers. 1.6 The
term "Educational Materials" means all advertising and promotional materials, handouts, workbooks,
presentations, manuals, software programs, and any other literature or material and other collateral
items employed, provided, distributed, sold, or otherwise made available in connection with the
Business, in any form of communication or media and whether or not in machine or human readable
format. 1.7 The term "Exclusive Field of Use" means the marketing, sale and distribution (including
e-distribution) of any in-person or remote (e.g., livestream of a live event, recording of a live
event, and/or on-demand) service offerings in real estate investing strategies and techniques, asset
protection, product and entrepreneurship in any form of communication or media to one or more
recipients, including, but not limited to, workshops, seminars, webinars, coaching, and mentorships,
and related product or services. 1.8. The term "Licensed Intellectual Property" means individually,
collectively or in any combination, T&B's copyrights (whether registered or not), including, without
limitation, the Educational Materials and any and all copyrightable literary works and audio-visual
works developed for use in the Business, trademarks and trade names (whether registered or
unregistered) used in connection with the Business; as well as customer lists, concepts,
developments, trade secrets, methods, systems, programs, improvements, data and information (whether
in perceivable or machine-readable form), and works of authorship including, but not limited to the
(a) the Licensed Marks and (b) the name, image, and likeness of the T&B Personality. 1.9. The term
"Licensed Marks" The term "Licensed Marks" shall mean T&B's current and future trademarks, service
marks, and trade dress used in connection with the Business.

2

Source: LEGACY EDUCATION ALLIANCE, INC., 10-K, 3/30/2020
<!-- page 3 -->
Certain identified information has been excluded from this exhibit because it is both (i) not
material and (ii) would be competitively harmful if publicly disclosed. 1.10. The term "Products"
shall mean any in-person remote (e.g., livestream of a live event, recording of a live event, and
on-demand) product or service offerings in real estate investing strategies and techniques, asset
protection, and entrepreneurship in any form of communication or media to one or more recipients,
including, but not limited to, workshops, seminars, webinars, coaching, and mentorships, as may be
offered by LEA in the conduct of the Business and for which a fee is charged by LEA. 1.11. The term
"T&B Personality" shall mean Tarek El Moussa. 1.12 The term "Term" shall mean an initial term of
five years, automatically renewable thereafter for successive 5-year terms unless either party
provides prior written notice of termination not less than 90 days prior to the end of such
five-year term; provided, however, T&B shall have the right to terminate the license after the first
year of the Term if LEA does not conduct the Business so as to meet the Cash Sales benchmarks set by
the parties for years two through five of the Term, as set forth in Section 3.3, below. 2. Grant of
License. 2.1 T&B hereby grants to LEA, and LEA hereby accepts from T&B, during the Term, the sole
and exclusive worldwide right and license in and to the Licensed Intellectual Property, which right
and license shall be limited to that which is necessary for LEA to (i) develop and create
Educational Materials and (ii) develop, promote and conduct the Business worldwide , unless the
license is earlier terminated as provided herein. 2.2 LEA has the right to modify the Licensed
Intellectual Property and to create derivative works (the "Derivative Works"); provided that such
Derivative Works may be used, copied, distributed, performed and/or displayed only in connection
with the Business; and provided further that LEA will not distribute Products embodying the
Derivative Works other than to end users for personal use only in connection with the Business, and
not for sale, distribution or re-licensing by such end users. For the avoidance of doubt, T&B shall
remain the owner of all right, title and interest in and to the Derivative Works from inception. 2.3
T&B and LEA shall promptly notify one another in writing of any alleged infringement of the Licensed
Intellectual Property by a third party. Within fifteen (15) days of the receipt of such notice or
such other period as may be agreed to by the parties, T&B and LEA shall meet and confer to formulate
a strategy for resolving the alleged infringement. T&B and LEA (to the extent permitted by law) each
shall have the right to institute an action against such third party based upon such infringement of
the Licensed Intellectual Property. 2.4 Should either T&B or LEA commence a suit under the
provisions of this Section 15, and thereafter elect to abandon the same, it shall give timely notice
of the other party who may, if it so desires, continue to prosecute such suit. 2.5 T&B and LEA shall
cooperate in any legal proceeding concerning an alleged infringement of the Licensed Intellectual
Property. Each party shall, to the fullest extent reasonable, make its employees, records, and
information available to the other party as relevant to the legal process.

3

Source: LEGACY EDUCATION ALLIANCE, INC., 10-K, 3/30/2020
<!-- page 4 -->
Certain identified information has been excluded from this exhibit because it is both (i) not
material and (ii) would be competitively harmful if publicly disclosed. 3. Limitations, Restrictions
and Covenants 3.1. During the Term, the LEA shall not use the Licensed Intellectual Property other
than as permitted by this Agreement. 3.2. During the Term, T&B shall promptly disclose to LEA on an
ongoing basis all additions, improvements, changes, replacements, or enhancements to T&B's
Proprietary Rights not previously disclosed. 3.3 T&B shall not, during the Term, grant any third
party a license to use the Licensed Intellectual Property within the Exclusive Field of Use.
Further, during the Term, except as otherwise provided herein, neither T&B nor any of its Affiliates
may (1) offer to sell or sell any product or service that is the same or similar to the Products in
the Exclusive Field of Use, or (2) contact, solicit, or direct any person or entity to contact or
solicit, any of the customers of (or customers set forth in the Customer Data) for the purpose of
providing any products or services that are the same or similar to the Products; provided, however,
that T&B, in its sole and absolute discretion, shall have the right to terminate this Agreement,
including all rights and licenses granted to LEA herein, if and as of the date that any monthly
Royalty Payment (as defined in 9.3, below) payable to T&B does not exceed the Minimum Guaranteed
Royalty for six (6) consecutive months. 3.4. LEA may distribute goods and services embodying the
Licensed Intellectual Property to end users for personal use only in connect with the Business, and
for resale, distribution or re-licensing by such end users. 3.5 LEA acknowledges and agrees that,
except as otherwise specifically provided for herein, this Agreement grants LEA no title or right of
ownership in or to the Licensed Intellectual Property. LEA shall not at any time do or cause to be
done any act, omission, or thing contesting or in any way impairing or tending to impair any part of
T&B's right, title and interest in the Licensed Intellectual Property. 3.6 In the event LEA shall be
deemed to have acquired any ownership rights in the Licensed Intellectual Property, the LEA shall
assign, and agrees to execute all documents reasonably requested by T&B to assign, all such rights
in the Licensed Intellectual Property to T&B or its nominee. 4. Conduct of the Business 4.1 LEA
shall provide administrative and operational services for the conduct of the Business, including,
marketing, event planning, sales, operations, information technologies, human resources, and class
fulfillment. In consultation with T&B and subject to the licenses granted to LEA by T&B herein, LEA
shall be responsible for branding the Business (including trademarks and trade dress) and creating
and producing marketing collateral, sales presentations, course materials and other tangible work
product and deliverables related to the conduct of the Business (collectively, "Work Product").

4

Source: LEGACY EDUCATION ALLIANCE, INC., 10-K, 3/30/2020
<!-- page 5 -->
Certain identified information has been excluded from this exhibit because it is both (i) not
material and (ii) would be competitively harmful if publicly disclosed. 4.2 LEA and T&B shall
jointly own all jointly-created work product including, but not limited to, ideas, any and all
concepts, designs, Customer Data (including client lists) generated through the conduct of the
Business, programs, software, reports, or other intellectual property and tangible work product,
produced for the Business , regardless of whether such were incorporated into or used by the
Business (collectively "Work Product"), shall be and remain the joint property of LEA and T&B when
produced provided, however, (i) to the extent LEA has contributed distinct and divisible work
product to the Business during the Term ("LEA Work Product"), such LEA Work Product shall remain
frozen for a period not to exceed 90 days, during which time T&B may acquire a license for the LEA
Work Product by reimbursing LEA direct and verifiable costs LEA incurred in producing the LEA Work
Product during the Term and (ii) to the extent T&B has contributed distinct and divisible work
product to the Business during the Term ("T&B Work Product"), such T&B Work Product shall remain
frozen for a period not to exceed 90 days, during which time LEA may acquire license for the T&B
Work Product by reimbursing T&B direct and verifiable costs T&B incurred in producing the T&B Work
Product during the Term. No license or right is granted hereunder at any time from LEA to T&B, or by
T&B to LEA, whether expressly or by implication, estoppel or otherwise, arising out of or related to
LEA Work Product or T&B Work Product, respectively. LEA shall be the owner of all LEA Work Product
when created and T&B shall be the owner of all T&B Work Product when created. 5. Brand Development
and Launch 5.1 T&B shall assist LEA in developing the Business as reasonably requested by LEA from
time to time, including, but not limited to, assisting in the development of sales presentations and
course materials and consultation with LEA's sales and marketing organization to ensure that they
reflect T&B Personality's investing philosophy. T&B shall provide factual substantiation of T&B
Personality's biography and investing success stories provided by T&B for use by LEA in the conduct
of the Business. 5.2 The initial launch of the Business is contemplated to occur in four (4) major
test markets (e.g. Los Angeles and New York MSAs), with a preview event being conducted in each of
weeks 4, 5, 6 and 7 of calendar year 2020 and the associated basic event being held in each of weeks
7, 8, 9, and 10, respectively. To facilitate the effective launch of the Business, T&B shall assist
LEA by providing the items listed in Schedule 1 attached to this Agreement and incorporated herein
by reference. 6. Personal Appearances 6.1 T&B Personality shall make six (6) public appearances each
year of the Term, including an appearance at LEA's annual Hall of Fame Symposium, for the purpose of
promoting the Business, which appearances may include autograph sessions, book signings, appearances
at LEA's workshops, seminars and symposiums with each such session not to exceed four (4) hours. LEA
shall compensate T&B Personality the sum of [$●] plus first-class air and hotel accommodations for
up to three (3) additional persons for each such appearance.

5

Source: LEGACY EDUCATION ALLIANCE, INC., 10-K, 3/30/2020
<!-- page 6 -->
Certain identified information has been excluded from this exhibit because it is both (i) not
material and (ii) would be competitively harmful if publicly disclosed. 6.2 The parties may also
conduct up to 10 "big stage" live events each year to market Products. LEA may request T&B
Personality to appear at such events for not more than eight (8) hours each, subject to T&B
Personality's availability. LEA shall compensate T&B Personality the sum of [$●] plus first-class
air and hotel accommodations for up to three (3) additional persons for each such appearance. 7. New
Product Development 7.1 Co-Developed Products. T&B and LEA shall meet and confer no less than
quarterly to identify new Tarek's Real Estate 101 Product development, marketing and fulfillment
initiatives, including, by way of example only, (i) mobile apps that provide investor resources and
property evaluations, (ii) podcasts with T&B Personality that provide content to keep up to date
with investing techniques and motivation, and (iii) tailored coaching programs and subscription
services. The parties acknowledge that the development and fulfillment of such new Products may
require substantial time and effort by the T&B Personality to fulfill such new Products such that
the Marketing Royalty payable pursuant to V. B., above, is inadequate to compensate T&B Personality;
therefore, in lieu of any other royalty, the parties shall share Cash Sales from the sale of such
new Products as follows: [●%] to LEA [●%] to T&B 7.2 T&B Developed Products. In addition, T&B may
independently develop Products to be marketed and sold by T&B and fulfilled by T&B. In lieu of any
other royalty, the parties shall share Cash Sales from the sale of such independently developed T&B
Products that are generated directly and independently by LEA as follows: [●%] to LEA [●%] to T&B 8.
Confidentiality 8.1. Each party acknowledges the other's Confidential Information is unique and
valuable and was developed or otherwise acquired by the other at great expense, and that any
unauthorized disclosure or use of the other's Confidential Information would cause the other
irreparable injury loss for which damages would be an inadequate remedy. The party agrees to hold
such Confidential Information in strictest confidence, to use all efforts reasonable under the
circumstances to maintain the secrecy thereof, and not to make use thereof other than in accordance
with this Agreement, and not to release or disclose Confidential Information to any third party
without the other's prior written consent, subject to a court order, or subject to a sublicense
consistent with this Agreement and requiring the sublicensee to maintain the Confidential
Information in strictest confidence, to use all efforts reasonable under the circumstances to
maintain the secrecy thereof, not to make use thereof other than in accordance with the sublicense
Agreement, and not to release or disclose Confidential Information to any third party without the
other's prior written consent.

6

Source: LEGACY EDUCATION ALLIANCE, INC., 10-K, 3/30/2020
<!-- page 7 -->
Certain identified information has been excluded from this exhibit because it is both (i) not
material and (ii) would be competitively harmful if publicly disclosed. 8.2. Each party further
acknowledges that any violation of this Section 5 shall constitute a material breach of this License
Agreement resulting in irreparable injury to the non-breaching party and agree that, in addition to
any and all other rights available to the non-breathing party by law or by this Agreement, the
non-breaching party shall have the right to have an injunction entered against the party to enjoin
any further violations of this Agreement. 9. Royalties and Reporting 9.1. In consideration of the
rights to be granted by T&B to LEA, LEA agrees to pay T&B: 9.1.1 Base Royalty. In consideration of
the License granted and other good and valuable consideration provided by T&B to LEA, LEA shall pay
to T&B a base royalty ("Base Royalty") in the amount of [●%] of LEA's monthly Cash Sales for Cash
Sales of up to [$●]. For monthly Cash Sales above [$●] and up to [$●] , the Base Royalty paid to T&B
by LEA shall be [●%]of the LEA's Cash Sales. For monthly Cash Sales above [$●] and up to [$●] the
Base Royalty paid to T&B by LEA shall be [●%] of the LEA's Cash Sales. For monthly Cash Sales above
[$●] and up to [$●], the Base Royalty paid to T&B by LEA shall be [●%] of the LEA's Cash Sales. For
monthly Cash Sales above [$●]the Base Royalty paid to T&B by LEA shall be [●%] of the LEA's Cash
Sales. Payments will be made in U.S. Dollars. 9.1.2 Marketing Royalty: Marketing Royalty: In
consideration of T&B Personality providing commercially reasonable, regular and periodic marketing
support to LEA substantially in accordance with Schedule 2 attached to this Agreement and
incorporated herein by reference, which LEA agrees to request and accept from T&B consistently
during the Term, LEA will pay T&M a royalty in addition to the Base Royalty ("Marketing Royalty")
which shall be comprised of and calculated at [●%] of LEA's Cash Sales made from the sale of
Products at live events and [●%] of LEA's Cash Sales made from the sale of Products at on-line
webinars. For the avoidance of doubt, the Base Royalty and Marketing Royalty shall be cumulative and
calculated independently, without overlap. Further, nothing herein shall be construed to enable LEA
to refuse to accept reasonable, regular and periodic marketing support from T&B as a means to avoid
paying T&B a Marketing Royalty. In the event, T&B offers, but LEA refuses to request or accept
reasonable, regular and periodic marketing support from T&B during the Term, LEA shall continue to
be obligated to pay T&B a Marketing Royalty as if such marketing support had been requested and
accepted by LEA. 9.2 Minimum Guaranteed Royalty: In consideration of the exclusivity rights granted
to LEA, commencing with the seventh (7t h) month of the Term and continuing each year of the Term
thereafter, the minimum Royalties payable to T&B each month shall be the greater of the (i)
applicable monthly Base Royalty and Marketing Royalty or (ii) $200,000. 9.3 Base Royalties and
Marketing Royalties shall be paid monthly to T&M within 15 days after the end of the applicable
month. Payments will be made in U.S. Dollars.

7

Source: LEGACY EDUCATION ALLIANCE, INC., 10-K, 3/30/2020
<!-- page 8 -->
Certain identified information has been excluded from this exhibit because it is both (i) not
material and (ii) would be competitively harmful if publicly disclosed. 9.4. For each Base Royalty
and Marketing Royalty payment (collectively, "Royalty Payment"), LEA shall render to T&B, a written
statement, in such form as T&B may reasonably request, setting forth Cash Sales made during the
period to which the Royalty Payment relates, and such other information as T&B may reasonably
request to verify the Royalty Payments due hereunder. LEA shall keep such written records respecting
Cash Sales as T&B may reasonably request so that Royalty Payments payable hereunder may be
accurately determined and shall permit such records to be examined by T&B or its authorized
representative upon reasonable prior written notice at any reasonable time during regular business
hours to verify the records, reports and payments herein provided. 9.5. LEA shall be responsible
for, and shall pay, all sales, value added and similar taxes, if any, which may be imposed on any
receipts of the Trainings sold hereunder, as well as any other tax based upon LEA's use of the
Licensed Intellectual Property in connection with the Business. 9.6 T&B ACKNOWLEDGES AND AGREES THAT
NO REPRESENTATIONS OR STATEMENTS OF ACTUAL, AVERAGE, PROJECTED OR FORECASTED SALES, PROFITS,
ROYALTIES, OR EARNINGS HAVE BEEN MADE WITH RESPECT TO THE BUSINESS CONTEMPLATED BY THIS AGREEMENT.
10. Warranties and Representations. 10.1 T&B warrants and represents that: 10.1.1 It is a
corporation duly organized, validly existing, and in good standing under the laws of the state of
California with all requisite power and authority to execute, deliver and perform this Agreement.
10.1.2 All necessary actions on the part of T&B have been duly taken to authorize the execution,
delivery, and performance of the Agreement by T&B. 10.1.3 This Agreement has been duly authorized,
executed, and delivered by T&B, constitutes the legal, valid, and binding obligation of T&B and is
enforceable in accordance with its terms. 10.1.4 It has the right to grant the licenses and enter
into this Agreement without seeking the approval or consent of any third party and without payments
to any third party. 10.1.5 There are no existing or threatened claims or proceedings by any entity
relating to the Licensed Intellectual Property or challenging T&B's ownership of the same. 10.1.6
None of the Licensed Intellectual Property are subject to any outstanding order, decree, judgment,
stipulation, written restriction, undertaking or agreement limiting the scope or use of the Licensed
Intellectual Property or declaring any of it abandoned.

8

Source: LEGACY EDUCATION ALLIANCE, INC., 10-K, 3/30/2020
<!-- page 9 -->
Certain identified information has been excluded from this exhibit because it is both (i) not
material and (ii) would be competitively harmful if publicly disclosed. 10.1.7 Licensed Intellectual
Property, or any portion thereof, does not interfere with, infringe, or misappropriate, or violate
the intellectual property right of any third party and T&B has not received any charge, complaint,
claim, or notice alleging any such interference, infringement, misappropriation or violation nor
does T&B have any knowledge that any such charge or claim may be forthcoming. 10.1.8 Any trade
secrets comprising part of the Licensed Intellectual Property have been properly maintained as trade
secrets. 10.2 LEA warrants and represents that: 10.2.1 It is a corporation duly organized, validly
existing, and in good standing under the laws of the state of Colorado, with all requisite corporate
power and authority to execute, deliver and perform this Agreement. 10.2.2 All necessary corporate
proceedings of LEA have been duly taken to authorize the execution, delivery, and performance of the
Agreement by LEA.] 10.2.3 This Agreement has been duly authorized, executed, and delivered by LEA,
constitutes the legal, valid, and binding obligation of LEA and is enforceable in accordance with
its terms. 10.2.4 This Agreement has been duly authorized, executed, and delivered by LEA,
constitutes the legal, valid, and binding obligation of LEA and is enforceable in accordance with
its terms. 10.2.5 There are no existing or threatened claims or proceedings by any entity against
LEA that would impair LEA's ability to perform under this agreement. 10.2.6 That LEA will not
contract with Christina Anstead during the Term. 11. Term and Termination. 11.1 The Term shall
commence upon the Effective Date and shall continue for an initial term of five (5) years. The Term
shall automatically renew thereafter for successive 5-year terms unless either party provides prior
written notice of termination not less than 90 days prior to the end of such five-year term. 11.2
The Agreement may be terminated: (i) immediately by either party in the event of a breach of this
Agreement by the other party that is susceptible of cure and such breach is not cured within the
30-day period after written notice of such breach to the breaching party. (ii) by either party,
immediately, if the other party becomes insolvent, makes an assignment for the benefit of its
creditors, or becomes the subject of any bankruptcy or insolvency proceedings, and such proceedings
are not vacated within sixty (60) days of their initiation.

9

Source: LEGACY EDUCATION ALLIANCE, INC., 10-K, 3/30/2020
<!-- page 10 -->
Certain identified information has been excluded from this exhibit because it is both (i) not
material and (ii) would be competitively harmful if publicly disclosed. (iii) by either party, if
the other party ceases to do business. (iv) by LEA, immediately, in the event LEA is enjoined by a
court of competent jurisdiction from using any of the Licensed Intellectual Property. (v) by LEA if
the T&B Personality engages in illegal, immoral, or criminal conduct resulting in a felony
conviction; or misrepresents or conceals anything in his or her background that could be detrimental
to the value of the endorsement being made. 11.3 Upon termination of the license hereunder, all
rights and privileges in and to the Licensed Intellectual Property granted to the LEA herein shall
automatically revert to T&B or its nominee, and the LEA shall immediately cease any use thereof.
11.4. LEA shall, for a period of six (6) months ("Sell-Off Period") following the effective date of
termination of the license granted by T&B hereunder, have the right to fulfill commitments made to
customers during the Term. The provisions of this Agreement shall apply with full force and effect
during the Sell-Off Period. Upon expiration of the Sell-Off Period, LEA shall immediately cease and
desist from using or displaying any forms of advertising containing any of the Licensed Marks. 11.5
Sections 4.2; 8 (Confidentiality); 10 (Warranties and Representations); 12 (Indemnification); and 14
(Miscellaneous) hereof shall survive the expiration or early termination (for any reason) of this
Agreement. 12. Indemnification. 12.1 Each party shall defend, indemnify and hold harmless the other
party and their respective Affiliates and their respective officers, directors, agents, contractors,
employees, successor, and assigns from and against all claims, demands or causes of action, as well
as any and all damages, expenses, costs, interest and reasonable legal fees, including such fees
incurred on appeal, in any way related to, arising out of or connected with a breach of the
indemnifying party's representations, warranties or covenants under this Agreement. Without limiting
the generality of the foregoing, LEA shall defend, hold harmless and indemnify T&B and T&B's agents
and employees from and against any and all claims, demands, losses, disputes, causes of action or
damages, including, without limitation, FTC actions or other regulatory actions, and/or attorneys'
fees arising out of or relating to the promotion, distribution and/or sale of any financial
education programs, products or services, including (but not limited to) live presentations, print
advertising, radio advertising, direct mail, outbound calls, email marketing, affiliate marketing,
online advertising, infomercials and other marketing methods, by or through LEA, In any instance to
which such indemnities pertain, LEA shall obtain and maintain necessary insurance, including,
without limitation, Commercial General Liability Insurance, including product liability insurance,
trademark infringement, copyright infringement, defamation, contractual liability and personal and
advertising injury liability insurance in an amount no less than ten million dollars
($10,000,000.00) per occurrence and ten million dollars ($10,000,000.00) aggregate combined single
limit. T&B and Tarek El Moussa shall be named as an additional insured on such insurance and proof
of such inclusion shall be provided to T&B.

10

Source: LEGACY EDUCATION ALLIANCE, INC., 10-K, 3/30/2020
<!-- page 11 -->
Certain identified information has been excluded from this exhibit because it is both (i) not
material and (ii) would be competitively harmful if publicly disclosed. 12.2. EXCEPT FOR AMOUNTS
PAYABLE TO THIRD PARTIES IN CONNECTION WITH CLAIMS SUBJECT TO THE INDEMNIFICATION PROVISIONS OF
SECTION 9.1 OR A BREACH OF EITHER PARTY'S OBLIGATIONS UNDER SECTION 5 (CONFIDENTIALITY), NEITHER
PARTY WILL, UNDER ANY CIRCUMSTANCES, BE LIABLE TO THE OTHER PARTY FOR ANY LOST PROFITS OR ANY OTHER
SPECIAL, INDIRECT OR CONSEQUENTIAL DAMAGES ARISING OUT OF OR RELATING TO THIS AGREEMENT EVEN IF THE
PARTY HAS BEEN NOTIFIED OF THE POSSIBILITY OF SUCH DAMAGES. 13. Independent Development. Nothing in
this Agreement shall be construed as restricting LEA's right or ability to acquire, license,
develop, manufacture or distribute for itself, or have others acquire, license, develop, manufacture
or distribute for LEA, adult education products and services, or technology performing the same or
similar functions as the adult education products and services, or technology contemplated by this
Agreement, or to market or distribute such same or similar adult education products and services, or
technology in addition to, or in lieu of, the adult education products and services, or technology
contemplated by this Agreement including, whether in the conduct of the Business or otherwise. 14.
Miscellaneous. 14.1 Waiver. The failure of either party at any time or times to demand strict
performance by the other party of any of the terms, covenants or conditions set forth herein shall
not be construed as a continuing waiver or relinquishment thereof, and either party may at any time
demand strict and complete performance by the other party of said terms, covenants and conditions.
14.2 Notices. All notices and other written communications required to be given under this Agreement
shall be in writing and shall be delivered to the addressee in person, mailed by registered or
certified mail, return receipt requested, or by reputable overnight courier. Any such notice shall
be deemed to be delivered, given and received for all purposes as of the date so delivered, if
delivered personally, or, if sent by certified or registered mail, three days following the date on
which the same was deposited in a regularly maintained receptacle for the deposit of United States
mail, postage and charges prepaid. The addresses of the parties (until written notice of change
shall have been given) shall be as follows: To T&B T & B Seminars, Inc. 4411 East La Palma Avenue
Anaheim, CA 92807 With a copy to: Roger N. Behle, Jr., Esq. FOLEY BEZEK BEHLE & CURTIS, LLP 575
Anton Boulevard, Suite 710 Costa Mesa, CA 92626 To LEA: Legacy Education Alliance Holdings, Inc.
1612 E. Cape Coral Parkway Cape Coral, FL 33904 Attn: VP/Operations With a copy to: Legacy Education
Alliance Holdings, Inc. 1612 E. Cape Coral Parkway Cape Coral, FL 33904 Attn: General Counsel

11

Source: LEGACY EDUCATION ALLIANCE, INC., 10-K, 3/30/2020
<!-- page 12 -->
Certain identified information has been excluded from this exhibit because it is both (i) not
material and (ii) would be competitively harmful if publicly disclosed. 14.3 Binding Effect. This
Agreement shall be binding upon and inure to the benefit of the parties hereto and their respective
successors and permitted assigns. 14.4 Further Documents. The parties agree to execute and deliver
all such further documents, agreements and instruments and take such other and further action as may
be necessary or appropriate to carry out the purposes and intent of this Agreement. 14.5 Entire
Agreement. This Agreement, along with any attachments, exhibits, schedules and documents
specifically referenced herein, constitutes the entire agreement between the parties hereto with
respect to the subject matter hereof and supersedes all prior communications, writings and other
documents with regard thereto. No modification, amendment or waiver of any provision hereof shall be
binding upon either party hereto unless it is in writing and executed by both of the parties hereto
or, in the case of a waiver, by the party waiving compliance. 14.6 Relationship of the Parties.
Nothing contained in this Agreement shall be deemed or construed by the parties hereto or by any
third person to create the relationship of principal and agent or of partnership or of joint venture
or of any association between the parties. None of the provisions contained in this Agreement nor
any acts of the parties hereto shall be deemed to create any relationship between the parties other
than the relationship specified in this Agreement. 14.7 Severability. In the event any provision of
this Agreement or the application of any provision shall be held by a tribunal of competent
jurisdiction to be contrary to law, then, the remaining provisions of this Agreement shall be
unimpaired, and the illegal, invalid or unenforceable provision shall be replaced by a provision,
which, being legal, valid and enforceable, comes closest to the intent of the parties underlying the
illegal, invalid or unenforceable provision. In any event, an illegal, invalid or unenforceable
provision shall not affect the enforceability or the validity of the remaining terms or portions
thereof, and each such unenforceable or invalid provision or portion thereof shall be severable from
the remainder of this Agreement. 14.8 Cost of Enforcement. If a party commences any action at law or
in equity, or for declaratory relief to secure or protect any rights under, or to enforce any
provision of, this Agreement, then, in addition to any judgment, order, or other relief obtained in
such proceedings, the prevailing party shall be entitled to recover from the losing party all
reasonable costs, expenses, and attorneys' fees incurred by the party in connection with such
proceedings, including, attorneys' fees incurred for consultation and other legal services performed
prior to the filing of such proceeding.

12

Source: LEGACY EDUCATION ALLIANCE, INC., 10-K, 3/30/2020
<!-- page 13 -->
Certain identified information has been excluded from this exhibit because it is both (i) not
material and (ii) would be competitively harmful if publicly disclosed. 14.9 No Assignment. Neither
party may assign this Agreement without the other party's prior written consent. Notwithstanding the
foregoing, either party may assign this Agreement without the other party's prior written consent in
the event of a merger, acquisition, reorganization, change in control, or sale of substantially all
of the assets or business of such assigning party. Any assignment in conflict with this provision
shall be void. 14.10 Governing Law. This Agreement will be governed by and construed in accordance
with the laws of the State of New York without regard to its provisions concerning the applicability
of the laws of other jurisdictions, and specifically excluding the United Nations Convention on the
International Sale of Goods. 14.11. Force Majeure. To the extent any event beyond the control of
either party (such as an act of God, action of the elements, man-made or natural disaster, industry
or supplier strike or other labor disturbance, or civil or military disturbance) shall prevent such
party from performing any of its duties or obligations hereunder by the date provided or to be
provided, the time for such performance shall be deemed extended for a period of time equivalent to
the duration of such event; provided, however, that the party so prevented from performing must give
prompt written notice to the other party of the nature of such event, the date when such event shall
have taken place, and the date when the duration of such event shall have terminated; and further
provided, however, that if performance shall be so prevented for a period of more than six months,
the other party may terminate this Agreement by written notice of such termination, and thereafter
neither party hereto shall be under any further liability or obligation to the other hereunder. IN
WITNESS WHEREOF, the parties hereto have executed this Agreement as of the date and year written
above. Legacy Education Alliance Holdings, Inc. T&B Seminars, Inc. By: /s/ James E. May By: /s/
Tarek El Moussa Name:James E. May Name:Tarek El Moussa Title: Chief Executive Officer Title: Owner

13

Source: LEGACY EDUCATION ALLIANCE, INC., 10-K, 3/30/2020
<!-- page 14 -->
Certain identified information has been excluded from this exhibit because it is both (i) not
material and (ii) would be competitively harmful if publicly disclosed. Inducement As a material
inducement for Legacy Education Alliance Holdings, Inc. . ("LEA") to enter into the above Real
Estate Education Training Program Development Agreement (the "Agreement") with T&B Seminars, Inc.
("T&B"), I hereby represent, warrant, and agree as follows: 1. I have entered into an agreement with
T&B requiring me to render services to T&B for at least the full term of the term of the Agreement
and authorizing T&B to enter into the Agreement and to furnish my rights and services to LEA upon
the terms, covenants, and conditions contained in the Agreement. 2. I am familiar with the terms,
covenants, and conditions of the Agreement. I hereby consent to the terms and conditions of, and
agree to perform all of the duties, obligations and services required of T&B Personality under the
Agreement as if I had executed it directly as an individual. 3. I hereby confirm that T&B has been
granted all of the rights granted by T&B to LEA under the Agreement and I hereby join in and confirm
all grants, representations, warranties and agreements made by T&B under the Agreement. /s/ Tarek El
Moussa Tarek El Moussa, an individual Date: 12-23-2019

14

Source: LEGACY EDUCATION ALLIANCE, INC., 10-K, 3/30/2020
<!-- page 15 -->
Certain identified information has been excluded from this exhibit because it is both (i) not
material and (ii) would be competitively harmful if publicly disclosed. Schedule 1 Brand Development
and Launch To facilitate the effective launch of the Business, T&B shall assist LEA by providing the
following: o Approved Images § Minimum 5 Hero image/poses (studio or in the field) of Tarek · Full
length, 3/4 or straight, waist up and/or chest up o Hi-resolution: 8"x10" or 5"x 7" 300 dpi
flattened file § File Format: .jpg, .psd, .tiff, .png. o Approved Videos § Minimum 3 Live Workshop
Promotion · 1 30 second clip · 1 60 second clip · 1 3-minute video § Minimum 3 Online Workshop
Promotion by topic · 1 30 second clip · 1 60 second clip · 1 3-minute video § Minimum 5
Nurturing/Event Reminder- Live and Online (10) · 1 Thank you for registering · 1 Workshop reminder/
content · 1 Motivational- Why/Purpose · 1 Call to action- Show up. Take action by doing. o What
they'll learn/expectations · 1 Thank you for pursing education- post event § Video resolutions,
formats and frame rates: (This also applies to future video specs) o 4K (3940x2160) o HDV
(1440x1080) o HD (1920x1080) o HD (1280x720 minimum) · Containers/Format: o .MP4 (H.264, MPEG-4 Part
2, MPEG-2, MPEG-1) o .Mpg ( MPEG-1 part 1) o .AVI o .MTS (AVCHD) o .MOV § QuickTime Format: Cinepak,
DV-NTSC, H.261, H.263, mpeg-4, Sorenson o NTSC preferred

15

Source: LEGACY EDUCATION ALLIANCE, INC., 10-K, 3/30/2020
<!-- page 16 -->
Certain identified information has been excluded from this exhibit because it is both (i) not
material and (ii) would be competitively harmful if publicly disclosed. · Frame Rate: o 24, 29.970,
50, 59.94 · All modern Phone Video is accepted above 720p resolution (Landscape mode preferred) o
Approved Audio Recording Phrases § Save your Seat § Don't miss out on this event § Personal quotes
or phrases o Approved Copy § Personal Story § 10 Motivational Quotes § Call to Action ·
Registration- Landing Page, Emails, Text and Mail · Attendance- Increase Attendance · Buyer- Next
Steps · Motivation · Investing Content- Strategies & Designs · Copy of handwritten signature

16

Source: LEGACY EDUCATION ALLIANCE, INC., 10-K, 3/30/2020
<!-- page 17 -->
Certain identified information has been excluded from this exhibit because it is both (i) not
material and (ii) would be competitively harmful if publicly disclosed. Schedule 2 Marketing Support
Requirements Social Platforms Content- Monthly o Suggested Design Concepts § Samples or ideas as
needed o Approved Images § Minimum 5 Photos · Studio or in the field of Tarek o File Format: .jpg,
.psd, .tiff, .png. o Approved Copy § Minimum 3 topics to post · 1-2 paragraphs of content o Event
promotion, Motivational and Real Estate Content o Approved Videos § Minimum 3 Videos · 60 seconds to
3 minutes + o Studio or in the field of Tarek · Event promotion, Motivational and Real Estate
Content o Personal Post § Minimum 1 social post on all platforms inviting people to events, products
or services o Approval for Legacy to Repost Tarek's Social Media Content on all platforms
Registration Landing Page Content- Quarterly o Suggested Design Concepts § Samples or ideas as
needed o Approved Images § 3 Hero image/poses (studio or in the field) of Tarek · Full length, 3/4
or straight, waist up and/or chest up o Hi-resolution: 8"x10" or 5"x 7" 300 dpi flattened file §
File Format: .jpg, .psd, .tiff, .png. o Approved Copy § Minimum 3 topics to post · 1-2 paragraphs of
content o Event promotion, Motivational and Real Estate Content o Approved Videos § Minimum 3 Videos
· 60 seconds to 3 minutes + o Studio or in the field of Tarek · Event promotion, Motivational and
Real Estate Content

17

Source: LEGACY EDUCATION ALLIANCE, INC., 10-K, 3/30/2020
<!-- page 18 -->
Certain identified information has been excluded from this exhibit because it is both (i) not
material and (ii) would be competitively harmful if publicly disclosed. Email Invite Contact Method-
Quarterly o Suggested Design Concepts § Samples or ideas as needed o Approved Images § 3 Hero
image/poses (studio or in the field) of Tarek · Full length, 3/4 or straight, waist up and/or chest
up o Hi-resolution: 8"x10" or 5"x 7" 300 dpi flattened file § File Format: .jpg, .psd, .tiff, .png.
o Approved Copy § Minimum 3 topics to post · 1-2 paragraphs of content o Event promotion,
Motivational and Real Estate Content o Approved Videos § Minimum 3 Videos · 60 seconds to 3 minutes
+ o Studio or in the field of Tarek · Event promotion, Motivational and Real Estate Content 18

Source: LEGACY EDUCATION ALLIANCE, INC., 10-K, 3/30/2020
