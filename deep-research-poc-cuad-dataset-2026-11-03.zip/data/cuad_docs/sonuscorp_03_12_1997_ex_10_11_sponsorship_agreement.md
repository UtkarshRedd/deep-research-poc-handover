<!-- page 1 -->
# SPONSORSHIP AGREEMENT
| Field | Value |
|---|---|
| Document Type | Sponsorship Agreement |
| Agreement Date | 1996-03-13 |
| Parties | HEALTHCARE CAPITAL CORP. ("Issue"); C.M. OLIVER & COMPANY LIMITED ("Sponsor") |
| Source | CUAD v1 / SONUSCORP_03_12_1997-EX-10.11-SPONSORSHIP AGREEMENT |

SPONSORSHIP AGREEMENT

THIS AGREEMENT, dated for reference March 13, 1996, is made

BETWEEN:

HEALTHCARE CAPITAL CORP., a corporation incorporated pursuant to the laws of the Province of Alberta
and having an office located at 1120-595 Howe Street, Vancouver, British Columbia, V6B 1N2

(the "Issuer");

AND:

C.M. OLIVER & COMPANY LIMITED, a company amalgamated under the laws of British Columbia, having its
head office at the 2nd Floor, 750 West Pender Street, Vancouver, British Columbia, V6C 1B5

(the "Sponsor").

WHEREAS:

A. The Issuer wishes to distribute to residents of British Columbia and Alberta units, comprised of
one common share and one share purchase warrant, to be issued on the exercise of previously issued
special warrants, on the terms and conditions described in the prospectus of the Issuer to be filed
with the British Columbia Securities Commission and the Alberta Securities Commission (the
"Prospectus");

B. The Sponsor is an investment dealer based in Vancouver and is a member of the Vancouver, Alberta,
Toronto and Montreal stock exchanges and of the Pacific District of the Investment Dealers
Association of Canada, and is registered as a dealer under the Securities Act (British Columbia);

C. The Sponsor is prepared, on and subject to the terms and conditions of this Agreement, to conduct
an investigation of the organization, management, business and affairs of the Issuer, sufficient to
enable it to sign the certificate for the final Prospectus of the Issuer.

THEREFORE, the parties agree:

1. INTERPRETATION

1.1 Defined Terms

In this Agreement:

AG2432.386 [097]

- 2 -

(a) "Distribution" means the distribution by the Issuer of the Units to holders of the Securities
under the Prospectus and "distribute" has a corresponding meaning;

(b) "Finders' Special Warrants" means the Special Warrants issued by the Issuer as a finders' fee
pursuant to a private placement completed by the Issuer on February 28, 1996;

(c) "Indemnified Parties" means the Sponsor, its affiliates and their respective directors,
officers, employees and agents;

(d) "Issuer" means HealthCare Capital Corp.;

(e) "Marketing Materials" means any marketing materials to be used in connection with the Offering;

(f) "material change", "material fact" and "misrepresentation" have the respective meanings assigned
in the Securities Act (British Columbia);

(g) "Offering" means the offering, sale and distribution of the Securities pursuant to the
Prospectus;

(h) "Prospectus" means the final prospectus of the Issuer to be filed with the Securities
Commissions in connection with the Offering;

(i) "Related Agreements" means any contract which may be
<!-- page 2 -->
regarded as material to the purchase of Securities, each as more particularly described in the
Prospectus;

(j) "Securities" means the 1,870,000 Units of the Issuer issuable pursuant to the Special Warrants
and additional 35,750 Units of the Issuer issuable pursuant to the Finders' Special Warrants offered
under the Prospectus;

(k) "Securities Commissions" means the Alberta Securities Commission and the British Columbia
Securities Commission;

(l) "Securities Law" means collectively the applicable laws, regulations, policies and prescribed
forms of Alberta and British Columbia relating to the distribution of the Securities;

(m) "Security Holder" means any person whose subscription for Securities is accepted by the Issuer,
or any subsequent transferee or successor of such person;

(n) "Sponsor" means C.M. Oliver & Company Limited; and

AG2432.386 [097]

- 3 -

(o) "Special Warrants" means the outstanding special warrants of the Issuer each such special
warrant entitling the acquisition of one common share and one non-transferable share purchase
warrant to purchase one additional common share in the capital of the Issuer.

1.2 Accounting Terms

Any accounting terms used herein which are not specifically defined in the preceding section 1.1
shall be construed in accordance with generally accepted Canadian accounting principles.

1.3 Number and Gender

Words importing the singular number include plural and vice versa and words importing gender include
the masculine, feminine and neuter genders.

1.4 Headings

The division of this Agreement into sections, subsections, paragraphs, subparagraphs, schedules and
clauses, and the insertion of headings and captions are for convenience of reference only and do not
affect the construction or interpretation of this Agreement.

1.5 Severability

Any provision of this Agreement which may be found to be prohibited by or unenforceable pursuant to
the laws of any jurisdiction shall, as to such jurisdiction, be ineffective to the extent of such
unenforceability or prohibition without invalidating the remaining terms and provisions hereof.

1.6 Certificates and Certified Copies

Whenever in this Agreement reference is made to a certificate or a certified copy to be delivered by
a party, unless specifically provided otherwise, such certificate or certified copy must be executed
by an officer of the party who, by virtue of his office, is familiar with the subject of such
certificate or certified copy and shall certify the completeness, truth and accuracy thereof as of
the date of such certificate or certified copy.

1.7 Governing Law

This Agreement is governed by, and will be construed in accordance with, the laws of British
Columbia, Canada.

1.8 Entire Agreement

AG2432.386 [097]

- 4 -

This Agreement, including any thing expressly incorporated by reference herein, contains all the
terms and conditions in connection with the subject matter hereof and no other agreements, written
or oral, respecting such subject matter
<!-- page 3 -->
shall be deemed to exist or to bind any party.

1.9 Currency References

All dollar amounts referred to in this Agreement are in Canadian dollars unless otherwise
specifically provided.

2. APPOINTMENT OF SPONSOR

2.1 Appointment of Sponsor

The Issuer appoints the Sponsor as sponsor of the Offering and the Sponsor accepts the appointment
and agrees to act as sponsor of the Issuer under the Prospectus on the terms of this Agreement.

2.2 Duties of Sponsor

As sponsor of the Issuer under the Prospectus, the Sponsor will conduct an investigation of the
organization, management, business and affairs of the Issuer sufficient, in its sole discretion, to
enable it to determine whether or not it is able to sign the certificate of the Prospectus.

2.3 Signature of Certificate

If, following the investigation referred to in subsection 2.2, the Sponsor determines in its sole
discretion that it is able to do so, the Sponsor will sign the certificate for the Prospectus,
certifying that, to the best of its knowledge, the Prospectus contains full, true and plain
disclosure of all material facts relating to the Securities.

2.4 Review of Business

The Issuer will provide, or cause to be provided, to the Sponsor, its counsel and its agents a
reasonable opportunity to conduct such full and comprehensive review of its business, capital,
finances, operations and principals as the Sponsor, in its sole discretion, considers reasonably
necessary in the circumstances.

2.5 Sponsor's Fee

For the services of the Sponsor as sponsor of the Offering and as full and complete compensation
therefor, the Issuer will pay to the Sponsor the sum of $32,100 (inclusive of Goods and Services
Tax), the receipt of which is acknowledged by the Sponsor.

AG2432.386 [097]

- 5 -

3. REPRESENTATIONS AND WARRANTIES

3.1 Representations and Warranties of the Issuer

The Issuer represents and warrants to the Sponsor that:

(a) Status of the Issuer

The Issuer, and each of its subsidiaries, is a corporation duly incorporated, validly existing and
in good standing under the respective laws of the jurisdiction of its incorporation and each has all
requisite power and authority and holds all material licences, certificates, consents, permits and
other authorizations as are necessary to enable it to carry on its proposed business as disclosed in
the Prospectus.

(b) Regular Business

The business of the Issuer and its subsidiaries have been carried on, in all material respects, as
contemplated by and in compliance with the requirements of their respective constating documents and
in compliance with all applicable laws, rules and regulations, and neither the Issuer nor any of its
subsidiaries is in breach of or in default under any mortgage, note, indenture, contract,
instrument, lease or other document or agreement to which it is a party.

(c) Corporate and Partnership Authority

The execution, delivery and performance by the Issuer of this Agreement and the Related Agreements,
when executed and delivered, to which it is or will be a party are within the Issuer's powers, have
been or will have been, at the time of execution and delivery thereof, duly authorized by all
necessary corporate
<!-- page 4 -->
action and do not and will not contravene its constating documents or any provision of any contract
binding on it.

(d) Claims and Potential Claims

To the knowledge of the Issuer, no litigation, proceeding or investigation is pending or threatened
before any court, agency, arbitrator or otherwise which will or might reasonably result in any
material adverse change in the business, affairs or properties or conditions (financial or
otherwise) of the Issuer or any of its subsidiaries or which might reasonably result in any material
liability on the part of the Issuer or any of its subsidiaries.

AG2432.386 [097]

- 6 -

(e) Prospectus

The Prospectus complies with the requirements of the Securities Law in all material respects. The
Prospectus does not contain any misrepresentation or any untrue statement of a material fact or omit
any statement or information, the omission of which constitutes a misrepresentation, or omit to
state any material fact required to be stated or necessary to make any statement contained therein
not false or misleading in light of the circumstances in which it is made and all information and
statements contained in the Prospectus are true and correct. In addition, all information and
statements contained in the Prospectus constitute full, true and plain disclosure of all material
facts.

(f) Financial Statements

The financial statements of the Issuer contained in the Prospectus accurately reflect the financial
position of the Issuer on a consolidated basis at the dates thereof and there have been no adverse
material changes in the financial position of the Issuer or any of its subsidiaries since the
respective dates thereof, except as fully and plainly disclosed in the Prospectus.

(g) Representations and Warranties

The representations and warranties in this Agreement are true and will remain true as of the date of
the Prospectus.

3.2 Representations and Warranties of the Sponsor

The Sponsor represents and warrants to the Issuer that:

(a) Corporate Status

It is a corporation duly amalgamated, validly existing and in good standing under the laws of
British Columbia.

(b) Corporate Authority

The execution, delivery and performance by the Sponsor of this Agreement is within the Sponsor's
corporate powers, has been duly authorized by all necessary corporate action and does not
contravene:

(i) the memorandum or articles of the Sponsor; or

(ii) any law; or

AG2432.386 [097]

- 7 -

(iii) any provision of any other contract binding on the Sponsor.

(c) Governmental Approvals
<!-- page 5 -->
Except for compliance with the requirements of the Securities Law, no authorization or approval or
other action by and no notice to or filing with any governmental authority or regulatory body is
required for the due execution, delivery and performance by the Sponsor of this Agreement.

3.3 Survival of Representations and Warranties

Each of the parties hereto acknowledges that the other parties are relying on each of the
representations and warranties addressed to such other parties set forth in section 3.1 or 3.2, as
the case may be, and any representations made in any certificate issued to such other parties in
connection with this Agreement notwithstanding any investigations heretofore or hereafter made by
such other parties or their counsel or representatives. All such representations and warranties
shall not merge in or be prejudiced by, and shall survive for a period of three years from the
completion of the distribution of the Units.

4. COVENANTS OF THE ISSUER

The Issuer covenants with the Sponsor that:

(a) it will take all such acts and execute, file and deliver all such documents, amendments, notices
and information as may be necessary to cause the purchasers of Securities to become Security Holders
of the Issuer;

(b) it will execute or procure the execution of all documents and use its best efforts to take or
cause to be taken all steps which may be reasonably necessary to enable the transactions
contemplated herein to be completed;

(c) it will notify the Sponsor promptly in writing of the full particulars of any material change,
whether actual, anticipated or threatened, in any material fact stated or referred to in the
Prospectus or which would result in an omission from the Prospectus to state a material fact
necessary to make any statement contained therein not misleading in light of the circumstances in
which it is made;

(d) during the period of distribution, distribution to the public or primary distribution to the
public (as contemplated by the Securities Law) of the Securities, it will advise the Sponsor
promptly of any request of any securities commission or other securities authority for a cease
trading order relating to the Securities, or of the institution or threat of institution of any
proceedings for that purpose, or of the receipt by it, or its counsel

AG2432.386 [097]

- 8 -

of any material communication from any securities commission or other securities authority relating
to the Prospectus or any supplements or amendments thereto;

(e) upon the occurrence of a material change, it shall, to the satisfaction of the Sponsor, promptly
comply with all applicable filing and other requirements under the Securities Law as a result of
such material change;

(f) the Securities, when issued, will have the attributes described in the Prospectus; and

(g) it will deliver or cause to be delivered all documents, including legal opinions, required
hereunder and by the Prospectus.

5. EXPERT OPINIONS

The Issuer shall deliver to the Sponsor on the date of filing the Prospectus:

(a) a letter dated as of a date not more than one Business Day prior to the date of the Prospectus,
in form and substance satisfactory to the Sponsor, from the then current auditor of the Issuer:

(i) stating that, in such auditor's opinion, the financial statements and notes thereto of the
Issuer examined by them and included in the Prospectus covered by his report therein comply as to
form in all material respects

with the applicable accounting requirements of the Securities Law; and
<!-- page 6 -->
(ii) stating that, in such auditor's opinion, the balance sheet of the Issuer examined by the
auditor and included in the Prospectus and covered by his report therein complies as to form in all
material respects with the applicable accounting requirements of the Securities Law; and

(iii) addressing such other matters relating to the financial information in the Prospectus to which
the Sponsor may reasonably require comfort;

(b) a favourable legal opinion, in form and content reasonably satisfactory to the Sponsor, by
counsel to the Issuer dated the date of the Prospectus and addressed to the Sponsor, relating to
such legal matters as the Sponsor may reasonably request, including, without limitation, certain of
the matters in section 3.1, title to the Issuer's property, and matters pertaining to the Securities
Law;

AG2432.386 [097]

- 9 -

(c) a certificate of the Issuer certifying certain facts relating to the business of the Issuer, and
its affairs as may be reasonably requested by the Sponsor; and

(d) any other certificates, comfort letters or opinions in connection with any matter related to the
Prospectus which are reasonably requested by the Sponsor or their legal counsel.

6. TERMINATION

6.1 Term of Agreement

This Agreement shall terminate and, subject to the provisions set forth below, be of no further
force or effect on the exercise by the Sponsor of its right to terminate this Agreement as provided
in subsection 6.2, provided that, in any event, sections 3, 7 and 8 and, in the event that such
termination occurs by virtue of paragraph 6.2(b), subsection 2.5 shall not terminate (except as set
forth therein) and shall continue in full force and effect for the benefit of the Sponsor or the
other parties to this Agreement, as the case may be.

6.2 Termination of Agreement

The Sponsor may, at its sole option, terminate this Agreement at any time prior to the issuance of a
receipt for the Prospectus by all of the Securities Commissions by notice in writing to the Issuer
if:

(a) any representation or warranty made by or on behalf of the Issuer herein or in any certificate
delivered in connection with this Agreement proves to have been incorrect in any material respect
when made;

(b) any material adverse change occurs in the business or financial condition of the Issuer or any
of its subsidiaries;

(c) the Issuer breaches or fails to perform or observe any of the covenants or agreements to be
performed or observed by it hereunder;

(d) any order operating to restrict, prevent or cease trading in the Securities is made under the
Securities Law;

(e) any inquiry or investigation, whether formal or informal, is commenced or threatened by a
securities commission against the Issuer or its directors, officers or agents; or

(f) any of the conditions set forth in section 5 are not satisfied.

AG2432.386 [097]

- 10 -
<!-- page 7 -->
6.3 Obligations of Sponsor Clarified

For greater certainty, the Sponsor is obligated under this Agreement, subject to subsection 6.2,
only to perform the investigation referred to in subsection 2.2, and nothing in this Agreement will
obligate the Sponsor to sign the certificate for the Prospectus, unless, in its sole discretion, it
considers itself able to do so.

7. COSTS, EXPENSES AND TAXES

Whether or not the Sponsor signs the certificate as contemplated in subsection 2.3, the Issuer will
bear the costs and expenses in connection with the Offering, the preparation, execution and delivery
of this Agreement, amendments to the Prospectus and the other documents to be delivered hereunder,
including, without limitation:

(a) the reasonable fees and out-of-pocket expenses of counsel for the Sponsor with respect thereto
(which fees, not including expenses and taxes, are not expected to exceed $15,000 but may after
consultation with and receipt of the prior approval of the Issuer) and with respect to advising the
Sponsor as to its rights and responsibilities under this Agreement;

(b) fees and costs of preparing and reproducing the Prospectus, any amendments thereto and any other
Marketing Materials prepared by the Issuer;

(c) filing fees in connection with compliance with the Securities Law;

(d) all costs and expenses associated with obtaining an assessment report in compliance with Interim
Local Policy Statement 3-17 of the British Columbia Securities Commission, if required; and

(e) all costs and expenses, if any (including reasonable counsel fees and expenses), in connection
with the enforcement of this Agreement, and the other documents to be delivered hereunder.

8. INDEMNIFICATION

8.1 Indemnification of Indemnified Parties

The Issuer shall and does hereby indemnify and save the Indemnified Parties harmless from and
against any liability, claim, demand or loss, excluding loss of profits, which the Indemnified
Parties may suffer, whether pursuant to statute or otherwise, howsoever arising, in consequence of:

AG2432.386 [097]

- 11 -

(a) any statement or omission in the Prospectus, or otherwise made or omitted by the Issuer in
connection with the Offering, being or being alleged to be a misrepresentation;

(b) the Issuer not complying with any requirement of applicable legislation of Canada or of British
Columbia or Alberta; or

(c) any order made or any inquiry, investigation or proceeding commenced, threatened or announced by
any securities regulatory authority or other competent authority in British Columbia, Alberta or
Ontario which prevents or restricts trading in or the sale or distribution in British Columbia and
Alberta of the Securities.

8.2 Right to Counsel

If any claim contemplated by this section is asserted against any of the Indemnified Parties, the
Issuer shall be entitled (but not required) to assume the defence on behalf of the Indemnified
Parties of any suit brought to enforce such claim, provided that the defence shall be through legal
counsel acceptable to the Indemnified Parties and no admission of liability shall be made by the
Issuer or the Indemnified Parties without, in each case, the prior written consent of all the
parties hereto, such consent not to be unreasonably withheld. Any of the Indemnified Parties shall
have the right to employ separate counsel in any such suit and participate in the defence thereof,
at the expense of the Issuer.

8.3 Indemnity
<!-- page 8 -->
The indemnity provided for in this section will not be limited or otherwise affected by any other
indemnity obtained by the Sponsor from any other person in respect of any matters specified in this
Agreement and will continue in full force and effect until all possible liability of the Sponsor
arising out of the transactions contemplated by this Agreement has been extinguished by the
operation of law.

9. NOTICES

Any notice required or permitted to be given hereunder shall be in writing and be given by personal
service, telex, telegram, telecopy or by registered letter, with postage fully prepaid, to the
address set forth below:

AG2432.386 [097]

- 12 -

(a) if to the Issuer at:

HealthCare Capital Corp. c/o Ballem MacInnes Barristers and Solicitors First Canadian Centre 1800,
350-7th Avenue S.W. Calgary, Alberta T2P 3N9 Attention: William DeJong Telephone: (403) 292-9800
Fax: (403) 233-8979

(b) if to the Sponsor at:

C.M. Oliver & Company Limited 2nd Floor, 750 West Pender Street Vancouver, B.C. V6C 1B5 Attention:
Lyle Davis Telephone: (604) 668-6700 Fax: (604) 681-8964

Any notice delivered personally or by telex, telegram or telecopy shall be deemed to be received by
and given to the addressee on the day of delivery. Any notice mailed as aforesaid shall be deemed to
have been received by and given to the addressee on the fifth Business Day following the date of
mailing except in the event of a disruption of postal service, in which event notice shall be
delivered personally or given by telex, telegram or telecopy. Either party hereto may designate a
new address by giving written notice thereof to the other party at least ten days in advance of the
effective date of such designation.

10. MISCELLANEOUS

10.1 Amendments, Etc.

No amendment or waiver of any provision of this Agreement nor consent to any departure by the Issuer
therefrom shall in any event be effective unless it is in writing and signed by the Sponsor and then
such waiver or consent will be effective only in the specific instance and for the specific purpose
for which given.

10.2 Time

Time shall be of the essence of this Agreement.

AG2432.386 [097]

- 13 -

10.3 Binding Effect

This Agreement is binding upon and enures to the benefit of the parties and their respective
successors and assigns, and no party shall have the right to assign its rights hereunder or any
interest herein without the prior written consent of the other parties.

10.4 Governing Law

This Agreement will be governed by the law of British Columbia and the parties attorn to the
non-exclusive jurisdiction of the courts of British Columbia for the resolution of all disputes
arising in connection with this Agreement.

11. EXECUTION IN COUNTERPART
<!-- page 9 -->
This Agreement may be executed by any party in two or more counterparts, each such counterpart will
be deemed to be an original, and all such counterparts taken together will constitute one and the
same agreement.

IN WITNESS of this Agreement, the parties have executed and delivered this Agreement as of the date
given above.

HEALTHCARE CAPITAL CORP.

By: /s/ Douglas F. Good Title: Chief Financial Officer

C.M. OLIVER & COMPANY LIMITED

By: /s/ C. M. O'Brian Title: Chairman

AG2432.386 [097]
