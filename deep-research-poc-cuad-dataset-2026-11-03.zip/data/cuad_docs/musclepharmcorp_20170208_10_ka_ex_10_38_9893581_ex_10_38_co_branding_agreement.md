<!-- page 1 -->
# ENDORSEMENT LICENSING AND CO-BRANDING AGREEMENT
| Field | Value |
|---|---|
| Document Type | Co-Branding Agreement |
| Agreement Date | 2013-07-26 |
| Parties | Marine MP, LLC (“Lender”); Arnold Schwarzenegger (“Endorser”); Fitness Publications, Inc. (“Fitness”); Lender, Endorser and Fitness (“AS Parties”); MusclePharm Corporation ("MusclePharm" or "Company") |
| Source | CUAD v1 / MusclepharmCorp_20170208_10-KA_EX-10.38_9893581_EX-10.38_Co-Branding Agreement |

ENDORSEMENT LICENSING AND CO-BRANDING AGREEMENT This ENDORSEMENT LICENSING AND CO-BRANDING AGREEMENT
is entered into on July 26, 2013 (the "Effective Date") by and between Marine MP, LLC ("Lender"),
for services of Arnold Schwarzenegger ("Endorser"), and Fitness Publications, Inc. ("Fitness")
(collectively, Lender, Endorser, and Fitness are referred to as the "AS Parties") and MusclePharm
Corporation with its principal place of business in Denver, Colorado and its subsidiaries,
(collectively, "MusclePharm" or the "Company"). RECITALS WHEREAS, the AS Parties have the rights
necessary to license the use of the rights of publicity with respect to name, voice, approved
signature, approved photographs, approved images, and approved likenesses of Arnold Schwarzenegger
(the "Name and Appearance Rights") and the use of the Name and Appearance Rights as trademarks or
service marks (the "Trademarks"); and WHEREAS, MusclePharm is engaged in the business of developing
and marketing nutritional products for athletes and fitness enthusiasts, and WHEREAS, MusclePharm
from time to time uses consumer, celebrity, and expert endorsements or testimonials to promote
MusclePharm Products (as defined in Section 2(b) of this Agreement) in marketing and advertising
materials, and WHEREAS, MusclePharm desires to develop, market, promote and sell in conjunction and
in cooperation with the Endorser a unique Arnold Schwarzenegger customized product line approved by
the Endorser initially comprised of between four to eight (4 to 8) products, subject to Section 2(b)
below), that will be marketed and advertised under the Endorser's name and likeness, all subject to
the Endorser's approval, as described in Section 12, (the "AS Product Line"); and WHEREAS,
MusclePharm desires to engage Endorser, and Endorser desires to accept the engagement, as more fully
described in this Agreement, whereby Endorser will lend his name, reputation, and appearance to (i)
endorse and promote MusclePharm and its Products and (ii) to develop the AS Product Line and several
related promotional giveaway items that will depict the Endorser's name and likeness solely in
conjunction with the MusclePharm logo or images of the AS Product Line on the permitted promotional
products (the "Promotional Products") set forth on Exhibit A attached hereto, as may be amended in
writing by the parties hereto from time to time (collectively, the Promotional Products and the AS
Product Line are referred to as the "Licensed Products"). NOW, THEREFORE, in consideration of the
mutual promises and agreements set forth below, the parties agree as follows:

Source: MUSCLEPHARM CORP, 10-K/A, 2/8/2017
<!-- page 2 -->
1. Term: (a) This Agreement shall have an Initial Term of three (3) years. The Term shall commence
on July 23, 2013 and shall expire on July 22, 2016, unless otherwise terminated earlier pursuant to
Section 9 of this Agreement. The period from July 23, 2013 to July 22, 2014 shall be referred to as
the "First Contract Year". The period from July 23, 2014 to July 22, 2015 shall be referred to as
the "Second Contract Year". The period from July 23, 2015 to July 22, 2016 shall be referred to as
the "Third Contract Year". (b) In the event that MusclePharm shall achieve Net Sales (as defined
below) of $20 million (the "First Renewal Threshold") in the aggregate during the Third Contract
Year, then this Agreement shall automatically be renewed for an additional term of three (3) years
(the "First Additional Term") on the same terms and conditions for the Initial Term except that: (i)
no additional Stock Compensation (as defined below) shall be issued in connection with the renewal
Term, (ii) the Cash Compensation for the First Additional Term shall be as set forth in Section 7
and Exhibit "C" Section (2) attached hereto, (iii) Endorser shall only be obligated to make two (2)
Appearances in each Contract Year during the First Additional Term pursuant to Section 4(a)(ii)
below and (iv) the marketing budget to promote the Licensed Products shall be $5.0 million during
each Contract Year of the First Additional Term (subject to Section 12(b) of this Agreement). If
this Agreement is renewed for the First Additional Term, then the First Additional Term shall
commence on July 23, 2016, and the Agreement shall expire and terminate automatically without
further notice on July 22, 2019. (c) In the event that MusclePharm shall achieve Net Sales of $50
million (the "Second Renewal Threshold") in the aggregate during the sixth Contract Year, then this
Agreement shall automatically be renewed for an additional term of three (3) years (the "Second
Additional Term") on the same terms and conditions for the initial Term except that: (i) no
additional Stock Compensation (as defined below) shall be issued in connection with the renewal
Term, (ii) the Cash Compensation for the renewal Term shall be as set forth in Section 7 and Exhibit
"C" Section (3) attached hereto, (iii) Endorser shall only be obligated to make two (2) Appearances
in each Contract Year during the Second Additional Term pursuant to Section 4(a)(ii) below and (iv)
the marketing budget to promote the Licensed Products shall be $5.0 in each Contract Year of the
Second Additional Term (subject to Section 12(b) of this Agreement). If this Agreement is renewed
for the Second Additional Term, then the Second Additional Term shall commence on July 23, 2019 and
the Agreement shall expire and terminate automatically without further notice on July 22, 2022. 2.
Engagement: (a) MusclePharm hereby engages Endorser and Endorser promises and agrees to hold himself
available to use, evaluate, advertise and promote certain MusclePharm Products, as may be reasonably
requested by MusclePharm in accordance with the terms and conditions set forth herein on a
world-wide basis. Endorser also agrees to the use on a world-wide basis (as specified pursuant to
Section 6 below and subject to the terms and conditions of this Agreement), during the Term, of his
Name and Appearance Rights to advertise and promote the business of MusclePharm, its Products, and
the Licensed Products.

Source: MUSCLEPHARM CORP, 10-K/A, 2/8/2017
<!-- page 3 -->
(b) Products. As used in this Agreement, "Products" shall mean dietary supplements manufactured
within the fifty states of the United States of America; provided, however, MusclePharm shall not
produce during the Term (and any renewal Term, if any) any diet pills and/or sexual enhancement
products; provided, further, that fat burning products, Shred Matrix and Live Shredded products and
products that increase testosterone levels currently produced by MusclePharm as of the date hereof
shall be part of the definition of Products for the purpose of this Agreement. (c) New Products.
During the Term (including any renewal Term, if any), in the event that MusclePharm shall determine
to develop and introduce a new Product into the market, MusclePharm shall provide the AS Parties
with a sample of the name, design, marketing plan and an actual sample of such new Product (the
"Sample") and the AS Parties shall have a right of first refusal (exercisable by written notice to
MusclePharm within 15 days after receipt of the Sample) to include such new Product in the AS
Product Line, it being understood that there shall initially be no less than four (4) Products at
the start of the Term and thereafter no more than 8 (eight) Products in the AS Product Line without
the mutual written agreement of the parties hereto. (d) Distribution Channels - Licensed Products.
Subject to the terms and conditions herein (including the Exhibits), the license to MusclePharm with
respect to distribution and promotion of the Licensed Products is on a worldwide basis through the
Distribution Channels (as defined below) subject to approval rights set forth in Section 13 herein.
For the purposes of this Agreement, "Distribution Channels" means the distribution of the Licensed
Products through GNC retail and online chains worldwide during the First Contract Year and,
thereafter, through MusclePharm's other worldwide distribution channels, as mutually determined by
MusclePharm and the AS Parties. 3. Endorsement of Products: Endorser agrees that he will use and
evaluate the Products and Licensed Products according to the recommended use and dose guidelines.
Based on Endorser's knowledge, personal use and experience with the Products and Licensed Products
that he shall from time to time during the Term of this Agreement provide his honest evaluation,
opinion, and findings about the Products and Licensed Products he is endorsing and promoting. The
endorsements must be based on Endorser's knowledge and/or personal use and experience with the
Products and Licensed Products at or about the times the endorsements are made. Endorser's
statements and endorsements, or paraphrases thereof, may be used by MusclePharm to advertise,
promote and publicize its business, Products and Licensed Products as provided herein. Endorser's
endorsements of the Products and Licensed Products will be in accordance with the guidelines
established by the Federal Trade Commission for endorsements in advertising. If requested by
MusclePharm, Endorser shall provide a signed affidavit in form satisfactory to MusclePharm
confirming Endorser's compliance with the FTC standards in connection with his endorsements and
endorsement activities.

Source: MUSCLEPHARM CORP, 10-K/A, 2/8/2017
<!-- page 4 -->
4. Appearances, Advertising and Promotional Activities: (a) Appearances and Video. (i) In order to
ensure the success of the co-branded Licensed Products and maximize Net Sales of such Licensed
Products to the mutual benefit of the parties hereto, the Endorser agrees that he shall make four
(4) personal appearances ("Appearances") in the First Contract Year on dates, times and places
mutually agreed upon by the parties hereto. Endorser acknowledges that such Appearances in the First
Contract Year shall consist of: (i) one (1) appearance at an industry tradeshow to be mutually
agreed by the parties, (ii) one (1) charity event with Arnold's All-Stars, (iii) one (1) appearance
at the Arnold Classic, and (iv) one (1) corporate and public relations event(s) in 2013 to be
mutually agreed by the parties. (ii) The Endorser and MusclePharm may also agree to produce on
dates, times and places mutually agreed upon by the parties hereto a GetSwole training video (the
"Training Video") during a production session (the "Production Day"). In the event that Endorser
shall agree to produce the Training Video (such decision shall be made by the Endorser exercisable
in his sole discretion) and Products (other than the Licensed Products) are featured and sold in
connection with such Training Video then Endorser shall receive ten percent (10%) of Net Sales (as
defined below) from the sale of any Products other than the Licensed Products featured and sold
directly in conjunction with the Training Video. (iii) In order to ensure the success of the
co-branded Licensed Products and maximize Net Sales of such Licensed Products to the mutual benefit
of the parties hereto, the Endorser agrees that he shall make two (2) Appearances in each of the
Second Contract Year and Third Contract Year (and any subsequent Contract Years if applicable) on
dates, times and places mutually agreed upon by the parties hereto (one such appearance to include
the Arnold Classic in each such Contract Year). (iv) Each Appearance may be up to two (2) hours in
length not including travel time to and from the Appearance, as scheduled by MusclePharm, for the
purpose or promoting MusclePharm, its Products and the Licensed Products. The Production Day shall
be for the purpose of MusclePharm shooting the Training Video. In the event that the Endorser agrees
to participate in the Training Video, the Production Day for the Training Video may be up to two (2)
hours in duration. (v) In the event Endorser agrees to appear in the Training Video on television
promoting the Licensed Products during the Term hereof, the Training Video shall be produced by a
production company that is a SAG signatory and such production company shall pay on behalf of the
Endorser all pension, health & welfare benefit payments. For the purpose of computing such pension,
health and welfare benefit contributions and any other payments under any SAG or AFTRA contracts
applicable to Endorser's appearance in such Training Video, 25% of the compensation payable to
Endorser under this Agreement shall be allocated as fair and reasonable consideration for Endorser's
work and appearance in the Training Video during the Term or thereafter during the Use-Up Period
defined below.

Source: MUSCLEPHARM CORP, 10-K/A, 2/8/2017
<!-- page 5 -->
(b) Advertisements, Print Media, and Promotional Items. Endorser agrees that during the Term
MusclePharm shall have the right to use, worldwide, Endorser's Name and Appearance Rights (as
specified in Section 6) to advertise MusclePharm and its Products and Licensed Products in print
media, and in all other forms of media (other than telephone marketing or texting campaigns)
including, but not limited to, point of sale material, premiums and novelties, direct marketing
material, and radio, television, electronic, and computer media (including but not limited to
MusclePharm's Internet and social media websites). Print media will also include promotional items
on which Endorser's approved picture; approved likeness, or facsimile signature may appear. Endorser
will have the right to approve, in writing via his representative's office, all advertising
materials which utilize Endorser's Name and Appearance Rights, but Endorser will not unreasonably
withhold approval and will promptly respond to all approval requests. (c) Use of Endorsements.
During the Term, MusclePharm also shall have the right to use, worldwide, Endorser's oral or written
endorsements of Products and Licensed Products, or paraphrases thereof, to promote MusclePharm, its
business, Products, and Licensed Products. Endorser shall have the right to approve such oral or
written endorsements and the use thereof, such approval not to be unreasonably withheld or delayed.
(d) Use-Up Period. During the Term, the right to use Endorser's Name and Appearance Rights granted
to MusclePharm in this Section shall extend for six (6) months beyond the expiration of this
Agreement (the "Use-up Period"). MusclePharm shall create no new advertising during the Use-up
Period using Endorser's Name and Appearance, but shall have the right to use during the Use-up
Period Endorser's Name and Appearance in advertisements and promotional materials created before the
expiration date of this Agreement. (e) Promotional Products. During the Term, MusclePharm shall have
the right to create and distribute the Promotional Products world- wide. MusclePharm shall be
permitted to sell the Promotional Products at its cost to third parties and Endorser shall not be
entitled to any additional compensation with respect to the Promotional Products. In the event that
MusclePharm shall sell any Promotional Products above its cost then Endorser shall be entitled to
receive 10% of Net Sales from the sale of such Promotional Products. (f) Online content. During the
Term, Endorser will use good faith efforts to provide online content for MusclePharm's websites and
social media websites as reasonably requested by MusclePharm. This will be in a form agreed to by
the parties (e.g. training video or video interview with a MusclePharm representative). This will be
scheduled so as to not interfere with Endorser's movie and other obligations. Endorser will use good
faith efforts to promote MusclePharm on his website (e.g. www.schwarzenegger.com). (g) GetSwole.
Endorser, in conjunction with MusclePharm's management and fitness experts will help in the design
of the GetSwole Diet and Weight Training Program. (h) Autographed Items. Endorser shall also supply
MusclePharm with at least fifty (50) signed items for each Contract Year, on the Licensed Products
or on other items to be mutually agreed upon by the parties hereto, to be used by MusclePharm in
connection with the promotion of the Products and/or Licensed Products.

Source: MUSCLEPHARM CORP, 10-K/A, 2/8/2017
<!-- page 6 -->
(i) Representations and Warranties. Endorser expressly represents and warrants that he is not
subject to any restriction or limitation by way of employment or contractual obligation that may
impair or limit his performance of the advertising and promotional activities described above, and
that Endorser has the express approval of any third party to make the promises and commitments set
forth herein, and will advise any future employer of his obligations hereunder. 5. Scheduling: (a)
The Appearances, the Production Day, the Licensed Product launch and related media campaign, the
interview of Endorser by MusclePharm, and all advertising and promotional activities requested by
MusclePharm and approved by Endorser shall be scheduled by mutual agreement and subject to
Endorser's other business activities and commitments occurring during the Term of this Agreement.
Endorser's commitments pursuant to this Agreement shall be scheduled so as not to conflict with
Endorser's other commitments. Endorser agrees that he will in good faith make every reasonable
effort, given his other commitments, to give priority to the fulfillment of his obligations pursuant
to this Agreement. The parties shall confer periodically for the purpose of coordinating and
scheduling Endorser's advertising and promotional activities and services. 6. Right of Publicity:
(a) Name and Appearance Rights. As provided below, during the Term, the AS Parties grant to
MusclePharm the right to use the Trademarks as defined in this Agreement and the Name and Appearance
Rights, which shall include Endorser's name, approved photograph, approved picture (including,
without limitation, any copyrighted pictures and video images of the Endorser owned by the Endorser
which Endorser agrees to make available for use hereunder), approved appearance, or approved
likeness, including video and other recordings of Endorser's appearance, along with the right to use
Endorser's voice, including audio or other recordings of Endorser's voice, Endorser's signature,
personal or professional background and experience, reputation, approved quotations and approved
endorsements, or approved paraphrases of Endorser's approved quotations and endorsements, including
approved touch-ups, approved simulations or approved compositions of any of the above whether
generated by computer or by any other means, for the period of time and for the purposes set forth
in this Agreement. MusclePharm acknowledges that the use of some works may require that MusclePharm
obtain a copyright license from third parties. (b) Promotional Uses. During the Term of this
Agreement, the AS Parties grant to MusclePharm and consent to MusclePharm's commercial use of the
Name and Appearance Rights to advertise, promote, endorse and publicize Products, Licensed Products,
and MusclePharm's business, worldwide in any media selected by MusclePharm (excluding telephone or
texting campaigns), including but not limited to print, radio, television, electronic, wireless or
internet, pursuant to the terms and conditions set forth herein. MusclePharm acknowledges that any
use on products requires approval and that use of the Name and Appearance Rights on products is
limited to the Licensed Products.

Source: MUSCLEPHARM CORP, 10-K/A, 2/8/2017
<!-- page 7 -->
(c) Editorial Uses. Endorser also grants to MusclePharm and consents to MusclePharm's editorial use
world-wide of Endorser's Name and Appearance in MusclePharm published materials approved by
Endorser. For purposes of this Agreement, MusclePharm's editorial use of Endorser's Name and
Appearance shall mean a use that does not directly promote, advertise or endorse MusclePharm's
business, its Products or Licensed Products. Nothing in this Section 6(c) shall entitle MusclePharm
to reduce Endorser's compensation pursuant to Section 7 and Section 8 of this Agreement (including,
without limitation, with respect to any renewal Term, if any). (d) Discretion to Utilize. Except as
otherwise provided in this Agreement, MusclePharm may in its sole discretion exercise some or all of
the rights granted by Endorser in this Agreement, but MusclePharm shall have no obligation to
exercise or use the rights Endorser has granted. If MusclePharm elects to not exercise or use all
the rights granted by Endorser, MusclePharm's election shall not be interpreted or construed as a
waiver or release of such rights. MusclePharm shall have the rights to use Endorser's Name and
Appearance Rights and the Right to Publicize Endorser's Name and Appearance, as provided in this
Agreement, unless Endorser and MusclePharm enter into a separate written agreement in which
MusclePharm waives or releases some or all of the rights Endorser has granted in this Agreement. (e)
Representations and Warranties. Endorser expressly represents and warrants that he is not subject to
any restriction or limitation by way of employment or contractual obligation that may impair or
limit the right of publicity granted herein by Endorser, and that Endorser has the express approval
of his employer to make the promises and commitments set forth herein. 6A. News Releases and Public
Announcements: Neither party may, without the other party's prior written consent, make any news
release or public announcement of the existence or value of this Agreement or its terms and
conditions, or in any other manner advertise or publish its value, or its terms and conditions and
neither party shall issue any press release or other public announcement which includes the name of
the other party without such party's prior written consent, such consent not to be unreasonably
withheld or delayed. The parties hereby agree that within four (4) business days after the execution
and delivery of this Agreement and within four (4) business days after the launch of the Licensed
Products, the parties hereto shall issue a joint press release in form and substance mutually
agreeable to the parties hereto. Notwithstanding the foregoing, a party may make any filing of this
Agreement or description of this Agreement in a current report on Form 8-K or similar requisite
filing with the Securities and Exchange Commission that it believes in good faith and upon a
reasonable basis is required by applicable law or any listing or trading agreement concerning its
publicly traded securities. 6B. Sample Products for Endorser's Use: MusclePharm shall provide a
reasonable supply of Products, Licensed Products, and Promotional Products for Endorser's personal
use and endorsement as contemplated by this Agreement.

Source: MUSCLEPHARM CORP, 10-K/A, 2/8/2017
<!-- page 8 -->
7. Compensation: (a) Cash: (i) During the Term of this Agreement and during any sell-off period,
MusclePharm shall pay Lender a royalty (the "Royalty") of 10% on Net Sales (as defined below) of
Licensed Products sold through its wholesale Distribution Channels or retail Distribution Channels,
as the case may be and 10% on Net Sales of the Training Video and any Products sold in connection
with any Training Video as contemplated pursuant to the last sentence of Section 4(a)(i) above. For
purposes of this Agreement, "Net Sales" shall mean MusclePharm's gross sales (the gross invoice
amount billed customers) of the Licensed Products, less discounts and allowances actually shown on
the invoice (except cash discounts, transportation costs and commissions not deductible in the
calculation of Royalty) and less any bona fide returns (net of all returns actually made or allowed
as supported by credit memoranda actually issued to the customers not to exceed 5% in any reporting
cycle), the aggregate of which discounts and allowances shall not exceed 5% in any reporting cycle.
No other costs incurred in the manufacturing, selling, advertising, and distribution of the Licensed
Products shall be deducted nor shall any deduction be allowed for any uncollectible accounts,
allowances or bad debt. (ii) A Royalty obligation shall accrue upon the sale of the Licensed
Products regardless of the time of collection by MusclePharm. For purposes of this Agreement,
Licensed Products shall be considered "sold" upon the date when such Licensed Products are billed,
invoiced, shipped, or paid for, whichever event occurs first. (iii) If MusclePharm sells any
Licensed Products to any party affiliated with MusclePharm, or in any way directly or indirectly
related to or under the common control with MusclePharm, at a price less than the regular price
charged to other parties, the Royalty payable to Lender shall be computed on the basis of the
regular price charged to other parties. (iv) All payments due hereunder shall be made in United
States currency drawn on a United States bank, unless otherwise specified between the parties. (v)
During the Term and during the sell-off period, MusclePharm shall make royalty payments in U.S.
dollars for the respective quarters ending on the last day of September, December, March and June
(each, a "Royalty Period") within thirty (30) days from the end of each quarterly period. Each such
royalty payment shall include an itemized statement showing the nature and source of such royalties,
including (i) the number of units of Licensed Products sold (by country and customer); (ii) the
total number of units returned for which credit was given and the total dollar amount of such
credits, and (iii) the total gross sales and the total royalties due with respect to such gross
sales, and each itemized statement shall be certified by a duly authorized officer of MusclePharm.
Such statements shall be in the form attached hereto as Exhibit "B" and furnished to Lender whether
or not any Licensed Products were sold during the Royalty Period.

Source: MUSCLEPHARM CORP, 10-K/A, 2/8/2017
<!-- page 9 -->
(vi) MusclePharm will send all statements and payments, including all royalties, to the Lender to
the address set forth in Section 20 below. MusclePharm will make all payments payable to the Lender.
(vii) Receipt or acceptance by Lender (or its authorized representative) of a royalty statement or
receipt or acceptance of any accompanying royalty payment shall not prevent Lender from at any time
within three years after the Term of this Agreement questioning the validity or accuracy of such
royalty statement or payment. (viii) MusclePharm's obligations for the payment of a Royalty and the
Guaranteed Minimum Royalty (as defined below) shall survive expiration or termination of this
Agreement and will continue for so long as MusclePharm continues to manufacture, sell or otherwise
market the Licensed Products. Notwithstanding the foregoing, Lender shall be entitled to receive a
guaranteed minimum royalty for each Contract Year including the Additional Term, if any (the
"Guaranteed Minimum Royalty"), payable in accordance with Exhibit "C" attached hereto. 8. Stock: (a)
Within three (3) days of the execution and delivery of this Agreement and prior to any news release
or public disclosure of the existence of this Agreement, its terms and conditions, or the
relationship of the parties hereto, whether pursuant to a press release, a current report on Form
8-K or other filing with the Securities and Exchange Commission or otherwise (the "Issuance Date"),
MusclePharm shall issue Lender 780,000 shares of MusclePharm's restricted stock (the "Compensation
Shares"), for services performed and to be performed pursuant to this Agreement. All Compensation
Shares will be fully vested upon issuance, and for a period of six (6) months following the date
hereof, Lender may not sell in excess of fifty percent (50%) of the Compensation Shares without the
prior consent of MusclePharm; provided, that, the Lender shall be entitled, without the prior
consent of MusclePharm, to transfer the Compensation Shares at any time to affiliates and family
members so long as such transfers are in compliance with state and federal securities laws and such
transferees agree to be bound by foregoing transfer restrictions for the six (6) month period
following the date hereof with respect to the Compensation Shares. MusclePharm agrees that (i) with
respect to the Compensation Shares, Lender shall be entitled to all rights and benefits under the
registration rights agreement, dated as of March 28, 2013 (the "Registration Rights Agreement"), by
and among MusclePharm and the investors party thereto as if it were an investor party thereto,
mutatis mutandis. MusclePharm shall promptly file (and in no event later than August 14, 2013) a
registration statement on Form S-1 pursuant to the Securities Act (as defined below) (the
"Registration Statement") with the SEC and will include therein the offering of all of the
Compensation Shares and no other securities of the Company. MusclePharm agrees that if the SEC shall
issue comments on the Registration Statement, MusclePharm shall in good faith respond to such
comments as soon as practicable. MusclePharm will cause the Registration Statement to be declared
effective as promptly as practicable.

Source: MUSCLEPHARM CORP, 10-K/A, 2/8/2017
<!-- page 10 -->
(b) MusclePharm and Lender agree that, for purposes of determining the taxable income of Lender and
the tax expense, deduction or other corresponding charge of MusclePharm, in each case in connection
with the issuance of the Compensation Shares in accordance with this Section 8, the fair market
value of the Compensation Shares shall be the amount set forth in any third-party valuation report
delivered by Lender to MusclePharm within forty-five (45) days following the Issuance Date.
MusclePharm will promptly provide all information reasonably requested by Lender and/or its
valuation firm in connection with the preparation and delivery of such report. MusclePharm shall not
take any position for tax purposes inconsistent with such fair market value as so determined without
the consent of Lender; provided, however, that nothing herein shall preclude MusclePharm from
utilizing a different method of calculating the fair market value of the Compensation Shares for
financial accounting purposes if MusclePharm's Chief Financial Officer, audit committee and
independent auditors shall determine in good faith that such alternative calculation of the fair
market value of the Compensation Shares is required under generally accepted accounting principles
in the United States. (c) In connection with the issuance of the Compensation Shares, but without
limitation of Section 8(a) or the other terms and conditions in this Agreement, Lender hereby makes
the following representations to MusclePharm regarding the Compensation Shares: (i) Lender
understands that, as of the date hereof, none of the Compensation Shares have been registered under
the Securities Act of 1933, as amended ("Securities Act"), by reason of a specific exemption from
the registration provisions of the Securities Act, the availability of which depends upon, among
other things, the bona fide nature of the investment intent and the accuracy of Lender's
representations as expressed herein. Lender is acquiring all of the Compensation Shares for its own
account, not as a nominee or agent, for investment and not with a view to, or for resale in
connection with, any distribution or public offering thereof within the meaning of the Securities
Act. (ii) Lender understands that all of the Compensation Shares will constitute "restricted
securities" under the federal securities laws, inasmuch as it is being acquired from MusclePharm or
such other company in one or more transactions not involving a public offering and that under such
laws the Compensation Shares may not be resold without registration under the Securities Act or an
exemption therefrom. The certificates representing the Compensation Shares will be endorsed with a
legend to such effect. Lender has been informed and understands that (i) there are substantial
restrictions on the transferability of the Compensation Shares, and (ii) no federal or state agency
has made any finding or determination as to the fairness for public investment, nor any
recommendation nor endorsement, of the Compensation Shares. (iii) Lender, or Lender's business and
financial advisors, have substantial experience in evaluating and investing in private transactions
of securities in companies similar to MusclePharm and such other company and Lender acknowledges
that it can protect its own interests. Lender, or such advisors, have such knowledge and experience
in financial and business matters so that it is capable of evaluating the merits and risks of its
acceptance of all of the Compensation Shares of MusclePharm as compensation or otherwise.

Source: MUSCLEPHARM CORP, 10-K/A, 2/8/2017
<!-- page 11 -->
(iv) Lender is an "accredited investor" within the meaning of Rule 501 of Regulation D promulgated
under the Securities Act. (v) Lender understands that all books, records, and documents of
MusclePharm relating to it have been and remain available for inspection by him or his business and
financial advisors upon reasonable notice. Lender confirms that all documents requested have been
made available, and that it or such advisors have been supplied with all of the information
concerning MusclePharm that has been requested. Lender confirms that it or such advisors have
obtained sufficient information, in its and their judgment to evaluate the merits and risks of
receipt of the Compensation Shares as compensation or otherwise. Lender confirms that it has had the
opportunity to obtain such independent legal and tax advice and financial planning services as it
has deemed appropriate prior to making a decision to enter this Agreement. In making each such
decision, Lender has relied exclusively upon its experience and judgment, or that of such advisors,
upon such independent investigations as it, or they, deemed appropriate, and upon information
provided by MusclePharm in writing or found in the books, records, or documents of MusclePharm. (vi)
Lender is aware that the economic ownership of the Compensation Shares is highly speculative and
subject to substantial risks. Lender is capable of bearing the high degree of economic risk and
burdens of this venture, including, but not limited to, the possibility of a complete loss, the lack
of a sustained and orderly public market, and limited transferability of the Compensation Shares,
which may make the liquidation thereof impossible for the indefinite future. (vii) The offer to
issue the Compensation Shares as compensation to Lender was directly communicated to Lender or its
business or financial advisors by such a manner that it or such advisors were able to ask questions
of and receive answers from MusclePharm or a person acting on its behalf concerning this Agreement.
At no time was Lender presented with or solicited by or through any leaflet, public promotional
meeting, television advertisement, or any other form of general advertising. (viii) None of the
following information has ever been represented, guaranteed, or warranted to Lender, expressly or by
implication by any broker, MusclePharm, or agent or employee of the foregoing, or by any other
person: (1) The approximate or exact length of time that Lender will be required to remain as a
holder of any of the Compensation Shares; (2) The amount of consideration, profit, or loss to be
realized, if any, as a result of owning any of the Compensation Shares; or (3) That the past
performance or experience of MusclePharm, its officers, directors, associates, agents, affiliates,
or employees or any other person will in any way indicate or predict economic results in connection
with the plan of operations of MusclePharm or the return on any of the Compensation Shares.

Source: MUSCLEPHARM CORP, 10-K/A, 2/8/2017
<!-- page 12 -->
(d) MusclePharm represents, warrants and covenants to Lender that: (i) It has the full right, power
and authority to enter into this Agreement and to perform its obligations hereunder; (ii) it has
acquired all rights necessary to perform this Agreement and exploit the Licensed Products as
contemplated herein; (iii) the Licensed Products, any element thereof, or any advertising,
promotional or publicity materials supplied by Licensee or third parties hereunder will not contain
any language or material which is obscene, libelous, slanderous or defamatory; and (iv) the use of
the Licensed Product and the Lender's Name and Appearance rights as contemplated herein will not
violate or infringe the copyright, trademark, or other rights of any third party. (ii) It has duly
executed and delivered this Agreement and, assuming due authorization, execution and delivery by
Lender, this Agreement constitutes its legal, valid and binding agreement, enforceable against it in
accordance with its terms. (iii) It is duly organized, validly existing and in good standing under
the laws of the State of Nevada. It has all requisite power to own its properties and to carry on
the business as it is now being conducted and is intended to be conducted and is duly licensed or
qualified to do business in each jurisdiction in which the nature of its business or the ownership
or leasing of its properties makes such license or qualification necessary. (iv) Neither the
execution, delivery nor performance by it of this Agreement does or will (a) violate, conflict with
or result in the breach of any provision of its organizational documents, (b) conflict with or
violate any law or governmental authorization applicable to it or any of its assets or its business,
or (c) conflict with, result in any breach of, constitute a default (or event which with the giving
of notice or lapse of time, or both, would become a default) under, require any consent under, or
give to others any rights of termination, amendment or acceleration of, or result in the creation of
any encumbrance on any of its assets pursuant to, any note, bond, mortgage or indenture, contract,
agreement, lease, license, permit or franchise to which it is a party or by which any of its assets
is bound or affected. (v) It has timely filed all reports, schedules, forms, statements and other
documents required to be filed by it with the SEC pursuant to the reporting requirements of the
Exchange Act (all the foregoing filed prior to the date hereof and all exhibits included or
incorporated by reference therein and financial statements and schedules thereto and documents
included or incorporated by reference therein being sometimes hereinafter collectively referred to
as the "SEC Reports"). As of their respective filing dates, the SEC Reports complied in all material
respects with the requirements of the Exchange Act applicable to the SEC Reports (as amended or
supplemented), and none of the SEC Reports, at the time they were filed with the SEC, contained any
untrue statement of a material fact or omitted to state a material fact required to be stated
therein or necessary in order to make the statements therein, in light of the circumstances under
which they were made, not misleading.

Source: MUSCLEPHARM CORP, 10-K/A, 2/8/2017
<!-- page 13 -->
(vi) Set forth on Schedule 8(c) attached hereto is a true, complete, and accurate capitalization
table of MusclePharm as of the date hereof on a fully diluted basis, taking into account all equity
interests of MusclePharm issued or outstanding, or issuable upon conversion or exchange of any
security, and any rights, options, or warrants or other agreements to acquire any such equity
interests. 9. Termination: (a) This Agreement may be terminated by MusclePharm only: (i) In the
event Endorser is convicted of a felony. (ii) In the event Endorser is in material breach or default
of this Agreement, then MusclePharm may give written notice to Endorser of its intent to terminate
this agreement and in such notice shall set forth in reasonable detail the facts, circumstances or
events causing the alleged breach or default ("Endorser Events of Default"). The Endorser shall have
thirty (30) days' notice in which to cure the Endorser Events of Default to the reasonable and
objective satisfaction of Musclepharm. If the Endorser fails, refuses or is unable for any reason to
cure the Endorser Events of Default to the reasonable and objective satisfaction of MusclePharm,
then MusclePharm may terminate this Agreement by giving a written termination notice which shall be
effective on third calendar day after the date of such termination notice. (iii) This Agreement may
also be terminated by MusclePharm, upon fifteen days prior written notice, if death, or physical
disability, physical injury, or other incapacity lasting more than eight (8) weeks, causes Endorser
to be unable to perform a material amount of the personal or consulting services described in this
Agreement. (b) This Agreement may be terminated by the AS Parties only: (i) In the event MusclePharm
shall default under any indebtedness or financial obligations owed by MusclePharm in an amount in
excess of $1,000,000 including, without limitation, any failure to pay principal or interest
thereon, and such event of default or condition shall continue after any applicable grace period
specified in such agreement or instrument, and the effect of such event or condition results in an
actual acceleration of the maturity of such indebtedness or obligations; and/or (ii) If MusclePharm
(A) dissolves, liquidates or otherwise terminates its business or operations; (B) shall generally
not pay its debts or obligations as the same become due; (C) commences or becomes the subject of any
case or proceeding under the bankruptcy, insolvency or equivalent laws of the United States or any
other jurisdiction in the Territory which is not dismissed within 45 days; (D) has appointed for it
or for any substantial part of its property a court-appointed receiver, liquidator, assignee,
trustee, custodian, sequestrator or other similar official which is not dismissed within 45 days;
(E) makes an assignment for the benefit of its creditors; or (F) takes corporate action in
furtherance of any of the foregoing; and/or

Source: MUSCLEPHARM CORP, 10-K/A, 2/8/2017
<!-- page 14 -->
(iii) If the Company shall have (or with respect to the Company, the Chief Executive Officer or the
Chief Financial Officer of the Company shall have) (A) been charged with respect to a felony; (B)
been sued by a governmental agency; (C) received a subpoena from a governmental entity relating to
an investigation of the Company; or (D) become the subject of an investigation by a governmental
agency that, in each case, if adversely determined, could have, as determined by Endorser in good
faith (or, solely with respect to clause (D), as reasonably determined by the Endorser), a material
adverse effect on the Company's reputation or financial performance; and/or (iv) If the AS Parties
reasonably determine (based either on (A) internal MusclePharm information; (B) reports or other
credible information produced by established medical or scientific experts; or (C) multiple adverse
events reported to MusclePharm or in the media) that any of MusclePharm's products are harmful to
the human body or unsafe. (v) In the event Musclepharm is in material breach or default of this
Agreement, the AS Parties may give written notice to Musclepharm of intent to terminate, and such
notice shall set forth in reasonable detail the facts, circumstances or events causing the alleged
breach or default ("MusclePharm Events of Default"). Musclepharm shall have thirty (30) days' notice
in which to cure the MusclePharm Events of Default to the reasonable and objective satisfaction of
the terminating party. If Musclepharm fails, refuses or is unable for any reason to cure the
MusclePharm Events of Default to the reasonable and objective satisfaction of the terminating party,
then the the AS Parties may terminate this Agreement by giving a written termination notice which
shall be effective on third calendar day after the date of the termination notice (c) Effect of
Expiration/Termination: Upon expiration or termination of the Agreement for pursuant to Section 9
herein, Endorser shall have no further obligation to render any services whatsoever. MusclePharm
shall have no further right to use the rights granted to MusclePharm hereunder and all such rights
(including without limitation the rights to use the Name and Appearance Rights and Trademarks) shall
immediately and automatically be revoked and shall terminate and revert to the AS Parties
immediately with no "use-up period". Notwithstanding the foregoing, in the event the expiration of
this Agreement or termination of this Agreement by Musclepharm pursuant to paragraph 9(a),
MusclePharm shall be entitled to sell-off the remaining Licensed Products for six (6) months after
such expiration of this Agreement pursuant to paragraph 4(d) herein and shall continue to pay
Endorser the Royalty set forth in paragraph 7 herein. MusclePharm shall not be liable to pay any
compensation for services performed after the expiration or termination. In the event of a
termination by MusclePharm pursuant to paragraph 9(a)(i)-(ii), Musclepharm shall not be required to
pay Endorser any further compensation except for Royalties earned up until such termination date,
and provided, however, that if Musclepharm terminates this Agreement because of death, disability,
physical injury, or other incapacity of Endorser, if Endorser has performed all services required by
this Agreement for a particular Contract Year, then MusclePharm shall continue to be obligated to
compensate Lender with the full compensation amount of this Agreement for such Contract Year.
Notwithstanding anything contained herein, irrespective of the expiratation or termination of this
Agreement, the AS Parties shall always be entitled to retain and shall never be obligated to return
any monies paid and/or stock issued to Lender and/or Endorser pursuant to this Agreement. All
formulas used in the Licensed Products shall remain the property of MusclePharm, but all rights in
any packaging, promotional materials, and websites of the Licensed Products (including, without
limitation, pictures, the name, logos and trade dress) and all intellectual property of the AS
Parties shall revert back or otherwise be vested in the AS Parties; provided, however, that the
MusclePharm trade name, any MusclePharm trademarks, and MusclePharm logo used on the Licensed
Products shall remain the property of MusclePharm. The AS Parties shall also have the right to
purchase from MusclePharm the Arnold.com domain name for a purchase price equal to MusclePharm's
actual cost in acquiring such domain name (in the amount of Twenty Seven Thousand Five Hundred
($27,500) plus interest accruing at an annual rate of five percent (5%) from April 27, 2013 the date
of acquisition of such domain name through the date of the sale of such domain name.

Source: MUSCLEPHARM CORP, 10-K/A, 2/8/2017
<!-- page 15 -->
10. Expenses: In connection with any Appearance or Production Day that Endorser shall be required to
specifically travel solely for MusclePharm to make such Appearance or Production Day and shall not
already be in such geographic location for another commitment, MusclePharm shall be required to pay
the expenses associated with Endorser's travel, lodging, security and other expenses as set forth on
Exhibit "D" attached hereto. 11. Audit Rights: (a) The AS Parties shall have the right, upon at
least five (5) days written notice and no more than once each Contract Year of the Term to inspect
MusclePharm's books and records and all other documents and material in the possession of or under
the control of MusclePharm with respect to the Licensed Products at the place or places where such
records are normally retained by MusclePharm. The AS Parties shall have reasonable access thereto
for such purposes and shall be permitted to be able to make copies thereof and extracts therefrom.
(b) MusclePharm shall keep complete and accurate books of account for the preceding three years from
the date of termination and expiration. In the event that any shortfalls, inconsistencies or
mistakes are discovered, they shall immediately be rectified by MusclePharm at its sole cost and
expense. (c) In the event a shortfall in the amount of five percent (5%) or more is discovered,
MusclePharm shall reimburse the AS Parties for the cost of the audit including any reasonable
attorney's fees incurred in connection therewith. (d) MusclePharm agrees to preserve and keep
accessible and available to the AS Parties all relevant books and records for a period of at least
three (3) years following the expiration or termination of the Agreement. 12. Sales and Marketing
Plan And AS Product Line and Trademarks: (a) MusclePharm shall utilize its commercially reasonable
efforts to advertise and promote the Licensed Products at its own expense and to sell the Licensed
Products through the Distribution Channels worldwide as contemplated herein during the Term and to
promote both the goodwill of the Endorser and the market reputation of the Licensed Products.
MusclePharm will conduct its activities relating to the marketing of the Licensed Products in a
professional manner. In that connection:

Source: MUSCLEPHARM CORP, 10-K/A, 2/8/2017
<!-- page 16 -->
(b) Prior to the execution and delivery of this Agreement with respect to the First Contract Year
and at least ninety (90) days prior to the beginning of each Contract Year of the Term, MusclePharm
will provide the AS Parties with a detailed marketing plan (the "Marketing Plan"). The AS Parties
shall be entitled to approve the Marketing Plan, such approval not to be unreasonably withheld or
delayed. MusclePharm shall use its commercially reasonable efforts to market and distribute the
Licensed Products, and MusclePharm shall allocate between $3,000,000 and $5,000,000 in the First
Contract Year and $5,000,000 in each subsequent Contract Year (including any renewal terms if any)
toward the marketing of the Licensed Products (the "Marketing Budget"); it being understood that the
parties may mutually decide not to deploy the full Marketing Budget in any Contract Year if in the
good faith determination by the parties that the deployment of the full Marketing Budget is
unnecessary to achieve its projected revenue targets in connection with the sale of the Licensed
Products. Notwithstanding the foregoing, MusclePharm shall be entitled to re-allocate marketing
dollars in its good faith judgment exercisable in its sole discretion from the media forms set forth
in the Marketing Plan to promote the Licensed Products in other media forms. (c) AS Product Line and
Trademarks. The parties hereto agree and understand that the AS Product Line will be marketed and
promoted as a distinct product line from MusclePharm's overall product lines. Any trademarks and
trade dress used as the brand of the AS Product Line shall be owned by the AS Parties (as among
them, to be determined among them) and shall be included within the defined term Trademarks as used
in this Agreement. Any trademark used as a brand for an individual product in the AS Product Line,
as opposed to a brand for the line of products, whether or not is based upon or derived from the
Name and Appearance Rights or is independently developed also shall be owned by the AS Parties (as
among them, to be determined among them) and as shall be included within the defined term Trademarks
as used in this Agreement. Notwithstanding the foregoing, the MusclePharm trade name, any
MusclePharm trademarks, and MusclePharm logo used on the Licensed Products shall remain the property
of MusclePharm. 13. Quality Control: (a) MusclePharm acknowledges and agrees that, in order to
maintain the goodwill and integrity of the Endorser, the Name and Appearance Rights, and the
Trademarks (the "Endorser IP"), the Licensed Products shall be of a standard and of such style,
appearance and quality as to protect and enhance the goodwill associated with the Endorser IP, which
standard the AS Parties may from time to time prescribe and which, in any event, shall be of
substantially the same or better quality than the samples previously provided by MusclePharm to
Endorser. To this end, MusclePharm will use the approval form attached hereto as Exhibit "E" to
obtain required approvals under this Agreement (including, ingredients contained in the Licensed
Products). Prior to any use of any of the Endorser IP, MusclePharm shall submit to the AS Parties
for the AS Parties' prior written approval all artwork, photos, images, writings, advertising
campaigns, slogans, claims made and other Name and Appearance Rights associated with the Endorser
IP, samples of materials and design of the Licensed Products on which the Endorser IP are to appear
and of all advertising, press and promotional literature which MusclePharm intends to use in the
marketing or merchandising of the Licensed Products using the submission form in Exhibit "E"
attached hereto. The AS Parties shall respond to any such approval request within ten (10) business
days. To the extent that the AS Parties shall fail to respond within such ten (10 day) period, the
submissions shall be deemed disapproved. Should MusclePharm desire to submit the same request for
approval, the AS Parties shall respond within five (5) days detailing the reason for disapproval.
Should the AS Parties fail to respond in this last Five (5) business day period, submission shall be
deemed approved. In addition, MusclePharm shall send, at its expense, at a minimum, two (2)
representative samples of each Licensed Products, at each of the concept, pre-production and
production stages, to the AS Parties at the address set forth in Section 20 below for prior
approval. During the Term, MusclePharm will also send two (2) representative samples of the Licensed
Products to the AS Parties at the address set forth in Section 20 below upon request so that the AS
Parties can determine whether the quality of the Licensed Products bearing the Endorser IP is being
maintained.

Source: MUSCLEPHARM CORP, 10-K/A, 2/8/2017
<!-- page 17 -->
(b) MusclePharm shall at all reasonable times during the Term (but no more than once during each
Contract Year of the Term), and upon reasonable notice, permit the AS Parties to send their
authorized representatives to inspect the facilities of MusclePharm or its agents in order to
confirm that the production of the Licensed Products hereunder is in compliance with the quality
standards set out herein and, at MusclePharm's expense, randomly test the formulas of the Licensed
Products for quality control purposes, although the AS Parties will have no obligation to do so. (c)
The Licensed Products shall be of the highest quality and manufactured, produced, sold, distributed
and promoted in strict compliance with all applicable laws and regulations, and be of substantially
the same or better quality as the samples previously submitted by MusclePharm. MusclePharm shall be
responsible for ensuring that the products are properly designed and manufactured for safe use and
shall promptly and fairly address and resolve all consumer complaints and warranty claims.
MusclePharm hereby acknowledges that the AS Parties are not competent to determine whether the
products are safe for sale and/or distribution to the public at large. Accordingly, the AS Parties'
approval rights relate to aspects of quality and not to a determination of the safety of the
products and any approvals given by the AS Parties of the products shall in no way detract from the
MusclePharm's obligations hereunder. (d) The License Products will be doctor-formulated and
clinically tested at Stanford University or North Carolina University or another university mutually
acceptable to the parties hereto to prove the effectiveness of the Licensed Products. All Licensed
Products will be tested by Informed Choice or another independent testing laboratory mutually
acceptable to the parties hereto to be certified "Banned Substance Free" for athletes. (e)
Manufacturers will comply with the requirements set forth in this Section 13(e): (i) MusclePharm and
the manufacturers will not use child labor (not including child actors or models) in the
manufacturing, packaging, marketing, advertising, or distribution of the Licensed Products.

Source: MUSCLEPHARM CORP, 10-K/A, 2/8/2017
<!-- page 18 -->
(ii) MusclePharm and the manufacturers will only employ persons whose presence is voluntary.
MusclePharm and the manufacturers will not use any forced or involuntary labor. (iii) MusclePharm
and the manufacturers will treat each employee with dignity and respect, and will not use corporal
punishment, threats of violence, abuse, or other forms of physical, sexual, psychological, or verbal
harassment. (iv) MusclePharm and the manufacturers will not unlawfully discriminate in any hiring or
employment practices. (v) MusclePharm and the manufacturers will, at a minimum, materially comply
with all applicable wage and hour laws, rules, regulations, and industry standards. MusclePharm and
the manufacturers agree that, where local industry standards are higher than applicable legal
requirements, MusclePharm and manufacturer will meet the higher local standards. (vi) MusclePharm
and the manufacturers will materially comply with all applicable workplace laws, rules, regulations,
and industry standards, ensuring, at a minimum, reasonable access to potable water and sanitary
facilities, fire safety, and adequate lighting and ventilation. (vii) MusclePharm and the
manufacturers will respect the rights of employees to associate, organize, and bargain collectively
in a lawful and peaceful manner, without penalty or interference. (viii) MusclePharm and the
manufacturers will materially comply with all applicable environmental laws, rules, regulations, and
industry standards. (ix) If MusclePharm becomes aware that any manufacturer has used or is using
Endorser IP for any unauthorized purpose, MusclePharm, will immediately notify the AS Parties and,
if so instructed by the AS Parties, will cause such manufacturer to cease such use immediately. (f)
Unless the AS Parties expressly agree in advance and in writing otherwise, all Licensed Products
shall be manufactured within the fifty states of the United States of America and in no other
locations. 13A. Ownership and Registration of Trademarks and Name and Appearance Rights: (a) During
the Term and after expiration or termination of this Agreement, MusclePharm shall not contest or
otherwise challenge or attack the AS Parties' rights in the Trademarks or Name and Appearance Rights
or the validity of the license being granted herein. (b) During the Term and after expiration or
termination of this Agreement, MusclePharm shall not use any trademark which so substantially
resembles any of the Trademarks or Name and Appearance Rights as to be likely to deceive or cause
confusion or mistake or which might amount to passing-off; provided however, nothing herein shall
preclude MusclePharm from using any of the intellectual property to be retained by MusclePharm
contemplated pursuant to Section 9(f) of this Agreement after the termination of this Agreement.

Source: MUSCLEPHARM CORP, 10-K/A, 2/8/2017
<!-- page 19 -->
(c) MusclePharm recognizes the value of the good will associated with the Trademarks and Name and
Appearance Rights and acknowledges that the Trademarks and Name and Appearance Rights, and all
rights therein and the good will pertaining thereto, belong exclusively to the AS Parties. (d)
MusclePharm agrees that its use of the Trademarks and Name and Appearance Rights shall inure to the
benefit of the AS Parties and that MusclePharm shall not, at any time, acquire any rights in the
Trademarks and/or Name and Appearance Rights by virtue of any use it may make of the Trademarks
and/or Name and Appearance Rights. (e) MusclePharm agrees that any copyrights in works created based
upon the Trademarks and/or Name and Appearance Rights shall become the rights of the AS Parties (as
among them to be determined among them). MusclePharm irrevocably and unconditionally transfers and
assigns to the AS Parties in perpetuity and throughout the universe any and all of MusclePharm's
right, title, and interest, if any (including, without limitation, the rights generally known as
'moral rights') in and to all works, including any packaging, advertising and promotional materials,
and other materials based upon the Trademarks and/or Name and Appearance Rights, all of which shall,
upon their creation, become and remain the property of the AS Parties. All such works based upon the
Trademarks and/or Name and Appearance Rights shall be prepared by an employee-for- hire of
MusclePharm (under MusclePharms's sole supervision, responsibility, and monetary obligation) or as a
work-for-hire by a third party who assigns to the AS Parties in writing and in perpetuity throughout
the universe all right, title, and interest in the same provided however, nothing herein shall
preclude MusclePharm from using any of the intellectual property to be retained by MusclePharm
contemplated pursuant to Section 9(f) of this Agreement after the termination of this Agreement. (f)
Injunctive Relief. MusclePharm acknowledges that the unauthorized use of the Name and Appearance
Rights and Trademarks will result in immediate and irreparable damages to the AS Parties and that
the AS Parties would have no adequate remedy at law for such authorized use. MusclePharm further
agrees that in the event of any unauthorized use of the Name and Appearance Rights and/or the
Trademarks, the AS Parties, in addition to all other remedies available to them hereunder, shall be
entitled to injunctive relief against any such unauthorized use as well as such other relief as any
court with jurisdiction may deem just and proper. (g) Registration. If the AS Parties decide in
their sole discretion after consulting with MusclePharm to register the Trademarks and/or Name And
Appearance Rights as a trademark for the Licensed Products and/or any Promotional Products or to
register the copyrights in any works based upon the Trademarks and/or the Name And Appearance
Rights, MusclePharm will cooperate to provide information, samples, and documents as reasonably
requested by the AS Parties to enable the AS Parties to comply with the application, registration,
license recordal, and other requirements of any applicable jurisdictions. If the AS Parties decide
to register Trademarks and/or Name And Appearance Rights as a trademark for the Licensed Products,
MusclePharm will reimburse the AS Parties for any reasonable expenses incurred in registering in the
United States and Canada and such other countries as the parties shall mutually agree upon.

Source: MUSCLEPHARM CORP, 10-K/A, 2/8/2017
<!-- page 20 -->
14. Independent Contractor: It is expressly agreed that Endorser is acting as an independent
contractor in performing his services hereunder. MusclePharm shall carry no worker's compensation
insurance or any health, accident or disability insurance to cover Endorser. MusclePharm shall not
pay any contributions to Social Security, unemployment insurance, federal or state withholding
taxes, nor provide any other contributions or benefits that might be expected in an
employer-employee relationship. Endorser shall be solely responsible and liable for reporting and
paying all federal and state income or other taxes applicable to the Endorser's compensation under
this Agreement and MusclePharm will provide Lender with an IRS Form 1099 at the end of each calendar
year in which compensation is paid to Lender. It is further understood and expressly agreed by
Endorser that he has no right or authority to incur expenses, obligations or liabilities in the name
of or binding on MusclePharm, and he shall not represent to third parties that he has any
relationship (e.g., employer-employee or principal-agent) with MusclePharm other than the
independent contractor arrangement set forth in this Agreement. 15. Indemnification. (a) By the AS
Parties. The AS Parties will at all times indemnify and hold MusclePharm and its agents and
licensees harmless from and against any and all claims, damages, liabilities, costs and expenses
(including reasonable outside attorneys' fees), arising out of any breach by the AS Parties of any
warranty or agreement made by the AS Parties hereunder. In no event shall the AS Parties'
indemnification obligations to MusclePharm hereunder exceed the after-tax value of the Cash
Consideration received by Lender under this Agreement. (b) By MusclePharm. MusclePharm agrees to
protect, indemnify, save, defend, and hold harmless the AS Parties, their related companies,
affiliates, and partners, and each of their assigns, agents, representatives, officers, directors,
shareholders, and employees from and against any and all expenses, damages, liabilities, claims,
suits, actions, judgments, costs and expenses whatsoever (including reasonable attorney's fees; both
those incurred in connection with the defense or prosecution of the indemnifiable claim and those
incurred in connection with the enforcement of this provision), caused by, arising out of, or in any
way connected with (i) any injury, death, or other harm or claim connected with, or claimed defect
in, Products or Licensed Products provided, manufactured, produced, marketed, promoted, sold, and/or
distributed by MusclePharm (including any party affiliated with MusclePharm); (ii) any material
inaccuracy or misrepresentation by MusclePharm in this Agreement; (iii) any advertisement and/or
promotion of MusclePharm, its Products, or Licensed Products, including but not limited to any use
of the materials produced pursuant to this Agreement, as well as MusclePharm's advertising/promotion
campaign described above in this Agreement and/or (iv) any breach of this Agreement and/or in
connection with this Agreement. No settlement will be entered into by the AS Parties without
MusclePharm's prior written approval.

Source: MUSCLEPHARM CORP, 10-K/A, 2/8/2017
<!-- page 21 -->
16. Exclusivity; Non-Competition: (a) During the term of this Agreement, or any extensions of this
Agreement, Endorser and the Lender hereby agree and warrant that it will not enter into any other
endorsement agreement for the use of Endorser's name, image and/or likeness for advertising,
marketing and/or endorsement of any other dietary supplements during the Term of this Agreement.
Notwithstanding the foregoing, the following will not be a breach of this Agreement: (i) Endorser's
performance of services or appearing in the news or informational portion of any radio, TV or film
or entertainment program regardless of products or services therein or sponsorship thereof; (ii)
Endorser's participation in movies or TV programs as well as merchandising, commercial tie-ins
and/or product placements utilizing Endorser, or (iii) Endorser's performance of services,
appearance or use of his name, likeness in connection with charitable events, sports events,
organizations, regardless of usage of products or services and/or sponsorship thereof. (b) Endorser
shall not use or provide endorsements or testimonials for products that compete with MusclePharm
Products or the Licensed Products. Any failure of Endorser to disclose such conflicting interests,
or any breach of this Section, shall be deemed a material breach of the Agreement. Endorser's duty
not to compete with the business of MusclePharm shall continue for a period of one year following
the expiration or termination of this Agreement. Endorser's non-competition obligation shall not be
required in the event of a material breach of this Agreement by MusclePharm. (c) Notwithstanding the
foregoing or anything else contained herein, this Agreement shall not prevent or shall in any manner
restrict Endorser from advertising, marketing and or endorsing products (or other companies which
manufacture such products) which incidentally contain dietary supplements (including without
limitation protein, vitamins, minerals, amino acids, herbs, legal performance enhancing substances)
provided the primary purpose of such product or company is not to sell or market a dietary
supplement. 17. [RESERVED.] 18. Assignment: The license granted by this Agreement is personal to
MusclePharm. Except as set forth below, MusclePharm shall not assign or otherwise transfer, license,
sublicense, or delegate any rights or obligations under this Agreement without the express prior
written consent of the AS Parties. Neither party shall voluntarily or by operation of law assign or
otherwise transfer the rights and/or obligations incurred pursuant to the terms of this Agreement
without the prior written consent of the other party. Any attempted assignment or transfer by a
party of their rights and/or obligations without such consent shall be void. Nothwithstanding the
foregoing, this Agreement may be assigned without the AS Parties' consent by MusclePharm in
connection with a change of control transaction; provided that the acquirer of MusclePharm shall
have financial resources substantially similar or greater than MusclePharm and shall specifically
assume the obligations of MusclePharm under this Agreement in writing prior to the consummation of
the change of control transaction. In addition, notwithstanding the foregoing, the Endorser and the
Lender shall be entitled to sell, transfer and assign the Cash Compensation and the Compensation
Shares (subject to compliance with the restrictions set forth in Section 8(a) above and federal and
state securities laws) to third parties; provided, however, that Endorser shall remain solely liable
to fulfill all of his obligations under this Agreement.

Source: MUSCLEPHARM CORP, 10-K/A, 2/8/2017
<!-- page 22 -->
19. Modification of Agreement: The parties may modify this Agreement hereto only by a written
supplemental agreement executed by both parties. 20. Notice: Any notice required or permitted to be
given hereunder shall be sufficient if given in writing, and sent by registered or certified mail,
postage prepaid, or by courier such as FedEx, addressed as follows: If to MusclePharm: MusclePharm
Attn: Brad Pyatt; CEO 4721 Ironton Street Denver, CO 80237 With a copy to: Sichenzia Ross Friedman
Ference LLP 61 Broadway, 32nd Floor New York, NY 10006 Attn: Harvey J. Kesner, Esq. Edward H.
Schauder, Esq If to the AS Parties: Arnold Schwarzenegger c/o Main Street Advisors, Inc. 3110 Main
Street, Suite #310 Santa Monica, CA 90405 Marine MP, LLC 3110 Main Street, Suite #300 Santa Monica,
CA 90405 ATTN: Arnold Schwarzenegger Fitness Publications, Inc. 3110 Main Street, Suite #300 Santa
Monica, CA 90405 ATTN: Arnold Schwarzenegger

Source: MUSCLEPHARM CORP, 10-K/A, 2/8/2017
<!-- page 23 -->
With a copies to: Main Street Advisors 3110 Main Street, Suite 310 Santa Monica, CA 90405 Attn: Paul
Wachter & Alex Cohen and Bloom Hergott Diemer Rosenthal LaViolette Feldman Schenkman & Goodman, LLP
150 South Rodeo Drive, 3rd Floor Beverly Hills, CA 90212 Attn: Patrick M. Knapp, Esq. and Loeb &
Loeb LLP 10100 Santa Monica Blvd., Suite 2200 Los Angeles, Ca 90067 Attn: David W. Grace or to such
other address as the parties hereto may specify, in writing, from time to time. Written notice given
as provided in this Section shall be deemed received by the other party two business days after the
date the mail is stamped registered or certified and deposited in the mail, or deposited with
courier. 21. Governing Law: This Agreement has been executed and delivered in Los Angeles County in
the State of California, and its interpretation, validity and performance shall be construed and
enforced in accordance with the laws of the State of California. The exclusive venue for any
proceeding to interpret, construe or enforce this Agreement in accordance with Section 22 below
shall be Los Angeles County, California. 22. Dispute Resolution and Attorneys' Fees: (a) Any
dispute, claim or controversy arising out of or relating to this Agreement or the breach,
termination, enforcement, interpretation or validity thereof, including the determination of the
scope or applicability of this agreement to arbitrate, shall be determined by arbitration in Los
Angeles County before an arbitrator who is a retired U.S. District Court judge. The arbitration
shall be administered by JAMS pursuant to its Comprehensive Arbitration Rules and Procedures.
Judgment on the Award may be entered in any court having jurisdiction. The parties adopt and agree
to implement the JAMS Optional Arbitration Appeal Procedure (as it exists on the effective date of
this Agreement) with respect to any final award in an arbitration arising out of or related to this
Agreement. Nothing in this agreement clause shall preclude parties from seeking provisional or
injunctive relief remedies in aid of arbitration from a court of appropriate jurisdiction.

Source: MUSCLEPHARM CORP, 10-K/A, 2/8/2017
<!-- page 24 -->
(b) In any arbitration arising out of or related to this Agreement, the arbitrator(s) shall award to
the prevailing party, if any, the costs and attorneys' fees reasonably incurred by the prevailing
party in connection with the arbitration. If the arbitrator(s) determine a party to be the
prevailing party under circumstances where the prevailing party won on some but not all of the
claims and counterclaims, the arbitrator(s) may award the prevailing party an appropriate percentage
of the costs and attorneys' fees reasonably incurred by the prevailing party in connection with the
arbitration. 23. Binding Effect: This Agreement when signed by the parties shall be binding upon the
parties, and their respective heirs, successors or legal representatives. 24. Representations,
Warranties and Covenants: (a) The AS Parties represent and warrant that (i) they hold all such
rights, title, and interest in his Name and Appearance Rights as are required to permit them to
enter into this Agreement; (ii) they have the full right, power and authority to enter into this
Agreement; (iii) they have not authorized any third party to create products similar to the AS
Product Line, and (iv) they do not own any equity interest in any companies that produce nutrition
and/or supplement products. MusclePharm expressly acknowledges that the AS Parties have not
ascertained the worldwide availability of the Name and Appearance Rights and related Trademarks for
use as trademarks on the Licensed Products or whether such use would infringe the rights of any
other entities. EXCEPT AS SPECIFICALLY SET FORTH HEREIN, THE AS PARTIES EXPRESSLY DISCLAIM ALL
REPRESENTATIONS AND WARRANTIES, EXPRESS OR IMPLIED, IN CONNECTION WITH THE TRADEMARKS AND NAME AND
APPEARANCE RIGHTS, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF TITLE, NON-INFRINGEMENT
OF INTELLECTUAL PROPERTY RIGHTS, MERCHANTABILITY, AND FITNESS FOR A PARTICULAR PURPOSE. THE AS
PARTIES SHALL NOT BE LIABLE TO MUSCLEPHARM OR ANY THIRD PARTY FOR ANY DAMAGES ARISING FROM OR
RELATING TO MUSCLEPHARM'S USE OF THE TRADEMARKS AND NAME AND APPEARANCE RIGHTS. IN NO EVENT SHALL
THE AS PARTIES BE LIABLE FOR SPECIAL, CONSEQUENTIAL, OR PUNITIVE DAMAGES. (b) MusclePharm
represents, warrants and covenants that (i) it has the full right, power and authority to enter into
this Agreement; (ii) it has acquired all rights necessary to perform this Agreement and exploit the
Licensed Products as contemplated herein; (iii) the Licensed Products, any element thereof, or any
advertising, promotional or publicity materials supplied by Licensee or third parties hereunder will
not contain any language or material which is obscene, libelous, slanderous or defamatory; (iv) the
use of the Licensed Product and the Name and Appearance Rights as contemplated herein will not
violate or infringe the copyright, trademark, or other rights of any third party; (v) the Products
and Licensed Products will comply in all material respects with all applicable laws and regulations
and will be safe for human consumption.

Source: MUSCLEPHARM CORP, 10-K/A, 2/8/2017
<!-- page 25 -->
25. Payments: All cash payments shall be made via wire transfer to the Lender to an account provided
by Lender or his representative. 26. Confidentiality: The parties acknowledge that during the course
of this Agreement the parties will provide to each other certain proprietary and confidential
information that is held and maintained confidentially by each party. Each party shall be entitled
to share such confidential information received by such party only with such party's
representatives, legal and accounting advisors who shall agree to be bound by the confidentiality
obligations set forth in this Section 26. During the term of this Agreement and for three (3) years
thereafter, each party shall hold in strict confidence all such information. This obligation shall
not apply to any information which: (a) becomes known to the general public through no fault of
either party; (b) is required to be disclosed in the enforcement of rights hereunder, or (c) is
required to be disclosed by any state or federal statue, regulation or court order. 27. Insurance:
MusclePharm shall, throughout the Term of the Agreement and for a period of not less than four years
thereafter, obtain and maintain at its own cost and expense from a qualified insurance company
licensed to do business in California and New York, a commercial general liability insurance policy
including coverage for contractual liability (applying to the terms and conditions of this
agreement), product liability, personal injury liability, and advertiser's liability, in a form
approved by the AS Parties, in the amount of at least Five Million Dollars (US$5,000,000) per
occurrence naming the AS Parties (for the avoidance of doubt, specifically including each of Lender,
Endorser, and Fitness) as additional named insureds. Without limiting the generality of the
foregoing, such policy shall provide protection against any and all claims, demands, and causes of
action arising out of any defects or failure to perform, alleged or otherwise, of the Products and
Licensed Products or any material used in connection therewith or any use thereof. The policy shall
provide for ten (10) days notice to the AS Parties from the insurer by Registered or Certified Mail,
return receipt requested, in the event of any modification, cancellation, or termination thereof.
MusclePharm agrees to furnish the AS Parties a certificate of insurance evidencing same within
thirty (30) days after execution of this Agreement and, in no event, shall MusclePharm manufacture,
distribute, advertise, or sell the Licensed Products prior to receipt by the AS Parties of such
evidence of insurance. MusclePharm shall be responsible to provide for any appearances pursuant to
this Agreement by Endorser appropriate certificates of insurance with coverage limits of at least
Five Million Dollars (US$5,000,000) per occurrence endorsed to name the AS Parties as additional
named insureds with respect to claims arising out of appearances by Endorser. MusclePharm shall be
responsible to pay the deductible under any such insurance policies with respect to any claims made
under such policies.

Source: MUSCLEPHARM CORP, 10-K/A, 2/8/2017
<!-- page 26 -->
28. Entire Agreement: This Agreement contains the entire contract of the parties with respect to the
subject matter hereof and supersedes all agreements and understandings between the parties
concerning the subject matter hereof. The language in all parts of this Agreement shall in every
case be construed simply according to its fair meaning. 29. Infringement: (a) The AS Parties shall
have the exclusive right, but not the obligation, to prosecute, defend, and/or settle at their own
cost and expense and in their sole discretion, all actions, proceedings and claims involving an
infringement of the Name and Appearance Rights or Trademarks and to take any other action that they
deem proper or necessary in their sole discretion for the protection and preservation of such
rights. In their sole option, the AS Parties may take any action described above in one or more of
their own names and MusclePharm will cooperate fully therewith. MusclePharm shall have the exclusive
right, but not the obligation, to prosecute, defend and/or settle at its own cost and expense and in
its sole discretion, all actions, proceedings and claims involving an infringement of the
MusclePharm trade name, trademarks, and logo even if the matter involves the Licensed Products and
to take any other action that its deem proper or necessary in its sole discretion for the protection
and preservation of such rights. In its sole option, MusclePharm may take any action described above
in its own name and the AS Parties will cooperate fully therewith if the matter involves the
Licensed Products. All expenses of any action taken by a party hereto as contemplated above shall be
borne by such party, and all relief granted in connection therewith shall be solely for the account
of such party. A party hereto will not claim or reserve any rights against the other party as the
result of any such action contemplated above. (b) Each party shall notify the other party promptly
of any adverse, pending or threatened action in respect of an infringement of the Name and
Appearance Rights or Trademarks or any infringement of the Licensed Products, as the case may be,
and of any use by third parties that would or might tend to be adverse to the rights of the parties
hereto, as applicable. * * * THE REMAINDER OF THIS PAGE INTENTIONALLY LEFT BLANK. * * *

Source: MUSCLEPHARM CORP, 10-K/A, 2/8/2017
<!-- page 27 -->
This Agreement when signed and dated by all parties shall be deemed to be made, accepted and
delivered in the City and County of Los Angeles, California, regardless of where the Agreement is
executed by the parties. MusclePharm Corporation By: /s/Brad Pyatt Name: Brad Pyatt Title:CEO Dated:
July 26, 2013 Marine MP, LLC By: /s/ Paul Wachter Name: Paul Wachter Title: Manager Dated: July 26,
2013 By: /s/Arnold Schwarzenegger Arnold Schwarzenegger Dated: July 26, 2013 Fitness Publications,
Inc. By: /s/Arnold Schwarzenegger Name: Title: Dated: July 26, 2013

Source: MUSCLEPHARM CORP, 10-K/A, 2/8/2017
<!-- page 28 -->
EXHIBIT A PROMOTIONAL PRODUCTS Promotional Products shall include the following products: ·
T-Shirts; · Golf Shirts; · Hats; · Visors; · Wristbands and Headbands; and · Shakers. Each and every
of the foregoing Promotional Products must be specifically approved in advance and in writing by the
AS Parties and shall always prominently include the MusclePharm logo or images of the Licensed
Products.

Source: MUSCLEPHARM CORP, 10-K/A, 2/8/2017
<!-- page 29 -->
Exhibit "B" Royalty Statement Company Name:MusclePharm Corporation Licensee Address:4721 Ironton
Street, Unit A, Denver, Colorado 80239 For Quarter Ending:____________________

Customer Name

Item/SKU Number or Description

Invoice Price

No. Units Sold

Sales Invoice

Less Returns

Net Sales

Royalty Percentage

Royalty Amount Total Royalty Earned This Quarter: $ Total Earned Royalty To Date (This Contract
Year): $ TOTAL $ Less Paid and Un-Recouped Minimum Guarantee: $ ([ ]) Balance Due From the Company
and Payable This Quarter: $ I hereby certify that the above is accurate and complete. Signature Date
Title Printed Name Submit to: Name: Email: Tel: Date Received:

Source: MUSCLEPHARM CORP, 10-K/A, 2/8/2017
<!-- page 30 -->
Exhibit "C" Section (1) Guaranteed Minimum Royalty during the initial Term: Contract Year Minimum
Royalty Timing of Payment One $1,500,000 $500,000 payment due on the following dates: July 23, 2013;
October 1, 2013; February 1, 2014 Two $2,000,000 $666,666.66 payment due on the following dates:
July 23, 2014; October 1, 2014; February 1, 2015 Three $2,500,000 $833,333.33 payment due on the
following dates: July 23, 2015; October 1, 2015; February 1, 2016

Source: MUSCLEPHARM CORP, 10-K/A, 2/8/2017
<!-- page 31 -->
Section (2) Guaranteed Minimum Royalty during the First Additional Term: In the event that the
Renewal Threshold is achieved in the Third Contract Year, during the First Additional Term the
Minimum Royalty and Timing of Payment shall be as follows: Contract Year Minimum Royalty Timing of
Payment Four $2,500,000 $833,333.33 payment due on the following dates: July 23, 2016; October 1,
2016; February 1, 2017 Five $2,500,000 $833,333.33 payment due on the following dates: July 23,
2017; October 1, 2017; February 1, 2018 Six $2,500,000 $833,333.33 payment due on the following
dates: July 23, 2018; October 1, 2018; February 1, 2019

Source: MUSCLEPHARM CORP, 10-K/A, 2/8/2017
<!-- page 32 -->
Section (3) Guaranteed Minimum Royalty during the Second Additional Term: In the event that the
Second Renewal Threshold is achieved in the Sixth Contract Year, during the Second Additional Term
the Minimum Royalty and Timing of Payment shall be as follows: Contract Year Minimum Royalty Timing
of Payment Seven $5,000,000 $1,666,666.66 payment due on the following dates: July 23, 2019; October
1, 2019; February 1, 2020 Eight $5,000,000 $1,666,666.66 payment due on the following dates: July
23, 2020; October 1, 2020; February 1, 2021 Nine $5,000,000 $1,666,666.66 payment due on the
following dates: July 23, 2021; October 1, 2021; February 1, 2022

Source: MUSCLEPHARM CORP, 10-K/A, 2/8/2017
<!-- page 33 -->
Exhibit "D" Endorser Expenses MusclePharm shall be responsible for the following expenses: ·
Exclusive private jet transportation (Netjets, or as otherwise indicated by Endorser) to be arranged
through M. Paul Wachter or Alex Cohen; · A first class suite at a hotel of Endorser's choice; · A
security detail; and · A reasonable per diem expense allowance while Endorser is on location.

Source: MUSCLEPHARM CORP, 10-K/A, 2/8/2017
<!-- page 34 -->
Exhibit "E" Approval Request Response Tracking Number: _____________________ CONCEPT:
________________________________ Date: __________________ Approved. Supply pre-production sample as
soon as available for approval. Not approved, pending changes indicated. Re-submit concept sample
for approval. Not approved. PRE-PRODUCTION SAMPLE: _____________________ Date: _____________
Approved. Supply production sample as soon as available for approval. Not approved, pending changes
indicated. Re-submit pre-production sample for approval. Not approved. PRODUCTION SAMPLE:
_______________________ Date: ______________ Approved. Supply production sample for Arnold
Schwarzenegger's records. Approved with changes for next production run - please re-submit. Not
approved, pending changes indicated. Re-submit production sample for approval. Not approved. Cease
all manufacture, sale, display, marketing, and distribution. COMMENTS: Signature: Title:

Source: MUSCLEPHARM CORP, 10-K/A, 2/8/2017
