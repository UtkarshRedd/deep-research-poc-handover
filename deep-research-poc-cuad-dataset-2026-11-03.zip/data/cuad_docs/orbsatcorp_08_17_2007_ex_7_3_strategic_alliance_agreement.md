<!-- page 1 -->
# Strategic Alliance Agreement
| Field | Value |
|---|---|
| Document Type | Strategic Alliance Agreement |
| Agreement Date | 2005-09-09 |
| Parties | UTEK Corporation ("UTK"); World Energy Solutions ("AVDU") |
| Source | CUAD v1 / ORBSATCORP_08_17_2007-EX-7.3-STRATEGIC ALLIANCE AGREEMENT |

Exhibit 7.3

STRATEGIC ALLIANCE AGREEMENT

This Strategic Alliance Agreement is made and entered into this 9th day of September 2005, by and
between UTEK Corporation ("UTK"), 202 South Wheeler Street, Plant City, Florida 33566 a Delaware
corporation, and World Energy Solutions, ("AVDU"), 3900A 31st Street North, St. Petersburg, Florida,
a Florida corporation.

WITNESSETH:

WHEREAS, AVDU desires to engage UTK to provide the services as set forth in this Agreement, and

WHEREAS, UTK is agreeable to provide these services.

NOW THEREFORE, in consideration of the mutual promise made in this Agreement, and for other good and
valuable consideration, the receipt and sufficiency of which is hereby acknowledged, the parties
hereto agree as follows:

I. ENGAGEMENT

AVDU hereby retains UTK to provide those services as defined herein and UTK hereby agrees to the
appointment on the terms and conditions hereinafter set forth and agrees to use commercially
reasonable efforts in providing said services.

II. INDEPENDENT CONTRACTOR

UTK shall be, and in all respects be deemed to be, an independent contractor in the performance of
its duties hereunder.

A. AVDU shall be solely responsible for making all payments to and on behalf of its employees and
UTK shall in no event be liable for any debts or other liabilities of AVDU.

B. UTK shall not have or be deemed to have, fiduciary obligations or duties to AVDU, and shall be
able to pursue, conduct and carry on for its own account (or for the account of others) such
activities, ventures, businesses and other pursuits as UTK in its sole, absolute and unfettered
discretion, may elect.

C. Notwithstanding the above, no activity, venture, business or other pursuit of UTK, during the
term of this Agreement shall conflict with UTK's obligations under this Agreement.
<!-- page 2 -->
III. SERVICES

UTK agrees to provide the following services, hereinafter collectively referred to as "Services":

SEE "CONFIDENTIAL TERM SHEET" (EXHIBIT A) ATTACHED AND MADE A PART HEREOF.

A. UTK shall devote such time and efforts, as it deems commercially reasonable, under the
circumstances to the affairs of the AVDU, as is reasonable and adequate to render the Services
contemplated by this Agreement.

B. UTK cannot guarantee results on behalf of AVDU, but shall pursue all reasonable avenues available
through its network of contacts. The acceptance and consumption of any transaction is subject to
acceptance of the terms and conditions by its sole discretion.

C. In conjunction with the Services, UTK agrees to:

1. Make itself available at the offices of AVDU or at another mutually agreed upon place, during
normal business hours, for reasonable periods of time, subject to reasonable advance notice and
mutually convenient scheduling.

2. Make itself available for telephone conferences with the principal officer(s) of AVDU during
normal business hours.

IV. EXPENSES

It is expressly agreed and understood that each party shall be responsible for its own normal and
reasonable out-of-pocket expenses.

V. COMPENSATION

A. In consideration for the services to be provided, AVDU agrees that it will remit the agreed upon
stock certificate within five (5) days of both parties executing this Agreement.

B. AVDU agrees that UTK shall be entitled to compensation as follows:

SEE STRATEGIC ALLIANCE CONFIDENTIAL TERM SHEET (EXHIBIT A) ATTACHED AND MADE A PART HEREOF.

VI. TERM AND TERMINATION

The term of the Agreement will be for 12 months unless terminated sooner. This agreement may be
renewed upon mutual, written agreement of the parties. Either party may terminate this Agreement at
any time with 30 days written notice. - 2 -
<!-- page 3 -->
VII. LEGAL COMPLIANCE

AVDU agrees that it will put in place, if it has not already done so, policies and procedures
relating to and addressing, with the commercially reasonable intent to ensure compliance with,
applicable securities laws, rules and regulations, including, but not limited to:

A. The use, release or other publication of forward-looking statements.

B. Disclosure requirements regarding the required disclosure of the nature and terms of UTK's
relationship with, including, but not limited to press releases, publications on its web site,
letters to investors and telephone or other personal communication with potential or current
investors.

C. No press releases or any other forms of communication to third parties which mention both UTK
CORPORATION and AVDU, shall be released without the prior written consent and approval of both UTK
and AVDU.

D. EXECUTION. The execution, delivery and performance of this Agreement, in the time and manner
herein specified will not conflict with, result in a breach of, or constitute a default under any
existing agreement, indenture, or other instrument to which either AVDU OR UTK is a party or by
which either entity may be bound or affected.

E. TIMELY APPRISALS. AVDU shall use its commercially reasonable efforts to keep UTK up to date and
apprised of all business, market and legal developments related to and its relationship to UTK.

F. CORPORATE AUTHORITY. Both AVDU and UTK have full legal authority to enter into this Agreement and
perform the same in the time and manner contemplated.

G. The individuals whose signatures appear below are authorized to sign this Agreement on behalf of
their respective corporations.

H. AVDU will cooperate with UTK and will promptly provide UTK with all pertinent materials and
requested information in order for UTK to perform its Services pursuant to this Agreement.

I. When delivered, the shares of AVDU Common Stock shall be duly and validly issued, fully paid and
non-assessable.

J. UTK represents to AVDU that a) it has the experience as may be necessary to perform all the
required, b) all Services will be performed in a professional manner, and c) all individuals it
provides to perform the Services will be appropriately qualified and subject to appropriate
agreements concerning the protection of trade secrets and confidential information of which such
persons may have access to over the term of this Agreement.

K. Until termination of the engagement, AVDU will notify UTK promptly of the occurrence of any
event, which might materially affect the condition (financial or otherwise), or prospects of AVDU. -
3 -
<!-- page 4 -->
VIII. CONFIDENTIAL DATA

A. UTK shall not divulge to others, any trade secret or confidential information, knowledge, or data
concerning or pertaining to the business and affairs of AVDU, obtained by UTK as a result of its
engagement hereunder, unless authorized, in writing by AVDU. UTK represents and warrants that it has
established appropriate internal procedures for protecting the trade secrets and confidential
information of AVDU, including, without limitation, restrictions on disclosure of such information
to employees and other persons who may be engaged in such information to employees and other persons
who may be engaged in rendering services to any person, firm or entity which may be a competitor of
AVDU.

B. AVDU shall not divulge to others, any trade secret or confidential information, knowledge, or
data concerning or pertaining to the business and affairs of UTK or confidential information
revealed by UTK obtained as a result of its engagement hereunder, unless authorized, in writing, by
UTK.

C. UTK shall not be required in the performance of its duties to divulge to AVDU, or any officer,
director, agent or employee of AVDU, any secret or confidential information, knowledge, or data
concerning any other person, firm or entity (including, but not limited to, any such person, firm or
entity which may be a competitor or potential competitor of) which UTK may have or be able to obtain
other than as a result of the relationship established by this Agreement.

IX. OTHER MATERIAL TERMS AND CONDITIONS

A. INDEMNITY.

1. UTK shall indemnify, defend and hold harmless AVDU from and against any and all losses incurred
by AVDU which arise out of or result from misrepresentation, breach of warranty or breach or non-
fulfillment of any covenant contained herein or Schedules annexed hereto or in any other documents
or instruments furnished by UTK pursuant hereto or in connection with this Agreement.

2. AVDU shall indemnify, defend and hold harmless UTK from and against any and all losses incurred
by UTK which arise out of or result from misrepresentation, breach of warranty or breach or
non-fulfillment of any covenant contained herein or Schedules annexed hereto or in any other
documents or instruments furnished by AVDU pursuant hereto or in connection with this Agreement.

B. PROVISIONS. Neither termination nor completion of the assignment shall affect the provisions of
this Agreement, and the Indemnification Provisions that are incorporated herein, which shall remain
operative and in full force and effect.

C. AVDU agrees that for a twenty four months (24) following the execution of this Agreement, AVDU
shall not, without UTEK's prior written consent, directly or indirectly solicit for employment any
present employee of UTEK, or request induce or advise any employee of UTEK to leave the employ of
UTEK. In turn, UTEK agrees that it will not directly or indirectly solicit any present employee of
AVDU. - 4 -
<!-- page 5 -->
D. ADDITIONAL INSTRUMENTS. Each of the parties shall from time to time, at the request of others,
execute, acknowledge and deliver to the other party any and all further instruments that may be
reasonably required to give full effect and force to the provisions of this Agreement.

E. ENTIRE AGREEMENT. Each of the parties hereby covenants that this Agreement, is intended to and
does contain and embody herein all of the understandings and agreements, both written or oral, of
the parties hereby with respect to the subject matter of this Agreement, and that there exists no
oral agreement or understanding expressed or implied liability, whereby the absolute, final and
unconditional character and nature of this Agreement shall be in any way invalidated, empowered or
affected. There are no representations, warranties or covenants other than those set forth herein.

F. ASSIGNMENTS. The benefits of the Agreement shall inure to the respective successors and assignees
of the parties and assigns and representatives, and the obligations and liabilities assumed in this
Agreement by the parties hereto shall be binding upon their respective successors and assigns;
provided that the rights and obligations of UTK under this Agreement may not be assigned or
delegated without the prior written consent of AVDU and any such purported assignment shall be null
and void. Notwithstanding the foregoing, UTK may assign this Agreement or any portion of its
Compensation as outlined herein to its subsidiaries in its sole discretion.

G. ORIGINALS. This Agreement may be executed in any number of counterparts, each of which so
executed shall be deemed an original and constitute one and the same agreement.

H. ADDRESSES OF PARTIES. Each party shall at all times keep the other informed of its principal
place of business if different from that stated herein, and shall promptly notify the other of any
change, giving the address of the new place of business or residence.

I. NOTICES. All notices that are required to be or may be sent pursuant to the provision of this
Agreement shall be sent by certified mail, return receipt requested, or by overnight package
delivery service to each of the parties at the addresses appearing herein, and shall count from the
date of mailing or the validated air bill.

J. MODIFICATION AND WAVIER. A modification or waiver of any of the provisions of this Agreement
shall be effective only if made in writing and executed with the same formality as this Agreement.
The failure of any party to insist upon strict performance of any of the provisions of this
Agreement shall not be construed as a waiver of any subsequent default of the same or similar nature
or of any other nature.

K. INJUNCTIVE RELIEF. Solely by virtue of their respective execution of this Agreement and in
consideration for the mutual covenants of each other, AVDU and UTK hereby agree, consent and
acknowledge that, in the event of a breach of any material term of this Agreement, the non-breaching
party will be without adequate remedy-at-law and shall therefore, be entitled to immediately redress
any material breach of this Agreement by temporary or permanent injunctive or mandatory relief
obtained in an action or proceeding instituted in any court of competent jurisdiction without the
necessity of proving damages and without prejudice to any other remedies which the non-breaching
party may have at law or in equity. - 5 -
<!-- page 6 -->
L. ATTORNEY'S FEES. If any arbitration, litigation, action, suit, or other proceeding is instituted
to remedy, prevent or obtain relief from a breach of this Agreement, in relation to a breach of this
Agreement or pertaining to a declaration of rights under this Agreement, the prevailing party will
recover all such party's attorneys' fees incurred in each and every such action, suit or other
proceeding, including any and all appeals or petitions there from. As used in this Agreement,
attorneys' fees will be deemed to be the full and actual cost of any legal services actually
performed in connection with the matters involved, including those related to any appeal to the
enforcement of any judgment calculated on the basis of the usual fee charged by attorneys performing
such services.

APPROVED AND AGREED: UTEK CORPORATION WORLD ENERGY SOLUTIONS

By: /s/ Clifford M. Gross By: /s/ Benjamin C. Croxton Clifford M. Gross, Ph.D. Benjamin C. Croxton
Chief Executive Officer Chief Executive Officer - 6 -
<!-- page 7 -->
Exhibit A

CONFIDENTIAL TERM SHEET

PROPOSED STRATEGIC ALLIANCE BETWEEN UTEK CORPORATION (UTK) & WORLD ENERGY SOLUTIONS (AVDU)

Statement of Work: To identify technology acquisition opportunities for AVDU from research
universities and government laboratories. A first step in this process is the development of a
Technology Acquisition Profile. Once completed, we will identify and present technologies that meet
this profile. While conducting our search we will maintain the confidentiality of AVDU.

Term: The term of the Agreement will be for 12 months unless terminated sooner. This Agreement may
be renewed upon mutual, written agreement of the parties. Either party may terminate this agreement
at any time with 30 days written notice.

Services: UTK agrees to provide the following distinct services to AVDU:

i. Identify synergistic new technologies from universities and government laboratories to help
provide AVDU with an enhanced new product pipeline.

ii. Review technology acquisition opportunities for AVDU while maintaining AVDU's confidentiality.

iii. Present technology acquisition opportunities for AVDU. AVDU will have 30-days to determine if
they want to go forward with the technology license.

a. UTK after 30 days shall have the right to present the technology to other clients.

iv. AVDU acknowledges that the sources of technologies represented by UTEK are 3rd party research
institutions for which UTEK does not control whether the technology will be shown to other parties
by the licensor.

v. At AVDU's request, UTK will prepare, and compile additional information regarding the technology
acquisition opportunities for AVDU.

vi. At AVDU's request and upon mutual agreement between AVDU and UTK, UTK will negotiate and seek to
acquire a license to the requested technology for subsequent sale to and acquisition by AVDU.

vii. On a case-by-case basis, at AVDU's request and UTK's sole discretion, UTK will propose an
equity-financing plan for AVDU's consideration, to finance select technology acquisition
opportunities for AVDU.

viii. AVDU will not seek to acquire any technologies presented to AVDU by UTK directly from the
technology developer for a period of 24 months following the termination of this Strategic Alliance
agreement.
<!-- page 8 -->
ix. The compensation quotation is valid for projects authorized and initiated within 30 days of the
date of this term sheet.

a. In arms length negotiation with the technology developer, UTK will seek to acquire the license to
the technology through one of its subsidiaries. UTEK will then negotiate with AVDU to acquire this
subsidiary in a stock for stock exchange under an "Agreement and Plan of Acquisition". The
consideration to be paid by AVDU to UTK will be based upon a markup to the value of the license and
other assets in the subsidiary as determined by UTK and agreed to by both parties.

b. Should AVDU decide not to proceed in the acquisition of the technology/company as described
above, then AVDU shall be prohibited from acquiring the technology/company either directly or
indirectly, from the technology/company developer for a period of 24 months following the
termination of this Strategic Alliance Agreement.

Technology Transfer: When a technology is shown to AVDU that AVDU wants to acquire, UTK will seek to
acquire the license to a technology through one of its subsidiaries. UTK will then seek to provide a
term sheet to AVDU outlining the consideration to be paid by AVDU for the acquisition of this
technology. UTK shall transfer this subsidiary to AVDU in a stock for stock exchange under an
"Agreement and Plan of Acquisition." The consideration to be paid by AVDU to UTK will be based upon
a markup to the value of the license and other assets in the subsidiary as determined by UTK and
agreed to by both parties.

Compensation:

In consideration for providing these Services, AVDU shall pay UTK $120,000 worth of unregistered
shares of common stock (31,413 shares) upon the execution of this Strategic Alliance Agreement.
1/12th of the shares (2,617) shall vest each month during the term of this Agreement. If this
Agreement is terminated any unvested shares will be returned to AVDU. Both AVDU and UTK will cover
their own out-of-pocket expenses incurred during the performance of this Strategic Alliance
Agreement.

Approved by: /s/ Clifford M. Gross /s/ Benjamin C. Croxton UTEK Corporation World Energy Solutions
Clifford M. Gross, Ph.D. Benjamin C. Croxton Chief Executive Officer Chief Executive Officer

Date: September 9, 2005 Date: September 9, 2005
