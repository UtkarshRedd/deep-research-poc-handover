<!-- page 1 -->
# APPLICATION DEVELOPMENT AGREEMENT
| Field | Value |
|---|---|
| Document Type | Development Agreement |
| Agreement Date | 2020-03-20 |
| Parties | InfinixSoft Global LLC ("Developer"); Clickstream Corporation ("Client") |
| Source | CUAD v1 / ClickstreamCorp_20200330_1-A_EX1A-6 MAT CTRCT_12089935_EX1A-6 MAT CTRCT_Development Agreement |

Exhibit 6.1

APPLICATION DEVELOPMENT AGREEMENT This Application Development Agreement (the "Agreement") is
entered into as of March 20, 2020, effective as of March 20, 2020 (the "Effective Date") by and
between InfinixSoft Global LLC, a Florida Limited Liability Company, with its principal office
located at 360 NE 75 St Miami, Suite #127, 33138, Miami, Florida (the "Developer") and Clickstream
Corporation with its principal office located at 1801 Century Park East Suite 1201 Los Angeles, CA
90067 (the "Client") and together with the Developer ( the "Parties"). RECITALS WHEREAS, the Client
is engaged in the business of developing and designing mobile software applications; and WHEREAS,
the Developer is engaged in the business of developing and designing application solutions; and
WHEREAS, the Client wishes to engage the Developer as an independent contractor for the Client for
the purpose of designing the Client's application (the "Application") on the terms and conditions
set forth below; and WHEREAS, the Developer wishes to design the Application and agrees to do so
under the terms and conditions of this Agreement; and WHEREAS, each Party is duly authorized and
capable of entering into this Agreement. NOW THEREFORE, in consideration of the above recitals and
the mutual promises and benefits contained herein, the Parties hereby agree as follows: 1. PURPOSE.
The Client hereby appoints and engages the Developer, and the Developer hereby accepts this
appointment, to perform the services described in Exhibit A attached hereto and made a part hereof,
in connection with the design of the Application (collectively, the "Services"). 2. COMPENSATION.
The total compensation for the design of the app shall be as set forth in Exhibit A hereto. These
payments shall be made in installments according to the schedule set forth in Exhibit A hereto. 3.
TERM. This Agreement shall become effective as of the Effective Date and, unless otherwise
terminated in accordance with the provisions of Section 4 of this Agreement, will continue until the
expiration of the Warranty Period as defined in subsection 9(a) of this Agreement. 4. TERMINATION.
(a) Types of Termination. This Agreement may be terminated: 1. By either Party on provision of seven
(7) days written notice to the other Party in case of a Force Majeure Event. 2. Client has the
unilateral right to cancel this agreement at any time within a 7-day notice period. Further,
Developer can only cancel due to lack of payment. Client will have a 30 day right to cure before a
cancelation can occur. 3. By either Party for a material breach of any provision of this Agreement
by the other Party, if the other Party's material breach is not cured within three (3) days of
receipt of written notice thereof. This shall include any delays to the timeline specified in
Exhibit A. 4. By the Client at any time and without prior notice, if the Developer is convicted of
any crime or offense, fails or refuses to comply with the written policies or reasonable directives
of the Client, or is guilty of serious misconduct in connection with performance under this
Agreement.

1 │ Page

Source: CLICKSTREAM CORP, 1-A, 3/30/2020
<!-- page 2 -->
(b) Responsibilities after Termination. Following the termination of this Agreement for any reason,
the Client shall promptly pay the Developer according to the terms of Exhibit A for Services
rendered before the effective date of the termination (the "Termination Date"). The Developer
acknowledges and agrees that no other compensation, of any nature or type, shall be payable
hereunder following the termination of this Agreement. All intellectual property developed pursuant
to this Agreement before the Termination Date shall be delivered to the Client within one day of the
Termination Date. 5. RESPONSIBILITIES. (a) Of the Developer. The Developer agrees to do each of the
following: 1. Create the Application System as detailed in Exhibit A to this Agreement and extend
its best efforts to ensure that the design and functionality of the Application System meets the
Client's specifications. 2. Devote as much productive time, energy, and ability to the performance
of its duties hereunder as may be necessary to provide the required Services in a timely and
productive manner and to the timeframe specified in this agreement. 3. Perform the Services in a
workmanlike manner and with professional diligence and skill, as a fully trained, skilled,
competent, and experienced personnel. 4. On completion of the Application System, assist the Client
in installation of the Application System to its final location, which assistance will include
helping the Client with its upload of the finished files to the Client's selected Web-hosting Client
and submitting for approval on the Apple Store and Google Play Store. 5. Provide Services and an
Application System that are satisfactory and acceptable to the Client and free of defects. 6.
Communicate and show with the Client regarding progress it has made with respect to the milestones
listed in this agreement. 7. Operate and Maintain the Application System through hosting of games
including customer Support 8. Assist the Client in identification and acquisition of corporate
sponsors 9. Include internal messaging system whereas users can communicate with each other (b) Of
the Client. The Client agrees to do each of the following: 1. Engage the Developer as the creator of
its Application System. 2. Provide all assistance and cooperation to the Developer in order to
complete the Application System timely and efficiently. 3. Provide initial information and supply
all content for the Application System. 4. Provide acceptance testing and certification within one
week of deployment of final build

2 │ Page

Source: CLICKSTREAM CORP, 1-A, 3/30/2020
<!-- page 3 -->
6. CONFIDENTIAL INFORMATION. The Developer agrees, during the Term and thereafter, to hold in
strictest confidence, and not to use, except for the benefit of the Client, or to disclose to any
person, firm, or corporation without the prior written authorization of the Client, any Confidential
Information of the Client. "Confidential Information" means any of the Client's proprietary
information, technical data, trade secrets, or know-how, including, but not limited to, business
plans, research, product plans, products, services, customer lists, markets, software, developments,
inventions, processes, formulas, technology, designs, drawings, engineering, hardware configuration
information, marketing, finances, or other business information disclosed to the Developer by the
Client either directly or indirectly. 7. PARTIES' REPRESENTATIONS AND WARRANTIES. (a) The Parties
each represent and warrant as follows: 1. Each Party has full power, authority, and right to perform
its obligations under the Agreement. 2. This Agreement is a legal, valid, and binding obligation of
each Party, enforceable against it in accordance with its terms (except as may be limited by
bankruptcy, insolvency, moratorium, or similar laws affecting creditors' rights generally and
equitable remedies). 3. Entering into this Agreement will not violate the charter or bylaws of
either Party or any material contract to which that Party is also a party. (b) The Developer hereby
represents and warrants as follows: 1. The Developer has the right to control and direct the means,
details, manner, and method by which the Services required by this Agreement will be performed. 2.
The Developer has the experience and ability to perform the Services required by this Agreement. 3.
The Developer has the right to perform the Services required by this Agreement at any place or
location, and at such times as the Developer shall determine. 4. The Services shall be performed in
accordance with and shall not violate any applicable laws, rules, or regulations, and the Developer
shall obtain all permits or permissions required to comply with such laws, rules, or regulations. 5.
The Services required by this Agreement shall be performed by the Developer, and the Client shall
not be required to hire, supervise, or pay any assistants to help the Developer perform such
services. 6. The Developer is responsible for paying all ordinary and necessary expenses of itself
or its staff. 7. The Developer shall not develop, maintain or market a similar platform and will not
compete with the Client directly or indirectly worldwide. 8. At the time cash online betting is
implemented, incorporate and update the approximate 40 algorithms previously developed by Developer
for Client. (c) The Client hereby represents and warrants as follows: 1. The Client will make timely
payments of amounts earned by the Developer under this Agreement. 2. The Client shall notify the
Developer of any changes to its procedures affecting the Developer's obligations under this
Agreement at least three days prior to implementing such changes. 3. The Client shall provide such
other assistance to the Developer as it deems reasonable and appropriate. 4. Because of the trade
secret subject matter of Developer's business, Client agrees that, during the term of this Agreement
and for a period of two (2) years thereafter, it will not solicit the services of any of Developer's
employees, consultants or suppliers for Client's own benefit or for the benefit of any other person
or entity.

3 │ Page

Source: CLICKSTREAM CORP, 1-A, 3/30/2020
<!-- page 4 -->
8. APPLICATION REPRESENTATIONS AND WARRANTIES. (a) Performance. The Developer hereby warrants and
represents that following delivery of the Application System to the Client (which shall be deeded to
occur only on the date the Web Application is uploaded to the AWS for distribution) pursuant to
Exhibit A (the "Support Period"), the Application will be free from programming errors and defects
in workmanship and materials, and will conform to the specifications of Exhibit A. If programming
errors or other defects are discovered during the Support Period, the Developer shall promptly
remedy those errors or defects at its own expense. The developer will fix any bugs that may come up
from the original contract after the 90 days warranty has passed. (b) No Disablement. The Developer
hereby warrants and represents that the Application System, when delivered or accessed by the
Client, will be free from material defects, and from viruses, logic locks, and other disabling
devices or codes, and in particular will not contain any virus, Trojan horse, worm, drop-dead
devices, trap doors, time bombs, or other software routines or other hardware component that could
permit unauthorized access, disable, erase, or otherwise harm the Application System or any
software, hardware, or data, cause the Application System or any software or hardware to perform any
functions other than those specified in this Agreement, halt, disrupt, or degrade the operation of
the Application System or any software or hardware, or perform any other such actions. 9. TIMING AND
DELAYS. The Developer recognizes and agrees that failure to deliver the Application in accordance
with the delivery schedule detailed in Exhibit A to this Agreement will result in expense and damage
to the Client. The Developer shall inform the Client immediately of any anticipated delays in the
delivery schedule and of any remedial actions being taken to ensure completion of the Application
System according to such schedule. If a delivery date is missed, the Client may, in its sole
discretion, declare such delay a material breach of the Agreement under subsection 4(a) and pursue
all of its legal and equitable remedies. The Client may not declare a breach, and the Developer
cannot be held in breach of this Agreement, of this section if such delay is caused by an action or
failure of action of the Client. In such case, the Developer will provide the Client with written
notice of the delay and work on the Application System will work until the reason for the delay has
been resolved by the Client and written notice of that resolution has been provided to the
Developer. 10. NATURE OF RELATIONSHIP. (a) Independent Contractor Status. The Developer agrees to
perform the Services hereunder solely as an independent contractor. The Parties agree that nothing
in this Agreement shall be construed as creating a joint venture, partnership, franchise, agency,
employer/employee, or similar relationship between the Parties, or as authorizing either Party to
act as the agent of the other. The Developer is and will remain an independent contractor in its
relationship to the Client. The Client shall not be responsible for withholding taxes with respect
to the Developer's compensation hereunder. The Developer shall have no claim against the Client
hereunder or otherwise for vacation pay, sick leave, retirement benefits, social security, worker's
compensation, health or disability benefits, unemployment insurance benefits, or employee benefits
of any kind. Nothing in this Agreement shall create any obligation between either Party or a third
party. (b) Indemnification of Client by Developer. The Client has entered into this Agreement in
reliance on information provided by the Developer, including the Developer's express representation
that it is an independent contractor and in compliance with all applicable laws related to work as
an independent contractor. If any regulatory body or court of competent jurisdiction finds that the
Developer is not an independent contractor and/or is not in compliance with applicable laws related
to work as an independent contractor, based on the Developer's own actions, the Developer shall
assume full responsibility and liability for all taxes, assessments, and penalties imposed against
the Developer and/or the Client resulting from such contrary interpretation, including but not
limited to taxes, assessments, and penalties that would have been deducted from the Developer's
earnings had the Developer been on the Client's payroll and employed as an employee of the Client.

4 │ Page

Source: CLICKSTREAM CORP, 1-A, 3/30/2020
<!-- page 5 -->
11. WORK FOR HIRE. (a) Work for Hire. The Developer expressly acknowledges and agrees that any all
proprietary materials prepared by the Developer under this Agreement shall be considered "works for
hire" and the exclusive property of the Client unless otherwise specified. These items shall
include, but shall not be limited to, any and all deliverables resulting from the Developer's
Services or contemplated by this Agreement, all tangible results and proceeds of the Services, works
in progress, records, diagrams, notes, drawings, specifications, schematics, documents, designs,
improvements, inventions, discoveries, developments, trademarks,, licenses, trade secrets, customer
lists, databases, software, programs, middleware, applications, and solutions conceived, made, or
discovered by the Developer, solely or in collaboration with others, during the Term of this
Agreement relating in any manner to the Developer's Services. (b) Additional Action to Assign
Interest. To the extent such work may not be deemed a "work for hire" under applicable law, the
Developer hereby assigns to the Client all of its right, title, and interest in and to such work.
The Developer shall execute and deliver to the Client any instruments of transfer and take such
other action that the Client may reasonably request, including, without limitation, executing and
filing, at the Client's expense, copyright applications, assignments, and other documents required
for the protection of the Client's rights to such materials. (c) Notice of Incorporation of Existing
Work. If the Developer intends to integrate or incorporate any work that it previously created into
any work product to be created in furtherance of its performance of the Services, the Developer must
obtain the Client's prior written approval of such integration or incorporation. If the Client, in
its reasonable discretion, consents, the Client is hereby granted an exclusive, worldwide,
royalty-free, perpetual, irrevocable license to use, distribute, modify, publish, and otherwise
exploit the incorporated items in connection with the work product developed for the Client. 12.
RETURN OF PROPERTY. Within three (3) days of the termination of this Agreement, whether by
expiration or otherwise, the Developer agrees to return to the Client all Client products, samples,
models, or other property and all documents, retaining no copies or notes, relating to the Client's
business including, but not limited to, reports, abstracts, lists, correspondence, information,
computer files, computer disks, and all other materials and all copies of such material obtained by
the Developer during and in connection with its representation of the Client. All files, records,
documents, blueprints, specifications, information, letters, notes, media lists, original
artwork/creative, notebooks, and similar items relating to the Client's business, whether prepared
by the Developer or otherwise coming into its possession, shall remain the Client's exclusive
property. 13. INDEMNIFICATION. (a) Of Client by Developer. The Developer shall indemnify and hold
harmless the Client and its officers, members, managers, employees, agents, contractors, sub
licensees, affiliates, subsidiaries, successors and assigns from and against any and all damages,
liabilities, costs, expenses, claims, and/or judgments, including, without limitation, reasonable
attorneys' fees and disbursements (collectively, the "Claims") that any of them may suffer from or
incur and that arise or result primarily from (i) any gross negligence or willful misconduct of the
Developer arising from or connected with the Developer's carrying out of its duties under this
Agreement, or (ii) the Developer's breach of any of its obligations, agreements, or duties under
this Agreement. (b) Of Developer by Client. The Client shall indemnify and hold harmless the
Developer from and against all Claims that it may suffer from or incur and that arise or result
primarily from (i) the Client's operation of its business, (ii) the Client's breach or alleged
breach of, or its failure or alleged failure to perform under, any agreement to which it is a party,
or (iii) the Client's breach of any of its obligations, agreements, or duties under this Agreement;
provided, however, none of the foregoing result from or arise out of the actions or inactions of the
Developer.

5 │ Page

Source: CLICKSTREAM CORP, 1-A, 3/30/2020
<!-- page 6 -->
14. INTELLECTUAL PROPERTY. (a) No Intellectual Property Infringement by Developer. The Developer
hereby represents and warrants that the use and proposed use of the Application by the Client or any
third party does not and shall not infringe, and the Developer has not received any notice,
complaint, threat, or claim alleging infringement of, any trademark, copyright, patent, trade
secrets, industrial design, or other rights of any third party in the Application, and the use of
the Application will not include any activity that may constitute "passing off." To the extent the
Application infringes on the rights of any such third party, the Developer shall obtain a license or
consent from such third party permitting the use of the Application. It is hereby stated, the
Application developed under this agreement is the exclusive worldwide sole property of Client. (b)
No Intellectual Property Infringement by Client. The Client represents to the Developer and
unconditionally guarantees that any elements of text, graphics, photos, designs, trademarks, or
other artwork furnished to the Developer for inclusion in the Application are owned by the Client,
or that the Client has permission from the rightful owner to use each of these elements, and will
hold harmless, protect, indemnify, and defend the Developer and its subcontractors from any
liability (including attorneys' fees and court costs), including any claim or suit, threatened or
actual, arising from the use of such elements furnished by the Client. (c) Continuing Ownership of
Existing Trademarks, Copyrights and Patents. The Developer recognizes the Client's right, title, and
interest in and to all service marks, trademarks, trade names , Copyrights and Patents used by the
Client and agrees not to engage in any activities or commit any acts, directly or indirectly, that
may contest, dispute, or otherwise impair the Client's right, title, and interest therein, nor shall
the Developer cause diminishment of value of said trademarks or trade names through any act or
representation. The Developer shall not apply for, acquire, or claim any right, title, or interest
in or to any such service marks, trademarks, trade names, Copyrights and Patents or others that may
be confusingly similar to any of them, through advertising or otherwise. Effective as of the
termination of this Agreement, the Developer shall cease to use all of the Client's trademarks,
marks, and trade names. (d) The Developer recognizes that the complete Intellectual Property of the
project belongs to the Client. The Developer will deliver to the Client all the source code,
licenses and other assets used during the process as soon as the work described in this proposal is
finished under client acceptation and after receiving the last payment. 15. AMENDMENTS. No
amendment, change, or modification of this Agreement shall be valid unless in writing and signed by
both Parties. 16. ASSIGNMENT. The Client may assign this Agreement freely, in whole or in part. The
Developer may not, without the written consent of the Client, assign, subcontract, or delegate its
obligations under this Agreement, except that the Developer may transfer the right to receive any
amounts that may be payable to it for its Services under this Agreement, which transfer will be
effective only after receipt by the Client of written notice of such assignment or transfer. 17.
SUCCESSORS AND ASSIGNS. All references in this Agreement to the Parties shall be deemed to include,
as applicable, a reference to their respective successors and assigns. The provisions of this
Agreement shall be binding on and shall inure to the benefit of the successors and assigns of the
Parties. 18. FORCE MAJEURE. A Party shall be not be considered in breach of or in default under this
Agreement on account of, and shall not be liable to the other Party for, any delay or failure to
perform its obligations hereunder by reason of fire, earthquake, flood, explosion, strike, riot,
war, terrorism, or similar event beyond that Party's reasonable control (each a "Force Majeure
Event"); provided, however, if a Force Majeure Event occurs, the affected Party shall, as soon as
practicable:

6 │ Page

Source: CLICKSTREAM CORP, 1-A, 3/30/2020
<!-- page 7 -->
(a) notify the other Party of the Force Majeure Event and its impact on performance under this
Agreement; and (b) use reasonable efforts to resolve any issues resulting from the Force Majeure
Event and perform its obligations hereunder. 19. NO IMPLIED WAIVER. The failure of either Party to
insist on strict performance of any covenant or obligation under this Agreement, regardless of the
length of time for which such failure continues, shall not be deemed a waiver of such Party's right
to demand strict compliance in the future. No consent or waiver, express or implied, to or of any
breach or default in the performance of any obligation under this Agreement shall constitute a
consent or waiver to or of any other breach or default in the performance of the same or any other
obligation. 20. NOTICE. Any notice or other communication provided for herein or given hereunder to
a Party hereto shall be in writing and shall be given in person, by overnight courier, or by mail
(registered or certified mail, postage prepaid, return-receipt requested) to the respective Parties
as follows: If to the Client: Contact: Frank Magliochetti, CEO Company Name: Clickstream Corp. Main
Address: 1801 Century Park East Suite 1201 Los Angeles, CA 90067 If to the Developer: Contact: Ivan
Saroka, CEO Company Name: InfinixSoft Global LLC Main Address: 360 NE 75th St. Suite #127, 33138,
Miami, Florida 21. GOVERNING LAW. This Agreement shall be governed by the laws of the state of
Florida. If litigation results from or arises out of this Agreement or the performance thereof, each
Party shall be responsible for its own attorneys' fees, court costs, and all other expenses, whether
or not taxable by the court as costs. 22. COUNTERPARTS/ELECTRONIC SIGNATURES. This Agreement may be
executed in one or more counterparts, each of which shall be deemed an original but all of which
shall constitute one and the same instrument. For purposes of this Agreement, use of a facsimile,
e-mail, or other electronic medium shall have the same force and effect as an original signature.
23. SEVERABILITY. Whenever possible, each provision of this Agreement will be interpreted in such
manner as to be effective and valid under applicable law, but if any provision of this Agreement is
held to be invalid, illegal, or unenforceable in any respect under any applicable law or rule in any
jurisdiction, such invalidity, illegality, or unenforceability will not affect any other provision
or any other jurisdiction, but this Agreement will be reformed, construed, and enforced in such
jurisdiction as if such invalid, illegal, or unenforceable provisions had never been contained
herein. 24. ENTIRE AGREEMENT. This Agreement constitutes the final, complete, and exclusive
statement of the agreement of the Parties with respect to the subject matter hereof and supersedes
any and all other prior and contemporaneous agreements and understandings, both written and oral,
between the Parties.

7 │ Page

Source: CLICKSTREAM CORP, 1-A, 3/30/2020
<!-- page 8 -->
25. HEADINGS. Headings used in this Agreement are provided for convenience only and shall not be
used to construe meaning or intent.
**********************************************************************************************
EXHIBIT A A. PURPOSE OF APPLICATION SYSTEM. To create a new iOS / Android Native app and a web
responsive site to allow users to connect with each other inside a unique social betting platform.
The Platform is social trivia, initially sports trivia and other trivia contests leading to peer to
peer betting intended for the causal and non- professional betting market. A landing page to promote
the product is included as well for desktop and mobile devices. Developer will publish the app in
Apple Store / Google Play Store with developer accounts registered to the client. The responsive
website will be uploaded and deployed into an AWS Environment also registered to the client. The
applications and responsive website will be fed by a Ruby on Rails backend with the according API.
The API will be open to be used in other sports betting platforms. The app will be developed under
the following considerations: ● Native iOS Swift 5.0 Language with Xcode Development Environment. ●
Native JAVA with Android Studio for Android Devices with OS 6.0+ ● Ruby On Rails Backend +
PostgreSQL + Rest API ● HTML5 + CSS 3 + Bootstrap Core Platform The Core of Click Stream is a free
to play gaming platform that caters untapped market of the causal users that will spend a few
seconds to interact with a platform for free in order to win real money. Our primary target is not
the sports betters or the fantasy players. We target a more general demographic that is much more
general and includes more of the female population. Our games will initially be quick to play quiz
type games that allows the user to get involved in around 20 seconds, and then receive results from
push notifications. Game types are set up dynamically with live game shows with Hosts 2 - 4 times
per month. Because the format doesn't change, we can run games nightly for NBA to NHL, NFL to
individual events such as the Oscars, other awards shows, and new sporting events such as Soccer and
Nascar. Games and events automated from the backend and launched automatically. Api's Are plugged in
to track results in real time, and there is a manual option to allow customs events that can be run
through the platform. Business model- What sets our platform apart from other platforms in this
untapped casual industry is that we have winners win significant amounts of money via time breakers,
timing of inputting answers etc. Competitor platforms pay out an average of a few dollars. Our
winners are more top loaded and pay out around $2,500 per the top 5 and $1,000 per the top 10.
Initially monetization is based upon sponsors paying out the pots. IE, a pot for a single game will
be around $25,000 to the winners and Sponsors will pay around $30,000 to $35,000 to sponsor the
event. In return they will get around 30,000-75,000 unique user hits and eyeballs to their
product/company.

8 │ Page

Source: CLICKSTREAM CORP, 1-A, 3/30/2020
<!-- page 9 -->
Eventually the platform will expand into affiliate sales of products and once the audience has grown
large enough, peer to peer betting. Monetization We will initially fund the first month of pots in
order to attract enough users to get sponsors. After the first month we will have enough users to
begin having sponsors pay the pots. We will then expand to peer to peer betting and advertising. B.
SERVICES. The Developer will develop the mobile application based on the Client's specifications,
will assist the Client in acquiring corporate sponsors and will operate and maintain the Application
System through hosting of games including customer support. The Client will provide The Developer
with all necessary information to carry out the development process. C. SPECIFICATIONS. Features for
Website & iOS / Android Mobile App for users include: ● Home Screen ● Users Sign in / Sign up ●
Profile Creation / Edition with ● Social Networks links ● Add image / Videos ● In App Purchase by
each platform convenient method + Stripe.com integration on website. ● Lineup Creation ● SMS/email
alert system (when a lineup has to be changed). ● Monetization / Subscription Model ● Mirco social
betting ● Peer to Peer betting ● Group betting ● Dynamic Quiz game Engine ● Other dynamic Game
Engines ● Homepage with newsfeed, how to play screens, institutional information, Twitter feeds,
promotions and other CTAs. ● Historical data with "How your lineup did" compared to winning lineups.
● Push Notification ● Pop up (Advertiser) ● Rate Us ● Chat ● Block / Delete ● Terms of Use / Privacy
Policy ● Analytics integration Web Admin Dashboard features include: ● Statistics to see the data in
real-time ● Resolve payment issues ● Users Main Administration ● Disable / Lock Users ● Homepage
features administration. ● Confirm Signup ● Forgot Password ● Payment success / receipt ● Payment
Failed ● Renew Reminder ● Renew Notice

9 │ Page

Source: CLICKSTREAM CORP, 1-A, 3/30/2020
<!-- page 10 -->
Transactional emails ● Welcome Email ● Order Confirmation ● Forgot Password Notes ● UI / UX design
is included in the proposal. ● The source code belongs to the client and will be delivered as soon
as the project is fully finished. ● Confidentiality: The main concept and idea of the platform are
not to be shared by Developer. D. COMPLETION SCHEDULE. The schedule for completion of the
Application Development (the "Schedule") and the responsibilities under the Agreement is detailed as
follows: Mobile / Web App development: 24 weeks + 4 weeks for QA & Details. E. MAINTENANCE AND
SUPPORT. The Maintenance & Support is not included in this contract, but we suggest making a plan in
the future that includes bug fixing, server monitoring and constant optimization of the apps. 90
days warranty (bugfixing) support is included. F. MILESTONES. ● Week 1 -> UI Design + Logo + Look &
Feel ● Week 2-> UI Design - 40% of the UX flow completed ● Week 4 -> UI Design - 75% of the UX flow
completed ● Week 6 -> Finished UI Design + Feedback / Technical Documentation ● Week 8 -> Final UI
Design - Initial Dev. Process - Backend Development Started ● Week 10 -> Initial Dev. builds with 3
or more screens (hardcoded frontend) for iOS ● Week 12 -> Second Dev. builds with 6 or more screens
(hardcoded frontend) for iOS ● Week 14 -> Third Dev. builds with all screens (hardcoded frontend)
for iOS / Backend CMS in alpha stage ● Week 16 -> Registration process and Home APIs Integrated in
Dev. builds. ● Week 18 ->Other APIs Integrated in Dev. builds. ● Week 20 -> Mobile Apps in Alpha
Stage with 70% of the APIs Integrated ● Week 22 -> Mobile Apps in Alpha Stage with 90% of the APIs
Integrated ● Week 23 -> Mobile Apps in Beta Stage of the APIs Integrated + Payment Gateway
Integration ● Week 24 -> Final RC1 Build uploaded to stores + AWS Production Deployment subject to
acceptance testing by client G. PAYMENT SCHEDULE. The total cost for the development of the project
is $ 480,000. - Developer has accepted 4,122,394 shares of Clients common stock in exchange for
$180,000 worth of services to be provided. The Shares were paid to INFX Development, LLC.
(Certificate # 1054) and accepted by Developer as payment on December 30t h, 2019 Client will form
subsidiary and register the new business if necessary.

10 │ Page

Source: CLICKSTREAM CORP, 1-A, 3/30/2020
<!-- page 11 -->
The Client agrees to pay to the Developer for the development of the project as listed above, the
amount of the other $300,000. - according to the following schedule: ● $30,000. - down payment. ●
$30,000.- mid payment (Week 2). ● $30,000.- mid payment (Week 6). ● $30,000.- mid payment (Week 9).
● $30,000.- mid payment Week 12). ● $30,000.- mid payment (Week 16). ● $30,000.- mid payment (Week
20). ● $90,000.- following Client acceptance of the Application, and when RC1 version is delivered
and uploaded to stores. By signing below, the Parties agree to comply with all of the requirements
contained in this agreement. IN WITNESS WHEREOF, the Parties have executed this Agreement as of the
date first above written Clickstream Corp. By: Frank Magliochetti, CLIENT CEO Name: Title: CEO
InfinixSoft Global LLC DEVELOPER By: Name: Ivan Alejandro Saroka Title: CEO - Founding Partner 11 │
Page

Source: CLICKSTREAM CORP, 1-A, 3/30/2020
