"""Adapters: wrap the plain tool functions for LangChain (and, if needed, LlamaIndex or the
internal agent SDK). Tool LOGIC never lives here — only argument schemas and rendering.

Usage (Approach 2 tool set, <= 6 tools):
    tools = as_langchain_tools(ws, bank, tracker, names=["grep","read","outline","list_docs","add_evidence"])
"""
from __future__ import annotations

from typing import Any, Callable

from pydantic import BaseModel, Field

from ..config import DEFAULT, Config
from ..evidence import EvidenceBank
from ..workspace import Workspace
from . import bm25 as _bm25
from . import grep as _grep
from . import manifest as _manifest
from . import outline as _outline
from . import read as _read

# ---------------------------------------------------------------- argument schemas (flat)


class GrepArgs(BaseModel):
    pattern: str = Field(description="Python regex. Use alternations for synonyms, e.g. 'terminat(e|ion)|cancel'.")
    doc_ids: list[str] | None = Field(default=None, description="Restrict to these doc_ids (optional).")
    max_matches: int | None = Field(default=None, description="Cap on returned matches (counts are always complete).")


class ReadArgs(BaseModel):
    doc_id: str
    start_line: int = Field(default=1, description="1-based line to start from (use grep/outline line numbers).")
    n_lines: int | None = Field(default=None, description="How many lines (capped).")


class OutlineArgs(BaseModel):
    doc_id: str


class ListDocsArgs(BaseModel):
    doc_ids: list[str] | None = None
    doc_type: str | None = None
    date_from: str | None = Field(default=None, description="ISO date, inclusive")
    date_to: str | None = Field(default=None, description="ISO date, inclusive")
    party_contains: str | None = None


class SearchArgs(BaseModel):
    query: str = Field(description="Short keyword query (names, defined terms, amounts, section words).")
    k: int | None = Field(default=None, description="Hits on the first page (default 10, max 30).")


class PageResultsArgs(BaseModel):
    query: str = Field(description="The exact query of an earlier search.")
    page: int = Field(default=2, description="1-based page of 10 hits in that ranking.")


class AddEvidenceArgs(BaseModel):
    doc_id: str
    start_line: int
    end_line: int
    quote: str = Field(description="VERBATIM text copied from the read window. Do not paraphrase.")
    note: str = Field(description="One line: what this shows and why it matters.")
    sub_question: str | None = None


class SubmitArgs(BaseModel):
    sub_question: str
    answer: str = Field(description="Short answer citing evidence ids inline like [e12]. Say if not in corpus.")
    evidence_ids: list[str]
    confidence: str = Field(default="medium", description="high|medium|low")
    not_in_corpus: bool = False


# ---------------------------------------------------------------- spec + adapter


class ToolSpec(BaseModel):
    name: str
    description: str
    args_schema: type[BaseModel]
    fn: Callable[..., str]

    model_config = {"arbitrary_types_allowed": True}


def build_specs(
    ws: Workspace,
    bank: EvidenceBank,
    tracker: _read.ReadTracker,
    created_by: str = "researcher",
    config: Config = DEFAULT,
    bm25: Any | None = None,
) -> dict[str, ToolSpec]:
    def grep_fn(pattern: str, doc_ids: list[str] | None = None, max_matches: int | None = None) -> str:
        return _grep.render(_grep.grep(ws, pattern, doc_ids=doc_ids, max_matches=max_matches, config=config))

    def search_fn(query: str, k: int | None = None) -> str:
        if bm25 is None:
            return "REJECTED: search is not available in this run (no BM25 index was built); use grep."
        return _bm25.render(bm25.search(query, k))

    def page_results_fn(query: str, page: int = 2) -> str:
        if bm25 is None:
            return "REJECTED: page_results is not available in this run (no BM25 index was built)."
        return _bm25.render(bm25.page(query, page))

    def read_fn(doc_id: str, start_line: int = 1, n_lines: int | None = None) -> str:
        return _read.render(_read.read(ws, doc_id, start_line, n_lines, tracker=tracker, config=config))

    def outline_fn(doc_id: str) -> str:
        return _outline.render(_outline.outline(ws, doc_id, config=config))

    def list_docs_fn(doc_ids=None, doc_type=None, date_from=None, date_to=None, party_contains=None) -> str:
        rows, total = _manifest.list_docs(ws, doc_ids, doc_type, date_from, date_to, party_contains, config=config)
        return _manifest.render(rows, total)

    def add_evidence_fn(doc_id: str, start_line: int, end_line: int, quote: str, note: str, sub_question: str | None = None) -> str:
        try:
            it = bank.add(doc_id, start_line, end_line, quote, note, sub_question, created_by=created_by)
        except (ValueError, KeyError) as e:
            return f"REJECTED: {e}"
        pg = f" p.{it.page}" if it.page else ""
        return f"saved {it.id} ({it.doc_id}{pg} L{it.start_line}-{it.end_line}); bank size {len(bank)}"

    def submit_fn(sub_question: str, answer: str, evidence_ids: list[str], confidence: str = "medium", not_in_corpus: bool = False) -> str:
        missing = [e for e in evidence_ids if bank.get(e) is None]
        if missing:
            return f"REJECTED: unknown evidence ids {missing}; add_evidence first."
        if not evidence_ids and not not_in_corpus:
            return "REJECTED: submit requires >= 1 evidence id unless not_in_corpus=true."
        return "SUBMITTED"

    specs = [
        ToolSpec(name="grep", description="Regex search across all documents in scope. Returns per-document match COUNTS plus a capped list of matching lines with line numbers and pages. Use counts to decide which documents to read.", args_schema=GrepArgs, fn=grep_fn),
        ToolSpec(name="read", description="Read a line-numbered window of one document (capped). Use line numbers from grep or outline. Repeated windows return 'already read'.", args_schema=ReadArgs, fn=read_fn),
        ToolSpec(name="outline", description="Table of contents of one document: headings with line numbers and pages.", args_schema=OutlineArgs, fn=outline_fn),
        ToolSpec(name="list_docs", description="List documents in scope with metadata (type, date, parties, pages). Supports filters.", args_schema=ListDocsArgs, fn=list_docs_fn),
        ToolSpec(name="search", description="BM25 keyword search over ~300-token chunks of every document. Returns ranked hits with doc_id, line range, page and a snippet, plus the ranking depth. Use several distinct queries, then read around the best hits.", args_schema=SearchArgs, fn=search_fn),
        ToolSpec(name="page_results", description="The next page (10 hits) of an earlier search's ranking, down to its full depth. Use it instead of repeating the same query.", args_schema=PageResultsArgs, fn=page_results_fn),
        ToolSpec(name="add_evidence", description="Save a VERBATIM quote with its doc_id and line range to the evidence bank. Every claim in your final answer must cite evidence ids from here.", args_schema=AddEvidenceArgs, fn=add_evidence_fn),
        ToolSpec(name="submit", description="Finish: give the answer to the sub-question with inline evidence ids. Rejected if ids are unknown.", args_schema=SubmitArgs, fn=submit_fn),
    ]
    return {s.name: s for s in specs}


def as_langchain_tools(
    ws: Workspace,
    bank: EvidenceBank,
    tracker: _read.ReadTracker,
    names: list[str] | None = None,
    created_by: str = "researcher",
    config: Config = DEFAULT,
    bm25: Any | None = None,
):
    """Return LangChain StructuredTools. Imported lazily so the core package has no hard
    dependency on langchain at import time."""
    from langchain_core.tools import StructuredTool

    specs = build_specs(ws, bank, tracker, created_by=created_by, config=config, bm25=bm25)
    chosen = names or ["grep", "read", "outline", "list_docs", "add_evidence", "submit"]
    assert len(chosen) <= 6, "small-model rule: expose at most 6 tools per agent"
    return [
        StructuredTool.from_function(
            func=specs[n].fn, name=n, description=specs[n].description, args_schema=specs[n].args_schema
        )
        for n in chosen
    ]


# For LlamaIndex (optional):  FunctionTool.from_defaults(fn=spec.fn, name=spec.name, description=spec.description)
# For the internal SDK: iterate build_specs() and register (name, description, args_schema.model_json_schema(), fn).
