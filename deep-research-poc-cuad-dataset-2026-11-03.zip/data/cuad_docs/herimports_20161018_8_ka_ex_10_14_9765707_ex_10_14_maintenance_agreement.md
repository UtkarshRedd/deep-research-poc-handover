<!-- page 1 -->
# SOFTWARE MAINTENANCE AGREEMENT
| Field | Value |
|---|---|
| Document Type | Maintenance Agreement |
| Agreement Date | 2016-10-13 |
| Parties | Leader Act Ltd (“LEADER”); EZJR, Inc. (“EZJR”); |
| Source | CUAD v1 / HerImports_20161018_8-KA_EX-10.14_9765707_EX-10.14_Maintenance Agreement |

Exhibit 10.14 SOFTWARE MAINTENANCE AGREEMENT This Software Maintenance Agreement (the "Agreement")
is entered into as of October 13, 2016, between Leader Act Ltd HK ("LEADER"), a Nevada Corporation,
(hereinafter referred to as "Leader"), and EZJR, Inc. a Nevada corporation, (hereinafter referred to
as "EZJR"). WHEREAS, EZJR currently owns a Customer Relationship Management ("CRM") software program
as developed by LEADER; and WHEREAS, upon the purchase of the software EZJR entered into an
agreement for LEADER to maintain the software for a period of two years after which LEADER was be
paid by EZJR to service and maintain the software; and WHEREAS, this previous agreement expired on
May 28, 2016; NOW THEREFORE, in consideration of the mutual agreements, representations and
warranties in this Agreement, the parties agree as follows: 1. EXTENSION OF SERVICE AGREEMENT.
Subject to all other terms and conditions set forth herein, as of the date of this agreement, LEADER
maintain the software for an additional five years. 2. COMPENSATION TO LEADER. The compensation to
LEADER shall be: 3,000,000 shares of EZJR's unregistered restricted common stock which shall be
issuable upon the closing; 3. LEADER' REPRESENTATIONS AND WARRANTIES. LEADER represents and warrants
to EZJR as follows: A. LEADER is a corporation duly organized, validly existing, and in good
standing under the laws of the Nevada. Leader has all requisite corporate power and authority to
enter into this Agreement and perform its obligations hereunder. B. The execution, delivery, and
performance of this Agreement has been duly authorized and approved by the Board of Directors of
LEADER, and this Agreement constitutes a valid and binding Agreement of LEADER in accordance with
its terms. C. LEADER has not employed any broker or finder in connection with the transaction
contemplated by this Agreement and has taken no action that would give rise to a valid claim against
any party for a brokerage commission, finder's fee, or other like payment. D. LEADER has not
employed any broker or finder in connection with the transactions contemplated by this Agreement, or
taken action that would give rise to a valid claim against any party for a brokerage commission,
finder's fee, or other like payment.

Source: HER IMPORTS, 8-K/A, 10/18/2016
<!-- page 2 -->
F. The execution and delivery of this Agreement by LEADER and the consummation of the contemplated
transactions, will not result in the creation or imposition of any valid lien, charge, or
encumbrance on any of the Assets, and will not require the authorization, consent, or approval of
any third party, including any governmental subdivision or regulatory agency. G. LEADER has no
knowledge of any claim, litigation, proceeding, or investigation pending or threatened against
LEADER or its Assets that might result in any material adverse change in the business or condition
of the Assets being conveyed under this Agreement. H. None of the representations or warranties of
LEADER contain or will contain any untrue statement of a material fact or omit or will omit or
misstate a material fact necessary in order to make statements in this Agreement not misleading.
LEADER knows of no fact that has resulted, or will result in a material change in the business,
operations, or assets of LEADER. 4. REPRESENTATIONS OF EZJR. EZJR represents and warrants as
follows: A. EZJR is a corporation duly organized, validly existing, and in good standing under the
laws of the State of Nevada. EZJR has all requisite corporate power and authority to enter into this
Agreement and perform its obligations hereunder. B. The execution, delivery, and performance of this
Agreement has been duly authorized and approved by the Board of Directors of EZJR, and this
Agreement constitutes a valid and binding Agreement of EZJR in accordance with its terms. C. EZJR
has not employed any broker or finder in connection with the transaction contemplated by this
Agreement and has taken no action that would give rise to a valid claim against any party for a
brokerage commission, finder's fee, or other like payment. D. None of the representations or
warranties of EZJR contain or will contain any untrue statement of a material fact or omit or will
omit or misstate a material fact necessary in order to make the statements contained herein not
misleading. 3. INDEMNIFICATION AND SURVIVAL. All representations and warranties made in this
Agreement shall survive the Closing of this Agreement, except that any party to whom a
representation or warranty has been made in this Agreement shall be deemed to have waived any
misrepresentation or breach of representation or warranty of which such party had knowledge prior to
Closing. Any party learning of a misrepresentation or breach of representation or warranty under
this Agreement shall immediately give written notice thereof to all other parties to this Agreement.
The representations and warranties in this Agreement shall terminate one year from the Closing Date,
and such representations or warranties shall thereafter be without force or effect, except any claim
with respect to which notice has been given to the party to be charged prior to such expiration
date. LEADER hereby agrees to indemnify and hold EZJR, it successors, and assigns harmless from and
against any and all damage or deficiency resulting from any material misrepresentation, breach of
warranty or covenant, or nonfulfillment of any agreement on the part of LEADER under this Agreement.

Source: HER IMPORTS, 8-K/A, 10/18/2016
<!-- page 3 -->
4. GOVERNING LAW. This Agreement and any matters arising out of or related to this Agreement will be
governed by the laws of the State of Nevada. If any action is brought among the parties with respect
to this Agreement or otherwise, by way of a claim or counterclaim, the parties agree that in any
such action, and on all issues, the parties irrevocably waive their right to a trial by jury.
Exclusive jurisdiction and venue for any such action shall be the State Courts of Nevada. 5. ENTIRE
AGREEMENT. This Agreement contains the entire agreement among the parties, and supersedes all prior
agreements, representations and understandings of the parties, relating to the subject matter of
this Agreement. 6. FURTHER ACTIONS. Each party agrees that after the delivery of this Agreement it
or he will execute and deliver such further documents and do such further acts and things as another
party may reasonably request in order to carry out the terms of this Agreement. 7. AMENDMENT. No
supplement to or amendment of this Agreement will be binding unless executed in writing by LEADER
and EZJR. 8. SUCCESSORS AND ASSIGNS. This Agreement will be binding on, and will inure to the
benefit of, the parties and their respective successors and assigns, and shall not confer any rights
or remedies on any other Persons. 9. COUNTERPARTS. This Agreement may be executed in one or more
counterparts, each of which will be deemed a valid, original agreement, but all of which together
will constitute one and the same instrument. 10. SEVERABILITY. If any provision of this Agreement or
its application to any Person or circumstances is held to be unenforceable or invalid by any court
of competent jurisdiction, its other applications and the remaining provisions of this Agreement
will be interpreted so as best reasonably to effect the intent of the parties. 11. ATTORNEYS' FEES.
Each party will pay its or his own legal fees and other expenses in connection with the preparation
of this Agreement and the sale of Assets in accordance with this Agreement. However, if any legal
action or other proceeding is brought for the enforcement of this Agreement, or because or arising
out of an alleged dispute, breach, default or misrepresentation in connection with any of the
provisions of this Agreement, the prevailing party will be entitled to recover reasonable attorney's
fees and other costs incurred in that action or proceeding, in addition to any other relief to which
it or he may be entitled. 12. NOTICES. All notices, requests, demands, and other communications
required or permitted hereunder will be in writing and will be deemed to have been duly given when
delivered by hand, by overnight courier, or fax, or two days after being mailed by certified or
registered mail, return receipt requested, with postage prepaid. 13. WAIVERS. Any provision of this
Agreement may be waived at anytime by the party entitled to the benefit thereof by a written
instrument executed by the party or by a duly authorized officer of the party. No waiver of any of
the provisions of this Agreement will be deemed, or will constitute, a waiver of any other
provision, whether or not similar, nor will any waiver constitute a continuing waiver.

Source: HER IMPORTS, 8-K/A, 10/18/2016
<!-- page 4 -->
SIGNATURES EZJR, INC. LEADER ACT LTD HK By: /s/ Barry Hall /s/ Aymen Boughanmi Barry Hall Aymen
Boughanmi Chief Executive Officer President

Source: HER IMPORTS, 8-K/A, 10/18/2016
<!-- page 5 -->
Exhibit A Customer Relationship Management System Description The Customer Relationship Management
("CRM") system entails all aspects of interaction that a company has with its customer, whether it
is sales or service-related. It also provides a greater understanding of the customer and helps
manage customer data and all interaction with the customer. Advantages and features of the CRM are
as following: ● Enhanced customer relationship management including retention tools and fraud
prevention. ● Recurring billing feature that allows for fully automated billing and tools to
determine approval and decline rates and automated retries of declines. ● Profit management tools
including affiliate commission tracking, price point testing and indemnification of revenue loss
causes. ● Gateway integration and merchant account load balancing. ● Improved affiliate management
and affiliate fraud detection. ● Better reporting and performance tracking.

Source: HER IMPORTS, 8-K/A, 10/18/2016
<!-- page 6 -->
Source: HER IMPORTS, 8-K/A, 10/18/2016
