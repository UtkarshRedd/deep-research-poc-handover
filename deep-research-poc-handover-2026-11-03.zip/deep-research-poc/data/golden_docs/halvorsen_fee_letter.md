<!-- page 1 -->
# Fee Letter — Halvorsen Marine Holdings
| Field | Value |
|---|---|
| Document Type | Fee Letter |
| Effective Date | 2025-02-14 |
| Parties | Halvorsen Marine Holdings, Inc.; Meridian Trust Bank, N.A. |
| Facility ID | FAC-2025-0042 |
| Version | Original (Execution Version) |

Reference: MTB-2025-FEE-0042
Meridian Trust Bank, N.A.
One Meridian Plaza, 18th Floor, New York, New York 10005

2025-02-14

Halvorsen Marine Holdings, Inc.
1200 Harbor Way, Suite 400, Seattle, Washington 98101

Re: Credit Agreement dated as of 2025-02-14 (facility FAC-2025-0042) — Fees

Ladies and Gentlemen:
This letter (this "Fee Letter") sets forth the fees payable by the Borrower in connection with the Credit Agreement. Capitalized terms used but not defined herein have the meanings given in the Credit Agreement. This Fee Letter is a Loan Document.
<!-- page 2 -->
## 1. Fees
(a) Upfront Fee. On the Effective Date, the Borrower shall pay to the Administrative Agent, for the account of each Lender, an upfront fee equal to 0.75% of such Lender's Commitment on the Effective Date.
(b) Agency Fee. The Borrower shall pay to the Administrative Agent, for its own account, an annual agency fee of $75,000, payable in advance on the Effective Date and on each anniversary thereof.
(c) Commitment Fee. The commitment fee set forth in Section 3.3 of the Credit Agreement accrues at 0.375% per annum on the unused Commitments.
## 2. Payment
All fees are payable in immediately available funds, without setoff or counterclaim, to the Administrative Agent at Meridian Trust Bank, N.A. , Account No. 4471-882901, reference MTB-2025-FEE-0042.
Fees paid are non-refundable under all circumstances.
<!-- page 3 -->
## 3. Confidentiality; Governing Law
The Borrower shall keep this Fee Letter confidential and shall not disclose it to any person other than its officers, directors, advisors and the Lenders, except as required by law.
This Fee Letter shall be governed by the laws of the State of New York.
Very truly yours,
Meridian Trust Bank, N.A., as Administrative Agent — By: /s/ Authorized Signatory
Accepted and agreed: Halvorsen Marine Holdings, Inc. — By: /s/ Authorized Signatory
