# What exclusivity obligation does the Collaboration Agreement ("A between FibroGen, Inc....

*Question:* What exclusivity obligation does the Collaboration Agreement ("A between FibroGen, Inc. and Astellas Pharma Inc. (dated 2005-06-01) impose?

> **Partial report.** Research or writing ended before completion; see the gaps and the appendix.

## Answer

[GAP] No evidence was found for: Answer the question: What exclusivity obligation does the Collaboration Agreement ("A between FibroGen, Inc. and Astellas Pharma Inc. (dated 2005-06-01) impose?

## Verification appendix

Claims: 1 · supported: 0 · partially: 0 · dropped: 0 · gaps: 1

Notes: no evidence in the bank; every section is a gap; OpenAIRateLimitError: Error code: 429

| claim | section | tier 1 | score | sources | note |
|---|---|---|---|---|---|
| s1.1 | s1 | gap |  |  |  |

### Evidence

