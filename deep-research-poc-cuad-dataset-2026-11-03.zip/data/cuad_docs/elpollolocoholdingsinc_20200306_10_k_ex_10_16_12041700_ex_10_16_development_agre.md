<!-- page 1 -->
# FRANCHISE DEVELOPMENT AGREEMENT (Non-exclusive/Exclusive)
| Field | Value |
|---|---|
| Document Type | Development Agreement |
| SEC Filing Date | 2020-03-06 |
| Parties | EL POLLO LOCO, INC. ("El Pollo Loco" or "Franchisor"); an individual ("Developer") |
| Source | CUAD v1 / ElPolloLocoHoldingsInc_20200306_10-K_EX-10.16_12041700_EX-10.16_Development Agreement |

Exhibit 10.16

EL POLLO LOCO® FRANCHISE DEVELOPMENT AGREEMENT

Dated: ____________________

Territory: Developer:

(Disclosure Document Control No. 032619)

TABLE OF CONTENTS 1.DEVELOPMENT RIGHTS IN TERRITORY. 4 2.LIMITATION ON DEVELOPMENT RIGHTS. 5
3.DEVELOPMENT FEE. 9 4.TERM OF DEVELOPMENT AGREEMENT. 10 5.TERRITORY CONFLICTS. 10 6.PROPRIETARY
RIGHTS OF EL POLLO LOCO. 11 7.INSURANCE AND INDEMNIFICATION. 11 8.TRANSFER OF RIGHTS. 13
9.ACKNOWLEDGMENT OF SELECTED TERMS AND PROVISIONS OF THE FRANCHISE AGREEMENT. 14 10.TERMINATION BY
DEVELOPER; EXPIRATION DATE. 14 11.EVENTS OF DEFAULT. 15 12.EFFECT OF TERMINATION. 16 13.NON-WAIVER.
17 14.INDEPENDENT CONTRACTOR AND INDEMNIFICATION. 17 15.ENTIRE AGREEMENT. 17 16.DISPUTE RESOLUTION
18 17.SEVERABILITY. 19 18.APPLICABLE LAW; CHOICE OF FORUM; WAIVER OF JURY TRIAL. 19 19.DOCUMENT
INTERPRETATION. 19 20.COVENANT NOT TO COMPETE. 20 21.NOTICES. 21 22.SECTION HEADINGS. 21
23.ACKNOWLEDGMENTS. 21 24.COUNTERPARTS. 22 Source: EL POLLO LOCO HOLDINGS, INC., 10-K, 3/6/2020
<!-- page 2 -->
EXHIBITS EXHIBIT "A" TO DEVELOPMENT AGREEMENT - TERRITORY23 EXHIBIT "B" TO DEVELOPMENT AGREEMENT -
DEVELOPMENT SCHEDULE24 EXHIBIT "C" TO DEVELOPMENT AGREEMENT - EXISTING EL POLLO LOCO® RESTAURANTS IN
THE TERRITORY 25

EL POLLO LOCO® FRANCHISE DEVELOPMENT AGREEMENT (Non-exclusive/Exclusive)

THIS FRANCHISE DEVELOPMENT AGREEMENT ("Agreement") dated for identification purposes only as of
_____________________, is made and entered into by and between EL POLLO LOCO, INC., a Delaware
corporation, with its principal place of business at 3535 Harbor Blvd, Suite 100, Costa Mesa,
California 92626 (referred to herein as "El Pollo Loco" or "Franchisor") and __________________an
individual, with its principal place of business at _____________________________________
("Developer").

Recitals.

A.Franchisor owns certain proprietary and other property rights and interests in and to the "El
Pollo Loco®" trademark and service mark, and such other trademarks, service marks, logo types,
insignias, trade dress designs and commercial symbols as Franchisor may from time to time authorize
or direct Developer to use in connection with the operation of a(n) "El Pollo Loco®" restaurant (the
"El Pollo Loco® Marks"). Franchisor has a distinctive plan for the operation of retail outlets for
the sale of fire-grilled food items and related products, which plan includes but is not limited to
the El Pollo Loco® Marks and the Operations Manual (the "Manual"), policies, standards, procedures,
employee uniforms, signs, menu boards and related items, and the reputation and goodwill of the El
Pollo Loco® chain of restaurants (collectively, the "El Pollo Loco® System").

B.Developer represents that it is experienced in and has independent knowledge of the nature and
specifics of the restaurant business. Developer represents that in entering into this Agreement it
has relied solely on its personal knowledge and has not relied on any representations of Franchisor
or any of its officers, directors, employees or agents, except those representations contained in
any legally required Franchise Disclosure Document delivered to Developer.

C. Developer desires to obtain development rights for multiple restaurants under the El Pollo Loco®
System (each, an "El Pollo Loco® Restaurant") from Franchisor within a specified geographical (the
"Territory") specified in Exhibit "A" attached hereto and made a part hereof (or if single unit,
replace with "Developer desires to obtain development rights for a single restaurant under the El
Pollo Loco® System (each, an "El Pollo Loco® Restaurant") from Franchisor within a specified address
(the "Territory") specified in Exhibit "A" attached hereto and made a part hereof.")

D.Franchisor is willing to grant the (non-exclusive/exclusive) right to develop and open El Pollo
Loco® Restaurant(s) within the Territory referenced in Exhibit "A."

NOW, THEREFORE, in consideration of the mutual covenants and obligations herein contained, the
parties hereto agree as follows:

1.Development Rights in Territory.

1.1. Franchisor hereby grants to Developer, subject to the terms and conditions of this Agreement
(if Section 2.20 is applicable add ", and specifically Section 2.20 hereof,") and as long as
Developer shall not be in default of this Agreement or any other development, franchise or other
agreement between Developer and Franchisor, (non-exclusive/exclusive) development rights to
establish and operate ____ franchised restaurant(s), and to use the El Pollo Loco® System solely in
connection therewith, at specific locations to be designated in separate Franchise Agreement(s) (the
"Franchise Agreements"). (If exclusive agreement, add "Developer expressly acknowledges that the
exclusive rights granted herein apply only to the right to develop new restaurants in the Territory,
and no exclusive territory or radius protection for the term of any Franchise Agreement is granted
herein and any such protection shall be set forth in the particular Franchise Agreement to be
signed.") The Franchise Agreements (and all ancillary documents attached as Exhibits to the
Franchise Agreement, including the Personal Guarantee) executed in accordance with this Agreement
shall be in the form currently in use by Franchisor at the time of execution of the Franchise
Agreement and shall be executed individually by each person, partner, member or shareholder.

1.2. (Only applies if exclusive Agreement. Delete if non-exclusive Agreement.) Except as otherwise
provided in this Agreement and subject to the terms and conditions of Section 2.20 hereof, after the
date of this

Source: EL POLLO LOCO HOLDINGS, INC., 10-K, 3/6/2020
<!-- page 3 -->
Agreement and during the term of this Agreement, and so long as Developer is in compliance with its
obligations under this Agreement, Franchisor shall neither, without Developer's prior written
consent: (i) grant development rights to anyone else with respect to the Territory or any part of
the Territory; nor (ii) establish or franchise any person to establish an El Pollo Loco restaurant
under the Marks and System at any location within the Territory. Franchisor expressly retains all
other rights and may, among other things, on any terms and conditions Franchisor deems advisable,
and without granting Developer any rights therein:

a. Establish and operate or franchise others to establish and operate an El Pollo Loco restaurant
located outside of the Territory;

b. Sell the same or similar products (whether or not using the Marks), as will be sold by Developer
in a developed El Pollo Loco restaurant, to customers at any retail location (whether within or
outside of the Territory), through any method or channel of distribution, including, without
limitation, at retail locations such as grocery or convenience stores and via the Internet,
telemarketing and direct marketing means, through other non-El-Pollo Loco restaurants having the
same or similar menu items, or through any other distribution channel;

c. Establish and operate or franchise others to establish and operate restaurants (not using the
Marks) having the same or similar menu items whether within or outside of the Territory; and

d. Any continued operation by Franchisor, or the allowance of any continued operation by a
franchisee of Franchisor, of an El Pollo Loco restaurant within the Territory which was opened on or
before the date of this Agreement shall not be considered to constitute a breach of this Agreement.

1.3. (Only applies to multi-unit Development Agreement - delete if single-unit Development
Agreement). Prior to or concurrent with the execution of this Agreement, Developer shall meet with
Franchisor's development representatives and prepare a market development plan for the units to be
constructed and opened by Developer in the Territory (identifying specific key areas, key
intersections and trade areas in the Territory) and all development pursuant to this Agreement shall
be in accordance with this plan (the "Market Plan"). The Market Plan shall include proposed areas
where sites may be located, ranking and prioritization of site locations and other information
customarily used by market planners in the restaurant industry. Developer and Franchisor shall
jointly approve the Market Plan.

2. Limitation on Development Rights.

2.1. Developer must submit one or more site(s) for approval, enter into binding leases or purchase
agreements and open to the public the number of El Pollo Loco® Restaurant(s) on such approved sites
each calendar year as required on the Development Schedule, all as set forth on Exhibit "B" attached
hereto and made a part hereof.

2.2. For purposes of the Development Schedule in Exhibit "B", no credit will be given for the
development of El Pollo Loco® Restaurant(s) outside the Territory, regardless of the fact that
Developer may, upon proper application, obtain from Franchisor an El Pollo Loco® Franchise Agreement
("Franchise Agreement") for any such development.

2.3. Although this Agreement affords the Developer the right to develop and open El Pollo Loco®
restaurant(s) within the Territory, as set forth on Exhibit "A", all Restaurant(s) developed under
this Agreement must be duly licensed through individual Franchise Agreement(s). Developer will
execute El Pollo Loco's then standard Franchise Agreement in use at the time of execution for each
restaurant developed under this Agreement, and agrees to pay Franchisor the current fees, royalties
and other required payments in accordance with the Franchise Agreement and Franchise Disclosure
Document then in effect. Execution of the appropriate Franchise Agreement and payment of the initial
franchise fee and/or any other required fees must be accomplished prior to the commencement of
construction at any site.

2.4. Developer must satisfy all Franchisor's financial and operational criteria then in effect and
in addition, if Developer is also a Franchisee of one or more El Pollo Loco Restaurants, Franchisee
must also be in good standing with Franchisor and satisfy all Franchisor's financial and operational
criteria then in effect prior to El Pollo Loco's execution of each standard Franchise Agreement
issued pursuant to this Agreement. Developer shall provide Franchisor with current information
pertaining to Developer's financial condition and the financial condition of the majority and
managing members/partners/shareholders of Developer at any time upon El Pollo Loco's request and in
no event less than once annually. Developer acknowledges that, among other things, it will be

Source: EL POLLO LOCO HOLDINGS, INC., 10-K, 3/6/2020
<!-- page 4 -->
required to submit annual financial statements of Developer and personal financial statements of
each of its principal owners and Managing Members to be eligible for financial approval by El Pollo
Loco. In the event any of the majority owners of Developer shall also be the Managing Members and/or
majority owners of any other entity which is a franchisee of El Pollo Loco, then each such
franchisee entity must be operationally and financially approved by Franchisor before approval for
expansion will be granted to any one franchisee entity. "Managing Members" shall be any individuals
who are designated as the primary decision makers or general managers of the franchisee entity and
those individuals who (individually or collectively) own at least 51% interest in the franchisee
entity.

2.5. Developer shall use its best efforts to retain qualified real estate professionals (including
licensed brokers) to locate proposed sites for the El Pollo Loco® Restaurant(s). Developer shall
submit proposed sites for each El Pollo Loco® Restaurant unit to be developed under this Agreement
for acceptance by Franchisor's Real Estate Site Approval Committee ("RESAC"), together with such
site information as may be reasonably required by Franchisor to evaluate the proposed site, no later
than the dates set forth in Exhibit "B" as RESAC Submittal Dates, the first of which shall be
approximately ninety (90) days after execution of this Agreement. Should the site be accepted by
RESAC, it will be referred to as the "Approved Site". Such acceptance will expire one (1) year from
the RESAC approval date. Franchisor may require, as a condition to its approval of a site, a "Market
Study", which shall include a site description and analysis, traffic and other demographic
information and an analysis of the impact of the proposed site on other company owned and franchised
El Pollo Loco restaurants surrounding or within the vicinity of such proposed site all in such
format as the Franchisor may require. All such analyses, information and studies shall be prepared
at the sole cost and expense of Developer.

2.6. Franchisor shall send representatives to evaluate proposed site(s) for each El Pollo Loco®
Restaurant to be developed under this Agreement, and Franchisor will do so at its own expense for
the first two (2) proposed sites for each El Pollo Loco® Restaurant. If Developer proposes, and
Franchisor evaluates, more than two (2) sites for each El Pollo Loco® Restaurant, then Developer
shall reimburse Franchisor for the reasonable costs and expenses incurred by Franchisor's
representatives in connection with the evaluation of such additional proposed site(s), including,
without limitation, the costs of lodging, travel, meals and wages.

2.7. Provided there exists no default by Developer under this Agreement or any other development,
franchise or other agreement between Franchisor and Developer, Franchisor shall evaluate each site
proposed for which Developer has provided all necessary evaluation information, and shall promptly
after receipt of Developer's proposal, send to Developer written notice of acceptance or
non-acceptance of the sit

2.8. If RESAC determines through its evaluation of the proposed site that the proposed site may
impact sales at any company-owned El Pollo Loco® Restaurant, Franchisor has the sole and absolute
right to accept or reject the proposed site, without any obligation to discuss a possible resolution
with Developer. However, Franchisor may elect to discuss with Developer a possible resolution with
regard to the proposed site; however, if such an agreement cannot be reached, Franchisor has the
sole and absolute right to reject the proposed site. If RESAC determines through its evaluation of
the proposed site that the proposed site may potentially impact sales at any existing El Pollo Loco®
franchisee's restaurant, Franchisor shall notify Developer of the existing El Pollo Loco®
franchisees' location(s) and contact information. If nevertheless Developer wishes to try to proceed
with that site, Developer must obtain a written waiver from those existing El Pollo Loco®
franchisees of any claims they might have against Developer and Franchisor with respect to the
proposed new El Pollo Loco® Restaurant. Such waiver, if obtained, must be submitted along with the
evaluation information required pursuant to this Section.

2.9. No later than the Site Commitment Dates set forth in Exhibit "B", Developer shall submit for
the Approved Site to Franchisor for its review and approval of:

a. A fully negotiated but unexecuted lease, which may only subject to obtaining necessary
governmental permits. The unexecuted form of the lease must be submitted to Franchisor to review for
the required terms and conditions listed in Sections 2.9, 2.10, 2.11 and 2.12 below prior to full
execution of the lease. Franchisor will promptly notify Developer upon their approval of the
inclusion of such required terms and conditions. Developer will promptly then provide a final
executed copy of the lease to Franchisor; or

b. A purchase agreement. Should Developer purchase the site using another entity other than the
franchise entity, Developer must then enter into a lease with the Franchise entity as the lessee and
the purchasing entity as the lessor and must comply with all the requirements of this Sections 2.9,
2.10, 2.11 and 2.12 below).

2.10. Any lease to be entered into by Developer shall include the terms and conditions set forth
below and in a form approved by Franchisor:

Source: EL POLLO LOCO HOLDINGS, INC., 10-K, 3/6/2020
<!-- page 5 -->
a. The tenant entity on the lease must match the franchise entity on the franchise agreement; and

b. The term (with renewal options) of the lease must match at least the initial term of the
franchise agreement; and

c. The landlord consents to your use of the premises as an El Pollo Loco® restaurant which will be
open during the required days and hours set out in the Operations Manual.

2.11. Franchisor shall have no liability under any lease or purchase agreement for any El Pollo
Loco® Restaurant location developed under this Agreement and shall not guarantee Developer's
obligations thereunder. Upon approval by Franchisor of the form of Developer's lease and execution
of a lease for a site by Developer, Developer shall furnish to Franchisor a fully executed copy of
such lease and any amendments thereto within fifteen (15) calendar days of such execution.
Franchisor shall have no obligation to assist Developer to negotiate its leases.

2.12. The lease or deed may not contain a non-competition covenant which restricts Franchisor or any
franchisee or licensee of Franchisor, from operating an El Pollo Loco® Restaurant or any other
retail restaurant, unless such covenant is approved by Franchisor in writing prior to the execution
by Developer of the lease.

2.13. Each subsequent site to be developed pursuant to the Development Schedule shall be submitted
for approval by RESAC by the date set forth in Exhibit "B". Similarly, each fully executed lease
(executed upon prior review and approval by Franchisor) or purchase agreement (with all
contingencies to Developer's obligations waived or satisfied, except permitting contingencies)
relating to each subsequent Approved Site shall: (1) be delivered to Franchisor on or before the
Site Commitment Date for each respective El Pollo Loco® Restaurant as set forth in Exhibit "B" and
(2) prior to the execution of your Franchise Agreements (3) prior to the payment of your initial
Franchise Fees for each site and (4) prior to the commencement of construction of the El Pollo Loco®
Restaurant.

2.14. RESAC site approval does not assure that a Franchise Agreement will be executed. Execution of
the Franchise Agreement is contingent upon Developer completing the purchase or lease of the
proposed site within sixty (60) days after approval of the site by the Franchisor or no later than
the dates set forth in Exhibit "B" as Site Committment Dates.

2.15. Developer acknowledges that time is of the essence in this Agreement. If Developer has not
obtained approval and entered into a binding lease or purchase agreement for each site for El Pollo
Loco® Restaurant(s) to be developed under this Agreement by the applicable Site Commitment Date,
Developer shall be in default of its obligations under the Development Schedule and Franchisor shall
be entitled to exercise its rights and remedies under this Agreement, up to and including
termination of this Agreement.

2.16. Developer also acknowledges that it is required pursuant to this Agreement to open El Pollo
Loco® Restaurants in the future pursuant to dates set forth in the Development Schedule attached as
Exhibit "B". If Developer fails to meet the opening date for any El Pollo Loco® Restaurant to be
developed under this Agreement, Developer shall be in default and Franchisor shall be entitled to
exercise all rights and remedies available to Franchisor set forth in Section 11. Developer
acknowledges that if Developer fails to open El Pollo Loco® Restaurants in a timely manner pursuant
to the Development Schedule, Franchisor will suffer lost revenues, including royalties and other
fees which would be difficult to calculate and which Franchisor would have received had Developer
met the agreed schedule or had Franchisor had the right to grant development rights to others in the
Territory.

2.17. Developer acknowledges that the estimated initial investment and estimated expenses set forth
in Items 6 and 7 of our Franchise Disclosure Document are subject to and likely to increase over
time, and that future El Pollo Loco® Restaurants will likely involve a greater initial investment
and operating capital requirements than those stated in the Franchise Disclosure Document provided
to you prior to your execution of this Agreement.

2.18. Developer understands and acknowledges that in accepting Developer's proposed site or by
granting a franchise for each approved site, Franchisor does not in any way, endorse, warrant or
guarantee either directly or indirectly the suitability of such site or the success of the franchise
business to be operated by Developer at such site. The suitability of the site and the success of
the franchise business depend upon a number of factors outside of Franchisor's control, including,
but not limited to, the Developer's operational abilities, site location, consumer trends and such
other factors that are within the direct control of the Developer. Source: EL POLLO LOCO HOLDINGS,
INC., 10-K, 3/6/2020
<!-- page 6 -->
2.19. The purpose of this Agreement is to promote orderly incremental growth within the El Pollo
Loco® System. The acquisition of existing El Pollo Loco® restaurants by Developer does not represent
incremental growth and, therefore, does not satisfy the terms of this Agreement pertaining to
development.

2.20. (To be added where there are existing restaurants in the Territory) Developer acknowledges
that Franchisor (i) is operating or has franchised another to operate, one (1) or more restaurants
in the Territory or (ii) has granted franchise rights to another in the Territory or (iii) approved
a new site for development for those locations identified in Exhibit "C" attached hereto and
incorporated herein by this reference. Developer further acknowledges that Franchisor retains the
sole and absolute right to approve or disapprove any proposed location for development under this
Agreement if, in Franchisor's reasonable judgment: (i) such proposed location is not suitable for an
El Pollo Loco® Restaurant or (ii) such proposed location will have a material adverse effect on the
profitability of another existing El Pollo Loco® location (or approved site) in the Territory.
Developer covenants to use its reasonable best efforts to avoid selecting proposed locations that
would adversely impact pre-existing locations in the Territory.

3. Development Fee.

3.1. Developer shall pay to Franchisor upon execution of this Agreement a non-refundable Development
Fee (the "Development Fee") equal to Twenty Thousand Dollars ($20,000) in immediately available
funds, for each El Pollo Loco® Restaurant to be developed under this Agreement. The Development Fee
is consideration for this Agreement. The Development Fee is not consideration for any Franchise
Agreement and is non-refundable. The $20,000 Development Fee for each El Pollo Loco® Restaurant
shall be applied against the initial franchise fee payable upon the execution of the Franchise
Agreement applicable to such El Pollo Loco® Restaurant. As a benefit of signing the Development
Agreement, the Initial Fee for the second and each subsequent restaurant developed under the same
Development Agreement will be reduced by us to $30,000. As an example, the Initial Fee for the first
restaurant developed under a Development Agreement would be $40,000 to which $20,000 (from the
Development Fee will be credited. The Initial Fee for the second and remaining restaurants developed
under the same Development Agreement would be $30,000, to which $20,000 from the Development Fee
will be credited. If this Agreement is terminated pursuant to Sections 10 or 11 below, Developer
will lose its right to develop and Development Fee.

4. Term of Development Agreement.

4.1. This Agreement shall commence on the date specified in Exhibit "B". Unless terminated pursuant
to Section 10 or 11 below, it shall expire upon the earlier of the date specified in Exhibit "B" or
upon the opening of the last El Pollo Loco® Restaurant listed in the Development Schedule.

5. Territory Conflicts.

5.1. The rights granted Developer in this Agreement are subject to any prior territorial rights of
other franchisees which may now exist in the Territory, whether or not those rights are currently
being enforced. In the event of a conflict in territorial rights, whether under a Franchise
Agreement or separate territorial or development agreement, Developer shall be free to negotiate
with any person, corporation or other entity, which claims territorial rights adverse to the rights
granted under this Agreement, for the assignment of those prior territorial rights. For this
purpose, Franchisor agrees to approve any such assignment not in conflict with the other terms of
this Agreement, subject to the condition of any Franchise Agreements involved, and current policies
pertaining to assignments, including, but not limited to, satisfaction of all past due debts owed to
Franchisor and the execution of a General Release.

5.2. In the event of third party claims of the right to develop the Territory, it is the sole
responsibility of El Pollo Loco, where the right granted herein is exclusive, to protect and
maintain Developer's right to the development of the Territory. However, if it appears to El Pollo
Loco, as its sole and absolute right to determine, that protection of the Territory by legal action
is not advisable, whether due to the anticipation of, or the actual protracted nature of the action,
the costs involved, the uncertainty of outcome, or otherwise, Franchisor has the right to terminate
this Agreement, provided that it refunds to Developer the balance, if any, of the Development Fee
made pursuant to Section 3, which has not been applied against the initial franchise fees for
Franchise Agreement(s) to be acquired under this Agreement.

6. Proprietary Rights of El Pollo Loco. Source: EL POLLO LOCO HOLDINGS, INC., 10-K, 3/6/2020
<!-- page 7 -->
6.1. Developer expressly acknowledges El Pollo Loco's exclusive right, title, and interest in an to
the trade name, service mark and trademark "El Pollo Loco", and such other trade names, service
marks, and trademarks which are designated as part of the El Pollo Loco® System (the "Marks"), and
Developer agrees not to represent in any manner that Developer has any ownership in El Pollo Loco®
Marks. This Agreement is not a Franchise Agreement. Developer may not open an El Pollo Loco®
Restaurant or use the El Pollo Loco® Marks at a particular site until it executes a Franchise
Agreement for that site. Developer's use of the El Pollo Loco® Marks shall be limited to those
rights granted under each individual Franchise Agreement. Notwithstanding the foregoing, El Pollo
Loco® may authorize Developer in writing to use the Marks in connection with advertising and
marketing activities in connection with this Agreement. Developer expressly agrees that such usage
is limited to those specific activities or promotional materials approved by El Pollo Loco's
marketing department in advance. Developer further agrees that its use of the Marks shall not create
in its favor any right, title, or interest in or to El Pollo Loco® Marks, but that all of such use
shall inure to the benefit of El Pollo Loco, and Developer has no rights to the Marks except to the
degree specifically granted by the individual Franchise Agreement(s). Building designs and
specifications, color schemes and combinations, sign design specifications, and interior building
layouts (including equipment, equipment specification, equipment layouts, and interior color schemes
and combinations) are acknowledged by Developer to comprise part of the El Pollo Loco® System.
Developer shall have no right to license or franchise others to use the Marks by virtue of this
Agreement.

6.2. Developer acknowledges that, in connection with its execution of this Agreement, it may receive
confidential and proprietary information regarding the El Pollo Loco® System, including but not
limited to the El Pollo Loco Operational Manual. Developer recognizes the unique value and secondary
meaning attached to the El Pollo Loco® Marks and the El Pollo Loco® System, and Developer agrees
that any noncompliance with the terms of this Agreement or any unauthorized or improper use will
cause irreparable damage to Franchisor and its franchisees. Developer, therefore, agrees that if it
should engage in any such unauthorized or improper use during, or after, the term of this Agreement,
Franchisor shall be entitled to both seek temporary and permanent injunctive relief from any court
of competent jurisdiction in addition to any other remedies prescribed by law.

6.3. Developer acknowledges that it will receive one (1) copy of the Operations Manual on loan from
Franchisor and that the Operations Manual shall at all times remain the sole property of the
Franchisor.

7. Insurance and Indemnification.

7.1. Throughout the term of this Agreement, Developer shall obtain and maintain insurance coverage
for public liability, including products liability, in the amount of at least One Million Dollars
($1,000,000) combined single limit. Developer also shall carry such worker's compensation insurance
as may be required by applicable law.

7.2. Franchisor shall be named as an additional insured on all such insurance policies and shall be
provided with certificates of insurance evidencing such coverage. All public liability and property
damage policies shall contain a provision that El Pollo Loco, although named as an insured, shall
nevertheless be entitled to recover under such policies on any loss incurred by El Pollo Loco, its
affiliates, agents and/or employees, by reason of the negligence of Developer, its principals,
contractors, agents and/or employees. All policies shall provide Franchisor with at least thirty
(30) days' notice of cancellation or termination of coverage.

7.3. Franchisor reserves the right to specify reasonable changes in the types and amounts of
insurance coverage required by this Section 7. In the event that Developer fails or refuses to
obtain or maintain the required insurance coverage from an insurance carrier acceptable to El Pollo
Loco, Franchisor may, as its sole and absolute right and without any obligations to do so, procure
such coverage for Developer. In such event, Developer shall pay the required premiums or reimburse
such premiums to Franchisor upon written demand.

7.4. Developer shall defend immediately upon tender of defense, at its own cost, the Franchisor, its
subsidiaries, parent and affiliates, shareholders, directors, officers, employees and agents
(collectively for this section only known as "Franchisor"), from and against any and all claims,
lawsuits, complaints, cross complaints, arbitrations, demands, allegations, costs embraced by
indemnity, loss, costs, expenses (including attorneys' fees), liens and damages (collectively for
this section only known as "Losses"), however caused, and reimburse Franchisor for all costs and
expenses (including attorneys' fees) incurred by the Franchisor in defense of any Losses, resulting
directly or indirectly from or pertaining to or arising out of, or alleged to arise out of, or in
connection with Developer's activities under the Development Agreement, including any labor, any
employee related claims whatsoever, including, without limitation any claims made by an employee of
Developer resulting from the employee's training in a Franchisor operated facility or restaurant,
and including Developer's failure for

Source: EL POLLO LOCO HOLDINGS, INC., 10-K, 3/6/2020
<!-- page 8 -->
any reason to fully inform any third party of Developer's lack of authority to bind the Franchisor
for any purpose. Such Losses shall include, without limitation, those arising from the death of or
injury to any person or arising from damage to the property of Developer or the Franchisor, or any
third person, firm or corporation, whether or not resulting from any strict liability imposed by
fact, law, statute, or ordinance, on the Franchisor. Developer further agrees that Developer's duty
to defend the Franchisor is separate from, independent of and free-standing of Developer's duty to
indemnify the Franchisor and applies whether the issue of Developer's negligence, breach of
contract, or other fault or obligation has been determined. Developer's duty to defend is regardless
of the outcome of liability even if Developer is ultimately found not negligent and not dependent on
the ultimate resolution of issues arising out of any claims, lawsuits, complaints, cross complaints,
arbitration, demands, allegations, costs embraced by indemnity, loss, costs, expenses (including
attorneys' fees), liens or damages.

7.5. Developer shall indemnify and hold harmless the Franchisor (as defined above) from and against
any and all Losses (as defined above), however caused, resulting directly or indirectly from or
pertaining to or arising out of or in connection with Developer's activities under the Development
Agreement, including any labor, any employee related claims whatsoever, including, without
limitation any claims made by an employee of Developer resulting from the employee's training in a
Franchisor operated facility or restaurant, and including Developer's failure for any reason to
fully inform any third party of Developer's lack of authority to bind the Franchisor for any
purpose. Such Losses shall include, without limitation, those arising from latent or other defects
in the restaurant whether or not discoverable by Franchisor, and those arising from the death of or
injury to any person or arising from damage to the property of Developer or the Franchisor, or any
third person, firm or corporation, whether or not resulting from any strict liability imposed by
fact, law, statute, or ordinance, on the Franchisor. Developer further agrees to indemnify and hold
harmless Franchisor from all said Losses and shall pay for and be responsible for all said Losses,
however caused, whether by any individual, employee, third person or party, vendor, visitor,
invitee, trespasser or any firm or corporation whatsoever, whether caused by or contributed to by
Franchisor, the combined conduct of Developer and Franchisor, or active or passive negligence of
Franchisor, but for the sole negligence or willful misconduct of Franchisor.

7.6. The provisions of this Section 7 shall expire as to each El Pollo Loco® Restaurant to be
developed under this Agreement upon execution of a Franchise Agreement for such El Pollo Loco®
Restaurant. The provision of the Franchise Agreement, in particular, Section 9 thereof (insurance
and Indemnification) shall supersede this Section 7 and govern the rights and obligations of the
parties prospectively.

8. Transfer of Rights.

8.1. This Agreement shall inure to the benefit of Franchisor and its successors and assigns, and is
fully assignable by El Pollo Loco.

8.2. The parties acknowledge and agree that this Agreement is personal in nature with respect to
Developer, being entered into by Franchisor in reliance upon and in consideration of the personal
skills, qualifications and trust and confidence reposed in Developer and Developer's present
partners, managing members or officers if Developer is a partnership, a limited liability company or
a corporation. Therefore, the rights, privileges and interests of Developer under this Agreement
shall not be assigned, sold, transferred, leased, divided or encumbered, voluntarily or
involuntarily, in whole or in part, by operation of law or otherwise without the prior written
consent of El Pollo Loco, which consent may be given or withheld as El Pollo Loco's sole and
absolute right. For purposes of this Section, a sale of stock, or any membership or partnership
interest in Developer, or a merger or other combination of Developer shall be considered a transfer
of Developer's interest prohibited hereunder. Notwithstanding the foregoing, Developer shall be
permitted to assign business organizations to serve as Franchisee after Developer individually
executes the Franchise Agreements, provided the ownership mirrors that of Developer (e.g., Developer
consists of persons A (50%), B (25%) and C (25%). Franchisee also must be owned and controlled by
the same three (3) persons with each retaining the same percentage of ownership). All other entity
structures shall require the prior written approval of Franchisor. Developer shall pay an
administrative fee of Five Hundred Dollars ($500) per transfer for each permitted transfer to an
Entity where such transfer is for the convenience of ownership only and does not involve a change of
principals of the business. Where Developer desires to add new principals to the Developer or any
Franchisee entity, Developer shall pay to Franchisor an additional Two Thousand Five Hundred Dollars
($2,500) per new principal to cover Franchisor's administrative costs for reviewing the application
and suitability of each new principal as participants in the franchise business.

9. Acknowledgment of Selected Terms and Provisions of the Franchise Agreement.

Source: EL POLLO LOCO HOLDINGS, INC., 10-K, 3/6/2020
<!-- page 9 -->
9.1. Developer represents that it has read each of the terms and provisions of the current form of
Franchise Agreement and acknowledges and is willing to agree to each and every obligation of
Franchisee thereunder (as they may be modified in then-current forms of Franchise Agreement)
including, but not limited to:

a. The obligation to deliver execute Personal Guarantees or Investor Covenants Regarding
Confidentiality and Non-Competition in connection with the execution of each franchise agreement for
El Pollo Loco® Restaurants to be developed under this Agreement;

b. The obligation to obtain the consent of Franchisor to any security interests to be granted by
Developer in the assets or business of the El Pollo Loco® Restaurant to lenders or other financing
sources in advance of any agreement to provide those security interests to such third parties;

c. All in-term and post-term restrictive covenants; and

d. All territorial rights, options and rights of first refusal retained by Franchisor under the
franchise agreement.

10. Termination by Developer; Expiration Date.

10.1. This Agreement shall terminate immediately upon El Pollo Loco's receipt of Developer's notice
to terminate. In such event, the Development Fee shall be forfeited to Franchisor in consideration
of the rights granted in the Territory up to the time of termination. Notwithstanding any provision
to the contrary contained herein, unless earlier terminated by either party, this Agreement shall
expire on ______, 20___, and all rights of Developer herein shall cease and all unapplied or unused
Development Fees paid pursuant to Section 3 hereof shall be forfeited to Franchisor.

11. Events of Default.

11.1. The following events shall constitute a default by Developer, which shall result in El Pollo
Loco's right to declare the immediate termination of this Agreement.

a. Failure by Developer to meet the requirements of the Development Schedule within the time periods
specified therein, including failure by Developer to meet the Site Commitment Date or Opening Date
for each site for an El Pollo Loco® Restaurant in a timely manner as set forth in Exhibit "B" and
Section 2 above.

b. Any assignment, transfer or sublicense of this Agreement by Developer without the prior written
consent of El Pollo Loco.

c. Any violation by Developer of any covenant, term, or condition of any note or other agreement
(including any El Pollo Loco® Franchise Agreement) between Developer and Franchisor (or an affiliate
of El Pollo Loco), the effect of which is to allow Franchisor to terminate (or accelerate the
maturity of) such agreement before its stated termination (or maturity) date.

d. Developer's assignment for the benefit of creditors or admission in writing of its inability to
pay its debts generally as they become due.

e. Any order, judgment, or decree entered adjudicating Developer bankrupt or insolvent.

f. Any petition, or application, by Developer to any tribunal for the appointment of a trustee,
receiver, or liquidator of Developer (or a substantial part of Developer's assets), or commencement
by Developer of any proceedings relating to Developer under any bankruptcy, reorganization,
compromise, arrangement, insolvency, readjustment of debt, dissolution, or liquidation law of any
jurisdiction, whether now or hereinafter in effect.

g. Any filing of a petition or application against Developer, or the commencement of such
proceedings, in which Developer, in any way, indicates its approval thereof, consent thereto, or
acquiescence therein; or the entry of any order, judgment, or decree appointing any trustee,
receiver, or liquidator, or approving the petition in any such proceedings, where the order,
judgment, or decree remains unstayed and in effect for more than thirty (30) days.

h. Any entry in any proceeding against the Developer of any order, judgment, or decree, which
requires the Source: EL POLLO LOCO HOLDINGS, INC., 10-K, 3/6/2020
<!-- page 10 -->
dissolution of Developer, where such order, judgment, or decree remains unstayed and in effect for
more than thirty (30) days.

i. Developer's voluntary abandonment of any of Developer's restaurants.

11.2. The following events shall constitute a default by Developer, which shall result in El Pollo
Loco's right to declare the termination of this Agreement, if such default is not cured within
thirty (30) days after written notice by Franchisor to Developer:

a. Developer's default in the performance or observance of any covenant, term, or condition
contained in this Agreement not otherwise specified in Section 11.1 above.

b. The creation, incurrence, assumption, or sufferance to exist of any lien, encumbrance, or option
whatsoever upon any of Developer's property or assets, whether now owned or hereafter acquired, the
effect of which substantially impairs Developer's ability to perform or observe any covenant, term,
or condition of this Agreement.

c. Refusal by Developer or Developer's partners, members, or shareholders to enter individually into
the then-current form of Franchise Agreements and Personal Guarantee as provided in Section 1 above.

d. Any change, transfer or conveyance ("Transfer") in the ownership of Developer, which Transfer has
not been approved in advance by Franchisor. Franchisor reserves the right to approve or disapprove
any Transfer as its sole and absolute right.

11.3. If Franchisor is entitled to terminate this Agreement in accordance with Sections 11.1 or 11.2
above, Franchisor shall have the right to undertake the following action instead of terminating this
Agreement:

a. Franchisor may terminate or modify any rights that Developer may have with respect to protected
exclusive rights in the Territory, as granted under Section 1.1 above, effective ten (10) days after
delivery of written notice thereof to Developer.

11.4. If any of such rights are terminated or modified in accordance with this Section 11.3, such
action shall be without prejudice to Franchisor's right to terminate this Agreement in accordance
with Sections 11.1 or 11.2 above, and/or to terminate any other rights, options or arrangements
under this Agreement at any time thereafter for the same default or as a result of any additional
defaults of the terms of this Agreement.

12. Effect of Termination.

12.1. Immediately upon termination or expiration of this Agreement, for any reason, all of
Developer's development rights granted pursuant to this Agreement shall revert to El Pollo Loco. At
the time of termination, only restaurants operating or to be operated under the El Pollo Loco®
System by virtue of a fully executed Franchise Agreement shall be unaffected by the termination of
this Agreement. Franchisor shall have no duty to execute any Franchise Agreement with Developer
after the termination of this Agreement. The foregoing remedies are nonexclusive, and nothing stated
in this Section 12 shall prevent El Pollo Loco's pursuit of any other remedies available to
Franchisor in law or at equity due to the termination of this Agreement.

12.2. Developer understands and agrees that upon the expiration or termination of this Agreement (or
in the event of an exclusive development agreement, the failure of Developer to meet the Development
Schedule and the resulting loss of exclusive development rights), Franchisor or its subsidiaries or
affiliates, as their sole and absolute right, may open and/or operate restaurants in the Territory,
or may authorize or franchise others to do the same, whether it is in competition with or in any
other way affects the sales of Developer at the restaurants.

13. Non-Waiver.

13.1. El Pollo Loco's consent to or approval of any act or conduct of Developer requiring such
consent or approval shall not be deemed to waive or render unnecessary El Pollo Loco's consent to or
approval of any subsequent act or conduct hereunder.

14. Independent Contractor and Indemnification.

Source: EL POLLO LOCO HOLDINGS, INC., 10-K, 3/6/2020
<!-- page 11 -->
14.1. This Agreement does not constitute Developer an agent, legal representative, joint venturer,
partner, employee or servant of Franchisor for any purpose whatsoever, and it is understood between
the parties hereto that Developer shall be an independent contractor and is in no way authorized to
make any contract, agreement, warranty or representation on behalf of El Pollo Loco. The parties
agree that this Agreement does not create a fiduciary relationship between them.

14.2. Under no circumstances shall Franchisor be liable for any act, omission, contract, debt, or
any other obligation of Developer. Developer shall indemnify and save Franchisor harmless against
any such claim and the cost of defending it arising directly or indirectly from or as a result of,
or in connection with, Developer's actions pursuant to this Agreement.

15. Entire Agreement.

15.1. This Agreement, including Exhibits "A", "B" and "C" attached hereto, constitutes the entire
full and complete agreement between Franchisor and Developer concerning the subject matter hereof
and supersedes any and all prior written agreements. No other representations have induced Developer
to execute this Agreement, and there are no representations, inducements, promises, or agreements,
oral or otherwise, between the parties, not embodied herein, which are of any force or effect with
reference to this Agreement or otherwise. Notwithstanding the foregoing, nothing in this Agreement
shall disclaim or require Developer to waive reliance on any representation that Franchisor made in
the most recent disclosure document (including its exhibits and amendments) that Franchisor
delivered to Developer or its representative, subject to any agreed-upon changes to the contract
terms and conditions described in that disclosure document and reflected in this Agreement
(including any riders or addenda signed at the same time as this Agreement). The provisions of this
Agreement may not be contradicted by any other statement concerning the subject matter herein. No
amendment or modification of this Agreement shall be binding on either party unless written and
fully executed.

16. Dispute Resolution

16.1. Initial Meeting and Mediation - Except as otherwise provided in this Agreement, before any
legal action is filed involving any claim or controversy between Franchisor and Developer (including
its affiliates, investors, and Owners) relating to (a) this Agreement, (b) the parties business
activities conducted as a result of this Agreement, or (c) the parties' relationship or business
dealings with each other generally, the following procedure shall be complied with:

a. The party wishing to resolve a dispute shall initiate negotiation proceedings by first requesting
in writing a meeting with the other party or parties. Within forty-five (45) days of receipt of the
initial request for a meeting, the parties shall meet within the county in which Developer is then
located, to discuss and negotiate toward a resolution of the controversy.

b. If negotiation efforts do not succeed, the parties shall engage in mandatory but non-binding
mediation by a mediator jointly chosen by the parties or if the parties cannot agree upon a
mediator, appointed by, and in accordance with the procedures of, JAMS or, if JAMS is no longer in
existence, an organization of similar quality

c. A mediation meeting will be held at a place and at a time mutually agreeable to the parties and
the mediator. The Mediator will determine and control the format and procedural aspects of the
mediation meeting which will be designed to ensure that both the mediator and the parties have an
opportunity to present and hear an oral presentation of each party's views regarding the matter in
controversy. The parties act in good faith to resolve the controversy in mediation.

d. The mediation will be held as soon as practicable after the negotiation meeting is held. The
mediator will be free to meet and communicate separately with each party either before, during or
after the mediation meeting within 60 days of demand by either party.

16.2. At the election of the Franchisor, the provisions of this Section 16 shall not apply to
controversies relating to any fee due the Franchisor by Developer or its affiliates, any promissory
note payments due the Franchisor by Developer, or any trade payables due the Franchisor by Developer
as a result of the purchase of equipment, goods or supplies. The provisions of this Section 16 shall
also not apply to any controversies relating to the use and protection of the El Pollo Loco Marks,
the Manual or the El Pollo Loco System, including without limitation, the Franchisor's right to
apply to any court of competent jurisdiction for appropriate injunctive relief for the infringement
of the El Pollo Loco Marks or the El Pollo Loco System.

Source: EL POLLO LOCO HOLDINGS, INC., 10-K, 3/6/2020
<!-- page 12 -->
17. Severability.

17.1. Each section, part, term and/or provision of this Agreement shall be considered severable, and
if, for any reason, any section, part, term and/or provision herein is determined to be invalid,
contrary to, or in conflict with, any existing or future law or regulation, by any court or agency
having valid jurisdiction, then such shall be deemed not to be a part of this Agreement, but such
shall not impair the operation of, or affect the remaining portions, sections, parts, terms and/or
provisions of this Agreement, which will continue to be given full force and effect and bind the
parties hereto.

18. Applicable Law; Choice of Forum; Waiver of Jury Trial.

18.1. This Agreement, after review by Developer and El Pollo Loco, was accepted in the state in
which Franchisor's then-current headquarters (currently the State of California) is located and
shall be governed by and construed in accordance with the laws of such state, except that the
provisions in Section 20.1 covering competition following the expiration, termination or assignment
of this Agreement shall be governed by the laws of the state in which the breach occurs. THE PARTIES
AGREE THAT ANY ACTION BROUGHT BY EITHER PARTY AGAINST EACH OTHER IN ANY COURT, WHETHER FEDERAL OR
STATE, WILL BE BROUGHT WITHIN THE STATE IN WHICH FRANCHISOR'S HEADQUARTERS (CURRENTLY THE STATE OF
CALIFORNIA) IS THEN LOCATED. THE PARTIES HEREBY WAIVE ANY RIGHT TO DEMAND OR HAVE TRIAL BY JURY IN
ANY ACTION RELATING TO THIS AGREEMENT IN WHICH THE FRANCHISOR IS A PARTY. THE PARTIES CONSENT TO THE
EXERCISE OF PERSONAL JURISDICTION OVER THEM BY SUCH COURTS AND TO THE PROPRIETY OF VENUE OF SUCH
COURTS FOR THE PURPOSE OF CARRYING OUT THE PROVISION, AND THEY WAIVE ANY OBJECTION THAT THEY WOULD
OTHERWISE HAVE TO THE SAME. ANY ACTION BETWEEN DEVELOPER AND FRANCHISOR SHALL INVOLVE ONLY THE
INDIVIDUAL CLAIMS OF DEVELOPER AND SHALL NOT INVOLVE ANY CLASS, GROUP, CONSOLIDATED, REPRESENTATIVE
OR ASSOCIATIONAL ACTION. NOTHING IN THIS SECTION 18.1 IS INTENDED BY THE PARTIES TO SUBJECT THIS
AGREEMENT TO ANY FRANCHISE OR SIMILAR LAW, RULE OR REGULATION TO WHICH THIS AGREEMENT WOULD NOT
OTHERWISE BE SUBJECT.

19. Document Interpretation.

19.1. All terms and words used in this Agreement, regardless of the number and gender in which they
are used, shall be deemed and construed to include the singular or plural tense, and any gender,
whether masculine, feminine or neuter, as the context or sense of this Agreement or any paragraph or
clause may require, the same as if such words had been fully and properly written in the appropriate
number or gender. In the event of a conflict in the language, terms, or conditions between this
Agreement and any Franchise Agreement issued pursuant to this Agreement, the Franchise Agreement
shall control.

20. Covenant Not to Compete.

20.1. To further protect the El Pollo Loco® System while this Agreement is in effect, Developer and
each officer, director, shareholder, member, manager, partner and other equity owner, as applicable,
of Developer, if Developer is an entity, shall neither directly nor indirectly own, operate, control
or any financial interest in any other business which would constitute a "Competitive Business" (as
hereinafter defined) without the prior written consent of Franchisor; provided further, that
Franchisor may, as its sole and absolute right, consent to the Developer's continued operation of
any business already in existence and operating at the time of execution of this Agreement. In
addition, Developer covenants that, except as otherwise approved in writing by the Franchisor,
Developer shall not, for a continuous, uninterrupted period commencing upon the expiration,
termination or assignment of this Agreement, regardless of the cause for termination, and continuing
for two (2) years thereafter, either directly or indirectly, for itself, or through or on behalf of,
or in conjunction with any person, partnership, corporation or other entity, own, operate, control
or have any financial interest in any Competitive Business which is located or has outlets or
restaurant units within the Territory. The foregoing shall not apply to operation of an El Pollo
Loco® restaurant by Developer pursuant to a Franchise Agreement with Franchisor or the ownership by
Developer of less than five percent (5%) of the issued or outstanding stock of any company whose
shares are listed for trading on any public exchange or on the over-the-counter market, provided
that Developer does not control or become involved in the operations of any such company. For
purposes of this Section 20.1, a Competitive Business shall mean a self-service restaurant or
fast-food business which sells chicken and/or Mexican food products, which products individually or
collectively represent more than twenty percent (20%) of the revenues from such self-service
restaurant or fast-food business operated at any one location during any calendar quarter. A
"Competitive Business" shall not include a full-service restaurant.

Source: EL POLLO LOCO HOLDINGS, INC., 10-K, 3/6/2020
<!-- page 13 -->
20.2. In the event that any provision of Section 20.1 above shall be determined by a court of
competent jurisdiction to be invalid or unenforceable, this Agreement shall not be void, but such
provision shall be limited to the extent necessary to make it valid and enforceable.

20.3. Developer understands and acknowledges that Franchisor shall have the right to reduce the
scope of any obligation imposed on Developer by Section 20.1, without Developer's consent, and that
such modified provision shall be effective upon Developer's receipt of written notice thereof.

20.4. Developer acknowledges that violation of the covenants not to compete contained in this
Agreement would result in immediate and irreparable injury to Franchisor for which no adequate
remedy at law will be available. Accordingly, Developer hereby consents to the entry of a
preliminary and permanent injunction prohibiting any conduct by Developer in violation of the terms
of those covenants not to compete set forth in this Agreement. Developer expressly agrees that it
may conclusively be presumed that any violation of the terms of said covenants not to compete was
accomplished by and through Developer's unlawful utilization of Franchisor's Confidential
Information, know-how, methods and procedures

21. Notices.

21.1. For the purpose of this Agreement, all notices shall be in writing and shall be sent to the
party to be charged with receipt thereof either (i) served personally, or (i) sent by certified or
registered United States mail, or (ii) sent by reputable overnight delivery service, or (iv) sent by
facsimile. Notices served personally are effective immediately on delivery, and those served by mail
shall be deemed given forty-eight (48) hours after deposit of such notice in a United States post
office with postage prepaid and duly addressed to the party to whom such notice or communication is
directed. Notices served by overnight delivery shall be deemed to have been given the day after
deposit of such notice with such service. Notices served via facsimile shall be deemed to have been
given the day of faxing such notice. All notices to El Pollo Loco® shall be addressed as follows:

El Pollo Loco, Inc. Attn: Legal Department 3535 Harbor Blvd, Suite 100 Costa Mesa, CA 92626 (714)
599-5503 (fax)

21.2. All notices to Developer shall be faxed and mailed or sent via overnight service to the
Developer's number and address shown on Exhibit "B". Either party may from time to time change its
address for the purposes of this Section by giving written notice of such change to the other party
in the manner provided in this Section. Notwithstanding anything to the contrary contained herein,
the Franchisor may deliver bulletins and updates to the Developer by electronic means, such as by
the internet (e-mail) or an intranet, if any, established by Franchisor.

22. Section Headings.

22.1. The section headings appearing in this Agreement are for reference purposes only and shall not
affect, in any way, the meaning or interpretation of this Agreement.

23. Acknowledgments.

23.1. Developer acknowledges that it has received a complete copy of the El Pollo Loco® Franchise
Disclosure Document, issuance date March 26, 2019 (Control No. 032619) at least fourteen (14)
calendar days prior to the date on which this Agreement was executed by Developer or payment of any
monies to the Franchisor.

23.2. Developer acknowledges that it has read and understands this Agreement, the Franchise
Agreement, the attachments thereto and the agreements relating thereto contained in the Franchise
Disclosure Document received by Developer on _____,20__, and that Franchisor has accorded Developer
ample opportunity and has encouraged Developer to consult with advisors of Developer's own choosing
about the potential benefits and risks of entering into this Agreement.

24. Counterparts.

24.1. This Agreement may be executed in two or more counterparts, each of which shall be deemed an

Source: EL POLLO LOCO HOLDINGS, INC., 10-K, 3/6/2020
<!-- page 14 -->
original but all of which together shall constitute a single instrument. A signature on this
Agreement transmitted via facsimile or electronic mail shall be considered an original for all
purposes hereunder.

IN WITNESS WHEREOF, the parties hereto have duly executed, sealed and delivered this Agreement in
duplicate original as of the dates set forth below.

FRANCHISOR: DEVELOPER: EL POLLO LOCO, INC., a Delaware Corporation ____________________________, an
individual By: By: Name: Name: Title: Title: An individual Date: Date:

25. EXHIBIT "A" TO DEVELOPMENT AGREEMENT - TERRITORY

EXHIBIT "B" TO DEVELOPMENT AGREEMENT - DEVELOPMENT SCHEDULE

DEVELOPER NAME: PRINCIPALS: NOTICE ADDRESS: FAX NUMBER: EMAIL: COMMENCEMENT DATE: EXPIRATION DATE:
DEVELOPMENT FEE (SECTION 3):

DEVELOPMENT SCHEDULE:

INITIAL FRANCHISEE AMOUNT

RESAC SUBMITTAL DATES

SITE COMMITMENT DATES (Date for delivery of signed leases or purchase agreements)

OPENING DATE OF RESTAURANT

Restaurant # 1 $40,000.00 Restaurant # 2 $30,000.00 Restaurant # 3 $30,000.00

EXHIBIT "C" TO DEVELOPMENT AGREEMENT - EXISTING EL POLLO LOCO® RESTAURANTS IN THE TERRITORY

Source: EL POLLO LOCO HOLDINGS, INC., 10-K, 3/6/2020
