<!-- page 1 -->
# Software License Agreement [v.08.05.03]
| Field | Value |
|---|---|
| Document Type | Distributor Agreement |
| SEC Filing Date | 2019-08-22 |
| Parties | Customer; Cisco Systems, Inc. or its subsidiaries licensing the Software instead of Cisco Systems ("Cisco"); Customer |
| Source | CUAD v1 / ScansourceInc_20190822_10-K_EX-10.38_11793958_EX-10.38_Distributor Agreement2 |

Exhibit 10.38

EXHIBIT C

Software License Agreement [v.08.05.03]

PLEASE READ THIS SOFTWARE LICENSE AGREEMENT CAREFULLY BEFORE DOWNLOADING, INSTALLING OR USING CISCO
OR CISCO- SUPPLIED SOFTWARE.

BY DOWNLOADING OR INSTALLING THE SOFTWARE, OR USING THE EQUIPMENT THAT CONTAINS THIS SOFTWARE, YOU
ARE BINDING THE BUSINESS ENTITY THAT YOU REPRESENT ("CUSTOMER") TO THIS AGREEMENT. IF YOU DO NOT
AGREE TO ALL OF THE TERMS OF THIS AGREEMENT, THEN (A) DO NOT DOWNLOAD, INSTALL OR USE THE SOFTWARE,
AND (B) YOU MAY RETURN THE SOFTWARE FOR A FULL REFUND, OR, IF THE SOFTWARE IS SUPPLIED AS PART OF
ANOTHER PRODUCT, YOU MAY RETURN THE ENTIRE PRODUCT FOR A FULL REFUND. YOUR RIGHT TO RETURN AND
REFUND EXPIRES 30 DAYS AFTER PURCHASE FROM CISCO OR AN AUTHORIZED CISCO RESELLER, AND APPLIES ONLY
IF CUSTOMER IS THE ORIGINAL END USER PURCHASER.

The following terms of this Software License Agreement ("Agreement') govern Customer's access and
use of the Software, except to the extent (a) there is a separate signed agreement between Customer
and Cisco governing Customer's use of the Software or (b) the Software includes a separate
"click-accept" license agreement as part of the installation and/or download process. To the extent
of a conflict between the provisions of the foregoing documents, the order of precedence shall be
(1) the signed agreement, (2) the click-accept agreement, and (3) this Software License Agreement.

License. Subject to the terms and conditions of this Agreement, Cisco Systems, Inc. or its
subsidiary licensing the Software instead of Cisco Systems, Inc. ("Cisco"), grants to Customer a
nonexclusive and nontransferable license to use for Customer's internal business purposes the
Software and the Documentation for which Customer has paid the required license fees.
"Documentation" means written information (whether contained in user or technical manuals, training
materials, specifications or otherwise) regarding the Software and made available by Cisco in any
manner (including on CD-Rom, or on-line).

Customer's license to use the Software shall be limited to, and Customer shall not use the Software
in excess of, a single hardware chassis or card or that number of agent(s), concurrent users,
sessions, IP addresses, port(s), seat(s), server(s) or site(s), as set forth in the applicable
Purchase Order which has been accepted by Cisco and for which Customer has paid to Cisco the
required license fee.

Unless otherwise expressly provided in the Documentation, Customer shall use the Software solely as
embedded in, for execution on, or (where the applicable documentation permits installation on
non-Cisco equipment) for communication with Cisco equipment owned or leased by Customer. NOTE: For
evaluation or beta copies for which Cisco does not charge a license fee, the above requirement to
pay license fees does not apply.

General Limitations. Except as otherwise expressly provided under this Agreement, Customer shall
have no right, and Customer specifically agrees not to:

(i) transfer, assign or sublicense its license rights to any other person or entity, or use the
Software on unauthorized or secondhand Cisco equipment, and Customer acknowledges that any attempted
transfer, assignment, sublicense or use shall be void;

(ii) make error corrections to or otherwise modify or adapt the Software or create derivative works
based upon the Software, or permit third parties to do the same;

(iii) decompile, decrypt, reverse engineer, disassemble or otherwise reduce the Software to human-
readable form; or

(iv) use or permit the Software to be used to perform services for third parties without the express
written authorization of Cisco.

To the extent required by law, and at Customer's written request, Cisco shall provide Customer with
the interface information needed to achieve interoperability between the Software and another
independently created program, on payment of Cisco's

Source: SCANSOURCE, INC., 10-K, 8/22/2019
<!-- page 2 -->
Exhibit 10.38

applicable fee, if any. Customer shall observe strict obligations of confidentiality with respect to
such information.

Software, Upgrades and Additional Copies. For purposes of this Agreement, "Software" shall include
(and the terms and conditions of this Agreement shall apply to) computer programs, including
firmware, as provided to Customer by Cisco or an authorized Cisco reseller, and any upgrades,
updates, bug fixes or modified versions thereto (collectively, "Upgrades") or backup copies of the
Software licensed or provided to Customer by Cisco or an authorized Cisco reseller. NOTWITHSTANDING
ANY OTHER PROVISION OF THIS AGREEMENT: (1) CUSTOMER HAS NO LICENSE OR RIGHT TO USE ANY ADDITIONAL
COPIES OR UPGRADES UNLESS CUSTOMER, AT THE TIME OF ACQUIRING SUCH COPY OR UPGRADE, ALREADY HOLDS A
VALID LICENSE TO THE ORIGINAL SOFTWARE AND HAS PAID THE APPLICABLE FEE FOR THE UPGRADE; (2) USE OF
UPGRADES IS LIMITED TO CISCO EQUIPMENT FOR WHICH CUSTOMER IS THE ORIGINAL END USER PURCHASER OR
LESSEE OR WHO OTHERWISE HOLDS A VALID LICENSE TO USE THE SOFTWARE WHICH IS BEING UPGRADED; AND (3)
THE MAKING AND USE OF ADDITIONAL COPIES IS LIMITED TO NECESSARY BACKUP PURPOSES ONLY.

Proprietary Notices. Customer agrees to maintain and reproduce all copyright and other proprietary
notices on all copies, in any form, of the Software in the same form and manner that such copyright
and other proprietary notices are included on the Software. Except as expressly authorized in this
Agreement, Customer shall not make any copies or duplicates of any Software without the prior
written permission of Cisco.

Protection of Information. Customer agrees that aspects of the Software and associated
Documentation, including the specific design and structure of individual programs, are trade secrets
and/or copyrighted materials of Cisco, its suppliers or licensors. Customer shall not disclose,
provide, or otherwise make available such trade secrets or copyrighted material in any form to any
third party without the prior written consent of Cisco. Customer shall implement reasonable security
measures to protect such trade secrets and copyrighted materials. Title to Software and
Documentation shall remain solely with Cisco, its suppliers or licensors.

Term and Termination. This Agreement and the license granted herein shall remain effective until
terminated. Customer may terminate this Agreement and the license at any time by destroying all
copies of Software including any Documentation. Customer's rights under this Agreement will
terminate immediately without notice from Cisco if Customer fails to comply with any provision of
this Agreement. Upon termination, Customer shall destroy all copies of Software and Documentation in
its possession or control.

Customer Records. Customer grants to Cisco and its independent accountants the right to examine
Customer's books, records and accounts during Customer's normal business hours to verify compliance
with this Agreement. In the event such audit discloses non-compliance with this Agreement, Customer
shall promptly pay to Cisco the appropriate license fees.

Export. Software, including technical data, may be subject to U.S. export control laws, including
the U.S. Export Administration Act and its associated regulations, and may be subject to export or
import regulations in other countries. Customer agrees to comply strictly with all such regulations
and acknowledges that it has the responsibility to obtain licenses to export, re-export, or import
Software.

Government End User Purchasers. The Software and Documentation qualify as "commercial items," as
that term is defined at 48 C.F.R. 2.101, consisting of "commercial computer software" and
"commercial computer software documentation" as such terms are used in 48 C.F.R. 12.212. Consistent
with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through 227.7202-4, Customer will provide to
Government end user, or, if this Agreement is direct Government end user will acquire, the Software
and software documentation with only those rights set forth herein that apply to non- governmental
customers. Use of this Software and Documentation constitutes agreement by the Government entity
that the computer software and Documentation is commercial, and constitutes acceptance of the rights
and restrictions herein.

Limited Warranty Cisco warrants that commencing from the date of shipment to Customer (but in case
of resale by an authorized Cisco reseller, commencing not more than ninety (90) days after original
shipment by Cisco), and continuing for a period of the longer of (a) ninety (90) days or (b) the
software warranty period (if any) set forth in the warranty card accompanying the Product (if any):
(a) the media on which the Software is furnished will be free of defects in materials and
workmanship under normal use; and (b) the Software substantially conforms to its published
specifications. The date of shipment of a Product by Cisco is set forth on the packaging material in
which the Product is shipped. Except for the foregoing, the Software is provided AS IS. This limited
warranty extends only to the Customer who is the original licensee. Customer's sole and exclusive
remedy and the entire liability of Cisco and its suppliers and licensors under this limited warranty
will be, at Cisco's option, repair, replacement,

Source: SCANSOURCE, INC., 10-K, 8/22/2019
<!-- page 3 -->
Exhibit 10.38

or refund of the Software if reported (or, upon request, returned) to Cisco or the party supplying
the Software to Customer, if different than Cisco. In no event does Cisco warrant that the Software
is error free or that Customer will be able to operate the Software without problems or
interruptions. In addition, due to the continual development of new techniques for intruding upon
and attacking networks, Cisco does not warrant that the Software or any equipment, system or network
on which the Software is used will be free of vulnerability to intrusion or attack.

Restrictions. This warranty does not apply if the Software, Product or any other equipment upon
which the Software is authorized to be used (a) has been altered, except by Cisco, (b) has not been
installed, operated, repaired, or maintained in accordance with instructions supplied by Cisco, (c)
has been subjected to abnormal physical or electrical stress, misuse, negligence, or accident; or
(d) is licensed, for beta, evaluation, testing or demonstration purposes for which Cisco does not
charge a purchase price or license fee.

DISCLAIMER OF WARRANTY. EXCEPT AS SPECIFIED IN THIS WARRANTY, ALL EXPRESS OR IMPLIED CONDITIONS,
REPRESENTATIONS, AND WARRANTIES INCLUDING, WITHOUT LIMITATION, ANY IMPLIED WARRANTY OR CONDITION OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, NONINFRINGEMENT, SATISFACTORY QUALITY OR ARISING
FROM A COURSE OF DEALING, LAW, USAGE, OR TRADE PRACTICE, ARE HEREBY EXCLUDED TO THE EXTENT ALLOWED
BY APPLICABLE LAW AND ARE EXPRESSLY DISCLAIMED BY CISCO, ITS SUPPLIERS AND LICENSORS. TO THE EXTENT
AN IMPLIED WARRANTY CANNOT BE EXCLUDED, SUCH WARRANTY IS LIMITED IN DURATION TO THE WARRANTY PERIOD.
BECAUSE SOME STATES OR JURISDICTIONS DO NOT ALLOW LIMITATIONS ON HOW LONG AN IMPLIED WARRANTY LASTS,
THE ABOVE LIMITATION MAY NOT APPLY. THIS WARRANTY GIVES CUSTOMER SPECIFIC LEGAL RIGHTS, AND CUSTOMER
MAY ALSO HAVE OTHER RIGHTS WHICH VARY FROM JURISDICTION TO JURISDICTION. This disclaimer and
exclusion shall apply even if the express warranty set forth above fails of its essential purpose.

General Terms Applicable to the Limited Warranty Statement and Software License

Disclaimer of Liabilities. IN NO EVENT WILL CISCO OR ITS SUPPLIERS BE LIABLE FOR ANY LOST REVENUE,
PROFIT, OR LOST OR DAMAGED DATA, OR FOR SPECIAL, INDIRECT, CONSEQUENTIAL, INCIDENTAL, OR PUNITIVE
DAMAGES HOWEVER CAUSED AND REGARDLESS OF THE THEORY OF LIABILITY OR WHETHER ARISING OUT OF THE USE
OF OR INABILITY TO USE SOFTWARE OR OTHERWISE AND EVEN IF CISCO OR ITS SUPPLIERS OR LICENSORS HAVE
BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES. In no event shall Cisco's or its suppliers' or
licensors' liability to Customer, whether in contract, tort (including negligence), or otherwise,
exceed the price paid by Customer for the Software that gave rise to the claim or if the Software is
part of another Product, the price paid for such other Product. The foregoing limitations shall
apply even if the above​ stated warranty fails of its essential purpose. BECAUSE SOME STATES OR
JURISDICTIONS DO NOT ALLOW LIMITATION OR EXCLUSION OF CONSEQUENTIAL OR INCIDENTAL DAMAGES, THE ABOVE
LIMITATION MAY NOT APPLY TO YOU.

The Warranty and the Software License shall be governed by and construed in accordance with the laws
of the State of California, without reference to principles of conflict of laws. The United Nations
Convention on the International Sale of Goods shall not apply. If any portion hereof is found to be
void or unenforceable, the remaining provisions of the Agreement shall remain in full force and
effect. Except as expressly provided herein, this Agreement constitutes the entire agreement between
the parties with respect to the license of the Software and supersedes any conflicting or additional
terms contained in any purchase order or elsewhere all of which terms are excluded.

Source: SCANSOURCE, INC., 10-K, 8/22/2019
