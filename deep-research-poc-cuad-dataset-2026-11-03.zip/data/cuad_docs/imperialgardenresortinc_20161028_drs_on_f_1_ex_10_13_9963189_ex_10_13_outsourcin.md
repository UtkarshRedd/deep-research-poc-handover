<!-- page 1 -->
# Outsourcing Contract on Development of Miaoli Royal Resort Hotel
| Field | Value |
|---|---|
| Document Type | Outsourcing Agreement |
| Agreement Date | 2015-10-29 |
| Parties | The HUANG JIA Country CLUB and Recreation Inc. ("Party A"); Chang Chen-Bin Architects Office ("Party B") |
| Source | CUAD v1 / ImperialGardenResortInc_20161028_DRS (on F-1)_EX-10.13_9963189_EX-10.13_Outsourcing Agreement |

Exhibit 10.13 Outsourcing Contract on Development of Miaoli Royal Resort Hotel Planning Unit: Chang
Chen-Bin Architects Office October 29, 2015

Source: IMPERIAL GARDEN & RESORT, INC., DRS (on F-1), 10/28/2016
<!-- page 2 -->
Outsourcing Contract on Development of Miaoli Royal Resort Hotel The Covenanter: The HUANG JIA
Country CLUB and Recreation Inc. (hereinafter referred to as Party A) and the Covenanter: Chang
Chen- Bin Architects Office (hereinafter referred to as Party B) hereby agree to establish the
following terms and conditions with regard to the development of Miaoli Royal Resort Hotel: Article
I. Outsourced Project Development of Miaoli Royal Resort Hotel Article II. Project Range The base of
the project is located on Lot No. 19 and so on in the Section of Laotianliao, Touwu Township, Miaoli
County (refer to the attached map for more details) with an area about 29 hectares. Article III.
Outsourced Work Outsourced work regarding this Contract is stated below: Part I: Establishment of
Architectural Development Plan and Business Plan I. Establishment of documents and drawing relevant
to the Architectural Development Plan and Business Plan II. Attendance of Concerned Work
Coordination Meeting 1. Attendance of relevant review meetings and presentations 2. Reply to
relevant consultations and revision of the development plan Part II: Development of Soil and Water
Conservation Plan I. Establishment of documents and drawing relevant to the soil and water
conservation plan. 1. Trunk sewer, calculation on water control and treatment and relevant design
drawings. 2. Design of disasters prevention facilities during construction. 3. Design of desilting
and detention basin. 4. Designs and drawings relevant to soil and water conservation. II. Attendance
of Concerned Work Coordination Meeting 1. Attendance of review meetings and presentations 2. Reply
to relevant consultations and revision of scheme drawings associated with soil and water
conservation. III. Signing & Verification of Technicians Signing and verification relevant to land
preparation and water discharge of the project.

Source: IMPERIAL GARDEN & RESORT, INC., DRS (on F-1), 10/28/2016
<!-- page 3 -->
Part III: Environmental Impact Assessment Report I. Program on runoff of Waste Water And Pollution
Reduction on the Construction Site. II. Implementation Plan for Environmental Protection. III.
Environmental Monitoring (Monitoring Report prior to Environmental Impact Assessment) IV.
Establishment of Environmental Impact Statement And Assessment Report Part IV: Establishment of
Documents Relevant to Change of Land Usage (I) Establishment of Documents and Drawings Relevant to
Change of Land Usage. (II). Attendance of Concerned Work Coordination Meeting 1. Attendance of
relevant review meetings and presentations. 2. Reply to relevant consultations and plan revision.
Part V: Establishment of Documents and Drawings Relevant to Landscaping I. Principles, Concepts and
Calculations on Landscaping II. Planting Scheme & Relevant Design Drawings III. Calculations &
Drawings on Green Cover Rate Part VI: Planning, Design and Monitoring on Miscellaneous Works I.
Basic Design. II. Establishment of Documents & Drawings Relevant to Miscellaneous Works 1. Trunk
sewer, calculation on water control and treatment and relevant design drawings 2. Design of
disasters prevention facilities during construction 3. Design of desilting and detention basin 4.
Designs and drawings relevant to miscellaneous works III. Attendance of Miscellaneous Works Review
Meetings 1. Attendance of project review meetings and presentations 2. Reply to relevant
consultations and revision of relevant documents and drawings. IV. Signing & Verification of
Technicians and Architects Signing & Verification of Miscellaneous Works Relevant to the Project
(including signing and verification of geological technicians) V. Construction Monitoring VI.
Submitting documents for obtaining miscellaneous license, providing structural design and signing
and verification relevant to the miscellaneous works. Part VII: Planning and Design of Relevant
Buildings and Construction Monitoring I. Planning & Design of Relevant Buildings.

Source: IMPERIAL GARDEN & RESORT, INC., DRS (on F-1), 10/28/2016
<!-- page 4 -->
II. Coordination on geological drilling and survey and arrangement of building structure, sewage
treatment, water and electricity utility, fire protection, telecommunications and electrical and
mechanical systems etc. for various professional technicians pursuant to relevant laws and
regulations. III. Construction Drawings (involving building structure, interior decoration, water
supply and drainage and electricity, telecommunication, monitoring, fire protection and air
conditioning system). IV. Assistance in Works Quantity Counting & Valuation. V. Submitting of
Construction License and Structure, Water, Electricity and Fire Protection Design for Reviewing,
Signing and Verification. VI. Monitoring on Major Construction Parts. VII. Construction Monitoring
(Survey on Major Parts). VIII. Solving Any Disputes & Problems Relevant to the Construction. IX.
Other Items Agreed by the Two Parties Herein. Article IV. Service Fee The fees for services
mentioned in Part I to Part VI are NTD 12 million ((SAY TWELVE MILLION ONLY) in total and the fees
for planning and design of the buildings and construction monitoring shall be calculated based on
the ratio of 3.50% of the legal construction cost hereof. Should Party A require a comprehensive
modification on the development plan of the project outsourced and any subsequent extra cost occur
in Party B; Party A shall bear the corresponding extra service fee. Article V. Payment Method With
regard to the payment method regarding the project herein, Party A shall remit relevant cashes into
the account designated by Party B by stages as per the following conditions: Stage 1: The service
fee of NTD 1.2 million (SAY ONE MILLION AND TWENTY THOUSAND ONLY) shall be paid upon signing of the
Contract herein. Stage 2: The service fee of NTD 1.2 million (SAY ONE MILLION AND TWENTY THOUSAND
ONLY) shall be paid upon completion of the Business Plan and Architectural Development Plan and
Relevant Drawings. Stage 3: The service fee of NTD 1.2 million (SAY ONE MILLION AND TWENTY THOUSAND
ONLY) shall be paid after the soil and water conservation plan and relevant drawings are filed in
the county government. Stage 4: The service fee of NTD 1.2 million (SAY ONE MILLION AND TWENTY
THOUSAND ONLY) shall be paid after the Environmental Impact Assessment Report and relevant drawings
are filed in the county government.

Source: IMPERIAL GARDEN & RESORT, INC., DRS (on F-1), 10/28/2016
<!-- page 5 -->
Stage 5: The service fee of NTD 1 million (SAY ONE MILLION ONLY) shall be paid after the
Environmental Impact Assessment Report is adopted. Stage 6: The service fee of NTD 3 million (SAY
THREE MILLION ONLY) shall be paid after the Development Plan is adopted. Stage 7: The service fee of
NTD 1 million (SAY ONE MILLION ONLY) shall be paid after change of the non-urban land usage is
completed. Stage 8: The service fee that is 3.00% of the legal construction cost shall be paid after
documents and drawings for applying for the construction license of relevant buildings and the
application is submitted to the competent authority. Stage 9: The service fee that is 0.5% of the
legal construction cost shall be paid upon submitting the construction starting application to the
competent authority. Stage 10: The final service fee shall be paid in a lump sum upon the completion
of the structure of relevant buildings and submitting the usage license application to the competent
authority. In case the Contract cannot be performed due to any reason other than the architect
herein, the client agrees the fees paid will not be refunded. In case the Contract cannot be
performed due to the architect herein, the architect shall refund the fees paid in full without
taking any interest to the client. Article VI. Exclusions The service fee shall not include the fees
for land measurement and boundary identification, geological drilling, meeting relevant land
administration regulations, air pollution prevention, meeting relevant construction regulations,
security system monitoring, scrivener service, deposit of soil and water conservation, review of the
competent authority, attendance of concerned experts and scholars and meeting relevant
administrative regulations. Article VII. Term Planned Party B shall make the most economical and
effective arrangement for Party A with respect to the project based on the principle of alignment
with the plan progress of Party A. The term planned is stated as following: I. Topographic survey
and measurement, geological drilling and program evaluation (about 1.0 months); II. Establishment of
architectural development plan and business plan (about 2.0 months); III. Development of soil and
water conservation plan (about 2.0 months); IV. Establishment of environmental impact assessment
report (about 8.0 months); V. Review of development plan (containing soil and water conservation
plan and environmental impact assessment report) (about 4 - 6 months);

Source: IMPERIAL GARDEN & RESORT, INC., DRS (on F-1), 10/28/2016
<!-- page 6 -->
VI. Miscellaneous works review (about 2 - 4 months); VII. Change of usage zoning and category of the
land (about 2 - 4 months); VIII. Application for miscellaneous license (about 1.0 month) IX.
Application for construction license (including review on green construction materials and
barrier-free facilities) (about 1.0 month) Article VIII. Duties of Party A Party A shall provide the
following data during the term mentioned above: I. Data of rights relevant to the land. II. Data
required by Party B and can be provided by Party A. (I) Basic data that must be provided in
accordance with relevant regulations: 1. Name and business address of the developer; 2. Full name,
address and ID card number of the person in charge; 3. Purpose and content of the development.
Article IX. Duties of Party B I. Party B shall follow all instructions of Party A and ensure all
plans and designs of the project to meet relevant construction laws and regulations. II. Party B
shall take on a professional attitude for various services mentioned in Article III of the Contract,
maintain benefits and interests of Party A all the time and adopt the most economical option under
the precondition of safety and reliability. III. Party B is obligatory to report the latest progress
and completed content to Party A. Article X. Special Terms I. With regard to the payment of all fees
for professional services, the person appointed shall designate relevant professional institutions
and pay the fees directly to them and the service fees due will be deducted after the payment
foregoing is made. II. Any other items not specified in the Contract may be negotiated and
formulated by the both Parties herein separately.

Source: IMPERIAL GARDEN & RESORT, INC., DRS (on F-1), 10/28/2016
<!-- page 7 -->
Article XI. Disputes Resolving Both parties herein agree to resolve any dispute regarding
interpretation of the Contract in the following methods: I. Should both Parties be unable to reach
an agreement within one month through negotiation, they may apply for an arbitration in Miaoli
County and the arbitration result shall be compulsory. II. Should either Party herein initiate a
legal proceeding for revoking any arbitration result regarding the Contract, both Parties herein
agree to take the Miaoli District Court of Taiwan as the competent court of first instance pursuant
to the laws of the R.O.C.. Article XII. The Contract shall be made in duplicate and Party A and
Party B shall hold a copy respectively in witness thereof. Covenanters Party A: The HUANG JIA
Country CLUB and Recreation Inc. Address: Floor 4, No. 106, Zhouzi Street, Neihu District, Taipei
City Tel: 02-26582502 Party B:Chang Chen-Bin Architects Office Unified No: 95822673 Address: No. 1,
Floor 10, No. 575, Jinhwa Road, Bei District, Taichung City Tel: 04-22373588 Fax: 04-22373388
October 29, 2015

Source: IMPERIAL GARDEN & RESORT, INC., DRS (on F-1), 10/28/2016
