Turn {turn}. Tool calls so far: {calls_used}/{max_calls} (minimum {min_calls}). Evidence saved: {n_evidence}.
{phase_hint}
Issue up to {width} INDEPENDENT tool calls in this turn (they run in parallel). Do not repeat a call
you already made. {deadline_hint}
