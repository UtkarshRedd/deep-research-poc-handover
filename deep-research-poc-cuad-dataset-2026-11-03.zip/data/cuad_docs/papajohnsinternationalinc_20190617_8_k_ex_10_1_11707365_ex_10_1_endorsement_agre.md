<!-- page 1 -->
# ENDORSEMENT AGREEMENT
| Field | Value |
|---|---|
| Document Type | Endorsement Agreement |
| Agreement Date | 2019-03-15 |
| Parties | ABG-Shaq, LLC ("ABG"); Papa John's Marketing Fund, Inc ("PJMF"); Papa John's International, Inc ("PJI")(PJMF and PJI individually and collectively, "PAPA JOHN'S") |
| Source | CUAD v1 / PapaJohnsInternationalInc_20190617_8-K_EX-10.1_11707365_EX-10.1_Endorsement Agreement |

Exhibit 10.1

ENDORSEMENT AGREEMENT

THIS ENDORSEMENT AGREEMENT ("Agreement") is made and entered into effective March 15, 2019 (the
"Effective Date") by and among, on the one hand, ABG-Shaq, LLC, a Delaware limited liability company
("ABG") for the personal services of Shaquille O'Neal, ("CELEBRITY"), and, on the other hand, Papa
John's Marketing Fund, Inc., a Kentucky corporation ("PJMF"), and Papa John's International, Inc.
("PJI") (PJMF and PJI are, individually and collectively, "PAPA JOHN'S"). ABG and PAPA JOHN'S may
hereinafter be referred to individually as a "Party" or collectively as the "Parties".

WITNESSETH:

WHEREAS, CELEBRITY is recognized and known for his skills as an athlete, sports analyst, and
celebrity personality;

WHEREAS, ABG, as successor in interest to CELEBRITY, is the exclusive rights holder throughout the
world of certain rights to CELEBRITY'S name, image, and services, and has the authority to exploit
such rights;

WHEREAS, PJMF is a corporation that pays for the national marketing of PJI and is licensed to use
and sublicense its intellectual property;

WHEREAS, PAPA JOHN'S desires to acquire the right to use the Celebrity Endorsement (as defined
below) in connection with the advertisement, promotion and sale of PAPA JOHN'S Products (defined
below) and ABG agrees to grant such rights to PAPA JOHN'S and provide the services of CELEBRITY, all
subject to the terms and conditions of this Agreement;

NOW, THEREFORE, in consideration of the mutual covenants contained herein and other good and
valuable consideration, the receipt and sufficiency of which are hereby acknowledged, the parties
hereto agree as follows:

1. Definitions. As used herein, the terms set forth below shall be defined as follows:

A. "Celebrity Endorsement" shall mean the right to use, subject to the provisions hereof,
CELEBRITY's name (including variations and derivations of the same), nickname, initials, autograph,
voice, video or film portrayals, facsimile signature, photograph, trade name, likeness and image or
facsimile image, or means of endorsement (not including video) (individually and collectively, the
"Personality Rights"), in each case, solely as Approved (as hereinafter defined) by ABG, in
connection with the advertising, promotion and sale of Products.

B. "Contract Year" shall refer to the period commencing on the Effective Date and ending the day
before the one year anniversary of the Effective Date, and each successive twelve (12) month period
thereafter during the term of this Agreement.

1

Source: PAPA JOHNS INTERNATIONAL INC, 8-K, 6/17/2019
<!-- page 2 -->
C. "Competitive Products" shall mean pizza intended primarily for carry-out or home delivery and
prepared on the premises of a pizza carry-out/delivery restaurant, including but not limited to,
pizza "take and bake" outlets, dine-in restaurants in which pizza is the principal food offering,
and/or frozen pizza sold in grocery or mass merchandiser stores for in-home preparation.

D. "Products" shall mean PAPA JOHN'S-branded pizza, bread sides, and, subject to ABG's Approval in
each instance, piadinas and desserts (excluding pastries, doughnuts, coffee and coffee-based
products, energy drinks, 'hydration' frozen ice bars, 'energy' frozen ice bars, and 'recovery'
frozen ice bars), in each case produced and sold by PAPA JOHN'S.

E. "Territory" shall mean Worldwide.

2. Term. Unless earlier terminated in accordance with the provisions hereof, the initial term of
this Agreement ("Term") is the Effective Date through March 15, 2022. The Agreement may be extended
for one (1) year upon the parties' mutual agreement in writing, it being specifically understood the
services to be performed by CELEBRITY (on behalf of ABG) and remuneration to ABG in connection with
the same shall be negotiated in good faith.

3. Grant of Endorsement.

A. In consideration of the remuneration to be paid to ABG pursuant hereto and subject to the
conditions and limitations contained herein, ABG grants to PAPA JOHN'S the non-transferrable,
non-assignable, non-sublicensable, indivisible right and license solely during the Term of the
Agreement and within the Territory to use the Celebrity Endorsement, in each instance, subject to
ABG's Approval (as hereinafter defined). It is understood that PAPA JOHN'S shall not use the
Celebrity Endorsement for any other purpose or in connection with any other items unless
specifically permitted herein. Subject to the terms contained herein, PAPA JOHN'S and ABG agree and
acknowledge that during the Term of this Agreement and for one (1) year thereafter, ABG shall be
prohibited from granting any rights for CELEBRITY identical or similar to the rights granted to PAPA
JOHN'S hereunder to any entity other than PAPA JOHN'S for the purpose of directly promoting,
advertising, making an appearance on behalf of, or endorsing Competitive Products; provided,
however, that in the event this Agreement is terminated pursuant to Section 7.B. of this Agreement,
the prohibition referenced above shall be for a period of six (6) months, except that the
prohibition shall referenced above shall not apply (or shall immediately cease to apply, as
applicable) in the event of any one or more of the following: (i) the Agreement is terminated due to
PAPA JOHN'S failure to pay to ABG any monies under this Agreement, as set forth herein, (ii) the
Agreement is terminated due to PAPA JOHN'S failure to grant, issue, or cause to vest any of the RSUs
(as hereinafter defined) under this Agreement, as set forth herein, (iii) PAPA JOHN'S failure to pay
to ABG any monies under Section 7.D.a. or Section 7.D.b. of this Agreement, as set forth herein, or
(iv) PAPA JOHN'S failure to grant, issue, or cause to vest any of the RSUs under Section 7.E.a. or
Section 7.E.b. of this Agreement, as set forth herein.

2

Source: PAPA JOHNS INTERNATIONAL INC, 8-K, 6/17/2019
<!-- page 3 -->
B. The parties acknowledge and agree that all materials produced by or on behalf of PAPA JOHN'S in
connection with this Agreement and all elements thereof, including all advertising and promotional
materials, trademarks, phrases, words, writing, dialogue, adlibs, music, titles or characters
therein, but in all cases specifically excluding the Celebrity Endorsement and the Personality
Rights (the "Materials"), shall be and remain the absolute and exclusive property of PAPA JOHN'S.
Neither CELEBRITY nor ABG has any right, title, or interest, and agrees that neither will claim any,
in or to the Materials. Except as otherwise provided herein, all the results of ABG's provision of
CELEBRITY'S Services hereunder, including, but not limited to, Materials (but in all cases
specifically excluding the Celebrity Endorsement and the Personality Rights), will be deemed a "work
made for hire" under the provisions of the United States Copyright Act (17 U.S.C. Sec. 101) and will
be owned by PAPA JOHN'S for all purposes. If any Materials created under this Agreement are not
legally capable of being a work-made-for-hire under the applicable copyright laws, then all right,
title, and interest in such Materials is hereby assigned to Papa John's and CELEBRITY or ABG will
execute any documents consistent herewith necessary to perfect such assignment.

C. The Parties acknowledge that PAPA JOHN'S has no right, title or interest, and PAPA JOHN'S hereby
agrees that PAPA JOHN'S will not claim any, in or to the Celebrity Endorsement, the Personality
Rights, or any of CELEBRITY'S or ABG's other intellectual property rights. PAPA JOHN'S hereby
acknowledges that PAPA JOHN'S exercise of the Celebrity Endorsement (including, without limitation,
all uses of the Personality Rights) and all goodwill that is attached or may become attached to the
foregoing shall inure solely to the benefit of ABG.

D. Approval Standard. For purposes of this Agreement, "Approval" (and all grammatical variations
thereof, e.g., Approve, Approved, etc.) shall be defined as ABG's prior written approval, which may
be given or withheld in ABG's sole discretion. ABG has the right to Approve all uses of the
Celebrity Endorsement and the Personality Rights, whether by PAPA JOHN'S or any of its approved
designees (including, without limitation, the use of the Personality Rights in connection with any
and all Products and Materials. PAPA JOHN'S hereby agrees that: (A) no Materials may be released or
exhibited publicly, in any manner, unless and until ABG has Approved the same, (B) all Materials
must be re-submitted for Approval each time a revision is made incorporating any changes, and (C)
ABG'S Approval of Materials hereunder is specifically limited to Approval of the use of the
Personality Rights contained therein, and that to the extent any materials owned by third parties
(e.g., logos, locations, individuals, music, etc.) ("Third-Party Materials") are incorporated
therein, PAPA JOHN'S shall be solely responsible for identifying such Third-Party Materials, and for
obtaining an appropriate license from the owner(s) of such Third-Party Materials to secure all
applicable rights to use and otherwise exploit such Third-Party Materials.

E. Approval Process.

3

Source: PAPA JOHNS INTERNATIONAL INC, 8-K, 6/17/2019
<!-- page 4 -->
1. General. ABG shall respond to each initial request for Approval from PAPA JOHN'S ("First
Request") within three (3) days of ABG's receipt of such request ("Approval Window"); provided,
however that ABG's silence or failure to respond to the First Request prior to the expiration of the
Approval Window shall be deemed ABG's disapproval of the Materials contained in the First Request
for Approval. In the event that ABG is silent with respect to, or fails to reply to, the First
Request prior to the expiration of the Approval Window, then PAPA JOHN'S shall be entitled to submit
a second (2nd) request for Approval of the same Materials included in the First Request ("Second
Request"), with a copy of the Materials and the request to ABG's Legal Department (using the contact
information set forth in Section 12.F. of this Agreement). In the event that ABG is silent with
respect to, or fails to reply to, the Second Request within three (3) days of ABG's receipt thereof,
then ABG's silence with respect to, or failure to respond to, the Second Request shall be deemed
ABG's Approval of the Materials included in the Second Request. PAPA JOHN'S hereby acknowledges that
ABG's Approval of any particular Materials for a specific purpose shall only be deemed an Approval
for said purpose. PAPA JOHN'S shall be required to re-submit any previously Approved Materials to
the extent PAPA JOHN'S wishes to use the same for other purposes. PAPA JOHN'S hereby acknowledges
that, in the event PAPA JOHN'S fails to obtain ABG's consent or approval for any act or omission
requiring such consent or approval (e.g., use of Celebrity Endorsement or Personality Rights, etc.),
the same shall be deemed a non-curable breach of this Agreement entitling, but not requiring, ABG to
immediately terminate this Agreement. In the event that ABG expressly disapproves any Materials that
are submitted by PAPA JOHN'S for ABG's Approval hereunder, ABG shall provide PAPA JOHN'S with a
reason for such disapproval.

2. Advertising & Promotion. PAPA JOHN'S shall create and submit to ABG, via email (as specified by
ABG) the concept (e.g., story boards, mock-ups, etc.) ("Concept") for each of PAPA JOHN'S proposed
advertising, marketing, and promotional efforts utilizing any of the Personality Rights for purposes
of selling Products (each, an "Advertisement"). After Approval of such Concept, and prior to the
public exhibition of any Advertisement, PAPA JOHN'S shall create and submit to ABG, via email (as
specified by ABG), the completed Advertisement intended for public exhibition. After Approval of
such Advertisement, PAPA JOHN'S shall be permitted to publicly exhibit the same, through those
channels (e.g., broadcast television, Internet, radio) Approved by ABG, in each case, subject to the
terms and conditions of this Agreement.

3. Legal Lines. Upon ABG's reasonable request, uses of the Personality Rights shall bear appropriate
copyright, trademark and credit notices, as provided by ABG ("Legal Lines"), either directly on the
Materials using the same, or on stickers or labels affixed thereto, such placement to be mutually
agreed upon by the Parties.

4. PAPA JOHN'S shall not itself or through its agents or representatives or otherwise indirectly,
make, issue, distribute or disseminate any information or statements to the press regarding ABG,
CELEBRITY, Celebrity's Endorsement of PAPA JOHN'S Products and/or matters pertaining to or arising
out of this Agreement (each a "Press Release"). In the event that PAPA JOHN'S desires to issue a
Press Release, PAPA JOHN'S shall submit the same to ABG for Approval. If ABG has not responded in
writing prior to the expiration of an Approval Window, then the submission shall be deemed
disapproved. ABG shall have the right, but not the obligation, to include PAPA JOHN'S, Celebrity's
Endorsement of PAPA JOHN'S Products, and the existence of a partnership between ABG and PAPA JOHN'S
in connection with CELEBRITY in Press Releases, subject to PAPA JOHN'S approval, such approval not
to be unreasonably withheld.

4

Source: PAPA JOHNS INTERNATIONAL INC, 8-K, 6/17/2019
<!-- page 5 -->
5. Brand Restrictions. PAPA JOHN'S shall not, during the Term or at any time thereafter: (I) defame
or disparage CELEBRITY or the Personality Rights (or any portion thereof), nor shall PAPA JOHN'S
place the CELEBRITY or the Personality Rights (or any portion thereof) in a negative light, whether
in connection with this Agreement or otherwise, or (ii) utilize the Personality Rights (or any
portion thereof) in association with, nor shall PAPA JOHN'S associate CELEBRITY with any of the
following: (A) alcohol, drugs (including, without limitation, both prescription and
non-prescription) or other supplements; (B) death; (C) pornography or other "adult only" or sexually
explicit activities; (D) massage parlors, prostitution or any dating or escort activities; (E)
weapons or ammunition; (F) denigration or discrimination against individuals based on race, national
origin, gender, religion, disability, ethnicity, sexual orientation, gender identity or age; (G)
incontinence; (H) weight loss/gain; (I) medical conditions (including, without limitation, hair
loss); or (J) political campaigns or causes.

6. Enforcement of Celebrity Endorsement and Personality Rights. ABG shall have the exclusive right,
at ABG's sole cost and expense (excluding PAPA JOHN'S outside counsel fees and costs) and
exercisable at ABG's sole discretion, to institute in its own name, and to control, with counsel of
its own choosing, all claims, suits and/or actions against third parties relating to the Personality
Rights, and other proprietary rights in and to the same ("Infringement Claim"), and ABG shall be
entitled to receive and retain all amounts awarded, if any, as damages, profits or otherwise, in
connection with such Infringement Claims. PAPA JOHN'S shall assist ABG to ensure that third parties
do not unlawfully infringe on the Personality Rights. PAPA JOHN'S shall promptly notify ABG of any
such infringements of which PAPA JOHN'S becomes aware. PAPA JOHN'S shall not take any action on
account of, or in connection with, any Infringement Claim, other than to notify ABG of the same, and
to cooperate with ABG, pursuant to this Section. PAPA JOHN'S hereby acknowledges that: (i) ABG and
CELEBRITY have no obligation to take any action in connection with any Infringement Claim, and (ii)
ABG and CELEBRITY shall incur no liability by reason of: (A) ABG's or CELEBRITY's failure or refusal
to take any such action against any Infringement Claim, or (B) any settlement relating to any
Infringement Claim to which ABG or CELEBRITY may agree.

7. No Attack. PAPA JOHN'S shall not, during the Term or at any time thereafter, attack or challenge,
or lend assistance to any third party in connection with an attack or challenge, of any right, title
or interest of ABG in and to any Personality Rights (including, without limitation, copyrights,
trademarks and/or patents), whether by way of: (i) an application for and/or an opposition against
any intellectual property rights relating to the Personality Rights, (ii) adoption and/or
application for and/or registration of any intellectual property rights (including, without
limitation, domain names, business names, and social media accounts) that are confusingly similar
to, that dilute, or that infringe, any of the Personality Rights, or (iii) any lawsuit, cancellation
proceeding or action, or otherwise. PAPA JOHN'S shall not represent in any filing, presentation,
document or other statement, whether written or verbal, that PAPA JOHN'S or any third party is the
owner of the Personality Rights, and PAPA JOHN'S shall not use or display any of the foregoing
except as expressly permitted herein.

5

Source: PAPA JOHNS INTERNATIONAL INC, 8-K, 6/17/2019
<!-- page 6 -->
4. Services. To facilitate PAPA JOHN'S usage of the right and license to the Celebrity Endorsement
with respect to the Products as provided herein, during each Contract Year during the Term of the
Agreement, subject to CELEBRITY's prior personal and professional obligations, and further subject
to advance scheduling reasonable acceptable to ABG and CELEBRITY and to confirmation with respect to
scheduling dates, times, and locations, and subject to Section 5(C) below, ABG agrees to cause
CELEBRITY to provide the services set forth below ("Services"). ABG shall require CELEBRITY to
provide the Services in a professional manner, subject to the terms and conditions of this
Agreement.

A. At least eight (8) "Service Days", including but not limited to:

1. Production days. Up to four (4) production days (defined as a maximum of eight (8) consecutive
hours each), with PAPA JOHN'S creative agency.

2. Personal appearances. CELEBRITY shall appear at least (each of the following not to exceed six
(6) consecutive hours):

(A) One (1) day engaging with franchisees and team members at company-wide event(s);

(B) One (1) day visiting Papa John's Pizza stores, date and locations to be mutually agreed upon by
the Parties; and

(C) One (1) day at a community event, date and location to be mutually agreed upon by the Parties.

PAPA JOHN'S and ABG shall both use commercially reasonable efforts to schedule the dates, times and
locations for Service Days so as to meet the reasonable needs of PAPA JOHN'S while not unreasonably
conflicting with CELEBRITY's previously scheduled other commitments. PAPA JOHN'S understands that if
Service Days are requested hereunder, then such Service Days may be coordinated with similar
services for others entitled to the use of CELEBRITY's personal services (e.g., if Service Days
include traveling to Las Vegas, Nevada, CELEBRITY and/or ABG may coordinate such Service Days to be
performed during a previously scheduled trip to Las Vegas, Nevada). PAPA JOHN'S shall provide local
hair, make-up and/or wardrobe stylists for CELEBRITY in connection with all Service Days hereunder,
provided each such stylist, and all wardrobe selections, shall be pre- approved by CELEBRITY in his
sole, absolute discretion. The timing allocated in Section 4(A) above for all Service Days shall be
exclusive of travel time, but inclusive of time spent for makeup, wardrobe, and reasonable breaks.

6

Source: PAPA JOHNS INTERNATIONAL INC, 8-K, 6/17/2019
<!-- page 7 -->
B. Social media posts. ABG shall require CELEBRITY to post on each of CELEBRITY's Instagram (the
page located at www.instagram.com/shaq and Personality's Instagram account (@shaq)), Twitter (the
page located at www.twitter.com/shaq and Celebrity's Twitter account (@shaq)), and Facebook (the
page located at www.facebook.com/shaq) at least one post (1) per month promoting Papa John's
Products. Each post shall be created by PAPA JOHN'S, but subject to ABG's Approval in each instance.
PAPA JOHN'S shall provide ABG and CELEBRITY with all suitable and necessary language, compliant with
all Federal Trade Commission ("FTC") standards and requirements to include in each post (each a or
the, "Required Disclosure") which shall clearly and conspicuously disclose to the public that ABG
and/or CELEBRITY has been paid by PAPA JOHN'S in connection with such posts. Notwithstanding
anything to the contrary contained in this Agreement, PAPA JOHN'S shall be solely responsible for
ensuring that any and all Required Disclosures comply with all applicable laws, rules, regulations,
and guidelines, including, without limitation, the FTC's "Guides Concerning the Use of Endorsements
and Testimonials in Advertising" and PAPA JOHN'S shall indemnify, defend, and hold harmless the ABG
Indemnified Parties (as hereinafter defined) from any and all liability arising out of the same,
unless ABG or CELEBRITY materially modifies the Required Disclosure provided by PAPA JOHN'S (i.e. if
the Required Disclosure provided by PAPA JOHN'S complied with all applicable laws, rules,
regulations, and guidelines, and ABG or CELEBRITY's modification of the Required Disclosure causes
such Required Disclosure to not comply all applicable laws, rules, regulations, and guidelines).

C. Public Relations.

1. Affiliation announcement. For the announcement of the Affiliation between Papa John's and
CELEBRITY, ABG shall require CELEBRITY to provide business and consumer PR interviews, including the
following, all of which shall be subject to ABG's Approval:

(A) Two (2) broadcast television and three (3) print or online media interviews in New York City;

(B) Two (2) approved photos for release (one at a Papa John's Pizza restaurant; one making pizza
with CEO Steve Ritchie);

7

Source: PAPA JOHNS INTERNATIONAL INC, 8-K, 6/17/2019
<!-- page 8 -->
(C) One (1) social media post;

(D) Quote for Press Release;

(E) Business headshot; and

(F) Business bio.

2. During each Contract Year during the Term, ABG shall cause CELEBRITY to make himself available
for sixty (60) total minutes of interview time promoting Papa John's, subject to CELEBRITY's prior
personal and professional obligations, and further subject to advance scheduling reasonable
acceptable to ABG and CELEBRITY. Upon PAPA JOHN'S reasonable request, (i) interviews may be broken
up into smaller increments (e.g., five or ten minutes each), and (ii) ABG will cause CELEBRITY to
participate in media and message training before each interview, in each case, subject to
CELEBRITY's prior personal and professional obligations, and further subject to advance scheduling
reasonable acceptable to ABG and CELEBRITY.

D. New Co-Branded Products. ABG will permit CELEBRITY and PAPA JOHN'S to collaborate in good faith
to develop one (1) or more co-branded Products using the Personality Rights. Any such co-branded
Products shall be subject to the separate mutual written agreement of the Parties.

E. Notwithstanding anything to the contrary contained in this Agreement, the Parties specifically
agree that the Personality Rights shall not be used, in whole or in part, in connection with any
Tie-In Programs (as hereinafter defined) without ABG's Approval in each instance. Except as
specifically provided herein, PAPA JOHN'S hereby acknowledges and agrees that, both during the Term
and at any and all times thereafter, PAPA JOHN'S has no right to, and PAPA JOHN'S shall not, affix
or attach any of the Personality Rights, in any manner, to any of PAPA JOHN'S products or services
(including, without limitation, Products) (e.g., either directly on any products or on any packaging
therefor, etc.). For purposes of this Agreement, "Tie-In Program" shall be defined as any program or
plan developed around a particular product or property and designed primarily to generate additional
income related to such product or property (e.g., traffic builders, cross-promotions, third party
programs involving the use of a premium or a third party's product and/or service), including,
without limitation: (i) any program primarily designed to attract the consumer to purchase a product
or service other than or in addition to the Products; and/or (ii) any cross-promotion with a third
party and/or its products or services.

F. Condition Precedent. PAPA JOHN'S expressly acknowledges that the obligations of ABG to require
CELEBRITY to perform the Services specified hereunder are subject to the condition that all payments
to ABG are current and up-to-date.

8

Source: PAPA JOHNS INTERNATIONAL INC, 8-K, 6/17/2019
<!-- page 9 -->
G. Pay or Play. In the event that PAPA JOHN'S fails to utilize any or all of the Services as and
when the same are allocated and/or scheduled pursuant to the above (e.g., within a particular
Contract Year), then: (A) the same shall not result in a reduction in any amounts due and/or payable
to ABG hereunder, and (B) PAPA JOHN'S shall be deemed to have waived its right to utilize those
particular Services (e.g., Service Days that are allocated for a particular Contract Year may not be
carried into future Contract Years, or beyond the expiration or early termination of the Term)
without ABG's Approval.

H. No Dangerous Activity. The Parties acknowledge and agree that CELEBRITY shall not be required to
participate in any physical activity during CELEBRITY's performance of any Services hereunder that
may be of a dangerous nature or which may involve a risk of serious bodily injury to CELEBRITY
and/or others, as determined by ABG and CELEBRITY in their collective sole and absolute discretion.

I. Additional Services. Personality's rendition of additional services beyond the scope of the
Services set forth herein shall at all times be subject to the mutual agreement of the Parties
(including, without limitation, the negotiation of appropriate remuneration in connection
therewith). PAPA JOHN'S acknowledges and agrees that (i) it is contemplated that PAPA JOHN'S and
CELEBRITY will enter into one or more 'Franchise Agreement' pursuant to which, among other things,
CELEBRITY (and/or CELEBRITY'S designee) will acquire a thirty percent (30%) ownership in nine (9)
Atlanta-area Papa John's Pizza restaurants, and (ii) PAPA JOHN'S shall not, directly or indirectly,
request, cause, or require CELEBRITY, under or in connection with any such 'Franchise Agreement' or
otherwise (except as expressly set forth in this Agreement), (a) to provide to PAPA JOHN'S
(including its designees) any services that are the same as or similar to the Services hereunder, or
(b) to grant to PAPA JOHN'S (including its designees) any right or license to use any of the
Personality Rights. PAPA JOHN'S further acknowledges that ABG, as successor in interest to
CELEBRITY, is the sole and exclusive owner of a worldwide portfolio of Personality Rights, as well
as other copyrights, trademarks and other intellectual property rights related to CELEBRITY, and the
rights of publicity, and other rights in and to the name, image, likeness, persona, personality,
voice, signature, and other indicia of, and rights of association and endorsement related to,
CELEBRITY including, without limitation, pursuant to Section 43(a) of the United States Lanham Act
(collectively, the "Shaq Rights"). PAPA JOHN'S further acknowledges and agrees that: (a) any and all
use of the Shaq Rights and/or any intellectual property rights related to CELEBRITY (e.g.
exploitation of a copyrighted photograph of CELEBRITY), whether in connection with the Products or
otherwise, requires the consent and authorization of ABG in each instance, (b) ABG is the only
person or entity that can authorize the use of Shaq Rights on or in connection with any products or
services throughout the world, and (C) should PAPA JOHN's or any third party desire to manufacture,
advertise, sell, offer or otherwise exploit any products or services related to CELEBRITY, any and
all such acts would be a use of the Shaq Rights and would therefore require the prior written
consent of ABG in each instance.

9

Source: PAPA JOHNS INTERNATIONAL INC, 8-K, 6/17/2019
<!-- page 10 -->
J. Reverse License. PAPA JOHN'S hereby grants to ABG and CELEBRITY, a royalty-free, perpetual,
irrevocable, fully- paid, assignable, transferable, sublicensable right and license to utilize the
Materials, in their entirety or any portions thereof, in all media now known or hereafter developed,
throughout the universe (individually and collectively, "PJ Rights") as follows: (i) on or in
connection the performance of the Services hereunder; (ii) in connection with historical and
archival purposes (e.g., documentary, commentary, corporate retrospective, historical files on
websites of ABG), so-called business-to-business uses and other non-commercial purposes; and (iii)
for industry recognition purposes (e.g., award competition submissions); in each case, in all media
now known or hereafter devised. For external or public uses in subsection (ii) and for all instances
in subsection (iii), such license is subject to PAPA JOHN'S prior written approval, such approval
not to be unreasonably withheld.

5. Consideration. In consideration of the rights granted herein and the Services to be provided
hereunder, PAPA JOHN'S will pay to ABG in each Contract Year of the Term, the following:

A. Cash Payment.

1. PAPA JOHN'S shall pay ABG a cash payment of: One Million Two Hundred Fifty Thousand U.S. Dollars
(USD$1,250,000) for Contract Year 1, One Million Three Hundred Seventy Five Thousand U.S. Dollars
(USD$1,375,000) for Contract Year 2, and One Million Five Hundred Thousand U.S. Dollars
(USD$1,500,000) for Contract Year 3 (such cash payments for Contract Years 1-3 referred to herein as
the "Cash Payment") for the services and rights provided hereunder. In addition to the Cash Payment
and any other compensation payable to ABG (and, as applicable, CELEBRITY) hereunder, PAPA JOHN'S
shall pay without limitation, usage of the union-covered materials produced hereunder, with usage
applied against the Cash Payment at double scale (or such other applicable rate). Each of such Cash
Payments shall be paid in four equal installments, as set forth in Section 5.A.3 below, as follows:

(A) The first payment is due on the Effective Date for the First Contract Year, and March 1 for
subsequent Contract Years;

(B) The second payment is due June 1 for each Contract Year;

(C) The third payment is due September 1 for each Contract Year; and

(D) The fourth payment is due December 1 for each Contract Year.

10

Source: PAPA JOHNS INTERNATIONAL INC, 8-K, 6/17/2019
<!-- page 11 -->
2. Wire Instructions. PAPA JOHN'S shall be solely responsible for any costs and/or fees associated
with making any and all payments to ABG as required under this Agreement, including, without
limitation, wire transfer fees. PAPA JOHN'S shall pay all sums due to ABG by wire transfer to the
following account, unless otherwise instructed by ABG:

Payee: ABG-Shaq, LLC Bank of America One Bryant Park New York, NY 10036 Account Number: 483043584155
ABA Routing Number (for domestic transfers): Wire: 026009593 / ACH: 021000322 Swift Code (for
international transfers): BOFAUS3N

3. No Deductions. PAPA JOHN'S may not deduct from, setoff or offset the Cash Payments or any other
amount payable to ABG for any reason. For purposes of illustration but without limitation, PAPA
JOHN'S may not deduct: Union Fees, Other Fees, uncollectible accounts, wire transfer fees, bank fees
or any other fees associated with making any and all payments to ABG, slotting fees, advertising or
other expenses of any kind, the costs incurred in the operation of the Business, or the conversion
of any currency into United States Dollars.

4. Allocation. ABG may, in ABG's sole discretion, allocate and apply payments it receives from PAPA
JOHN'S hereunder. Partial payment by PAPA JOHN'S to ABG of any amounts due hereunder shall not, in
any circumstance, avoid default by PAPA JOHN'S as to the full amount of any such payments, and PAPA
JOHN'S shall not be entitled to any return of the amount of any partial payments in the event of any
expiration or termination of this Agreement.

5. Taxes & Fees. All sales, use, value added, withholding, local privilege, excise taxes, tariffs,
duties or other charges of any kind, character or description which may be levied or imposed upon
any of the Products, PAPA JOHN'S business operation relating to the Products, or on any aspect of
performance of this Agreement, shall be PAPA JOHN'S responsibility. ABG shall only be responsible
for the actual taxes on ABG's net income resulting from this Agreement.

6. Union Fees; Other Fees. PAPA JOHN'S hereby acknowledges that CELEBRITY is a member of SAG-AFTRA.
In addition to and separate from the Cash Payment and any other compensation payable to ABG (and, as
applicable, CELEBRITY) hereunder, for purposes of this Agreement, forty percent (40%) of the Cash
Payment shall be allocated to union-covered services. If PAPA JOHN'S engages any performance or
service of CELEBRITY hereunder in any way that is subject to the jurisdiction of any applicable
union, guild or other organization of which CELEBRITY is a member (including, without limitation,
SAG-AFTRA), either during or after the Term, then PAPA JOHN'S shall pay, as required by such union,
guild or other organization, all minimum (and other, as applicable) payments or fees (or for
SAG-AFTRA, minimum pension and welfare contributions) required to be made with respect to PAPA
JOHN'S use of the Services hereunder ("Union Fee(s)"). PAPA JOHN'S shall be solely responsible for
all Union Fee(s) and any costs and/or fees associated with making any and all payments to ABG as
required under this Agreement, including, without limitation, wire transfer fees ("Other Fees"). In
no event shall ABG or CELEBRITY be responsible for any Union Fees or Other Fees that may arise out
of this Agreement. Upon PAPA JOHN'S reasonable request, and subject to CELEBRITY's and ABG's prior
consultation with counsel of their own choosing, ABG shall work together in good faith with
CELEBRITY and PAPA JOHN'S to have CELEBRITY sign a Screen Actors Guild contract for each session for
tracking purposes.

11

Source: PAPA JOHNS INTERNATIONAL INC, 8-K, 6/17/2019
<!-- page 12 -->
7. Development. All costs and expenses of PAPA JOHN'S business (including, without limitation, the
design, development, preparation, cooking, packaging, distribution, delivery, advertisement,
marketing, promotion, offering for sale, sale, or other exploitation of the Products, and other
costs and expenses related to the Materials and all Advertisements, including, without limitation,
to the expense of compliance with the Approval requirements set forth herein) shall be borne by PAPA
JOHN'S.

8. Sub-Contractors. In the event PAPA JOHN'S wishes to sub-contract any or all of the operation of
the Products or its related business hereunder (e.g., design of the Products, advertising of the
Products, creation of Products, etc.) to any third party (e.g., ad agencies, photographers,
videographers, producers, crew, etc.) (each, a "Sub-Contractor"), the same may only be done if and
after ABG has given its Approval therefor. If requested by ABG, PAPA JOHN'S shall provide ABG with
additional information about any proposed Sub- Contractor, such that ABG will have sufficient
information to evaluate PAPA JOHN'S request for Approval of such Sub-Contractor. In the event ABG
Approves any given Sub-Contractor, then such Sub-Contractor shall be permitted to carry out only
that portion of the business for which ABG Approved such Sub-Contractor. PAPA JOHN'S shall use PAPA
JOHN'S best efforts to ensure that all Sub-Contractors abide by the terms of this Agreement. All
acts of all Sub-Contractors shall be deemed to be the acts of PAPA JOHN'S for all purposes of this
Agreement.

B. Award of PJI Restricted Stock Units. On the Effective Date or as soon as practicable thereafter
(such date, the "Grant Date"), PJI will grant to CELEBRITY (as agent of ABG solely for purposes of
receiving the RSUs and authorizing and irrevocably instructing PJI's transfer agent to deliver the
shares of common stock issued upon vesting of the RSUs at each applicable Vesting Date to ABG)
87,136 restricted stock units of PJI (the "RSUs"). The RSUs will be granted pursuant to the PJI 2018
Omnibus Incentive Plan (the "Plan") and will be subject in all respects to the terms of the Plan and
an applicable Restricted Stock Unit Agreement set forth in Exhibit A, which is attached hereto and
incorporated by reference herein (the "Restricted Stock Unit Agreement"). Except as set forth in
this Agreement or the Restricted Stock Unit Agreement, the RSUs will vest as to 31% [27,012] of the
RSUs on the first anniversary of the Grant Date, as to 33% [28,755] of the RSUs on the second
anniversary of the Effective Date, and as to 36% [31,369] of the RSUs on the third anniversary of
the Effective Date (each of such dates, a "Vesting Date"). In the event of a Corporate Transaction,
as defined in the Plan, the RSUs shall be treated in accordance with the terms of the Plan.

12

Source: PAPA JOHNS INTERNATIONAL INC, 8-K, 6/17/2019
<!-- page 13 -->
C. Expenses. In connection with all personal appearances and personal services (including, by way of
example, all Service Days) to be performed by CELEBRITY pursuant to this Agreement, PAPA JOHN'S
shall provide the following for CELEBRITY and two (2) travel companions: (i) corporate private jet,
or other private air travel option; (ii) five-star hotel (suite level or higher for CELEBRITY), with
separate rooms for travel companions; and (iii) private, high-end ground transportation to and from
airports and appearance locations.

6. Warranties and Additional Covenants.

A. ABG represents and warrants to PAPA JOHN'S that (i) neither ABG nor CELEBRITY is a party to any
oral or written agreement or understanding, which grants to any other entity or person a right or
license to use the Celebrity Endorsement in connection with the advertisement, promotion or
endorsement of any Competitive Products or would prevent, limit or hinder the performance of any of
its obligations under this Agreement; (ii) the execution and delivery of this Agreement by ABG
and/or ABG's performance of its obligations under this Agreement will not cause a violation or
breach of any other Agreement to which ABG or CELEBRITY is party to; (iii) all endorsements of the
Products by CELEBRITY that are Approved and actually used by PAPA JOHN'S in accordance with the
terms and conditions of this Agreement reflect the honest opinions, findings, beliefs, or
experiences of the CELEBRITY; and (iv) ABG has the full ability and right to enter into this
Agreement and to perform, and cause CELEBRITY to perform, all of the obligations in this Agreement,
as evidenced by the Inducement Letter set forth on Exhibit B, which is attached hereto and
incorporated by reference herein.

B. PAPA JOHN'S represents and warrants to ABG and CELEBRITY that (i) PAPA JOHN'S is not a party to
any oral or written agreement or understanding that would prevent, limit or hinder the performance
of any of its obligations under this Agreement; (ii) the execution and delivery of this Agreement by
PAPA JOHN'S and/or PAPA JOHN'S performance of its obligations under this Agreement will not cause a
violation or breach of any other Agreement to which PAPA JOHN'S is party to; (iii) PAPA JOHN'S has
the full ability and right to enter into this Agreement and to perform all of the obligations in
this Agreement; (iv) PAPA JOHN'S maintains appropriate policies, procedures, systems, and training,
in each case consistent with prevailing industry standards: (A) for the production, distribution,
and sale of Products, (B) to ensure that Products are safe for human consumption, (C) to ensure
compliance with all applicable food safety regulations, and (D) to provide a level of customer
service at least as favorable as is standard in its industry and that will not have a material
adverse impact on the PAPA JOHN'S brand; (v) no injurious, deleterious or defamatory material,
writing or images shall be used in connection with the Personality Rights, the Materials, or PAPA
JOHN'S business; (vi) PAPA JOHN'S shall not create, incur or permit any encumbrance, lien, security
interest, mortgage, pledge, assignment or other hypothecation upon this Agreement or permit the
commencement of any proceeding or foreclosure action on this Agreement or to obtain any assignment
thereof, whether or not involving any judicial or nonjudicial foreclosure sales; (vii) (A) PAPA
JOHN'S owns all rights in and to the Products and the Materials, including by way of example and not
limitation, any and all trademarks and service marks used for or in connection therewith (e.g.,
'PAPA JOHN'S'), and (B) none of the design, development, preparation, cooking, packaging,
distribution, delivery, advertisement, marketing, promotion, offering for sale, sale, or other
exploitation of the Products or the Materials shall infringe any intellectual property right or
otherwise violate any right of any third party; and (viii) PAPA JOHN'S has not and will not, during
the Term or at any time after expiration of the Term, create any expenses chargeable to ABG or
CELEBRITY without Approval.

13

Source: PAPA JOHNS INTERNATIONAL INC, 8-K, 6/17/2019
<!-- page 14 -->
C. Each party acknowledges and agrees that (i) all copyrights and trademarks used in connection
herewith that are owned by a party shall be and remain the sole and complete property of such party;
(ii) the other party shall not at any time acquire or claim any right, title or interest of any
nature whatsoever in any such copyright or trademark by virtue of this Agreement; (iii) the other
party shall not contest or assist others to contest the validity of all such copyrights and
trademarks; and (iv) it will not incur or create any expenses chargeable to the other party.

D. Each Party represents and warrants to the other that it will comply with all rules, regulations,
laws, orders, decrees, and ordinances of each and every country or political subdivision thereof,
having legal jurisdiction over any aspect of their respective activities under this Agreement
including specifically, but not limited to, the use of the Celebrity Endorsement in Materials for
and on behalf of PAPA JOHN'S, and the design, development, preparation, cooking, packaging,
labeling, distribution, delivery, advertisement, marketing, promotion, offering for sale, sale, or
other exploitation of the Products by and on behalf of PAPA JOHN'S.

E. ABG agrees to execute (and require CELEBRITY to execute) such other documents as reasonably
requested by PAPA JOHN'S as are necessary to effectuate the intent of this Agreement, including the
grant of RSUs hereunder.

F. Notwithstanding anything to the contrary contained in this Agreement, PAPA JOHN'S acknowledges
and agrees that ABG and/or CELEBRITY are party(ies) to one or more agreement(s) with one or more
third party(ies) for, among other things, the use of Celebrity's Endorsement and the Personality
Rights during the Term (or portions thereof) for and in connection with (i) the following food and
beverage products typically consumed for breakfast: bagels, breakfast sandwiches (i.e., sandwiches
filled primarily with food products that are typically consumer at breakfast such as scrambled eggs
and sausage patties), pastries, doughnuts, coffee, espresso and cappuccino, (ii) fast-casual dining,
chain restaurants (i.e., business(es) which prepare(s) and serve(s) food and beverages to customers
in exchange for money) with menus primarily focused on chicken dishes, (iii) high-end dining
restaurant(s) (i.e., business(es) which prepare(s) and serve(s) food and beverages to customers in
exchange for money) with menus primarily focused on Americanized dishes similar to those customarily
found at steakhouses (which may include pizzas/flatbreads, bread sides, desserts, etc. as part of
their menu), and (iv) 'hydration' frozen ice bars, 'energy' frozen ice bars, and 'recovery' frozen
ice bars, and energy drinks (individually and collectively, the "Existing Agreements"); and that
ABG's and CELEBRITY's performance under the Existing Agreements shall not be deemed a breach of this
Agreement by ABG or CELEBRITY.

14

Source: PAPA JOHNS INTERNATIONAL INC, 8-K, 6/17/2019
<!-- page 15 -->
7. Termination.

A. Termination by PAPA JOHN'S. Without prejudice to any other rights it may have in law, equity or
otherwise, PAPA JOHN'S shall have the right to terminate this Agreement upon written notice to ABG,
as determined by PAPA JOHN'S in its sole discretion, exercising good-faith business judgment, in the
event that any of the following occur during the Term of this Agreement (1) CELEBRITY's conviction
or plea of guilty to a crime of moral turpitude; (2) CELEBRITY's or ABG's public malignment or
disparagement of PAPA JOHN'S; (3) CELEBRITY or ABG intentionally makes any voluntary statement or
commits any voluntary act that is or becomes generally known to the public which such statement or
act both (a) has the effect of egregiously disparaging or insulting any group of the community on
the basis of ethnicity, religion, race, national origin, gender, or sexual orientation, and (b) is
the direct cause of a material adverse impact on PAPA JOHN'S actual sales of pizza; (4) (a)
CELEBRITY's death or permanent incapacitation, or (b) CELEBRITY'S inability to perform the Services
of this Agreement except due to a Force Majeure Event; or (5) CELEBRITY's or ABG's breach of any
material term of this Agreement, which breach CELEBRITY or ABG fails to cure within thirty (30) days
(or to the extent not possible to cure within such period, commence to cure) after CELEBRITY's or
ABG's receipt of PAPA JOHN'S written notice of such breach. Specifically, if this Agreement is
terminated for any of the reasons provided in Section 7.A.(1)-(3), PAPA JOHN'S right to terminate
this Agreement shall be PAPA JOHN'S sole remedy for the same.

B. Termination by ABG. Without prejudice to any other rights it may have in law, equity or
otherwise, ABG shall have the right to terminate this Agreement upon written notice to PAPA JOHN'S,
as determined by ABG in its sole discretion, exercising good-faith business judgment, in the event
that (1) during the Term of this Agreement, any member of PJI's executive team or any member of the
Board of Directors of PJI (a) is convicted of or pleads guilty to a crime of moral turpitude, (b)
disparages or publicly maligns CELEBRITY or ABG; (2) PAPA JOHN'S breaches any material term of this
Agreement, which breach PAPA JOHN'S fails to cure within thirty (30) days after PAPA JOHN'S receipt
of ABG's written notice of such breach, it being understood such period shall be five (5) business
days with respect to the payment of any monies, or (c) any member of PJI's executive team or any
member of the Board of Directors of PJI or any authorized spokesperson of PAPA JOHN'S intentionally
makes any voluntary statement or commits any voluntary act that is or becomes generally known to the
public which such statement or act has the effect of egregiously disparaging or insulting any group
of the community on the basis of ethnicity, religion, race, national origin, gender, or sexual
orientation.

15

Source: PAPA JOHNS INTERNATIONAL INC, 8-K, 6/17/2019
<!-- page 16 -->
C. Effect of Termination - Use Beyond Term. Upon expiration or termination of this Agreement by PAPA
JOHN'S (but not in the event of termination by ABG), and subject to PAPA JOHN'S ongoing compliance
with the terms and conditions of this Agreement, PAPA JOHN'S shall have the following rights to use
the Celebrity Endorsement solely as follows: (i) for a period of six (6) months following the
effective date of expiration or termination, PAPA JOHN'S shall have the right to continue to use,
display and distribute copies of Materials which bear the Celebrity Endorsement and which were
printed and published, or irrevocably booked for publication or display with a third party, prior to
the effective date of expiration or termination; and (ii) PAPA JOHN'S shall have the right, without
restriction, to the in-house, non-commercial use of any Materials. Such use may include in-house
exhibition for historical, educational or commemorative purposes. Provided that PAPA JOHN'S has
exerted its best efforts to cease use of the Celebrity Endorsement and/or Personality Rights as
provided above, any incidental use of the Celebrity Endorsement and/or Personality Rights that may
occur or be discovered for the three (3) month period following such period shall not be deemed a
breach of this Agreement; provided, however, that in any event, all use of the Celebrity Endorsement
and/or Personality Rights must cease by no later than nine (9) months following the effective date
of expiration or termination of this Agreement.

D. Effect of Termination - Cash Consideration.

a. Termination by PAPA JOHN'S. If this Agreement is terminated by PAPA JOHN'S for any of the reasons
provided in Section 7.A. above, then ABG shall be entitled to the pro-rata share of the respective
Cash Payment for the then-current Contract Year as set forth in Section 5.A. above, determined by
multiplying the Cash Payment for such Contract Year by a fraction, the numerator of which is the
number of days elapsed in such Contract Year and the denominator of which is the total number of
days in such Contract Year, and such amounts shall be immediately due as of the effective date of
termination and paid to ABG.

b. Termination by ABG. If this Agreement is terminated by ABG for any of the reasons provided in
Section 7.B. above, then any and all unpaid amounts under this Agreement for the eighteen (18)
months following the effective date of termination (including, without limitation, any balance due
of the Cash Payment as of the effective date of termination, in addition to any and all of the Cash
Payments that would have become payable during the next eighteen (18) months but for the
termination) shall be immediately due as of the effective date of termination and paid to ABG;
provided, however, that in the event there is less than eighteen (18) months remaining in the Term
as of the effective date of such termination, then any and all unpaid amounts under this Agreement
for the balance of the Term (including, without limitation, any balance due of the Cash Payment as
of the effective date of termination, in addition to any and all Cash Payments that would have
become payable but for the termination) shall be immediately due as of the effective date of
termination and paid to ABG.

16

Source: PAPA JOHNS INTERNATIONAL INC, 8-K, 6/17/2019
<!-- page 17 -->
E. Effect of Termination - Awards of RSUs. Notwithstanding anything to the contrary contained in
this Agreement or the Restricted Stock Unit Agreement:

a. Termination by PAPA JOHN'S. If this Agreement is terminated by PAPA JOHN'S for any of the reasons
set forth in Section 7.A. above, then CELEBRITY shall be entitled to immediately vest in the
pro-rata share of the respective number of RSUs for the then-current Contract Year as set forth in
Section 5.B. above, determined by multiplying the number of RSUs for such Contract Year by a
fraction, the numerator of which is the number of days elapsed in such Contract Year and the
denominator of which is the total number of days in such Contract Year, and such RSUs shall vest
immediately as of the effective date of termination.

b. Termination by ABG. If this Agreement is terminated by ABG for any of the reasons provided in
Section 7.B. above, then CELEBRITY shall be entitled to immediately vest in all of the RSUs for the
eighteen (18) months following the effective date of termination (including, without limitation, any
balance of unvested RSUs that were due to vest as of the effective date of termination, in addition
to any and all of the RSUs that would have vested during the next eighteen (18) months but for the
termination); provided, however, that in the event there is less than eighteen (18) months remaining
in the Term as of the effective date of such termination, then any and all of the balance of the
RSUs shall vest immediately as of the effective date of termination.

8. Indemnification and Insurance.

A. ABG's Indemnification Obligations. ABG shall indemnify, defend and hold harmless PAPA JOHN'S and
its current and future parents, subsidiaries, affiliated companies and each of their respective
current and future officers, directors, shareholders, employees, agents, attorneys, and each of
their respective successors and assigns (individually and collectively, "PAPA JOHN'S Indemnified
Party(ies)") from and against any and all third-party claims, liabilities, demands, causes of
action, judgments, settlements, costs and expenses (including, without limitation, reasonable
outside attorneys' fees and court costs) (collectively, "Claims") arising out of or in connection
with any one (1) or more of the following: (i) the breach by ABG of any of its express
representations, express warranties, or express covenants in this Agreement; or (ii) the failure by
ABG or CELEBRITY to perform any of its obligations under this Agreement. ABG shall not be liable to
PAPA JOHN'S or any third party under this Section 8.A. to the extent that PAPA JOHN'S is required to
indemnify ABG pursuant to Section 8.B. below.

B. PAPA JOHN'S Indemnification Obligations. PAPA JOHN'S shall indemnify, defend and hold harmless
CELEBRITY, ABG and its current and future parents, subsidiaries, affiliated companies and each of
their respective current and future officers, directors, shareholders, employees, agents, attorneys,
and each of their respective successors and assigns (individually and collectively, "ABG Indemnified
Party(ies)") from and against any and all direct and third-party Claims, arising out of or in
connection with any one (1) or more of the following: (i) the breach by PAPA JOHN'S of any of its
express or implied representations, warranties or covenants in this Agreement; (ii) the failure by
PAPA JOHN'S to perform any of its obligations under this Agreement; (iii) the design, development,
preparation, cooking, packaging, distribution, delivery, advertisement, marketing, promotion,
offering for sale, sale, or other exploitation of the Products, the Materials, or any Advertisements
(including, without limitation, any product liability, false advertising and/or infringement
Claims); and (iv) any acts, whether by omission or commission, by PAPA JOHN'S (including any of its
franchisees, vendors, and store operators), which may arise out of, in connection with, or is any
way related to any of the Products, the Materials, PAPA JOHN'S business and/or this Agreement. PAPA
JOHN'S shall not be liable to ABG or any third party under this Section 8.B. to the extent that ABG
is required to indemnify PAPA JOHN'S pursuant to Section 8.A. above. PAPA JOHN'S hereby agrees that
ABG's Approval shall not waive, diminish or negate any of PAPA JOHN'S indemnification obligations to
the ABG Indemnified Parties hereunder.

17

Source: PAPA JOHNS INTERNATIONAL INC, 8-K, 6/17/2019
<!-- page 18 -->
C. Indemnification Process. The Party to be indemnified hereunder (the "Indemnitee") must give the
indemnifying Party hereunder (the "Indemnitor") prompt written notice of any Claim, and the
Indemnitor, in its sole discretion, may then take such action as it deems advisable to defend such
Claim on behalf of the Indemnitee. In the event that appropriate action is not taken by the
Indemnitor within thirty (30) days after the Indemnitor's receipt of written notice from the
Indemnitee, the Indemnitee shall have the right to defend such Claim with counsel reasonably
acceptable to the Indemnitor, and no settlement of any such Claim may be made without the prior
written approval of the Indemnitor, which approval shall not be unreasonably withheld, conditioned
or delayed. Even if appropriate action is taken by the Indemnitor, the Indemnitee may, at its own
cost and expense, be represented by its own counsel in such Claim. In any event, the Indemnitee and
the Indemnitor shall keep each other fully advised of all developments and shall cooperate fully
with each other in all respects with respect to any such Claim.

D. Insurance. PAPA JOHN'S shall procure and maintain, at its sole cost and expense, and use
commercially reasonable efforts cause its Sub-Contractors to obtain, at their sole cost and expense,
during the Term and for a period of three (3) years thereafter ("Insurance Period"), comprehensive
general liability insurance (including, without limitation, product liability insurance, inventory
insurance, worker's compensation insurance, and advertising injury insurance), to defend and protect
the Parties against claims arising out of or in connection with PAPA JOHN's business, the Materials,
the Products, and Advertisements therefor. Insurance must be obtained from a company reasonably
acceptable to ABG, in an amount not less than Five Million United States Dollars ($5,000,000 USD) in
the aggregate, or PAPA JOHN'S standard insurance policy limits, whichever is greater.

E. Within five (5) business days of the date on which this Agreement is fully executed, PAPA JOHN'S
shall submit to ABG a certificate of insurance naming each of ABG, CELEBRITY and Authentic Brands
Group, LLC as additional insureds ("COI"), which COI, or a renewal or replacement thereof, shall
remain in force at all times during the Insurance Period, and shall require the insurer to provide
at least thirty (30) days' prior written notice to PAPA JOHN'S, and all additional insureds, of any
termination, cancellation or modification thereof.

18

Source: PAPA JOHNS INTERNATIONAL INC, 8-K, 6/17/2019
<!-- page 19 -->
F. In the event that any insurance policy required hereunder includes or permits a waiver of
subrogation, such waiver shall apply to ABG and CELEBRITY. In the event that any insurance policy
required hereunder provides for a waiver of subrogation in the event that such waiver is required by
a third-party agreement, then this Agreement shall be deemed to require such waiver. PAPA JOHN'S
shall notify ABG of all claims regarding the Personality Rights, Materials and/or Products under any
of the foregoing policies of insurance promptly upon the filing thereof. PAPA JOHN'S indemnification
obligations hereunder shall not be limited by the amount of insurance requirements hereunder. ABG
shall be entitled to its proportionate share of the insurance proceeds received by PAPA JOHN'S in
respect to the Celebrity Endorsement and/or the Personality Rights, and PAPA JOHN'S shall report and
pay to ABG any such insurance proceeds at the same time as the next quarterly installment of the
Cash Payment is due.

G. LIMITATION OF LIABILITY. TO THE MAXIMUM EXTENT PERMISSIBLE UNDER APPLICABLE LAW, NEITHER ABG NOR
AUTHENTIC BRANDS GROUP LLC NOR CELEBRITY SHALL BE LIABLE TO PAPA JOHN'S FOR ANY CONSEQUENTIAL,
INCIDENTAL, PUNITIVE, EXEMPLARY, OR SPECIAL DAMAGES, REGARDLESS OF THE FORM OR ACTION, WHETHER IN
CONTRACT OR IN TORT, EVEN IF ABG OR AUTHENTIC BRANDS GROUP LLC HAS BEEN ADVISED OF THE POSSIBLITY OF
SUCH DAMAGES OR LOSSES. IN NO EVENT SHALL ABG'S, AUTHENTIC BRANDS GROUP LLC'S, AND CELEBRITY'S TOTAL
LIABILITY UNDER THIS AGREEMENT EXCEED THE AMOUNTS ACTUALLY RECEIVED BY ABG (EXCLUSIVE OF
REIUMBURSEMENT OF EXPENSES) HEREUNDER, REGARDLESS OF THE NUMBER OR TYPE OF CLAIMS.

9. Arbitration. In the event a dispute arises under this Agreement which cannot be resolved, such
dispute shall be submitted to arbitration and resolved by a single arbitrator (who shall be a
lawyer) in accordance with the Commercial Arbitration Rules of the American Arbitration Association
then in effect. All such arbitration shall take place at the office of the American Arbitration
Association located in or nearest to New York, New York. Each Party is entitled to depose at least
two (2) fact witnesses and any expert witness designated by the other Party, and to conduct such
other discovery as the arbitrator deems appropriate. The award or decision rendered by the
arbitrator shall be final, binding and conclusive and judgment may be entered upon such award by any
court.

10. Confidentiality and Non-Disparagement. Each Party shall hold all confidential information
received pursuant to this Agreement, including the terms and conditions of this Agreement and
CELEBRITY'S personal and/or business affairs, confidential and may only disclose them (i) with the
prior written consent of the other Party, (ii) where required by law or (iii) to such party's
advisors, attorneys or other designees, as long as such recipients also keep such information
confidential. Nevertheless, after the parties have announced the association between CELEBRITY and
PAPA JOHN's or the association otherwise becomes public, each party may respond, discuss and comment
in a favorable and positive manner that CELEBRITY is associated with PAPA JOHN'S during any public
events and/or interviews, subject to the requirements herein. All Parties agree not to disparage or
make derogatory comments, verbal or written, regarding the other Party during the Term of the
Agreement, and for one year thereafter.

19

Source: PAPA JOHNS INTERNATIONAL INC, 8-K, 6/17/2019
<!-- page 20 -->
11. Force Majeure. If, at any time during the Term, CELEBRITY and/or ABG are prevented, hampered or
interrupted by, or interfered with in, in any manner whatsoever, fully performing either of their
duties hereunder, by reason of: any present or future statute, law, ordinance, regulation, order,
judgment or decree, whether legislative, executive or judicial (whether or not valid); any act of
God, earthquake, fire, flood, epidemic, accident, explosion or casualty; any lockout, boycott,
strike, labor controversy (including, without limitation, any threat of the foregoing); any riot,
civil disturbance, war or armed conflict (whether or not there has been an official declaration of
war or official statement as to the existence of a state of war), invasion, occupation, intervention
of military forces or act of public enemy; any embargo, delay of a common carrier, inability without
default on CELEBRITY and/or ABG part to obtain sufficient material, labor, transportation, power or
other essential commodity required in the conduct of its business; any cause beyond the reasonable
control of CELEBRITY and/or ABG; or any other cause of any similar nature (each of the foregoing, a
"Force Majeure Event"), then CELEBRITY'S and/or ABG's obligations hereunder shall be suspended as
often as any such Force Majeure Event occurs and during such period(s) of time as such Force Majeure
Event(s) exist and such non-performance by shall not be deemed to be a breach of this Agreement by
CELEBRITY or ABG, or a forfeiture of any of CELEBRITY'S or ABG's rights hereunder.

12. Miscellaneous.

A. Severability. If any term or provision of this Agreement shall be declared illegal, invalid, void
or unenforceable by any judicial or administrative authority, then (i) such provision shall be
eliminated to the minimum extent necessary, and (ii) such provision shall be reformed and rewritten
so as to most closely reflect the intention of ABG and PAPA JOHN'S, such that this Agreement shall
otherwise remain in full force and effect and enforceable.

B. Entire Agreement. This Agreement shall constitute the entire understanding between ABG, CELEBRITY
and PAPA JOHN'S with respect to the subject matter hereof, and cannot be altered or modified except
by an agreement or amendment in writing, signed by all parties.

C. Governing Law. This Agreement shall be governed by and construed in accordance with the laws of
the State of Delaware, without regard to its principles of conflicts of law.

20

Source: PAPA JOHNS INTERNATIONAL INC, 8-K, 6/17/2019
<!-- page 21 -->
D. Waiver. The failure at any time of any party to demand strict performance of another party of any
of the terms, covenants or conditions set forth in this Agreement will not be construed as a
continuing waiver or relinquishment thereof, and any party may, at any time, demand strict and
complete performance of any other party of such terms, covenants, and conditions.

E. No Joint Venture. This Agreement does not constitute and shall not be construed as constituting a
partnership or joint venture between PAPA JOHN'S and ABG or CELEBRITY. Neither party shall have any
right to obligate or bind the other party in any manner whatsoever, and nothing contained herein
shall give, or is intended to give, any rights of any kind to any third person.

F. Notices. All notices, samples, claims, certificates, requests, demands, and other communications
(other than payments) desired or required hereunder will be made in writing and will be deemed to
have been duly given if delivered to the party address by hand, or by other means of express courier
service, addressed as follows:

To PAPA JOHN'S: Papa John's International, Inc. and Papa John's Marketing Fund, Inc. 2002 Papa
John's Boulevard Louisville, Kentucky 40299 With an electronic copy to: Caroline_Oyler@papajohns.com
To ABG: (i) If to ABG for questions about submitting Approval requests:

c/o Authentic Brands Group, LLC 1411 Broadway, 4th Floor New York, NY 10018 Attention: Approvals
Department With electronic copies to: approvals@abg-nyc.com; CSmeeton@abg-nyc.com;
PRogers@abg-nyc.com; and Mbergson@abg-nyc.com Facsimile Number: (212) 760-2419

(ii) If to ABG for any other reason:

c/o Authentic Brands Group, LLC 1411 Broadway, 4th Floor New York, NY 10018 Attention: Legal
Department With an electronic copy to: legaldept@abg-nyc.com Facsimile Number: (212) 760-2419

21

Source: PAPA JOHNS INTERNATIONAL INC, 8-K, 6/17/2019
<!-- page 22 -->
G. Rights Cumulative. Except as expressly set forth herein, all rights and remedies conferred upon
or reserved by the Parties in this Agreement shall be cumulative and concurrent and shall be in
addition to all other rights and remedies available to such Parties at law or in equity or
otherwise, including, without limitation, requests for temporary and/or permanent injunctive relief.
Such rights and remedies are not intended to be exclusive of any other rights or remedies and the
exercise by either Party of any right or remedy herein provided shall be without prejudice to the
exercise of any other right or remedy by such Party provided herein or available at law or in
equity.

H. Equitable Relief. PAPA JOHN'S acknowledges that any breach by PAPA JOHN'S shall cause ABG
irreparable harm for which there is no adequate remedy at law, and in the event of such breach, ABG
shall be entitled to, in addition to other available remedies, injunctive or other equitable relief,
including, without limitation, interim or emergency relief, including, without limitation, a
temporary restraining order or injunction, before any court with applicable jurisdiction, to protect
or enforce its rights.

I. Any sections and any other obligations under the provisions of this Agreement which, by their
term or implication, have a continuing effect, shall survive any expiration or termination of this
Agreement.

J. Counterparts. This Agreement may be executed in multiple counterparts, each of which shall be
deemed an original, but all of which together shall constitute one (1) agreement binding on all
Parties hereto notwithstanding that all of the Parties hereto are not signatories to the same
counterpart. Each of the Parties agrees that an electronic signature evidencing a Party's execution
of this Agreement shall be effective as an original signature and may be used in lieu of the
original for any purpose.

[Signature Page Follows]

22

Source: PAPA JOHNS INTERNATIONAL INC, 8-K, 6/17/2019
<!-- page 23 -->
IN WITNESS WHEREOF, the parties hereto have duly executed this Agreement effective the date first
above written.

Papa John's Marketing Fund, Inc. ABG-Shaq, LLC Date: 6/6/19 Date: June 11, 2019 By: /s/ Steve
Ritchie By: Jay Dubiner Title: President & CEO Title: General Counsel Papa John's International,
Inc. Date: 6/6/19 By: /s/ Steve Ritchie Title: President & CEO

23

Source: PAPA JOHNS INTERNATIONAL INC, 8-K, 6/17/2019
