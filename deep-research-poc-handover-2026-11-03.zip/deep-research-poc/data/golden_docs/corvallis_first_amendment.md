<!-- page 1 -->
# First Amendment to Credit Agreement — Corvallis Foods Group
| Field | Value |
|---|---|
| Document Type | Amendment |
| Effective Date | 2025-11-15 |
| Parties | Corvallis Foods Group LLC; Pacific Commerce Bank |
| Facility ID | FAC-2025-0108 |
| Version | First Amendment |

THIS FIRST AMENDMENT TO CREDIT AGREEMENT (this "Amendment") is entered into as of 2025-11-15 (the "First Amendment Effective Date") among Corvallis Foods Group LLC (the "Borrower"), the Lenders party hereto and Pacific Commerce Bank, as Administrative Agent.

## Recitals
WHEREAS, the Borrower, the Lenders and the Administrative Agent are parties to that certain Credit Agreement dated as of 2025-04-01 (the "Credit Agreement"; facility FAC-2025-0108);
WHEREAS, the Borrower has requested covenant relief in connection with the acquisition of Willamette Valley Produce, Inc.;
NOW, THEREFORE, the parties agree as follows.
<!-- page 2 -->
## Section 1 — Amendments to the Credit Agreement
Effective as of the First Amendment Effective Date, the Credit Agreement is amended as follows:
1.1 Section 7.1 is amended by replacing "3.25 to 1.00" with "3.75 to 1.00", so that the Borrower shall not permit the Leverage Ratio as of the last day of any fiscal quarter to exceed 3.75 to 1.00.
1.2 The definition of "Applicable Margin" in Section 1.1 is amended by replacing "3.25%" with "3.50%", so that the Applicable Margin for Term SOFR Loans is 3.50% per annum.

## Section 2 — Conditions to Effectiveness
This Amendment becomes effective on the date the Administrative Agent receives counterparts hereof executed by the Borrower and the Required Lenders, together with an amendment fee for the account of each consenting Lender equal to 0.125% of such Lender's Commitment.
<!-- page 3 -->
## Section 3 — Representations; Reaffirmation
The Borrower represents that no Default has occurred and is continuing and that the representations in Article V of the Credit Agreement are true and correct in all material respects on the date hereof.
Each Guarantor, by its acknowledgment below, reaffirms its obligations under the Guarantee and the Security Agreement after giving effect to this Amendment.
## Section 4 — Effect; Governing Law
Except as expressly amended hereby, the Credit Agreement and the other Loan Documents remain in full force and effect and are hereby ratified and confirmed. This Amendment is a Loan Document.
This Amendment shall be governed by the laws of the State of California. Notices hereunder shall be given in the manner set forth in Section 10.1 of the Credit Agreement.
Corvallis Foods Group LLC, as Borrower — By: /s/ Authorized Signatory
Pacific Commerce Bank, as Administrative Agent — By: /s/ Authorized Signatory
