<!-- page 1 -->
# SERVICES AND HOSTING AGREEMENT
| Field | Value |
|---|---|
| Document Type | Hosting Agreement |
| Agreement Date | 2018-03-14 |
| Parties | VITALIBIS INC ("Licensee"); VOTOCAST, Inc. ("VOTOCAST") |
| Source | CUAD v1 / VitalibisInc_20180316_8-K_EX-10.2_11100168_EX-10.2_Hosting Agreement |

Exhibit 10.2 SERVICES AND HOSTING AGREEMENT THIS SERVICES AND HOSTING AGREEMENT (this "Agreement")
is entered into by and between VITALIBIS INC a Nevada C having its principal place of business at
5348 Vegas Drive, Las Vegas, NV 89108 (hereinafter, -Licensee"), and VOTOCAST, Inc. a California
corporation (dba, newkleus), having its principal place of business at PO Box 7302 Newport Beach, CA
92658 (hereinafter, "VOTOCAST). VOTOCAST and Licensee may also be referred to individually as a
"Party" and collectively as the "Parties." WHEREAS, VOTOCAST provides certain hosting and technical
services, including iOS and Android Mobile Applications, APIs, SDKs and Admin Module ("Services");
and WHEREAS, Licensee wishes to engage VOTOCAST, and VOTOCAST desires to be engaged by Licensee, to
provide hosting and technical services on the terms and subject to the conditions set forth below.
NOW. THEREFORE, in consideration of the promises, benefits, and covenants set forth herein, the
Parties hereby agree as follows: 1. SERVICES 1.1 Grant of License. Under the terms and conditions of
this Agreement, VOTOCAST hereby grants to Licensee a nonexclusive, nontransferable license, to
access the Services and provide Licensee's users ("Licensee Users") with access to the Services.
Licensee may not transfer the license granted in this Agreement unless such transfer is mutually
agreed upon by the Parties in a writing signed by the Parties. VOTOCAST reserves all rights under
any intellectual property rights in and to the Services not expressly granted in this Agreement. 1.2
Services. VOTOCAST shall provide the Services to Licensee as specifically set forth in Exhibit A,
attached hereto. 1.3 Acceptance Testing. Prior to the payment of the License and Hosting Fees
defined in Exhibit A, Licensee shall have the right to conduct acceptance testing ("Acceptance
Testing") to verify that the Services satisfy the acceptance criteria set forth in Exhibit B
("Acceptance Criteria"). Acceptance Testing shall commence within five (5) business days from the
date on which VOTOCAST notifies Licensee, in writing by U.S. mail or electronic mail that all
implementation work has been completed and is ready for Acceptance Testing by Licensee. In the event
that the Services do not conform to the Acceptance Criteria, Licensee shall give VOTOCAST written
notice thereof. VOTOCAST shall make commercially reasonable efforts to correct any deficiencies that
prevent the Services from conforming to the Acceptance Criteria. When the Services have successfully
conformed to or satisfied the Acceptance Criteria, Licensee shall give VOTOCAST written notice by
U.S. mail or electronic mail of acceptance ("Acceptance"). Acceptance by Licensee shall be
automatically deemed to have occurred: (a) fifteen (15) business days after Licensee's receipt, if
Licensee does not communicate to VOTOCAST any defects in the Services, or (b) if Licensee uses the
Services in the normal and usual operation of Licensee's business prior to written Acceptance.
Licensee shall have the right to terminate this Agreement if, in its sole discretion, the Services
have not conformed to the Acceptance Criteria within thirty (30) days from the date of Acceptance
Testing; provided however, VOTOCAST shall continue to be entitled to receive, and Licensee shall be
obligated to pay to VOTOCAST, any and all amounts owing for Implementation Fees up to the date of
termination. 1.4 Additional Services. VOTOCAST and Licensee agree that any additional services
("Additional Services") to be provided by VOTOCAST to Licensee shall be described in a statement of
work ("SOW'). which shall be executed by authorized representatives of both Parties. The Parties
agree that maintenance and support services as set forth in Sections 2.2 and 2.3, respectively,
shall not constitute Additional Services arid shall not require an SOW. Each SOW will be deemed to
incorporate the terms and conditions of this Agreement unless SOW explicitly states otherwise. Each
SOW shall reference this Agreement, contain a description of the services to be provided and the
associated fees and charges, and such additional terms and conditions as the Parties may desire to
include. The Services and Additional Services shall be collectively referred to herein as the
"Services?' The Agreement and any SOWs shall be collectively referred to herein as the "Agreement."
The form of the SOW is outlined in Exhibit D. 1.5 Modification of the Services. VOTOCAST shall
provide sixty (60) days prior written notice to Licensee of any proposed change or modification by
VOTOCAST to the Services that will materially affect Licensee or Licensee Users' use of, or ability
to use. the Services.

1

Source: VITALIBIS, INC., 8-K, 3/16/2018
<!-- page 2 -->
2. VOTOCAST'S OBLIGATIONS 2.1 Privacy. VOTOCAST shall use commercially reasonable efforts to protect
the privacy of Licensee and Licensee Users and the content that is transmitted through the Services.
VOTOCAST will only access and disclose information as necessary to comply with applicable laws and
government orders or requests, to provide the Services, to operate or maintain its systems or to
protect itself or Licensee Users. In all such instances. VOTOCAST shall provide prior written notice
to Licensee of not less than three (3) business days prior to accessing or disclosing such
information so that Licensee may have an opportunity to dispute or restrict such disclosure.
Licensee acknowledges, however, that Licensee and Licensee Users' content will not pass through nor
be stored in a segregated or separate physical location from which VOTOCAST'S other users content
will be transmitted or stored. 2.2 Maintenance of System. VOTOCAST shall use commercially reasonable
efforts to maintain or cause to be maintained the software and systems required for the operation of
the Services. For avoidance of doubt. maintenance services are limited to Services and not custom
code. 2.3 Support. VOTOCAST will identify a primary point of contact for support escalation, to be
accessible pursuant to the Service Levels set forth in Exhibit C. 2.4 Availability of Services.
Unless otherwise indicated on Exhibit A hereto, the Services will be accessible to Licensee and
Licensee Users via the Wi-Fi, broadband, or cellular services twenty-four (24) hours a day, seven
(7) days a week, except for scheduled maintenance and required repairs, and except for any loss or
interruption of Services due to causes beyond the control of VOTOCAST or which are not reasonably
foreseeable by VOTOCAST, including, but not limited to, interruption or failure of Wi-Fi, cellular,
telecommunication or digital transmission links and Wi-Fi or cellular slow-downs or failures.
VOTOCAST agrees to provide reasonable written notice to Licensee prior to any scheduled maintenance
or required repairs that would cause the Services to be inaccessible. VOTOCAST does not provide
Wi-Fi, broadband or cellular services to Licensee or Licensee Users. 2.5 Credit for Interruption of
Services. In the event of any loss or interruption of Services solely due to VOTOCAST controlled
activities. Licensee's sole and exclusive remedy and VOTOCAST'S sole and exclusive liability for any
loss or interruption of Services shall be as follows. For loss or interruption of Services which is
not due to scheduled maintenance, and is caused by VOTOCAST, and such loss or interruption of
Services exceeds a continual period of one (I) hour per Exhibit C, Licensee shall receive a credit
against future Services equal to one-thirtieth (1/30) of the monthly fees for the Services for each
cumulative hour, up to a maximum total of the fees charged for Services for the applicable month of
the affected Services. 2.6 Response Time. VOTOCAST shall have qualified personnel respond to
outages, emergencies and requests for support from Licensee within the time frames set forth in the
Service Levels set forth in Exhibit C. 3. LICENSEE'S OBLIGATIONS 3.1 Requirements. Licensee hereby
agrees that it will offer, access, and make the Services available to Licensee Users pursuant to a
terms of use agreement ("Terms of Use") adapted to local laws and languages no less protective of
VOTOCAST'S rights, in all material respects, than the terms of this Agreement. Licensee agrees to
obtain acceptance by provable electronic means from each Licensee User of the Terms of Use prior to
such Licensee User's initial use of the Services. 3.2 Suspension or Termination. If VOTOCAST becomes
aware of, or suspects any violation of, Licensee's Terms of Use by any Licensee User, VOTOCAST shall
immediately notify Licensee and provide reasonable detail of such violation. The Parties shall use
commercially reasonable efforts to promptly resolve the violation or suspected violation. If the
matter cannot be promptly resolved, however, VOTOCAST reserves the right to suspend or terminate the
provision of Services to the violating Licensee User as reasonably necessary to protect VOTOCAST'S
interests. 3.3 Representations. Licensee shall not make any representations or warranties concerning
the Services beyond those expressly made in writing by VOTOCAST, and shall not misrepresent the
Services or the performance or functionality thereof. 3.4 Licensee Mobile Apps, APIs, SDKs. Licensee
will provide to VOTOCAST the information, such as the domain name and URL for the Websites, that
will be used for the Services and any other information of Licensee or a Licensee User necessary for
VOTOCAST to perform the set- up and other initial services before Licensee or such Licensee User
will have access to the Services.

2

Source: VITALIBIS, INC., 8-K, 3/16/2018
<!-- page 3 -->
3.5 Provision of Mobile Apps, APIs, SDKs. Licensee shall provide VOTOCAST with all logos, text,
images. and other data of Licensee to be used to produce and support Licensee's Mobile Apps
("Licensee Content'). Licensee warrants and represents to VOTOCAST that Licensee has full power and
authority to provide to VOTOCAST and to authorize VOTOCAST'S use of, the Licensee Content provided
by Licensee for developing the Mobile Apps, and agrees to defend and indemnify VOTOCAST with respect
to any claims arising from VOTOCAST'S or Licensee's use of such Licensee Content 3.6 Removal of
Licensee Content. VOTOCAST shall not exclude or remove from the Mobile Apps or databases any
Licensee Content or other content not supplied by VOTOCAST without the written consent of Licensee.
Licensee is solely responsible for monitoring and exerting editorial control over the Mobile Apps,
APIs, SDKs and databases. Nothing in this Agreement obligates VOTOCAST to monitor or exert editorial
control over the Mobile Apps, APIs, SDKs or databases. 4. PRICING AND PAYMENT 4.1 Services Fees.
Licensee shall pay VOTOCAST the Services Fees in accordance with the applicable fee and payment
schedule set forth in Exhibit A hereto. VOTOCAST expressly reserves the right to change its rates
charged hereunder for the Services during any Renewal Term (as detined herein) but agrees that rates
may not increase by more than ten percent (10%) during any Renewal Term. If circumstances require
VOTOCAST to raise its rates more than ten percent (10%) during any Renewal Term, VOTOCAST will
provide Licensee cost related supporting documentation to justify the rate increase. VOTOCAST will
give Licensee at least thirty (30) days prior written notice of any rate changes during any Renewal
Term. 4.2 Payment. All fees are due and payable within thirty (30) days of the applicable VOTOCAST
invoice. Any payments made later than the due date will accrue interest from the date due until the
date paid at the rate of one percent (I%) per month on the amount due, or the maximum rate permitted
by law, whichever is less. In addition, failure of Licensee to fully pay any fees within sixty (60)
days after the applicable due date, shall be deemed a material breach of this Agreement, justifying
suspension of the performance of Services by VOTOCAST, and will be sufficient cause for immediate
termination of this Agreement by VOTOCAST. Any such suspension does not relieve Licensee from paying
fees past due plus interest and in the event of collection enforcement, Licensee shall be liable for
any costs associated with such collection, including, but not limited to, legal costs, attorneys'
fees, court costs and collection agency fees. 4.3 Taxes. All amounts payable hereunder are exclusive
of any sales, use, excise, property, value added or any other taxes associated with Licensee's or
Licensee Users' use of the Services. Licensee is responsible for payment of any and all such taxes
(excluding taxes based on VOTOCAST'S net income). 4.4 Licensee Revenues. Except with respect to the
fees set forth in Exhibit A Licensee shall be authorized to keep all revenues derived from
Licensee's exploitation of Services including. but not limited to advertising, sponsorships,
subscriptions, and any other types of revenues. 5. OWNERSHIP AND PROPRIETARY RIGHTS 5.1 Proprietary
Rights of Licensee. As between Licensee and VOTOCAST, Licensee Content shall remain the sole and
exclusive property of Licensee, including, without limitation, all copyrights, trademarks, patents,
trade secrets, and any other proprietary rights. Except as provided in this Section 6.1 nothing in
this Agreement shall be construed to grant VOTOCAST any ownership rights in, or license to, the
Licensee Content provided by Licensee or Licensee Users. Licensee hereby grants to VOTOCAST a
non-exclusive, worldwide, royalty-free license during the term of this Agreement to edit, modify.
adapt. translate, exhibit, publish, transmit, participate in the transfer of, reproduce, create
derivative works from, distribute, perform, display and otherwise use Licensee Content as necessary
to render Services to Licensee under this Agreement. 5.2 Proprietary Rights of VOTOCAST. THIS
AGREEMENT IS NOT A WORK-FOR-HIRE AGREEMENT. All materials, including but not limited to any computer
software (in object code and source code form), data, information or content developed or provided
by VOTOCAST or its suppliers under this Agreement, and any know-how, methodologies, equipment. or
processes used by VOTOCAST to provide the Services to Licensee and Licensee Users, including,
without limitation, all copyrights, trademarks, patents, trade secrets, and any other proprietary
rights inherent therein and appurtenant thereto (collectively, "VOTOCAST Materials") shall remain
the sole and exclusive property of VOTOCAST or its suppliers. To the extent, if any, that ownership
of the VOTOCAST Materials does not automatically vest in VOTOCAST by virtue of this Agreement or
otherwise, Licensee hereby transfers and assigns to VOTOCAST all rights, title and interest which
Licensee may have in and to the VOTOCAST Materials. Licensee acknowledges and agrees that VOTOCAST
is in the business of hosting Mobile Apps and providing Mobile App services, and that VOTOCAST shall
have the right to provide to third parties services which are the same or similar to the Services,
and to use or otherwise exploit any VOTOCAST Materials in providing such services.

3

Source: VITALIBIS, INC., 8-K, 3/16/2018
<!-- page 4 -->
5.3 Feedback. With regard to any recommendations, ideas, contributions, corrections. enhancements,
improvements, or the like relating to the Services that are created or originated by Licensee
("Feedback"), Licensee shall, prior to disclosure of such Feedback to VOTOCAST, provide written
notice to VOTOCAST if Licensee considers the Feedback to be proprietary to Licensee. The Parties
will then exercise commercially reasonable efforts to reach an agreement regarding ownership and use
of the Feedback prior to disclosure by Licensee. Any Feedback submitted to VOTOCAST without Licensee
providing such written notice, shall be deemed the sole property of VOTOCAST and the same, together
with all copyrights, trade secrets, patent rights, and other intellectual property thereto shall be
and hereby are assigned to VOTOCAST. 6. WARRANTIES 6.1 Licensee Warranties. Licensee warrants that:
(a) it is duly organized, validly existing, and in good standing under the jurisdiction of its
formation; (b) it has all requisite power and authority to execute this Agreement and to perform its
obligations hereunder; (c) the execution, delivery, and performance of this Agreement has been duly
authorized and this Agreement is a valid and binding contract enforceable in accordance with its
terms; (d) VOTOCAST'S use of any data, information, or materials, including, without limitation, the
Licensee Content and Licensee User information, provided by Licensee or Licensee Users does not and
will not, to Licensee's knowledge, contain any content, materials, advertising or services that are
materially inaccurate or that infringe on or violate any applicable law, regulation or right of a
third party, including, without limitation, or any proprietary, contract, moral, or privacy right or
any other third party right, and that Licensee and/or Licensee Users own the Licensee Content or
otherwise has the right to place the Licensee Content on the Mobile Apps; and (e) Licensee has
obtained any authorization(s) necessary. Should Licensee receive notice of a claim regarding the
Mobile Apps, Licensee shall promptly provide VOTOCAST with written notice of such claim. The sole
remedy for any breach of Section 6.1 (d) and (e) shall be the provisions in Section 7.1. 6.2
VOTOCAST'S Warranties. VOTOCAST warrants that: (a) it is a California corporation duly organized and
validly existing under the jurisdiction of its formation; (b) it has all requisite power and
authority to execute this Agreement and to perform its obligations hereunder; (c) the execution,
delivery, and performance of this Agreement has been duly authorized and this Agreement is a valid
and binding contract enforceable in accordance with its terms; (d) the Services, as set forth in the
terms of this Agreement, will be performed in accordance with applicable industry standards; (e)
Licensed Software—Warranty is not based on time, but is based on support and maintenance of the
prior 2 versions (defined by update) and the current version. (For clarity, if the current version
is 1.7. we would also warrant 1.6 and 1.5.); (f) Configuration and Customization Services — Licensee
has a 15 business day period directly after the production release to report any defects related to
the customization services; these defects are covered under the warrant and are corrected at "no
cost" to the customer; and (g) Licensee's use of any VOTOCAST Materials provided on the Mobile Apps
does not and v. ill not, to VOTOCAST'S knowledge, contain any content, materials, advertising or
services that are materially inaccurate or that infringe on or violate any applicable law,
regulation or right of a third party. including, without limitation, or any proprietary, contract,
moral, or privacy right or any other third party right, and that VOTOCAST owns the content or
otherwise has the right to place the content on the Mobile Apps. The sole remedy for any breach of
Section 6.2 (e) shall be the provisions in Section 7.2. 6.3 Disclaimer of Warranty. EXCEPT FOR THE
LIMITED WARRANTY SET FORTH IN SECTION 6.2 VOTOCAST MAKES NO WARRANTIES HEREUNDER, AND VOTOCAST
EXPRESSLY DISCLAIMS ALL OTHER WARRANTIES, EXPRESS OR IMPLIED. INCLUDING, WITHOUT LIMITATION, ANY
IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NON- INFRINGEMENT. 7.
INDEMNIFICATION 7.1 Indemnification by Licensee. Licensee agrees to defend any action brought
against VOTOCAST with respect to any claim, demand, cause of action, debt or liability, including
reasonable outside attorneys' fees, to the extent that such action arises from the negligence or
willful misconduct of Licensee or is based upon a claim that any of the Licensee Content to be
provided by Licensee hereunder or other material on the Mobile App infringes or violates any rights
of third parties, including without limitation, rights or publicity, rights of privacy, patents,
copyrights, trademarks, trade secrets, and/or licenses. 7.2 Indenmification by VOTOCAST. VOTOCAST
agrees to defend any action brought against Licensee with respect to any claim, demand, cause of
action, debt or liability, including reasonable attorneys' fees, to the extent that such action
arises from the negligence or willful misconduct of VOTOCAST or is based upon a claim that any of
the VOTOCAST Materials provided by VOTOCAST on the Mobile Apps infringes or violates any rights of
third parties, including without limitation, rights or publicity, rights of privacy, patents,
copyrights, trademarks, trade secrets, and/or licenses.

4

Source: VITALIBIS, INC., 8-K, 3/16/2018
<!-- page 5 -->
7.3 Notice. In claiming any indemnification hereunder, the indemnified Party shall promptly provide
the indemnifying Party with written notice of any claim which the indemnified Party believes falls
within the scope of the foregoing Sections. The indemnified Party may, at its own expense, assist in
the defense if it so chooses, provided that the indemnifying Party shall control such defense and
all negotiations relative to the settlement of any such claim and further provided that any
settlement intended to bind the indemnified Party shall not be final without the indemnified Party's
written consent, which shall not be unreasonably withheld or delayed. 8. LIMITATION OF LIABILITY 8.1
Exclusion of Certain Damages. VOTOCAST SHALL HAVE NO LIABILITY FOR UNAUTHORIZED ACCESS TO, OR
ALTERATION, THEFT OR DESTRUCTION OF, THE MOBILE APPS OR LICENSEE'S OR LICENSEE USER'S DATA FILES,
PROGRAMS OR INFORMATION THROUGH ACCIDENT, FRAUDULENT MEANS OR DEVICES. VOTOCAST SHALL HAVE NO
LIABILITY WITH RESPECT TO VOTOCAST'S OBLIGATIONS UNDER THIS AGREEMENT OR OTHERWISE FOR ANY
CONSEQUENTIAL, EXEMPLARY, SPECIAL. INCIDENTAL, OR PUNITIVE DAMAGES OF ANY KIND (INCLUDING, WITHOUT
LIMITATION, LOSS OF PROFITS, REVENUE. BUSINESS, OR DATA), EVEN IF VOTOCAST HAS BEEN ADVISED OF THE
POSSIBILITY OF SUCH DAMAGES. 8.2 Limitation. TO THE MAXIMUM EXTENT PERMITTED BY LAW, VOTOCAST'S
AGGREGATE LIABILITY ARISING FROM OR RELATING TO THIS AGREEMENT OR THE USE OR INABILITY TO USE THE
SERVICES SHALL BE LIMITED TO THE AMOUNT OF ALL FEES ACTUALLY RECEIVED BY VOTOCAST FROM LICENSEE
UNDER THIS AGREEMENT. THIS LIMITATION APPLIES TO ALL CAUSES OF ACTION IN THE AGGREGATE, INCLUDING,
WITHOUT LIMITATION, TO BREACH OF CONTRACT, BREACH OF WARRANTY, NEGLIGENCE. STRICT LIABILITY,
MISREPRESENTATIONS, AND OTHER TORTS. 9. CONFIDENTIALITY 9.1 Confidential Information. Each Party
agrees that during the course of this Agreement, information that is confidential or proprietary may
be disclosed to the other Party, including, but not limited to, software, algorithms, technical
processes and procedures, product designs, sales, cost and other unpublished financial information,
product and business plans, revenues, advertising relationships, projections, and marketing data,
and any other information that the disclosing Party ("Discloser") desires to protect against
unrestricted disclosure by the receiving Party ("Recipient') that: (a) if disclosed in tangible or
electronic form, is marked as "confidential," (b) if disclosed orally or visually, is designated
orally as "confidential" at the time of disclosure or within a reasonable period of time thereafter,
or (c) that the Recipient knows or should reasonably know is confidential or proprietary. The
Recipient will maintain the confidentiality of the Discloser's Confidential Information with at
least the same degree of care that it uses to protect its own confidential information, but no less
than a reasonable degree of care. The Recipient will not disclose any of the Discloser's
Confidential Information to any employees or third parties except for (I) the employees of the
Recipient who have a need to know and who have agreed in writing to maintain the confidentiality of
such information, and (2) Recipient's third party contractors who have agreed in writing to maintain
the confidentiality of such information. These confidentiality obligations shall survive for three
(3) years after expiration or termination of this Agreement; provided, that the expiration of such
obligations shall not affect any other restrictions on the Recipient, including without limitation,
any restrictions under patent or copyright laws. 9.2 Exceptions. Confidential Information will not
include any information that is: (a) rightfully in the public domain without any breach by the
Recipient, but only from the date it entered the public domain. (b) rightfully received by Recipient
from a third party without any obligation of confidentiality, (c) rightfully known to the Recipient
without any obligation of confidentiality prior to its receipt from the Discloser, (d) independently
developed by the Recipient's employees without use of the Discloser's Confidential Information. (e)
made generally available to third parties by the Discloser without restrictions on disclosure, (0
required, on advice of counsel, to be disclosed under applicable laws, rules, or regulations,
provided that Recipient gives reasonable prior notice to Discloser of such duty to disclose, or
(vii) technical feedback from Licensee related to the Services. 10. TERM AND TERMINATION 10.1 Term.
This Agreement shall commence as of the Effective Date and shall continue in effect for one (I)
year, unless earlier terminated as expressly provided in Sections 1.3. 10.1. or 10.2 of this
Agreement (the *Initial Term"). This Agreement shall automatically renew beyond the Initial Term for
successive one (I) year terms (each, a "Renewal Term"), unless a Party provides the other with
written notice of termination at least one hundred eighty (180) days prior to the expiration of the
Initial Term or the then-current Renewal Term. Regardless of the term, Licensee can terminate
Agreement with at least one hundred eighty (180) days written notice with no further obligation.

5

Source: VITALIBIS, INC., 8-K, 3/16/2018
<!-- page 6 -->
10.2 Termination for Breach. Notwithstanding the foregoing, either Party may terminate this
Agreement by giving written notice to the other Party if the other Party is in material breach of
any obligation under this Agreement, ''which breach is not cured within thirty (30) days after
receipt of written notice of such breach. In addition, either Party may terminate this Agreement
effective immediately upon written notice to the other Party if the other Party: (a) terminates or
suspends its business operations, (b) becomes the subject of any bankruptcy or insolvency
proceeding, (c) becomes insolvent or unable to pay its obligations as they accrue, or (d) becomes
subject to direct control by a trustee, receiver, or similar authority. 10.3 Effect of Termination.
Upon termination of this Agreement. VOTOCAST shall immediately cease providing all Services,
Licensee and Licensees Users shall discontinue use of the Services. and VOTOCAST shall delete all
stored contents of Licensee and Licensees Users (after first delivering a copy of such stored
content to Licensee). However, VOTOCAST shall continue to be entitled to receive, and the Licensee
shall continue to pay to VOTOCAST, the amounts owing to VOTOCAST up to the date of termination
pursuant to Section 4. Termination of this Agreement shall not act as a waiver of any breach of this
Agreement or as a release of either Party from any liability for breach of such Party's obligations
under this Agreement. Regardless of any other provision of this Agreement, VOTOCAST shall not be
liable by reason of termination of this Agreement for compensation, reimbursement, or damages on
account of the loss of prospective profits on anticipated sales, or on account of expenditures,
investments, leases or other commitments made in connection with Licensee's business or otherwise,
excluding any amounts paid by Licensee to VOTOCAST pursuant to the terms of this Agreement. 10.4
Survival. Sections 4.2. 4.3. 5. 6. 7, 8. 9. 10.3. 10.4, 11, and any other provision of this
Agreement which by its nature or express terms extends beyond the duration of this Agreement, shall
survive any termination of this Agreement. 11. OTHER PROVISIONS 11.1 Independent Parties. Nothing
contained in this Agreement shall be construed as creating a joint venture, partnership, agent or
employment relationship between VOTOCAST and Licensee. 11.2 Waiver. The failure of either Party to
enforce any provision of this Agreement shall not be deemed a waiver of that provision or of the
right of the Party to thereafter enforce that or any other provision. 11.3 Severability. If any term
or provision of this Agreement should be declared invalid by a court of competent jurisdiction or by
operation of law, the remaining terms and provisions of this Agreement shall be unimpaired, and the
invalid term or provision shall be replaced by such valid term or provision as comes closest to the
intention underlying the invalid term or provision. 11.4 Notices. All notices and other
communications required or permitted under this Agreement shall be in writing and shall be: (a)
delivered personally, (b) sent by confirmed email, (c) sent by commercial overnight courier with
written verification of receipt, or (d) sent by registered or certified mail, return receipt
requested, postage paid, to the address of the Party to be noticed as set forth herein, or such
other address as such Party last provided to the other by written notice. VITA LI BI S. INC. Attn:
Thomas Raack 5348 Vegas Drive Las Vegas, NV 89108 Phone: 702-944-9620 Email: traack@vitalibis.com

VOTOCAST, Inc. (dba, newkleus) Attn: Steve Raack PO Box 7302 Newport Beach, CA 92658 Phone:
310-259-1248 Email: steve@VOTOCAST.com 11.5 Integration. This Agreement and its exhibits constitute
the entire agreement between the Parties with respect to the subject matter hereof and supersede all
prior proposals, negotiations, conversations, discussions and agreements between the Panics
concerning the subject matter hereof.

6

Source: VITALIBIS, INC., 8-K, 3/16/2018
<!-- page 7 -->
11.6 Assignment. Neither Party may assign this Agreement or otherwise transfer in any way any of the
rights and obligations arising out of this Agreement without the prior written consent of the other
Party. Notwithstanding the foregoing, (1) either Party may assign this Agreement to any entity who
acquires (by merger, acquisition, or otherwise) all or substantially all of the business assets of
such Party applicable to the subject matter of this Agreement; and (2) VOTOCAST may subcontract any
portion of the Services to a third party contractor without the prior consent of Licensee, provided
that VOTOCAST remains fully responsible to Licensee for the delivery of such Services as set forth
in this Agreement. Any attempted assignment or delegation without such prior written consent, except
as expressly set forth herein, will be void, or at the non-assigning Party's sole discretion, may be
treated as fully binding upon and in force and effect against any such successor or assign. 11.7
Publicity. VOTOCAST may only use the name of and identify Licensee as a VOTOCAST client. in
advertising, publicity, or similar materials distributed or displayed to prospective clients upon
the written approval (by email or other written means) of Licensee, which approval shall not be
unreasonably withheld or delayed. 11.8 Force Majeure. Except for the payment of fees by Licensee,
neither Party shall be responsible for any delay or failure to perform obligations specified in this
Agreement due to causes beyond the Party's reasonable control. including, without limitation, acts
of God, strikes, lockouts, riots, acts of war, governmental regulations, shortage of equipment,
materials or supplies, fire, power failure. earthquakes, severe weather, floods or other natural
disaster; provided, however, it is understood that this Section is intended only to suspend and not
discharge a Party's obligations under this Agreement and that when the causes of the delay or
failure are removed or alleviated, the affected Party shall resume performance of its obligations
hereunder. 11.9 Amendments. No amendment or modification of any provision of this Agreement shall be
effective unless the same shall be in writing and signed by both Parties. 11.10 Governing Law. This
Agreement shall be governed by the laws of the State of California without giving effect to conflict
or choice of law principles. The Parties hereto agree that the exclusive jurisdiction and venue for
any action under this Agreement shall be the state and federal courts sitting in California, and
each of the Parties hereby agrees and submits itself to the exclusive jurisdiction and venue of such
courts for such purpose. 11.11 Freedom of Action. This Agreement is non-exclusive. The Parties
acknowledge that each Party is free to enter into agreements that are similar to this Agreement with
any corporation or other entity; including competitors of the other Party, provided the
confidentiality provisions of this Agreement are not breached and the intellectual property rights
of the other Party are not misappropriated or infringed. 11.12 Injunctive Relief. The Parties
acknowledge that any breach by the other Party of any of the covenants or provisions contained in
this Agreement may give rise to irreparable injury to non-breaching Party inadequately compensable
in damages alone. Accordingly, the non- breaching Party may seek preliminary and permanent
injunctive relief against the breach or threatened breach of said covenants or provisions. Such
relief shall be in addition to any other legal or equitable remedies that may be available to the
non-breaching Party. 11.13 Laws and Regulations. Licensee and VOTOCAST agree to comply with
applicable laws, rules, and regulations, including any Internet regulations or policies and
applicable export laws, in its performance under this Agreement. 11.14 Non-Solicitation. Each Party
agrees that during the term of this Agreement and for a period of twelve (12) consecutive months
thereafter they shall not, directly, solicit, engage, compensate, induce in any way or hire for
employment or other representation, any officer, employee, consultant or other representative
employed or retained by the other Party or assist any other person or entity to do any of the
foregoing. If any such action occurs and results in an employee accepting employment with the other
Party, the Party with whom the employee accepts employment agrees to pay to the other Party as
liquidated damages, an amount equal to two times that particular individual's annual salary and
bonus.

7

Source: VITALIBIS, INC., 8-K, 3/16/2018
<!-- page 8 -->
11.15 Execution and Authority. This Agreement may be executed in two or more counterparts, each of
which shall be deemed an original, but all of which taken together shall constitute one and the same
instrument. A facsimile or imaged copy of this Agreement, including the facsimile or imaged
signatures of the Parties' representatives thereon, shall for all purposes be deemed equivalent to
an original. 11.16 Effective Date. The Effective Date of this Agreement shall be the later of the
dates shown by the signatures below. IN WITNESS WHEREOF. the Parties have caused this Agreement to
be executed below by their respective duly authorized representatives. VITABILIS, INC. VOTOCAST,
INC. ("Votocast") By: /s/ Markus Frick By: /s/ Steven P. Raack Name: Markus Frick Name: Steven P.
Raack Title: Director Title: CEO Date: 3-14-18 Date: 3-7-18

8

Source: VITALIBIS, INC., 8-K, 3/16/2018
<!-- page 9 -->
EXHIBIT A SERVICES AND FEES Services Fees: 1. Implementation Fees: Implementation Fees for Branded
Mobile Apps are shown in the table below: Service Fee Branded Mobile Apps $0 Admin Database $0
Website Integration (APIs) $0 Existing Mobile App Integration (APIs and/or SDKs) SO These are
one-time fees, paid in advance. No work will begin until these fees have been received. 2. License
and Hosting Fees License and Hosting Fees are as shown in the table below: # of Monthly Video Views
Fee Up to 9,999 SO Between 10.000 — 24,999 $1.000 Between 25.000 — 49,999 $1.500 Over 50,000 $2,000
License and Hosting Fees will be billed after each month, based on the Total Number of Videos Views
for that month. For tracking and validation purposes, the Total Number of Video Views will be shown
within the Admin Database as a cumulative metric. 3. Scone of Services: - Branded iOS Mobile App -
Branded Android Mobile App - Application APIs - Application SDKs - Admin Database Unless
specifically noted othenwise, the scope of all services provided by VOTOCAST is limited to the usage
and ongoing support of the Services only, and does not include analysis, operation, integration,
development, additional training or modification of other custom or OEM packaged software
applications, hardware or systems. Such services can be requested by Licensee and negotiated under a
separate SOW. PRICES ARE STRICTLY CONFIDENTIAL. NO PART OF THIS DOCUMENT, ESPECIALLY PRICING
INFORMATION, MAY BE DISCLOSED IN ANY MANNER TO A THIRD PARTY WITHOUT THE PRIOR WRITTEN CONSENT OF
VOTOCAST.

9

Source: VITALIBIS, INC., 8-K, 3/16/2018
<!-- page 10 -->
EXHIBIT B ACCEPTANCE CRITERIA Acceptance criteria shall be as follows: · Licensee Content was
applied to the Mobile Apps appropriately · A user can create a new account and login using an
existing account · A user can upload a video, vote for a video, comment on a video, share a video,
report a video, follow another user, follow a campaign, and set up their user profile · An admin
user can login to the Admin Module, create campaigns, delete comments, delete videos, export user
information and monitor key metrics Upon Acceptance approval by Licensee per Section 13, VOTOCAST
will assist in publishing the Mobile Apps on the AppStore and on GooglePlay.

10

Source: VITALIBIS, INC., 8-K, 3/16/2018
<!-- page 11 -->
EXHIBIT C SERVICE LEVELS VOTOCAST shall provide support to Licensee, in English, through e-mail
(support@VOTOCAST.com), five (5) days a week, eight hours a day (9:00 to 5:00 PST). Monday to
Friday, excluding federal and banking holidays. Licensee shall be solely responsible for support to
Licensee Users. Licensee agrees that VOTOCAST is responsible only for providing the Services, and is
not responsible for providing any services or performing any tasks not specifically set forth in
Exhibit A. unless such services or tasks are mutually agreed upon in writing by authorized
representatives of the Parties. Severity Response Time Severity 1 Every Two Hours (24x7) Severity 2
Every 8 Hours (9AM-5PM PST) Severity 3 Every 48 Hours (9A1V1-5PM PST) Severity 4 Every 72 Hours
(9AM-5PM PST) "Response Time" means the time beginning when Licensee informs VOTOCAST of a Support
incident and ending when the Support incident is either resolved or a reasonable fix is implemented.
Support Incident Severity Definitions and Responses: Classifications. By mutual agreement (following
the definitions noted here below), Support incidents will be classified by type as a Severity I, 2,
3 or 4. Severity 1 Definition - Critical business impact, including Licensee being unable to use one
or more of the features resulting in a critical impact on operations. This condition requires
immediate resolution. Severity 1 Condition - Issue has a critical business impact and / or a
crippling effect on the Licensee's business. Examples include the following: · The production system
is down · Critical features are unusable · Data is not accessible · Company has repeated production
outages that are disrupting the success of their business NOTE: A critical situation does not
automatically imply Severity 1. The associated problem's business impact sets the Severity. Severity
2 Definition — To the extent not a Severity 1, significant business impact, including when one of
the critical features is usable but is severely limited. Severity 2 Conditions. Examples include the
following: · Non-production system data is inaccessible · Degraded performance having serious
negative impact on business · A database/application error has occurred, severely hampering business
operability Severity 3 Definition — To the extent not a Severity I or a Severity 2, some business
impact, including when one of the critical features is usable but with less significant features
(e.g., not critical to operations) being unavailable.

11

Source: VITALIBIS, INC., 8-K, 3/16/2018
<!-- page 12 -->
Severity 3 Conditions. Examples include the following: · Aesthetic formatting inconsistencies ·
Degraded performance such as unusually slow application response causing user dissatisfaction and
reported complaints · Acceptable (by Licensee) workarounds available for incidents initially
classified as Severity I or Severity 2 Severity 4 Definition — To the extent not a Severity I,
Severity 2 or Severity 3, minimal business impact, including when the problem results in little
impact on operations or a reasonable circumvention to the problem has been implemented. Severity 4
Conditions. Examples include the following: · General question such as "how-to" · Issue with little
or no impact on business · Documentation issues · Issue is essentially resolved but remains open for
Licensee confirmation

12

Source: VITALIBIS, INC., 8-K, 3/16/2018
<!-- page 13 -->
EXHIBIT D FORM OF SOW STATEMENT OF WORK #XXXX TO SERVICES AND HOSTING AGREEMENT THIS STATEMENT OF
WORK # XA2X TO SERVICES AND HOSTING AGREEMENT (this "Statement of Work") is made and entered into as
of <DATE> (the "SOW Effective Date"), by and between VITALIBIS INC. a Nevada C Corporation having
its principal place of business at 5348 Vegas Drive, Las Vegas NV 89108 (hereinafter, "Licensee"),
and VOTOCAST, Inc., a California corporation (dba, newkleus), having its principal place of business
at PO Box 7302 Newport Beach, CA 92658 (hereinafter, "VOTOCAST"). VOTOCAST and Licensee may also be
referred to individually as a "Party" and collectively as the 'Parties." RECITALS WHEREAS, Licensee
and VOTOCAST have entered into a Services and Hosting Agreement (the "Agreement') dated March 7t h,
2018 (the "Effective Date"). WHEREAS, pursuant to Section 1.4 of the Agreement, the Parties now
desire to enter into this Statement of Work describing Professional Services to be performed by
VOTOCAST and the terms and conditions applicable to the performance of such Professional Services.
AGREEMENT NOW THEREFORE, in consideration of the promises and mutual covenants herein contained, the
undersigned hereby agree as follows: 1. Statement of Work. This Statement of Work sets forth the
scope of Professional Services to be rendered by VOTOCAST pursuant to the Agreement. The Agreement
is hereby expressly supplemented by the terms and conditions contained in this Statement of Work
and, except as expressly provided herein, the terms and conditions of the Agreement shall apply to
the SOW Services (as defined below). Any capitalized terms used in this Statement of Work which are
not defined herein shall have the meanings ascribed to such terms in the Agreement. Should a
conflict arise between a term or provision of this Statement of Work and a term or provision of the
Agreement, (i) every effort shall be made to interpret and construe the Agreement and this Statement
of Work in an inclusive and consistent manncr, and (ii) if such consistent interpretation is
impossible, then the terms of the Agreement shall prevail unless specifically provided otherwise in
this Statement of Work. 2. Services. VOTOCAST agrees to use reasonable efforts to perform the
Professional Services as set forth in Schedule A attached hereto (the "SOW Services"). 3. Payment.
3.1 Services Fee. As payment for the SOW Services, Licensee shall pay VOTOCAST TBD — as analysis and
negotiations are necessary (the "SOW Services Fee"). Licensee shall pay or promptly reimburse
VOTOCAST for any out-of-pocket expenses, including without limitation, travel and travel-related
expenses, incurred by VOTOCAST in connection with the performance of the SOW Services. 3.2 Payment
Terms. The SOW Services Fee will be invoiced twice monthly by VOTOCAST and invoiced in even
increments between SOW execution and scheduled production deployment. Payment for the SOW Services
Fee shall be in U.S. dollars and is due and payable within fifteen (15) days of the applicable
VOTOCAST invoice. Except as othenwise provided herein, all payments due and payable under this
Statement of Work shall be made in accordance with the payment terms set forth in Section 4 of the
Agreement.

13

Source: VITALIBIS, INC., 8-K, 3/16/2018
<!-- page 14 -->
4. Change Orders. If Licensee desires to extend the SOW Services in any way, the Parties agree to
negotiate in good faith and enter into a separate change order that sets forth the terms and
conditions (including any additional consideration) applicable to such additional services as set
forth in Schedule B attached hereto (the "Change Order"). Neither Party shall have any obligation
with respect to any services not specifically described in the Agreement, this Statement of Work, or
a Change Order unless and until such has been agreed to in a writing executed by the authorized
representatives of both Parties. The following are authorized to sign or provide email approval
Change Orders in behalf of Licensee: Name: Thomas Raack Title: CFO Secretary IN WITNESS WHEREOF,
VOTOCAST and Licensee have executed this Statement of Work effective as of the SOW Effective Date.
VITABILIS, INC. VOTOCAST, INC. "Votocast") By: ______________________ By: ______________________
Name: ____________________ Name: ____________________ Title: _____________________ Title:
_____________________ Date: _______ Date: _______

Source: VITALIBIS, INC., 8-K, 3/16/2018
