<!-- page 1 -->
# DISTRIBUTOR AGREEMENT
| Field | Value |
|---|---|
| Document Type | Distributor Agreement |
| SEC Filing Date | 2005-12-15 |
| Parties | PPG Paints Trading (Shanghai) Co Ltd ("PPG Shanghai"); NeoMedia Micro Paint Repair ("DISTRIBUTOR") |
| Source | CUAD v1 / NEOMEDIATECHNOLOGIESINC_12_15_2005-EX-16.1-DISTRIBUTOR AGREEMENT |

Exhibit 16.1

AUTOMOTIVE REFINISH DISTRIBUTOR AGREEMENT (P.R.China)

THIS AGREEMENT, made as of the 1st day of December, (the "Effective Date") by and between:

PPG Paints Trading (Shanghai) Co Ltd hereinafter referred to as ("PPG Shanghai")

Address : Suite 2512, 5th Floor No. 2 Xin Kang Building, 28 Jia Feng Road Wai Gao Qiao Free Trade
Zone Shanghai, P. R. China

Tel. : (86-21) 6291 3500

Fax : (86-21) 6291 2100

Business liscence no. : 0537762

Legal representative : Viktoras R. Sekmakas and

NeoMedia Micro Paint Repair hereinafter referred to as ("DISTRIBUTOR")

Address : 2201 Second Street, Suite 600 Ft. Myers, Florida, 33901

Tel. : 239-337-3434

Fax : 239-337-3668

Business licence no. : 2648151

Legal representative : Charles T. Jensen

WITNESSETH:

WHEREAS:

A. PPG SHANGHAI desires DISTRIBUTOR to market and sell PPG's "Deltron" and "ACS" brand products, as
hereinafter defined in Section 2 (the "Products"), to the repair chain shops in P.R.China as listed
on Appendix 4 (the "Territory");

B. DISTRIBUTOR has the means to market Products in the Territory. As soon as Distributor's China
subsidary, NeoMeida Micro Paint Repair China, a Wholley Foreign Owned Enterprise ("WFOE") registered
under the Chinese laws and regulations, will be established, this title of Distributor will be
automatically switched to the WFOE.

C. PPG SHANGHAI desires to appoint DISTRIBUTOR as a PPG SHANGHAI distributor in the Territory and
DISTRIBUTOR desires to be such distributor; and

D. Accordingly, PPG SHANGHAI and DISTRIBUTOR have reached an agreement as hereinafter set forth.

In consideration of the mutual covenants and agreements herein contained, the parties hereto,
intending to be legally bound hereby, covenant and agree as follows:

1. APPOINTMENT

1.1 PPG SHANGHAI does hereby appoint DISTRIBUTOR to distribute in the Territory the Products (as
defined in paragraph 2, below) upon the terms and conditions hereinafter set forth. DISTRIBUTOR does
hereby accept such appointment.

1.2 It is agreed that such appointment is nonexclusive and PPG SHANGHAI may, without obligation to
pay DISTRIBUTOR any commission or other compensation, make direct sales of Products to other
customers in the Territory and/or appoint additional distributors of Products in the Territory.
During the term of this Agreement, DISTRIBUTOR shall have the exclusive right for selling the
Products to Beijing Sino-US Jinche Yingang Auto Technological Services Limited (the "Auto Center").
PPG Shanghai or any of its direct or indirect affiliates shall not sell any of its products directly
to the Auto Center or to any of the Auto Center's affiliates in China or throughout the world,
unless PPG Shanghai obtains Distributor's written approval. It is understood and agreed that as used
herein the term "PPG" shall mean PPG Industries Inc. and/or one or more affiliated companies of PPG
Industries Inc. as the context may require.

1.3 Notwithstanding anything to the contrary in this Section 1, PPG SHANGHAI may also sell Products
to any person or entity located outside the Territory without being obligated to consider whether
such Products may be resold in the Territory. DISTRIBUTOR shall not be entitled to any commission or
other compensation in such event.
<!-- page 2 -->
1.4 Deleted.

1.5 DISTRIBUTOR warrants that it will not handle any counterfeit, passing-off products or products
other than those purchased directly from PPG SHANGHAI.

1.6 DISTRIBUTOR warrants and represents that it is a corporation duly organized, validly existing,
and in good standing under the applicable laws, that it has full legal right, power, and authority
to enter into this Agreement and to consummate or cause to be consummated all of the transactions
contemplated hereby, and that the execution, delivery, and/or performance of this Agreement do not
or will not conflict with or result in a breach of any provision of any articles of incorporation or
by-laws, or any written undertaking to which it is a party or by which it, or any of its assets, may
be bound or affected, or result in a violation of any law, regulation, order, or award of any
authority or body having jurisdiction over the assets and operations of it.

2. PRODUCTS

2.1 The Products and subject matter of this Agreement shall be the products listed below
manufactured and sold by PPG SHANGHAI or affiliated companies of PPG SHANGHAI. Additional Products
may be added to or deleted from the list at the sole discretion of PPG SHANGHAI:

(a) Global Deltron Refinish Products.

(b) ACS Products.

(c) Ancilliaries confirmed in writing for distribution by PPG SHANGHAI.

(d) Mixing equipment and related accessories as approved and supplied by PPG SHANGHAI.

(e) Any other products as PPG SHANGHAI may launch from time to time, at its absolute discretion.

2.2 Specific product codes for above category a, b, c, d, and e shall reference PPG SHANGHAI Price
List in effect as of January 1, 2005 on Appendix 5.

3. REPRESENTATIONS AND WARRANTIES BY DISTRIBUTOR

DISTRIBUTOR represents and warrants to PPG SHANGHAI that(pound)(0)

(a) it is a business entity duly incorporated and registered and validly existing under the relevant
PRC laws and regulations;

(b) it has been issued a valid business licence in its name by the relevant local branch of the
State Administration of Industry and Commerce, and that business licence shall be valid within the
duration of this Agreement;

(c) it is permitted to distribute chemical products pursuant to this Agreement under its approved
business scope;

(d) it has a Dangerous Goods Business Permit Licence issued by the appropriate local government;

(e) it has the qualification of a general taxpayer and is able to issue value added tax invoices;

(f) it shall comply with all the relevant laws, regulations and permits, which have jurisdiction
over its business, in relation to the sale of Products,

4. DISTRIBUTOR'S RESPONSIBILITY

4.1 DISTRIBUTOR shall promote the sale of the Products in the Territory. DISTRIBUTOR will conduct
its operations in the Territory through offices or agencies to be maintained by DISTRIBUTOR at its
sole cost and expense.

4.2 If DISTRIBUTOR sells or distributes the Products outside the Territory, whether directly or
indirectly through DISTRIBUTOR's cooperation or in conjunction with other third parties, or to
customers outside the Territory without the prior knowledge and consent of PPG SHANGHAI, PPG
SHANGHAI shall have the right to terminate with immediate effect this Agreement and any existing
incentive arrangements between PPG SHANGHAI and DISTRIBUTOR, whether entered into before or after
the commencement of the Agreement.

4.3 DISTRIBUTOR agrees to satisfy the annual and quarterly sale targets for the Products set forth
in Appendix 3 herein as mutually agreed to by the parties hereof.

4.4 DISTRIBUTOR and PPG Shanghai shall be responsible for providing technical support and after sale
services to the Territory. PPG Shanghai's responsibility under this Section 4.4 is defined in
Section 8.

5. PRICES AND TERMS
<!-- page 3 -->
5.1 PPG SHANGHAI agrees that PPG SHANGHAI will sell and DISTRIBUTOR agrees to buy the Products at
the prices agreed to by the parties from time to time and subject to the terms and conditions stated
herein. The prices in effect as of the Effective Date of the Agreement are set forth on Appendix 5.
The prices for the Products must be agreed upon by PPG SHANGHAI at the time of PPG SHANGHAI's
written acceptance of an order hereunder. Unless otherwise agreed by PPG SHANGHAI in writing,
DISTRIBUTOR shall prepay all the invoiced amount in the currency and manner as indicated by PPG
Shanghai. DISTRIBUTOR shall be deemed to complete its payment obligation upon full payment of the
invoiced sum, and such amount has been allocated into the account as directed by PPG SHANGHAI. PPG
SHANGHAI shall only have the obligation to deliver the Products upon full and due payment.

5.2 PPG SHANGHAI reserves the right to adjust its selling prices based on local market situation.

5.3 PPG SHANGHAI shall bear the cost of transportation from overseas to its own warehouse, insurance
and export / import duty for any Products to be sold to Distributor hereunder. DISTRIBUTOR shall
pick up the ordered Products from PPG SHANGHAI by its own transport agency to its own places at its
own expenses.

6. INTENT

It is the intent of this Agreement, and PPG SHANGHAI and DISTRIBUTOR agree, that:

(a) no consignment shipments shall be made to DISTRIBUTOR;

(b) DISTRIBUTOR is not authorized to sell the Products in any area outside the Territory or to
establish or operate a "permanent establishment" in any country on behalf of PPG SHANGHAI;

(c) DISTRIBUTOR shall take no action which would cause PPG SHANGHAI to be classified or to be
considered as doing business in any country under the laws of any country, or which would cause PPG
SHANGHAI to become subject to the income tax, excess profits tax, corporation receipts tax, or any
other tax of any country;

(d) DISTRIBUTOR has no authority to conclude contracts on behalf of or in the name of PPG SHANGHAI;

(e) DISTRIBUTOR shall hold PPG SHANGHAI harmless from any taxes or other liability of any type, kind
or nature, assessed against PPG SHANGHAI because of DISTRIBUTOR taking any action prohibited by
subparagraphs (b), (c) and (d) above;

(f) DISTRIBUTOR distributes the Products solely as an independent contractor and is not a
franchisee, employee, partner or agent of PPG SHANGHAI and agrees not to represent the relationship
as otherwise;

(g) No fee or other mandatory consideration has been paid by DISTRIBUTOR to PPG SHANGHAI for
issuance of this Agreement.

8. PPG SHANGHAI'S RESPONSIBILITIES

(a) PPG SHANGHAI shall use reasonable commercial efforts to support DISTRIBUTOR in its sale and
marketing. PPG SHANGHAI shall provide its assistance in sale by providing DISTRIBUTOR with its usual
and newly developed sale materials, samples and sale items from time to time through its
sale/technical representatives.

(b) Upon request by DISTRIBUTOR, PPG SHANGHAI shall provide DISTRIBUTOR with extra support by
generally providing the relevant technique and other manner of consultation in relation to sale and
use of Products.

(c) In pursuance to the reasonable request of DISTRIBUTOR, PPG SHANGHAI shall arrange training for
DISTRIBUTOR in accordance with the product training generally provided by PPG SHANGHAI at its
Training Centers or other pre-agreed venues.

(d) PPG SHANGHAI shall use reasonable commercial efforts to provide forthwith DISTRIBUTOR with the
quantity of Products ordered by it and accepted by PPG SHANGHAI. The supplying responsibility of PPG
SHANGHAI shall be subject to the stock of the ordered products at the time when DISTRIBUTOR's order
is made with PPG SHANGHAI.

(e) PPG SHANGHAI shall provide DISTRIBUTOR Quarterly and Annual Rebate as listed in Appendix 3 if
agreed targets are achieved on time.

9. DISTRIBUTOR'S RESPONSIBILITIES

DISTRIBUTOR agrees that DISTRIBUTOR shall, use all reasonable efforts , do the following:

(a) provide its customers with services regarding the Products, including the safety and
toxicological aspects of Products handling and ensure that delivery to customers is made of
technical information provided by PPG SHANGHAI regarding Products, including the safety precautions
and toxicological aspects of Products handling;
<!-- page 4 -->
(b) maintain an adequate supply of Products to expedite customer deliveries and give prompt and
efficient service to its customers in the Territory;

(c) maintain knowledge of the market in the Territory and regularly communicate such knowledge to
PPG SHANGHAI;

(d) be responsible that the labels for the Products meet all governmental and all applicable laws of
the Territory regulatory requirements and comply with all applicable laws of the Territory;

(e) provide to its customers, Product technical support and training and ensure its customers
maintain technical support and training to end-users.

(f) plan and develop promotional and advertising strategies to enhance PPG SHANGHAI's image and
sales value in the region.

(g) Achieve agreed and signed sales target (Appendix 3).

10. PPG SHANGHAI TRADEMARKS

10.1 PPG SHANGHAI represents that it has rights and interests in the trademarks used on the
Products, including, without limitation, the PPG logo listed on Appendix 2 hereto which shall herein
be collectively referred to as the "PPG Trademarks." PPG SHANGHAI hereby grants to DISTRIBUTOR
during the Term, subject to the terms and conditions hereinafter specified, a limited, nonexclusive,
nonassignable and nontransferable right to use the PPG Trademarks in the Territory for or in
connection with its advertisement, promotion, sale and distribution of Products. In connection with
any use of the PPG Trademarks, DISTRIBUTOR shall prominently indicate that DISTRIBUTOR is an
independent distributor for PPG SHANGHAI. DISTRIBUTOR's use shall be subject to PPG SHANGHAI's
approval and shall be limited to labels and advertisements of the Products in the Territory and
shall be at the expense of DISTRIBUTOR. DISTRIBUTOR agrees to submit proposed uses of the PPG
Trademarks on labels to the Director of Automotive Refinish (Asia Pacific region), or such other
person as PPG SHANGHAI may designate from time to time, for review and approval. DISTRIBUTOR agrees
that if it uses the PPG Trademarks on its labels and in its advertisements, it shall only be in the
form approved in writing by PPG SHANGHAI. PPG SHANGHAI agrees that it will not unreasonably withhold
approval of any labels or advertising material submitted to it by DISTRIBUTOR for approval and use
pursuant to the provisions hereof. DISTRIBUTOR will not seek to obtain any registration of any of
the PPG Trademarks. Upon termination of this Agreement, DISTRIBUTOR shall forthwith cease all
further use of the PPG Trademarks and shall destroy all unused labels and advertisements containing
the PPG Trademarks. Thereafter, DISTRIBUTOR shall not use any PPG Trademarks or trade or corporate
names similar thereto.

10.2 DISTRIBUTOR acknowledges PPG SHANGHAI's exclusive right and interests in relation to the PPG
Trademarks and further acknowledges that all copyrights, patent, utility model rights and all other
industrial property rights of whatever kind used in or in connection with the Products are the sole
and exclusive property of PPG SHANGHAI or PPG and that DISTRIBUTOR will not, whether during the Term
of this appointment or after its expiry or termination, knowingly do or cause to be done any act or
thing directly or indirectly, contest or in any way impair or attempting to impair PPG SHANGHAI or
PPG's rights, titles or interests in the PPG Trademarks.

10.3 DISTRIBUTOR shall not apply for registration of the PPG Trademarks in the People's Republic of
China or in any other countries.

11. WARRANTY AND LIMITATION

11.1 PPG SHANGHAI warrants only its title to the Products and that the &bbsp; Products will be as
set forth in the warranty statement, if any, on the Products' labeling or in the absence of any such
warranty statement that the Products will conform to PPG SHANGHAI's standard warranty when they are
taken from PPG SHANGHAI's warehouse by DISTRIUTOR or its transport agent. DISTRIBUTOR is not
authorized to make warranties or representations on behalf of PPG SHANGHAI and shall make no such
warranties or representations. THESE ARE THE ONLY REPRESENTATIONS OR WARRANTIES THAT PPG SHANGHAI
MAKES, AND ALL OTHER EXPRESS OR IMPLIED WARRANTIES UNDER STATUTE OR ARISING OTHERWISE IN LAW FROM A
COURSE OF DEALING OR USAGE OF TRADE, INCLUDING, WITHOUT LIMITATION, ANY WARRANTY OF MERCHANTIBILITY,
FITNESS FOR A PARTICULAR PURPOSE OR USE, ARE DISCLAIMED BY PPG SHANGHAI. In the event that the
Product fails to conform to the warranties herein given, DISTRIBUTOR's exclusive remedy and PPG
SHANGHAI's sole responsibility is, at PPG SHANGHAI's option, limited to the replacement of such
nonconforming Product at PPG SHANGHAI's expense or the refund of the purchase price attributable to
a specific delivery as to which a claim is made. For the avoidance of doubt, PPG SHANGHAI hereby
declares and represents that PPG SHANGHAI is not responsible for any damage to the Products after
they have been taken away from PPG SHANGHAI's warehouse and caused by DISTRIBUTOR or its transport
agent.

11.2 It is PPG SHANGHAI's responsibility to ensure that mis-delivery of Product is kept to the
minimum. DISTRIBUTOR shall inspect the Products within 48 hours upon delivery. In case of
discrepancy found in Products
<!-- page 5 -->
delivered, DISTRIBUTOR shall report to PPG SHANGHAI in writing, detailing all the discrepancies
within 48 hours after delivery. PPG SHANGHAI will not accept any claims for discrepancy in delivery
beyond the 48 hours period. If Products are found damaged upon delivery, DISTRIBUTOR or its
customers who directly receive the delivery shall report to PPG SHANGHAI in writing within 48 hours.
The necessary and sufficient evidence (and photos) required for insurance claim must be submitted
altogether. None of the damaged Products shall be disposed of until the claim is settled by the
insurance company or PPG SHANGHAI.

11.3 DISTRIBUTOR assumes all responsibility, risk and liability arising from (i) the unloading,
discharge, storage, handling and use of the Products, including use thereof alone or in combination
with other substances; (ii) the improper functioning or failure of unloading, discharge,
transportation or storage systems equipment used by DISTRIBUTOR, whether furnished or recommended by
PPG SHANGHAI or not; and (iii) the failure to comply with laws, rules and regulations governing
unloading, discharge, storage, handling and use of the Products.

12. FORCE MAJEURE

PPG SHANGHAI's failure or inability to make, or DISTRIBUTOR's failure or inability to take, any
delivery or deliveries when due, or the failure or inability of either party to effect timely
performance of any other obligation required of it hereunder, if caused by "force majeure" as
hereinafter defined, shall not constitute a default hereunder or subject the party affected by force
majeure to any liability to the other; provided, however, that the party so affected shall promptly
notify the other of the existence thereof and of its expected duration and the estimated effect
thereof upon its ability to perform its obligations hereunder. Such party shall promptly notify the
other party when such force majeure circumstance has ceased to affect its ability to perform its
obligations hereunder. The quantity to be delivered hereunder shall be reduced to the extent of the
deliveries omitted for such cause or causes, unless both parties agree that the total quantity to be
delivered hereunder shall remain unchanged. For so long as its ability to perform hereunder is
affected by such force majeure circumstance, PPG SHANGHAI may, at its option, elect to allocate its
total production of Product among its various requirements therefor (e.g., manufacturing and sales)
in such manner as PPG SHANGHAI deems practicable and which, in the opinion of PPG SHANGHAI, is fair
and reasonable. During the time that PPG SHANGHAI is unable to make deliveries or otherwise perform,
it shall not be obligated to procure, or to use its best efforts to procure, any quantity of Product
sold hereunder from any alternate producer or supplier. As used herein, the term "force majeure"
shall mean and include any act of God, nature or the public enemy, accident, explosion, operation
malfunction or interruption, fire, storm, earthquake, flood, drought, perils of the sea, strikes,
lockouts, labor disputes, riots, sabotage, embargo, war (whether or not declared and whether or not
the United States of America is a participant), federal, state or municipal legal restriction or
limitation or compliance therewith, inability to obtain export licenses, failure or delay of
transportation, shortage of, or inability to obtain, raw materials, supplies, equipment, fuel,
power, labor, or other operational necessity, interruption, or curtailment of power supply, or any
other circumstance of a similar or different nature beyond the reasonable control of the party
affected thereby. In this connection, a party shall not be required to resolve labor disputes or
disputes with suppliers of raw materials, supplies, equipment, fuel or power, except in accordance
with such party's business judgment as to its best interest.

13. PRODUCT HANDLING

DISTRIBUTOR acknowledges that it has experience and expertise in handling and storing the Products,
and that DISTRIBUTOR has the obligation to handle, store and distribute the Products safely and
properly.

14. PRODUCT SAFETY

PPG SHANGHAI and DISTRIBUTOR recognize the importance of product safety considerations and the need
to protect persons and property against unsafe conditions that could occur from the improper use,
transportation, storage, handling, distribution or disposal of the Products sold hereunder. PPG
SHANGHAI and DISTRIBUTOR will follow PPG's Responsible Care(R) Distributor Guidelines as set forth
in the attached Appendix I (Responsible Care(R) is a registered trademark in the United States of
the American Chemistry Council ). Accordingly, PPG SHANGHAI will furnish certain information to
DISTRIBUTOR regarding product safety and handling aspects of the Products, and DISTRIBUTOR, in
addition to its independent responsibility to obtain and implement a product safety program
regarding the Products, will implement and conform to PPG SHANGHAI's product safety recommendations
and Responsible Care(R) Distributor Guidelines, DISTRIBUTOR will also provide its customers,
employees and other third parties foreseeably exposed to the Products with appropriate warnings,
advice and other material regarding the Products, including all product safety and handling material
provided by PPG SHANGHAI, and will ensure that the Products are used, stored, handled, distributed,
transported and disposed of in a manner consistent with all of the above recommendations.

15. PRODUCT DISCONTINUANCE

DISTRIBUTOR acknowledges that it has express notice that PPG or PPG SHANGHAI may at any time
discontinue the production and/or sale of any of the Products. If PPG or PPG SHANGHAI does
discontinue the production and/or sale of any of the Products, this Agreement shall automatically
terminate with respect to such discontinued Product, and DISTRIBUTOR shall not be entitled to claim
or receive
<!-- page 6 -->
from PPG or PPG SHANGHAI any compensation, reimbursement or damages of any nature as a result
(direct or indirect) of PPG or PPG SHANGHAI's discontinuance of the production and/or sale of the
affected Product.

16. LIMITATION OF DAMAGES

Notwithstanding the provisions of any law, rule, or regulation to the contrary, on the termination
of this Agreement for any cause whatsoever, DISTRIBUTOR shall not be entitled to claim or receive
from PPG SHANGHAI any compensation, reimbursement, or damages on account of any expenditure or
commitment of any kind in connection with its business or on account of goodwill or on account of
loss of prospective profits or otherwise. In no event shall PPG SHANGHAI be liable for consequential
damages.

17. BUSINESS CONDUCT

17.1 In the performance of its responsibilities pursuant to this Agreement, DISTRIBUTOR agrees to
make every effort to operate as a good, responsible and ethical corporate entity in the Territory
and will comply with the laws of the Territory, the applicable laws of the United States of America
and the countries of origin of the Products. DISTRIBUTOR further agrees that it will not, in
connection with this Agreement or its performance hereunder, directly or indirectly offer, pay,
promise to pay or authorize the payment of any money or thing of value to any employee of a customer
or to any government official or to any person,

(a) to improperly or unlawfully influence any act or decision of such customer employee or
governmental official, including a decision to fail to perform his/her official functions, or

(b) to induce such customer employee or government official to use his/her influence with the
customer or the government (or instrumentality thereof), respectively, to affect or influence any
act or decision of such customer or government (or instrumentality), in order to assist PPG SHANGHAI
or DISTRIBUTOR in obtaining or retaining business or directing business to any other party. As used
in this Section, the term "government official" means any officer or employee of any government or
any department, agency, instrumentality or wholly-owned corporation thereof, or any person acting in
an official capacity for or on behalf of any such government or department, agency, instrumentality
or wholly-owned corporation thereof, or any candidate for political office.

17.2 DISTRIBUTOR agrees to notify PPG SHANGHAI immediately of any solicitation, demand or other
request for anything of value, by or on behalf of any employee of a customer, government official or
employee of any government which is directed to itself or to PPG SHANGHAI related to the sale and/or
service of the Products.

17.3 DISTRIBUTOR agrees to require any sub-distributor or other person which it hires or engages to
assist in the performance of this Agreement to comply with the provisions of this Section 17.

18. TERM OF AGREEMENT

18.1 The term of this Agreement (the "Term") shall commence on the date first above written and
shall terminate on 31 December 2006, unless sooner terminated in accordance with the provisions
hereof.

18.2 The parties hereof intend to form a long-term relationship. To this end, if both parties wish
to renew this Agreement, the parties shall agree on such intention in writing at least thirty(30)
days before the expiry of the current Term of the Agreement. The parties shall agree on the terms
and conditions of the renewal, and enter into a new agreement within sixty(60) days from the expiry
of this Agreement. During this sixty(60) days period, both parties shall continue to perform their
respective obligation under the same terms and conditions of this Agreement.

18.3 In the event that there is no written notice issued by either party to show the intention to
renew this Agreement in the said thirty(30) days before the expiry of the current Term of the
Agreement, the Agreement shall terminate at the end of the said thirty(30) days. In the event that
such a notice of intention to renew is issued, but the parties are not able to enter into a new
agreement within that sixty(60) days from the expiry of this Agreement, this Agreement shall
terminate at the end of the said sixty(60) days.

19. DEFAULT AND TERMINATION

19.1 If either party be in default with respect to any of the terms or conditions of this Agreement,
including, without limitation, DISTRIBUTOR's failure to pay any invoice of PPG SHANGHAI in
accordance with its terms, and if it fails to correct such default or failure within ten (10)
business days following written notice thereof from the other, the party serving such notice may,
without prejudice to any other right or remedy, defer further performance hereunder until such
default be remedied or terminate this Agreement by written notice to the other, and the same shall
terminate immediately upon the giving of such notice.
<!-- page 7 -->
19.2 PPG SHANGHAI shall have the right to terminate this Agreement and/or suspend its performance
hereunder immediately upon giving notice to DISTRIBUTOR, which termination shall be effective upon
receipt of notice, if any one of the following occurs: (i) DISTRIBUTOR engages in fraudulent conduct
in its dealings with PPG SHANGHAI or the Products; (ii) DISTRIBUTOR, or any principal owner of
DISTRIBUTOR, is convicted of a crime which, in PPG SHANGHAI's reasonable judgment, may adversely
affect the goodwill or interest of DISTRIBUTOR or of PPG SHANGHAI; (iii) DISTRIBUTOR becomes
insolvent, assigns or attempts to assign its business assets for the benefit of creditors,
institutes or has instituted against it proceedings in bankruptcy, or dissolves or liquidates the
business of DISTRIBUTOR; or (iv) the business licence of DISTRIBUTOR is cancelled by the State
Administration of Industry and Commerce.

20. DISPUTE RESOLUTION

20.1 All disputes, controversies and claims arising from or incidental to this Agreement shall be
resolved by both parties through friendly consultation. If no resolution can be reached within
thirty (30) days following the date on which one party informed the other party his intention to
refer the disputes, controversies and claims for arbitration, such disputes, controversies and
claims shall be referred to the China International Economic and Trade Arbitration Committee
("Arbitration Committee") for a final and binding arbitration in pursuance to the arbitration rules
which is effective on the date hereof.

20.2 The venue of arbitration shall be in Shanghai or Beijing, China (to be decided by PPG
SHANGHAI).

20.3 The arbitration shall be conducted in English and Chinese.

20.4 There shall be three arbitrators. Each of PPG SHANGHAI and DISTRIBUTOR shall select one; the
chief arbitrator shall be selected by the first two arbitrators, provided that where the first two
arbitrators are not able to agree on the appointment of the chief arbitrator within ten (10) days of
the later of their appointments, the chief arbitrator shall be selected by the chairman of the
Arbitration Committee.

20.5 The chief arbitrator shall not be a PRC national or a national of the United States.

20.6 The arbitration award shall be final and binding on both parties. Each party agree to be bound
by the arbitration award. The arbitration fees and enforcement costs (including witness fees and
reasonable legal fees) shall be borne by the losing party unless provided otherwise in the
arbitration award.

20.7 During the occurrence of the dispute and the arbitration, other than the issues in dispute,
each party shall continuously exercise its undisturbed rights and discharge its undisturbed
obligations under this agreement.

21. GOVERNING LAW

The validity, construction, and performance of this Agreement shall be governed by and interpreted
in accordance with the laws of the People's Republic of China.

22. LANGUAGE AND COUNTERPART

This Agreement shall be executed in two (2) counterparts of the Chinese language text.

23. ENTIRE AGREEMENT

This writing, including all documents attached to and/or referenced herein, constitutes the entire
agreement between PPG SHANGHAI and DISTRIBUTOR regarding the subject matter hereof, terminating and
superseding any prior agreements relating to the subject matter hereof, and there are no
understandings, representations, or warranties of any kind except as expressly set forth herein. No
modification, amendment or change in this Agreement or addition hereto shall be effective or binding
on either of the parties hereto unless set forth in a writing which specifically references this
Agreement and is executed by the respective duly authorized representatives of PPG SHANGHAI and
DISTRIBUTOR and, if required, upon approval by competent governmental authorities, and no
modifications shall be effected by any DISTRIBUTOR purchase order forms or other documents
containing terms or conditions at variance with or in addition to those in this Agreement.

IN WITNESS WHEREOF, PPG SHANGHAI and DISTRIBUTOR have executed this Distributor Agreement effective
the day, month, and year first above written.

Witness: PPG Paints Trading (Shanghai) Co., Ltd.
<!-- page 8 -->
/s/ Ju dian By: /s/ Yuen Kit Yeg, Pauline ----------------------------
------------------------------ Name: Yuen Kit Yeg, Pauline ---------------------------- Title:
General Manager ---------------------------

Witness: [DISTRIBUTOR]

/s/ Paul Grzebielucha By /s/ Charles T. Jensen ----------------------------
------------------------------- Name: Charles T. Jensen ---------------------------- Title: CEO
---------------------------
