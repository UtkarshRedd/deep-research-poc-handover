<!-- page 1 -->
# PROMOTION AGREEMENT
| Field | Value |
|---|---|
| Document Type | Promotion Agreement |
| Agreement Date | 2015-09-10 |
| Parties | BookingEntertainment.com ("Promoter"); VNUE, Inc. ("VNUE") |
| Source | CUAD v1 / VnueInc_20150914_8-K_EX-10.1_9259571_EX-10.1_Promotion Agreement |

Exhibit 10.1 PROMOTION AGREEMENT This Promotion Agreement ("Agreement") is entered into effective
September 10, 2015 between BookingEntertainment.com ("Promoter") of 275 Madison Avenue, 6t h Floor,
New York, NY 10016 and VNUE, Inc., ("VNUE"), a Nevada corporation quoted on the OTCMarkets, with
offices at 104 West 29th Street 11th Floor, New York, NY 10001. WHEREAS, Promoter has substantial
business experience in the music industry, and since 1996 has built thousands of relationships with
artists, entertainment venues and other industry professionals, while delivering turn-key fully
produced live concerts worldwide for almost 20 years; and WHEREAS, VNUE believes Promoter can
provide valuable Promotion services related to rapidly securing contracts with multiple venues with
which Promoter has existing relationships. NOW, THEREFORE, in consideration of the representations,
covenants and agreements hereinafter set forth, and other good and valuable consideration, the
receipt and sufficiency of which are hereby acknowledged, VNUE and the Promoter agree as follows:
Independent Contractor. Nothing contained herein or any document executed in connection herewith,
shall be construed to create an employer-employee, partnership or joint venture relationship between
VNUE and Promoter. Promoter is an independent contractor and not an officer, director, affiliate,
insider, employee or agent of VNUE or any of its subsidiaries or affiliates. Promoter has no
authority to, and will not, enter into contracts, make representations, warranties or commitments
purporting to be binding on VNUE or otherwise act on VNUE's behalf and shall not take any action
that might lead third parties to believe Promoter has the right to do so. The consideration set
forth in Section 3 shall be the sole consideration due Promoter for the services rendered hereunder.
It is understood that VNUE will not withhold any amounts for payment of taxes from the compensation
of Promoter hereunder. Section 1. Promotion Services. Promoter to provide the following services to
VNUE in accordance with the terms and conditions set forth in this agreement: A. VNUE hereby engages
the Promoter as an Independent Contractor to secure contracts for VNUE with Thirty (30) music
venues. B. The Promoter will provide certain skills, expertise, experience and abilities developed
as global leader in the music and entertainment business over two decades. C. The Promoter will
consult and work with the Directors and Officers of VNUE concerning matters relating to business
development and other matters deemed necessary to perform the Promotion Services. Section 2.
Promoter's Fee. For providing services as set forth herein, VNUE will compensate Promoter i) Two
Thousand Five Hundred Dollars ($2,500.00) for each One (1) Year contract Promoter secures per venue
and Five Thousand Dollars ($5,000,00) for each Two (2) Year contract Promoter secures per venue,
with payment due to Promoter within Thirty (30) Days from the date on which each such contract is
countersigned; and ii) through the issuance of VNUE common stock as set forth below, and for the
purposes of Rule 144 such shares of stock shall be deemed to have fully earned by Promoter upon the
date of each issuance of such stock certificates by VStock Transfer: Three Million (3,000,000)
shares of VNUE common stock shall be awarded to Promoter for performing Promotion Services as
follows:

Source: VNUE, INC., 8-K, 9/14/2015
<!-- page 2 -->
For every Five (5) music venues that sign a contract with VNUE, Six Hundred Thousand (600,000)
shares of VNUE common stock shall be awarded to Promoter; and If Ten (10) music venues sign a
contract with VNUE before January 16, 2016, Promoter will receive an additional bonus of Three
Hundred Thousand (300,000) shares of VNUE common stock. Section 3. Expenses. VNUE shall reimburse
Promoter for expenses incurred by Promoter while performing the duties herein. Promoter shall
deliver to VNUE an itemized accounting of expenses incurred on a weekly basis, and VNUE shall
reimburse Promoter within Thirty (30) Days of receipt of such accounting. Section 4. Ability to
Perform Services/Third-Party Trade Secrets. Promoter affirms that Promoter is not restricted from
providing services in this Agreement due to any agreement with any other person or entity. Promoter
will not disclose to VNUE or use in its work any trade secrets, inventions or confidential
information of any other person or entity which Promoter is not lawfully entitled to disclose or
use. Section 5. Place of Work. Promoter may perform the Promotion Services at such locations as
Promoter may choose. Section 6. Term. This Agreement shall commence on September 10, 2015 and shall
continue for One (1) Year (the "Term"). At any time prior to the end of the Term, the Parties may
agree in writing to extend the Agreement for successive One (1) Year periods (the "Renewal Terms")
under the same conditions set forth herein. Section 7. Liability. The work to be performed under
this Agreement will be performed entirely at Promoter's risk, and Promoter assumes all
responsibility for the condition of equipment and facilities used in the performance of this
agreement. Promoter agrees to indemnify VNUE for any and all liability or loss arising in any way
out of the actions of Promoter taken in the performance of this Agreement. VNUE agrees to indemnify
and hold Promoter harmless for any and all liability or loss arising in any way out of the actions,
during the term of this Agreement, of VNUE officers, directors, employees, agents or third parties
not under the control of Promoter. Section 8. Competent Work. All work will be done in a competent
fashion in accordance with applicable standards of the profession. Promoter represents, warrants,
and covenants the following: A. Promoter will disclose to VNUE any and all material facts and
circumstances, which may affect its ability to perform its undertaking herein. B. Promoter is an
independent contractor acting in the limited capacity as an independent contractor for VNUE. C.
Promoter will not disseminate or share with third parties any material information about VNUE not
already contained in a Company report filed with the Securities and Exchange Commission, as Promoter
acknowledges that such third parties might try to act on such material non-public information by
engaging in "insider trading" to the detriment of VNUE.

Source: VNUE, INC., 8-K, 9/14/2015
<!-- page 3 -->
Section 9. Legal Right. Promoter covenants and warrants that Promoter has the unlimited legal right
to enter into this Agreement and to perform in accordance with its terms without violating the
rights of others or any applicable law and that he has not and shall not become a party to any other
agreement of any kind which conflicts with this Agreement. Promoter shall indemnify and hold VNUE
harmless from any and all damages, claims and expenses (including, but not limited to attorneys'
fees and costs) arising out of or resulting from any claim that this Agreement violates any such
other agreements. Breach of this Section shall operate to terminate this Agreement automatically
without notice otherwise required by this Agreement. Section 10. Notice. Any notice or communication
permitted or required by this Agreement shall be deemed effective when personally delivered, or sent
by certified or registered mail, properly addressed to VNUE or Promoter at the addresses set forth
above. Section 11. Enforceability. It is agreed between the parties that there are no other
agreements or understandings between them relating to the subject matter of this agreement. This
agreement supersedes all prior agreements, oral or written, between the parties and is intended as a
complete and exclusive statement of the agreement between the parties. If any provision in this
Agreement is held by a court of competent jurisdiction to be invalid, void or unenforceable, the
remaining provisions will continue in full force without being impaired or invalidated in any way.
Section 12. Non-exclusion. It is understood that VNUE does not agree to use BookingEntertainment.com
exclusively as its Promoter, and that Promoter shall not be held liable for the actions of third
parties which may also be providing the same or similar services during the term of this Agreement.
Likewise, Promoter is free to contract for services to be performed for other public and private
companies while under contract with VNUE, subject to the terms of this Agreement. Section 13.
Miscellaneous. This Agreement shall inure to the benefit of the parties hereto and their respective
successors, heirs and assigns. In case any provision of this Agreement shall be invalid, illegal or
unenforceable, the validity, legality and enforceability of the remaining provisions of the
Agreement shall not in any way be affected or impaired thereby. This Agreement shall be governed by
and construed in accordance with the laws of the State of Nevada without giving effect to choice of
law doctrine. The party in violation of any of the provision agrees to pay to the injured party all
court fees, attorney fees, charges and expenses as are deemed fair by the court. Each party hereto
consents to personal jurisdiction in Nevada and voluntarily submits to its jurisdiction in any
action or proceeding with respect to this Agreement. Venue for any action arising hereunder shall
lie in the state and federal courts located Nevada. Section 14. Review by Counsel. Promoter
acknowledges that Promoter has had the opportunity to have this Agreement reviewed by legal counsel
of Promoter's choice. Section 15. Execution. This Agreement may be executed via facsimile and in
counterparts, which together shall constitute the single Agreement. Section 16. SEC Reporting and
Press Release. Promoter acknowledges that VNUE is an SEC reporting public company and that a Form
8-K will be filed announcing the Promotion Agreement, which shall include a copy of this Agreement,
and that a Press Release summarizing the Agreement and Promoter's background may be issued as well.
Promoter agrees to make no additional public statements or press releases related to VNUE or to this
Agreement without VNUE's prior written consent. WHEREFORE, the parties have executed this Promotion
Agreement as of the date written above. VNUE, INC. BOOKINGENTERTAINMENT.COM By: /s/ By: /s/ Matthew
Carona, CEO Steve Einzig, President

Source: VNUE, INC., 8-K, 9/14/2015
