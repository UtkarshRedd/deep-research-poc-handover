# When does the Distributor Agreement between COMWARE TECHNICAL SERVICES and INTERNATIONA...

*Question:* When does the Distributor Agreement between COMWARE TECHNICAL SERVICES and INTERNATIONAL TEST SYSTEMS, INC. (filed 2000-07-26) expire, according to its term clause?

> **Partial report.** Research or writing ended before completion; see the gaps and the appendix.

## Identify the term clause

The term clause is found in Section 2, Definitions, which defines the Initial Distribution Period as April 15, 2000 through October 15, 2000 (6 Months from the Effective Date). [ce581d56506a6a52 p.1] The Effective Date is defined as the earlier of the date Comware orders and pays for a minimum of $22,710 worth of Products, in any combination, or April 15, 2000. [ce581d56506a6a52 p.1] The agreement was filed on 2000-07-26, which is after the Effective Date of April 15, 2000. [ce581d56506a6a52 p.1]

[GAP] The evidence does not state the expiration date of the Distributor Agreement beyond the Initial Distribution Period.

## Not established by the evidence

[GAP] No evidence was found for: Establish that the document filed on 2000-07-26 between COMWARE TECHNICAL SERVICES and INTERNATIONAL TEST SYSTEMS, INC. is the Distributor Agreement in question.

## Verification appendix

Claims: 5 · supported: 3 · partially: 0 · dropped: 0 · gaps: 2 · tier-1 support rate: 1.00

Notes: 1 empty section(s) collapsed into gaps: Locate the Distributor Agreement

| claim | section | tier 1 | score | tier 2 | clusters | sources | note |
|---|---|---|---|---|---|---|---|
| s2.1 | s2 | keep | 1.00 | skipped | 1 | e1→[ce581d56506a6a52 p.1] |  |
| s2.2 | s2 | keep | 1.00 | skipped | 1 | e1→[ce581d56506a6a52 p.1] |  |
| s2.3 | s2 | keep | 1.00 | skipped | 1 | e1→[ce581d56506a6a52 p.1] |  |
| s2.4 | s2 | gap |  | skipped |  |  |  |
| gaps.1 | gaps | gap |  | skipped |  |  |  |

### Evidence

- e1 [ce581d56506a6a52 p.1 L23-36] keep (1.0): "2. DEFINITIONS:

INITIAL DISTRIBUTION PERIOD: April 15, 2000 through October 15, 2000 (6 Months from the Effective Date)

PRODUCTS: The CircuiTest 2000S In-Circuit Test System

The CircuiTest 2100 Scanner Expansion

EXCLUSIVE TERRITORIES: T…"
