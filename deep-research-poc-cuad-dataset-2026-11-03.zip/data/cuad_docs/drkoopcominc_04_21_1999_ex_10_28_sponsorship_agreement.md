<!-- page 1 -->
# SPONSORSHIP AGREEMENT
| Field | Value |
|---|---|
| Document Type | Sponsorship Agreement |
| Agreement Date | 1999-03-11 |
| Parties | drkoop.com, inc."drkoop.com"; Vitamin Shoppe Industries, Inc. "Sponsor" |
| Source | CUAD v1 / DRKOOPCOMINC_04_21_1999-EX-10.28-SPONSORSHIP AGREEMENT |

EXHIBIT 10.28

SPONSORSHIP AGREEMENT

This Sponsorship Agreement (the "Agreement") is entered into as of the 11th day of March, 1999 by
and between drkoop.com, inc., a Delaware corporation, located at 8920 Business Park Drive, Longhorn
Suite, Austin, Texas 78759 ("drkoop.com"), and Vitamin Shoppe Industries, Inc., a New Jersey
corporation, located at 4700 Westside Avenue, North Bergen, New Jersey 07047 ("Sponsor").

WHEREAS, drkoop.com develops, markets and maintains an integrated suite of Internet enabled,
consumer oriented software applications and services, including but not limited to, drkoop.com.
electronic data interchange services, and advertising and promotional services on the Internet at
the website http://www.drkoop.com (together with any successor or replacement websites, the
"drkoop.com Website");

WHEREAS, Sponsor markets and sells vitamins and nutritional supplements on the Internet at the
website http://www.vitaminshoppe.com (together with any successor or replacement websites, the
"Sponsor Website"; and together with the drkoop.com Website, the "Sites"); and

WHEREAS, Sponsor desires to have certain * * * rights with respect to vitamins and nutritional
supplements on the drkoop.com Website and to be the * * * vitamin and nutritional supplement tenant
in the E-Commerce area of the drkoop.com Website and drkoop.com desires to promote Sponsor for
vitamin and nutritional supplements and to make Sponsor its' * * * vitamin and nutritional
supplement tenant pursuant to the terms and conditions contained in this Agreement.

NOW, THEREFORE, in consideration of the mutual covenants and promises contained herein and for other
good and valuable consideration the receipt and adequacy of which are hereby acknowledged, the
parties hereto agree as follows:

____________________ Confidential treatment has been requested for portions of this exhibit. The
copy filed herewith omits the information subject to the confidentiality request. Omissions are
designated as * * *. A complete version of this exhibit has been filed separately with the
Securities and Exchange Commission.

* * * Certain information on this page has been omitted and filed separately with the Securities and
Exchange Commission. Confidential treatment has been requested with respect to the omitted portions.

ARTICLE I. * * * VITAMIN SPONSOR

1.1. * * * VITAMIN SPONSOR. Throughout the Term (as defined below), Sponsor shall be the * * *
vitamin and supplement sponsor of, and the * * * vitamin and supplement advertiser on, the
drkoop.com Website * * *

1.2. SPONSOR PLACEMENTS. During the Term, in no way limiting the foregoing in Section 1.1, Sponsor
will receive the following sponsorship and promotional placements on the drkoop.com Website:

(i) Sponsor shall be the * * * sponsor of the Nutrition Center on the drkoop.com Website and each
area (other than the "Daily Special" area, the "Healthy Recipes" area and any other area which may
be created in the future which specifically relates to cooking or food recipes (collectively, the
"Excluded Areas")) within the Nutrition Center, including, the "Vitamins & Supplements" area, the
"Vitamins and Minerals" area, the "Nutrition News" area, the "Nutrition for Healthy Living" area and
the "Nutrition for your Condition" area (collectively, the "Sponsor Areas"). * * *

(ii) * * *

(iii) From time to time, drkoop.com shall create content which features vitamins and nutritional
supplements. Sponsor's Advertising Content shall be displayed on such pages which host vitamins and
nutritional supplement content to the same extent and subject to the same restrictions as such
Sponsor Advertising Content is displayed in the Sponsor Areas.

(iv) * * * Drkoop.com's obligations with respect to each area of the drkoop.com Website set forth in
this Section 1.2 shall also apply to all areas which are successors or replacements to such areas
and to all new vitamin and nutrition areas on the drkoop.com Website launched on the drkoop.com
Website after the date of this Agreement. * * * Sponsor may promote the sale of vitamins and
supplements in the Sponsor Areas.

1.3. IMPRESSIONS. Not including any permanent Sponsor links, banners or buttons pursuant to Section
1.2, drkoop.com shall, during the Initial Term (as defined below) provide * * * advertising banner
and e-commerce tile impressions consisting of Sponsor Advertising Content* * * shall be delivered
during each month of the Initial Term. If by the end of the Initial Term drkoop.com has not
delivered the foregoing number of impressions, then, as Sponsor's sole remedy for such breach, the
Term of this Agreement shall be extended until drkoop.com has satisfied its obligations under this
Section.

____________________

* * * Certain information on this page has been omitted and filed separately with the Securities and
Exchange Commission. Confidential treatment has been requested with respect to the omitted portions.

2
<!-- page 2 -->
1.4. DR. KOOP HEALTH LINKS. In addition to the fees specified in Section 2.5.1, Sponsor shall pay *
* * to drkoop.com and in exchange therefore shall have the right to use as many Dr. Koop Health
Links as Sponsor, in its sole discretion, wishes to use, all in accordance with the terms of the
drkoop.com Healthlinks Agreement, the form of which is attached hereto as Exhibit B. - ---------

1.5. * * *

1.6. MODIFICATIONS.. Each party reserves the right to modify the design, organization, structure,
look and feel, navigation and other elements of its Site, provided, that drkoop.com may not, without
the prior written consent of Sponsor, substantially alter, change or modify the look, feel or
functionality of the Sponsor Areas of the drkoop.com Website* * *.

ARTICLE II. SPONSORSHIP POLICY

2.1. CONTENT. For each of the placements described in Section 1, including all banner advertisements
and e-commerce tiles, Sponsor shall provide drkoop.com with all content including all trademarks,
logos or banners (the "Sponsor Advertising Content"), in accordance with the specifications set
forth on Exhibit C attached hereto, which will be displayed on the drkoop.com Website and which will
link, in Sponsor's discretion, to either the Sponsor Site or Vitamin Buzz. The parties hereto agree
to cooperate and work together in the establishment of all links, buttons and banners placed
pursuant to this Agreement. Links from one party's Site to the other party's Site shall in no way
alter the look, feel or functionality of the linked Site.

2.2. CHANGES AND CANCELLATIONS. Any cancellations or change orders must be made in writing and
acknowledged by drkoop.com. Sponsor shall not be required to change Sponsor Advertising Content more
often than once per month. Sponsor shall provide drkoop.com with Sponsor Advertising Content artwork
at least five business days in advance of the publication date.

2.3. STATISTICS. Drkoop.com shall provide Sponsor with Sponsor usage reports on a monthly basis.
Sponsor shall have the right to use such data for its internal business purposes, but may not
provide such data for use by third parties. Such reports shall contain substantially the same types
of information delivered to other of drkoop.com's similarly situated partners, which reports will
include information regarding impressions, clickthroughs and any information known about the users
of such areas in aggregate form.

2.4. PUBLICATION ERROR. In the event of a publication error in the Sponsor Advertising Content
arising exclusively from the fault of drkoop.com, Sponsor shall notify drkoop.com of such error and
drkoop.com will use reasonable efforts to promptly correct the error. _____________________________
* * * Certain information on this page has been omitted and filed separately with the Securities and
Exchange Commission. Confidential treatment has been requested with respect to the omitted portions.

3

2.5. PAYMENT.

2.5.1. FEES. The fee for the placements and other rights provided under this Agreement for the
Initial Term (as defined below) is * * * is payable within * * * of the date of this Agreement, with
the balance of such fee payable by Sponsor in * * * consecutive equal installments of * * * payable
by the * * * of the Initial Term commencing * * * following * * * the Launch Date (as defined
below).

2.5.2. TAXES. Sponsor shall be responsible for the collection of any and all value added,
consumption, sales, use or similar taxes and fees payable with respect to all sales made on the
Sponsor Website.

ARTICLE III. OWNERSHIP OF DATA

3.1. USER DATA. Drkoop.com requests its users ("Individual Users"), to provide personal information
when they sign up for certain services including requesting information on a specific disease, chat
rooms and forums ("User Data"). Such User Data is owned by each Individual User and drkoop.com does
not use or disclose any such User Data without the consent of the Individual User.

3.2. DATA RELEASE TO SPONSOR. Drkoop.com shall provide to Sponsor any and all User Data for which
the Individual User has specifically authorized release to Sponsor. In the event that an Individual
User grants rights to Sponsor for use of his User Data, Sponsor shall use its best efforts to keep
User Data confidential and shall only use such data in an ethical manner. Sponsor may use User Data
for its owns purposes, but User Data may not be disclosed, sold, assigned, leased or otherwise
disposed of to third parties by Sponsor.

3.3. DATA CONFIDENTIALITY. The User Data shall be drkoop.com Confidential Information under Article
5 and shall in addition be subject to the
<!-- page 3 -->
terms of this Article 3. Sponsor shall be liable for the conduct of its employees, agents and
representatives who in any way breach this Amendment. Sponsor's obligations to treat the User Data
as Confidential Information under Article 5 and this Article 3 shall continue in perpetuity
following termination of this Amendment.

3.4. SPONSOR USER DATA. All users on the Sponsor Website, including, users linked to the Sponsor
Website from the drkoop.com Website, will be deemed to be customers of Sponsor. Accordingly, all
rules, policies and operating procedures of Sponsor concerning customer orders, customer service and
sales will apply to those customers. Sponsor may change its policies and operating procedures at any
time. Sponsor will determine the prices to be charged for products and other merchandise sold on the
Sponsor Website in accordance with its own pricing policies.

____________________ * * * Certain information on this page has been omitted and filed separately
with the Securities and Exchange Commission. Confidential treatment has been requested with respect
to the omitted portions.

4

Prices and availability on the Sponsor Website may vary from time to time. Notwithstanding Section
3.3, the parties hereto hereby agree that title to any user information of any users on the Sponsor
Website, including but not limited to the name, address and e-mail address of users, obtained by
Sponsor from such users shall be owned by the Sponsor. The parties hereto agree that pursuant to
this Section 3 they may each collect and own similar information from and with respect to
individuals who visit each of their Sites.

ARTICLE IV. LICENSES

4.1. LICENSES.

4.1.1. Subject to the terms and conditions hereof, Sponsor hereby represents and warrants that it
has the power and authority to grant, and does hereby grant to drkoop.com a non-exclusive,
non-transferable, royalty-free, worldwide license to reproduce and display all logos, trademarks,
trade names and similar identifying material relating to Sponsor (the "Sponsor Marks") solely in
connection with the promotion, marketing and distribution of the parties and the Sites in accordance
with the terms hereof, provided, however, that drkoop.com shall, other than as specifically provided
for in this Agreement, not make any specific use of any Sponsor Mark without first submitting a
sample of such use to Sponsor and obtaining its prior consent, which consent shall not be
unreasonably withheld. The foregoing license shall terminate upon the effective date of the
expiration or termination of this Agreement.

4.1.2. Subject to the terms and conditions hereof, drkoop.com hereby represents that it has the
power and authority to grant, and does hereby grant to Sponsor a non-exclusive, non-transferable,
royalty-free, worldwide license to reproduce and display all logos, trademarks, trade names and
similar identifying material relating to drkoop.com and, solely as allowed pursuant to this
Agreement, to the Dr. C. Everett Koop name (collectively, the "drkoop.com Marks") solely in
connection with the promotion, marketing and distribution of the parties and the Sites in accordance
with the terms hereof, provided, however, that Sponsor shall, other than as specifically provided
for in Section 4.4 of this Agreement, not make any specific use of any drkoop.com Marks without
first submitting a sample of such use to drkoop.com and obtaining its prior consent, which consent
shall not be unreasonably withheld. The foregoing license shall terminate upon the effective date of
the expiration or termination of this Agreement.

4.2. INTELLECTUAL PROPERTY OWNERSHIP. Each party shall retain all right, title, and interest
(including all copyrights, patents, service marks, trademarks and other intellectual property
rights) in its Site. Except for the license granted pursuant to this Agreement, neither party shall
acquire any interest in the other party's Site or any other services or materials, or any copies or
portions thereof, provided by such party pursuant to this Agreement.

4.3. REMOVAL OF MATERIALS. Each party reserves the right to reject or remove any content,
information, data, logos, trademarks and other materials (collectively, "Materials") provided by the
other from its servers at any time if, in its reasonable opinion, it believes that any such
Materials infringe any third-party intellectual property right, are libelous or invade the privacy
or violate other rights of any person, violate applicable laws or regulations, or jeopardize

5

the health or safety of any person. Each party will use reasonable efforts to contact the other
prior to removing any of its Materials from its servers and will work with the other to resolve the
issue as quickly as possible.

4.4. USE OF NAME AND LIKENESS. Sponsor shall not have any right to use the name and/or likeness of
Dr. C. Everett Koop or to make any statements, whether written or oral, which state or otherwise
imply, directly or indirectly, any endorsement from or affiliation with Dr. C. Everett Koop in any
manner whatsoever without the prior written consent of drkoop.com, which consent may be withheld in
drkoop.com's sole discretion. Notwithstanding the foregoing, Sponsor is hereby authorized during the
Term to use the logo and tag lines set forth on Exhibit D, on its Site, in its catalogs and in its
stores in connection with its marketing and promotion efforts, in each case in accordance with the
terms of
<!-- page 4 -->
this Agreement and subject to the reasonable approval of drkoop.com. Sponsor is hereby authorized to
place such logo and any one of such tag lines on its Site, in its stores and in its catalogs in
accordance with the terms of this Agreement.

ARTICLE V. CONFIDENTIALITY

5.1. CONFIDENTIALITY. For the purposes of this Agreement, "Confidential Information" means
non-public information about the disclosing party's business or activities that is proprietary and
confidential, which shall include, without limitation, all business, financial, technical and other
information of a party marked or designated "confidential" or by its nature or the circumstances
surrounding its disclosure should reasonably be regarded as confidential. Confidential Information
includes not only written or other tangible information, but also information transferred orally,
visually, electronically or by any other means. Confidential Information will not include
information that (i) is in or enters the public domain without breach of this Agreement, (ii) the
receiving party lawfully receives from a third party without restriction on disclosure and without
breach of a nondisclosure obligation or (iii) the receiving party knew prior to receiving such
information from the disclosing party or develops independently.

5.2. EXCLUSIONS. Each party agrees (i) that it will not disclose to any third party or use any
Confidential Information disclosed to it by the other except as expressly permitted in this
Agreement and (ii) that it will take all reasonable measures to maintain the confidentiality of all
Confidential Information of the other party in its possession or control, which will in no event be
less than the measures it uses to maintain the confidentiality of its own information of similar
importance.

5.3. EXCEPTIONS. Notwithstanding the foregoing, each party may disclose Confidential Information (i)
to the extent required by a court of competent jurisdiction or other governmental authority or
otherwise as required by law, provided, however, that with respect to filing obligations under the
securities laws, each party will, to the extent that it is required to file this Agreement, file
this Agreement in redacted form reasonably approved by the other party prior to such filing or (ii)
on a "need-to-know" basis under an obligation of confidentiality to its legal counsel, accountants,
banks and other financing sources and their advisors. Except as set forth in

6

this Section 5.3, the terms and conditions of the Agreement will be deemed to be the Confidential
Information of each party and will not be disclosed without the prior written consent of the other
party.

5.4. SPONSOR ADVERTISING CONTENT. drkoop.com hereby confirms and agrees that during the Term Sponsor
shall be able to serve up its own advertising using NetGravity software and tags, and that
drkoop.com shall not do anything which would interfere or hamper such serving. Notwithstanding
anything in this Agreement, all information regarding Sponsor Advertising Content (including Sponsor
banner advertisements and e-commerce tiles), including all users viewing and clicking information
with respect thereto, shall be deemed to be Confidential Information of Sponsor (collectively,
"Sponsor Confidential Advertising Information"). To the extent that in connection with drkoop.com's
advertising efforts, or otherwise, any third party may or will receive any Sponsor Confidential
Advertising Information from or through drkoop.com, drkoop.com agrees that prior to such third party
receiving any such information drkoop.com will enter into an agreement with such third party
pursuant to which such third party will agree to keep any such Sponsor Confidential Advertising
Information received by such third party confidential to the same extent as drkoop.com is required
to keep such information confidential under the Agreement. To the extent that any third party
breaches any such agreement of confidentiality with drkoop.com, drkoop.com hereby agrees to enforce
its rights and pursue its remedies under such agreement to the fullest extent permitted by law,
including seeking equitable relief, * * *.

ARTICLE VI. REPRESENTATIONS AND WARRANTIES; INDEMNIFICATION

6.1. SPONSOR WARRANTY. Sponsor represents and warrants for the benefit of drkoop.com that the
Sponsor Advertising Content and Sponsor Marks are true and correct and do not and will not for the
Term infringe upon or violate: (i) any intellectual property rights, including any copyright or
trademark rights, of any third party and do not and will not constitute a defamation or invasion of
the rights of privacy or publicity of any kind of any third party, (ii) any applicable law,
regulation or non-proprietary third-party right. Sponsor further represents and warrants for the
benefit of drkoop.com that the Sponsor Advertising Content does not contain any material which is
unlawful, harmful, abusive, hateful, obscene, threatening or defamatory and Sponsor is not an entity
or an affiliate of any entity which engages in the manufacture or wholesale distribution of tobacco
or tobacco products (such activities are collectively referred to herein as "Tobacco Industry
Affiliation").

6.2. DRKOOP.COM WARRANTY. Drkoop.com represents and warrants for the benefit of Sponsor that the
drkoop.com Marks are true and correct and do not and will not for the Term infringe upon or violate:
(i) any intellectual property rights, including any copyright or

____________________ * * * Certain information on this page has been omitted and filed separately
with the Securities and Exchange Commission. Confidential treatment has been requested with respect
to the omitted portions.

7
<!-- page 5 -->
trademark rights, of any third party and do not and will not constitute a defamation or invasion of
the rights of privacy or publicity of any kind of any third party, (ii) any applicable law,
regulation or non-proprietary third-party right. Drkoop.com further represents and warrants for the
benefit of Sponsor that the drkoop.com Marks do not contain any material which is unlawful, harmful,
abusive, hateful, obscene, threatening or defamatory, and drkoop.com has the right to license the
drkoop.com Marks, including the Dr. C. Everett Koop name (to the extent licensed under this
Agreement), in accordance with the terms of this Agreement.

6.3. INDEMNIFICATION. Each party hereby agrees to indemnify and hold harmless the other party and
its subsidiaries and affiliates, and their respective directors, officers, employees, agents,
shareholders, partners, members and other owners, against any and all claims, actions, demands,
liabilities, losses, damages, judgments, settlements, costs and expenses (including reasonable
attorneys' fees) (any or all of the foregoing hereinafter referred to as "Losses") insofar as such
Losses (or actions in respect thereof) arise out of or are based on (i) the breach of any
representation or warranty set forth in Articles 4, 5 or 6, (ii) any breach by it of the licenses
granted by it hereunder; (iii) the use by it of any trademarks or Content other than in accordance
with the terms hereof; * * *. For purposes herein, "Content" shall mean, with respect to each party,
the proprietary content delivered by such party to the other party pursuant to this Agreement,
including, Sponsor Advertising Content, but only to the extent that such content is not altered by
the receiving party, and the proprietary content contained on such party's Site, and shall include
only that content created by such party, its employees or other persons contractually bound to such
party to create such content. The foregoing obligations are contingent upon the indemnified party:
(i) promptly notifying the indemnifying party of any claim, suit, or proceeding for which indemnity
is claimed; (ii) cooperating reasonably with the indemnifying party at the latter's expense; and
(iii) allowing the indemnifying party to control the defense or settlement thereof. The indemnified
party will have the right to participate in any defense of a claim and/or to be represented by
counsel of its own choosing at its own expense.

ARTICLE VII. LIMITATION OF LIABILITY

7.1. WARRANTY. Drkoop.com will use commercially reasonable efforts to maintain the drkoop.com
Website available and display the Sponsor Advertising Content twenty four hours per day each day
during the term of the Agreement. Drkoop.com shall install and maintain a commercially acceptable
system of collecting information about impressions and other data relating to the use of the Sponsor
Advertising Content. Drkoop.com warrants to Sponsor that it will make reasonable effort to perform
under this agreement in a competent manner. * * *

7.2. DISCLAIMER. Each party will be solely responsible for the development, operation and
maintenance of its Site and for all materials that appear on its Site. Such

____________________ * * * Certain information on this page has been omitted and filed separately
with the Securities and Exchange Commission. Confidential treatment has been requested with respect
to the omitted portions.

8

responsibilities include, but are not limited to: (i) the technical operation of its Site and all
related equipment; (ii) the accuracy and appropriateness of materials posted on its Site; (iii) for
ensuring that materials posted on its Site do not violate any law, rule or regulation, including all
FDA requirements, or infringe upon the rights of any third party (including, for example, copyright,
trademarks, privacy or other personal or proprietary rights); and (iv) for ensuring that materials
posted on its Site are not libelous or otherwise illegal. Each party disclaims all liability for all
such matters with respect to the other party's Site. Except for the foregoing, or as otherwise
specifically set forth in this Agreement, neither party makes any representations, warranties or
guarantees of any kind, either express or implied (including, without limitation, any warranties of
merchantability or fitness for a particular purpose), with respect to their respective Sites, or the
functionality, performance or results of use thereof, or otherwise in connection with this
Agreement.

7.3. EXCLUSION OF WARRANTY. EXCEPT AS EXPRESSLY SET FORTH IN THIS AGREEMENT, NEITHER PARTY MAKES ANY
WARRANTY TO THE OTHER PARTY IN CONNECTION WITH THE SUBJECT MATTER OF THIS AGREEMENT AND EACH PARTY
HEREBY DISCLAIMS ANY AND ALL WARRANTIES WITH REGARD TO ITS SITE AND SERVICES, EXPRESS OR IMPLIED,
INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF NONINFRINGEMENT AND THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. IN PARTICULAR, AND NOT BY WAY OF LIMITATION,
NEITHER PARTY WARRANTS THAT ITS SITE WILL OPERATE ERROR-FREE OR WITHOUT INTERRUPTION.

7.4. DAMAGES. EXCEPT AS SET FORTH IN SECTION 6.3, IN NO EVENT SHALL EITHER PARTY BE LIABLE TO THE
OTHER FOR ANY SPECIAL, INCIDENTAL, CONSEQUENTIAL OR PUNITIVE DAMAGES ARISING OUT OF THIS AGREEMENT
OR ITS TERMINATION, WHETHER LIABILITY IS ASSERTED IN CONTRACT, TORT (INCLUDING NEGLIGENCE) STRICT
LIABILITY OR OTHERWISE AND IRRESPECTIVE OF WHETHER SUCH PARTY HAS BEEN ADVISED OF THE POSSIBILITY OF
ANY SUCH LOSS OR DAMAGE. * * *

ARTICLE VIII. TERM AND TERMINATION
<!-- page 6 -->
8.1. TERM; TERMINATION.

8.1.1. The initial term (the "Initial Term"; and together with all extensions and renewals, the
"Term") will begin on the date set forth above * * * (the "Launch Date") on which: (i) each of the
Sponsor Areas of the drkoop.com Website are operational in accordance with the terms of this
Agreement (other than the e-commerce tile placements); and (ii) the links to the

____________________ * * * Certain information on this page has been omitted and filed separately
with the Securities and Exchange Commission. Confidential treatment has been requested with respect
to the omitted portions.

9

Sponsor Website or Vitamin Buzz contained in the Sponsor logos or the Sponsor banner advertisements
are established in accordance with the terms of this Agreement, subject to earlier termination as
set forth in this Agreement. If the Launch Date has not occurred by August 31, 1999, Sponsor shall,
in its sole discretion, be entitled to terminate this Agreement without any liability and receive a
full refund of all amounts paid by Sponsor to drkoop.com pursuant to this Agreement prior to the
date of such termination.

* * *

8.2. TERMINATION FOR TOBACCO INDUSTRY AFFILIATION. Upon commencing any activities relating to
Tobacco Industry Affiliation (as defined in Section 6.1), Sponsor shall promptly notify drkoop.com
of its intent to undertake Tobacco Industry Affiliation. Upon receipt of such notice or upon
learning of any such Tobacco Industry Affiliation from a third party, drkoop.com shall have the
right to terminate this Agreement immediately on written notice to Sponsor without liability of any
kind.

8.3. TERMINATION FOR GARNISHMENT. * * * Additionally, in the event that either party undertakes any
action or fails to undertake any action, which the other party reasonably believes tarnishes the
high quality of its name or trademarks, including, with respect to drkoop.com, the "Dr. Koop" name,
the other party shall have the right to terminate this agreement upon ten (10) days' written notice
to the other party, provided that such action or inaction is not cured to the reasonable
satisfaction of the terminating party within such ten day period.

8.4. TERMINATION FOR CAUSE. Either party may terminate this Agreement upon thirty (30) days' written
notice of a breach by the other party, provided such breach is not cured within such thirty-day
period.

8.5. TERMINATION BY INSOLVENCY. Either party may terminate this Agreement by providing written
notice to the other party if the other party ceases to function as a going concern, becomes
insolvent, makes an assignment for the benefit of creditors, files a petition in bankruptcy, permits
a petition in bankruptcy to be filed against it, or admits in writing its inability to pay its debts
as they mature, or if a receiver is appointed for a substantial part of its assets.

8.6. SURVIVAL. The following Sections shall survive termination of this Agreement: Article 5
(Confidentiality), Article 6 (Representations, Warranties and Indemnification), Article 7
(Limitation of Liability), and Article 9 (General).

____________________ * * * Certain information on this page has been omitted and filed separately
with the Securities and Exchange Commission. Confidential treatment has been requested with respect
to the omitted portions.

10

ARTICLE IX. GENERAL

9.1. PUBLICITY. Except as may be required by applicable laws and regulations or a court of competent
jurisdiction, or as required to meet credit and financing arrangements, or as required or
appropriate in the reasonable judgment of either party to satisfy the disclosure requirements of an
applicable securities law or regulation or any applicable accounting standard, neither party shall
make any public release respecting this Agreement and the terms hereof without the prior consent of
the other party.

9.2. ARBITRATION. Any and all disputes, controversies and claims arising out of or relating to this
Agreement or concerning the respective rights or obligations of the parties hereto shall be settled
and determined by arbitration in the defending parties home forum before one (1) arbitrator pursuant
to the Commercial Rules then in effect of the American Arbitration Association. Each party shall
have no longer than three (3) days to present its position. Judgment upon the award rendered may be
entered in any court having jurisdiction or application may be made to such court for a judicial
acceptance of the award and an order of enforcement. The parties agree that the arbitrators shall
have the power to award damages, injunctive relief and reasonable attorneys' fees and expenses to
any party in such arbitration.

9.3. ASSIGNMENT. Neither party may assign this Agreement, in whole or in part, without the other
party's written consent, which consent will not be unreasonably withheld, except that: (a) a party's
rights and obligation hereunder may be transferred to a successor of all or substantially all of the
<!-- page 7 -->
business and assets of the party regardless of how the transaction or series of related transactions
is structured, provided, that the successor party agrees to be bound by all of the terms and
conditions of this Agreement; and (b) Sponsor may assign its rights and obligations under this
Agreement to any entity (i) which operates the Sponsor Website and (ii) which agrees to bound by all
of the terms and conditions of this Agreement.

9.4. GOVERNING LAW. This Agreement shall be construed and enforced in accordance with the laws of
the State of Delaware, but without giving effect to its laws or rules relating to conflicts of laws.

9.5. NOTICE. All notices, statements and reports required or permitted by this Agreement shall be in
writing and deemed to have been effectively given and received: (i) five (5) business days after the
date of mailing if sent by registered or certified U.S. mail, postage prepaid, with return receipt
requested; (ii) when transmitted if sent by facsimile, provided a confirmation of transmission is
produced by the sending machine and a copy of such facsimile is promptly sent by another means
specified in this section; or (iii) when delivered if delivered personally or sent by express
courier service. Notices shall be addressed as follows:

11

For drkoop.com: For Sponsor:

drkoop.com. Vitamin Shoppe Industries, Inc. Personal Medical Records, Inc. 4700 Westside Avenue 8920
Business Park Drive North Bergen, New Jersey 07047 Austin, TX 78759 Attn: Ms. Miriam Nesheiwat Attn:
Chief Financial Officer Fax: 201-583-1834 Fax: 512-726-5130 Email: mnesh@vitaminshoppe.com Email:
gsears@drkoop.com

With a copy to: H. Leigh Feldman Robinson Silverman Pearce Aronsohn & Berman LLP 1290 Avenue of the
Americas 32nd Floor New York, NY 10104 Fax: 212-541-1492 Email: feldman@rspab.com

Either party may change its address for the purpose of this paragraph by notice given pursuant to
this paragraph

9.6. NO AGENCY. The parties are independent contractors and will have no power or authority to
assume or create any obligation or responsibility on behalf of each other. This Agreement will not
be construed to create or imply any partnership, agency or joint venture.

9.7. SEVERABILITY. In the event that any of the provisions of this Agreement are held to be
unenforceable by a court or arbitrator, the remaining portions of the Agreement will remain in full
force and effect.

9.8. ENTIRE AGREEMENT. This Agreement is the complete and exclusive agreement between the parties
with respect to the subject matter hereof, superseding any prior agreements and communications (both
written and oral) regarding such subject matter. This Agreement may only be modified, or any rights
under it waived, by a written document executed by both parties.

9.9. COUNTERPARTS. This Agreement may be signed in counterparts which, when signed, shall constitute
one document.

12

IN WITNESS WHEREOF, the parties have caused this Agreement to be duly executed and delivered as of
the day and year first above written.

drkoop.com, inc.

By:______________________________ Name: Title:

VITAMIN SHOPPE INDUSTRIES, INC.

By:______________________________ Name: Title:

13

SCHEDULE 1.2(I) SCREEN SHOT MOCK-UPS

[ATTACHED]

EXHIBIT A DIRECT COMPETITORS

* * *

____________________ * * * Certain information on this page has been omitted and filed separately
with the Securities and Exchange Commission. Confidential treatment has been requested with respect
to the omitted portions.
<!-- page 8 -->
EXHIBIT B FORM OF HEALTHLINKS AGREEMENT

[ATTACHED]

EXHIBIT C ADVERTISING SPECIFICATIONS

File Formats

Naming Convention: (lowercase only, 8.3)

Alternate Text: Use ALT tag; ten words or less

Image Dimensions :

Sponsor Banner: 468 pixels by 60 pixels, 234 pixels by 60 pixels, 120 pixels by 60 pixels

Image File Format: [GIF/JPEG]

Image File Size: 12 k maximum file size

File Names:Use Sponsor name.: [Sponsor].gif]

Delivery of GIFs

Email - mbaehr@drkoop.com.com, cc: gsears@drkoop.com.com

We accept [,CompactPro, zip, gzip, and UNIX tar or compress] format tiles. All formats must be
mailed in [ASCII encoding(uuencode, mmencode)].

EXHIBIT D DRKOOP.COM CORPORATE LOGO

[LOGO ATTACHED]

"The Vitamin Shoppe is the proud exclusive vitamin sponsor of drkoop.com."

"The Vitamin Shoppe is a proud sponsor of drkoop.com, the Trusted Health Network, led by Dr. C.
Everett Koop."

The Vitamin Shoppe is a proud sponsor of drkoop.com, the Trusted Health Network, led by Dr. C.
Everett Koop."
