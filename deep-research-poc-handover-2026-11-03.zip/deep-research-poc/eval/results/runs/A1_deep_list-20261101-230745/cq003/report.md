# Which jurisdiction's law governs the Intellectual Property Agreement between Morgan Sta...

*Question:* Which jurisdiction's law governs the Intellectual Property Agreement between Morgan Stanley & Co. Incorporated and MSCI Inc. (dated 2007-11-20)?

## Verify document date and parties

The document under review is titled "Intellectual Property Agreement". [3e3a5bbd900a15ef p.1] The agreement date is 2007-11-20. [3e3a5bbd900a15ef p.1] The parties are Morgan Stanley & Co. [uncited] Incorporated ("MS") and MSCI Inc. [uncited] ("MSCI"). [3e3a5bbd900a15ef p.1] MS and MSCI are individually defined as "Party" and collectively as the "Parties". [3e3a5bbd900a15ef p.1]

## Identify the governing law clause

The Intellectual Property Agreement between Morgan Stanley & Co. [uncited] Incorporated and MSCI Inc. dated 2007-11-20 contains a governing law clause stating that the agreement shall be construed in accordance with and governed by the substantive internal laws of the State of New York. [3e3a5bbd900a15ef p.3] The explicit jurisdiction named in the agreement is the State of New York. [3e3a5bbd900a15ef p.3]

## Verification appendix

Claims: 9 · supported: 6 · partially: 0 · dropped: 0 · gaps: 3 · tier-1 support rate: 1.00

| claim | section | tier 1 | score | sources | note |
|---|---|---|---|---|---|
| s1.1 | s1 | keep | 1.00 | e1→[3e3a5bbd900a15ef p.1] |  |
| s1.2 | s1 | keep | 1.00 | e1→[3e3a5bbd900a15ef p.1] |  |
| s1.3 | s1 | gap |  |  | no evidence cited |
| s1.4 | s1 | gap |  |  | no evidence cited |
| s1.5 | s1 | keep | 1.00 | e1→[3e3a5bbd900a15ef p.1] |  |
| s1.6 | s1 | keep | 1.00 | e1→[3e3a5bbd900a15ef p.1] |  |
| s2.1 | s2 | gap |  |  | no evidence cited |
| s2.2 | s2 | keep | 1.00 | e2→[3e3a5bbd900a15ef p.3] |  |
| s2.3 | s2 | keep | 1.00 | e2→[3e3a5bbd900a15ef p.3] |  |

### Evidence

- e1 [3e3a5bbd900a15ef p.1 L2-7] keep (1.0): "# Intellectual Property Agreement
| Field | Value |
|---|---|
| Document Type | IP Agreement |
| Agreement Date | 2007-11-20 |
| Parties | Morgan Stanley & Co. Incorporated ("MS"); MSCI Inc. ("MSCI"); MS and MSCI individually as "Party" and…"
- e2 [3e3a5bbd900a15ef p.3 L118-122] keep (1.0): "6.1 Governing Law; Jurisdiction; Dispute Resolution.

(a) This Agreement shall be construed in accordance with and governed by the substantive internal laws of the State of New York."
